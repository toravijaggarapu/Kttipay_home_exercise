plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
//    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.dagger.hilt.android)
    alias(libs.plugins.navigation.safe.args)
//    alias(libs.plugins.google.ksp)
    kotlin("kapt")
    id ("kotlin-parcelize")
}

android {
    namespace = "com.fsc.flare"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fsc.flare"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        manifestPlaceholders += mapOf("appAuthRedirectScheme" to "com.fsc.flare")
        buildConfigField("String", "ORG_URL", "\"https://dev-123456.okta.com\"")
    }

    flavorDimensions += "env"

    productFlavors {
        create("l1") {
            dimension = "env"
            applicationIdSuffix = ".l1" // Or full ID: applicationId = "com.fsc.flare.l1"
            versionName = "1.0" //
            resValue("string", "app_name", "L1 FlareApp")
            buildConfigField("String", "CLIENT_ID", "\"0oawsaaqp7gWDVFdn0h7\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oayncrs62czrsdv80h7\"")
            buildConfigField("String", "BASE_URL", "\"https://fscportal-l1.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid-stage.oktapreview.com/oauth2/aus1c2ymhu6qoMpfh0h8/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners-stage.oktapreview.com/oauth2/\"")
            buildConfigField("String", "GATEWAY_URL", "\"https://api-gwl1.services.logistics.fedex.com/\"")
            buildConfigField("String", "ORIGIN", "\"https://fscportal-l1.logistics.fedex.com\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABD-CVZ\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
        create("l2") {
            dimension = "env"
            applicationIdSuffix = ".l2" // Or full ID: applicationId = "com.fsc.flare.l2"
            versionName = "1.0"
            resValue("string", "app_name", "L2 FlareApp")
            buildConfigField("String", "CLIENT_ID", "\"0oawsaaqp7gWDVFdn0h7\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oayncrs62czrsdv80h7\"")
            buildConfigField("String", "BASE_URL", "\"https://fscportal-l2.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid-stage.oktapreview.com/oauth2/aus1c2ymhu6qoMpfh0h8/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners-stage.oktapreview.com/oauth2/\"")
            buildConfigField("String", "GATEWAY_URL", "\"https://api-gwl2.supplychain.logistics.fedex.com/\"")
            buildConfigField("String", "ORIGIN", "\"https://fscportal-l2.logistics.fedex.com\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABD-CVZ\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
        create("l3") {
            dimension = "env"
            applicationIdSuffix = ".l3" // Or full ID: applicationId = "com.fsc.flare.l3"
            versionName = "1.0"
            resValue("string", "app_name", "L3 FlareApp")
            buildConfigField("String", "CLIENT_ID", "\"0oawsaaqp7gWDVFdn0h7\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oayncrs62czrsdv80h7\"")
            buildConfigField("String", "BASE_URL", "\"https://fscportal-l3.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid-stage.oktapreview.com/oauth2/aus1c2ymhu6qoMpfh0h8/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners-stage.oktapreview.com/oauth2/\"")
            buildConfigField("String", "GATEWAY_URL", "\"https://api-gwl3.supplychain.logistics.fedex.com/\"")
            buildConfigField("String", "ORIGIN", "\"https://fscportal-l3.logistics.fedex.com\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABD-CVZ\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
        create("l4") {
            dimension = "env"
            applicationIdSuffix = ".l4" // Or full ID: applicationId = "com.fsc.flare.l4"
            versionName = "1.0"
            resValue("string", "app_name", "L4 FlareApp")
            buildConfigField("String", "CLIENT_ID", "\"0oawsaaqp7gWDVFdn0h7\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oayncrs62czrsdv80h7\"")
            buildConfigField("String", "BASE_URL", "\"https://fscportal-l4.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid-stage.oktapreview.com/oauth2/aus1c2ymhu6qoMpfh0h8/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners-stage.oktapreview.com/oauth2/\"")
            buildConfigField("String", "GATEWAY_URL", "\"https://api-gwl4.supplychain.logistics.fedex.com/\"")
            buildConfigField("String", "ORIGIN", "\"https://fscportal-l4.logistics.fedex.com\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABD-CVZ\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
        create("l5") {
            dimension = "env"
            applicationIdSuffix = ".l5" // Or full ID: applicationId = "com.fsc.flare.l5"
            versionName = "1.0"
            resValue("string", "app_name", "FlareApp") // Note: Name is different here
            buildConfigField("String", "CLIENT_ID", "\"0oawsaaqp7gWDVFdn0h7\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oayncrs62czrsdv80h7\"")
            buildConfigField("String", "BASE_URL", "\"https://www.fscportal-stage.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid-stage.oktapreview.com/oauth2/aus1c2ymhu6qoMpfh0h8/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners-stage.oktapreview.com/oauth2/\"")
            buildConfigField("String", "GATEWAY_URL", "\"https://api-gwl5.supplychain.logistics.fedex.com/\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "ORIGIN", "\"https://www.fscportal-stage.logistics.fedex.com\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABD-CVZ\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
        create("l6") {
            dimension = "env"
            versionName = "1.0"
            resValue("string", "app_name", "FlareApp") // Note: Name is different here
            buildConfigField("String", "CLIENT_ID", "\"0oa99rk0w6K9YXyeQ357\"")
            buildConfigField("String", "TEMP_WORKER_CLIENT_ID", "\"0oa93igbjgmmvlQNf357\"")
            buildConfigField("String", "BASE_URL", "\"https://www.fscportal.logistics.fedex.com/\"")
            buildConfigField("String", "BASE_AUTH_URL", "\"https://purpleid.okta.com/oauth2/aus7u1p6au4Jx3gp7357/\"")
            buildConfigField("String", "TEMP_WORKER_BASE_AUTH_URL", "\"https://purpleid-partners.okta.com/\"")
            buildConfigField("String", "GATEWAY_URL", "\" https://api-supplychain.logistics.fedex.com/\"") // Note: leading space in URL
            buildConfigField("String", "ORIGIN", "\"https://www.fscportal.logistics.fedex.com\"")
            buildConfigField("String", "LOGIN_PAGE_PATH", "\"v1/authorize?\"")
            buildConfigField("String", "APDYNAMICS_KEY", "\"AD-AAB-ABE-KFK\"")
            buildConfigField("boolean", "ENABLE_ACTIVITY_TRANSACTION_TRACKER", "false")
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file("RFMobileApp.jks")
            storePassword = "rfmobileapp"
            keyAlias = "RFMobileApp"
            keyPassword = "rfmobileapp"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
//        compose = true
        dataBinding = true
        buildConfig = true
    }
}

dependencies {

    implementation(fileTree(project.layout.projectDirectory.dir("libs")) {
        include("*.jar", "*.aar")
    })

    // ================ ANDROID ================
    //    implementation(libs.androidx.activity.compose)
//    implementation(platform(libs.androidx.compose.bom))
//    implementation(libs.androidx.ui)
//    implementation(libs.androidx.ui.graphics)
//    implementation(libs.androidx.ui.tooling.preview)
//    implementation(libs.androidx.material3)

    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation ("androidx.constraintlayout:constraintlayout:2.2.1")
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation ("androidx.legacy:legacy-support-v4:1.0.0")
    implementation ("androidx.lifecycle:lifecycle-livedata-ktx:2.9.0")

    implementation ("com.google.android.material:material:1.12.0")

    implementation ("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    implementation(libs.jetbrains.kotlinx.coroutines)

    implementation(libs.zxing.android.embedded)

    // ================ Jetpack ================
//    implementation(libs.androidx.lifecycle.viewmodel)
    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation ("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")

    // ============ OKHTTP & RETROFIT =============
    implementation(libs.squareup.retrofit2)
    implementation(libs.squareup.okhttp3)
    implementation(libs.squareup.gson.convertor)
    implementation(libs.squareup.logging.interceptor)

    // ================ HILT ================
    implementation(libs.hilt.android)
//    implementation(libs.androidx.hilt.compose)
    kapt(libs.hilt.compiler)

    // ================ ROOM DATA_BASE ================
    implementation (libs.androidx.room.runtime)
    kapt(libs.androidx.room.compiler)
    implementation (libs.androidx.room.ktx)

    // ================ NAVIGATION COMPONENTS ================
    implementation (libs.androidx.navigation.fragment.ktx)
    implementation (libs.androidx.navigation.ui.ktx)

    //================ JODA TIME ================
    implementation (libs.joda.time)

    // ================ LOGGER ================
    implementation (libs.slf4j.api)
    implementation (libs.logback.android)

    // ================ WORK MANAGER ================
    implementation (libs.androidx.work.runtime.ktx)
    implementation(libs.appdynamics.runtime)


    // ================ UNIT TEST ================
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    testImplementation ("org.mockito:mockito-core:4.6.1")
    testImplementation ("org.mockito:mockito-inline:3.12.4")
    testImplementation ("org.mockito.kotlin:mockito-kotlin:4.1.0")
    testImplementation ("androidx.arch.core:core-testing:2.2.0")
    testImplementation ("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
    androidTestImplementation ("androidx.test.ext:junit:1.1.5")
    androidTestImplementation ("androidx.test.espresso:espresso-core:3.5.1")
//    androidTestImplementation(platform(libs.androidx.compose.bom))
//    androidTestImplementation(libs.androidx.ui.test.junit4)
//    debugImplementation(libs.androidx.ui.tooling)
//    debugImplementation(libs.androidx.ui.test.manifest)
}

kapt {
    correctErrorTypes = true
}