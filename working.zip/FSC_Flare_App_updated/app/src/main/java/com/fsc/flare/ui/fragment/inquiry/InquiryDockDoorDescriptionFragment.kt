package com.fsc.flare.ui.fragment.inquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryDockDoorDescBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "DockDoorLocation"

/**
 * A simple [InquiryDockDoorDescriptionFragment] class.
 */
@AndroidEntryPoint
class InquiryDockDoorDescriptionFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryDockDoorDescBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryDockDoorDescBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getDDLocation()
        FlareLog.i(TAG, "InquiryDDDescFragment: $data")
        if(data != null){
            val location = data.location!!
            binding.dockDoor.text = location.barCode
            binding.asn.text = ""
            binding.locationStatus.text = location.status
        }

        binding.btnOk.setOnClickListener {

            Handler(Looper.getMainLooper()).postDelayed({
                val action = InquiryDockDoorDescriptionFragmentDirections.actionInquiryDockDoorDescFragmentToInquiryDockDoorFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inquiryDockDoor, true).build()
                getNavigationController().navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME_500)

        }
    }
}