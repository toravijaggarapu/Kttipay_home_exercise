package com.fsc.flare.ui.fragment.receiving

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.google.android.material.textview.MaterialTextView
import java.util.*

class SerialAdapter(
    private var serialList: ArrayList<String>
) : RecyclerView.Adapter<SerialAdapter.ViewHolder>() {
    lateinit var context: Context
    fun update(item: String) {
        serialList.add(item)
        notifyItemInserted(serialList.size)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvSerialNumber: MaterialTextView = itemView.findViewById(R.id.tvSerialNumber)
        var tvSerialNumberValue: MaterialTextView = itemView.findViewById(R.id.tvSerialNumberValue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SerialAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_serial, parent, false)
        context = parent.context
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: SerialAdapter.ViewHolder, position: Int) {
        holder.tvSerialNumber.text = String.format("%s %d :",context.getString(R.string.lbl_serial_v3),position + 1)
        holder.tvSerialNumberValue.text = serialList.get(position)
    }

    override fun getItemCount(): Int {
        return serialList.size
    }

}