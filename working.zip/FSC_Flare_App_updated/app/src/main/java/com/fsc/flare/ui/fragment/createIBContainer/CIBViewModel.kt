package com.fsc.flare.ui.fragment.createIBContainer

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.createIBContainer.CIBItembarcodeResponse
import com.fsc.flare.source.data.dto.createIBContainer.CIBPostRequest
import com.fsc.flare.source.data.dto.createIBContainer.CIBPostResponse
import com.fsc.flare.source.data.dto.createIBContainer.Item
import com.fsc.flare.source.data.dto.inventory.*
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.LookupCode
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.repository.CIBRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "CIBViewModel"

@HiltViewModel
class CIBViewModel @Inject constructor(
    private val cibRepository: CIBRepository
) : BaseViewModel() {

    val newCaseNumberKey = "casenum"
    val palletTransferTypeKey = "PALLET"
    val containerResponse: MutableLiveData<Resource<PalletAdjustmentDetailResponse>> = SingleLiveEvent()
    val itemBarCodeResponse: MutableLiveData<Resource<CIBItembarcodeResponse>> = SingleLiveEvent()
    val lotNumberResponse: MutableLiveData<Resource<ValidateLotNumberResponse>> = SingleLiveEvent()
    val serialNumberResponse: MutableLiveData<Resource<PickingSerialOrItemCodeResponse>> = SingleLiveEvent()
    val lockCodeResponse: MutableLiveData<Resource<InventoryLockCodeResponse>> = SingleLiveEvent()
    val reasonCodeResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val stagingLocationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val cibPostResponse: MutableLiveData<Resource<CIBPostResponse>> = SingleLiveEvent()
    val newContainerResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()

    /**
     * method to get container details
     */
    fun getContainerDetails(containerNumber: String) = viewModelScope.launch {
        containerResponse.postValue(Resource.Loading())
        val response = cibRepository.getContainerDetails(containerNumber)
        containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handleContainerResponse(response: Response<PalletAdjustmentDetailResponse>): Resource<PalletAdjustmentDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponseErrorCode(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to get Item details
     */
    fun getItemDetails(itemBarcode: String) = viewModelScope.launch {
        itemBarCodeResponse.postValue(Resource.Loading())
        val response = cibRepository.getItemDetails(itemBarcode)
        itemBarCodeResponse.postValue(handleItemBarCodeResponse(response))
    }

    /**
     * method to handle ItemBarcode response
     */
    private fun handleItemBarCodeResponse(response: Response<CIBItembarcodeResponse>): Resource<CIBItembarcodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ItemBarcode Success Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ItemBarcode Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate Lot number
     */
    fun validateLotNumber(request: ValidateLotNumberRequest) = viewModelScope.launch {
        lotNumberResponse.postValue(Resource.Loading())
        val response = cibRepository.validateLotNumber(request)
        lotNumberResponse.postValue(handleLotNumberResponse(response))
    }

    /**
     * method to handle Lot number response
     */
    private fun handleLotNumberResponse(response: Response<ValidateLotNumberResponse>): Resource<ValidateLotNumberResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LotNumber Success Response: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    /**
     * method to validate serial number or itemcode API
     */
    fun validateSerialNumber(serialNumberOrItemId: String) = viewModelScope.launch {
        serialNumberResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = cibRepository.validateSerialNumber(serialNumberOrItemId)
        serialNumberResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    /**
     * method to handle serial or Item id validation response
     */
    private fun handleSerialNumberOrItemIdValidationResponse(response: Response<PickingSerialOrItemCodeResponse>): Resource<PickingSerialOrItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            return if (response.code() in 400..501) {
                val responseMessage = handleForwardErrorResponse(response.errorBody(), TAG)
                if (responseMessage.isEmpty()) {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: ${response.message()}")
                    Resource.Error(response.message())
                } else {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: $responseMessage")
                    Resource.Error(responseMessage)
                }
            } else {
                Resource.Error(response.message())
            }
        }
        return null
    }

    /**
     * method to get lock codes
     */
    fun getLockCodes(inventoryLockcodeRequest: InventoryLockcodeRequest) = viewModelScope.launch {
        lockCodeResponse.postValue(Resource.Loading())
        val response = cibRepository.getLockCodes(inventoryLockcodeRequest)
        lockCodeResponse.postValue(handleLockCodesResponse(response))
    }

    /**
     * method to handle lock codes response
     */
    private fun handleLockCodesResponse(response: Response<InventoryLockCodeResponse>): Resource<InventoryLockCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getLockCodesResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getLockCodesResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get Reason codes
     */
    fun getReasonCodes() = viewModelScope.launch {
        reasonCodeResponse.postValue(Resource.Loading())
        val response = cibRepository.getReasonCodes()
        reasonCodeResponse.postValue(handleInventoryLocksResponse(response))
    }

    /**
     * method to handle reason code response
     */
    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getReasonCodesResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getReasonCodesResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate staging location
     */
    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "StagingLocation Request: $locationClassReq")
        stagingLocationResponse.postValue(Resource.Loading())
        val response = cibRepository.validateStagingLocation(locationClassReq)
        stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    /**
     * method to handle staging location response
     */
    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.e(TAG, "StagingLocation Success Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "StagingLocation Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to create IB Container
     */
    fun createIBContainer(cibPostRequest: CIBPostRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "createIBContainer Request: $cibPostRequest")
        cibPostResponse.postValue(Resource.Loading())
        val response = cibRepository.createIBContainer(cibPostRequest)
        cibPostResponse.postValue(handleCreateIBContainerResponse(response))
    }

    /**
     * method to handle create IB Container response
     */
    private fun handleCreateIBContainerResponse(response: Response<CIBPostResponse>): Resource<CIBPostResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.e(TAG, "createIBContainer Success Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "createIBContainer Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    //data to be saved in view model
    var containerData: MutableLiveData<List<PalletAdjustmentResponse>> = MutableLiveData<List<PalletAdjustmentResponse>>()
    var itemBarcodeData: MutableLiveData<Item> =
        MutableLiveData<Item>()
    var serialNumberList: MutableLiveData<List<String>> = MutableLiveData(emptyList())
    var defaultLockCode: MutableLiveData<InventoryLockcode> = MutableLiveData()
    var lockCodeList: MutableLiveData<ArrayList<String>> = MutableLiveData()
    var reasonCodeList: MutableLiveData<ArrayList<String>> = MutableLiveData()
    var inputContainerNumber: MutableLiveData<String> = MutableLiveData()
    var inputQty: MutableLiveData<Int> = MutableLiveData()
    var inputQtyUom: MutableLiveData<String> = MutableLiveData()
    var inputQtyInUnits: MutableLiveData<Int> = MutableLiveData()
    var inputLotNumber: MutableLiveData<String> = MutableLiveData()
    var inputExpiryDate: MutableLiveData<String> = MutableLiveData()
    var inputCoo: MutableLiveData<String> = MutableLiveData()
    var inputLockcode: MutableLiveData<InventoryLockcode> = MutableLiveData()
    var inputReasoncode: MutableLiveData<LookupCode> = MutableLiveData()
    var inputStagingLocation: MutableLiveData<String> = MutableLiveData()

    fun setInputContainerNumber(containerNbr: String?) {
        this.inputContainerNumber.value = containerNbr
    }

    fun getInputContainerNumber(): String?  {
        return inputContainerNumber.value
    }

    fun setInputQty(qty: Int?) {
        this.inputQty.value = qty
    }

    fun getInputQty(): Int?  {
        return inputQty.value
    }

    fun setInputQtyUom(qtyUom: String?) {
        this.inputQtyUom.value = qtyUom
    }

    fun getInputQtyUom(): String?  {
        return inputQtyUom.value
    }

    fun setInputQtyInUnits(qtyInUnits: Int) {
        this.inputQtyInUnits.value = qtyInUnits
    }

    fun getInputQtyInUnits(): Int?  {
        return inputQtyInUnits.value
    }

    fun setInputLotNumber(lotNbr: String?) {
        this.inputLotNumber.value = lotNbr
    }

    fun getInputLotNumber(): String?  {
        return inputLotNumber.value
    }

    fun setInputExpiryDate(expiryDate: String?) {
        this.inputExpiryDate.value = expiryDate
    }

    fun getInputExpiryDate(): String?  {
        return inputExpiryDate.value
    }

    fun setInputCoo(coo: String?) {
        this.inputCoo.value = coo
    }

    fun getInputCoo(): String? {
        return inputCoo.value
    }

    fun setInputLockCode(lockCode: InventoryLockcode?) {
        this.inputLockcode.value = lockCode
    }

    fun getInputLockCode(): InventoryLockcode?  {
        return inputLockcode.value
    }

    fun setInputReasonCode(reasonCode: LookupCode?) {
        this.inputReasoncode.value = reasonCode
    }

    fun getInputReasonCode(): LookupCode?  {
        return inputReasoncode.value
    }

    fun setInputStagingLocation(stagingLoc: String?) {
        this.inputStagingLocation.value = stagingLoc
    }

    fun getInputStagingLocation(): String?  {
        return inputStagingLocation.value
    }

    fun setContainerData(containerList: List<PalletAdjustmentResponse>) {
        this.containerData.value = containerList
    }

    fun getContainerData(): List<PalletAdjustmentResponse>?  {
        return containerData.value
    }

    fun setItemBarcodeData(item: Item?) {
        this.itemBarcodeData.value = item
    }

    fun getItemBarcodeData(): Item?  {
        return itemBarcodeData.value
    }

    fun getSerialNumberList(): List<String>?  {
        return serialNumberList.value
    }

    fun setSerialNumberList(serialList: List<String>?) {
        this.serialNumberList.value = serialList
    }

    fun getDefaultLockCode(): InventoryLockcode? {
        return defaultLockCode.value
    }

    fun setDefaultLockCode(inventoryLockcode: InventoryLockcode?) {
        this.defaultLockCode.value = inventoryLockcode
    }

    fun getLockCodeList(): ArrayList<String>? {
        return lockCodeList.value
    }

    fun setLockCodeList(list: ArrayList<String>?) {
        this.lockCodeList.value = list
    }

    fun getReasonCodeList(): ArrayList<String>? {
        return reasonCodeList.value
    }

    fun setReasonCodeList(list: ArrayList<String>) {
        this.reasonCodeList.value = list
    }

    fun generatePalletCaseNumber(type: String) = viewModelScope.launch {
        newContainerResponse.postValue(Resource.Loading())
        val response = cibRepository.generatePalletCaseNumber(type)
        newContainerResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun resetToDefault() {
        setInputContainerNumber(null)
        setInputQty(0)
        setInputQtyUom(null)
        setInputQtyInUnits(0)
        setInputLotNumber(null)
        setInputExpiryDate(null)
        setInputCoo(null)
        setInputLockCode(null)
        setInputReasonCode(null)
        setContainerData(arrayListOf())
        setItemBarcodeData(null)
        setSerialNumberList(arrayListOf())
        setDefaultLockCode(null)
        setLockCodeList(arrayListOf())
        setReasonCodeList(arrayListOf())
    }

}