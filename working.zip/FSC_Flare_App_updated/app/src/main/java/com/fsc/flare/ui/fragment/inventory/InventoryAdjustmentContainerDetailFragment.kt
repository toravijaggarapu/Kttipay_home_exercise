package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryAdjustmentContainerDetailBinding
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [InventoryAdjustmentContainerDetailFragment] class.
 */
@AndroidEntryPoint
class InventoryAdjustmentContainerDetailFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryAdjustmentContainerDetailBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryAdjustmentContainerDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryIcCtrAdj.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (binding.etQty.isFocusableInTouchMode) {
            showSoftKeyBoard(fragmentContext, binding.etQty)
        }

        val containerList = viewModel.getContainerInfo()
        val uomConversionsList = ArrayList<String>()
        val uomBottomList = ArrayList<String>()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                val containerData = containerList[0]
                binding.txtContainerNumberValue.text = containerData.containerNumber
                if (containerData.item != null) {
                    binding.txtItemCodeValue.text = containerData.item.itemCode
                    binding.txtItemDesValue.text = containerData.item.itemDesc
                    binding.InvTypeValue.text = getInventoryDescription(containerData.inventoryType)
                    binding.txtQtyValue.text = containerData.item.itemQty.toString()
                    binding.txtUomValue.text = containerData.item.itemQtyUom
                    binding.tvtxtUom.text = containerData.item.itemQtyUom
                    containerData.item.uomConversions.forEach { uomConversion ->
                        if (uomConversion.toUOM != "EA") {
                            uomBottomList.add(uomConversion.toUOM + " = " + uomConversion.conversionRate + " " + uomConversion.qtyUOM)
                        }
                        uomConversionsList.add(uomConversion.toUOM)
                    }
                }
                for (i in 0..uomBottomList.size) {
                    if (indexExists(uomBottomList, i)) {
                        when (i) {
                            0 -> {
                                binding.bottomItemInfo.tvSubPack.text = uomBottomList[i]
                            }
                            1 -> {
                                binding.bottomItemInfo.tvPack.text = uomBottomList[i]
                            }
                            2 -> {
                                binding.bottomItemInfo.tvCase.text = uomBottomList[i]
                            }
                            3 -> {
                                binding.bottomItemInfo.tvPallet.text = uomBottomList[i]
                            }
                        }
                    }
                }
            }
        }

        binding.etQty.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                sharedPreferences.edit().putString(PreferenceKeys.Item.QUANTITY_INPUT, binding.etQty.text.toString()).apply()
                val previousQty: Int = Integer.parseInt(binding.txtQtyValue.text.toString())
                when (Integer.parseInt(binding.etQty.text.toString())) {
                    0 -> {
                        showErrorSnackBar(resources.getString(R.string.lbl_cannot_adjust_to_zero))
                        binding.etQty.requestFocus()
                    }
                    previousQty -> {
                        showErrorSnackBar(resources.getString(R.string.lbl_cannot_be_equal))
                        binding.etQty.requestFocus()
                    }
                    else -> {
                        checkAndUpdateQty()
                    }
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etQty.isFocused && !binding.etQty.text.isNullOrEmpty()) {
                        sharedPreferences.edit().putString(PreferenceKeys.Item.QUANTITY_INPUT, binding.etQty.text.toString()).apply()
                        val previousQty: Int = Integer.parseInt(binding.txtQtyValue.text.toString())
                        when (Integer.parseInt(binding.etQty.text.toString())) {
                            0 -> {
                                showErrorSnackBar(resources.getString(R.string.lbl_cannot_adjust_to_zero))
                                binding.etQty.requestFocus()
                            }
                            previousQty -> {
                                showErrorSnackBar(resources.getString(R.string.lbl_cannot_be_equal))
                                binding.etQty.requestFocus()
                            }
                            else -> {
                                checkAndUpdateQty()
                            }
                        }
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    private fun checkAndUpdateQty(){
        val updatedQty: Int = Integer.parseInt(binding.etQty.text.toString())
        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                val containerData = containerList[0]
                //Update the entered qty to the view model.
                containerData.updatedQty = updatedQty
                //Check the condition for serial number if not serial track move to Reason selection.
                if (containerData.item?.tracking != null) {
                    if (containerData.item.tracking.serialNumberRequired == "4") {
                        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                        val action =
                            InventoryAdjustmentContainerDetailFragmentDirections.actionInventoryAdjustmentContainerDetailFragmentToInventoryAdjustmentSerialFragment()
                        navController.navigate(action)
                    } else {
                        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                        val action =
                            InventoryAdjustmentContainerDetailFragmentDirections.actionInventoryAdjustmentContainerDetailFragmentToInventoryAdjustmentReasonFragment()
                        navController.navigate(action)
                    }
                }
            }
        }
    }
}