package com.fsc.flare.ui.fragment.kitting

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentItemScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.Item
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ItemScanFragment"

/**
 * A simple [ItemScanFragment] class.
 */
@AndroidEntryPoint
class ItemScanFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: KittingViewModel by activityViewModels()
    private lateinit var binding: FragmentItemScanBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etScanItem.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etScanItem)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentItemScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        val pallet = viewModel.getPalletResponse()
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        binding.tvKitStagingLocationValue.text = pallet.kitStagingLocation
        binding.tvItemNameValue.text = "Mixed Items"
        binding.tvItemDescValue.text = "Mixed"
        binding.kittingItemLayoutInclude.tvKitItemNameValue.text = viewModel.kitItem.kitItemName
        binding.kittingItemLayoutInclude.tvKitItemDescValue.text = viewModel.kitItem.kitItemDescription

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etScanItem.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etScanItem)
                    if (binding.etScanItem.isFocused && !binding.etScanItem.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Item field focused")
                        getItemInfo()
                      //  validateItem()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etScanItem.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanItem)
                if (binding.etScanItem.isFocused && !binding.etScanItem.text.isNullOrEmpty()) {
                    FlareLog.i(TAG, "Item field focused")
                    getItemInfo()
                   // validateItem()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etScanItem.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etScanItem)
                binding.tvScanItemResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })

        binding.kittingItemLayoutInclude.tvKitViewButton.setOnClickListener {
              showKitItemDialog(viewModel.kitItem) {}
        }
    }
    private fun getItemInfo() {
        binding.tvScanItemResponse.text = null
        viewModel.getItems(
            PackageItemRequest(
                "Detail",
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                "0",
                binding.etScanItem.text.toString(),
                ""
            )
        )
    }

    private fun validateItem(item: com.fsc.flare.source.data.dto.receiving.item.Item) {
        val pallet = viewModel.getPalletResponse()
        val itemsListResult = pallet.containersList!![0].items
        val selectedItem = getItemByID(item.itemId, itemsListResult!!)
        if (selectedItem != null) {
            viewModel.setItem(selectedItem)
            if (selectedItem.lotRequired == "1") {
                navController.navigate(R.id.action_itemScanFragment_to_selectLotFragment)
            } else {
                navController.navigate(R.id.action_itemScanFragment_to_moveQtyFragment)
            }
        } else {
            displayErrorMessage(getString(R.string.item_not_matched))
        }
    }

    private fun subscribeObservers() {
        viewModel.packageItemResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { packageItemResponse ->
                        FlareLog.i(TAG, "packageItem Success: $packageItemResponse")
                        if (packageItemResponse != null) {
                            handleItemBarcodeResponse(packageItemResponse)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        binding.tvScanItemResponse.text = message
                        FlareLog.e(TAG, "packageItem error: $message")
                    }
                }
            }
        }
    }
    private fun handleItemBarcodeResponse(itemBarcodeResponse: PackageItemResponse) {
        if (itemBarcodeResponse.success) {
            if (itemBarcodeResponse.items != null && itemBarcodeResponse.items.isNotEmpty()) {
                if (itemBarcodeResponse.items.size == 1) {
                    val item = itemBarcodeResponse.items[0]
                    validateItem(item)
                }
                else if (itemBarcodeResponse.items.size > 1)
                {
                    //implement multiple item barcode logic
                    // Multiple Items having same Item Barcode or Multiple items having the same UPC
                    val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                    val str = "<font color='#340e5f'>" + "Select Item" + "</font>"
                    builder.setTitle(HtmlCompat.fromHtml(str, HtmlCompat.FROM_HTML_MODE_LEGACY))
                    val items = itemBarcodeResponse.items
                    val itemsList = ArrayList<String>()
                    for (item in items) {
                        val itemType = item.itemName
                        itemsList.add(itemType)
                    }
                    val itemsArray: Array<String> = itemsList.toTypedArray()

                    builder.setSingleChoiceItems(itemsArray, -1) { dialogInterface, pos ->
                        val item = itemBarcodeResponse.items[pos]
                        validateItem(item)
                        dialogInterface.dismiss()
                    }
                    builder.setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
                        dialog.cancel()
                    }
                    // create and show the alert dialog
                    val dialog = builder.create()
                    dialog.setCancelable(false)
                    dialog.show()
                }
            }else{
                displayErrorMessage(getString(R.string.invalid_item_barcode))
            }
        }else
        {
            displayErrorMessage(getString(R.string.invalid_item_barcode))
        }
    }

    private fun displayErrorMessage(message: String) {
       // binding.etScanItem.text = null
        binding.etScanItem.selectAll()
        binding.etScanItem.requestFocus()
        binding.tvScanItemResponse.text = message
    }

    private fun getItemByName(itemNameToCheck: String, items: List<Item>): Item? {
        return items.find { it.itemName == itemNameToCheck }
    }

    private fun getItemByID(itemIDToCheck: Int, items: List<Item>): Item? {
        return items.find { it.itemId == itemIDToCheck }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etScanItem.setText(scan?.barcode.toString())
            binding.etScanItem.text?.length?.let {
                binding.etScanItem.setSelection(it)
              //  validateItem()
                getItemInfo()
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

}