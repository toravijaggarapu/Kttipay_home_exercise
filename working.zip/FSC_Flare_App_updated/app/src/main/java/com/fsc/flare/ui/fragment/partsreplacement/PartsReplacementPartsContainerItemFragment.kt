package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementItemBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_TYPE_PUTAWAY
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementPartsContainerItemFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementPartsContainerItemFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var partsReplacementFragmentItemBinding: FragmentPartsReplacementItemBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails : List<TaskDetail>
    lateinit var task : List<Task>


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementFragmentItemBinding =
            FragmentPartsReplacementItemBinding.inflate(inflater, container, false)
        partsReplacementFragmentItemBinding.lifecycleOwner = this
        return partsReplacementFragmentItemBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        taskDetails?.let {
            with(partsReplacementFragmentItemBinding) {
                tvPalletCartIdValue.text = taskDetails.get(viewModel.getIndexCountValue()).taskId
                tvItemValue.text = taskDetails.get(viewModel.getIndexCountValue()).itemId
                tvDescriptionValue.text = taskDetails.get(viewModel.getIndexCountValue()).itemDescription
                tvPartContainerValue.text = taskDetails.get(viewModel.getIndexCountValue()).ibContainerNumber
                tvInventoryTypeValue.text = taskDetails.get(viewModel.getIndexCountValue()).invType
            }
        }

        addListeners()

    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {

        partsReplacementFragmentItemBinding.etPartContainerItem.doAfterTextChanged {
            partsReplacementFragmentItemBinding.errResponse.text = null
        }

        partsReplacementFragmentItemBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementFragmentItemBinding.etPartContainerItem)
                    if (partsReplacementFragmentItemBinding.etPartContainerItem.isFocused) {
                        validateTest()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementFragmentItemBinding.etPartContainerItem.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementFragmentItemBinding.etPartContainerItem)
                validateTest()
            }
            false
        }
    }

    private fun updateMoveTaskDetailsRf() {
        viewModel.getMoveTaskList().firstOrNull()?.let {
            viewModel.updateMoveTaskDetailsRf(
                UpdateMoveTaskDetailsRequest(
                    taskId = it.taskId,
                    taskType = TASK_TYPE_PUTAWAY,
                    actionType = "",
                    toteNumber = taskDetails.get(viewModel.getIndexCountValue()).toteNumber?:"",
                    toteId = taskDetails.get(viewModel.getIndexCountValue()).refContainerId?:"",
                    partRunnerCart = it.partRunnerCart?:"",
                    partRunnerCartId = it.partRunnerCartId?.toIntOrNull() ?: 0
                )
            )
        }
    }

    private fun subscribeObservers() {
        viewModel.updateMoveTaskDetailsRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { updateRepairTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(updateRepairTaskRfResponse)
                        FlareLog.e(TAG, "updateRepairTaskRfResponse : ${updateRepairTaskRfResponse.toString()}")
                        if(!viewModel.getSerialNumberList().isNullOrEmpty()) {
                            navigateToSerialFragment()
                        } else   if (viewModel.getIndexCountValue() < viewModel.getTaskDetailsSize()-1) {
                            viewModel.setIndexCountValue(viewModel.getIndexCountValue()+1)
                            navigateToPartsPutawayContainerFragment()
                        } else {
                            navigateToPartsPutawayLocationsFragment()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "updateRepairTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                else -> {}
            }
        }
    }


    private fun validateTest() {
        subscribeObservers()
        val etPartContainerItem = partsReplacementFragmentItemBinding.etPartContainerItem.text.toString().trim()
        if (etPartContainerItem.isNotEmpty()) {
            partsReplacementFragmentItemBinding.errResponse.text = null
            if (partsReplacementFragmentItemBinding.tvItemValue.text.toString().trim() == etPartContainerItem) {
                updateMoveTaskDetailsRf()
            }
        }
    }

    private fun hideProgressBar() {
        partsReplacementFragmentItemBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementFragmentItemBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementFragmentItemBinding.etPartContainerItem.setText(scan?.barcode.toString())
        partsReplacementFragmentItemBinding.etPartContainerItem.text?.length?.let {
            partsReplacementFragmentItemBinding.etPartContainerItem.setSelection(it)
        }
        validateTest()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToSerialFragment() {
        val action = PartsReplacementPartsContainerItemFragmentDirections.actionPartsReplacementPartsContainerItemFragmentToPartsReplacementSerialNumberFragment()
        findNavController().navigate(action)
    }

    private fun navigateToPartsPutawayLocationsFragment() {
        viewModel.setIndexCountValue(0)
        val action =
            PartsReplacementPartsContainerItemFragmentDirections.actionPartsReplacementPartsContainerItemFragmentToPartsReplacementPutawayLocationFragmen()
        findNavController().navigate(action)
    }

    private fun navigateToPartsPutawayContainerFragment() {
        val action =
            PartsReplacementPartsContainerItemFragmentDirections.actionPartsReplacementPartsContainerItemFragmentToPartsReplacementPartsContainerFragment()
        findNavController().navigate(action)
    }

    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementFragmentItemBinding.errResponse.text = errorMessage
        partsReplacementFragmentItemBinding.etPartContainerItem.requestFocus()
        partsReplacementFragmentItemBinding.etPartContainerItem.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementFragmentItemBinding.etPartContainerItem)
    }

}