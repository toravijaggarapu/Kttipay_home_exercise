package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.receiving.Container
import com.fsc.flare.source.data.dto.taskgroup.GroupTask
import com.fsc.flare.source.data.dto.taskgroup.PickGroupedTaskRequest
import com.fsc.flare.source.data.dto.taskgroup.VirtualContainer
import com.fsc.flare.source.repository.GroupTaskRepository
import com.fsc.flare.source.repository.MasterPalletRepackRepository
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_PRINT_REQUESTERS
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.PICK_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.PRINT_REQUESTER_API_ERROR
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PrintLabelTypes.IB_CASE_LABEL
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EnterCaseCountViewModel @Inject constructor(
    private val repository: GroupTaskRepository,
    private val masterPalletRepackRepository: MasterPalletRepackRepository,
    private val sharedPreferences: SharedPreferences
) : CaseCountBaseViewModel(repository, sharedPreferences) {

    val screenState = innerScreenState.asStateFlow()

    private val _enterCaseCountState = SingleLiveEvent<EnterCaseCountScreenState>()
    val enterCaseCountState: LiveData<EnterCaseCountScreenState> = _enterCaseCountState

    private val printRequesters = mutableListOf<String>()

    fun initData(groupTask: GroupTask, palletInfo: PalletInformation) {
        this.groupTask = groupTask
        this.palletInfo = palletInfo
    }

    fun getContainersToBePick(): List<VirtualContainer> {
        return groupTask.containersToBePicked ?: emptyList()
    }

    fun getNoOfCasesToBePicked(): Int {
        return groupTask.numOfContainersToBePicked
    }

    /**
     * Function to get print requesters API Call.
     */
    fun getPrintRequesters(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val request = PrinterConfigRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                page = 0,
                pageLimit = 100,
                printerType = "LBL"
            )
            val response = masterPalletRepackRepository.getPrintRequestorList(request)
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { successResponse ->
                if (successResponse.printerConfigs.isNotEmpty()) {
                    printRequesters.clear()
                    printRequesters.addAll(successResponse.printerConfigs.map { it.requestor })
                    _enterCaseCountState.postValue(EnterCaseCountScreenState.PrintRequesters(printRequesters))
                } else {
                    innerScreenState.emit(CaseCountFlowState.ShowError(NO_PRINT_REQUESTERS))
                }
            } ?: run {
                val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
                innerScreenState.emit(CaseCountFlowState.ShowError(PRINT_REQUESTER_API_ERROR, errorResponse))
            }
        }
    }

    /**
     * Function to print labels API Call.
     */
    fun printLabels(
        scope: CoroutineScope = viewModelScope,
        containers: List<VirtualContainer>,
        printRequester: String,
    ) {
        scope.launch {
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val response = masterPalletRepackRepository.printContainerLabelInfo(
                PrintContainerLabelRequest(
                    printRequester = printRequester,
                    labelType = IB_CASE_LABEL,
                    containers = containers.map {
                        Container(
                            containerId = it.containerId,
                            containerNumber = it.containerNumber
                        )
                    }
                )
            )
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { successResponse ->
                if (successResponse.success) {
                    _enterCaseCountState.postValue(EnterCaseCountScreenState.PrintSuccess)
                } else {
                    innerScreenState.emit(
                        CaseCountFlowState.ShowError(
                            errorCode = PRINT_REQUESTER_API_ERROR,
                            errorMessage = successResponse.message
                        )
                    )
                }
            } ?: run {
                val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
                innerScreenState.emit(CaseCountFlowState.ShowError(PRINT_REQUESTER_API_ERROR, errorResponse))
            }
        }
    }

    /**
     * Function to call pick cases API.
     */
    fun pickCases(
        scope: CoroutineScope = viewModelScope,
        quantity: Int,
        preferredContainers: List<VirtualContainer>
    ) {
        scope.launch {
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val groupTaskPickRequest = PickGroupedTaskRequest(
                cartNbr = palletInfo.cartNumber,
                cartId = palletInfo.cartId,
                flareShipmentId = groupTask.shipmentId ?: 0,
                shipmentStopSeq = groupTask.shipmentStopSeq ?: 0,
                pickLocId = groupTask.pickLocId ?: 0,
                pickedQty = quantity,
                preferredCaseIds = preferredContainers.map { it.containerId.toLong() },
                shipmentNbr = groupTask.shipmentNbr.orEmpty()
            )

            val response = repository.pickGroupedTask(groupTaskPickRequest)
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.taskInfo?.let {
                    when {
                        it.eligibleToStage -> {
                            _enterCaseCountState.postValue(
                                EnterCaseCountScreenState.StagePending(
                                    cartNumber = it.groupTask.cartNbr,
                                    stageLocationId = it.stageLocId ?: 0,
                                    stageLocation = it.stageLocBarcode.orEmpty()
                                )
                            )
                        }

                        !it.eligibleToStage && it.groupTask.containersToBePicked?.isNotEmpty() == true -> {
                            groupTask = it.groupTask.copy()
                            _enterCaseCountState.postValue(EnterCaseCountScreenState.GroupTaskData(groupTask))
                        }

                        else -> {
                            _enterCaseCountState.postValue(EnterCaseCountScreenState.PickSuccessWithNoTask)
                        }
                    }
                } ?: innerScreenState.emit(CaseCountFlowState.ShowError(PICK_API_ERROR))
            } ?: run {
                val errorMessage = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
                innerScreenState.emit(CaseCountFlowState.ShowError(PICK_API_ERROR, errorMessage))
            }
        }
    }

    fun clearData() {
        innerScreenState.value = null
    }
}

/**
 * Sealed class to represent the Enter case count screen state.
 */
sealed class EnterCaseCountScreenState {
    data class PrintRequesters(val printRequesters: List<String>) : EnterCaseCountScreenState()
    data object PrintSuccess : EnterCaseCountScreenState()
    data class StagePending(
        val cartNumber: String,
        val stageLocationId: Int,
        val stageLocation: String
    ) : EnterCaseCountScreenState()

    data class GroupTaskData(val groupTask: GroupTask) : EnterCaseCountScreenState()
    data object PickSuccessWithNoTask : EnterCaseCountScreenState()
}