package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogPrintRequesterSelectionBinding
import com.fsc.flare.databinding.FragmentInvmBlindPalletBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmBlindPalletErrors
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmBlindPalletViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.setNavigationResult
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "InvmBlindPalletFragment"
const val BLIND_PALLET_RESULT = "blindPalletResult"
@AndroidEntryPoint
class InvmBlindPalletFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private  val viewModel: InvmBlindPalletViewModel by viewModels()
    private lateinit var binding: FragmentInvmBlindPalletBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentInvmBlindPalletBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        viewModel.setRequiredData(sharedViewModel.taskDetails, sharedViewModel.selectedTaskMode, sharedViewModel.sourceDetails)
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        handleGeneratePalletBtnClick()
        observeEvents()
    }

    private fun setTextChangedListener() {
        binding.palletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun handleEnterKeyEvent() {
        binding.palletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validatePallet()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        validatePallet()
                    }
                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validatePallet() {
        if (!binding.palletNumber.text.isNullOrEmpty()){
            viewModel.validatePallet(binding.palletNumber.text.toString().trim())
        }
    }

    private fun handleGeneratePalletBtnClick() {
        binding.btnNewPallet.setOnClickListener{
            viewModel.generatePalletNumber()
        }
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.incProgressBar.progressLoading.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { errorType ->
            val errorMessage = errorType?.let {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                when (it) {
                    is InvmBlindPalletErrors.ApiError -> it.errorMessage
                    is InvmBlindPalletErrors.PrefixStartsWith -> getString(R.string.pallet_prefix_length_validation, it.containerType.ctyId, it.containerType.ctyContainerLength)
                    InvmBlindPalletErrors.PalletAlreadyExist -> getString(R.string.pallet_prefix_length_validation)
                }
            } ?: ""
            binding.errResponse.text = errorMessage
        }

        viewModel.palletNumber.observe(viewLifecycleOwner){palletNumber ->
            sharedViewModel.blindPallet = palletNumber
            viewModel.getPrintRequesters()
        }

        viewModel.printRequestersResponse.observe(viewLifecycleOwner){response ->
            showPrintRequesters(response.printerConfigs.map { it.requestor })
        }

        viewModel.printPalletResponse.observe(viewLifecycleOwner) { palletPrintResponse ->
            if (palletPrintResponse.success) {
                showSuccessSnackBarStd(palletPrintResponse.message){ setPalletAndNavigateBack() }
            } else {
                showErrorSnackBarStd(palletPrintResponse.message){ setPalletAndNavigateBack() }
            }
        }
    }

    private fun setPalletAndNavigateBack(){
        setNavigationResult(key = BLIND_PALLET_RESULT,result =viewModel.palletNumber.value ?: "")
        getNavigationController().popBackStack()
    }


    private fun showPrintRequesters(requesters : List<String>) {
        if (requesters.isNotEmpty()) {
            sharedViewModel.defaultPrinter = requesters[0]
            val dialogBinding = DialogPrintRequesterSelectionBinding.inflate(layoutInflater)
            val dialog =
                MaterialAlertDialogBuilder(requireContext(), R.style.AlertDialogTheme).apply {
                    setView(dialogBinding.root)
                    setCancelable(false)
                }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }
            dialogBinding.tvPalletNumberValue.text = sharedViewModel.blindPallet
            dialogBinding.PrintRequesterDropDown.setOptions(ArrayList(requesters))
            dialogBinding.PrintRequesterDropDown.boolFoo.observe(viewLifecycleOwner) { selectedOption ->
                sharedViewModel.defaultPrinter = selectedOption
            }
            dialogBinding.btnPrint.setOnClickListener {
                dialog.dismiss()
                viewModel.printPalletLabel(requester = sharedViewModel.defaultPrinter ?: "")
            }
            dialogBinding.btnCancel.setOnClickListener {
                setPalletAndNavigateBack()
                dialog.dismiss()
            }
            dialogBinding.PrintRequesterDropDown.setSelectedValue(sharedViewModel.defaultPrinter ?: "")
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        binding.palletNumber.setText(scan?.barcode.toString())
        binding.palletNumber.text?.length?.let {binding.palletNumber.setSelection(it)}
        validatePallet()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}