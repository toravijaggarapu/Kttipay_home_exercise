package com.fsc.flare.transactiontracker

import com.fsc.flare.BuildConfig
import com.fsc.flare.transactiontracker.dto.FSCTrackerContainerDetailModel
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.fsc.flare.transactiontracker.dto.FSCTransactionDetailModel
import com.fsc.flare.transactiontracker.logs.FSCTrackerLogFileManager
import com.google.gson.GsonBuilder
import java.util.Locale


class FSCTransactionTracker {

    private var mUserId: String? = null
    private var mModuleName: String = ""
    private var childSeqNo: Int = 1
    var mainSeqNo: Int = 1
    private var mTransactionModel: FSCTransactionDetailModel? = null
    private var moduleTransactionList = arrayListOf<FSCTransactionDetailModel>()
    private var transactionData: FSCTrackerListModel? = null

    fun setUserId(userId: String): FSCTransactionTracker {
        mUserId = userId
        return this
    }

    fun setModuleName(moduleName: String): FSCTransactionTracker {
        mModuleName = moduleName
        return this
    }

    fun setTransactionModel(transactionModel: FSCTransactionDetailModel): FSCTransactionTracker {
        mTransactionModel = transactionModel
        val screenName = transactionModel.screenName.lowercase(Locale.getDefault())
        if (screenName.contains("menu") || screenName.contains("home") || screenName.contains("account")) {
            mainSeqNo = 0
        } else {
            moduleTransactionList.add(transactionModel)
        }
        return this
    }

    fun setTriggersModel(containerDetail: FSCTrackerContainerDetailModel): FSCTransactionTracker {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            if (moduleTransactionList.isNotEmpty()) {
                containerDetail.seqNo = childSeqNo
                mTransactionModel = moduleTransactionList[moduleTransactionList.size - 1]
                if (mTransactionModel != null) {
                    if (mTransactionModel!!.apiTriggers.isNotEmpty()) childSeqNo += 1
                    else childSeqNo = 1

                    mTransactionModel!!.apiTriggers.add(containerDetail)
                }
            }
        }
        return this
    }

    private fun getTransactionJson(trackerArray: FSCTrackerListModel): String {
        val gson = GsonBuilder().setPrettyPrinting().create()
        return gson.toJson(trackerArray)
    }

    fun getTrackerData(): FSCTrackerListModel? {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            if (moduleTransactionList.isNotEmpty()) {
                transactionData = FSCTrackerListModel(
                    transactionType = mModuleName,
                    startTimeStamp = moduleTransactionList[0].eventTimeStamp,
                    endTimeStamp = moduleTransactionList[moduleTransactionList.size - 1].eventTimeStamp,
                    events = moduleTransactionList,
                )
                transactionData!!.events = moduleTransactionList
                return transactionData
            }
        }
        return null
    }

    fun writeTrackerData(cusId: Long, buId: Long, fcyId: Long) {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            transactionData?.let {
                it.customerId = cusId
                it.businessId = buId
                it.facilityId = fcyId
                FSCTrackerLogFileManager.writeTransaction(getTransactionJson(it))
            }
        }
    }

    fun resetData() {
        moduleTransactionList.clear()
        childSeqNo = 1
        mainSeqNo = 1
        FSCTrackerLogFileManager.deleteTrackerData()
    }

    fun readTrackerData(): FSCTrackerListModel? {
        return FSCTrackerLogFileManager.readTrackerData()
    }
}