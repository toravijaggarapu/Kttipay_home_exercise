package com.fsc.flare.ui.fragment.packing

import android.app.Dialog
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackingSuccessBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.databinding.RfPackItemDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packing.req.DeManifestCartonInfo
import com.fsc.flare.source.data.dto.packing.req.DeManifestRequest
import com.fsc.flare.source.data.dto.packing.req.ManifestCartonInfo
import com.fsc.flare.source.data.dto.packing.req.ManifestRequest
import com.fsc.flare.source.data.dto.packing.req.PackedContainerDetail
import com.fsc.flare.source.data.dto.packing.req.PrintLabelRequest
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.req.UnPackRequest
import com.fsc.flare.source.data.dto.packing.res.CartonDetail
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackingSuccessFragment"

@AndroidEntryPoint
class PackingSuccessFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPackingSuccessBinding
    private val viewModel: PackingViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    // Manifest Recall Error Code
    val ERROR_RECALL_MANIFEST = "ERR-MF-RC-01"

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackingSuccessBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        subscribeObservers()

        return binding.root
    }

    fun subscribeObservers() {
        // Get Confirm Pack Qty API Response
        viewModel.confirmPackQtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { confirmPackQtyResponse ->
                        FlareLog.i(TAG, "confirmPackQtyResponse success: $confirmPackQtyResponse")
                        showSuccessSnackBarStd(resources.getString(R.string.packing_successful)) {
                            // Call PackComplete API
                            viewModel.callPackAPI("", viewModel.cartonInfo!!.obContainerNumber)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackStationListResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Packing Status From API
        viewModel.packAPIResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packAPIResponse ->
                        FlareLog.i(TAG, "packAPIResponse success: $packAPIResponse")
                        viewModel.cartonInfo = packAPIResponse.carton
                        updateData()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PACK API Response error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Packing Status From API
        viewModel.manifestAPIResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { manifestAPIResponse ->
                        FlareLog.i(TAG, "manifestAPIResponse success: $manifestAPIResponse")

                        showSuccessSnackBarStd(manifestAPIResponse.message) {
                            // Call Pack API to get the updated data
                            viewModel.callPackAPI("", viewModel.cartonInfo!!.obContainerNumber)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Manifest API Response error: $message")
                        handleManifestErrorResponse(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Packing Status From API
        viewModel.printAPIResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printAPIResponse ->
                        FlareLog.i(TAG, "printAPIResponse success: $printAPIResponse")
                        showSuccessSnackBar(printAPIResponse.message)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Print API Response error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Packing Status From API
        viewModel.sendToPRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { sendToPRResponse ->
                        FlareLog.i(TAG, "sendToPRResponse success: $sendToPRResponse")
                        showSuccessSnackBarStd(sendToPRResponse.message) {
                            // Call Pack API to get the updated data
                            viewModel.callPackAPI("", viewModel.cartonInfo!!.obContainerNumber)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "sendToP API Response error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get UnPack Status From API
        viewModel.unPackAPIResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { unPackAPIResponse ->
                        FlareLog.i(TAG, "unPackAPIResponse success: $unPackAPIResponse")
                        showSuccessSnackBarStd(resources.getString(R.string.unpack_successful)) {
                            // Call PackComplete API
                            viewModel.callPackAPI("", viewModel.cartonInfo!!.obContainerNumber)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "unPackAPIResponse API Response error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleManifestErrorResponse(msg: String) {
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            showErrorSnackBar(responseMessage)
            if(errorMessage[0].equals(ERROR_RECALL_MANIFEST, ignoreCase = true)) {
                binding.ldUnpackButton.isEnabled = true
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateData()
    }

    fun updateData() {

        binding.toteNumberGroup.visibility = View.GONE
        binding.cartonNumberGroup.visibility = View.GONE

        if(viewModel.cartonNumber.isEmpty()){
            // Set Tote Number
            binding.toteNumberGroup.visibility = View.VISIBLE
            binding.tvToteNumberValue.text = viewModel.toteNumber
        }
        else {
            // Set Carton Number
            binding.cartonNumberGroup.visibility = View.VISIBLE
            binding.tvCartonNumberValue.text = viewModel.cartonNumber
        }

        // Set Shipping Method
        binding.tvTotalPickedQtyValue.text =
            viewModel.getTotalPickedQty().toString().plus(" ").plus(
                viewModel.cartonInfo?.cartonDetails?.get(0)?.pickedQtyUom
            )

        // Set Number of Items
        binding.tvTotalNoOfItemsValue.text = viewModel.getTotalNumberOfItems().toString()

        binding.tvViewButton.setOnClickListener {
            showItemDialog(viewModel.cartonInfo?.cartonDetails!!, {})
        }

        // Set Carton Status
        binding.tvCartonStatusValue.text = getContainerStatus(viewModel.getCartonStatus())

        // Set Customer Order Number
        binding.tvCustomerOrderNumberValue.text = viewModel.getCustomerOrderNumber()

        // Set Order Status
        binding.tvOrderStatusValue.text = getOrderStatus(viewModel.getOrderStatus())

        // Set Manifest Number
        if(viewModel.cartonInfo?.manifestNumber.isNullOrEmpty()) {
            binding.manifestNumberGroup.visibility = View.GONE
            binding.trackingNumberGroup.visibility = View.GONE

            binding.ldManifestButton.visibility = View.VISIBLE
            binding.ldManifestButton.text = resources.getString(R.string.MANIFEST)
        }
        else {
            binding.trackingNumberGroup.visibility = View.VISIBLE
            binding.manifestNumberGroup.visibility = View.VISIBLE
            binding.tvManifestNumberValue.text = viewModel.cartonInfo?.manifestNumber
            binding.tvTrackingNumberValue.text = viewModel.cartonInfo?.trackingNumber

            binding.ldManifestButton.visibility = View.VISIBLE
            binding.ldManifestButton.text = resources.getString(R.string.DEMANIFEST)
        }

        // Handle Back Button
        binding.ldBackButton.setOnClickListener {
            navigateToPackingFragment()
        }

        // Handle PACK Button
        binding.ldPackButton.isEnabled =
            viewModel.isContainerPickingCompleted(viewModel.cartonInfo!!)
        binding.ldPackButton.setOnClickListener {
            binding.tvError.visibility = View.INVISIBLE

            if (viewModel.isContainerPickingCompleted(viewModel.cartonInfo!!) == true) {
                handlePackAction()
            } else {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text =
                    resources.getString(R.string.error_carton_not_eligible_packing)
            }
        }

        // If Manifest Number is not empty then enable
        if((!viewModel.cartonInfo?.manifestNumber.isNullOrEmpty())) {
            binding.ldManifestButton.isEnabled = true
        }
        else if(viewModel.isLTLOrder()){
            binding.ldManifestButton.isEnabled = false
        }
        else {
            binding.ldManifestButton.isEnabled =
                viewModel.isContainerPackCompleted(viewModel.cartonInfo!!) || viewModel.isContainerWeighed(
                    viewModel.cartonInfo!!
                )
        }
        binding.ldManifestButton.setOnClickListener {
            binding.tvError.visibility = View.INVISIBLE


            if(viewModel.cartonInfo?.manifestNumber.isNullOrEmpty() && (viewModel.isContainerPackCompleted(viewModel.cartonInfo!!) ||  viewModel.isContainerWeighed(viewModel.cartonInfo!!))) {
                handleManifestAction()
            }
            else if (!viewModel.cartonInfo?.manifestNumber.isNullOrEmpty()) {
                handleDeManifestAction()
            } else {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text =
                    resources.getString(R.string.error_carton_not_eligible_manifesting)
            }
        }

        binding.ldPrintButton.setOnClickListener {
            binding.tvError.text = ""
            binding.tvError.visibility = View.INVISIBLE

            handlePrintAction()
        }

        binding.ldSendToPr.isEnabled =
            viewModel.isContainerPickingCompleted(viewModel.cartonInfo!!)!!
        binding.ldSendToPr.setOnClickListener {
            binding.tvError.text = ""
            binding.tvError.visibility = View.INVISIBLE

            handleSendToPR()
        }

        binding.ldUnpackButton.isEnabled = viewModel.isContainerWeighed(viewModel.cartonInfo!!) || viewModel.isContainerPackCompleted(viewModel.cartonInfo!!)

        binding.ldUnpackButton.setOnClickListener {
            handleUnPackAction()
        }
    }

    protected fun showItemDialog(
        cartonDetailList: List<CartonDetail>,
        onPositiveClick: () -> Unit
    ) {
        val dialogView = RfPackItemDialogBinding.inflate(layoutInflater)

        dialogView.packItemHeaderInclude.tvComponentName.typeface = Typeface.DEFAULT_BOLD
        dialogView.packItemHeaderInclude.tvMinQty.typeface = Typeface.DEFAULT_BOLD

        dialogView.packItemHeaderInclude.tvComponentName.text =
            resources.getString(R.string.lbl_packed_item)
        dialogView.packItemHeaderInclude.tvMinQty.text =
            resources.getString(R.string.lbl_packed_item_qty)

        dialogView.rvItems.layoutManager = LinearLayoutManager(fragmentContext)

        val dialog = AlertDialog.Builder(fragmentContext).setView(dialogView.root).create()
        dialogView.btnOk.setOnClickListener {
            dialog.dismiss()
            onPositiveClick()
        }
        dialog.setCancelable(false)
        dialog.setOnShowListener {
            val packItemAdapter = PackItemAdapter(cartonDetailList)
            dialogView.rvItems.adapter = packItemAdapter
        }
        dialog.show()
    }


    fun handlePackAction() {
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        val packingMethod = viewModel.getPackMethodCode()
        val toteNumber = viewModel.toteNumber
        val cartonId = viewModel.getCartonId()
        val selectAll = true;

        viewModel.confirmPackQty(
            custId,
            fcyId,
            buId,
            packingMethod,
            toteNumber,
            cartonId,
            selectAll
        )
    }

    fun handleUnPackAction() {
        val cartonId = viewModel.getCartonId()
        val unPackRequest = UnPackRequest(cartonId)
        viewModel.callUnPackAPI(unPackRequest)
    }

    fun handleManifestAction() {

        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        val containerId = viewModel.getContainerId()
        val cartonId = viewModel.getCartonId()
        val shipmentMethod = viewModel.getShipmentMethodCode()
        val packingMethod = viewModel.getPackMethodCode()
        val autoPrintLables = true
        val autoPrintPackingSlip = true
        val saturdayDelivery = if (viewModel.saturdayDelivery) "Y" else "N"
        val cartonType = viewModel.getCartonTypeValue()
        val requestor = viewModel.getPackStationDescription()

        val cartonInfo = ManifestCartonInfo(
            custId,
            fcyId,
            buId,
            containerId,
            cartonId,
            shipmentMethod,
            packingMethod,
            autoPrintLables,
            autoPrintPackingSlip,
            saturdayDelivery,
            cartonType,
            requestor
        )

        val manifestRequest = ManifestRequest(cartonInfo)

        viewModel.manifest(manifestRequest)
    }

    fun handleDeManifestAction() {

        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        val containerId = viewModel.getContainerId()
        val cartonId = viewModel.getCartonId()
        val cartonType = viewModel.getCartonTypeValue()
        val requestor = viewModel.getPackStationDescription()

        val cartonInfo = DeManifestCartonInfo(
            custId,
            fcyId,
            buId,
            containerId,
            cartonId,
            cartonType,
            requestor,
            1
        )

        val manifestRequest = DeManifestRequest(cartonInfo)
        viewModel.demanifest(manifestRequest)
    }

    fun handlePrintAction() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.print_button))

        val printOptionsList = mutableListOf<String>()
        printOptionsList.add(getString(R.string.lbl_print_content_label))

        if (viewModel.isOrderedPacked(viewModel.cartonInfo!!) == true) {
            printOptionsList.add(getString(R.string.lbl_print_packing_slip))
        } else if (viewModel.isContainerManifested(viewModel.cartonInfo!!) == true) {
            printOptionsList.add(getString(R.string.lbl_print_packing_slip))
            printOptionsList.add(getString(R.string.lbl_print_shipping_label))
            printOptionsList.add(getString(R.string.lbl_print_content_shipping_label))
        }

        val printOptions = printOptionsList.toTypedArray()
        builder.setItems(printOptions) { dialog, position ->
            dialog.dismiss()
            callPrintAPI(printOptions[position])
        }
        builder.setNeutralButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.show()
    }

    fun callPrintAPI(printOption: String) {

        var printPackingSlip = false
        var printShippingLabel = false

        when (printOption) {

            getString(R.string.lbl_print_packing_slip) -> {
                printPackingSlip = true
            }

            getString(R.string.lbl_print_content_label) -> {

            }

            getString(R.string.lbl_print_shipping_label) -> {
                printShippingLabel = true
            }

            getString(R.string.lbl_print_content_shipping_label) -> {
                printShippingLabel = true
            }
        }

        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        val containerId = viewModel.getContainerId()
        val cartonId = viewModel.getCartonId()
        val requestor = viewModel.getPackStationDescription()
        val shipmentMethod = viewModel.getShipmentMethodCode()

        val containerDetailList = mutableListOf<PackedContainerDetail>()
        var containerNumber = ""
        if(viewModel.cartonNumber.isNullOrEmpty()) {
            containerNumber = viewModel.cartonInfo!!.obContainerNumber
        }
        else {
            containerNumber = viewModel.cartonNumber
        }
        containerDetailList.add(PackedContainerDetail(containerNumber))

        val printLabelRequest = PrintLabelRequest(
            fcyId,
            custId,
            buId,
            containerId,
            cartonId,
            requestor,
            printPackingSlip,
            printShippingLabel,
            shipmentMethod,
            containerDetailList
        )
        viewModel.print(printLabelRequest)
    }

    fun handleSendToPR() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        val reasonsMap = HashMap<String, String>()
        reasonsMap.put("Lot Number Mismatch", "LNMM")
        reasonsMap.put("Pack-Short Damaged", "PSTD")
        reasonsMap.put("Pack-Short Qty Missing", "PSTQ")

        val reasonCodesList = ArrayList<String>(reasonsMap.keys)

        dialogView.reasonCodeDropDown.setOptions(reasonCodesList)

        dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            dialogView.btnOk.isEnabled = true
            lockCode = reasonsMap.get(selection)!!
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            dialog.dismiss()
            callSendToPRAPI(lockCode)
        }
    }

    fun callSendToPRAPI(lockCode: String) {

        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)

        val containerDetailList = mutableListOf<Int>()

        for(cartonDetail in viewModel.cartonInfo!!.cartonDetails){
            containerDetailList.add(cartonDetail.cartonDetailId)
        }

        val request = SendToPRRequest(fcyId,custId,buId,containerDetailList,"",lockCode)
        viewModel.sendToPR(request)
    }


    fun navigateToPackingFragment() {
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action =
            PackingSuccessFragmentDirections.actionPackingSuccessFragmentToPackingFragment()
        navController.navigate(action)
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }
}