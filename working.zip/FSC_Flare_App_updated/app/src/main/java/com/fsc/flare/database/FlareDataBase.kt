package com.fsc.flare.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.fsc.flare.database.dao.FlareDao
import com.fsc.flare.database.entities.RFlog
import com.fsc.flare.database.typeconvertors.DateTimeConverter
import com.fsc.flare.database.typeconvertors.LogLevelConvertor

private const val FLARE_DB_NAME = "flare-rf-database"

@Database(entities = [RFlog::class], version = 1, exportSchema = false)
@TypeConverters(DateTimeConverter::class, LogLevelConvertor::class)
abstract class FlareDataBase : RoomDatabase() {

    abstract fun flareDao(): FlareDao

    companion object {

        @Volatile
        private var instance: FlareDataBase? = null

        fun getDataBase(context: Context): FlareDataBase {
            if (instance != null) instance
            synchronized(this) {
                val newInstance =
                    Room.databaseBuilder(context, FlareDataBase::class.java, FLARE_DB_NAME)
                        .allowMainThreadQueries().build()
                instance = newInstance
                return newInstance
            }
        }
    }

}