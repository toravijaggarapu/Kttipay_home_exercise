package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingPalletReplenishmentToCasepickBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTask
import com.fsc.flare.source.data.dto.interleaving.PickInfo
import com.fsc.flare.source.data.dto.interleaving.ValidateContainerRequest
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.observeFlowOnUI
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

private val TAG = PalletReplenishmentToActiveAndCasePick::class.java.simpleName.toString()
class PalletReplenishmentToActiveAndCasePick : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentInterleavingPalletReplenishmentToCasepickBinding
    private val screenTitle by lazy {
        PalletReplenishmentToActiveAndCasePickArgs.fromBundle(
            requireArguments()
        ).title
    }
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private val taskTypeIdentifierViewModel: InterLeavingTaskTypeIdentifierViewModel by viewModels()

    @Inject
    lateinit var alertHandler: AlertHandler

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingPalletReplenishmentToCasepickBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bindView(sharedViewModel.taskInterLeavingResponse?.pickInfo)
        observeFlowOnUI { observeApiResults() }

        validateLocation()
        setClickListenerToEndTaskButtons()
        setClickListenerToSkipButtons()
        setClickListenerToSkipInlineButtons()
    }

    /**
     * Bind the response data to view
     */
    private fun bindView(pickInfo: PickInfo?) {
        binding.tvInterleaving.text = screenTitle
        binding.tvTaskId.text = pickInfo?.taskId.toString()
        binding.tvItemCode.text = pickInfo?.itemBarcode.toString()
        binding.tvCurrentLocation.text = pickInfo?.pickLocBarcode.toString()
    }

    /**
     * Monitor the API response data and trigger corresponding actions based on the outcome.
     */
    private suspend fun observeApiResults() {
        taskTypeIdentifierViewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is InterLeavingLocationTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is InterLeavingLocationTaskState.ShowError -> showErrorSnackBar(state.errorMessage)
                is InterLeavingLocationTaskState.ContainerResponse -> {
                    sharedViewModel.validateContainerResponse = state.getInterLeavingResponse
                    val action =
                        PalletReplenishmentToActiveAndCasePickDirections.actionPalletReplenishmentToCasePickToPalletReplenishmentToCasePickToDetailed(
                            screenTitle
                        )
                    getNavigationController().navigate(action)
                }

                is InterLeavingLocationTaskState.EndTaskSuccess -> {
                    sharedViewModel.clearData()
                    val action =
                        PalletReplenishmentToActiveAndCasePickDirections.actionPalletReplenishmentToActiveAndCasePickToHomeFragment()
                    getNavigationController().navigate(action)
                }

                is InterLeavingLocationTaskState.NavigateToPalletPutwayToReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PalletReplenishmentToActiveAndCasePickDirections.actionPalletReplenishmentToActiveAndCasePickToScanCurrentLocation()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(
                            R.id.scanEquipmentFragment,
                            inclusive = true
                        )
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }

                is InterLeavingLocationTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    bindView(state.response?.pickInfo)
                    binding.tvInterleaving.text = getString(state.screenTitle)
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code

                }

                is InterLeavingLocationTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PalletReplenishmentToActiveAndCasePickDirections.actionPalletReplenishmentToActiveAndCasePickToPickFromReserve()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(
                            R.id.scanEquipmentFragment,
                            inclusive = true
                        )
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }

                is InterLeavingLocationTaskState.NavigateToPalletReplenishmentToActive -> {
                    bindView(state.response?.pickInfo)
                    binding.tvInterleaving.text = getString(state.screenTitle)
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                }
                else ->{}
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun validateLocation() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (binding.scanLocation.isFocused && !binding.scanLocation.text.isNullOrEmpty()) {
                            if (binding.scanLocation.text.toString() == sharedViewModel.taskInterLeavingResponse?.pickInfo?.pickLocBarcode) {
                                validatePallet()
                                handleViewVisibility()
                            } else {
                                binding.tvShowLocationError.visibility = View.VISIBLE
                                binding.tvShowLocationError.text =
                                    getString(R.string.lbl_invalid_location)
                            }

                        } else {
                            binding.tvShowLocationError.visibility = View.VISIBLE
                            binding.tvShowLocationError.text =
                                getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.scanLocation.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.scanLocation)
                       binding.tvShowLocationError.visibility = View.GONE
                   }
                   return@setOnEditorActionListener false
               }

            binding.scanLocation.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    binding.tvShowLocationError.visibility = View.GONE

                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun validatePallet() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        when {
                            binding.scanPallet.isFocused && !binding.scanPallet.text.isNullOrEmpty() -> {
                                callContainerValidationService()
                            }

                            else -> {
                                binding.tvShowPalletError.visibility = View.VISIBLE
                                binding.tvShowPalletError.text =
                                    getString(R.string.lbl_input_required)
                            }
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.scanLocation.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.scanPallet)
                       binding.tvShowPalletError.visibility = View.GONE
                       callContainerValidationService()
                   }
                   return@setOnEditorActionListener false
               }

            binding.scanPallet.doAfterTextChanged { binding.tvShowPalletError.visibility = View.GONE }
        }
    }

    private fun callContainerValidationService() {
        taskTypeIdentifierViewModel.sendValidateContainerRequest(
            taskType = sharedViewModel.taskType ?: "",
            containerRequest = ValidateContainerRequest(
                containerNbr = binding.scanPallet.text.toString(),
                scannedLocBarcode = binding.tvCurrentLocation.text.toString(),
                taskId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                    ?: 0,
                sessionId = sharedViewModel.taskInterLeavingResponse?.sessionId
                    ?: ""
            )
        )
    }

    private fun setClickListenerToEndTaskButtons() {
        binding.btnEndTask.setOnClickListener {
            alertHandler.showFlareConfirmationAlert(
                message = getString(
                    R.string.interleaving_end_task_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                    taskTypeIdentifierViewModel.sendEndTaskRequest(
                        interLeavingEndTask = InterLeavingEndTask(
                            sessionId = sharedViewModel.taskInterLeavingResponse?.sessionId ?: ""
                        )
                    )
                }
            )
        }
    }

    /**
     * Method to handle the view visibility
     */
    private fun handleViewVisibility() {
        binding.lblCurrentLocation.visibility = View.GONE
        binding.scanLocation.visibility = View.GONE
        binding.lblPalletLocation.visibility = View.VISIBLE
        binding.scanPallet.visibility = View.VISIBLE
    }

    private fun setClickListenerToSkipButtons() {
        binding.btnSkip.setOnClickListener {
            alertHandler.showFlareConfirmationAlert(
                message = getString(
                    R.string.interleaving_skip_task_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                    taskTypeIdentifierViewModel.callInterLeavingService(
                        interLeavingPayload = GetInterLeavingRequest(
                            equipmentId = sharedViewModel.equipmentId ?: 0,
                            equipmentTypeId = sharedViewModel.equipmentTypeId ?: 0,
                            skipTaskId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                                ?: 0
                        )
                    )
                }
            )
        }
    }

    private fun setClickListenerToSkipInlineButtons() {
        binding.btnSkipSequence.setOnClickListener {
            alertHandler.showConfirmationAlert(
                message = getString(
                    R.string.interleaving_skip_task_sequence_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                    taskTypeIdentifierViewModel.callInterLeavingService(
                        interLeavingPayload = GetInterLeavingRequest(
                            equipmentId = sharedViewModel.equipmentId ?: 0,
                            equipmentTypeId = sharedViewModel.equipmentTypeId ?: 0,
                            skipTaskGrpId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                                ?: 0
                        )
                    )
                }
            )
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.scanLocation.isFocused && binding.scanLocation.text.isNullOrEmpty()) {
            binding.scanLocation.setText(scan?.barcode.toString())
            validatePallet()
            handleViewVisibility()
        } else {
            binding.scanPallet.setText(scan?.barcode.toString())
            callContainerValidationService()
        }
    }
}
