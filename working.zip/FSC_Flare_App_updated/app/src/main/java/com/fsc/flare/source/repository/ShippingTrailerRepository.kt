package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBDockDoorRCLockRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

class ShippingTrailerRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getDockDoorInfo(locBarCode: String) = apiGatewayInterface.getDockDoorInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locBarCode = locBarCode,
        locClass = "DD"
    )

    suspend fun getShipmentDockDoor(shipmentDockDoorRequest: ShipmentDockDoorRequest) =
        apiGatewayInterface.getShipmentDockDoor(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            shipmentDockDoorRequest.custId,
            shipmentDockDoorRequest.fcyId,
            shipmentDockDoorRequest.buId,
            shipmentDockDoorRequest.dockDoorId,
            shipmentDockDoorRequest.closeTrailer
        )

    suspend fun closeTrailer(closeTrailerRequest: CloseTrailerRequest)=
        apiGatewayInterface.closeTrailer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            closeTrailerRequest
        )

    suspend fun fetchRecallLockOBContainerDetails(obCartonRCLockRequest: OBDockDoorRCLockRequest): Response<OBCartonRCLockResponse> =
        apiGatewayInterface.fetchRecallLockOBContainerDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            lock = obCartonRCLockRequest.lock,
            dockDoorId = obCartonRCLockRequest.dockDoorId
        )
}