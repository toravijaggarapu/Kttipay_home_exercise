package com.fsc.flare.ui.fragment.interleaving

import androidx.lifecycle.viewModelScope
import com.fsc.flare.R
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.GetEquipmentCurrentPosition
import com.fsc.flare.source.data.dto.interleaving.GetEquipmentTypeData
import com.fsc.flare.source.data.dto.interleaving.GetEquipmentTypeResponse
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingResponse
import com.fsc.flare.source.data.dto.interleaving.TaskInterLeavingData
import com.fsc.flare.source.repository.InterLeavingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class ScanEquipmentViewModel @Inject constructor(
    private val interLeavingRepository: InterLeavingRepository
) : BaseViewModel() {

    private val _fetchTaskState = MutableStateFlow<InterLeavingTaskState?>(null)
    val fetchTaskState = _fetchTaskState.asStateFlow()

    private lateinit var equipmentMap: Map<String, Int>
    private  var equipmentTypeId : Int = 0

    /**
     * Initiate "Equipment type" service call
     */
    fun getEquipmentType(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = true))
            val response = interLeavingRepository.getEquipmentType()
            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = false))
                body()?.let { it.equipmentTypeData?.let { it1 ->
                    handleGetEquipmentTypeSuccessResponse(
                        it1
                    )
                } }
                FlareLog.i(TAG, "getEquipmentType Success:${body()}")
            } ?: run {
                handleEquipmentTypeErrorResponse(response)
            }
        }
    }

    private suspend fun handleGetEquipmentTypeSuccessResponse(getEquipmentTypeResponse: List<GetEquipmentTypeData>) {
        equipmentMap =
            getEquipmentTypeResponse.associate { it.equipmentTypeCode to it.equipmentTypeId }
        val equipmentValues = ArrayList(equipmentMap.keys)
        _fetchTaskState.emit(InterLeavingTaskState.ListOfEquipmentType(equipmentValues))
    }

    private suspend fun handleEquipmentTypeErrorResponse(response: Response<GetEquipmentTypeResponse>) {
        _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = false))
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "getEquipmentType Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingTaskState.ShowError(errorMessage))
    }

    /**
     * Initiate "current-position" service call
     */
    fun getCurrentPosition(scope: CoroutineScope = viewModelScope, selectedDescription: String, equipmentNbr: String) {
        scope.launch {
            equipmentTypeId = equipmentMap[selectedDescription] ?: 0
            val response = interLeavingRepository.getEquipmentCurrentPosition(equipmentNbr)
            _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                FlareLog.i(TAG, "EquipmentType current-position Success:${body()}")
                body()?.let {
                    handleCurrentPositionApiSuccessResponse(it, equipmentTypeId)
                } ?: run {
                    _fetchTaskState.emit(InterLeavingTaskState.ShowNoEquipmentError(R.string.show_equipment_error_msg))
                }
            } ?: run {
                handleCurrentPositionApiErrorResponse(response)
            }
        }
    }

    private suspend fun handleCurrentPositionApiSuccessResponse(
        it: GetEquipmentCurrentPosition,
        equipmentTypeId: Int
    ) {
        if (it.equipmentData?.allowedToUse == false) {
            _fetchTaskState.emit(InterLeavingTaskState.ShowNoEquipmentError(R.string.show_equipment_error_msg))
        } else {
            _fetchTaskState.emit(
                it.equipmentData?.equipmentId?.let { it1 ->
                    InterLeavingTaskState.NavigateToPalletPutawayToReserve(
                        it1,
                        equipmentTypeId
                    )
                }
            )
        }
    }

    private suspend fun handleCurrentPositionApiErrorResponse(response: Response<GetEquipmentCurrentPosition>) {
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "current-position Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingTaskState.ShowError(errorMessage))
    }

    /**
     * Initiate "InterLeaving" service call
     */
    fun callInterLeavingService(
        scope: CoroutineScope = viewModelScope,
        interLeavingPayload: GetInterLeavingRequest
    ) {

        scope.launch {
            val response = interLeavingRepository.getInterLeaving(interLeavingPayload)
            _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = true))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = false))
                FlareLog.i(TAG, "InterLeaving Success:${body()}")
                body()?.let {
                    handleInterLeavingApiSuccessResponse(it, interLeavingPayload)
                }
            } ?: run {
                handleInterLeavingApiErrorResponse(response)
            }
        }
    }

    /**
     * Method to get TaskType from interLeaving response and navigate to corresponding screen
     */
    private suspend fun handleInterLeavingApiSuccessResponse(
        interLeavingPayload: GetInterLeavingResponse,
        equipmentDetails: GetInterLeavingRequest
    ) {
        when (interLeavingPayload.interLeavingData?.pickInfo?.taskType) {
            InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingTaskState.EnableScanCurrentLocation(
                        interLeavingPayload.interLeavingData,
                        equipmentDetails.equipmentId,
                        equipmentDetails.equipmentTypeId
                    )
                )
            }

            InterLeavingTaskType.PICK_FROM_RESERVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingTaskState.NavigateToPickFromReserve(
                        interLeavingPayload.interLeavingData,
                        equipmentDetails.equipmentId,
                        equipmentDetails.equipmentTypeId
                    )
                )
            }

            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code -> {
                _fetchTaskState.emit(
                    InterLeavingTaskState.NavigateToPalletReplenishmentToCasePick(
                        interLeavingPayload.interLeavingData,
                        equipmentDetails.equipmentId,
                        equipmentDetails.equipmentTypeId,
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.description
                    )
                )
            }

            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingTaskState.NavigateToPalletReplenishmentToActive(
                        interLeavingPayload.interLeavingData,
                        equipmentDetails.equipmentId,
                        equipmentDetails.equipmentTypeId,
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.description
                    )
                )
            }
        }
    }

    private suspend fun handleInterLeavingApiErrorResponse(response: Response<GetInterLeavingResponse>) {
        _fetchTaskState.emit(InterLeavingTaskState.ShowProgress(show = false))
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "EquipmentType current-position Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingTaskState.ShowError(errorMessage))
    }

    fun clearData() {
        _fetchTaskState.value = null
    }

}

sealed class InterLeavingTaskState {
    data class ShowProgress(val show: Boolean) : InterLeavingTaskState()
    data class ShowError(val errorMessage: String) : InterLeavingTaskState()
    data class ShowNoEquipmentError(val errorMessage: Int) : InterLeavingTaskState()
    data class NavigateToPalletPutawayToReserve(val equipmentId: Int, val equipmentTypeId: Int) :
        InterLeavingTaskState()

    data class ListOfEquipmentType(val equipmentType: List<String>) : InterLeavingTaskState()
    data class EnableScanCurrentLocation(
        val response: TaskInterLeavingData?,
        val equipmentId: Int,
        val equipmentTypeId: Int
    ) : InterLeavingTaskState()

    data class NavigateToPalletReplenishmentToCasePick(
        val response: TaskInterLeavingData?,
        val equipmentId: Int,
        val equipmentTypeId: Int,
        val screenTitle: Int
    ) : InterLeavingTaskState()

    data class NavigateToPalletReplenishmentToActive(
        val response: TaskInterLeavingData?,
        val equipmentId: Int,
        val equipmentTypeId: Int,
        val screenTitle: Int
    ) : InterLeavingTaskState()

    data class NavigateToPickFromReserve(
        val response: TaskInterLeavingData?,
        val equipmentId: Int,
        val equipmentTypeId: Int
    ) : InterLeavingTaskState()
}

