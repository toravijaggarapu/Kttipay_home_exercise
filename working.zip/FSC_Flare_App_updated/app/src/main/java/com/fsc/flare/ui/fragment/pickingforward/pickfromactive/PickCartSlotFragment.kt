package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartSlotBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountHeader
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickQtyUpdateRes
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import java.lang.reflect.Type
import javax.inject.Inject

private const val TAG = "PickCartSlotFragment"

@AndroidEntryPoint
class PickCartSlotFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartSlotBinding
    lateinit var cb1: CustomVisibilityCallback
    private var isRequestProcessing:Boolean = false

    var lockCode:String = ""
    val inventoryLockList = ArrayList<String>()
    val inventoryLockCodeList = ArrayList<String>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartSlotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Slot field focused")
                    if (!isRequestProcessing)
                        validateSlot()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.slotInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Slot field focused")
                if(!isRequestProcessing)
                    validateSlot()
            }
            false
        }
        binding.slotInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.slotResponse.text = null
            }
        })

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            binding.cart.text = data?.cartNbr
            binding.taskId.text = taskData.taskId.toString()
            binding.item.text = taskData.itemCode
            binding.description.text = taskData.itemDescription
            binding.pickLocation.text = taskData.locationBarcode
            binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
            binding.pickedQty.text = viewModel.getPickQtyUOMValue(taskData)
            binding.slot.text = taskData.slot
            if(!taskData.toteNumber.isNullOrEmpty())
            {
                showToteLayout(true)
                binding.toteNumber.text = taskData.toteNumber
            }else
                showToteLayout(false)
        }
    }

    private fun validateSlot() {
        if (!binding.slotInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.slotInput)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (binding.slotInput.text.toString() == taskData.slot) {
                    if (viewModel.getTaskQty(taskData).toString() == taskData.pickedQty.toString() || viewModel.isShortPick) {
                        updateQtyAPICall(taskData)
                    } else {
                        val action = PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPickCartQtyFragment()
                        getNavigationController().navigate(action)
                    }
                } else {
                    binding.slotResponse.text = getString(R.string.slot_mismatch)
                    binding.slotInput.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.slotInput)
                }
            }
        } else {
            binding.slotResponse.text = getString(R.string.slot_required)
            binding.slotInput.selectAll()
            showSoftKeyBoard(fragmentContext, binding.slotInput)
        }
    }

    /**
     * method to get valid serial numbers list from sharedPreferences
     */
    private fun getSerialList(): List<String> {
        val serialNumberList: MutableList<String>
        val serialListJson = sharedPreferences.getString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return emptyList()
    }

    private fun subscribeObservers() {
        viewModel.taskPickQtyUpdateResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { qtyUpdateResponse ->

                        if (qtyUpdateResponse.success != null && qtyUpdateResponse.success) {
                            FlareLog.i(TAG, "taskPickQtyUpdate success: $qtyUpdateResponse")
                            if(!qtyUpdateResponse.zeroLocation.isNullOrEmpty() && qtyUpdateResponse.zeroLocation == "Y"){
                                showZeroLocationAlert(qtyUpdateResponse)
                            }else{
                                //TODO RTV order should not check for PR location Trans value
                                checkStagingOrPRLocation(qtyUpdateResponse, qtyUpdateResponse.promptStage)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPickQtyUpdate error: $message")
                        if(message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == TASK_CYCLE_COUNT_PENDING) {
                                    showCycleCountPendingAlert()
                                } else if(msgArray[0] == TASK_ALREADY_PICKED || msgArray[0] == TASK_ASSIGNED_TO_OTHER_USER) {
                                    showErrorAlert(msgArray[1], locationEmpty = false)
                                } else if (msgArray[0] == LOCATION_IS_EMPTY ) {
                                    showErrorAlert(msgArray[1], locationEmpty = true)
                                }
                                else{
                                    binding.slotInput.requestFocus()
                                    binding.slotInput.selectAll()
                                    binding.slotResponse.text = msgArray[1]
                                    showSoftKeyBoard(fragmentContext, binding.slotInput)
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.shortPickTotesResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shortPickToteResponse ->
                        if (!shortPickToteResponse.toteDetails.isNullOrEmpty()) {
                            viewModel.setShortPickTotesList(shortPickToteResponse)
                            if (!shortPickToteResponse.prLocExist) {
                                navigateToStageCart()
                            } else {
                                val action = PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPrLocationFragment()
                                getNavigationController().navigate(action)
                            }
                        } else {
                            if (shortPickToteResponse.promptStage)
                                navigateToStageCart()
                            else {
                                showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                                    navigateToTaskGroup()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Get short pick error: $message")
                        showErrorSnackBar(response.message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.cycleCountTriggerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cycleCountTriggerResponse ->
                        if (cycleCountTriggerResponse.success) {
                            FlareLog.i(TAG, "cycleCountTriggerResponse Success: $cycleCountTriggerResponse.message")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "cycleCountTriggerResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun checkStagingOrPRLocation(
        qtyUpdateResponse: TaskPickQtyUpdateRes,
        promptStage: Boolean?
    ) {
        val isChaseWave =
            viewModel.getPickTaskDetails()!!.taskWaveType.isNotEmpty() && viewModel.getPickTaskDetails()!!.taskWaveType == "C"
        if (qtyUpdateResponse.promptStage != null && promptStage == true) {

            if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                if (!isChaseWave && qtyUpdateResponse.taskShortQty > 0) {
                    showSuccessSnackBarImp(resources.getString(R.string.proceed_to_problem_resolution_area_with_short_pick)) {
                        getShortPickedTotesList()
                    }
                } else {
                    getShortPickedTotesList()
                }
            } else {
                val action =
                    PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPickCartStagingLocFragment()
                getNavigationController().navigate(action)
            }
        } else {
            if (qtyUpdateResponse.taskDetails != null) {
                if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue() && !qtyUpdateResponse.alterNativeLocationFound && !isChaseWave) {
                    showSuccessSnackBarStd(resources.getString(R.string.short_picked_continue_picking)) {
                        viewModel.updateOrderType(qtyUpdateResponse.orderType)
                        viewModel.setPickTaskDetails(qtyUpdateResponse.taskDetails)
                        navigateToLocationFragment()
                    }
                } else {
                    viewModel.updateOrderType(qtyUpdateResponse.orderType)
                    viewModel.setPickTaskDetails(qtyUpdateResponse.taskDetails)
                    navigateToLocationFragment()
                }
            } else {
                showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                    navigateToTaskGroup()
                }
            }
        }
    }
    private fun navigateToLocationFragment() {
        val action =
            PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPickCartLocationFragment()
        val navOptions =
            NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true)
                .build()
        getNavigationController().navigate(action, navOptions)
    }

    private fun showZeroLocationAlert(qtyUpdateResponse: TaskPickQtyUpdateRes) {
        val data = viewModel.getPickTaskDetails()
        if(data != null){
            showAlertDialog("",
                getString(R.string.lbl_does_the_location_empty_after_picking,data.locationBarcode),
                getString(R.string.alert_button_yes),
                getString(R.string.alert_button_no),
                object : AlertDialogClickListener {
                    override fun onPositiveButtonClick() {
                        checkStagingOrPRLocation(qtyUpdateResponse, qtyUpdateResponse.promptStage)
                    }
                    override fun onNegativeButtonClick() {
                        generateCycleCountToVerifyZeroLocation()
                        checkStagingOrPRLocation(qtyUpdateResponse, qtyUpdateResponse.promptStage)
                    }
                })
        }
    }
    private fun generateCycleCountToVerifyZeroLocation() {
        viewModel.getPickTaskDetails()?.let {
            viewModel.generateCycleCountToVerifyZeroLocation(
                CycleCountTriggerRequest(
                    CycleCountHeader(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    ),skipErrIfCCPending = true
                ), locationId = it.pullLocationId
            )
        }
    }

    private fun navigateToStageCart() {
        val action = PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPickCartStagingLocFragment()
        getNavigationController().navigate(action)
    }

    private fun getShortPickedTotesList() {
        viewModel.getShortPickedTotes(
            binding.cart.text.toString(),
            viewModel.getPickTask()?.cartId ?: 0
        )
    }

    private fun navigateToTaskGroup(){

        if (viewModel.isComingFromPickCartFlow) {
            val action = PickCartSlotFragmentDirections.actionPickCartSlotFragmentToPickCartPalletFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartPalletFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        } else {
            val action = PickCartSlotFragmentDirections.actionPickCartSlotFragmentToBuildCartTaskGroup()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
            getNavigationController().navigate(action, navOptions)
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        isRequestProcessing = true
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        isRequestProcessing = false
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }

        if (!isRequestProcessing) {
            binding.slotInput.setText(scan?.barcode.toString())
            binding.slotInput.text?.length?.let {
                binding.slotInput.setSelection(it)
            }
            FlareLog.i(TAG, "Slot  field focused")
            validateSlot()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

    private fun showCycleCountPendingAlert() {
        showAlertDialog(
            "",
            getString(R.string.cycle_count_pending_for_location),
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    reasonCode()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun reasonCode() {
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height =  ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                taskData.pickedQty = 0
                updateQtyAPICall(taskData)
            }
            dialog.dismiss()
        }
        if (inventoryLockList.isEmpty())
            viewModel.getInventoryReasonCodes()
        else
            dialogView.reasonCodeDropDown.setOptions(inventoryLockList)

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        viewModel.reasonCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
    }

    private fun updateQtyAPICall(taskData: TaskDetails) {
        viewModel.taskPickQtyUpdate(
            TaskPickQtyUpdateReq(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                allocationType = taskData.allocationType.toInt(),
                pickQty = viewModel.getPickQty(taskData).toString(),
                pickQtyUom = taskData.taskQtyUom,
                taskDetailId = taskData.taskDetId,
                taskId = taskData.taskId,
                serialNumber = getSerialList(),
                lotNumber = taskData.lotNumber,
                expDate = formatDate(taskData.expDate ?: ""),
                reasonCode = viewModel.reasonCode
            )
        )
        viewModel.reasonCode = ""
    }

    private fun showErrorAlert(message:String, locationEmpty:Boolean) {
        if(locationEmpty) {
            showCycleCountPendingAlert()
        } else {
            val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            builder.setTitle("")
            builder.setMessage(message)

            builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
                dialogInterface.dismiss()
                navigateToTaskGroup()
            }
            val alertDialog: MaterialAlertDialogBuilder = builder
            alertDialog.setCancelable(false)
            alertDialog.show()
        }
    }
}