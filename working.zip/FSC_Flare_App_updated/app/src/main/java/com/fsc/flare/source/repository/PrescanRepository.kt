package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.prescan.createShipment.request.CreateShipmentRequest
import com.fsc.flare.source.data.dto.prescan.fetch.PreScanValidateRMARequest
import com.fsc.flare.source.data.dto.prescan.trackingNumber.ValidateTrackingNumberRequest
import com.fsc.flare.source.data.dto.prescan.vendor.PreScanVenderRequest
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.PRE_SCAN_PARAMETER_SCAN
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

/**
 * A Repository class for  Precsan, this repository call PreScan API request to  ApiGatewayInterface  along with pass necessary arguments  .
 *
 */
@Singleton
class PrescanRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    /**
     * A Suspend Kotlin coroutines method for  validate RMA Number or get RMA details  .
     *
     */
    suspend fun validateRMANumber(request: PreScanValidateRMARequest) =
        apiGatewayInterface.validateRMANumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            cust_id = request.cust_Id,
            custid = request.custId,
            fcyId = request.fcyId,
            buId = request.buId,
            rmaNumber = request.rmaNumber,
            page = request.page,
            pageLimit = request.pageLimit
        )

    /**
     * A Suspend Kotlin coroutines method for  create new Shipment in RMA Number or Process prescan  .
     *
     */
    suspend fun createShipmentRMANumber(request: CreateShipmentRequest) =
        apiGatewayInterface.createShipmentRMANumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            createShipmentRequest = request
        )

    /**
     * A Suspend Kotlin coroutines method for get PreScan ReturnType  .
     *
     */
    suspend fun getPreScanReturnType() = apiGatewayInterface.getReturnType(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        facid = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        scan = PRE_SCAN_PARAMETER_SCAN
    )

    /**
     * A Suspend Kotlin coroutines method for get PreScan ReturnType  .
     *
     */
    suspend fun getCustomerDeatils(request: PreScanVenderRequest) =
        apiGatewayInterface.getVendor(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            customerId = request.customerId,
            vendorName = request.vendorName,
            active = request.active
        )

    /**
     * A Suspend Kotlin coroutines method for get Prescan CarrierSCAC  .
     *
     */
    suspend fun getCarrierSCAC() =
        apiGatewayInterface.getPrescanCarrierSCAC(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId =  sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        )

    /**
     * A Suspend Kotlin coroutines method for get Prescan Default Vendor  .
     *
     */
    suspend fun getDefaultVendor() =
        apiGatewayInterface.getPrescanDefaultVendor(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId =  sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        )

    /**
     * A Suspend Kotlin coroutines method for validate Tracking Number  .
     *
     */
    suspend fun validateTrackingNumber(request: ValidateTrackingNumberRequest) =
        apiGatewayInterface.validateTrackingNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            trackingNumber = request.trackingNumber
        )


}