package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.taskgroup.GroupTask
import com.fsc.flare.source.repository.GroupTaskRepository
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.END_PALLET_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_TASKS_FOUND
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.SKIP_API_ERROR
import com.fsc.flare.utils.GroupTaskAPI
import com.fsc.flare.utils.PreferenceKeys
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch


abstract class CaseCountBaseViewModel(
    private val repository: GroupTaskRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    protected val innerScreenState = MutableStateFlow<CaseCountFlowState?>(null)

    protected lateinit var groupTask: GroupTask
    protected lateinit var palletInfo: PalletInformation

    /**
     * Skip the current task and fetch the next task.
     */
    fun skipTask(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val requestMap = HashMap<String, String>()
            requestMap[GroupTaskAPI.CARTON_NUMBER] = palletInfo.cartNumber
            requestMap[GroupTaskAPI.CARTON_ID] = "${palletInfo.cartId}"
            requestMap[GroupTaskAPI.SHIPMENT_NUMBER] = groupTask.shipmentNbr.orEmpty()
            requestMap[GroupTaskAPI.SHIP_STOP_SEQUENCE] = "${groupTask.shipmentStopSeq ?: 0}"
            requestMap[GroupTaskAPI.LOCATION_ID] = "${groupTask.pickLocId ?: 0}"
            requestMap[GroupTaskAPI.SKIP_TASK_GRP_SEQ_NBR] = "${groupTask.taskGrpSeqNbr ?: 0}"

            val taskResponse = repository.skipTask(requestMap)
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))

            taskResponse.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.taskInfo?.let {
                    when {
                        it.eligibleToStage -> {
                            innerScreenState.emit(
                                CaseCountFlowState.StagePending(
                                    cartNumber = palletInfo.cartNumber,
                                    stageLocationId = it.stageLocId ?: 0,
                                    stageLocation = it.stageLocBarcode.orEmpty()
                                )
                            )
                        }

                        !it.eligibleToStage && it.groupTask.containersToBePicked?.isNotEmpty() == true -> {
                            groupTask = it.groupTask.copy()
                            innerScreenState.emit(CaseCountFlowState.GroupTaskData(groupTask))
                        }

                        else -> {
                            innerScreenState.emit(CaseCountFlowState.ShowError(NO_TASKS_FOUND))
                        }
                    }
                } ?: innerScreenState.emit(CaseCountFlowState.ShowError(SKIP_API_ERROR))
            } ?: run {
                val errorMessage = handleForwardErrorResponse(taskResponse.code(), taskResponse.errorBody(), taskResponse.message())
                innerScreenState.emit(CaseCountFlowState.ShowError(SKIP_API_ERROR, errorMessage))
            }
        }
    }

    /**
     * End the current pallet.
     */
    fun endPallet(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val endPickCartReq = EndPickCartReq(
                allocationType = 20,
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                pickCartNbr = palletInfo.cartNumber,
                cartId = palletInfo.cartId,
                casePickWithPallet = true
            )
            val response = repository.endPallet(endPickCartReq)
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))
            response.takeIf { it.isSuccessful && it.body()?.success == true }?.apply {
                if (body()?.taskDetails != null && body()?.promptStage == true) {
                    innerScreenState.emit(
                        CaseCountFlowState.StagePending(
                            cartNumber = palletInfo.cartNumber,
                            stageLocationId = body()?.taskDetails?.stageLocationId ?: 0,
                            stageLocation = body()?.taskDetails?.stageLocationBarcode.orEmpty()
                        )
                    )
                } else {
                    innerScreenState.emit(CaseCountFlowState.EndWithEmptyPallet)
                }
            } ?: run {
                val errorMessage = response.getGiltErrorMessage()
                innerScreenState.emit(CaseCountFlowState.ShowError(END_PALLET_API_ERROR, errorMessage))
            }
        }
    }
}

/**
 * State for the case count flow.
 */
sealed class CaseCountFlowState {
    data class ShowProgress(val show: Boolean) : CaseCountFlowState()
    data class ShowError(
        val errorCode: String,
        val errorMessage: String? = null
    ) : CaseCountFlowState()
    data class StagePending(
        val cartNumber: String,
        val stageLocationId: Int,
        val stageLocation: String
    ) : CaseCountFlowState()
    data class GroupTaskData(val groupTask: GroupTask) : CaseCountFlowState()
    data object EndWithEmptyPallet: CaseCountFlowState()
}

/**
 * Error codes for the case count flow screens.
 */
object CaseCountScreenError {
    const val TASK_FETCH_API_ERROR = "TASK_FETCH_API_ERROR"
    const val NO_TASKS_FOUND = "NO_TASKS_FOUND"
    const val SKIP_API_ERROR = "SKIP_API_ERROR"
    const val END_PALLET_API_ERROR = "END_PALLET_API_ERROR"
    const val PICK_API_ERROR = "PICK_API_ERROR"
    const val NO_PRINT_REQUESTERS = "NO_PRINT_REQUESTERS"
    const val PRINT_REQUESTER_API_ERROR = "PRINT_REQUESTER_API_ERROR"
}