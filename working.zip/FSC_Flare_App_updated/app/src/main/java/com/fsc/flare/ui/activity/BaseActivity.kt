package com.fsc.flare.ui.activity

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.fsc.flare.transactiontracker.FSCTransactionTracker
import com.fsc.flare.utils.ContextUtils
import com.fsc.flare.utils.PreferenceKeys
import java.util.Locale
import javax.inject.Inject

open class BaseActivity : AppCompatActivity() {
    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var trackerInstance: FSCTransactionTracker

    override fun attachBaseContext(newBase: Context) {
        // get chosen language from shared preference
        Log.d("debug", "attachBaseContext in BaseActivity")
        val sharedPref = newBase.getSharedPreferences(PreferenceKeys.APP_PREFERENCES, Context.MODE_PRIVATE)
        Log.d("debug", "APP LANGUAGE" + sharedPref.getString(PreferenceKeys.APP_LANGUAGE, "en"))
        val localeToSwitchTo = sharedPref.getString(PreferenceKeys.APP_LANGUAGE, "en")
        val locale = localeToSwitchTo?.let { Locale(it) }
        val localeUpdatedContext: ContextWrapper? = locale?.let { ContextUtils.updateLocale(newBase, it) }
        super.attachBaseContext(localeUpdatedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        trackerInstance
            .setUserId(sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString())
    }
}
