package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.pickingforward.req.BuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipBuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteCartonReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteReq
import com.fsc.flare.source.data.dto.pickingforward.req.WorkOrderDetailsReq
import com.fsc.flare.source.data.dto.pickingforward.req.RepairTaskRequest
import com.fsc.flare.source.data.dto.pickingforward.req.*
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class PickingForwardRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    private val apiGatewayAccessToken =
        sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)
    private val userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1)
    private val fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)

    suspend fun getTaskGroups(allocationType: String) = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
      //  allocationType = "10,20"
          allocationType = allocationType
    )

    suspend fun validateTote(validateToteReq: ValidateToteReq) = apiGatewayInterface.validateTote(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        validateToteReq = validateToteReq
    )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun getItemAttrTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun getWorkOrderDetails(workOrderDetailsReq: WorkOrderDetailsReq) = apiGatewayInterface.getWorkOrderDetailsForAssignedTasks(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = workOrderDetailsReq.fcyId,
        custId = workOrderDetailsReq.custId,
        buId = workOrderDetailsReq.buId,
        assignedTo = workOrderDetailsReq.assignedTo,
        allocationType = workOrderDetailsReq.allocationType,
        taskGroup = workOrderDetailsReq.taskGroup
    )

    suspend fun getTaskPick(taskPickReq: TaskPickReq) = apiGatewayInterface.getTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickReq = taskPickReq
    )

    suspend fun getTaskPickCart(taskPickCartReq: TaskPickCartReq) = apiGatewayInterface.getTaskPickCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickCartReq = taskPickCartReq
    )

    suspend fun pickEndCart(endPickCartReq: EndPickCartReq) = apiGatewayInterface.pickEndCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        endPickCartReq = endPickCartReq
    )

    suspend fun pickSkipCart(skipPickCartReq: SkipPickCartReq) = apiGatewayInterface.pickSkipCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = skipPickCartReq.fcyId,
        custId = skipPickCartReq.custId,
        buId = skipPickCartReq.buId,
        pickCartNbr = skipPickCartReq.pickCartNbr,
        assignedTo = skipPickCartReq.assignedTo,
        allocationType = skipPickCartReq.allocationType,
        skipTaskId = skipPickCartReq.skipTaskId,
        skipTaskDetId = skipPickCartReq.skipTaskDetId,
        replenType = skipPickCartReq.replenType,
        isLTLcubing = skipPickCartReq.isLTLcubing,
        orderType = skipPickCartReq.orderType
    )

    suspend fun buildSkipCart(skipBuildCartReq: SkipBuildCartReq) = apiGatewayInterface.buildSkipCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = skipBuildCartReq.fcyId,
        custId = skipBuildCartReq.custId,
        buId = skipBuildCartReq.buId,
        pickCartNbr = skipBuildCartReq.pickCartNbr,
        assignedTo = skipBuildCartReq.assignedTo,
        allocationType = skipBuildCartReq.allocationType,
        skipTaskId = skipBuildCartReq.skipTaskId,
        skipTaskDetId = skipBuildCartReq.skipTaskDetId,
        isLTLcubing = skipBuildCartReq.isLTLcubing,
        casePickWithPallet = false,
        orderType = skipBuildCartReq.orderType
    )

    suspend fun taskBuildCart(buildCartReq: BuildCartReq) = apiGatewayInterface.taskBuildCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        buildCartReq = buildCartReq
    )

    suspend fun validateSlot(buildCartReq: BuildCartReq) = apiGatewayInterface.validateSlot(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        buildCartReq = buildCartReq
    )

    suspend fun taskcasepickcomplete(taskCasePickCompleteReq: TaskCasePickCompleteReq) = apiGatewayInterface.taskcasepickcomplete(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskCasePickCompleteReq = taskCasePickCompleteReq
    )

    suspend fun taskPickQtyUpdate(taskPickQtyUpdateReq: TaskPickQtyUpdateReq) = apiGatewayInterface.taskPickQtyUpdate(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickQtyUpdateReq = taskPickQtyUpdateReq
    )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = locationClassReq.customerId,
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun taskactivepickstaging(taskPickActiveStagingReq: TaskPickActiveStagingReq) = apiGatewayInterface.taskactivepickstaging(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickActiveStagingReq = taskPickActiveStagingReq
    )

    suspend fun taskstaging(taskStagingRequest: TaskStagingRequest) = apiGatewayInterface.taskstaging(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskStagingRequest = taskStagingRequest
    )

    suspend fun validateLotNumber(lotNumReqBody: LotNumReqBody) =
        apiGatewayInterface.validateLotNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "null")!!,
            custId = lotNumReqBody.custId,
            fcyId = lotNumReqBody.fcyId,
            buId = lotNumReqBody.buId,
            lotNumber = lotNumReqBody.lotNumber,
            asnId = lotNumReqBody.asnId,
            itemId = lotNumReqBody.itemId,
            lotNumberCheck = true
        )

    suspend fun validateSerialNumberWithItemCode(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        taskId: Long,
        containerNbr:String,
        obContainerId: Int
    ) = apiGatewayInterface.validateSerialNumberWithItemCodeForPicking(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        serialNumberOrItemId = serialNumberOrItemId,
        isOutBoundOnly = isOutBoundOnly,
        pickLocationId = pickLocationId,
        itemId = itemId,
        taskId = taskId,
        containerNbr = containerNbr,
        containerId = obContainerId
    )


    suspend fun validateSerialNumberWithItemCode(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        containerId: Int
    ) = apiGatewayInterface.validateSerialNumberWithItemCodeForContainerPicking(
        "Bearer $apiGatewayAccessToken",
        fedexId = fedexId!!,
        custId = custId,
        buId = buId,
        fcyId = fcyId,
        serialNumberOrItemId = serialNumberOrItemId,
        isOutBoundOnly = isOutBoundOnly,
        pickLocationId = pickLocationId,
        itemId = itemId,
        containerId = containerId
    )

    suspend fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = apiGatewayInterface.validateUPCorSLP(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        itemCode = itemCode,
        upcOrSlp = upcOrSlp
    )

    suspend fun getInventoryReasonCodes() = apiGatewayInterface.getInventoryReasonCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
    )

    suspend fun getShortPickedTotes(cartNumber: String, cartId: Int, allocationType: String?) =
        apiGatewayInterface.getShortPickedTotes(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            allocationType ?: "",
            cartNumber,
            cartId
        )

    suspend fun validateToteCarton(validateToteReq: ValidateToteCartonReq) = apiGatewayInterface.transferTotePR(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        validateToteReq
    )

    suspend fun getKitStagingLocation(psuedoOrderId:Int, orderType: String) = apiGatewayInterface.getKitStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        psuedoOrderId = psuedoOrderId,
        orderType = orderType
    )

    suspend fun getContainer(container: String, itemInfo: String) = apiGatewayInterface.getContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = container,
        itemInfo = itemInfo
    )

    suspend fun validateContainerOverride(validateCaseOverrideRequest : ValidateCaseOverrideRequest) =
        apiGatewayInterface.validatePalletOverride(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            validateCaseOverrideRequest = validateCaseOverrideRequest
        )

    suspend fun generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest : CycleCountTriggerRequest, locationId: Long) =
        apiGatewayInterface.generateCycleCountToVerifyZeroLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            locationId = locationId,
            cycleCountTriggerRequest = cycleCountTriggerRequest
        )

    suspend fun initiateRepairFlow(repairTaskRequest: RepairTaskRequest) =
        apiGatewayInterface.initiateRepairFlow(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            repairTaskRequest = repairTaskRequest
        )

    suspend fun getAllocationType(cartNbr: String) = apiGatewayInterface.getAllocationType(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        cartNbr = cartNbr
    )
}