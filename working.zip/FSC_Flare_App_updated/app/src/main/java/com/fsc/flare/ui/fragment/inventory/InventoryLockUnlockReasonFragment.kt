package com.fsc.flare.ui.fragment.inventory

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryLockUnlockReasonBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.inventory.Lock
import com.fsc.flare.source.data.dto.inventory.LockCode
import com.fsc.flare.utils.Constants.LockCodes.FIRST_ARTICLE_INSPECTION
import com.fsc.flare.utils.Constants.LockCodes.INCUBATION_HOLD
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryLockReason"
private const val ARG_PARAM1 = "screenTagName"

/**
 * A simple [InventoryLockUnlockReasonFragment] class.
 */
@AndroidEntryPoint
class InventoryLockUnlockReasonFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var screenTagName: String? = null

    private val viewModel: InventoryViewModel by activityViewModels()
    lateinit var unLock: String
    private lateinit var binding: FragmentInventoryLockUnlockReasonBinding
    private var lockUnlockDropDownList = ArrayList<String>()
    private var lockCodeHashMap = HashMap<String, InventoryLockcode>()
    private var unLockCodeHashMap = HashMap<String, LockCode>()
    private var selectedLockCode :InventoryLockcode? = null
    private var selectedUnlockCode : LockCode? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            arguments?.let {
                screenTagName = it.getString(ARG_PARAM1)
            }
        /*viewModel.getInventoryLockcodes(
            InventoryLockcodeRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            )
        )*/

        //viewModel.getInventoryLocks()
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        if (lockUnlockDropDownList != null) {
            binding.lockCodeDropDown.setOptions(lockUnlockDropDownList)
        }

        /*if (viewModel.getInventoryLocksOptions() != null) {
            binding.lockCodeDropDown.setOptions(viewModel.getInventoryLocksOptions())
        }*/
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryLockUnlockReasonBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryLockUnlock.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (screenTagName!!.contains("UNLOCK")) {
            binding.lockCodeTv.text = getString(R.string.inventory_unlock_code)
            binding.lockCodeDropDown.text = getString(R.string.select_unlock_code)
        }
        val containerListData = viewModel.getContainerInfo()
        if (containerListData != null) {
            if (containerListData.isNotEmpty()) {
                val containerData = containerListData[0]
                binding.container.text = containerData.containerNumber
                if (screenTagName!! == "LOCK") {
                    viewModel.getInventoryLockcodes(
                        InventoryLockcodeRequest(
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                        )
                    )
                    //viewModel.getInventoryLocks()
                } else {
                    lockUnlockDropDownList.clear()
                    containerData.lockCodes?.forEach {
                        it.description?.let { it1 ->
                            unLockCodeHashMap[it1] = it
                            if (it.code != INCUBATION_HOLD && it.code != FIRST_ARTICLE_INSPECTION) {
                                lockUnlockDropDownList.add(it.description)
                            }
                        }

                    }
                    binding.lockCodeDropDown.setOptions(lockUnlockDropDownList)
                    if (lockUnlockDropDownList.size == 0) {
                        binding.lockCodeDropDown.text = resources.getString(R.string.lbl_no_lock_codes_applied)
                    }
                }
                if (containerData.item != null) {
                    binding.itemCode.text = containerData.item.itemCode
                    binding.packageBarcodeDesc.text = containerData.item.itemDesc
                    binding.tvInvTypeValue.text = getInventoryDescription(containerData.inventoryType)
                    binding.qty.text = String.format("%d %s",containerData.item.itemQty,containerData.item.itemQtyUom)
                }
            }
        }
        binding.btnConfirm.setOnClickListener {
            if (screenTagName!! != "UNLOCK") {
                if (selectedLockCode != null) {
                    callLockAdjustmentAPI(selectedLockCode!!.code, selectedLockCode!!.lockCodeId)
                }
            } else {
                if (selectedUnlockCode != null) {
                    callLockAdjustmentAPI(selectedUnlockCode!!.code, selectedUnlockCode!!.lockCodeId)
                }
            }
        }
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeInventoryLockCodesObserver()
        subscribeLocksAdjustmentObserver()
    }


    /**
     * method to subscribe get inventory lock codes observer
     */
    private fun subscribeInventoryLockCodesObserver() {
        viewModel.inventoryLockcodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lockCodeRes ->
                        FlareLog.i(TAG, "lockCodeResponse success: $lockCodeRes")
                        if (lockCodeRes.lockCodes != null && lockCodeRes.lockCodes.isNotEmpty()) {
                            lockUnlockDropDownList.clear()
                            lockCodeRes.lockCodes.forEach {
                                if (it.code != INCUBATION_HOLD && it.code != FIRST_ARTICLE_INSPECTION) {
                                    lockUnlockDropDownList.add(it.description)
                                }
                                lockCodeHashMap[it.description] = it
                            }
                            binding.lockCodeDropDown.setOptions(lockUnlockDropDownList)
                        } else {
                            showErrorSnackBar(resources.getString(R.string.lockcodes_not_available))
                        }

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lockCodeResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        //Dropdown onSelect observer
        binding.lockCodeDropDown.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            Log.d(TAG, "codeSelected: $isUpdated")
            if (screenTagName!! != "UNLOCK") {
                binding.btnConfirm.isEnabled = true
                selectedLockCode = lockCodeHashMap.get(isUpdated)
            } else {
                binding.btnConfirm.isEnabled = true
                selectedUnlockCode = unLockCodeHashMap.get(isUpdated)
            }
        }
    }

    /**
     * method to call lock adjustment/submit API
     */
    private fun callLockAdjustmentAPI(code: String?, codeId: Int?) {
        binding.btnConfirm.isEnabled = false
        val containerListData = viewModel.getContainerInfo()
        if (containerListData != null) {
            if (containerListData.isNotEmpty()) {
                val containerData = containerListData[0]
                unLock = if (screenTagName!! == "UNLOCK") {
                    "Y"
                } else {
                    "N"
                }
                viewModel.lockInventory(
                    InventoryLockRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        containerId = containerData.containerId,
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        //ibObCode = containerData.ibObCode,
                        invMasterId = containerData.invMasterId,
                        //qty = containerData.item!!.itemQty,//
                        //qtyUom = containerData.item.itemQtyUom,//
                        //reasonCode = "",//TODO:need clarity on this
                        locks = getLockUnlockList(code, codeId)
                    )
                )

            }
        }
    }

    /**
     * method to get lock/unlock list
     */
    private fun getLockUnlockList(code: String?, codeId: Int?): List<Lock> {
        val list: MutableList<Lock> = mutableListOf()
        val lock = Lock(
            lockCode = code,
            unLock = unLock,
            lockCodeId = codeId
        )
        list.add(lock)
        return list
    }

    /**
     * method to subscribe lock adjustment observer
     */
    private fun subscribeLocksAdjustmentObserver() {
        viewModel.inventoryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { inventorylock ->
                        if (inventorylock.message != null) {
                            showAlertDialog("", inventorylock.locksMessage?.get(0)?.message!!){getNavigationController().popBackStack(R.id.containerLockUnlockFragment, false)}
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "InventoryLockResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /*private fun subscribeObservers() {
        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksOptions(inventoryLockList)
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        if(!binding.tvInventoryLockUnlock.text.toString().contains("UNLOCK")){
                            binding.lockCodeDropDown.setOptions(inventoryLockList)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.inventoryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { inventorylock ->
                        showSuccessSnackBar(inventorylock.message)
                        Toast.makeText(fragmentContext, inventorylock.message, Toast.LENGTH_SHORT).show()
                        val navController =
                            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                        val action =
                            InventoryLockUnlockReasonFragmentDirections.actionContainerLockUnlockReasonFragmentToContainerLockUnlockFragment()
                        val navOptions = NavOptions.Builder().setPopUpTo(R.id.containerLockUnlockFragment, true).build()
                        navController.navigate(action, navOptions)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "InventoryLockResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.lockCodeDropDown.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            Log.d(TAG, "lockCodeDropDownSelected: $isUpdated")
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == isUpdated) {
                        Log.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        val containerListData = viewModel.getContainerInfo()
                        if (containerListData != null) {
                            if (containerListData.isNotEmpty()) {
                                val containerData = containerListData[0]
                                unLock = if (binding.tvInventoryLockUnlock.text.toString().contains("UNLOCK")) {
                                    "Y"
                                } else {
                                    "N"
                                }
                                MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                                    .setTitle("Are you sure you want to " + binding.tvInventoryLockUnlock.text.toString() + "?")
                                    .setPositiveButton(getString(R.string.alert_button_yes)) { dialogInterface, i ->
//                                        viewModel.lockInventory(
//                                            InventoryLockRequest(
//                                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
//                                                containerId = containerData.containerId,
//                                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
//                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
//                                                ibObCode = containerData.ibObCode,
//                                                invMasterId = containerData.invMasterId,
//                                                lock = Lock(
//                                                    lockCode = lookup.lookupCode,
//                                                    unLock = unLock
//                                                )
//                                            )
//                                        )
                                    }
                                    .setNegativeButton(getString(R.string.alert_button_no)) { dialogInterface, i ->
                                        binding.lockCodeDropDown.text = getString(R.string.select_lock_code)
                                        dialogInterface.dismiss()
                                    }
                                    .setCancelable(false)
                                    .show()
                            }
                        }
                    }
                }
            }
        }
    }
*/
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }


}