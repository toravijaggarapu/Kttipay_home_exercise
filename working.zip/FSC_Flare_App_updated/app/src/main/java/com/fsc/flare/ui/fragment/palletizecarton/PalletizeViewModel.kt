package com.fsc.flare.ui.fragment.palletizecarton

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.ShipmentCarton
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.palletize.CartonDetailResponse
import com.fsc.flare.source.data.dto.palletize.PalletizeRequest
import com.fsc.flare.source.data.dto.palletize.PalletizeResponse
import com.fsc.flare.source.repository.PalletizeRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PalletizeViewModel"

@HiltViewModel
class PalletizeViewModel @Inject constructor(
    private val palletizeRepository: PalletizeRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val palletResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val palletizeCartonResponse: MutableLiveData<Resource<PalletizeResponse>> = SingleLiveEvent()
    val dePalletizeCartonResponse: MutableLiveData<Resource<PalletizeResponse>> = SingleLiveEvent()

    // Send PR API
    val sendToPRResponse: MutableLiveData<Resource<SendToPRResponse>> = SingleLiveEvent()
    val cartonDetailsFromToteResponse: MutableLiveData<Resource<CartonDetailResponse>> = SingleLiveEvent()

    fun getPallet(container: String, itemInfo: String) = viewModelScope.launch {
        palletResponse.postValue(Resource.Loading())
        val response = palletizeRepository.getPallet(container, itemInfo)
        palletResponse.postValue(handleContainerResponse(response))
    }

    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    var container: MutableLiveData<ArrayList<Container>> = MutableLiveData<ArrayList<Container>>()
    fun getContainerInfo(): ArrayList<Container>? {
        return container.value
    }

    fun setContainerInfo(container: ArrayList<Container>) {
        this.container.value = container
    }

    fun palletize(palletizeRequest: PalletizeRequest) = viewModelScope.launch {
        palletizeCartonResponse.postValue(Resource.Loading())
        val response = palletizeRepository.palletize(palletizeRequest)
        palletizeCartonResponse.postValue(handlePalletizeResponse(response))
    }

    private fun handlePalletizeResponse(response: Response<PalletizeResponse>): Resource<PalletizeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletizeResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Palletize Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun depalletize(palletizeRequest: PalletizeRequest) = viewModelScope.launch {
        dePalletizeCartonResponse.postValue(Resource.Loading())
        val response = palletizeRepository.palletize(palletizeRequest)
        dePalletizeCartonResponse.postValue(handlePalletizeResponse(response))
    }

    fun sendToPR(request: SendToPRRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm SendToPR Request:")
        sendToPRResponse.postValue(Resource.Loading())
        val response = palletizeRepository.sendToPR(request)
        sendToPRResponse.postValue(handleSendToPRResponse(response))
    }

    private fun handleSendToPRResponse(response: Response<SendToPRResponse>): Resource<SendToPRResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SendToPRResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SendToPRResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // Pack API
    fun getCartonDetailsFromTote(toteNumber:String,cartonNumber:String) = viewModelScope.launch {
        FlareLog.i(TAG, "getCartonDetailsFromTote Request:")
        cartonDetailsFromToteResponse.postValue(Resource.Loading())
        val response = palletizeRepository.getCartonDetailsFromTote(toteNumber,cartonNumber)
        cartonDetailsFromToteResponse.postValue(handleCartonDetailsFromToteResponse(response))
    }

    private fun handleCartonDetailsFromToteResponse(response: Response<CartonDetailResponse>): Resource<CartonDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CartonDetailResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CartonDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

}