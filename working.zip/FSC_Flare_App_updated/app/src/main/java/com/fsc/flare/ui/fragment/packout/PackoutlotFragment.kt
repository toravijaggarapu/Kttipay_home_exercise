package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutLotBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutLotGetReq
import com.fsc.flare.source.data.dto.packout.req.PackOutSaveTmp
import com.fsc.flare.source.data.dto.packout.req.PrintCaseLabelPackoutReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutlotFragment"

@AndroidEntryPoint
class PackoutlotFragment : BaseFragment(), FlareScannable {


    var list = arrayListOf<String>()
    var count=1

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutLotBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutLotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvDockDoorValue.text = viewModel.getLocationBarcode()

        if (viewModel.getPalletReqNumber() == "") {
            binding.tvPallet.visibility = View.GONE
        }

        else {
            binding.tvPalletValue.text = viewModel.getPalletReqNumber()
        }
        binding.btnEndPackout.isEnabled = false
        binding.tvCartonValue.text = viewModel.getcartonReqNumber()
        binding.itemCode.text = viewModel.getitemData()
        binding.tvQtyValue.text = viewModel.getcasePalletQty().toString()
        binding.tvDescValue.text = viewModel.getItemDesc()

        subscribeObservers()
        subscribeObserversPackOutLot()
        return binding.root
    }

    private fun packOutLotCall() {
        viewModel.validateLotNumber(
            PackOutLotGetReq(
                fcy_Id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                batchNumber = binding.etLot.text.toString(),
                itemName = viewModel.getitemData(),
                itemId = viewModel.getItemId()
            )
        )
    }

    private fun navigateToPackOutCartonFragment(){
        val action=PackoutlotFragmentDirections.actionPackoutlotFragementToPackoutCartonFragement()
        moveToFragment(action)
    }

    private fun subscribeObserversPackOutLot() {
        viewModel.validateLotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packOutLotResponse ->
                        FlareLog.i(TAG, "PackOutLot response:$packOutLotResponse")
                        if (packOutLotResponse.success) {
                            FlareLog.i(TAG, "PackOutLot Success:${packOutLotResponse}")
                            if(!packOutLotResponse.batchDetail.isNullOrEmpty())
                            {

                                viewModel.setExpiryDate("")

                                viewModel.setlotNumber(binding.etLot.text.toString())
                                val taskDetails = viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
                                val serialNumber = taskDetails.tracking.serialNumberRequired
                                val expiryDate = taskDetails.tracking.expirationRequired
                                // viewModel.setTransactionParamResponse(response)
                                if (expiryDate == 1) {
                                    val expirtDateValue = viewModel.getExpiryDateFromResponse()
                                    if(!expirtDateValue.isNullOrEmpty()) {
                                        viewModel.setExpiryDate(expirtDateValue)
                                    }
                                }

                                if (serialNumber == 4 /*|| serialNumber == 1*/) {
//                                viewModel.setExpiryDate("")
                                    val action = PackoutlotFragmentDirections.actionPackoutlotFragementToPackoutserialnumberFragement()
                                    moveToFragment(action)
                                } else {
//                                viewModel.setExpiryDate("")
                                    viewModel.submitPackout(
                                        PackOutSaveTmp(
                                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                            viewModel.getLocationBarcode(),
                                            viewModel.getLocId(),
                                            viewModel.getcasePalletQty(),
                                            viewModel.getpckPallet(),
                                            viewModel.getPalletReqNumber(),
                                            viewModel.getcartonReqNumber(),
                                            viewModel.getItemId(),
                                            viewModel.getQuantity(),
                                            "EA",
                                            viewModel.getlotNumber(),
                                            viewModel.getExpiryDate(),
                                            viewModel.gettransIdentifier(),
                                            list,
                                            viewModel.getInventoryType(),
                                            viewModel.lockCodeSelected,
                                            viewModel.isKitting
                                        )
                                    )
                                }
                            }else
                            {
                                binding.etLotRes.text = resources.getString(R.string.lbl_invalid_lot_number)
                            }
                        } else {
                            FlareLog.e(TAG, "PackOutLot Error:${packOutLotResponse}")
                            binding.etLotRes.text = resources.getString(R.string.lbl_something_went_wrong)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParam Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun subscribeObservers() {
        viewModel.submitPackoutResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { saveTmpResponse ->
                        FlareLog.i(TAG, "PackOutLocation response:$saveTmpResponse")
                        if (saveTmpResponse.success) {
                            FlareLog.i(TAG, "PackOutLocation Success:${saveTmpResponse}")
                            sharedPreferences.edit().putBoolean(PreferenceKeys.Packout.IS_PACKOUT_DONE, true).apply()
                            binding.etLotRes.text = null
                            binding.btnEndPackout.isEnabled = true
                            viewModel.settransIdentifier(saveTmpResponse.transactionIdentifier)
                            if (saveTmpResponse.message.isNotEmpty()) {
                                showSuccessSnackBar(saveTmpResponse.message)
                            }
                            if(viewModel.isKitting && !viewModel.isDekitting)
                            {
                                callToPrintCaseLabel()
                            }
                            else
                            {
                                navigateToPackOutCartonFragment()
                            }
                        } else {
                            //  FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                            binding.etLotRes.text = resources.getString(R.string.lbl_something_went_wrong)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.printCaseLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printCaseLabelResponse ->
                        FlareLog.i(TAG, "printCaseLabelResponse response:$printCaseLabelResponse")
                        if (printCaseLabelResponse.success) {
                            FlareLog.i(TAG, "printCaseLabelResponse Success:${printCaseLabelResponse}")
                            showSuccessSnackBarStd(resources.getString(R.string.case_lbl_printed_successfully)) {
                                navigateToPackOutCartonFragment()
                            }
                        } else {
                            if(printCaseLabelResponse.message!=null)
                            {
                                FlareLog.e(TAG, "PackOutLocation Error:${printCaseLabelResponse.message}")
                                showErrorSnackBar(printCaseLabelResponse.message)
                            }
                            navigateToPackOutCartonFragment()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                        navigateToPackOutCartonFragment()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnEndPackout.setOnClickListener {
            val navController =
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = PackoutlotFragmentDirections.actionPackoutlotFragementToPackoutStagingLocationFragement()
            navController.navigate(action)
        }

        binding.etLot.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.etLotRes.text = null
            }
        })

        binding.etLot.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }

    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etLot)
        if (binding.etLot.isFocused && !binding.etLot.text?.trim().isNullOrEmpty()) {
            FlareLog.i(TAG, "Lot field focused")
            packOutLotCall()
        }else
        {
            binding.etLotRes.text = resources.getString(R.string.lbl_enter_lot_number)
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        binding.etLot.setText(scan?.barcode.toString())
        binding.etLot.text?.length?.let {
            binding.etLot.setSelection(it)
        }
        FlareLog.i(TAG, "Lot field focused")
        packOutLotCall()
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun callToPrintCaseLabel() {
        if (viewModel.isKitting) {
            viewModel.printCaseLabel(
                PrintCaseLabelPackoutReq(
                    itemBarcode = viewModel.getItemBarcode(),
                    itemDescription = viewModel.getItemDesc(),
                    itemName = viewModel.getitemData(),
                    caseNumber = viewModel.getcartonReqNumber(),
                    qty = viewModel.getcasePalletQty().toString(),
                    printerName = viewModel.getDefaultPrinter(),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
        }
    }

}