package com.fsc.flare.ui.fragment.casepicktopalletid

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasePickToPalletIdStageLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "CasePickToPalletIDStageFragment"

/**
 * A simple [CasePickToPalletIDStageFragment] subclass.
 */
@AndroidEntryPoint
class CasePickToPalletIDStageFragment : BaseFragment(), FlareScannable {

    private val viewModel: CasePickToPalletIDViewModel by activityViewModels()
    lateinit var binding: FragmentCasePickToPalletIdStageLocationBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentCasePickToPalletIdStageLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateUI()
        handleUIListeners()
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
    }

    private fun updateUI() {
        with(binding) {
            tvPickingBuildCart.text =
                sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)

            if (!viewModel.stageLocationBarcode.isNullOrEmpty()) {
                tvStagingLocationValue.text = viewModel.stageLocationBarcode
                stageLocationGroup.visibility = View.VISIBLE
            } else {
                stageLocationGroup.visibility = View.GONE
            }
            tvPalletValue.text = viewModel.getPalletNumber()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleUIListeners() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "StagingLocation field focused")
                    validateStagingLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "StagingLocation field focused")
                validateStagingLocation()
            }
            false
        }
        binding.etStagingLocation.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.stagingLocResponse.text = null
            }
        })
    }

    private fun subscribeObservers() {
        subscribeLocationObserver()
        subscribePickStagingObserver()
    }

    private fun subscribeLocationObserver() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationClassResponse ->
                        if (locationClassResponse.success && locationClassResponse.locations.isNotEmpty()) {
                            handleLocationSuccessResponse(locationClassResponse)
                        } else {
                            showErrorMessage(getString(R.string.invalid_staging_location))
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleLocationSuccessResponse(locationClassResponse: LocationClassRes) {
        val location = locationClassResponse.locations[0]
        val locationClass = location.classification
        if (locationClass == "S") {
            val stagingLocationId = location.locationId
            viewModel.taskActivePickStagingReq(stagingLocationId)
        } else {
            showErrorMessage(getString(R.string.invalid_staging_location))
        }
    }

    private fun subscribePickStagingObserver() {
        viewModel.taskActivePickStagingResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { pickStagingResponse ->
                        if (pickStagingResponse.success != null && pickStagingResponse.success) {
                            binding.etStagingLocation.text = null
                            showSuccessSnackBarStd(getString(R.string.pallet_staged_successfully)) {
                                val action =
                                    CasePickToPalletIDStageFragmentDirections.actionCasePickToPalletIDPalletToCasePickToPalletIDPalletFragment()
                                getNavigationController().navigate(action)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    fun showErrorMessage(message: String) {
        with(binding) {
            if (message.contains("##")) {
                val msgArray = message.split("##")
                if (msgArray.isNotEmpty()) {
                    stagingLocResponse.text = (msgArray[1])
                }
            } else {
                stagingLocResponse.text = message
            }
            etStagingLocation.selectAll()
            showSoftKeyBoard(fragmentContext, etStagingLocation)
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        binding.etStagingLocation.setText(scan?.barcode.toString())
        binding.etStagingLocation.text?.length?.let {
            binding.etStagingLocation.setSelection(it)
        }
        FlareLog.i(TAG, "StagingLocation field focused")
        validateStagingLocation()
    }

    private fun validateStagingLocation() {
        if (isProgressBarVisible()) {
            return
        }
        val stageLocation = binding.etStagingLocation.text.toString()
        if (stageLocation.isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
            viewModel.validateStageLocation(stageLocation)
        }
    }

}