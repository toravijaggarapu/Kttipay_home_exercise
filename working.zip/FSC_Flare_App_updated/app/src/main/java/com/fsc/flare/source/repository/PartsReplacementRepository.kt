package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.partsreplacement.request.CompleteMoveTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.PrintTaskLabelRequest
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PartsReplacementRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getRepairTaskRf(getRepairTaskRf : GetRepairTaskRf) =
        apiGatewayInterface.getRepairTaskRf(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            moveTaskRequest = getRepairTaskRf
        )


    suspend fun updateMoveTaskDetailsRf(updateMoveTaskRf : UpdateMoveTaskDetailsRequest) =
        apiGatewayInterface.updateMoveTaskDetailsRf(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            moveTaskRequest = updateMoveTaskRf
        )


    suspend fun completeMoveTaskRf(getMoveTaskRf : CompleteMoveTaskRf) =
        apiGatewayInterface.completeMoveTaskRf(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            moveTaskRequest = getMoveTaskRf
        )

    suspend fun printPartsReplacementRf(printTaskLabelRequest: PrintTaskLabelRequest) =
        apiGatewayInterface.printPartsReplacementRf(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            printTaskLabelRequest = printTaskLabelRequest
        )


}