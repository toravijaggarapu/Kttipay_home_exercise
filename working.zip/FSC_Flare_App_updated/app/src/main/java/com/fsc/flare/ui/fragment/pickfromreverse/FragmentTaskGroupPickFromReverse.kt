package com.fsc.flare.ui.fragment.pickfromreverse

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTaskgroupPickFromReverseBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "FragmentTaskGroupPickFromReverse"

@AndroidEntryPoint
class FragmentTaskGroupPickFromReverse : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTaskgroupPickFromReverseBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getTaskGroups("30")
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        if (viewModel.gettaskGroupCodeOptions() != null) {
            binding.rsvTaskGroupDropDown.setOptions(viewModel.gettaskGroupCodeOptions())
        }
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTaskgroupPickFromReverseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun subscribeObservers() {

        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success != null && taskpickResponse.success) {
                            FlareLog.i(TAG, "taskPick success: $taskpickResponse")
                            if (taskpickResponse.taskDetails == null) {
                                taskpickResponse.message?.let { showErrorSnackBar(it) }
                            } else {
                                viewModel.setPickTaskDetails(taskpickResponse.taskDetails)
                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    FragmentTaskGroupPickFromReverseDirections.actionPickFromReserveFragmentToPickFromReserveContainerFragment()
                                navController.navigate(action)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrp success: $taskGroupResponse")
                        val taskGroupDescList = ArrayList<String>()
                        val taskGroups = ArrayList<TaskGroup>()
                        taskGroupResponse.taskGroups?.forEach { lookup ->
                            taskGroupDescList.add(lookup.description)
                            taskGroups.add(lookup)
                        }
                        viewModel.settaskGroupCodeOptions(taskGroupDescList)
                        viewModel.setTaskGroupsList(taskGroups)
                        binding.rsvTaskGroupDropDown.setOptions(taskGroupDescList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskGrp Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        binding.rsvTaskGroupDropDown.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            val taskGroups = viewModel.getTaskGroupsList()
            taskGroups?.forEach { lookupCode ->
                if (lookupCode.description == isUpdated) {
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP, isUpdated).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, lookupCode.code).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, lookupCode.allocationType).apply()
                }
            }
            viewModel.getTaskPick(
                TaskPickReq(
                    allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    custId =  sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    taskGroup = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null)!!,
                    isLTLcubing = viewModel.isLTLCubingEnabled,
                    orderType = viewModel.orderType
                )
            )
        }
    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")

    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}