package com.fsc.flare.ui.fragment.labelsanddocuments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintCartonRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintDocAndLabelResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintOrderRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintPalletRequestNew
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfigReq
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.repository.LabelsAndDocumentsRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "LabelsAndDocumentsViewModel"

@HiltViewModel
class LabelsAndDocumentsViewModel @Inject constructor(
    private val labelsAndDocumentsRepository: LabelsAndDocumentsRepository,
) : BaseViewModel() {

    val printerConfigsResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    var printerConfigs: MutableLiveData<List<PrinterConfig>> = MutableLiveData<List<PrinterConfig>>()
    val printEntityResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val printerNameResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val printInputResponse: MutableLiveData<Resource<ValidateInputResponse>> = SingleLiveEvent()
    val printLblAndDocResponse: MutableLiveData<Resource<PrintDocAndLabelResponse>> = SingleLiveEvent()

    fun setPrinterConfigs(printerConfigs: List<PrinterConfig>) {
        this.printerConfigs.value = printerConfigs
    }

    fun getPrinterConfigs(): List<PrinterConfig>? {
        return printerConfigs.value
    }

    fun calGetPrinterConfig(printerConfigReq: PrinterConfigReq) = viewModelScope.launch {
        printerConfigsResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.getPrinterConfigs(printerConfigReq)
        printerConfigsResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getPrintEntity() = viewModelScope.launch {
        printEntityResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.getPrintEntity()
        printEntityResponse.postValue(handlePrintResponse(response))
    }

    fun getPrinterName() = viewModelScope.launch {
        printerNameResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.getPrinterName()
        printerNameResponse.postValue(handlePrintResponse(response))
    }

    private fun handlePrintResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    var entityDescList: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var entityList: MutableLiveData<List<Lookup>> = MutableLiveData<List<Lookup>>()
    var validateInput: MutableLiveData<ValidateInputResponse> = MutableLiveData<ValidateInputResponse>()


    fun getEntityList(): List<Lookup> {
        return entityList.value!!
    }

    fun setEntityList(entityList: List<Lookup>) {
        this.entityList.value = entityList
    }

    fun getEntityDescList(): ArrayList<String>? {
        return entityDescList.value
    }

    fun setEntityDescList(entityDescList: ArrayList<String>) {
        this.entityDescList.value = entityDescList
    }

    fun getInput(): ValidateInputResponse? {
        return validateInput.value
    }

    fun setInput(validateInput: ValidateInputResponse) {
        this.validateInput.value = validateInput
    }

    fun validateInputForPrinting(validateInputRequest: ValidateInputRequest) = viewModelScope.launch {
        printInputResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.validateInputForPrinting(validateInputRequest)
        printInputResponse.postValue(handlePrintInputResponse(response))
    }

    private fun handlePrintInputResponse(response: Response<ValidateInputResponse>): Resource<ValidateInputResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintInputResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintInput Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun printOrder(printOrderRequest: PrintOrderRequest)  = viewModelScope.launch {
        printLblAndDocResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.printOrder(printOrderRequest)
        printLblAndDocResponse.postValue(handlePrintLblAndDocResponse(response))
    }

    fun printShipment(printShipmentRequest: PrintShipmentRequest) = viewModelScope.launch {
        printLblAndDocResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.printShipment(printShipmentRequest)
        printLblAndDocResponse.postValue(handlePrintLblAndDocResponse(response))
    }

    fun printCarton(printCartonRequest: PrintCartonRequest) = viewModelScope.launch {
        printLblAndDocResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.printCarton(printCartonRequest)
        printLblAndDocResponse.postValue(handlePrintLblAndDocResponse(response))
    }

    private fun handlePrintLblAndDocResponse(response: Response<PrintDocAndLabelResponse>): Resource<PrintDocAndLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintLblAndDoc : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintLblAndDoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun printPalletNew(printPalletRequestNew: PrintPalletRequestNew)  = viewModelScope.launch {
        printLblAndDocResponse.postValue(Resource.Loading())
        val response = labelsAndDocumentsRepository.printPalletNew(printPalletRequestNew)
        printLblAndDocResponse.postValue(handlePrintPalletNewResponse(response))
    }

    private fun handlePrintPalletNewResponse(response: Response<PrintDocAndLabelResponse>): Resource<PrintDocAndLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintLblAndDoc : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintLblAndDoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

}