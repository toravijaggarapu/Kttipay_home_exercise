package com.fsc.flare.utils

import android.view.View
import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.ReasonCodes
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.model.TaskGroups


@BindingAdapter("lotShowHide")
fun setVisibility(view: TextView, lotRequired: String?) {
    view.visibility = if (lotRequired == "1") View.VISIBLE else View.GONE
}

@BindingAdapter("fieldShowHide")
fun setFieldVisibility(view: TextView, value: String?) {
    view.visibility = if (!value.isNullOrEmpty()) View.VISIBLE else View.GONE
}

@BindingAdapter("reasonCodeOptions")
fun setItems(dropdown: DropDown, items: List<ReasonCodes>?) {
    if (items != null) {
        dropdown.setOptions(ArrayList(items.map { it.reasonCode.plus(" - ").plus(it.reasonCodeDescription) }))
    }
}

@BindingAdapter("taskGroupOptions")
fun setTaskGroups(dropdown: DropDown, items: List<TaskGroup>?) {
    if (items != null) {
        dropdown.setOptions(ArrayList(items.map { it.description }))
    }
    }