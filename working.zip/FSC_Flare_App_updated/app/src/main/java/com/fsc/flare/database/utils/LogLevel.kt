package com.fsc.flare.database.utils

enum class LogLevel(val level: String) {
    INFO("INFO"), ERROR("ERROR"), WARN("WARN"), DEBUG("DEBUG")
}