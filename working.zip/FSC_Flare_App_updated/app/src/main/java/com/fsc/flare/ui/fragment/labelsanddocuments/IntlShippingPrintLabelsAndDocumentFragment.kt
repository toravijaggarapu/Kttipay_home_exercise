package com.fsc.flare.ui.fragment.labelsanddocuments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentIntlShippingPrintLabelsAndDocumentBinding
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull

@AndroidEntryPoint
class IntlShippingPrintLabelsAndDocumentFragment : BaseFragment() {

    private lateinit var binding: FragmentIntlShippingPrintLabelsAndDocumentBinding
    private val sharedViewModel: LabelsAndDocumentsViewModel by activityViewModels()
    private val viewModel: IntlShippingPrintLabelsAndDocumentViewModel by viewModels()
    private val inputResponse by lazy { sharedViewModel.getInput() }

    private val adapter by lazy {
        DocumentPrintAdapter { isEnable, isAllSelected ->
            binding.btnPrint.isEnabled = isEnable
            binding.cbSelectAll.isChecked = isAllSelected
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentIntlShippingPrintLabelsAndDocumentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeFlowOnUI { screenState() }
        inputResponse?.let { viewModel.getInternationalShippingDocuments(inputResponse = it) }
    }

    private fun initViews() {
        binding.tvPrintRequester.text = sharedViewModel.getPrinterConfigs()?.firstOrNull()?.requestor
        binding.tvPrintEntity.text = getString(R.string.order)
        binding.tvOrderNumber.text = inputResponse?.orderNumber.orEmpty()

        binding.rvDocuments.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvDocuments.adapter = adapter

        binding.cbSelectAll.setOnClickListener {
            adapter.manageAllDocumentSelection(binding.cbSelectAll.isChecked)
        }

        binding.btnPrint.setOnClickListener {
            viewModel.printSelectedDocuments(
                printInput = inputResponse,
                printerConfigs = sharedViewModel.getPrinterConfigs(),
                selectedDocuments = adapter.getSelectedDocList()
            )
        }
    }

    private suspend fun screenState() {
        viewModel.screenState.filterNotNull().collect { state ->
            when (state) {

                ShippingDocumentsScreenState.ShowLoading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    disableTouch()
                }

                ShippingDocumentsScreenState.HideLoading -> {
                    binding.progressBar.visibility = View.GONE
                    enableTouch()
                }

                is ShippingDocumentsScreenState.ShowDocuments -> {
                    binding.rvDocuments.visibility = View.VISIBLE
                    binding.cbSelectAll.visibility = View.VISIBLE
                    binding.tvNoDataMessage.visibility = View.GONE
                    adapter.resetList(state.documents)
                    binding.btnPrint.isEnabled = state.documents.any { it.isChecked }
                    binding.cbSelectAll.isChecked = state.documents.count { it.isChecked } == state.documents.size
                }

                ShippingDocumentsScreenState.NoDocumentsFound,
                is ShippingDocumentsScreenState.ShowDocAPIError -> {
                    binding.rvDocuments.visibility = View.GONE
                    binding.cbSelectAll.visibility = View.GONE
                    binding.tvNoDataMessage.visibility = View.VISIBLE
                    binding.tvNoDataMessage.text = if (state is ShippingDocumentsScreenState.ShowDocAPIError)
                            state.message
                        else
                            getString(R.string.no_documents_found)
                }

                is ShippingDocumentsScreenState.ShowPrintAPIError -> {
                    showErrorSnackBar(state.message ?: getString(R.string.lbl_something_went_wrong))
                }

                ShippingDocumentsScreenState.PrintSuccess -> {
                    showSuccessSnackBar(getString(R.string.documents_printed_successfully))
                    delay(3000)
                    findNavController().popBackStack(R.id.labelsAndDocuments, inclusive = false)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearData()
    }
}