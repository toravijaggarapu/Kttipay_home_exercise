package com.fsc.flare.ui.fragment.cyclecount

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.cyclecount.CCDetailsUpdateResponse
import com.fsc.flare.source.data.dto.cyclecount.CCLocationInquiryResponse
import com.fsc.flare.source.data.dto.cyclecount.CCQtyUpdateResponse
import com.fsc.flare.source.data.dto.cyclecount.CCTaskDetails
import com.fsc.flare.source.data.dto.cyclecount.CCTaskDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsForwardRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsReverseRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedResponse
import com.fsc.flare.source.data.dto.cyclecount.CCValidateSlpResponse
import com.fsc.flare.source.data.dto.cyclecount.CountPendingResponse
import com.fsc.flare.source.data.dto.cyclecount.CreateCycleCountDetailResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCount
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetailRequest
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetails
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTaskDetailResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTaskResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTrackingDetails
import com.fsc.flare.source.data.dto.cyclecount.EndCycleCountResponse
import com.fsc.flare.source.data.dto.cyclecount.EndUserDirectedCCRequest
import com.fsc.flare.source.data.dto.cyclecount.EndUserDirectedCCResponse
import com.fsc.flare.source.data.dto.cyclecount.InventoryMasterResponse
import com.fsc.flare.source.data.dto.cyclecount.LocationInventoryCount
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountDetailsRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateVirtualContainersCountRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateVirtualContainersCountResponse
import com.fsc.flare.source.data.dto.cyclecount.ValidateLotOrMfgCodeResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesContainerRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesContainerResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesEndCCRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesEndCycleCountResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesLocationRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesLocationResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesQtyRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesQtyResponse
import com.fsc.flare.source.data.dto.cyclecount.bypalletcontainerid.CCByPalletContainerIdDetails
import com.fsc.flare.source.data.dto.inquiry.location.resp.RlogLocationInquiryResp
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.Location
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.UpcOrSlpResponse
import com.fsc.flare.source.data.dto.receiving.item.Item
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.data.dto.receiving.serial.LotNumberResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.CycleCountRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

const val RESERVE_SYS_ALLOCATION_TYPES = "200,210,230,240,360,370,430,440"
const val RESERVE_USR_ALLOCATION_TYPES = "260,270"

const val REVERSE_SYS_ALLOCATION_TYPE="610,620"
const val REVERSE_USR_ALLOCATION_TYPE="610,620"

const val PALLET_NAVIGATION = "PL"
const val CASE_NAVIGATION = "CS"
const val ITEM_NAVIGATION = "IT"
const val QTY_NAVIGATION = "QTY"

const val TASK_MODE_USER_DIRECTED = "M"
const val TASK_MODE_SYSTEM_DIRECTED = "S"

const val ALLOCATION_TYPE_USER_DIRECTED = "530,540"
const val ALLOCATION_TYPE_SYSTEM_DIRECTED = "510,520,550,560"

const val CC_TYPE_SYSTEM_DIRECTED = "SD"
const val CC_TYPE_USER_DIRECTED = "UD"


@HiltViewModel
class CycleCountViewModel @Inject constructor(
    private val cycleCountRepository: CycleCountRepository
) : BaseViewModel() {

    val taskGroupResponse: MutableLiveData<Resource<TaskGroupResponse>> = SingleLiveEvent()
    val taskResponse: MutableLiveData<Resource<CycleCountTaskResponse>> = SingleLiveEvent()
    val endCCTaskResponse: MutableLiveData<Resource<CycleCountTaskResponse>> = SingleLiveEvent()
    val slpResponse: MutableLiveData<Resource<CCValidateSlpResponse>> = SingleLiveEvent()
    val ccDetailsResponse: MutableLiveData<Resource<CycleCountDetailsResponse>> = SingleLiveEvent()
    val qtyUpdateResponse: MutableLiveData<Resource<CCQtyUpdateResponse>> = SingleLiveEvent()
    val endCCResponse: MutableLiveData<Resource<EndCycleCountResponse>> = SingleLiveEvent()
    val packageItemResponse: MutableLiveData<Resource<PackageItemResponse>> = SingleLiveEvent()
    val updateCycleCountDetails: MutableLiveData<Resource<CCDetailsUpdateResponse>> = SingleLiveEvent()
    val locationDetailsResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val locationInquiryResponse: MutableLiveData<Resource<CCLocationInquiryResponse>> = SingleLiveEvent()
    val inventoryMasterResponse: MutableLiveData<Resource<InventoryMasterResponse>> = SingleLiveEvent()
    val locationInfoWithInventoryCountCallResponse: MutableLiveData<Resource<LocationInventoryCount>> = SingleLiveEvent()
    val userDirectedResponse: MutableLiveData<Resource<CCUserDirectedResponse>> = SingleLiveEvent()
    val cycleCountForLocationResponse: MutableLiveData<Resource<CCTaskDetailsResponse>> = SingleLiveEvent()
    val cycleCountTaskAssignResponse: MutableLiveData<Resource<CycleCountTaskDetailResponse>> = SingleLiveEvent()
    val ccTaskAssignResponse: MutableLiveData<Resource<CycleCountTaskDetailResponse>> = SingleLiveEvent()
    val userDirectedDetailsResponse: MutableLiveData<Resource<CCUserDirectedDetailsResponse>> = SingleLiveEvent()
    val mLPNResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val containerResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val endUserDirectedCCResponse: MutableLiveData<Resource<EndUserDirectedCCResponse>> = SingleLiveEvent()
    val lotNumberResponse: MutableLiveData<Resource<LotNumberResponse>> = SingleLiveEvent()
    val serialItemIdValidationResponse: MutableLiveData<Resource<PickingSerialOrItemCodeResponse>> = SingleLiveEvent()
    val lookupsResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val enableQtyCapture: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val validateLotNumberResponse: MutableLiveData<Resource<ValidateLotNumberResponse>> = SingleLiveEvent()
    val validateLotOrMfgCodeResponse: MutableLiveData<Resource<ValidateLotOrMfgCodeResponse>> = SingleLiveEvent()
    val validateCCLocationResponse: MutableLiveData<Resource<CCByLocationInEachesLocationResponse>> = SingleLiveEvent()
    val validateCCContainerResponse: MutableLiveData<Resource<CCByLocationInEachesContainerResponse>> = SingleLiveEvent()
    val validateCCQtyResponse: MutableLiveData<Resource<CCByLocationInEachesQtyResponse>> = SingleLiveEvent()
    val endSummaryLevelCycleCountResponse: MutableLiveData<Resource<CCByLocationInEachesEndCycleCountResponse>> = SingleLiveEvent()
    val upcOrSlpResponse: MutableLiveData<Resource<UpcOrSlpResponse>> = SingleLiveEvent()
    val locationByItemIdsInquiryResponse: MutableLiveData<Resource<Boolean>> = SingleLiveEvent()
    val countriesLookUpResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val countPendingResponse = SingleLiveEvent<Resource<CountPendingResponse>>()
    val updateVirtualContainersCountResponse = SingleLiveEvent<Resource<UpdateVirtualContainersCountResponse>>()
    val createCycleCountDetails: MutableLiveData<Resource<CreateCycleCountDetailResponse>> = SingleLiveEvent()

    var isUserDirectedFlow = false
    var previousScannedContainer: String? = null
    var previousScannedPallet: String? = null
    var ccReasonCodesLookup : List<Lookup> = emptyList()
    var selectedCCReasonCodeDesc: String? = ""
    var createNewExcessInventoryCasePick: String = "N"
    var createNewExcessInventoryReserve: String = "N"
    var createNewExcessInventory: String = "N"
    var countriesHashMap : HashMap<String, String> = hashMapOf()
    var countriesWithCodesList : ArrayList<String> = arrayListOf()
    var selectedInvTypeDesc : String = ""
    var cooSelected: String = ""
    var isVirtualContainerFlow = false
    var ccHeaderIdInUserDirectedFlow = 0
    var ccDetIdInBlindFlow = 0L
    var ccDetIdInEmptyLoc = 0L
    var acceptBlindCase = false
    private var locationByItemIdList: List<String?> = emptyList()
    var allowCountAsVirtualContainers = false
    var isPalletScannedSecondTime = false
    var locationClass = ""
    var blindContainersToCount = 0
    var palletLocationId: Int?= null


    fun getTaskGroups(allocationType: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getTaskGroups Request: $allocationType")
        taskGroupResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getTaskGroups(allocationType)
        taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskGroupsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskGroupsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getItems(packageItemRequest: PackageItemRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getItems Request: $packageItemRequest")
        packageItemResponse.postValue(Resource.Loading())
        val packageItemRes = cycleCountRepository.getItems(packageItemRequest)
        packageItemResponse.postValue(handlePackageItemResponse(packageItemRes))
    }

    fun validateItemCodeUPSForLocation(packageItemRequest: PackageItemRequest){
        if (locationByItemIdList.size > 1) {
            packageItemResponse.postValue(Resource.Error(Constants.ERR_MULTIPLE_SKU))
        } else {
            getItems(packageItemRequest)
        }
    }

    private fun handlePackageItemResponse(packageItemResponse: Response<PackageItemResponse>): Resource<PackageItemResponse>? {
        if (packageItemResponse.isSuccessful) {
            packageItemResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackageItemResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(packageItemResponse.code(), packageItemResponse.errorBody(), packageItemResponse.message())
            FlareLog.e(TAG, "PackageItemResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun cyclecountcontainer(locationId: Int, ccHeaderId: Int, containerNbr: String, createNewExcessInventory: String = "N", acceptBlindCase: Boolean = false, taskType: String? = "", reasonCode: String? = null) = viewModelScope.launch {
        FlareLog.i(TAG, "cyclecountcontainer Request: Locationid:$locationId CCHeaderId: $ccHeaderId ContainerNbr: $containerNbr")
        ccDetailsResponse.postValue(Resource.Loading())
        val ccDetailsRes = cycleCountRepository.cyclecountcontainer(locationId, ccHeaderId, containerNbr, createNewExcessInventory, acceptBlindCase, taskType, reasonCode)
        ccDetailsResponse.postValue(handleCcDetailsResponse(ccDetailsRes))
    }

    private fun handleCcDetailsResponse(response: Response<CycleCountDetailsResponse>): Resource<CycleCountDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return if (resultResponse.success) {
                    FlareLog.i(TAG, "CcDetailsResponse: $resultResponse")
                    Resource.Success(resultResponse)
                } else {
                    FlareLog.e(TAG, "CcDetailsResponse Error: ${resultResponse.message}")
                    Resource.Error(resultResponse.message)
                }
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CcDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun qtyUpdate(updateCycleCountRequest: UpdateCycleCountRequest, ccDetId: Long) = viewModelScope.launch {
        FlareLog.i(TAG, "qtyUpdate Request: QTY: $updateCycleCountRequest CCDetId: $ccDetId")
        qtyUpdateResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.qtyUpdate(updateCycleCountRequest, ccDetId)
        qtyUpdateResponse.postValue(handleQtyUpdateResponse(response))
    }

    private fun handleQtyUpdateResponse(response: Response<CCQtyUpdateResponse>): Resource<CCQtyUpdateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "QtyUpdateResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "QtyUpdateResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun endCycleCount(ccHeaderId: Int, override: Boolean) = viewModelScope.launch {
        FlareLog.i(TAG, "endCycleCount Request: CCHeaderId: $ccHeaderId")
        endCCResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.endCycleCount(ccHeaderId, override)
        endCCResponse.postValue(handleEndCCResponse(response))
    }

    private fun handleEndCCResponse(response: Response<EndCycleCountResponse>): Resource<EndCycleCountResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "EndCCResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "EndCCResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getCycleCountTask() = viewModelScope.launch {
        taskResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getCycleCountTask(locationId.toString())
        taskResponse.postValue(handleTaskResponse(response))
    }

    fun getEndCCCycleCountTask() = viewModelScope.launch {
        endCCTaskResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getCycleCountTask()
        endCCTaskResponse.postValue(handleTaskResponse(response))
    }

    fun getSystemDirectedCycleCountTask() = viewModelScope.launch {
        taskResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getSystemDirectedCycleCountTask()
        taskResponse.postValue(handleTaskResponse(response))
    }

    private fun handleTaskResponse(response: Response<CycleCountTaskResponse>): Resource<CycleCountTaskResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateSlp(ccHeaderId: Int, slp: String, containerId: Long) = viewModelScope.launch {
        FlareLog.i(TAG, "validateSlp Request: CCHeaderId: $ccHeaderId SLP: $slp ContainerId: $containerId")
        slpResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateSlp(ccHeaderId, slp, containerId)
        slpResponse.postValue(handleSlpResponse(response))
    }

    private fun handleSlpResponse(response: Response<CCValidateSlpResponse>): Resource<CCValidateSlpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SlpResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SlpResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun updateCycleCountDetails(cycleCountDetails: UpdateCycleCountDetailsRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "updateCycleCountDetails: $cycleCountDetails")
        updateCycleCountDetails.postValue(Resource.Loading())
        val response = cycleCountRepository.updateCycleCountDetails(cycleCountDetails)
        updateCycleCountDetails.postValue(handleUpdateCCDetailsResponse(response))
    }

    private fun handleUpdateCCDetailsResponse(response: Response<CCDetailsUpdateResponse>): Resource<CCDetailsUpdateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CCDetailsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CCDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getLocationDetails(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "LocationDetails Request: $locationClassReq")
        locationDetailsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getLocationDetails(locationClassReq)
        locationDetailsResponse.postValue(handleLocationDetailsResponse(response))
    }

    private fun handleLocationDetailsResponse(response: Response<LocationClassRes>): Resource<LocationClassRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationDetails Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getLocationInquiry(location: String, containerNumber: String, itemId: String ) = viewModelScope.launch {
        FlareLog.i(TAG, "LocationDetails Request: $location")
        locationInquiryResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getLocationInquiry(location, containerNumber, itemId)
        locationInquiryResponse.postValue(handleLocationInquiryResponse(response))
    }

    private fun handleLocationInquiryResponse(response: Response<CCLocationInquiryResponse>): Resource<CCLocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationDetails Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getLocationInfoWithInventoryCount(locationId: String) = viewModelScope.launch {
        locationInfoWithInventoryCountCallResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getLocationInventoryCount(locationId)
        locationInfoWithInventoryCountCallResponse.postValue(handleLocationInfoWithInventoryCountResponse(response))
    }

    private fun handleLocationInfoWithInventoryCountResponse(response: Response<LocationInventoryCount>):Resource<LocationInventoryCount>?{
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryMaster Location Info Count Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryMaster Location Info Count Response Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
    fun getContainerInquiry(containerId: String, itemId: String) = viewModelScope.launch {
        inventoryMasterResponse.postValue(Resource.Loading())
        val conResponse = cycleCountRepository.getContainerInquiry(containerId,itemId)
        inventoryMasterResponse.postValue(handleInventoryMasterResponse(conResponse))
    }

    private fun handleInventoryMasterResponse(lResponse: Response<InventoryMasterResponse>): Resource<InventoryMasterResponse>? {
        if (lResponse.isSuccessful) {
            lResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Inventory Master Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(lResponse.code(), lResponse.errorBody(), lResponse.message())
            FlareLog.e(TAG, "Inventory Master Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun cycleCountUserDirected(ccUserDirectedRequest: CCUserDirectedRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "CCUserDirected Request: $ccUserDirectedRequest")
        userDirectedResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.cycleCountUserDirected(ccUserDirectedRequest)
        userDirectedResponse.postValue(handleUserDirectedResponse(response))
    }

    private fun handleUserDirectedResponse(response: Response<CCUserDirectedResponse>): Resource<CCUserDirectedResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CCUserDirected Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CCUserDirected Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun ccUserDirectedDetailsForward(ccUserDirectedDetailsForwardRequest: CCUserDirectedDetailsForwardRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "CCUserDirectedDetailsForward Request: $ccUserDirectedDetailsForwardRequest")
        userDirectedDetailsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.ccUserDirectedDetailsForward(ccUserDirectedDetailsForwardRequest)
        userDirectedDetailsResponse.postValue(handleUserDirectedDetailsResponse(response))
    }

    fun ccUserDirectedDetailsForwardUserId(ccUserDirectedDetailsForwardRequest: CCUserDirectedDetailsForwardRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "CCUserDirectedDetailsForward Request: $ccUserDirectedDetailsForwardRequest")
        userDirectedDetailsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.ccUserDirectedDetailsForwardUserId(ccUserDirectedDetailsForwardRequest)
        userDirectedDetailsResponse.postValue(handleUserDirectedDetailsResponse(response))
    }

    private fun handleUserDirectedDetailsResponse(response: Response<CCUserDirectedDetailsResponse>): Resource<CCUserDirectedDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CCUserDirectedDetails Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CCUserDirectedDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun ccUserDirectedDetailsReverse(ccUserDirectedDetailsReverseRequest: CCUserDirectedDetailsReverseRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "CCUserDirectedDetailsReverse Request: $ccUserDirectedDetailsReverseRequest")
        userDirectedDetailsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.ccUserDirectedDetailsReverse(ccUserDirectedDetailsReverseRequest)
        userDirectedDetailsResponse.postValue(handleUserDirectedDetailsResponse(response))
    }

    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getContainer(container, itemInfo)
        containerResponse.postValue(handleContainerResponse(response))
    }

    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun endUserDirectedCycleCount(endUserDirectedCCRequest: EndUserDirectedCCRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "endUserDirectedCycleCount Request: $endUserDirectedCCRequest")
        endUserDirectedCCResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.endUserDirectedCycleCount(endUserDirectedCCRequest)
        endUserDirectedCCResponse.postValue(handleEndUserDirectedCCResponse(response))
    }

    fun endUserDirectedCycleCountUserId(endUserDirectedCCRequest: EndUserDirectedCCRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "endUserDirectedCycleCount Request: $endUserDirectedCCRequest")
        endUserDirectedCCResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.endUserDirectedCycleCountUserId(endUserDirectedCCRequest)
        endUserDirectedCCResponse.postValue(handleEndUserDirectedCCResponse(response))
    }

    private fun handleEndUserDirectedCCResponse(response: Response<EndUserDirectedCCResponse>): Resource<EndUserDirectedCCResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "EndUserDirectedCCResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "EndUserDirectedCCResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getValidateLPNNumber(container: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        mLPNResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getValidateLPN(container)
        mLPNResponse.postValue(handleValidateContainerResponse(response))
    }

    fun getValidateContainer(container: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getValidateContainer(container)
        containerResponse.postValue(handleValidateContainerResponse(response))
    }

    private fun handleValidateContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun updateValidContainer(cycleCountDetails: CycleCountDetailRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "updateCycleCountDetails: $cycleCountDetails")
        updateCycleCountDetails.postValue(Resource.Loading())
        val response = cycleCountRepository.updateValidContainer(cycleCountDetails)
        updateCycleCountDetails.postValue(handleUpdateCCDetailsResponse(response))
    }

    fun getEnableQtyCapture() = viewModelScope.launch {
        enableQtyCapture.postValue(Resource.Loading())
        val response = cycleCountRepository.getEnableQtyCapture()
        enableQtyCapture.postValue(handleInventoryLocksResponse(response))
    }

    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryLocksResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryLocksResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateItemLotNumber(request: ValidateLotNumberRequest) = viewModelScope.launch {
        validateLotNumberResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateLotNumber(request)
        validateLotNumberResponse.postValue(handleValidateLotNumberResponse(response))
    }

    private fun handleValidateLotNumberResponse(response: Response<ValidateLotNumberResponse>): Resource<ValidateLotNumberResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateLotNumberResponseTivoPFRResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    fun validateLotOrMfgCodeRequest(itemId: Int,lotOrMfgCode: String) = viewModelScope.launch {
        validateLotOrMfgCodeResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateLotOrMfgCodeRequest(itemId,lotOrMfgCode)
        validateLotOrMfgCodeResponse.postValue(handleValidateLotOrMfgCodeResponse(response))
    }

    private fun handleValidateLotOrMfgCodeResponse(response: Response<ValidateLotOrMfgCodeResponse>): Resource<ValidateLotOrMfgCodeResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleValidateLotOrMfgCodeResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleValidateLotOrMfgCode Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    /**
     * method to validate serial number or itemcode API
     */
    fun validateSerialNumberOrItemCode(serialNumberOrItemId: String, isOutBoundOnly: Boolean) = viewModelScope.launch {
        serialItemIdValidationResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = cycleCountRepository.validateSerialNumberWithItemCode(serialNumberOrItemId, isOutBoundOnly)
        serialItemIdValidationResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    /**
     * method to handle serial or Item id validation response
     */
    private fun handleSerialNumberOrItemIdValidationResponse(response: Response<PickingSerialOrItemCodeResponse>): Resource<PickingSerialOrItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            return if (response.code() in 400..501) {
                val responseMessage = handleForwardErrorResponse(response.errorBody(), TAG)
                if (responseMessage.isEmpty()) {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: ${response.message()}")
                    Resource.Error(response.message())
                } else {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: $responseMessage")
                    Resource.Error(responseMessage)
                }
            } else {
                Resource.Error(response.message())
            }
        }
        return null
    }

    /**
     * method to get inventory lookups
     */
    fun getEmptyLocationLookups(inventoryLookupsRequest: InventoryLookupsRequest) = viewModelScope.launch {
        lookupsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getEmptyLocationLookups(inventoryLookupsRequest)
        lookupsResponse.postValue(handleLookupsResponse(response))
    }

    fun getCCReasonCodes(inventoryLookupsRequest: InventoryLookupsRequest) = viewModelScope.launch {
        lookupsResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getEmptyLocationLookups(inventoryLookupsRequest)
        lookupsResponse.postValue(handleLookupsResponse(response))
    }

    /**
     * method to handle inventory lookups response
     */
    private fun handleLookupsResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "get Empty locationLookupsResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "get empty Location Lookups Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    var cycleCount: MutableLiveData<CycleCount> = MutableLiveData()
    var cycleCountDetails: MutableLiveData<CycleCountDetails> = MutableLiveData()
    private var ccTaskDetails: CCTaskDetails? = null
    private var taskGroupCodeOptions: MutableLiveData<ArrayList<String>> = MutableLiveData()
    private var taskGroupsList: MutableLiveData<ArrayList<TaskGroup>> = MutableLiveData()
    var itemData: Item? = null
    private var locationDetails: MutableLiveData<Location> = MutableLiveData()
    var containerDetails: Container? = null
    private var numberOfPallets: Int = 0
    private var totalPalletCount: Int = 0
    private var palletNumbersList: ArrayList<String> = ArrayList()
    var ccTrackingDetails : CycleCountTrackingDetails = CycleCountTrackingDetails()
    var emptyLocationLookup : Boolean = false
    var isContainerEmpty : Boolean = false
    var isLocationEmpty : Boolean = false
    private var allLPNList: ArrayList<CCByPalletContainerIdDetails> = ArrayList()
    var inputLPNList: ArrayList<CCByPalletContainerIdDetails> = ArrayList()
    var isQuantityEnabled = true
    var locationId = 0
    var mIsQuantityMismatch = false
    var mIsLocationMismatch = false
    var containerId = 0L

    fun getcycleCount(): CycleCount {
        return cycleCount.value!!
    }

    fun setcycleCount(cycleCount: CycleCount) {
        this.cycleCount.value = cycleCount
    }

    fun getCycleCountDetails(): CycleCountDetails {
        return cycleCountDetails.value!!
    }

    fun setCycleCountUDTaskDetails(ccTaskDetails: CCTaskDetails) {
        this.ccTaskDetails = ccTaskDetails
    }

    fun getCycleCountUDTaskDetails(): CCTaskDetails? {
        return ccTaskDetails
    }

    fun setCycleCountDetails(cycleCountDetails: CycleCountDetails) {
        this.cycleCountDetails.value = cycleCountDetails
    }

    fun gettaskGroupCodeOptions(): ArrayList<String>? {
        return taskGroupCodeOptions.value
    }

    fun settaskGroupOptions(taskGroupOptions: ArrayList<String>) {
        this.taskGroupCodeOptions.value = taskGroupOptions
    }

    fun getTaskGroupsList(): ArrayList<TaskGroup>? {
        return taskGroupsList.value
    }

    fun setTaskGroupsList(taskGroups: ArrayList<TaskGroup>) {
        this.taskGroupsList.value = taskGroups
    }

    fun getItem(): Item {
        return itemData!!
    }

    fun getItemDetail(): Item? {
        return itemData
    }

    fun setItem(item: Item?) {
        this.itemData = item
    }

    fun getLocationDetails(): Location {
        return locationDetails.value!!
    }

    fun setLocationDetails(locationDetails: Location) {
        this.locationDetails.value = locationDetails
    }

    fun getContainer(): Container? {
        return containerDetails
    }

    fun setContainer(container: Container) {
        this.containerDetails = container
    }

    fun cycleCountTaskForLocation(locationId: Int , status:String, responseFilter:String) = viewModelScope.launch {
        cycleCountForLocationResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.cycleCountTaskForLocation(locationId,status,responseFilter)
        cycleCountForLocationResponse.postValue(handleCycleCountForLocation(response))
    }

    fun cycleCountTaskForLocationPending(status:String, responseFilter:String, taskType: String) = viewModelScope.launch {
        cycleCountForLocationResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.cycleCountTaskForLocationPending(status, responseFilter, taskType)
        cycleCountForLocationResponse.postValue(handleCycleCountForLocation(response))
    }

    fun cycleCountTaskAssign(locationId: Int) = viewModelScope.launch {
        ccTaskAssignResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.cycleCountTaskAssignUpdate(locationId)
        ccTaskAssignResponse.postValue(handleCycleCountTaskAssign(response))
    }

    private fun handleCycleCountTaskAssign(response: Response<CycleCountTaskDetailResponse>): Resource<CycleCountTaskDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CycleCountForLocation Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CycleCountForLocation Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleCycleCountForLocation(response: Response<CCTaskDetailsResponse>): Resource<CCTaskDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CycleCountForLocation Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CycleCountForLocation Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateLocation(locationClassReq: CCByLocationInEachesLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "LocationDetails Request: $locationClassReq")
        validateCCLocationResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validationLocation(locationClassReq)
        validateCCLocationResponse.postValue(handleValidateLocationResponse(response))
    }

    private fun handleValidateLocationResponse(response: Response<CCByLocationInEachesLocationResponse>): Resource<CCByLocationInEachesLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationDetails Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateCCContainer(ccByLocationInEachesContainerRequest: CCByLocationInEachesContainerRequest,ccHeaderId:String) = viewModelScope.launch {

        if(ccByLocationInEachesContainerRequest.palletNbr.isNullOrEmpty()) {
            ccByLocationInEachesContainerRequest.palletNbr = null
        }

        FlareLog.i(TAG, "Validate Container Request: $ccByLocationInEachesContainerRequest")
        validateCCContainerResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateCCContainer(ccByLocationInEachesContainerRequest,ccHeaderId)
        validateCCContainerResponse.postValue(handleValidateCCContainerResponse(response))
    }

    private fun handleValidateCCContainerResponse(response: Response<CCByLocationInEachesContainerResponse>): Resource<CCByLocationInEachesContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Validate Container Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Validate Container Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateCCQty(ccByLocationInEachesQtyRequest: CCByLocationInEachesQtyRequest,ccHeaderId:String) = viewModelScope.launch {
        FlareLog.i(TAG, "Validate Qty Request: $ccByLocationInEachesQtyRequest")
        validateCCQtyResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateCCQty(ccByLocationInEachesQtyRequest,ccHeaderId)
        validateCCQtyResponse.postValue(handleValidateQtyResponse(response))
    }

    private fun handleValidateQtyResponse(response: Response<CCByLocationInEachesQtyResponse>): Resource<CCByLocationInEachesQtyResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Validate Qty Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Validate Qty Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun endSummaryLevelCycleCount(ccMode:String, ccByLocationInEachesEndCCReq: CCByLocationInEachesEndCCRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "End Summary Level Cycle Count Request: ${getCCHeaderId()}")
        endSummaryLevelCycleCountResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.endSummaryLevelCycleCount(getCCHeaderId().toString(), ccMode, ccByLocationInEachesEndCCReq)
        endSummaryLevelCycleCountResponse.postValue(handleEndSummaryLevelCycleCountResponse(response))
    }

    private fun handleEndSummaryLevelCycleCountResponse(response: Response<CCByLocationInEachesEndCycleCountResponse>): Resource<CCByLocationInEachesEndCycleCountResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "End Summary Level Cycle Count Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = viewModelScope.launch {
        FlareLog.i(TAG, "validateUPCorSLP Request: itemCode: $itemCode , upcOrSlp: $upcOrSlp")
        upcOrSlpResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.validateUPCorSLP(itemCode, upcOrSlp)
        upcOrSlpResponse.postValue(handleValidateUPCorSLP(response))
    }

    fun getItemsForLocation(locationBarcode: String) = viewModelScope.launch {
        locationByItemIdsInquiryResponse.postValue(Resource.Loading())
        locationByItemIdList = emptyList()
        val response = cycleCountRepository.getItemDetailByLocationBarcode(locationBarcode)
        locationByItemIdsInquiryResponse.postValue(parseLocationInquiryResponse(response))
    }


    private fun parseLocationInquiryResponse(response: Response<RlogLocationInquiryResp>): Resource<Boolean>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "locationByItemIdsInquiryResponse : $resultResponse")
                if (!resultResponse.locationDetails.isNullOrEmpty()) {
                    locationByItemIdList =
                        resultResponse.locationDetails.filter { !it.scnItmId.isNullOrEmpty() }
                            .groupBy { it.scnItmId }.keys.toList()
                    return Resource.Success(true)
                } else {
                    return Resource.Success(false)
                }
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "locationByItemIdsInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null

    }

    private fun handleValidateUPCorSLP(response: Response<UpcOrSlpResponse>): Resource<UpcOrSlpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateUPCorSLP Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateUPCorSLP Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getCountriesLookUps(lookUpsRequest: LookUpsRequest) = viewModelScope.launch {
        countriesLookUpResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getLookUps(lookUpsRequest)
        countriesLookUpResponse.postValue(handleCountriesLookUpResponse(response))
    }

    private fun handleCountriesLookUpResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getCountriesLookUps Success : $resultResponse")

                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getCountriesLookUps Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setNoOfPallets(numberOfPallets: Int) {
        this.numberOfPallets = numberOfPallets
    }

    fun getNoOfPallets(): Int {
        return numberOfPallets
    }

    fun getPalletNumberList(): ArrayList<String> {
        return palletNumbersList
    }

    fun setPalletNumberList(palletNumber : String) {
        palletNumbersList.add(palletNumber)
    }

    fun setExpectedPalletCount(count: Int) {
        totalPalletCount = count
    }

    fun getExpectedCount(): Int {
        return totalPalletCount
    }

    fun getSerialList(): ArrayList<String> {
        return ccTrackingDetails.serialNumbers
    }

    fun getSavedLPNList(): ArrayList<CCByPalletContainerIdDetails> {
        return inputLPNList
    }

    fun saveInputLPNList(lpnList:CCByPalletContainerIdDetails)  {
        inputLPNList.add(lpnList)
    }

    fun resetValues() {
        isQuantityEnabled = false
        inputLPNList.clear()
        allLPNList.clear()
        totalPalletCount = 0
        numberOfPallets = 0

        // Cycle Count By Location
        ccLocationBarcode = ""
    }

    /******************** Cycle Count By Location *****************************/

    private var ccItemBarCode = ""
    private var ccItemId = 0
    private var ccItemDesc = ""
    private var palletNumber = ""
    private var caseNumber = ""
    var ccHeaderId = 0
    var ccEachesContainerId = 0
    var ccEachesItemId = 0
    var ccEachesPalletId = 0
    var overrideContainer = false
    var overridePallet = false

    fun setCCItemDesc(value:String) {
        ccItemDesc = value
    }

    fun getCCItemDesc():String {
        return ccItemDesc
    }

    fun setCCItemBarcode(value:String) {
        ccItemBarCode = value
    }

    fun getCCItemBarcode():String {
        return ccItemBarCode
    }

    fun setCCItemId(value:Int) {
        ccItemId = value
    }

    fun getCCItemId():Int {
        return ccItemId
    }

    fun getCCPalletNumber():String {
        return palletNumber
    }

    fun setCCPalletNumber(palletNumber: String) {
        this.palletNumber = palletNumber
    }

    fun getCCCaseNumber():String {
        return caseNumber
    }

    fun setCCCaseNumber(caseNumber: String){
        this.caseNumber = caseNumber
    }

    private var ccLocationBarcode = ""

    fun setCCLocationBarcode(ccLocationBarcode:String){
        this.ccLocationBarcode = ccLocationBarcode
    }

    fun getCCLocationBarcode():String{
        return ccLocationBarcode
    }

    fun getCCHeaderId(): Int {
        return ccHeaderId
    }

    fun setCCHeaderId(ccHeaderId: Int){
        this.ccHeaderId = ccHeaderId
    }

    fun resetCCLocationEachesData(){
        setCCHeaderId(0)
        setCCPalletNumber("")
        setCCCaseNumber("")
        setCCLocationBarcode("")
        setCCItemId(0)
        setCCItemBarcode("")
        setCCItemDesc("")
        ccEachesContainerId = 0
        ccEachesPalletId = 0
        ccEachesItemId = 0
    }

    fun getCountPendingContainers(locationId: Int, ccHeaderId: Int, itemId: Int, lotNumber: String?, invType: String?, palletNbr: String?, palletId: Int?, palletLocationId: Int?)= viewModelScope.launch {
        countPendingResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.getCountPendingContainers(locationId,ccHeaderId, itemId, lotNumber, invType, palletNbr,palletId, palletLocationId)
        countPendingResponse.postValue(handleCountPendingResponse(response))
    }

    private fun handleCountPendingResponse(response: Response<CountPendingResponse>): Resource<CountPendingResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "countPendingResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "countPendingResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun updateVirtualContainersCount(updateVirtualContainersCountRequest: UpdateVirtualContainersCountRequest)= viewModelScope.launch {
        updateVirtualContainersCountResponse.postValue(Resource.Loading())
        val response = cycleCountRepository.updateVirtualContainersCount(updateVirtualContainersCountRequest)
        updateVirtualContainersCountResponse.postValue(handleUpdateVirtualContainersCount(response))
    }

    private fun handleUpdateVirtualContainersCount(response: Response<UpdateVirtualContainersCountResponse>): Resource<UpdateVirtualContainersCountResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "updateVirtualContainersCountResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "updateVirtualContainersCount Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun createCycleCountDetails(cycleCountDetails: UpdateCycleCountDetailsRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "updateCycleCountDetails: $cycleCountDetails")
        createCycleCountDetails.postValue(Resource.Loading())
        val response = cycleCountRepository.createCycleCountDetails(cycleCountDetails)
        createCycleCountDetails.postValue(handleCreateCCDetailsResponse(response))
    }

    private fun handleCreateCCDetailsResponse(response: Response<CreateCycleCountDetailResponse>): Resource<CreateCycleCountDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CCDetailsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CCDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}