package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.replenishment.ReplenTaskCompleteRequest
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTaskResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenResponse
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

const val REPLENISH_DELIVERY_TASK_TYPE = "RDC"
private const val REPLENISH_DELIVERY_ALLOCATION_TYPE = "150"

interface ReplenishDeliveryRepository {

    suspend fun getReplenishDeliveryTasks(): Response<ReplenishDeliveryTaskResponse>

    suspend fun getReplenishTaskForContainer(container: String): Response<ReplenishDeliveryTaskResponse>

    suspend fun skipReplenishDeliveryTask(
        taskId: Int,
        taskDetailId: Int
    ): Response<ReplenishDeliveryTaskResponse>

    suspend fun completeReplenishTask(
        taskId: Int,
        containerNumber: String,
        destinationLoc: String
    ): Response<TaskReplenResponse>
}

class ReplenishDeliveryRepositoryImpl @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) : ReplenishDeliveryRepository {

    override suspend fun getReplenishDeliveryTasks(): Response<ReplenishDeliveryTaskResponse> {

        val taskRequest = TaskReplenRequest(
            allocationType = REPLENISH_DELIVERY_ALLOCATION_TYPE,
            taskGroup = REPLENISH_DELIVERY_TASK_TYPE,
            buId = "${sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        )

        return getDeliveryTask(taskRequest)
    }

    override suspend fun getReplenishTaskForContainer(container: String): Response<ReplenishDeliveryTaskResponse> {

        val taskRequest = TaskReplenRequest(
            allocationType = REPLENISH_DELIVERY_ALLOCATION_TYPE,
            taskGroup = REPLENISH_DELIVERY_TASK_TYPE,
            buId = "${sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNum = container
        )

        return getDeliveryTask(taskRequest)
    }

    private suspend fun getDeliveryTask(taskRequest: TaskReplenRequest) =
        apiGatewayInterface.getReplenishDeliveryTask(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, "")}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            replenPickTaskRequest = taskRequest
        )

    override suspend fun skipReplenishDeliveryTask(
        taskId: Int,
        taskDetailId: Int
    ) = apiGatewayInterface.skipReplenishTask(
           gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, "")}",
           userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
           fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
           buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
           custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
           allocationType = REPLENISH_DELIVERY_ALLOCATION_TYPE,
           skipTaskId = "$taskId",
           skipTaskDetId = "$taskDetailId"
       )

    override suspend fun completeReplenishTask(
        taskId: Int,
        containerNumber: String,
        destinationLoc: String
    ): Response<TaskReplenResponse> {
        return apiGatewayInterface.completeReplenishDelivery(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, "")}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            allocationType = REPLENISH_DELIVERY_ALLOCATION_TYPE,
            requestPayload = ReplenTaskCompleteRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskId = taskId,
                containerNum = containerNumber,
                scannedDestLocation = destinationLoc
            )
        )
    }
}