package com.fsc.flare.ui.fragment.casepicktopalletid

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.res.EndPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.SkipPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickActiveStagingRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.CasePickToPalletIDRepository
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SOMETHING_WENT_WRONG
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "CasePickToPalletIDViewModel"

@HiltViewModel
class CasePickToPalletIDViewModel @Inject constructor(
    private val casePickToPalletIDRepository: CasePickToPalletIDRepository,
    sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {

    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    val allocationType = "20"
    private var taskGroup:String = ""
    var givenCartonNbr: String? = null

    val palletDetailKey = "pallet"
    val ltlCubeTransParamsKey = "LTLCUBE"
    val shortPickTransParamsKey = "SHORTPICK"
    private var newPalletNumber = ""
    internal var stageLocationBarcode: String? = null
    private var isLTLCubingEnabled = false
    private val ltlCubeEnabledKey = 17
    val shortPickTransEnabledKey = 19

    // Single live event declaration
    private val _shortPickTransactionParam = SingleLiveEvent<Resource<TransactionParamResponse>>()
    private val _generateNewPallet = SingleLiveEvent<Resource<CaseTransferPalletGenerateResponse>>()
    private val _getAssignedTask = SingleLiveEvent<Resource<TaskPickResponse>>()
    private val _validatePallet = SingleLiveEvent<Resource<TaskPickResponse>>()
    private val _locationValidation = SingleLiveEvent<Resource<LocationClassRes>>()
    private val _skipCart = SingleLiveEvent<Resource<SkipPickCartRes>>()
    private val _taskCasePickComplete = SingleLiveEvent<Resource<TaskCasePickCompleteRes>>()
    private val _inventoryLocks = SingleLiveEvent<Resource<LookUps>>()
    private val _caseOverride = SingleLiveEvent<Resource<ValidatePalletOverrideResponse>>()
    private val _endCart = SingleLiveEvent<Resource<EndPickCartRes>>()
    private val _taskActivePickStaging = SingleLiveEvent<Resource<TaskPickActiveStagingRes>>()

    val taskGroupResponse: MutableLiveData<Resource<TaskGroupResponse>> = SingleLiveEvent()
    val serialItemIdValidationResponse: MutableLiveData<Resource<PickingSerialOrItemCodeResponse>> = SingleLiveEvent()
    val containerResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()


    // Live data initialization
    val shortPickTransactionParamResponse: LiveData<Resource<TransactionParamResponse>>
        get() = _shortPickTransactionParam

    val newPalletDetailResponse: LiveData<Resource<CaseTransferPalletGenerateResponse>>
        get() = _generateNewPallet

    val validateAssignedTaskResponse: LiveData<Resource<TaskPickResponse>>
        get() = _getAssignedTask

    val validatePalletResponse: LiveData<Resource<TaskPickResponse>>
        get() = _validatePallet

    val locationClassResponse: LiveData<Resource<LocationClassRes>>
        get() = _locationValidation

    val skipCartResponse: LiveData<Resource<SkipPickCartRes>>
        get() = _skipCart

    val inventoryLocksResponse: LiveData<Resource<LookUps>>
        get() = _inventoryLocks

    val caseOverrideResponse: LiveData<Resource<ValidatePalletOverrideResponse>>
        get() = _caseOverride

    val taskCasePickCompleteResponse: LiveData<Resource<TaskCasePickCompleteRes>>
        get() = _taskCasePickComplete
    val endCartResponse: LiveData<Resource<EndPickCartRes>>
        get() = _endCart

    val taskActivePickStagingResponse: LiveData<Resource<TaskPickActiveStagingRes>>
        get() = _taskActivePickStaging

    fun getLTLTransactionParam(transParamsKey: String) = viewModelScope.launch(dispatcher) {
        val response = casePickToPalletIDRepository.getTransactionParam(transParamsKey)
        handleLTLTransactionParamResponse(response)
    }

    private fun handleLTLTransactionParamResponse(response: Response<TransactionParamResponse>) {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                val noOfCases = resultResponse.noOfCases?.get(0)
                isLTLCubingEnabled = noOfCases?.transVal == ltlCubeEnabledKey
            }
        } else {
            isLTLCubingEnabled = false
        }
    }

    fun getShortPickTransactionParam(transParamsKey: String) = viewModelScope.launch(dispatcher) {
        _shortPickTransactionParam.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.getTransactionParam(transParamsKey)
        _shortPickTransactionParam.postValue(handleShortPickTransactionParamResponse(response))
    }

    private fun handleShortPickTransactionParamResponse(response: Response<TransactionParamResponse>): Resource<TransactionParamResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    // Generate new pallet API method
    fun generatePalletNumber() = viewModelScope.launch(dispatcher) {
        _generateNewPallet.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.generatePalletCaseNumber(palletDetailKey)
        _generateNewPallet.postValue(response?.let { handleGeneratePalletCaseNumberResponse(it) })
    }

    // Handle the generated pallet number response
    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validatePalletId(palletNumber: String, group:String = taskGroup) = viewModelScope.launch {
        setPalletNumber(palletNumber)
        _validatePallet.postValue(Resource.Loading())
        val taskPickReq = TaskPickCartReq(
            allocationType = allocationType,
            buId = buId.toString(),
            custId = custId,
            fcyId = fcyId,
            taskGroup = group,
            cartNumber = getPalletNumber(),
            isLTLcubing = null,
            orderId = null,
            casePickWithPallet = true
        )
        val palletIdResponse = casePickToPalletIDRepository.getTaskPick(taskPickReq)
        _validatePallet.postValue(handlePalletIdResponse(palletIdResponse))
    }

    fun checkAssignedTasks(group:String = taskGroup) = viewModelScope.launch {
        _getAssignedTask.postValue(Resource.Loading())
        val taskPickReq = TaskPickCartReq(
            allocationType = allocationType,
            buId = buId.toString(),
            custId = custId,
            fcyId = fcyId,
            taskGroup = group,
            orderId = null,
            isLTLcubing = null,
            casePickWithPallet = true
        )
        val palletIdResponse = casePickToPalletIDRepository.getTaskPick(taskPickReq)
        _getAssignedTask.postValue(handlePalletIdResponse(palletIdResponse))
    }

    private fun handlePalletIdResponse(response: Response<TaskPickResponse>): Resource<TaskPickResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validatePalletIdResponse Success:$resultResponse")
                stageLocationBarcode = resultResponse.stageLocationBarcode
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "validatePalletIdResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun pickEndCart(cartId: Int?) = viewModelScope.launch {
        _endCart.postValue(Resource.Loading())
        val endCartRequest = EndPickCartReq(
            allocationType = allocationType.toInt(),
            buId = buId,
            custId = custId,
            fcyId = fcyId,
            pickCartNbr = getPalletNumber(),
            cartId = cartId,
            casePickWithPallet = true
        )
        val endCartResponse = casePickToPalletIDRepository.pickEndCart(endCartRequest)
        _endCart.postValue(handleEndPickCartResponse(endCartResponse))
    }

    private fun handleEndPickCartResponse(response: Response<EndPickCartRes>): Resource<EndPickCartRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickEndCartResponse Success: $resultResponse")
                stageLocationBarcode = resultResponse.taskDetails?.stageLocationBarcode ?: ""
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "pickEndCart Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun buildSkipCart(skipTaskId: Int) = viewModelScope.launch {
        _skipCart.postValue(Resource.Loading())
        val skipCartResponse = casePickToPalletIDRepository.buildSkipCart(
            getPalletNumber(), skipTaskId.toString(), "", isLTLCubingEnabled
        )
        _skipCart.postValue(handleSkipCartResponse(skipCartResponse))
    }

    fun buildSkipLineItem(skipTaskId: Int, skipTaskDetId: Int) = viewModelScope.launch {
        _skipCart.postValue(Resource.Loading())
        val skipCartResponse = casePickToPalletIDRepository.buildSkipCart(
            getPalletNumber(), skipTaskId.toString(), skipTaskDetId.toString(), isLTLCubingEnabled
        )
        _skipCart.postValue(handleSkipCartResponse(skipCartResponse))
    }

    private fun handleSkipCartResponse(response: Response<SkipPickCartRes>): Resource<SkipPickCartRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickEndCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "pickEndCart Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun taskCasePickCompleteReq(
        taskQty: Int, expDate: String, lockCode: String, containerId: Int, containerNbr: String, serialNumbers: ArrayList<String>
    ) = viewModelScope.launch {
        val data = getPickTask()
        val taskData = getPickTaskDetails()
        taskCasePickComplete(
            TaskCasePickCompleteReq(
                allocationType = allocationType,
                buId = buId,
                cartNumber = data!!.cartNbr,
                cartId = data.cartId,
                containerId = containerId,
                containerNumber = containerNbr,
                fcyId = fcyId,
                custId = custId,
                itemCode = taskData!!.itemCode,
                itemDescription = taskData.itemDescription,
                itemId = taskData.itemId,
                pickQty = taskQty,
                pickQtyUom = taskData.taskQtyUom,
                taskDetId = taskData.taskDetId,
                taskId = taskData.taskId,
                lotNumber = taskData.lotNumber,
                expDate = expDate,
                reasonCode = lockCode,
                casePickWithPallet = true,
                givenCartonNbr = givenCartonNbr,
                serialNumbers = serialNumbers
            )
        )
        givenCartonNbr = null
    }

    private suspend fun taskCasePickComplete(taskCasePickCompleteReq: TaskCasePickCompleteReq) {
        _taskCasePickComplete.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.taskCasePickComplete(taskCasePickCompleteReq)
        _taskCasePickComplete.postValue(handleTaskCasePickCompleteResponse(response))
    }

    private fun handleTaskCasePickCompleteResponse(response: Response<TaskCasePickCompleteRes>): Resource<TaskCasePickCompleteRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskCasePickComplete Success: $resultResponse")
                stageLocationBarcode = resultResponse.stageLocationBarcode
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescription(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "taskCasePickComplete Error Response: $errorResponse")
        return Resource.Error(errorResponse)

    }

    fun validatePickLocation() = viewModelScope.launch {
        _locationValidation.postValue(Resource.Loading())
        val response = getPickTaskDetails()?.locationBarcode?.let {
            casePickToPalletIDRepository.validateStagingLocation(it)
        }
        _locationValidation.postValue(response?.let { handleLocationClassResponse(it) })
    }

    fun validateStageLocation(stageLocation: String) = viewModelScope.launch {
        _locationValidation.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.validateStagingLocation(stageLocation)
        _locationValidation.postValue(handleLocationClassResponse(response))
    }

    private fun handleLocationClassResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getInventoryReasonCodes() = viewModelScope.launch {
        _inventoryLocks.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.getInventoryReasonCodes()
        _inventoryLocks.postValue(response?.let { handleInventoryLocksResponse(it) })
    }

    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryLocksResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "InventoryLocksResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)

    }

    fun validateContainerOverride(containerId: String, taskDetId: Int?) = viewModelScope.launch {
        val request = ValidateCaseOverrideRequest(
            givenContainerNbr = containerId,
            taskDetId = taskDetId,
            custId = custId,
            fcyId = fcyId,
            buId = buId,
            casePickWithPallet = true
        )
        _caseOverride.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.validateContainerOverride(request)
        _caseOverride.postValue(handleValidateContainerOverride(response))
    }

    private fun handleValidateContainerOverride(response: Response<ValidatePalletOverrideResponse>): Resource<ValidatePalletOverrideResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handlevalidateContainerOverride Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorDescription(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "handlevalidateContainerOverride Error: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun taskActivePickStagingReq(stagingLocationId: Int) = viewModelScope.launch {
        val data = getPickTask()
        taskActivePickStaging(
            TaskPickActiveStagingReq(
                buId = buId,
                custId = custId,
                fcyId = fcyId,
                cartId = data!!.cartId,
                cartNumber = data.cartNbr,
                locationId = stagingLocationId,
                taskId = 0,
                allocationType = allocationType,
                casePickWithPallet = true
            )
        )
    }

    private suspend fun taskActivePickStaging(taskPickActiveStagingReq: TaskPickActiveStagingReq) {
        _taskActivePickStaging.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.taskActivePickStaging(taskPickActiveStagingReq)
        _taskActivePickStaging.postValue(handleTaskActivePickStagingResponse(response))
    }

    private fun handleTaskActivePickStagingResponse(response: Response<TaskPickActiveStagingRes>): Resource<TaskPickActiveStagingRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskActivePickStagingResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "TaskActivePickStaging Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getTaskGroups() = viewModelScope.launch {
        taskGroupResponse.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.getTaskGroups()
        taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskGroupsResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskGroupsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to validate serial number or itemcode API
     */
    fun validateSerialNumberOrItemCodeContainer(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        containerId: Int
    ) = viewModelScope.launch {
        serialItemIdValidationResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = casePickToPalletIDRepository.validateSerialNumberWithItemCode(serialNumberOrItemId, isOutBoundOnly,pickLocationId, itemId, containerId)
        serialItemIdValidationResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    /**
     * method to handle serial or Item id validation response
     */
    private fun handleSerialNumberOrItemIdValidationResponse(response: Response<PickingSerialOrItemCodeResponse>): Resource<PickingSerialOrItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to get container details
     */
    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = casePickToPalletIDRepository.getContainer(container, itemInfo)
        containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private var pickTask: MutableLiveData<TaskPickResponse> = MutableLiveData<TaskPickResponse>()
    private var pickTaskDetails: MutableLiveData<TaskDetails> = MutableLiveData<TaskDetails>()
    private var inventoryLocksList: MutableLiveData<List<Lookup>> = MutableLiveData()

    fun setTaskGroup(group:String){
        taskGroup = group
    }

    fun getPickTask(): TaskPickResponse? {
        return pickTask.value
    }

    fun setPickTask(pickTask: TaskPickResponse) {
        this.pickTask.value = pickTask
    }

    fun getPickTaskDetails(): TaskDetails? {
        return pickTaskDetails.value
    }

    fun setPickTaskDetails(pickTaskDetails: TaskDetails) {
        this.pickTaskDetails.value = pickTaskDetails
    }

    fun setPalletNumber(palletNumber: String) {
        newPalletNumber = palletNumber
    }

    fun getPalletNumber(): String {
        return newPalletNumber
    }

    fun getInventoryLocksList(): List<Lookup> {
        return inventoryLocksList.value!!
    }

    fun setInventoryLocksList(inventoryLocksList: List<Lookup>) {
        this.inventoryLocksList.value = inventoryLocksList
    }

    fun validateInputType(
        inputValue: String, containerType: CustomerContainerTypes.ContainerTypesEntity?
    ): Boolean {
        return containerType != null && (!inputValue.startsWith(containerType.ctyId!!) || inputValue.length != containerType.ctyContainerLength!!.toInt())
    }

    private val _fetchTaskState = MutableStateFlow<FetchTaskState?>(null)
    val fetchTaskState = _fetchTaskState.asStateFlow()

    fun refreshAssignedTask(scope: CoroutineScope = viewModelScope, palletNumber: String) {
        scope.launch {
            _fetchTaskState.emit(FetchTaskState.ShowProgress(show = true))
            setPalletNumber(palletNumber)
            val taskPickReq = TaskPickCartReq(
                allocationType = allocationType,
                buId = buId.toString(),
                custId = custId,
                fcyId = fcyId,
                taskGroup = taskGroup,
                cartNumber = getPalletNumber(),
                casePickWithPallet = true
            )
            val response = casePickToPalletIDRepository.getTaskPick(taskPickReq)
            _fetchTaskState.emit(FetchTaskState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                stageLocationBarcode = body()?.stageLocationBarcode
                body()?.let { setPickTask(it) }
                FlareLog.i(TAG, "validatePalletIdResponse Success:${body()}")
                when {
                    body()?.cartIsReadyToEnd == true -> {
                        _fetchTaskState.emit(FetchTaskState.StagePending(body()?.cartNbr.orEmpty()))
                    }

                    body()?.taskDetails != null -> {
                        _fetchTaskState.emit(FetchTaskState.TaskFetchSuccess)
                    }

                    else -> {
                        _fetchTaskState.emit(FetchTaskState.TaskFetchError(SOMETHING_WENT_WRONG))
                    }
                }
            } ?: run {
                val errorMessage = handleForwardErrorResponse(
                    response.code(),
                    response.errorBody(),
                    response.message()
                )
                FlareLog.e(TAG, "validatePalletIdResponse Error Response: $errorMessage")
                _fetchTaskState.emit(FetchTaskState.TaskFetchError(errorMessage))
            }
        }
    }

    fun clearData() {
        _fetchTaskState.value = null
    }
}

sealed class FetchTaskState {
    data class ShowProgress(val show: Boolean) : FetchTaskState()
    data object TaskFetchSuccess : FetchTaskState()
    data class TaskFetchError(val errorMessage: String) : FetchTaskState()
    data class StagePending(val cartNumber: String): FetchTaskState()
}