package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmItemAndQtyScanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.enableOrDisableField
import dagger.hilt.android.AndroidEntryPoint


private const val TAG = "InvmItemAndQtyScanFragment"

@AndroidEntryPoint
class InvmItemAndQtyScanFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private lateinit var binding: FragmentInvmItemAndQtyScanBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInvmItemAndQtyScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.location.text = sharedViewModel.sourceDetails.data?.currentLocNumber
        binding.item.enableOrDisableField(true)
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        binding.qtyErrResponse.text = null
        binding.qty.addTextChangedListener(afterTextChanged =  {
            val quantity = binding.qty.text.toString().trim()

            binding.qtyErrResponse.text = when {

                quantity.isNotEmpty() && quantity.toLong() <= 0 ->
                    getString(R.string.quantity_must_be_grater_than_0)

                quantity.isNotEmpty() && quantity.toLong() > (sharedViewModel.sourceDetails.data?.qty ?: 0L) ->
                    getString(R.string.quantity_not_more_than_actual_quantity)

                else ->
                    ""
            }
        })
    }

    private fun setTextChangedListener() {
        binding.item.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.itmErrResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun handleEnterKeyEvent() {
        binding.item.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        validateField()
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    fun validateField() {
        if (binding.item.isFocused && !binding.item.text.isNullOrEmpty()) {
            if (binding.item.text.toString().trim() == sharedViewModel.sourceDetails.data?.item) {
                binding.item.enableOrDisableField(false)
                binding.qty.enableOrDisableField(true)
                binding.itmErrResponse.text = null
            } else {
                binding.itmErrResponse.visibility = View.VISIBLE
                binding.itmErrResponse.text = getString(R.string.lbl_invalid_barcode)
                binding.qty.enableOrDisableField(false)
                binding.item.selectAll()
            }
        }
        if (binding.qty.isFocused && !binding.qty.text.isNullOrEmpty()) {
            val scannedItem = binding.item.text.toString()
            val enteredQty = binding.qty.text.toString().toLong()
            if (scannedItem.isEmpty()) {
                binding.itmErrResponse.text = getString(R.string.please_scan_the_item)
            } else {
                binding.itmErrResponse.text = null
                if (enteredQty > 0L && enteredQty <= (sharedViewModel.sourceDetails.data?.qty ?: 0L)) {
                    savaData(scannedItem, enteredQty)
                    if (enteredQty != sharedViewModel.sourceDetails.data?.qty && sharedViewModel.sourceDetails.data?.itemTracking?.serialNumberRequired == "4") {
                        getNavigationController().navigate(InvmItemAndQtyScanFragmentDirections.actionInvmItemAndQtyScanViewModeltToInvmSerialScanFragment())
                    } else {
                        getNavigationController().navigate(InvmItemAndQtyScanFragmentDirections.actionInvmItemAndQtyScanViewModeltToInvmReasonCodeSelectFragment())
                    }
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)

        binding.item.setText(scan?.barcode.toString())
        binding.item.text?.length?.let {
            binding.item.setSelection(it)
        }
        validateField()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun savaData(scannedItem: String, enteredQty: Long) {
        sharedViewModel.scannedItem = scannedItem
        sharedViewModel.setScannedQuantity(enteredQty.toInt())
    }
}