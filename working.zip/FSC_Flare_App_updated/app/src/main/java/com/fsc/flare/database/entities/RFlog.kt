package com.fsc.flare.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.fsc.flare.database.utils.LogLevel
import java.util.Date

@Entity(tableName = "rfLog")
data class RFlog(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "logId") val logId: Long = 0L,
    @ColumnInfo(name = "createdBy") val createdBy: String,
    @ColumnInfo(name = "createdOn") val createdOn: Date,
    @ColumnInfo(name = "uuid") val uuid: String,
    @ColumnInfo(name = "customerId") val customerId: Long,
    @ColumnInfo(name = "buId") val buId: Long,
    @ColumnInfo(name = "fcyId") val fcyId: Long,
    @ColumnInfo(name = "loginUser") val loginUser: Long,
    @ColumnInfo(name = "customerName") val customerName: String,
    @ColumnInfo(name = "fcyTimeZone") val fcyTimeZone: String,
    @ColumnInfo(name = "loginUserID") val loginUserID: Long,
    @ColumnInfo(name = "enrollmentType") val enrollmentType: String? = null,
    @ColumnInfo(name = "message") val message: String,
    @ColumnInfo(name = "logLevel") val logLevel: LogLevel
)