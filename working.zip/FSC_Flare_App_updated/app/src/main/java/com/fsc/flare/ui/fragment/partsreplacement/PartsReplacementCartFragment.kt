package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementTaskdetailsCartsBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.ui.fragment.partsreplacement.PartsReplacementCartFragmentDirections.Companion.actionPartsReplacementCartFragmentToPartsReplacementSourceLocationFragment
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.ACTION_TYPE_GET
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_GROUP_TNR
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_TYPE_REPAIR
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private val TAG = PartsReplacementCartFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementCartFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var partsReplacementCartsBinding: FragmentPartsReplacementTaskdetailsCartsBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementCartsBinding =
            FragmentPartsReplacementTaskdetailsCartsBinding.inflate(inflater, container, false)
        partsReplacementCartsBinding.lifecycleOwner = this
        return partsReplacementCartsBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addListeners()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        partsReplacementCartsBinding.etCartValue.doAfterTextChanged {
            partsReplacementCartsBinding.errResponse.text = null
        }

        partsReplacementCartsBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementCartsBinding.etCartValue)
                    if (partsReplacementCartsBinding.etCartValue.isFocused) {
                        createCart()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementCartsBinding.etCartValue.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementCartsBinding.etCartValue)
                createCart()
            }
            false
        }
    }

    private fun createCart() {
        val etCartValue = partsReplacementCartsBinding.etCartValue.text.toString().trim()
        if (etCartValue.isNotEmpty()) {
            partsReplacementCartsBinding.errResponse.text = null

            viewModel.getRepairTaskRf(
                GetRepairTaskRf(
                    partRunnerCart = etCartValue,
                    taskType = TASK_TYPE_REPAIR,
                    taskgroup = TASK_GROUP_TNR,
                    actionType = ACTION_TYPE_GET
                )
            )
        }
    }

    private fun subscribeObservers() {
        viewModel.getRepairTaskRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { moveTaskRfResponse ->
                        if(moveTaskRfResponse.success){
                            viewModel.setMoveTaskRfResponse(moveTaskRfResponse)
                            navigateToPartsReplacementCartFragment()
                            FlareLog.e(TAG, "getMoveTaskRfResponse : ${moveTaskRfResponse.toString()}")
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "getMoveTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        partsReplacementCartsBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementCartsBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementCartsBinding.etCartValue.setText(scan?.barcode.toString())
        partsReplacementCartsBinding.etCartValue.text?.length?.let {
            partsReplacementCartsBinding.etCartValue.setSelection(it)
        }
        createCart()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToPartsReplacementCartFragment() {
        val action = actionPartsReplacementCartFragmentToPartsReplacementSourceLocationFragment()
        findNavController().navigate(action)
    }

    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementCartsBinding.errResponse.text = errorMessage
        partsReplacementCartsBinding.etCartValue.requestFocus()
        partsReplacementCartsBinding.etCartValue.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementCartsBinding.etCartValue)
    }

}