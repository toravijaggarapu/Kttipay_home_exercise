package com.fsc.flare.ui.fragment.packing

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.kitting.Item
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.source.data.dto.kitting.KitItemResponse
import com.fsc.flare.source.data.dto.packing.res.CartonDetail
import com.google.android.material.textview.MaterialTextView

class PackItemAdapter(
    private var componentList: List<CartonDetail>
) : RecyclerView.Adapter<PackItemAdapter.ViewHolder>() {
    lateinit var context: Context


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvComponentName: MaterialTextView = itemView.findViewById(R.id.tvComponentName)
        var tvMinQty: MaterialTextView = itemView.findViewById(R.id.tvMinQty)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PackItemAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_kitting_component, parent, false)
        context = parent.context
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: PackItemAdapter.ViewHolder, position: Int) {
            holder.tvComponentName.text = componentList[position].itemCode
            holder.tvMinQty.text = componentList[position].pickedQty.toString().plus(" ").plus(componentList[position].pickedQtyUom)
    }

    override fun getItemCount(): Int {
        val size = componentList.size
        return size
    }

}