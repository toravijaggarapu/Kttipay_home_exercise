package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.packout.req.PackOutGetReq
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.item.UomConversion
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutFragment"
private const val IN_PROGRESS_WO_STATUS = 120
private const val COMPLETED_WO_STATUS = 125
@AndroidEntryPoint
class PackoutFragment : BaseFragment(), FlareScannable {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutLocationBinding
    lateinit var cb1: CustomVisibilityCallback
    var containerInquiryRes: ContainerInventoryInquiryResponse? = null

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        viewModel.tempLpnsList.clear()
        viewModel.setDefaultPrinter(null)
        viewModel.printRequestorDescList = arrayListOf()
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callPIATransactionParamAPI()
    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.etLocationRes.text = ""
            }
        })

        binding.etLocation.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etLocation)
        if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Location field focused")
            validateLocation()
        }
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeLocationObserver()
        subscribeTransactionParamObserver()
        subscribePIATransactionParamObserver()
        subscribeDekkittingObserver()
    }

    /**
     * method to validate location
     */
    private fun validateLocation() {
        viewModel.validateLocationId(
            PackOutGetReq(
                facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                barcode = binding.etLocation.text.toString(),
                itemInfo = 1,
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            )
        )
    }

    /**
     * method to observe location response
     */
    private fun subscribeLocationObserver() {
        viewModel.validateLocIdResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success) {

                            if(response.locations.isEmpty()) {
                                binding.etLocationRes.text = getString(R.string.invalid_location)
                            }
                            else {
                                val location = response.locations[0]
                                if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) {
                                    if (location.lockCode == "CC") {
                                        binding.etLocationRes.text = getString(R.string.cycle_count_in_progress_for_given_location)
                                    } else {
                                        if (location.classification != null && (location.classification == "A" || location.classification == "KT")) {
                                            viewModel.isKitting = location.classification == "KT"
                                            if (location.items != null) {
                                                viewModel.setLocationData(response)
                                                viewModel.setFlag(1)
                                                viewModel.settransIdentifier("")
                                                viewModel.setLocId(response.locations[0].locationId)
                                                viewModel.setItemId(0)
                                                viewModel.setLocationBarcode(response.locations[0].locationBarcode)
                                                viewModel.setItemBarcode(response.locations[0].items[0].itemBarCode)
                                                viewModel.setSerialNumberList(arrayListOf())
                                                viewModel.setItemUomConversion(response.locations[0].items[0].uomConversions)
                                                if (viewModel.isKitting) {
                                                    callToCheckWorkOrderStatus(location.locationId)
                                                } else {
                                                    viewModel.getInquiryContainer(response.locations[0].locationBarcode)
                                                }
                                                checkPalletLevelItemUOMConfiguration(response.locations[0].items[0].uomConversions)
                                            } else {
                                                binding.etLocationRes.text = getString(R.string.packout_no_items_found_for_location)
                                            }
                                        } else {
                                            binding.etLocationRes.text = getString(R.string.invalid_location)
                                        }
                                    }
                                } else {
                                    if (location.cycleCountPending == "Y") {
                                        binding.etLocationRes.text = getString(R.string.cycle_count_is_pending_for_given_location)
                                    } else {
                                        if (location.classification != null && (location.classification == "A" || location.classification == "KT")) {
                                            viewModel.isKitting = location.classification == "KT"
                                            if (location.items != null) {
                                                viewModel.setLocationData(response)
                                                viewModel.setFlag(1)
                                                viewModel.settransIdentifier("")
                                                viewModel.setLocId(response.locations[0].locationId)
                                                viewModel.setItemId(0)
                                                viewModel.setLocationBarcode(response.locations[0].locationBarcode)
                                                viewModel.setItemBarcode(response.locations[0].items[0].itemBarCode)
                                                viewModel.setSerialNumberList(arrayListOf())
                                                if (viewModel.isKitting) {
                                                    callToCheckWorkOrderStatus(location.locationId)
                                                } else {
                                                    viewModel.getInquiryContainer(response.locations[0].locationBarcode)
                                                }
                                                checkPalletLevelItemUOMConfiguration(response.locations[0].items[0].uomConversions)
                                            } else {
                                                binding.etLocationRes.text = getString(R.string.packout_no_items_found_for_location)
                                            }
                                        } else {
                                            binding.etLocationRes.text = getString(R.string.invalid_location)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { containerInquiryResponse ->
                        if (containerInquiryResponse != null && containerInquiryResponse.success) {
                            FlareLog.i(TAG, "locationInfoWithInventoryCountCallResponse success: $containerInquiryResponse")
                            if (containerInquiryResponse.success && containerInquiryResponse.containers!!.isNotEmpty()) {
                                containerInquiryRes = containerInquiryResponse
                                callToGetTempLpns(viewModel.getLocId().toLong())
                            } else {
                                binding.etLocationRes.text = getString(R.string.packout_no_items_found_for_location)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "LocationInvCountResponse error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.LpnsInTempTableResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { TempLpnsResponse ->
                        if (TempLpnsResponse != null && TempLpnsResponse.success) {
                            FlareLog.i(TAG, "LpnsInTempTableResponse success: $TempLpnsResponse")
                            if(TempLpnsResponse.transactionIdentifier != null && TempLpnsResponse.transactionIdentifier != 0L ){
                                viewModel.settransIdentifier(TempLpnsResponse.transactionIdentifier.toString())
                            }
                            viewModel.existingPallet = TempLpnsResponse.palletNumber
                            if(TempLpnsResponse.containerDetails != null){
                                viewModel.tempLpnsList.addAll(TempLpnsResponse.containerDetails)
                            }
                            val containerList = if (containerInquiryRes != null) containerInquiryRes?.containers!!.filter { (it.containerStatus == "20" || it.containerStatus == "35") } else null
                            if (!containerList.isNullOrEmpty() || viewModel.tempLpnsList.isNotEmpty() || viewModel.isKitting){
                                callTransactionParamAPI()
                            } else {
                                binding.etLocationRes.text = getString(R.string.packout_from_active_no_inventory_found)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "LpnsInTempTableResponse error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.workOrderStatusResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { response ->
                        if (response != null && response.success) {
                            FlareLog.i(TAG, "workOrderStatusResponse success: $response")
                            val workOrderStatus = listOf(IN_PROGRESS_WO_STATUS, COMPLETED_WO_STATUS)
                            if(!workOrderStatus.contains(response.workOrder.workOrderStatus)){
                                binding.etLocationRes.text =  getString(R.string.work_order_is_not_having_a_valid_status_to_do_packout)
                            }
                            else{
                                callToGetTempLpns(viewModel.getLocId().toLong())
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "workOrderStatusResponse error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


    }

    private fun callToCheckWorkOrderStatus(kitLocationId: Int) {
        viewModel.getWorkOrderStatus(kitLocationId)
    }

    private fun checkPalletLevelItemUOMConfiguration(uomConversions : List<UomConversion>?) {
        val configuredUoms = uomConversions?.map { it.toUOM }
        if(configuredUoms!!.contains("PL")) {
            val palletUomDetailsList = uomConversions.filter { it.toUOM == "PL" && it.qtyUOM == "CS" || it.toUOM == "PL" && it.qtyUOM == "EA"}
            viewModel.ispalletUomConfigured = palletUomDetailsList.isNotEmpty()
            if (viewModel.ispalletUomConfigured) {
                viewModel.caseQtyForPallet = palletUomDetailsList[0].conversionRate
            }
        } else {
            viewModel.ispalletUomConfigured = false
        }
    }

    private fun callToGetTempLpns(LocationId : Long) {
        viewModel.getLpnsInTempTable(LocationId)
    }

    /**
     * method to get transaction param from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                trans_code = "PPC"
            )
        )
    }

    /**
     * method to get transaction param from API for Param item attributes
     */
    private fun callPIATransactionParamAPI() {
        viewModel.promptItemAttribute = false
        viewModel.getPIATransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                trans_code = "PIA"
            )
        )
    }

    /**
     * method to observe transaction param response
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.validateTransactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success) {
                            if (response.noOfCases != null && response.noOfCases.isNotEmpty()) {
                                val noOfCaseData = response.noOfCases[0]
                                if (noOfCaseData.transVal != null) {
                                    viewModel.setTpData(noOfCaseData.transVal)
                                    if (noOfCaseData.transVal == viewModel.palletizeCartonsTransValue && viewModel.existingPallet.isNullOrEmpty()) {
                                        viewModel.setFlag(1)
                                        navigateToPalletFragment = true
                                    } else {
                                        if(!viewModel.existingPallet.isNullOrEmpty()){
                                            viewModel.setPalletReqNumber(viewModel.existingPallet!!)
                                            navigateToPalletFragment = false
                                        }else{
                                            viewModel.setPalletReqNumber("")
                                            navigateToPalletFragment = false
                                        }
                                    }
                                    checkDekkitting()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParam Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeDekkittingObserver() {
        viewModel.dekitPackoutResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { dekitPackoutResponse ->
                        if (dekitPackoutResponse.success && dekitPackoutResponse.workOrderType != null && dekitPackoutResponse.workOrderType == "U") {

                            viewModel.isDekitting = true

                            if (!dekitPackoutResponse.deKitItems.isNullOrEmpty()) {
                                viewModel.dekitItems = dekitPackoutResponse.deKitItems.toMutableList()
                            }

                        } else {
                            dekitPackoutResponse.message?.let { message ->
                                FlareLog.e(TAG, "dekitPackoutResponse error: $message")
                            }
                        }
                        handleNavigation()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "dekitPackoutResponse error: $message")
                    }
                    handleNavigation()
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun checkDekkitting() {
        viewModel.clearKittingData()
        var locationId = viewModel.getKitLocationId()
        if (locationId > 0) {
            viewModel.deKitPackout(locationId)
        } else {
            handleNavigation()
        }
    }

    fun handleNavigation(){
        if(navigateToPalletFragment){
            navigateToPalletFragment()
        }
        else {
            navigateToCartonFragment()
        }
    }

    var navigateToPalletFragment = true;

    fun navigateToPalletFragment(){
        val action = PackoutFragmentDirections.actionPackoutLocationFragementToPackoutPalletFragement()
        getNavigationController().navigate(action)
    }

    fun navigateToCartonFragment(){
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackoutFragmentDirections.actionPackoutLocationFragementToPackoutCartonFragement()
        navController.navigate(action)
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribePIATransactionParamObserver() {
        viewModel.transactionPIAParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (transactionParamResponse.noOfCases != null && transactionParamResponse.noOfCases.isNotEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                viewModel.promptItemAttribute = noOfCases.transValDesc.equals("Prompt Item Attributes", true)
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                viewModel.promptItemAttribute = false
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        showErrorSnackBar(message)
                        viewModel.promptItemAttribute = false
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etLocation.setText(scan?.barcode.toString())
                binding.etLocation.text?.length?.let {
                    binding.etLocation.setSelection(it)
                }
                FlareLog.i(TAG, "location field focused")
                validateLocation()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}