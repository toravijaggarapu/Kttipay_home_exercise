package com.fsc.flare.ui.fragment.picking

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.BuildConfig
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.picking.*
import com.fsc.flare.source.repository.PickingRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PickingViewModel"

@HiltViewModel
class PickingViewModel @Inject constructor(
    private val pickingRepository: PickingRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val pickingWeightResponse: MutableLiveData<Resource<PickingWeightResponse>> = MutableLiveData()
    val pickingValidateBlResponse: MutableLiveData<Resource<PickingValidateBlResponse>> = MutableLiveData()
    val pickingValidateLocationResponse: MutableLiveData<Resource<PickingValidateLocationResponse>> = MutableLiveData()
    val pickingValidateLocationToResponse: MutableLiveData<Resource<PickingValidateLocationResponse>> = MutableLiveData()
    val pickingValidateContainerIdResponse: MutableLiveData<Resource<PickingValidateContainerIdResponse>> = MutableLiveData()
    val pickingValidateSubmitResponse: MutableLiveData<Resource<PickingSubmitResponse>> = MutableLiveData()
    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()

    fun getWeightReq() = viewModelScope.launch {
        try {
            pickingWeightResponse.postValue(Resource.Loading())
            val url = BuildConfig.GATEWAY_URL + "rlog/api/v1/picking/weightReq/" + sharedPreferences.getInt(
                PreferenceKeys.FACILITY_ID,
                -1
            ) + "/" + sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            FlareLog.i(TAG, "getWeightReq: $url")
            val response = pickingRepository.getWeightReq(url)
            pickingWeightResponse.postValue(handlePickingWeightResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handlePickingWeightResponse(response: Response<PickingWeightResponse>): Resource<PickingWeightResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PickingWeightResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "PickingWeightResponse Error: $errorResponse")
        return Resource.Error(response.message())
    }

    fun isValidBl(pickingValidateBlRequest: PickingValidateBlRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "isValidBl Request: $pickingValidateBlRequest")
        try {
            pickingValidateBlResponse.postValue(Resource.Loading())
            FlareLog.i(TAG, "isValidBl: $pickingValidateBlRequest")
            val response = pickingRepository.isValidBlReq(pickingValidateBlRequest)
            pickingValidateBlResponse.postValue(handleValidateBlResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleValidateBlResponse(response: Response<PickingValidateBlResponse>): Resource<PickingValidateBlResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateBlResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ValidateBlResponse Error: $errorResponse")
        return Resource.Error(response.message())
    }

    fun isValidLocation(pickingValidateLocationRequest: PickingValidateLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "isValidLocation Request: $pickingValidateLocationRequest")
        try {
            pickingValidateLocationResponse.postValue(Resource.Loading())
            val response = pickingRepository.isValidLocationReq(pickingValidateLocationRequest)
            pickingValidateLocationResponse.postValue(handleValidateLocationResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleValidateLocationResponse(response: Response<PickingValidateLocationResponse>): Resource<PickingValidateLocationResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateLocationResponse:$resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ValidateLocationResponse Error: $errorResponse")
        return Resource.Error(response.message())
    }

    fun isValidContainerId(pickingValidateContainerIdRequest: PickingValidateContainerIdRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "isValidContainerId Request: $pickingValidateContainerIdRequest")
        try {
            pickingValidateContainerIdResponse.postValue(Resource.Loading())
            val response = pickingRepository.isValidContainerIdReq(pickingValidateContainerIdRequest)
            pickingValidateContainerIdResponse.postValue(handleValidateContainerIdResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleValidateContainerIdResponse(response: Response<PickingValidateContainerIdResponse>): Resource<PickingValidateContainerIdResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateContainerIdResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ValidateContainerIdResponse Error: $errorResponse")
        return Resource.Error(response.message())
    }

    fun isValidPickSubmit(pickingSubmitRequest: PickingSubmitRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "isValidPickSubmit Request: $pickingSubmitRequest")
        try {
            pickingValidateSubmitResponse.postValue(Resource.Loading())
            val response = pickingRepository.isValidPickSubmitReq(pickingSubmitRequest)
            pickingValidateSubmitResponse.postValue(handleValidatePickingSubmitResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleValidatePickingSubmitResponse(response: Response<PickingSubmitResponse>): Resource<PickingSubmitResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidatePickingSubmitResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ValidatePickingSubmitResponse Error: $errorResponse")
        return Resource.Error(response.message())
    }

    fun isValidLocationTo(pickingLocationToRequest: PickingLocationToRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "isValidLocationTo Request: $pickingLocationToRequest")
        try {
            pickingValidateLocationToResponse.postValue(Resource.Loading())
            val response = pickingRepository.isValidLocationTo(pickingLocationToRequest)
            pickingValidateLocationToResponse.postValue(handleValidateLocationResponse(response))
        } catch (e: Exception) {
            FlareLog.e(TAG, "Connection Issue:${e.message.toString()}")
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e(TAG, "No Network connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }
}