package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.PickLocationFragmentBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.taskgroup.GroupTask
import com.fsc.flare.source.data.dto.taskgroup.getTaskPickModel
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.casepicktopalletid.CasePickToPalletIDViewModel
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.END_PALLET_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_TASKS_FOUND
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.SKIP_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.TASK_FETCH_API_ERROR
import com.fsc.flare.utils.getNavigationResult
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import java.lang.Exception
import javax.inject.Inject

@AndroidEntryPoint
class CaseCountPickLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var alertHandler: AlertHandler

    private val sharedViewModel: PickCaseByCountSharedViewModel by activityViewModels()
    private val existingViewModel: CasePickToPalletIDViewModel by activityViewModels()
    private val viewModel: CaseCountPickLocationViewModel by viewModels()

    private lateinit var binding: PickLocationFragmentBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = PickLocationFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeFlowOnUI { screenState() }
        sharedViewModel.palletInfo?.let { viewModel.getGroupTaskData(pallet = it) }
        observeSkipTaskResults()
    }

    private fun observeSkipTaskResults() {
        getNavigationResult<GroupTask>(NEXT_TASK_DATA_ARGUMENT) {
            updateTaskDataOnUI(it)
        }
    }

    private suspend fun screenState() {
        viewModel.screenState.filterNotNull().collect { state ->
            when(state) {
                is CaseCountFlowState.ShowProgress -> {
                    binding.incProgressBar.progressLoading.visibility = if (state.show) View.VISIBLE else View.GONE
                    binding.tvErrorMessage.text = null
                }

                is CaseCountFlowState.GroupTaskData -> {
                    updateTaskDataOnUI(state.groupTask)
                }

                is CaseCountFlowState.StagePending -> {

                    //==========UPDATE EXISTING FLOW VIEW MODEL DATA============
                    existingViewModel.stageLocationBarcode = state.stageLocation
                    existingViewModel.setPalletNumber(state.cartNumber)
                    sharedViewModel.groupTask?.let {
                        existingViewModel.setPickTask(
                            getTaskPickModel(
                                palletInfo = sharedViewModel.palletInfo,
                                state.stageLocation
                            )
                        )
                    }
                    //==========UPDATE EXISTING FLOW VIEW MODEL DATA============

                    alertHandler.showSimpleAlert(
                        message = getString(R.string.stage_pending_pallet_message, state.cartNumber),
                        buttonTitle = getString(R.string.stage)
                    ) {
                        val action = CaseCountPickLocationFragmentDirections.actionCasePickLocationToPalletStageScreen()
                        findNavController().navigate(action)
                    }
                }

                is CaseCountFlowState.ShowError -> {
                    handleError(state)
                }

                CaseCountFlowState.EndWithEmptyPallet -> {
                    val action = CaseCountPickLocationFragmentDirections.actionCasePickLocationToPalletId()
                    findNavController().navigate(action)
                }
            }
        }
    }

    private suspend fun handleError(error: CaseCountFlowState.ShowError) {
        when (error.errorCode) {
            TASK_FETCH_API_ERROR -> {
                showErrorAndMoveBack(errorMessage = error.errorMessage ?: getString(R.string.lbl_something_went_wrong))
            }

            NO_TASKS_FOUND -> {
                showErrorAndMoveBack(getString(R.string.no_task_available))
            }

            SKIP_API_ERROR,
            END_PALLET_API_ERROR -> {
                showErrorSnackBar(message = error.errorMessage ?: getString(R.string.lbl_something_went_wrong))
            }
        }
    }

    private suspend fun showErrorAndMoveBack(errorMessage: String) {
        binding.grpTaskView.visibility = View.GONE
        showErrorSnackBar(errorMessage, showMessageExtraLong = true)
        delay(3000)
        findNavController().popBackStack()
    }

    private fun updateTaskDataOnUI(task: GroupTask) {
        sharedViewModel.groupTask = task.copy()
        binding.grpTaskView.visibility = View.VISIBLE
        binding.tvShipment.text = task.shipmentNbr
        binding.tvStop.text = "${task.shipmentStopSeq}"
        binding.tvPalletId.text = task.cartNbr
        binding.tvItem.text = task.itemBarcode
        binding.tvDescription.text = task.itemDesc
        binding.tvPickLocation.text = task.pickLocBarcode
        binding.tvErrorMessage.text = null
        binding.etPickLocation.text = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initViews() {

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    super.onTouch(v, event)
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    navigateToCaseCountScreen(binding.etPickLocation.text.toString())
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnSkip.setOnClickListener {
            viewModel.skipTask()
        }

        binding.btnEndPallet.setOnClickListener {
            viewModel.endPallet()
        }

        binding.etPickLocation.doAfterTextChanged {
            val pickLocation = it.toString().trim()
            if (pickLocation.isEmpty() || pickLocation == sharedViewModel.pickLocationBarCode()) {
                binding.tvErrorMessage.text = null
            }
        }

        binding.etPickLocation.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE)
                navigateToCaseCountScreen(binding.etPickLocation.text.toString())

            false
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = it
            it.onVisibilityChange(true)
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        if (binding.incProgressBar.progressLoading.visibility == View.VISIBLE) return
        scan?.barcode.takeIf { it?.isNotEmpty() == true }?.let { barCode ->
            binding.etPickLocation.setText(barCode.trim())
            binding.etPickLocation.setSelection(barCode.length)
            Handler(Looper.getMainLooper()).postDelayed({
                navigateToCaseCountScreen(barCode)
            }, 1000)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        super.onScanError(scanRaw, ex)
        FlareLog.e(this::class.java.simpleName, "onScanError: $scanRaw")
    }

    private fun navigateToCaseCountScreen(pickLocation: String) {
        if (pickLocation.trim() == sharedViewModel.pickLocationBarCode()) {
            val action = CaseCountPickLocationFragmentDirections.actionCasePickLocationToEnterCaseCount()
            findNavController().navigate(action)
            binding.etPickLocation.text = null
        } else {
            binding.tvErrorMessage.text = if (pickLocation.trim().isNotEmpty())
                getString(R.string.lbl_invalid_pick_location)
            else
                null
            binding.etPickLocation.apply {
                setSelection(text?.length ?: 0)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        existingViewModel.clearData()
    }
}