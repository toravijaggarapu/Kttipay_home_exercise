package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryAsnBlindPalletNumberBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.asn.ASNRenamePalletRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryASNBlindPalletNumberFragment"

@AndroidEntryPoint
class InquiryASNBlindPalletNumberFragment : BaseFragment() {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryAsnBlindPalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback
    var isNewPallet = false
    var renamePalletRequest: ASNRenamePalletRequest? = null
    var newPalletNumber: String = ""

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquiryAsnBlindPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val palletInquiry = viewModel.getPalletDetails()
        if (palletInquiry != null) {
            //Set the values of pallet detail
            binding.tvCustAsnNumberValue.text = palletInquiry.customerASNNumber
            binding.tvAsnNumberValue.text = palletInquiry.asnNumber
            binding.tvPalletNumberValue.text = palletInquiry.palletNumber
            binding.tvNoOfCasesValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_cases, palletInquiry.noOfCase, palletInquiry.noOfCase)
            binding.tvPalletQuantityValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_units, palletInquiry.palletQuantity, palletInquiry.palletQuantity)
            binding.tvItemCodeValue.text = palletInquiry.itemCode
            binding.tvItemDescValue.text = palletInquiry.itemDescription
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etBlindPalletNumber.isFocused && binding.etBlindPalletNumber.text.toString().trim().isNotEmpty()) {
                        FlareLog.i(TAG, "Blind number field focused")
                        validateBlindPalletNumber(binding.etBlindPalletNumber.text.toString().trim())
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etBlindPalletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etBlindPalletNumber)
                FlareLog.i(TAG, "Blind number field focused")
                validateBlindPalletNumber(binding.etBlindPalletNumber.text.toString().trim())
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            binding.etBlindPalletNumber.text = null
            callNewPalletAPI()
        }

        binding.etBlindPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvBlindPalletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        //Blind Pallet number submit and navigation
        viewModel.renamePalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { renamePalletResponse ->
                        if (renamePalletResponse.success) {
                            //Pallet renamed then save the renamed pallet name to display it in pallet detail view and display the message
                            viewModel.getPalletDetails()!!.palletNumber = newPalletNumber
                            navigatePalletNumber(resources.getString(R.string.lbl_pallet_number_updated_to,renamePalletRequest!!.newPalletNumber))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if (isNewPallet) {
                            //If pallet renamed by new pallet button means displaying the error in dialog
                            showCustomDialog(message) {}
                        } else {
                            //otherwise display it in blind pallet response label
                            binding.etBlindPalletNumber.requestFocus()
                            binding.tvBlindPalletNumberResponse.text = message
                            binding.etBlindPalletNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etBlindPalletNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // New pallet button click update and navigation
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { newPalletResponse ->
                        if (newPalletResponse.success) {
                            if (newPalletResponse.numbers[0].type.equals(Constants.TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                //Took the generated pallet name and call the rename patch API
                                isNewPallet = true
                                validateBlindPalletNumber(newPalletResponse.numbers[0].value)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to navigate back screen with dialog
     */
    private fun navigatePalletNumber(message: String) {
        showCustomDialog(message) {
            getNavigationController().popBackStack()
        }
    }

    /**
     * method to validate blind pallet number
     */
    private fun validateBlindPalletNumber(palletNumber: String) {
        newPalletNumber = palletNumber
        if (newPalletNumber.isNotEmpty()) {
            val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
            if (containerType != null && (!newPalletNumber.startsWith(containerType.ctyId!!) || newPalletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.tvBlindPalletNumberResponse.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                renamePalletRequest = ASNRenamePalletRequest(
                    existingPalletNumber = binding.tvPalletNumberValue.text.toString(),
                    newPalletNumber = newPalletNumber,
                    asnId = viewModel.getPalletDetails()!!.asnId
                )
                viewModel.renamePalletNumberCall(renamePalletRequest!!)
            }
        }
    }

    /**
     * method to call Submit MPR API
     */
    private fun callNewPalletAPI() {
        viewModel.newPalletNumberGenerate()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.onVisibilityChange(true)
        cb1 = cb!!
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etBlindPalletNumber.setText(scan?.barcode.toString())
                binding.etBlindPalletNumber.text?.length?.let {
                    binding.etBlindPalletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Blind number field focused")
                    validateBlindPalletNumber(binding.etBlindPalletNumber.text.toString().trim())
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}