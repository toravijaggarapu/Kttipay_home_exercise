package com.fsc.flare.ui.fragment.putaway.damage

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSDPutawayActiveContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = DamagePutawayContainerFragment::class.java.simpleName.toString()

/**
 * A simple [DamagePutawayContainerFragment] class.
 */
@AndroidEntryPoint
class DamagePutawayContainerFragment : BaseFragment(), FlareScannable {

    val viewModel: DamagePutawayViewModel by activityViewModels()
    private lateinit var binding: FragmentSDPutawayActiveContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        cb1.onVisibilityChange(true)
        if (arguments != null) arguments?.let {
            viewModel.isUserDirected = it.getString(ARG_PARAM) != ARG_VALUE
            binding.tvHeader.text =
                if (viewModel.isUserDirected) getString(R.string.user_directed_putaway_damaged)
                else getString(R.string.system_directed_putaway_damaged)
        }

        super.onResume()
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentSDPutawayActiveContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        handleTouchAndFocusEvents()
        subscribeObservers()
        return binding.root
    }

    /**
     * Function to update container label hint
     */
    private fun updateContainerLabelHint(label: String) {
        binding.tvContainer.text = label
        binding.etContainer.hint = label
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.setPalletNumberValue(null)
        viewModel.isPutawayByPallet = true
        binding.rdPutawayGroup.setOnCheckedChangeListener { _, checkedId ->
            viewModel.isPutawayByPallet = checkedId == R.id.rdPutawayPallet
            updateContainerLabelHint(
                if (viewModel.isPutawayByPallet) {
                    getString(R.string.pallet_number_or_case_or_serial_number)
                } else {
                    getString(R.string.case_number_or_serial_number)
                }
            )
        }
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        // Set up the container EditText
        binding.etContainer.apply {
            setOnEditorActionListener { _, actionId, event ->
                if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, this)
                    FlareLog.i(TAG, "Container field focused")
                    getContainerInfo()
                }
                return@setOnEditorActionListener false
            }

            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    binding.tvContainerResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }

        // Set up the root layout touch listener
        binding.rootLayout.setOnTouchListener { _, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        getContainerInfo()
                    } else {
                        binding.tvContainerResponse.text =
                            getString(R.string.lbl_pallet_slash_case_is_required)
                        binding.etContainer.requestFocus()
                    }
                }
            }
            return@setOnTouchListener true
        }
    }

    /**
     * Function to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        observeContainerInfoResponse()
        observeContainerResponse()
    }

    /**
     * Function to get container details
     */
    private fun getContainerInfo() {
        val containerText = binding.etContainer.text?.trim().toString()
        if (containerText.isNotEmpty()) {
            viewModel.getContainerDetails(containerNum = containerText)
        }
    }

    /**
     * Function to validate container from API
     */
    private fun validateContainer() {
        val containerText = binding.etContainer.text?.toString()?.trim()
        if (containerText.isNullOrEmpty()) {
            binding.tvContainerResponse.text = getString(R.string.lbl_pallet_slash_case_is_required)
            binding.etContainer.requestFocus()
            return
        }
        viewModel.prepareContainerRequest(containerText)
    }

    /**
     * Function to observe Container Response
     */
    private fun observeContainerResponse() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    handleContainerSuccessResponse(response)
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        handleContainerError(message)
                    }
                }

                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle Container Success Response
     */
    private fun handleContainerSuccessResponse(response: Resource<UserDirectedPutawayContainerResponse>) {
        hideProgressBar()
        response.data?.let { containerResponse ->
            when {
                containerResponse.recallLockExists -> {
                    viewModel.isRCLockCalled = true
                    showItemRecallAlertDialog(
                        getString(R.string.lbl_item_recall_lock_dialog_title),
                        getString(R.string.lbl_sd_item_recall_lock_dialog_message)
                    )
                    return
                }

                containerResponse.dynamicSlottingMaxLocationCountReached -> {
                    handleDynamicSlottingMaxLocationCountReached(containerResponse)
                }

                containerResponse.maxPerLocation -> {
                    showMaxLocationReachedAlert(containerResponse)
                }

                else -> when {
                    containerResponse.dynamicSlotting && containerResponse.message?.isNotEmpty() == true -> {
                        when (containerResponse.messageCode) {
                            Constants.ErrorCode.ERR_CNT_DYS_001, Constants.ErrorCode.ERR_CNT_DYS_002 -> {
                                showSuccessSnackBarStd(containerResponse.message?:"") {
                                    processContainerResponse(containerResponse)
                                }
                            }
                            Constants.LockCodes.QUALITY_HOLD -> {
                                if (viewModel.isUserDirected) {
                                    showAlertDialog(
                                        "",
                                        getString(R.string.locked_for_quality_check_move_to_quarantine_location),
                                        getString(R.string.alert_button_yes),
                                        getString(R.string.alert_button_cancel),
                                        object : AlertDialogClickListener {
                                            override fun onPositiveButtonClick() {
                                                viewModel.isQHLockOnForUserDirectedPutaway = true
                                                processContainerResponse(containerResponse)
                                            }

                                            override fun onNegativeButtonClick() {
                                            }
                                        })
                                }
                            }
                            else -> {
                                binding.tvContainerResponse.text = containerResponse.message
                            }
                        }
                    }
                    else -> {
                        processContainerResponse(containerResponse)
                    }
                }
            }
        }
    }

    /**
     * Function to process container response
     */
    private fun processContainerResponse(containerResponse: UserDirectedPutawayContainerResponse) {
        viewModel.apply {
            setPutawayContainerData(containerResponse)
            containerResponse.locationBarcode?.let { setLocationData(it) }
        }
        navigateToActiveLocationFragment()
    }

    /**
     * Function to handle dynamic slotting Max location count reached
     */
    private fun handleDynamicSlottingMaxLocationCountReached(containerResponse: UserDirectedPutawayContainerResponse) {
        binding.tvContainerResponse.text = containerResponse.message
        binding.etContainer.apply {
            requestFocus()
            selectAll()
            showSoftKeyBoard(fragmentContext, this)
        }
    }

    /**
     * Function to handle container error response
     */
    private fun handleContainerError(message: String) {
        if (message == Constants.LockCodes.QUALITY_HOLD && !viewModel.isUserDirected) {
            showWarningDialog(
                "",
                getString(R.string.locked_for_quality_check_please_proceed_with_user_directed_put_away_to_move_it_to_quarantine_location)
            ) {
            }
        } else {
            binding.tvContainerResponse.text = message
            binding.etContainer.apply {
                requestFocus()
                selectAll()
                showSoftKeyBoard(fragmentContext, this)
            }
        }
    }

    /**
     * Function to observe Container Info Response
     */
    private fun observeContainerInfoResponse() {
        viewModel.containerInfoResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleContainerInfoSuccessResponse(response.data)
                is Resource.Error -> handleContainerInfoErrorResponse(response.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle Container Info Success Response
     */
    private fun handleContainerInfoSuccessResponse(containerResponse: InventoryContainerResponse?) {
        hideProgressBar()
        containerResponse?.container?.firstOrNull()?.let { containerInfo ->
            if(containerInfo.ibObCode == "OB"){
                binding.tvContainerResponse.text =  getString(R.string.scanned_container_is_an_ob_container_please_scan_valid_case)
                return
            }
            viewModel.setContainerDetail(containerInfo)
            containerInfo.lockCodes?.let { lockCodes ->
                if (lockCodes.any { it.code == "RC" }) {
                    // Code to execute when "RC" code is found
                    showItemRecallAlertDialog(
                        getString(R.string.lbl_item_recall_lock_dialog_title),
                        getString(R.string.lbl_sd_item_recall_lock_dialog_message)
                    )
                    return
                }
            }

            val isAllowOpsOnCCPendingLocation = sharedPreferencesBase.getBoolean(
                PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false
            )
            val isCyclePending =
                isAllowOpsOnCCPendingLocation && containerInfo.lockCode == "CC" || !isAllowOpsOnCCPendingLocation && containerInfo.locationCyclePending == Constants.YES

            binding.tvContainerResponse.text = when {
                isCyclePending -> getString(
                    if (isAllowOpsOnCCPendingLocation) R.string.cycle_count_in_progress_for_given_location
                    else R.string.cycle_count_is_pending_for_given_location
                )

                else -> {
                    validateContainer()
                    null
                }
            }
        } ?: run {
            binding.tvContainerResponse.text = getString(R.string.invalid_container)
        }
    }

    /**
     * Function to handle Container Info error response
     */
    private fun handleContainerInfoErrorResponse(errorMessage: String?) {
        hideProgressBar()
        errorMessage?.let { message ->
            val formattedMessage = message.split("##").getOrNull(1) ?: message
            FlareLog.e(TAG, "containerInfoResponse error: $formattedMessage")
            binding.tvContainerResponse.text = formattedMessage
        }
    }

    /**
     * Function to show Item Recall Alert Dialog
     */
    private fun showItemRecallAlertDialog(title: String, message: String) {
        val builder = showAlertDialog(title, message) {
            requireActivity().supportFragmentManager.popBackStack()
            requireActivity().supportFragmentManager.popBackStack()
        }
        builder.setIcon(R.drawable.alert_accent)
    }

    /**
     * Function to handle Max Location Reached Alert
     */
    private fun showMaxLocationReachedAlert(containerResponse: UserDirectedPutawayContainerResponse) {
        containerResponse.message?.let {
            showAlertDialog("",
                it,
                getString(R.string.alert_button_yes),
                getString(R.string.alert_button_no),
                object : AlertDialogClickListener {
                    override fun onPositiveButtonClick() {
                        handlePositiveButtonClick(containerResponse)
                    }

                    override fun onNegativeButtonClick() {
                        focusOnContainerInput()
                    }

                })
        }
    }

    /**
     * Function to handle positive button click
     */
    private fun handlePositiveButtonClick(containerResponse: UserDirectedPutawayContainerResponse) {
        with(viewModel) {
            setPutawayContainerData(containerResponse)
            containerResponse.locationBarcode?.let { setLocationData(it) }
        }
        navigateToActiveLocationFragment()
    }

    /**
     * Function to focus on Container Input
     */
    private fun focusOnContainerInput() {
        binding.etContainer.apply {
            requestFocus()
            selectAll()
            showSoftKeyBoard(fragmentContext, this)
        }
    }

    /**
     * Function to navigate Active Location Fragment
     */
    private fun navigateToActiveLocationFragment() {
        val action =
            DamagePutawayContainerFragmentDirections.actionDamagePutawayContainerFragmentToDamagePutawayLocationFragment()
        getNavigationController().navigate(action)
        binding.etContainer.text = null
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }

        binding.etContainer.setText(scan?.barcode.toString())
        binding.etContainer.text?.length?.let {
            binding.etContainer.setSelection(
                it
            )
            hideSoftKeyBoard(fragmentContext, binding.etContainer)
            FlareLog.i(TAG, "Container field focused")
            getContainerInfo()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}