package com.fsc.flare.ui.fragment.inventory.combinebypallet

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemContainerNQuantityBinding
import com.fsc.flare.source.data.dto.inventory.CaseItem

class ContainersAdapter(
    private var containersList: List<CaseItem>
) : RecyclerView.Adapter<ContainersAdapter.ContainerViewHolder>() {

    inner class ContainerViewHolder(
        val binding: ItemContainerNQuantityBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(container: CaseItem, isLastItem: Boolean) {
            binding.tvContainerNumber.text = container.caseNo
            binding.tvQuantity.text = container.qty
            binding.vSeparator.visibility = if (isLastItem) View.INVISIBLE else View.VISIBLE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContainerViewHolder {
        val binding = ItemContainerNQuantityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ContainerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContainerViewHolder, position: Int) =
        holder.bind(container = containersList[position], isLastItem = position == containersList.size - 1)

    override fun getItemCount(): Int {
        return containersList.size
    }
}