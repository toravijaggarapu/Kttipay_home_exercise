package com.fsc.flare.ui.fragment.inventory.combinebypallet

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemLockNDescriptionBinding
import com.fsc.flare.source.data.dto.inventory.LockItem

class LockCodesAdapter(
    private var lockCodesList: List<LockItem>
) : RecyclerView.Adapter<LockCodesAdapter.LockCodeViewHolder>() {

    inner class LockCodeViewHolder(
        val binding: ItemLockNDescriptionBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(lockCode: LockItem, isLastItem: Boolean) {
            binding.tvLockCode.text = lockCode.lockCode
            binding.tvDescription.text = lockCode.lockDescription
            binding.vSeparator.visibility = if (isLastItem) View.INVISIBLE else View.VISIBLE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LockCodeViewHolder {
        val binding = ItemLockNDescriptionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LockCodeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LockCodeViewHolder, position: Int) =
        holder.bind(lockCode = lockCodesList[position], isLastItem = position == lockCodesList.size - 1)

    override fun getItemCount(): Int {
        return lockCodesList.size
    }
}