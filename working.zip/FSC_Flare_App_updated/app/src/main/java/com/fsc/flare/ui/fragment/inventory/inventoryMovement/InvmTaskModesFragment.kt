package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmTaskModesBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.utils.Constants.TaskModes.SYSTEM_DIRECTED
import com.fsc.flare.utils.Constants.TaskModes.USER_DIRECTED
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InvmTaskModesFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private lateinit var binding: FragmentInvmTaskModesBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View {
        binding = FragmentInvmTaskModesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        val taskModeList = ArrayList<String>()
        taskModeList.add(SYSTEM_DIRECTED)
        taskModeList.add(USER_DIRECTED)
        binding.taskModesDropDown.setOptions(taskModeList)
        binding.taskModesDropDown.boolFoo.observe(viewLifecycleOwner) { selectedTaskMode ->
            sharedViewModel.selectedTaskMode = selectedTaskMode
            if (selectedTaskMode == USER_DIRECTED) {
                navigateToSourceScanScreen()
            } else {
                navigateToTaskGroupsScreen()
            }
        }
    }

    private fun navigateToTaskGroupsScreen() {
        getNavigationController().navigate(InvmTaskModesFragmentDirections.actionInvmTaskModesFragmentToInvmTaskGroupsFragment())
    }

    private fun navigateToSourceScanScreen() {
        getNavigationController().navigate(InvmTaskModesFragmentDirections.actionInvmTaskModesFragmentToInvmSourceScanFragment())
    }
}