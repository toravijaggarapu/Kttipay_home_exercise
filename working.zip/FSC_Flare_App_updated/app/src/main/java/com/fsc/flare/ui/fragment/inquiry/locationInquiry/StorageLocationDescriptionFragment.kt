package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryLocationDescBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryLonDesc"

/**
 * A simple [StorageLocationDescriptionFragment] class.
 */
@AndroidEntryPoint
class StorageLocationDescriptionFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryLocationDescBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryLocationDescBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        viewModel.page = 1
        val data = viewModel.getLocation()
        FlareLog.i(TAG, "InquiryLocDescFragment: $data")
        val locInventoryData = viewModel.locInventoryCounts
        if (data != null) {
            val location = data.locations[0]
            binding.zoneGroup.text = location.groupDescription
            binding.locationId.text = location.locationBarcode
            binding.locationClass.text = getLocationClass(location.classification)
            binding.locationType.text = getLocationType(location.locType)
            binding.status.text = getLocationStatus(location.status)
            if(location.locationStatus.equals("Inactive",true)){
                binding.locationStatusLnr.visibility = View.VISIBLE
                binding.locationStatus.text = location.locationStatus
            }
            if(!viewModel.lotNumbersList.isNullOrEmpty()){
                binding.lotLnr.visibility = View.VISIBLE
                if(viewModel.lotNumbersList.size > 1){
                    binding.lot.text = getString(R.string.lbl_Mixed)
                }else{
                    binding.lot.text = viewModel.lotNumbersList[0]
                }
            }
            if(!viewModel.cooCodesList.isNullOrEmpty()){
                binding.cooLnr.visibility = View.VISIBLE
                if(viewModel.cooCodesList.size >1 ){
                    binding.coo.text = getString(R.string.lbl_Mixed)
                }else{
                    binding.coo.text = viewModel.cooCodesList[0]
                }
            }
            if(!viewModel.expiredDatesList.isNullOrEmpty()){
                binding.expiryLnr.visibility = View.VISIBLE
                if(viewModel.expiredDatesList.size > 1){
                    binding.expiryDate.text = getString(R.string.lbl_Mixed)
                }else{
                    binding.expiryDate.text = viewModel.expiredDatesList[0]
                }
            }
            if(!viewModel.invTypesList.isNullOrEmpty()){
                binding.invTypeTv.visibility = View.VISIBLE
                binding.invType.visibility = View.VISIBLE
                if(viewModel.invTypesList.size > 1){
                    binding.invType.text = getString(R.string.lbl_Mixed)
                }else{
                    binding.invType.text = viewModel.invTypesList[0]?.let {
                        getInventoryDescription(
                            it
                        )
                    }
                }
            }
            binding.locationCapacity.text = location.uom.netVolume.toString()
            binding.locationCapacityUom.text = location.uom.volumeUom
            binding.item.text = viewModel.locationContainer?.item ?: " "
            binding.itemDescription.text = viewModel.locationContainer?.itemDesc ?: " "

            if (location.classification in arrayOf("A", "C", "R")) {
                binding.locationInventoryDetails.visibility = View.VISIBLE

                if (location.classification == "R" ) {
                    binding.noOfPalletsLnr.visibility = View.VISIBLE
                    if (locInventoryData != null) {
                        binding.totalQty.text = locInventoryData.totalQty.toString()
                        binding.noOfPallets.text = locInventoryData.palletCount.toString()
                    }
                    binding.viewPallets.setOnClickListener {
                        val action = StorageLocationDescriptionFragmentDirections.actionStorageLocationDescFragmentToPalletListFragment()
                        getNavigationController().navigate(action)
                    }
                } else if (location.classification == "C") {
                    binding.noOfCasesLnr.visibility = View.VISIBLE
                    if (locInventoryData != null) {
                        binding.totalQty.text = locInventoryData.totalQty.toString()
                        binding.noOfCases.text = locInventoryData.caseCount.toString()
                    }
                    binding.viewCases.setOnClickListener {
                        val action = StorageLocationDescriptionFragmentDirections.actionStorageLocationDescFragmentToCaseListFragment()
                        getNavigationController().navigate(action)
                    }
                }else if (location.classification == "A" ){
                    if (locInventoryData != null) {
                        binding.totalQty.text = locInventoryData.totalQty.toString()
                    }
                }
            }

            binding.btnOk.setOnClickListener {
                val action =
                    StorageLocationDescriptionFragmentDirections.actionStorageLocationDescFragmentToLocationFragment()
                val navOptions =  NavOptions.Builder().setPopUpTo(R.id.inquiryLocation, true).build()
                getNavigationController().navigate(action, navOptions)
            }
        }
    }
}