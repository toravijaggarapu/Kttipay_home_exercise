package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "TivoALTYP11LocationFragment"

/**
 * A simple [Fragment] subclass.
 * Use the TivoALTYP11LocationFragment that extends BaseFragment to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11LocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLLocationBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        viewModel.setSerialNumberList(arrayListOf())
        viewModel.setQtyEntered(0)
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        setUIValues()

        if (sharedPreferences.getBoolean(PreferenceKeys.PickFromReserve.IS_FIRST_TASK_UNITPICKED, false)) {
            binding.btnStage.isEnabled = true
        }

        binding.etLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLocation)
                FlareLog.i(TAG, "Location field focused")
                validateLocation()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Location field focused")
                        validateLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnStage.setOnClickListener {
            viewModel.reservepickstage()
        }

        binding.btnSkip.setOnClickListener {
            skipTaskLineItem()
        }
        subscribeReservePickStageReleaseObserver()
    }

    private fun setUIValues() {
        val taskDetails = viewModel.getPickTaskDetails()
        binding.tvTaskIdValue.text = taskDetails?.taskId.toString()
        binding.tvItemCodeValue.text = taskDetails?.itemCode
        binding.tvDescriptionValue.text = taskDetails?.itemDescription
        binding.tvPickQtyValue.text = String.format("%d Units",taskDetails?.taskQty)
        binding.tvPickedQtyValue.text = String.format("%d Units",0)
        binding.tvLocationValue.text = taskDetails?.locationBarcode

        binding.btnSkip.isEnabled = taskDetails!!.numberOfTaskLinesPickingPending > 1
    }

    private fun skipTaskLineItem() {
        viewModel.skipTaskLineItem(
            SkipPickCartReq(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                skipTaskId = viewModel.getPickTaskDetails()!!.taskDetId.toString(), // Skipping Task details
                skipTaskDetId = viewModel.getPickTaskDetails()!!.taskDetId.toString(),
                allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    /**
     * method to validate Location from API Result
     */
    private fun validateLocation() {
        val stageTaskDetails = viewModel.getPickTaskDetails()
        if (binding.etLocation.text.toString() == stageTaskDetails?.locationBarcode) {
            val bundle = bundleOf(
                "pageType" to "itemcode"
            )
            getNavigationController().navigate(R.id.action_locationFragment_to_itemSerialFragment, bundle)
        } else {
            binding.tvLocationResponse.text = resources.getString(R.string.invalid_location)
            binding.rootLayout.scrollTo(0, binding.rootLayout.height)
        }
    }

    /**
     * method to subscribe reserve pick stage release observer
     */
    private fun subscribeReservePickStageReleaseObserver() {
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if(response.success){
                            if (response.taskDetails == null) {
                                showSuccessSnackBarStd(response.message) {
                                    val action =
                                        TivoALTYP11LocationFragmentDirections.actionLocationFragmentToTaskgroupFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                            } else {
                                viewModel.setStageTaskDetails(response.taskDetails)
                                val action =
                                    TivoALTYP11LocationFragmentDirections.actionLocationFragmentToStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }else{
                            response.message.let { message ->
                                FlareLog.e(TAG, "reservePickStageResponse error: $message")
                                showErrorSnackBar(message)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                setUIValues()
                            } else {
                                skipCartResponse.message?.let { showErrorSnackBar(it) }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.success) {
                            if (response.taskDetails == null) {
                                showSuccessSnackBar(response.message)
                            } else {
                                viewModel.setStageTaskDetails(response.taskDetails)
                                val action = TivoALTYP11LocationFragmentDirections.actionLocationFragmentToStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            FlareLog.e(TAG, "reservePickStageResponse error: ${response.message}")
                            showErrorSnackBar(response.message)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etLocation.setText(scan?.barcode.toString())
                binding.etLocation.text?.length?.let {
                    binding.etLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Location field focused")
                    validateLocation()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}