package com.fsc.flare.ui.fragment.prescan

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.prescan.createShipment.request.CreateShipmentRequest
import com.fsc.flare.source.data.dto.prescan.createShipment.response.CreateShipmentResponse
import com.fsc.flare.source.data.dto.prescan.fetch.PreScanValidateRMARequest
import com.fsc.flare.source.data.dto.prescan.fetch.PreScanValidateRMAResponse
import com.fsc.flare.source.data.dto.prescan.returntype.PrescanReturnTypeResponse
import com.fsc.flare.source.data.dto.prescan.trackingNumber.ValidateTrackingNumberRequest
import com.fsc.flare.source.data.dto.prescan.trackingNumber.ValidateTrackingNumberResponse
import com.fsc.flare.source.data.dto.prescan.vendor.PreScanVenderRequest
import com.fsc.flare.source.data.dto.prescan.vendor.PrescanGetCustomerDetailsResponse
import com.fsc.flare.source.repository.PrescanRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = PreScanViewModel::class.java.simpleName.toString()

/**
 * A ViewModel class for call  Precsan API request to  PrescanRepository class along with pass necessary arguments  .
 * And handle receive response data and assigned to Livedata object.
 */
@HiltViewModel
class PreScanViewModel @Inject constructor(
    private val prescanRepository: PrescanRepository, sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val preScanValidateRMAResponse: MutableLiveData<Resource<PreScanValidateRMAResponse>> =
        SingleLiveEvent()
    val createShipmentResponse: MutableLiveData<Resource<CreateShipmentResponse>> =
        SingleLiveEvent()
    val vendorORCustomerDetailsResponse: MutableLiveData<Resource<PrescanGetCustomerDetailsResponse>> =
        SingleLiveEvent()
    val getReturnTypeResponse: MutableLiveData<Resource<PrescanReturnTypeResponse>> =
        SingleLiveEvent()
    val carrierSCACResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val defaultVendorResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()
    var listCarrierScac: MutableLiveData<ArrayList<String>?> = MutableLiveData()
    val validateTrackingNumberResponse: MutableLiveData<Resource<ValidateTrackingNumberResponse>> =
        SingleLiveEvent()

    lateinit var lookupMap: Map<String, String>
    val returnTypeHashMap: HashMap<String, String> = HashMap()
    var customerDetailsListItem = MutableLiveData<String>()

    var asnType :String= ""
    var storeNumber = MutableLiveData<String>()
    var showNoVendorAssociatedMsg = MutableLiveData<Boolean>()

    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)


    /**
     * method to fetch shipment details of existing RMA
     */
    fun getValidateRMADetails(preScanValidateRMARequest: PreScanValidateRMARequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "validate RMA Request: $preScanValidateRMARequest")
            preScanValidateRMAResponse.postValue(Resource.Loading())
            val preScanValidateRMARes =
                prescanRepository.validateRMANumber(preScanValidateRMARequest)
            preScanValidateRMAResponse.postValue(
                handleGetValidateRMAResponse(
                    preScanValidateRMARes
                )
            )
        }

    /**
     * method to create shipment and process prescan
     */
    fun processPrescan(createShipmentRequest: CreateShipmentRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Process prescan request: $createShipmentRequest")
        createShipmentResponse.postValue(Resource.Loading())
        val response = prescanRepository.createShipmentRMANumber(createShipmentRequest)
        FlareLog.i(TAG, "Process prescan  RESPONSE : ${response.body()}")
        createShipmentResponse.postValue(handleCreateShipmentResponse(response))
    }

    /**
     * method to get return type
     */
    fun getReturnType() = viewModelScope.launch {
        getReturnTypeResponse.postValue(Resource.Loading())
        val response = prescanRepository.getPreScanReturnType()
        getReturnTypeResponse.postValue(handleGetReturnTypeResponse(response))
    }

    /**
     * method to get customer details
     */
    fun getCustomerDetails(request: PreScanVenderRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "submit validate transaction param Request: $request")
        vendorORCustomerDetailsResponse.postValue(Resource.Loading())
        val response = prescanRepository.getCustomerDeatils(request)

        vendorORCustomerDetailsResponse.postValue(
            handleGetVendorCusttomerDetailsResponse(
                response
            )
        )
    }

    /**
     * method to lookup carrierSCAC code
     */
    fun getCarrierSCAC() = viewModelScope.launch {
        carrierSCACResponse.postValue(Resource.Loading())
        val response = prescanRepository.getCarrierSCAC()
        FlareLog.i(TAG, "get CarrierSCAC:  ${response.body()}")
        carrierSCACResponse.postValue(handleGetCarrierSCACResponse(response))
    }


    /**
     * method to lookup Default vendor
     */
    fun getPrescanDefaultVendor() = viewModelScope.launch {
        defaultVendorResponse.postValue(Resource.Loading())
        val response = prescanRepository.getDefaultVendor()
        FlareLog.i(TAG, "get Prescan DefaultVendor:  ${response.body()}")
        defaultVendorResponse.postValue(handleGetDefaultVendorResponse(response))
    }

    /**
     * method to get customer details
     */
    fun getValidateTrackingNumber(request: ValidateTrackingNumberRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "submit validate Tracking Number param Request: $request")
        validateTrackingNumberResponse.postValue(Resource.Loading())
        val response = prescanRepository.validateTrackingNumber(request)

        validateTrackingNumberResponse.postValue(
            handleValidateTrackingNumberResponse(
                response
            )
        )
    }

    /**
     * method to handle Get ValidateRMA Response
     */
    private fun handleGetValidateRMAResponse(preScanValidateRMARes: Response<PreScanValidateRMAResponse>): Resource<PreScanValidateRMAResponse>? {
        if (preScanValidateRMARes.isSuccessful) {
            preScanValidateRMARes.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PreScanValidateRMA Response: $resultResponse")
                asnType = resultResponse.asnType
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                preScanValidateRMARes.code(),
                preScanValidateRMARes.errorBody(),
                preScanValidateRMARes.message()
            )
            FlareLog.e(TAG, "PreScanValidateRMA Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle CreateShipment Response
     */
    private fun handleCreateShipmentResponse(createShipmentResponse: Response<CreateShipmentResponse>): Resource<CreateShipmentResponse>? {
        if (createShipmentResponse.isSuccessful) {
            createShipmentResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PreScan create shipment Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                createShipmentResponse.code(),
                createShipmentResponse.errorBody(),
                createShipmentResponse.message()
            )
            FlareLog.e(TAG, "PreScan create shipment Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle GetVendorCusttomerDetails Response
     */
    private fun handleGetVendorCusttomerDetailsResponse(prescanGetCustomerDetailsRes: Response<PrescanGetCustomerDetailsResponse>): Resource<PrescanGetCustomerDetailsResponse>? {
        if (prescanGetCustomerDetailsRes.isSuccessful) {
            prescanGetCustomerDetailsRes.body()?.let { resultResponse ->
                populateCustomerDetailsDropDown(resultResponse)
                FlareLog.i(TAG, "PrescanGetCustomerDetails Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                prescanGetCustomerDetailsRes.code(),
                prescanGetCustomerDetailsRes.errorBody(),
                prescanGetCustomerDetailsRes.message()
            )
            FlareLog.e(TAG, "PrescanGetCustomerDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle GetReturnType Response
     */
    private fun handleGetReturnTypeResponse(prescanReturnTypeResponse: Response<PrescanReturnTypeResponse>): Resource<PrescanReturnTypeResponse>? {
        if (prescanReturnTypeResponse.isSuccessful) {
            prescanReturnTypeResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "prescanReturnTypeResponse Response: $resultResponse")
                for (returnType in resultResponse) {
                    returnTypeHashMap[returnType.retReturnType] = returnType.retDescription
                }
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                prescanReturnTypeResponse.code(),
                prescanReturnTypeResponse.errorBody(),
                prescanReturnTypeResponse.message()
            )
            FlareLog.e(TAG, "prescanReturnTypeResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle GetDefaultVendor Response
     */
    private fun handleGetDefaultVendorResponse(getDefaultVendorResponse: Response<LookUps>): Resource<LookUps>? {
        if (getDefaultVendorResponse.isSuccessful) {
            getDefaultVendorResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Get DefaultVendor Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                getDefaultVendorResponse.code(),
                getDefaultVendorResponse.errorBody(),
                getDefaultVendorResponse.message()
            )
            FlareLog.e(TAG, "Get DefaultVendor Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle GetCarrierSCAC Response
     */
    private fun handleGetCarrierSCACResponse(getCarrierSCACResponse: Response<LookUps>): Resource<LookUps>? {
        if (getCarrierSCACResponse.isSuccessful) {
            getCarrierSCACResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Get carrierSCAC Response: $resultResponse")
                getLookUpDataForCarrierSCAC(resultResponse)
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                getCarrierSCACResponse.code(),
                getCarrierSCACResponse.errorBody(),
                getCarrierSCACResponse.message()
            )
            FlareLog.e(TAG, "Get carrierSCAC Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle Get ValidateRMA Response
     */
    private fun handleValidateTrackingNumberResponse(validateTrackingNumberRes: Response<ValidateTrackingNumberResponse>): Resource<ValidateTrackingNumberResponse>? {
        if (validateTrackingNumberRes.isSuccessful) {
            validateTrackingNumberRes.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PreScan Validate tracking number Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                validateTrackingNumberRes.code(),
                validateTrackingNumberRes.errorBody(),
                validateTrackingNumberRes.message()
            )
            FlareLog.e(TAG, "PreScan Validate tracking number Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get return type from HashMap
     */
    fun getSelectedReturnType(): String? {
        return returnTypeHashMap[asnType]
    }

    /**
     * method to get LookUpData For CarrierSCAC
     */
    private fun getLookUpDataForCarrierSCAC(lookUpResponse: LookUps) {
        lookupMap = lookUpResponse.lookups.flatMap { it.lookupCodes }
            .associate { it.lookupCodeDescription to it.lookupCode }
        val carrierScac = ArrayList(lookupMap.keys)
        listCarrierScac.postValue(carrierScac)
    }

    /**
     * method to get LookUpcode Form user selected CarrierSCAC
     */
    fun getCodeFromSelectedDescription(selectedDescription: String): String? {
        return lookupMap[selectedDescription]
    }

    /**
     * method to populate Customer name, Customer Number and address for dropdown based on api response
     */
    private fun populateCustomerDetailsDropDown(validateRMAResponse: PrescanGetCustomerDetailsResponse) {
        validateRMAResponse.vendors.firstOrNull()?.let { vendor ->
            val result = "${vendor.customerName}-${vendor.vendorNumber}-${vendor.address.addressLine1}"
            customerDetailsListItem.postValue(result)
            storeNumber.postValue(vendor.address.addressLine2)
        }
    }

    /**
     * method to get vendor Customer Details from API call
     */
    fun vendorCustomerDetails() {
        validateRMAResponse.customerInformation?.customerNumber?.let { customerNumber ->
            getCustomerDetails(
                PreScanVenderRequest(
                    customerId = custId,
                    vendorName = customerNumber,
                    active = Constants.PreScanScreen.PRE_SCAN_VENDOR_REQUEST_ACTIVE_COUNT
                )
            )
            showNoVendorAssociatedMsg.postValue(false)
        } ?: run {
            showNoVendorAssociatedMsg.postValue(true)
        }
    }

    lateinit var validateRMAResponse: PreScanValidateRMAResponse
    val validateRMAResponseObject: PreScanValidateRMAResponse get() = validateRMAResponse
}