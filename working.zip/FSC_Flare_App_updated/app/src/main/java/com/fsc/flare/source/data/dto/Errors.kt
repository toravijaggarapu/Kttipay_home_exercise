package com.fsc.flare.source.data.dto

data class Errors(
    val errorMessage: String,
    val exceptionResponse: List<ErrorResponse>
)