package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask


const val SYSTEM_DIRECTED = "SystemDirectedMode"
const val USER_DIRECTED = "UserDirectedMode"

class ReplenishmentDeliverySharedViewModel : ViewModel() {

    var selectedTaskMode: String? = null
    var task: ReplenishDeliveryTask? = null

    fun clearData() {
        selectedTaskMode = null
        task = null
    }
}

