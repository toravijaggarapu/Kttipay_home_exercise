package com.fsc.flare.ui.fragment.putaway

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fedex.services.barcode.model.Barcode
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.putawayreverse.*
import com.fsc.flare.source.repository.PutAwayRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PutAwayViewmodel"

@HiltViewModel
class PutAwayViewModel @Inject constructor(
    private val putawayRepository: PutAwayRepository
) : BaseViewModel() {

    private var mLastScannedBarcode: Barcode? = null
    val containerResponse: MutableLiveData<Resource<ContainerResponse>> = MutableLiveData()
    val locationIDResponse: MutableLiveData<Resource<LocationIDResponse>> = MutableLiveData()
    val putawayRes: MutableLiveData<Resource<DoPutawayResponse>> = MutableLiveData()
    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()
   
    

    fun validateContainer(containerRequest: ContainerRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "validateContainer Request: $containerRequest")
            containerResponse.postValue(Resource.Loading())
            val response = putawayRepository.validateContainer(containerRequest)
            containerResponse.postValue(handleContainerResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun validateLocationID(locationIDRequest: LocationIDRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validateLocationID request: $locationIDRequest")
        try {
            locationIDResponse.postValue(Resource.Loading())
            val response = putawayRepository.validateLocationID(locationIDRequest)
            locationIDResponse.postValue(handleLocationIDResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun doPutaway(doPutawayRequest: DoPutawayRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "doPutaway request: $doPutawayRequest")
        try {
            putawayRes.postValue(Resource.Loading())
            val response = putawayRepository.doPutaway(doPutawayRequest)
            putawayRes.postValue(handleDoPutAwayResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun doIMEIPutaway(doPutawayRequest: DoPutawayRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "doIMEIPutaway request: $doPutawayRequest")
        try {
            putawayRes.postValue(Resource.Loading())
            val response = putawayRepository.doIMEIPutaway(doPutawayRequest)
            putawayRes.postValue(handleDoIMEIPutAwayResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleContainerResponse(response: Response<ContainerResponse>): Resource<ContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun handleLocationIDResponse(response: Response<LocationIDResponse>): Resource<LocationIDResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationIDResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationID Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun handleDoPutAwayResponse(response: Response<DoPutawayResponse>): Resource<DoPutawayResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DoPutAwayResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "DoPutAway Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun handleDoIMEIPutAwayResponse(response: Response<DoPutawayResponse>): Resource<DoPutawayResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DoIMEIPutAwayResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "DoIMEIPutAway Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun handleBarcodeScan(barcode: Barcode?) {
        mLastScannedBarcode = barcode
    }
    
    


}