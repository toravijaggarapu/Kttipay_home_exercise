package com.fsc.flare.ui.fragment.inventory.reversecontainertoforwardstaging

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCtaLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = RCTSLocationFragment::class.java.simpleName.toString()

/**
 * A simple [RCTSLocationFragment] class.
 */
@AndroidEntryPoint
class RCTSLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: RCTSViewModel by activityViewModels()
    private lateinit var binding: FragmentCtaLocationBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etLocation.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etLocation)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCtaLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvInventoryTransfer.text =
            sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        setUpViews()
        return binding.root
    }

    /**
     * Function to setUp views
     */
    private fun setUpViews() {
        val ctaContainerData = viewModel.fetchRCTSContainerResponse()
        ctaContainerData?.let {
            binding.tvContainerValue.text = it.containerNbr
            binding.tvInventoryTypeValue.text = getInventoryDescription(it.inventoryType)
            binding.tvItemCodeValue.text = it.itemCode
            binding.tvItemDescriptionValue.text = it.description
            binding.tvQuantityValue.text = it.scanQty.toString()
            binding.tvFromLocationValue.text = it.fromLocationBarcode
            binding.tvLocation.text = getString(R.string.lbl_to_location)
            binding.tvToLocation.visibility = View.GONE
            binding.tvToLocationValue.visibility = View.GONE
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etLocation.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLocation)
                FlareLog.i(TAG, "Container field focused")
                if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                    validateLocation()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate location
     */
    private fun validateLocation() {
        val destLocBarcode = binding.etLocation.text.toString()
        viewModel.fetchRCTSContainerResponse()?.let {
            val sourceLocBarcode = it.fromLocationBarcode
            if (sourceLocBarcode != destLocBarcode) {
                viewModel.prepareInventoryTransferContainerLocation(locBarcode = destLocBarcode)
            } else {
                handleErrorMessage(getString(R.string.error_inventory_transfer_location))
            }
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeRCTSLocationResponse()
    }

    /**
     * Function to observe RCTS location response
     */
    private fun observeRCTSLocationResponse() {
        viewModel.getRCTSLocationResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { ctaLocationResponse ->
                        showSuccessSnackBarStd(ctaLocationResponse.message) {
                            val action =
                                RCTSLocationFragmentDirections.actionRctsLocationFragmentToRctsContainerFragment()
                            getNavigationController().navigate(action)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "inventoryTransferLocation Error: $message")
                        handleErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle error message
     */
    private fun handleErrorMessage(message: String) {
        binding.tvLocationResponse.text = message
        binding.etLocation.requestFocus()
        binding.etLocation.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etLocation)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etLocation.setText(scan?.barcode.toString())
        binding.etLocation.text?.length?.let {
            binding.etLocation.setSelection(it)
            FlareLog.i(TAG, "Location field focused")
            validateLocation()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}