package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.packout.req.PackOutSerialNumberGetReq
import com.fsc.flare.source.data.dto.physicalInventory.AssignBatchReq
import com.fsc.flare.source.data.dto.physicalInventory.UpdateBatchTaskReq
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumReqBody
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PhysicalInventoryRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getLookUps(lookUpsRequest: LookUpsRequest) = apiGatewayInterface.getLookUps(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = lookUpsRequest.cusId,
        fcyId = lookUpsRequest.fcyId,
        buId = lookUpsRequest.buId,
        lookupNames = lookUpsRequest.lookupNames
    )

    suspend fun getBatchSummary(batchNumber: String?, skipBatchId: String?, countType: String?) =
        apiGatewayInterface.getBatchSummary(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            batchNumber = batchNumber,
            skipBatchId = skipBatchId,
            countType = countType
        )

    suspend fun getBatchTaskDetails(assignBatchReq: AssignBatchReq) =
        apiGatewayInterface.getBatchTaskDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            assignBatchReq = assignBatchReq
        )

    suspend fun updateBatchTask(updateBatchTaskReq: UpdateBatchTaskReq?) =
        apiGatewayInterface.updateBatchTask(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            updateBatchTaskReq = updateBatchTaskReq
        )

    suspend fun getInquiryItemInfo(itemBarcode: String) = apiGatewayInterface.getInquiryItemInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        responseFilter = "summary",
        itemBarcode = itemBarcode,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )

    suspend fun getContainerInfo(containerNumber: String, itemInfo: String) =
        apiGatewayInterface.getPalletizeContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = containerNumber,
            itemInfo = itemInfo
        )

    suspend fun validateLotOrMfgCodeRequest(itemId: Int,lotOrMfgCode: String) = apiGatewayInterface.validateLotOrMfgCodeRequest(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
        lotOrMfgCode = lotOrMfgCode,
        itemId = itemId
    )

    suspend fun validateLotNumber(request: ValidateLotNumberRequest) =
        apiGatewayInterface.validateLotNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            batchNumber = request.batchNumber,
            itemName = request.itemName,
            itemId = request.itemId,
        )

    suspend fun validateSerialNumberWithItemCode(itemId: Int, serialNumberOrItemId: String, isOutBoundOnly: Boolean) =
        apiGatewayInterface.validatePISerialNumberWithItemCode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            itemId = itemId,
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            serialNumberOrItemId = serialNumberOrItemId,
            isOutBoundOnly = isOutBoundOnly
        )

}
