package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSCReverseQTYBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.Putaway
import com.fsc.flare.source.data.dto.splitcontainerreverse.QtyBaseReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "SCReverseQTYFragment"
@AndroidEntryPoint
class SCReverseQTYFragment : BaseFragment(), FlareScannable {

    private val viewModel: SplitContainerReverseViewModel by activityViewModels()
    private lateinit var binding: FragmentSCReverseQTYBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSCReverseQTYBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etQuantity.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtQuantityResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        //set container number
        binding.tvContainerNumberValue.text = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null)
        //set SKU for reverse/ Item barcode for Forward
        if (sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString() == "R") {
            binding.wgSku.visibility = View.VISIBLE
            binding.wgItemBarcode.visibility = View.GONE
            binding.tvSKUValue.text = sharedPreferences.getString(PreferenceKeys.SC_SKU_ITEMBARCODE, null)
        } else if (sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString() == "F") {
            binding.wgSku.visibility = View.GONE
            binding.wgItemBarcode.visibility = View.VISIBLE
            binding.tvItemBarcodeValue.text = sharedPreferences.getString(PreferenceKeys.SC_SKU_ITEMBARCODE, null)
        }


        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etQuantity.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.etQuantity.isFocused && !binding.etQuantity.text.isNullOrEmpty()) {
            FlareLog.i(TAG,"Quantity field focused")
            validateQtyAPI()
        }
    }


    /**
     * method to validate QTY field from API
     */
    private fun validateQtyAPI() {
        viewModel.validateQty(
            QtyBaseReq(
                dataSource = "RF",
                putaway = Putaway(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null).toString(),
                    qty = binding.etQuantity.text.toString().toInt(),
                    channel = sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString()
                )
            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeQtyValidateObserver()
    }


    /**
     * method for qty response observer
     */
    private fun subscribeQtyValidateObserver() {
        viewModel.qtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { qtyRes ->
                        FlareLog.i(TAG, "Qty response: $response")
                        when (qtyRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "Qty response Error: ${qtyRes.statusHandler.error}")
                                showSoftKeyBoard(fragmentContext, binding.etQuantity)
                                binding.etQuantity.selectAll()
                                binding.txtQuantityResponse.text = qtyRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "Qty response Success: $qtyRes")
                                sharedPreferences.edit().putInt(PreferenceKeys.SC_QTY, binding.etQuantity.text.toString().toInt()).apply()
                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = SCReverseQTYFragmentDirections.actionSCReverseQTYFragmentToSCReverseToContainerFragment()
                                navController.navigate(action)

                            }
                            else ->
                                FlareLog.e(TAG, "Qty response error: ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Qty response error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }




    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG,"onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etQuantity.setText(scan?.barcode.toString())
                binding.etQuantity.text?.length?.let {
                    binding.etQuantity.setSelection(
                        it
                    )
                    FlareLog.i(TAG,"Quantity field focused")
                    validateQtyAPI()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.i(TAG, "onScanError: $scanRaw")
    }


}