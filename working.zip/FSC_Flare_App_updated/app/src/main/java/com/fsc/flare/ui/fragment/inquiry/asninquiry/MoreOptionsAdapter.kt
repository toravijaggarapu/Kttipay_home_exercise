package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.inquiry.asn.ASNMoreOptionsData
import com.google.android.material.textview.MaterialTextView
import java.util.*

class MoreOptionsAdapter(
    private val moreOptionsList: ArrayList<ASNMoreOptionsData>,
    private val listener: OnAdapterClickListener,
    context: Context
) : RecyclerView.Adapter<MoreOptionsAdapter.ViewHolder>() {

    companion object {
        var row_index = -1
    }

    private val mContext: Context = context

    init {
        row_index = -1
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemData: MaterialTextView = itemView.findViewById(R.id.tvOption)
        var itemLayout: ConstraintLayout = itemView.findViewById(R.id.optionsContainer)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.inflate_asn_inquiry_more_options, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item: String = moreOptionsList[position].optionText

        viewHolder.itemData.apply {
            text = item
        }
        viewHolder.itemLayout.setOnClickListener {
            row_index = position
            listener.onItemSelected(moreOptionsList[position].optionId)
            notifyDataSetChanged()
        }
        viewHolder.itemView.apply {
            if (row_index == position) {
                viewHolder.itemView.backgroundTintList =
                    ContextCompat.getColorStateList(mContext, R.color.colorAccent)
            } else {
                viewHolder.itemView.backgroundTintList =
                    ContextCompat.getColorStateList(mContext, R.color.colorPrimary)
            }
        }
    }

    override fun getItemCount(): Int {
        return moreOptionsList.size
    }

    interface OnAdapterClickListener {
        fun onItemSelected(itemId: String)
    }

}