package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryAdjustmentItemBarcodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CartonDetailsRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryAdjustmentItemBarcodeFragment"

/**
 * A simple [InventoryAdjustmentItemBarcodeFragment] class.
 */
@AndroidEntryPoint
class InventoryAdjustmentItemBarcodeFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryAdjustmentItemBarcodeBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryAdjustmentItemBarcodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryCtrAdj.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.cartonDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cartonDetails ->
                        if(cartonDetails.success){
                            viewModel.setCartonInfo(cartonDetails)
                            binding.itemBarcode.text = null
                            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                InventoryAdjustmentItemBarcodeFragmentDirections.actionInventoryAdjustmentItemBarcodeFragmentToInventoryCartonAdjustmentFragment()
                            navController.navigate(action)
                        } else {
                            binding.itemBarcodeResponse.text = resources.getString(R.string.lbl_invalid_barcode)
                            binding.itemBarcode.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.itemBarcode)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.itemBarcodeResponse.text = message
                        binding.itemBarcode.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.itemBarcode)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                binding.rootLayout.setOnTouchListener { v, event ->
                    when (event?.action) {
                        MotionEvent.ACTION_DOWN -> {
                            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                            if (binding.itemBarcode.isFocused && !binding.itemBarcode.text.isNullOrEmpty()) {
                                validateField()
                            }
                        }
                    }
                    v?.onTouchEvent(event) ?: true
                }
            }
        }

        if(binding.itemBarcode.isFocusableInTouchMode){
            showSoftKeyBoard(fragmentContext, binding.itemBarcode)
        }
        binding.itemBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.itemBarcodeResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.itemBarcode.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                if (binding.itemBarcode.isFocused && !binding.itemBarcode.text.isNullOrEmpty()) {
                    validateField()
                }
            }
            false
        }
    }

    private fun validateField() {
        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                val containerData = containerList[0]
                binding.txtContainerNumberValue.text = containerData.containerNumber
                viewModel.shipmentCartons(
                    CartonDetailsRequest(
                        obContainerId = containerData.containerId,
                        itemBarcode = binding.itemBarcode.text.toString(),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                    )
                )
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                val containerData = containerList[0]
                if (!binding.itemBarcode.text.isNullOrEmpty()) {
                    viewModel.shipmentCartons(
                        CartonDetailsRequest(
                            obContainerId = containerData.containerId,
                            itemBarcode = binding.itemBarcode.text.toString(),
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                        )
                    )
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.i(TAG, "onScanError: $scanRaw")
    }


}