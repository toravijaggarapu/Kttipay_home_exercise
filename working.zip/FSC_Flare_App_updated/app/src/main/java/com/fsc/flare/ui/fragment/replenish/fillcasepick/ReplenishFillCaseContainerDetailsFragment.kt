package com.fsc.flare.ui.fragment.replenish.fillcasepick

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishFillCaseContainerDetailBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ReplenishFillCaseContainerDetailsFragment"

/**
 * A simple [ReplenishFillCaseContainerDetailsFragment] class.
 */
@AndroidEntryPoint
class ReplenishFillCaseContainerDetailsFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishFillCaseContainerDetailBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishFillCaseContainerDetailBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "validate container called")
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()
        if (data != null) {
            binding.txtCartPalletRes.text = data.cartNbr
            if (taskData != null) {
                binding.txtTaskIDRes.text = taskData.taskId.toString()
                binding.txtItemRes.text = taskData.itemCode
                binding.txtDesRes.text = taskData.itemDescription
                binding.txtLocationRes.text = taskData.locationName
                binding.txtContainerRes.text = taskData.containerNbr
                binding.txtPickQtyRes.text = String.format("%d %s",taskData.taskQty,taskData.taskQtyUom)
            }
        }
        binding.etContainerNo.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "validate Container called")
                validateContainer()
            }
            false
        }
        binding.etContainerNo.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.containerIdResponse.text = null
            }
        })
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            val action = ReplenishFillCaseContainerDetailsFragmentDirections.actionFillCasePickContainerToSubMenu()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.subMenuFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }
    }

    private fun validateContainer() {
        if (!binding.etContainerNo.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainerNo)
            if (binding.txtContainerRes.text == binding.etContainerNo.text.toString()) {
                binding.etContainerNo.text?.clear()
                getNavigationController().navigate(R.id.action_FillCasePickContainer_to_FillCasePickLocation)
            } else {
                binding.containerIdResponse.text = getString(R.string.invalid_container)
                binding.etContainerNo.selectAll()
                showSoftKeyBoard(fragmentContext, binding.etContainerNo)
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etContainerNo.setText(scan?.barcode.toString())
            binding.etContainerNo.text?.length?.let {
                binding.etContainerNo.setSelection(it)
            }
            validateContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}