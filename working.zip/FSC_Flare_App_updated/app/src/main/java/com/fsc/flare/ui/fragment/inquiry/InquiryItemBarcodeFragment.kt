package com.fsc.flare.ui.fragment.inquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryItemBarcodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ItemBarCodeFragment"

/**
 * A simple [InquiryItemBarcodeFragment] class.
 */
@AndroidEntryPoint
class InquiryItemBarcodeFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryItemBarcodeBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryItemBarcodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()
        binding.inquiryItemBarcode.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        binding.inquiryItemBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.inquiryItemBarCodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.inquiryItemBarcode)
        if (binding.inquiryItemBarcode.isFocused && !binding.inquiryItemBarcode.text.isNullOrEmpty()) {
            FlareLog.i(TAG,"ItemBarcode field focused")
            viewModel.getInquiryItemInfo(binding.inquiryItemBarcode.text.toString())
        }
    }

    private fun subscribeObservers() {
        viewModel.itemBarcodeResponse.observe(viewLifecycleOwner) { itemInquiryResponse ->
            when (itemInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG,"itemBarcode success: $itemInquiryResponse")
                    hideProgressBar()
                    itemInquiryResponse.data?.let { itemBarcodeResponse ->
                        if (itemBarcodeResponse.items != null) {
                            if (itemBarcodeResponse.items.size == 1) {
                                binding.inquiryItemBarcode.setText(itemBarcodeResponse.items[0].itemName)
                                binding.inquiryItemBarcode.text?.length?.let {
                                    binding.inquiryItemBarcode.setSelection(it)
                                }
                                val itemBarcode = itemBarcodeResponse.items[0]
                                viewModel.setItemBarcode(itemBarcode)
                                binding.inquiryItemBarcode.text = null
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = InquiryItemBarcodeFragmentDirections.actionInquiryItemBarcodeToInquiryItemDesc()
                                navController.navigate(action)
                            } else {
                                //implement multiple item barcode logic
                                // setup the alert builder
                                val builder = AlertDialog.Builder(fragmentContext)
                                val str = "<font color='#340e5f'>" +resources.getString(R.string.lbl_select_item)+ "</font>"
                                builder.setTitle(HtmlCompat.fromHtml(str, HtmlCompat.FROM_HTML_MODE_LEGACY))
                                val items = itemBarcodeResponse.items
                                val itemsList = ArrayList<String>()
                                for (item in items) {
                                    val itemType = "${item.itemId} - ${item.description}"
                                    itemsList.add(itemType)
                                }
                                val itemsArray: Array<String> = itemsList.toTypedArray()
                                builder.setItems(itemsArray) { dialog, position ->
                                    binding.inquiryItemBarcode.setText(items[position].itemName)
                                    binding.inquiryItemBarcode.text?.length?.let {
                                        binding.inquiryItemBarcode.setSelection(it)
                                    }
                                    val itemBarcode = itemBarcodeResponse.items[position]
                                    viewModel.setItemBarcode(itemBarcode)
                                    binding.inquiryItemBarcode.text = null
                                    val navController =
                                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action = InquiryItemBarcodeFragmentDirections.actionInquiryItemBarcodeToInquiryItemDesc()
                                    navController.navigate(action)
                                }
                                // create and show the alert dialog
                                val dialog = builder.create()
                                dialog.setCancelable(false)
                                dialog.show()
                            }
                        } else {
                            binding.inquiryItemBarCodeResponse.text = getString(R.string.no_items_found)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    itemInquiryResponse.message?.let { message ->
                        binding.inquiryItemBarCodeResponse.text = message
                        FlareLog.e(TAG, "ItemInquiry Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG,"onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.inquiryItemBarcode.setText(scan?.barcode.toString())
            binding.inquiryItemBarcode.text?.length?.let {
                binding.inquiryItemBarcode.setSelection(it)
            }
            FlareLog.i(TAG,"ItemBarcode field focused")
            viewModel.getInquiryItemInfo(binding.inquiryItemBarcode.text.toString())
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG,"onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}