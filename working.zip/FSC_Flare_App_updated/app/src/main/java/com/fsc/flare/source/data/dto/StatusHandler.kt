package com.fsc.flare.source.data.dto

data class StatusHandler(
    val error: String,
    val message: String,
    val statusCode: String
)