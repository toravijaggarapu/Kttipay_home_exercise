package com.fsc.flare.ui.fragment.interleaving

import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingResponse
import com.fsc.flare.source.data.dto.interleaving.PickInfo
import com.fsc.flare.source.data.dto.interleaving.TaskInterLeavingData
import com.fsc.flare.source.repository.InterLeavingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InterLeavingExecuteTaskViewModel @Inject constructor(
    private val interLeavingRepository: InterLeavingRepository,
) : BaseViewModel() {

    private val _fetchTaskState = MutableStateFlow<PutwayToReserveTaskState?>(null)
    val fetchTaskState = _fetchTaskState.asStateFlow()

    fun callExecuteTaskService(
        scope: CoroutineScope = viewModelScope,
        endTaskRequest: ExecuteTaskRequest
    ) {

        scope.launch {
            val response = interLeavingRepository.executeInterLeavingTask(endTaskRequest)
            _fetchTaskState.emit(PutwayToReserveTaskState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.let { handleEndTaskServiceSuccessResponse(it) }
                FlareLog.i(TAG, "EndTask Success:${body()}")
            } ?: run {

                val errorMessage = handleForwardErrorResponse(
                    response.code(),
                    response.errorBody(),
                    response.message()
                )
                FlareLog.e(TAG, "EndTask Error Response: $errorMessage")
                  _fetchTaskState.emit(PutwayToReserveTaskState.ShowError(errorMessage))
            }
        }
    }

    private suspend fun handleEndTaskServiceSuccessResponse(executeTaskResponse: GetInterLeavingResponse) {
        when (executeTaskResponse.interLeavingData?.pickInfo?.taskType) {
            InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code -> {
                _fetchTaskState.emit(PutwayToReserveTaskState.EnableScanCurrentLocation(executeTaskResponse.interLeavingData))
            }
            InterLeavingTaskType.PICK_FROM_RESERVE.code -> {
                _fetchTaskState.emit(PutwayToReserveTaskState.NavigateToPickFromReserve(executeTaskResponse.interLeavingData))
            }
            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code -> {
                _fetchTaskState.emit(
                    PutwayToReserveTaskState.NavigateToPalletReplenishmentToCasePick(
                        executeTaskResponse.interLeavingData,InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.description
                    )
                )
            }
            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code ->{
                _fetchTaskState.emit(
                    PutwayToReserveTaskState.NavigateToPalletReplenishmentToCasePick(
                        executeTaskResponse.interLeavingData, InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.description
                    )
                )
            }
        }
    }
}

sealed class PutwayToReserveTaskState {
    data class ShowProgress(val show: Boolean) : PutwayToReserveTaskState()
    data class ShowError(val errorMessage: String) : PutwayToReserveTaskState()
    data class PickNextTask(val pickInfo: PickInfo) : PutwayToReserveTaskState()
    data class EnableScanCurrentLocation(val response: TaskInterLeavingData?) : PutwayToReserveTaskState()
    data class NavigateToPalletReplenishmentToCasePick(val response: TaskInterLeavingData?, val screenTitle : Int) : PutwayToReserveTaskState()
    data class NavigateToPalletReplenishmentToActive(val response: TaskInterLeavingData?, val screenTitle : Int) : PutwayToReserveTaskState()

    data class NavigateToPickFromReserve(val response: TaskInterLeavingData?) : PutwayToReserveTaskState()

}