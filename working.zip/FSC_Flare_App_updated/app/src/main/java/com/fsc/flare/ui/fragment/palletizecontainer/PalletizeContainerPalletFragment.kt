package com.fsc.flare.ui.fragment.palletizecontainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeContainerPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletResponse
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_CONCEALED
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_FACILITY
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_TRANSIT
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeContainerPalletFragment"

@AndroidEntryPoint
class PalletizeContainerPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: PalletizeContainerViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeContainerPalletBinding
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var palletizeContainerPalletResponse: PalletizeContainerPalletResponse


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        viewModel.associatedContainersIds.clear() //reset all values
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun hitApi() {
        binding.tvError.text=""
        viewModel.getPalletizePallet(
            PalletizeContainerPalletRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                palletNumber = binding.etPalletNumber.text.toString().trim(),
                ibPalletize = true
            )
        )
    }

    private fun moveToNextScreen() {
        binding.etPalletNumber.setText("") // Empty the field
        val action = PalletizeContainerPalletFragmentDirections.actionPalletizeContainerPalletFragmentToPalletizeContianerFragment()
        moveToFragment(action)
    }


    private fun containerInquiryCall() {
        if (binding.etPalletNumber.text?.trim().toString().isNotEmpty()) {
            viewModel.getPalletDetails(binding.etPalletNumber.text.toString().trim())
        }
    }


    private fun subscribeObservers() {

        viewModel.palletDetailsResp.observe(viewLifecycleOwner) { palletDetailResponse ->
            when (palletDetailResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $palletDetailResponse")
                    hideProgressBar()
                    palletDetailResponse.data?.let { palletDetailResp ->
                        val damageLocksList = listOf(DAMAGE_IN_FACILITY, DAMAGE_IN_TRANSIT, DAMAGE_IN_CONCEALED)
                        val isAllowedOnCCPendingLocation = sharedPreferencesBase.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)

                        if(palletDetailResp.success && palletDetailResp.container.isNotEmpty()){
                            if (palletDetailResp.container[0].lockCode == "CC") {
                                displayErrorMessage(getString(R.string.cycle_count_in_progress_for_given_location))
                            } else if (palletDetailResp.container[0].cyclePending == YES && !isAllowedOnCCPendingLocation) {
                                displayErrorMessage(getString(R.string.cycle_count_is_pending_for_given_location))
                            }else {
                                val palletDamageLocks = palletDetailResp.container[0].lockCodes?.map { it.code }?.intersect(damageLocksList) ?: emptyList()
                                palletizeContainerPalletResponse.palletNumber = binding.etPalletNumber.text.toString().trim()
                                viewModel.setPalletizeContainerPalletInfo(palletizeContainerPalletResponse)
                                viewModel.palletHasDamageLocks = palletDamageLocks.isNotEmpty()
                                viewModel.palletDamageLock = palletDamageLocks.toList().getOrNull(0)
                                val restrictedLockCodesMixList = getRestrictedLockCodesMixList()
                                viewModel.restrictedLockCodesMixListOnPallet = (palletDetailResp.container[0].lockCodes?.map { it.code }?.filter { it in restrictedLockCodesMixList } ?: emptyList())
                                moveToNextScreen()
                            }
                        }else{
                            displayErrorMessage(getString(R.string.invalid_container))
                        }

                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    palletDetailResponse.message?.let { message ->
                        binding.tvError.text = message
                        FlareLog.e(TAG, "container error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.palletizeContainerPalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerPalletResponse ->
                        if (containerPalletResponse.success == true) {
                            if (containerPalletResponse.palletId != null) {
                                palletizeContainerPalletResponse = containerPalletResponse
                                containerInquiryCall()
                            } else {
                                containerPalletResponse.palletNumber = binding.etPalletNumber.text.toString().trim()
                                viewModel.setPalletizeContainerPalletInfo(containerPalletResponse)
                                moveToNextScreen()
                            }
                        } else {
                            binding.tvError.text = containerPalletResponse.message
                            requestFocusInputField(binding.etPalletNumber)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvError.text = message
                        requestFocusInputField(binding.etPalletNumber)

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun getRestrictedLockCodesMixList():List<String> {
        val restrictLocksHashMap: HashMap<String, String> = Gson().fromJson(sharedPreferencesBase.getString(PreferenceKeys.LOCK_COMPARE_IN_PALLETIZE_CONT_HASH_MAP,""), object : TypeToken<HashMap<String?, String?>?>() {}.type)
        return restrictLocksHashMap.keys.toList()
    }

    private fun displayErrorMessage(message: String) {
        binding.etPalletNumber.requestFocus()
        binding.tvError.text = message
        binding.etPalletNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizeContainerPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()

        setListener()
        showSoftKeyBoard(requireContext(), binding.etPalletNumber)
    }

    private fun setListener() {
        binding.etPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.tvError.text = null
            }
        })

        binding.etPalletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etPalletNumber)
        if (!binding.etPalletNumber.text?.trim().isNullOrEmpty()) {
            FlareLog.i(TAG, "Pallet field focused")
            val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
            val palletNumber = binding.etPalletNumber.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.tvError.text = getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                hitApi()
            }
        }
        else{
            binding.tvError.text = resources.getString(R.string.lbl_enter_valid_pallet_number)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etPalletNumber.setText(scan?.barcode.toString())
            binding.etPalletNumber.text?.length?.let {
                binding.etPalletNumber.setSelection(
                    it
                )
            }
            validateField()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}