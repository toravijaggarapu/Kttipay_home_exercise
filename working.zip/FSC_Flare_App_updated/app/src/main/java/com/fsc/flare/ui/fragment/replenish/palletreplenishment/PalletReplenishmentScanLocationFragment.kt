package com.fsc.flare.ui.fragment.replenish.palletreplenishment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishmentScanLocationPageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletReplenishmentScanLocationFragment"
@AndroidEntryPoint
class PalletReplenishmentScanLocationFragment:BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: ReplenishViewModel by activityViewModels()
    lateinit var binding: FragmentReplenishmentScanLocationPageBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentReplenishmentScanLocationPageBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel

        if(sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null) == "40")
        {
            binding.tvPalletReplenishHeader.text= getString(R.string.pallet_repln_active_header)

        }else if(sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null) == "50"){
            binding.tvPalletReplenishHeader.text= getString(R.string.pallet_repln_casepick_header)
        }

        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun subscribeObservers() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationDetailsResponse ->
                        if (locationDetailsResponse.success) {
                            FlareLog.i(TAG, "locationDetailsResponse success: $locationDetailsResponse")
                            if (locationDetailsResponse.locations.isNotEmpty()) {
                                val reserveLocation = locationDetailsResponse.locations[0]
                                if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) {
                                    if (reserveLocation.lockCode == "CC") {
                                        binding.scanLocationResponse.text = getString(R.string.cycle_count_in_progress_for_given_location)
                                    } else {
                                        navigateToPallet()
                                    }
                                } else {
                                    if (reserveLocation.cycleCountPending == "Y") {
                                        binding.scanLocationResponse.text = getString(R.string.cycle_count_is_pending_for_given_location)
                                    } else {
                                        navigateToPallet()
                                    }
                                }

                            } else {
                                showErrorSnackBar("Invalid Location")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToPallet() {
        // navigate to Pallet Page
        val action = PalletReplenishmentScanLocationFragmentDirections.actionReplenishmentScanLocationFragmentToReplenishmentScanPalletFragment()
        getNavigationController().navigate(action)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Location field focused")
                    validateLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        initData()

        binding.scanLocationVal.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Location field focused")
                validateLocation()
            }
            false
        }
        binding.scanLocationVal.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.scanLocationResponse.text = null
            }
        })
    }

    private fun initData() {
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()

        if(data!=null)
        {
            if (taskData != null) {
                binding.taskId.text = taskData.taskId.toString()
                binding.itemVal.text = taskData.itemCode
                binding.locationVal.text = taskData.locationBarcode
            }
        }else
        {
            showErrorSnackBar(resources.getString(R.string.lbl_task_details_are_not_found))
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.scanLocationVal.setText(scan?.barcode.toString())
            binding.scanLocationVal.text?.length?.let {
                binding.scanLocationVal.setSelection(it)
            }
            FlareLog.i(TAG, "Scan Location field focused")
            validateLocation()
    }

    private fun validateLocation() {
        if (binding.scanLocationVal.text.toString().trim().isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.scanLocationVal)
            if(binding.scanLocationVal.text.toString().trim() == binding.locationVal.text.toString())
            {
                viewModel.validateStagingLocation(
                    LocationClassReq(
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        binding.scanLocationVal.text.toString(),
                        ""
                    )
                )
            }else
            {
                binding.scanLocationResponse.text = getString(R.string.location_mismatch)
                binding.scanLocationVal.selectAll()
            }

        }else{
            binding.scanLocationResponse.text = getString(R.string.location_required)
            binding.scanLocationVal.selectAll()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}