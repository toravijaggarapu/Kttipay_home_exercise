package com.fsc.flare.utils;

import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.inject.Inject;

public class FlareSecurityManager {

    @Inject
    public FlareSecurityManager() {}

    /*
     * PKCE involves generating a 2 challenge for identity confirmation
     * Part one is a random string using only alpha-numeric characters and -._~.
     * We achieve this by using 48 random bytes and base 64 encoding that.
     * This value is given to OKTA during the token request. OKTA then hashes this value using
     * the specified method (SHA256), comparing to the value we sent when requesting the login page.
     *
     * see https://www.oauth.com/oauth2-servers/pkce/authorization-request/
     * and https://www.oauth.com/oauth2-servers/pkce/authorization-code-exchange/
     */
    public String generateChallengeCodeVerifier() {
        SecureRandom sr = new SecureRandom();
        byte[] code = new byte[48];
        sr.nextBytes(code);
        return Base64.encodeToString(code, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    /*
     * PKCE involves generating a 2 challenge for identity confirmation
     * Part two is a base64 url safe encode of the SHA256 hash of the original challenge code.
     * This value is passed along in the initial authorization request for the login page and stored
     * by OKTA to validate the later token request
     *
     * see https://www.oauth.com/oauth2-servers/pkce/authorization-request/
     * and https://www.oauth.com/oauth2-servers/pkce/authorization-code-exchange/
     */
    public String generateChallengeCodeFromVerifier(String challengeCodeVerifier) throws NoSuchAlgorithmException {
        byte[] bytes = challengeCodeVerifier.getBytes(StandardCharsets.US_ASCII);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(bytes, 0, bytes.length);
        return Base64.encodeToString(md.digest(), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }
}
