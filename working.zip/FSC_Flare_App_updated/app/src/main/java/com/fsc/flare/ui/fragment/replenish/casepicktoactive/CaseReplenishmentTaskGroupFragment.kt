package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenishmentTaskGroupBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.TaskStatus
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenishmentTaskGroupFragment::class.java.simpleName.toString()
@AndroidEntryPoint
class CaseReplenishmentTaskGroupFragment: BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    lateinit var binding: FragmentCaseReplenishmentTaskGroupBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        if (viewModel.taskGroupCodeOptions.value != null) {
            binding.replenTaskGroupDropDown.setOptions(viewModel.taskGroupCodeOptions.value)
        }
        super.onResume()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getTaskGroups()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentCaseReplenishmentTaskGroupBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        binding.tvCaseReplenishHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        observeTaskGroupResponse()
        observeReplenCaseToActiveTaskPickResponse()
    }

    private fun observeReplenCaseToActiveTaskPickResponse() {
        viewModel.replenCaseTaskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplen Response: $taskReplenResponse")
                        if (taskReplenResponse.success) {
                            val cartNbr = taskReplenResponse.cartNbr
                            val taskDetails = taskReplenResponse.taskDetails
                            when {
                                !cartNbr.isNullOrEmpty() && taskDetails != null && (taskDetails.taskStatus == TaskStatus.TASK_ASSIGNED.value || taskDetails.taskStatus == TaskStatus.TASK_IN_PROGRESS.value) -> {
                                    viewModel.apply {
                                        _pickCartNbr = cartNbr
                                        _replenTaskDetails.value = taskDetails
                                        _scannedContainerList = _replenTaskDetails.value?.pickedContainers?:_scannedContainerList
                                    }
                                    getNavigationController().navigate(CaseReplenishmentTaskGroupFragmentDirections.actionCaseReplenishmentTaskGroupToCaseReplenTaskDetails())
                                }
                                !cartNbr.isNullOrEmpty() && taskDetails != null && taskDetails.taskStatus == TaskStatus.TASK_INTERIM_UPDATE.value -> {
                                    viewModel.apply {
                                        _pickCartNbr = cartNbr
                                        _replenTaskDetails.value = taskDetails
                                        _scannedContainerList = _replenTaskDetails.value?.pickedContainers?:_scannedContainerList
                                    }
                                    getNavigationController().navigate(CaseReplenishmentTaskGroupFragmentDirections.actionCaseReplenishmentTaskGroupToCaseReplenDropCaseScan())
                                }
                                cartNbr.isNullOrEmpty() -> {
                                    getNavigationController().navigate(CaseReplenishmentTaskGroupFragmentDirections.actionCaseReplenishmentTaskGroupToCaseReplenBlindPallet())
                                }
                                else -> {
                                    showErrorSnackBar("No Task Details Found")
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(
                            TAG,
                            "taskReplen error: $message"
                        )
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun observeTaskGroupResponse() {

        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrp success: $taskGroupResponse")
                        val taskGroupDescList = ArrayList<String>()
                        val taskGroups = ArrayList<TaskGroup>()
                        taskGroupResponse.taskGroups?.forEach { lookup ->
                            taskGroupDescList.add(lookup.description)
                            taskGroups.add(lookup)
                        }
                        viewModel._taskGroupCodeOptions.value = taskGroupDescList
                        viewModel._taskGroupList.value = taskGroups
                        binding.replenTaskGroupDropDown.setOptions(taskGroupDescList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.replenTaskGroupDropDown.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            val taskGroups = viewModel.taskGroupList.value
            taskGroups?.forEach { lookupCode ->
                if (lookupCode.description == isUpdated) {
                    sharedPreferences.edit().putString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP, isUpdated).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_CODE, lookupCode.code).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, lookupCode.allocationType).apply()
                }
            }
            assignPickTask()
        }
    }

    private fun assignPickTask() {
        viewModel.getReplenCaseToActivePickTask(
            TaskReplenCartRequest(
                sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_CODE, null)!!,
            )
        )
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

}