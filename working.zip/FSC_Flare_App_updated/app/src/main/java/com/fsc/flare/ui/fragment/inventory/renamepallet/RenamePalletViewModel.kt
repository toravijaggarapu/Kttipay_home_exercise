package com.fsc.flare.ui.fragment.inventory.renamepallet

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventorymanagement.PalletDetailData
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletRequest
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletResponse
import com.fsc.flare.source.repository.RenamePalletRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "RenamePalletViewModel"

@HiltViewModel
class RenamePalletViewModel @Inject constructor(
    private val renamePalletRepository: RenamePalletRepository
) : BaseViewModel() {

    val palletDetailResponse: MutableLiveData<Resource<CaseTransferContainerResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val renamePalletResponse: MutableLiveData<Resource<RenamePalletResponse>> = SingleLiveEvent()

    /**
     * method to get pallet details
     */
    fun getPalletDetail(palletNumber: String, transferType: String) = viewModelScope.launch {
        palletDetailResponse.postValue(Resource.Loading())
        val response = renamePalletRepository.palletDetailValidate(palletNumber, transferType)
        palletDetailResponse.postValue(handlePalletDetailResponse(response))
    }

    /**
     * method to handle pallet detail response
     */
    private fun handlePalletDetailResponse(response: Response<CaseTransferContainerResponse>): Resource<CaseTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Pallet Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to generate new pallet
     */
    fun newPalletNumberGenerate() = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = renamePalletRepository.generatePalletCaseNumber()
        newPalletDetailResponse.postValue(handleNewPalletNumberGenerateResponse(response))
    }

    /**
     * method to handle new pallet response
     */
    private fun handleNewPalletNumberGenerateResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerate Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to rename pallet
     */
    fun renamePalletNumberCall(renamePalletRequest: RenamePalletRequest) = viewModelScope.launch {
        renamePalletResponse.postValue(Resource.Loading())
        val response = renamePalletRepository.renamePalletNumber(renamePalletRequest)
        renamePalletResponse.postValue(handleRenamePalletNumberResponse(response))
    }

    /**
     * method to handle rename pallet response
     */
    private fun handleRenamePalletNumberResponse(response: Response<RenamePalletResponse>): Resource<RenamePalletResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletRenameResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletRename Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * variable to save scanned pallet detail to display in detail view
     */
    private var palletDetailData = MutableLiveData<PalletDetailData>()

    fun setPalletDetailData(detailData: PalletDetailData) {
        palletDetailData.value = detailData
    }

    fun getPalletDetailData(): PalletDetailData {
        return palletDetailData.value!!
    }
}