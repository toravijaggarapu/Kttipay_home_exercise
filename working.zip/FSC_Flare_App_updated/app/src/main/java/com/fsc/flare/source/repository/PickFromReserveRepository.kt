package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoValidateQtyRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteRequestTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoPickReverseRequest
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumReqBody
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class PickFromReserveRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getTaskGroups(allocationType: String) = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = allocationType.trim()
    )

    suspend fun getTaskPick(taskPickReq: TaskPickReq) = apiGatewayInterface.getTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
          sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickReq = taskPickReq
    )

    suspend fun taskReservePickComplete(reservePickCompleteRequest: ReservePickCompleteRequest) =
        apiGatewayInterface.taskReservePickComplete(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            reservePickCompleteRequest = reservePickCompleteRequest
        )

    suspend fun reservepickstage() =
        apiGatewayInterface.reservepickstage(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        )

    suspend fun reservepickstageupdate(reservePickStageRequest: ReservePickStageRequest) =
        apiGatewayInterface.reservepickstageupdate(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            reservePickStageRequest = reservePickStageRequest
        )

    suspend fun tivoValidateQty(tivoValidateQtyRequest: TivoValidateQtyRequest) =
        apiGatewayInterface.tivoValidateQty(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = tivoValidateQtyRequest.custId,
            buId = tivoValidateQtyRequest.buId,
            fcyId = tivoValidateQtyRequest.fcyId,
            qty = tivoValidateQtyRequest.qty,
            palletQty = tivoValidateQtyRequest.palletQty,
            caseQty = tivoValidateQtyRequest.caseQty,
            locationBarCode = tivoValidateQtyRequest.locationBarCode,
            transactionIdentifier = tivoValidateQtyRequest.transactionIdentifier
        )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )


    suspend fun palletPickReserve(palletPickFromReserveRequest: PalletPickFromReserveRequest) =
        apiGatewayInterface.palletPickReserveComplete(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            palletPickFromReserveRequest = palletPickFromReserveRequest
        )

    suspend fun unitPickComplete(tivoUnitPickCompleteRequest: TivoUnitPickCompleteRequest) =
        apiGatewayInterface.unitPickComplete(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            tivoUnitPickCompleteRequest = tivoUnitPickCompleteRequest
        )

    suspend fun validateSerialNumber(serialNumReqBody: SerialNumReqBody) =
        apiGatewayInterface.validateSerialNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            buId = serialNumReqBody.buId,
            custId = serialNumReqBody.custId,
            fcyId = serialNumReqBody.fcyId,
            asnId = serialNumReqBody.asnId,
            itemId = serialNumReqBody.itemId,
            serialNum = serialNumReqBody.serialNum
        )

    suspend fun getTivoTaskPick(taskPickReq: TaskPickReq) = apiGatewayInterface.tivoGetTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickReq = taskPickReq
    // test comment
    )

    suspend fun validateInventoryTaskSerialNumber(inventorySerialNumberRequest: InventoryTaskSerialNumberRequest) =
        apiGatewayInterface.validateInventoryTaskSerialNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNumber = inventorySerialNumberRequest.containerNumber,
            palletNumber = inventorySerialNumberRequest.containerNumber,
            containerSerialNumber = inventorySerialNumberRequest.containerSerialNumber,
            taskUom = inventorySerialNumberRequest.taskUom,
            custId = inventorySerialNumberRequest.custId,
            fcyId = inventorySerialNumberRequest.fcyId,
            buId = inventorySerialNumberRequest.buId,
            userDirected = inventorySerialNumberRequest.userDirected,
            outBoundOnly = inventorySerialNumberRequest.outBoundOnly
        )

    suspend fun getInventoryLookups(inventoryLookupsRequest: InventoryLookupsRequest) = apiGatewayInterface.getInventoryLookups(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = inventoryLookupsRequest.fcyId,
        cusId = inventoryLookupsRequest.cusId,
        buId = inventoryLookupsRequest.buId,
        lookupNames = inventoryLookupsRequest.lookupNames,
    )

    /* ------------------- Tivo pick from reserve --------------------*/

    suspend fun validatePalletNumberTivoPFR(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validatePalletNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            palletNumber = request.palletNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected
        )

    suspend fun validatePalletSerialNumberTivoPFR(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validatePalletSerialNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            containerSerialNumber = request.containerSerialNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected,
            palletNumber = request.palletNumber?:""
        )

    suspend fun validatePalletNumberTivoPFRUserDirected(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validatePalletNumberTivoPFRUserDirected(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            containerSerialNumber = request.containerSerialNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected,
            taskDetailId = request.taskDetailId ?: 0
        )

    suspend fun validatePalletSerialNumberTivoPFRUserDirected(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validateContainerNumberTivoPFRUserDirected(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            containerNumber = request.containerNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected,
            taskDetailId = request.taskDetailId ?: 0,
        )

    suspend fun validateContainerNumberTivoPFR(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validateContainerNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            containerNumber = request.containerNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected,
            palletNumber = request.palletNumber?:""
        )

    suspend fun validateContainerSerialNumberTivoPFR(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest) =
        apiGatewayInterface.validateContainerSerialNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            containerSerialNumber = request.containerSerialNumber ?: "",
            taskUom = request.taskUom,
            userDirected = request.userDirected,
            palletNumber = request.palletNumber ?: "",
            containerNumber = request.containerNumber ?: ""
        )

    suspend fun markTaskCompleteTivPFRComplete(request: MarkTaskCompleteRequestTivoPFR) =
        apiGatewayInterface.markTaskCompleteTivoPFRPick(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            request = request
        )

    suspend fun validateLotNumberTivoPFR(request: ValidateLotNumberRequest) =
        apiGatewayInterface.validateLotNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            batchNumber = request.batchNumber,
            itemName = request.itemName,
            itemId = request.itemId,
        )

    suspend fun validateLotNumberPFR(request: LotNumReqBody) =
        apiGatewayInterface.validateLotNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "null")!!,
            custId = request.custId,
            fcyId = request.fcyId,
            buId = request.buId,
            lotNumber = request.lotNumber,
            asnId = request.asnId,
            itemId = request.itemId,
            lotNumberCheck = true
        )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun getItemAttrTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun validateLocationDetails(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = apiGatewayInterface.validateUPCorSLP(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        itemCode = itemCode,
        upcOrSlp = upcOrSlp
    )

    suspend fun ltlSkipTask(skipPickCartReq: SkipPickCartReq) = apiGatewayInterface.ltlSkipTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = skipPickCartReq.fcyId,
        custId = skipPickCartReq.custId,
        buId = skipPickCartReq.buId,
        allocationType = skipPickCartReq.allocationType,
        skipTaskId = skipPickCartReq.skipTaskId,
        skipTaskDetId = skipPickCartReq.skipTaskDetId,
        isLTLcubing = skipPickCartReq.isLTLcubing
    )

    suspend fun getInventoryReasonCodes() = apiGatewayInterface.getInventoryReasonCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
    )

    suspend fun getKitStagingLocation(psuedoOrderId:Int, orderType: String) = apiGatewayInterface.getOrderProcessLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        psuedoOrderId = psuedoOrderId,
        orderType = orderType
    )
    suspend fun validatePalletOverride(validatePalletOverrideRequest : ValidatePalletOverrideRequest) =
        apiGatewayInterface.validatePalletOverride(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            validatePalletOverrideRequest = validatePalletOverrideRequest
        )
    suspend fun generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest : CycleCountTriggerRequest, locationId: Long) =
        apiGatewayInterface.generateCycleCountToVerifyZeroLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            locationId = locationId,
            cycleCountTriggerRequest = cycleCountTriggerRequest
        )

    suspend fun zeroLocationPromptCall(locationId: Long, skipPalletId: List<Long>) = apiGatewayInterface.zeroLocationPromptCall(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        location_id = locationId,
        skip_pallet_id = skipPalletId,
    )

    /* ------------------- Tivo pick from reserve END HERE --------------------*/

}