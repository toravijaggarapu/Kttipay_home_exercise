package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.masterpalletrepack.*
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class MasterPalletRepackRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {


    suspend fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) = apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigRequest.fcyId,
        page = printerConfigRequest.page,
        pageLimit = printerConfigRequest.pageLimit,
        printerType = printerConfigRequest.printerType
    )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun generatePalletCaseNumber(type: String) =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = type
        )

    suspend fun validateContainer(containerNumber: String, transferType: String) =
        apiGatewayInterface.caseTransferValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            container = containerNumber,
            transferType = transferType
        )

    suspend fun validateItemCode(itemCode: String) =
        apiGatewayInterface.validateItemCode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            itemCode = itemCode
        )

    suspend fun validateLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun validateTempTable(palletNumber: String, containerNumber: String) =
        apiGatewayInterface.masterPalletRepackValidateTempTable(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            pallet = palletNumber,
            container = containerNumber
        )

    suspend fun postTempContainer(palletRepackPostRequest: PalletRepackPostRequest) =
        apiGatewayInterface.masterPalletRepackPostTempTable(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletRepackPostRequest = palletRepackPostRequest
        )

    suspend fun printContainerLabelInfo(printContainerLabelRequest: PrintContainerLabelRequest) =
        apiGatewayInterface.masterPalletRepackPrintContainerLabel(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            printContainerLabelRequest = printContainerLabelRequest
        )

    suspend fun getMPRTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun submitMPR(mprSubmitRequest: MPRSubmitRequest) = apiGatewayInterface.masterPalletRepackSubmit(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        mprSubmitRequest = mprSubmitRequest
    )
}