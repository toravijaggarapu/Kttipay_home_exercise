package com.fsc.flare.ui.fragment.pickingforward

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBuildCartSlotBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.BuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipBuildCartReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "BuildCartSlotFragment"
const val BUILD_CART_REPLEN_PENDING_ERR = "BUILD-CART-REPLEN-PENDING-ERR"

@AndroidEntryPoint
class BuildCartSlotFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentBuildCartSlotBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBuildCartSlotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPickingBuildCart.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            if (!isProgressBarVisible()) {
                getNavigationController().popBackStack()
            }
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Slot field focused")
                    // taskBuildCart()
                    validateSlot()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                binding.taskPriority.text = taskData.priority
                binding.taskId.text = taskData.taskId.toString()
                binding.txtToteRes.text = sharedPreferences.getString(PreferenceKeys.PICKING_TOTE_NBR, "")
                binding.carton.text = if (taskData.cartonNumber != null) taskData.cartonNumber else taskData.containerNbr
                if(taskData.cartonSize!=null){
                    binding.cartonSizeVal.text = taskData.cartonSize
                }
            }
        }
        binding.etSlot.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Slot field focused")
                //     taskBuildCart()
                validateSlot()
            }
            false
        }
        binding.etSlot.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.txtSlotRes.text = ""
            }
        })
        binding.skipCart.setOnClickListener {
            FlareLog.i(TAG, "Skipcart clicked")
            if (data != null) {
                viewModel.buildSkipCart(
                        SkipBuildCartReq(
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                binding.cart.text.toString(),
                                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                                sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")!!,
                                skipTaskId = binding.taskId.text.toString(),
                                skipTaskDetId = "",
                                isLTLcubing = viewModel.isLTLCubingEnabled,
                                orderType = viewModel.orderType
                        )
                )
            }
        }
    }

    private fun validateSlot() {
        if(isProgressBarVisible()){
            return
        }
        if (binding.etSlot.text.toString().trim().isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etSlot)
            val data = viewModel.getPickTask()
            val taskData = viewModel.getPickTaskDetails()
            if (data != null) {
                if (taskData != null) {
                    viewModel.validateSlot(
                        BuildCartReq(
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskId = taskData.taskId,
                            taskDetId = taskData.taskDetId,
                            cartId = data.cartId,
                            cartNumber = data.cartNbr,
                            toteNumber = binding.txtToteRes.text.toString(),
                            slotNumber = binding.etSlot.text.toString(),
                            allocationType = taskData.allocationType,
                            isLTLcubing = viewModel.isLTLCubingEnabled
                        )
                    )
                }
            }
        } else {
            binding.txtSlotRes.text = getString(R.string.slot_required)
        }
    }

    private fun taskBuildCart() {
        if (!binding.etSlot.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etSlot)
          //  sharedPreferences.edit().putString(PreferenceKeys.PickingForward.SLOT_INPUT, binding.etSlot.text.toString()).apply()
            val data = viewModel.getPickTask()
            val taskData = viewModel.getPickTaskDetails()
            if (data != null) {
                if (taskData != null) {
                    viewModel.taskBuildCart(
                        BuildCartReq(
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskId = taskData.taskId,
                            taskDetId = taskData.taskDetId,
                            cartId = data.cartId,
                            cartNumber = data.cartNbr,
                            toteNumber = binding.txtToteRes.text.toString(),
                            slotNumber = binding.etSlot.text.toString(),
                            allocationType = taskData.allocationType,
                            isLTLcubing = viewModel.isLTLCubingEnabled,
                            orderType = viewModel.orderType
                        )
                    )
                }
            }
        } else {
            binding.txtSlotRes.text = getString(R.string.slot_required)
        }
    }
    private fun subscribeObservers() {
        viewModel.taskBuildCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskBuildCartResponse ->
                        FlareLog.i(TAG, "taskBuildCart Response: $response")
                        if (taskBuildCartResponse.taskDetails != null) {
                            viewModel.setPickTaskDetails(taskBuildCartResponse.taskDetails)
                            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action = BuildCartSlotFragmentDirections.actionBuildCartSlotFragmentToBuildCartToteFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
                            navController.navigate(action, navOptions)
                        } else {
                            val tskData = viewModel.getPickTask()
                            viewModel.pickEndCart(
                                EndPickCartReq(
                                    allocationType = tskData?.taskDetails?.allocationType?.toIntOrNull() ?: -1,
                                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                    pickCartNbr = binding.cart.text.toString(),
                                    cartId = tskData?.cartId,
                                    isLTLcubing = viewModel.isLTLCubingEnabled
                                )
                            )
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskBuildCart error: $message")
                        binding.skipCart.visibility = View.GONE
                        if (message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == BUILD_CART_REPLEN_PENDING_ERR) {
                                    binding.skipCart.visibility = View.VISIBLE
                                    // show dialog
                                    val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                                    //set title for alert dialog
                                    builder.setTitle("")
                                    //set message for alert dialog
                                    builder.setMessage(msgArray[1])

                                    //performing positive action
                                    builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { _, _ ->
                                        val data = viewModel.getPickTask()
                                        val taskData = viewModel.getPickTaskDetails()
                                        if (data != null) {
                                            if (taskData != null) {
                                                viewModel.taskBuildCart(
                                                    BuildCartReq(
                                                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                        taskId = taskData.taskId,
                                                        taskDetId = taskData.taskDetId,
                                                        cartId = data.cartId,
                                                        cartNumber = data.cartNbr,
                                                        toteNumber = binding.txtToteRes.text.toString(),
                                                        slotNumber = binding.etSlot.text.toString(),
                                                        allocationType = taskData.allocationType,
                                                        isLTLcubing = viewModel.isLTLCubingEnabled,
                                                        skipReplenBuildCartValidation = true,
                                                        orderType = viewModel.orderType
                                                    )
                                                )
                                            }
                                        }
                                    }
                                    //performing negative action
                                    builder.setNegativeButton(resources.getString(R.string.alert_button_cancel)) { dialogInterface, _ ->
                                        dialogInterface.dismiss()
                                    }
                                    // Create the AlertDialog
                                    val alertDialog: MaterialAlertDialogBuilder = builder
                                    // Set other dialog properties
                                    alertDialog.setCancelable(false)
                                    alertDialog.show()
                                } else {
                                    displayErrorMessage(msgArray[1])
                                }
                            }  else {
                                displayErrorMessage(message)
                            }
                        } else {
                            displayErrorMessage(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.validateSlotResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateSlotResponse ->
                        FlareLog.i(TAG, "validate Slot Response: $response")

                        if (validateSlotResponse.success != null && validateSlotResponse.success)
                        {
                            sharedPreferences.edit().putString(PreferenceKeys.PickingForward.SLOT_INPUT, binding.etSlot.text.toString()).apply()
                            taskBuildCart()
                        }else
                        {
                            if(validateSlotResponse.message!=null)
                            {
                                showErrorSnackBar(validateSlotResponse.message)
                            }else
                            {
                                showErrorSnackBar(resources.getString(R.string.lbl_validate_slot_failed))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "validate Slot error: $message")
                        binding.txtSlotRes.text = message
                        binding.etSlot.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etSlot)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.endPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endPickCartResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (endPickCartResponse.success != null && endPickCartResponse.success) {
                            FlareLog.i(TAG, "endPickCart success: $endPickCartResponse")
                            if (endPickCartResponse.taskDetails != null) {
                                viewModel.updateOrderType(endPickCartResponse.orderType)
                                viewModel.setPickTaskDetails(endPickCartResponse.taskDetails)
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartSlotFragmentDirections.actionBuildCartSlotFragmentToPickCartLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else if (endPickCartResponse.promptStage != null && endPickCartResponse.promptStage) {
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartSlotFragmentDirections.actionBuildCartSlotFragmentToPickingStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickingStagingLocationFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else {
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartSlotFragmentDirections.actionBuildCartSlotFragmentToBuildCartToteFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartToteFragment, true).build()
                                navController.navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                FlareLog.e(TAG, "endPickCart error: ${msgArray[1]}")
                                showErrorSnackBar(msgArray[1])
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                binding.taskId.text = skipCartResponse.taskDetails.taskId.toString()
                                binding.carton.text = skipCartResponse.taskDetails.containerNbr
                                getNavigationController().popBackStack()
                            } else {
                                skipCartResponse.message?.let { showErrorSnackBar(it) }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.txtSlotRes.text = message
        binding.etSlot.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etSlot)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        binding.etSlot.setText(scan?.barcode.toString())
        binding.etSlot.text?.length?.let {
            binding.etSlot.setSelection(it)
        }
        FlareLog.i(TAG, "Slot field focused")
        validateSlot()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}