package com.fsc.flare.utils

import android.accounts.NetworkErrorException
import android.util.MalformedJsonException
import com.google.gson.JsonSyntaxException
import retrofit2.HttpException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object ExceptionUtil {

    /**
     *Handle the exception and snack bar will prompt the error message
     */
    fun catchException(e: Throwable): String {
        e.printStackTrace()
        when (e) {
            is HttpException -> {
                return "Network error"
            }
            is SocketTimeoutException -> {
                return "Request call timeout error"
            }
            is UnknownHostException, is NetworkErrorException -> {
                return "Network connection failure. Check your network connection!"
            }
            is MalformedJsonException, is JsonSyntaxException -> {
                return "Failed to parse response"
            }
            is InterruptedIOException -> {
                return "Server connection interrupted, Please try again later"
            }
            is ConnectException -> {
                return "Failed to connect to the server"
            }
            else -> {
                return Constants.COMMON_ERROR_MESSAGE
            }
        }
    }
}