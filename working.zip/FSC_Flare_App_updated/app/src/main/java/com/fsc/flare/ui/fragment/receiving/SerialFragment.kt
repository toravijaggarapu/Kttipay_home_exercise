package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumReqBody
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumber
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SerialFragment"

/**
 * A simple [SerialFragment] class.
 */
@AndroidEntryPoint
class SerialFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var serialListAdapter: SerialAdapter

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentSerialBinding
    private var serialList = ArrayList<String>()
    private var count = 0
    private val serialNumberList = mutableListOf<SerialNumber>()
    lateinit var cb1: CustomVisibilityCallback
    private val serialNumberExists = "SERIAL_NUMBER_EXISTS"
    private val newSerialNumber = "NEW_SERIAL_NUMBER"

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeSerialValidationObserver()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (sharedPreferences.getInt(PreferenceKeys.Item.SCANNED_SERIAL_VAL, -1) > 0) {
            count = sharedPreferences.getInt(PreferenceKeys.Item.SCANNED_SERIAL_VAL, -1)
            binding.tvSerialValue.text = count.toString()
            binding.tvSerialNumber.visibility = View.GONE
            binding.etSerialNumber.visibility = View.GONE
            binding.tvSerialNumberResponse.visibility = View.GONE
        } else {
            binding.tvSerialNumber.visibility = View.VISIBLE
            binding.etSerialNumber.visibility = View.VISIBLE
            binding.tvSerialNumberResponse.visibility = View.VISIBLE
        }

        //set ItemBarcode and serial value
        val item = viewModel.getItem()
        binding.tvItemBarcodeValue.text = item.itemBarCode
        binding.tvSerialValue.text = String.format("%d/%s",count,sharedPreferences.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, null))

        setupRecyclerView()

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    super.onTouch(v, event)
                    if (binding.etSerialNumber.isFocused && binding.etSerialNumber.text.toString().trim().isNotEmpty()) {
                        validateSerialNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerialNumber.setOnEditorActionListener { v, actionId, event ->
            super.onEditorAction(v, actionId, event)
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                if (binding.etSerialNumber.isFocused && binding.etSerialNumber.text.toString().trim().isNotEmpty()) {
                    validateSerialNumber()
                }
            }
            false
        }
        binding.etSerialNumber.onFocusChangeListener = this
    }

    /**
     * method to verify serial number from API
     */
    private fun validateSerialNumber() {
        /* itemId = 66486, viewModel.getItem().itemId*/
        FlareLog.i(TAG, "SerialNo field focused")
        hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
        viewModel.validateSerialNumber(
            SerialNumReqBody(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                asnId = sharedPreferences.getInt(PreferenceKeys.RECEVEING_ASN_ID, -1),
                itemId = viewModel.getItem().itemId,
                serialNum = binding.etSerialNumber.text.toString().trim()
            )
        )
    }

    /**
     * method to observe serial validation response
     */
    private fun subscribeSerialValidationObserver() {
        viewModel.serialValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { serialValidationResponse ->
                        FlareLog.i(TAG, "serialValidation Response: $serialValidationResponse")
                        if (serialValidationResponse!!.success) {
                            FlareLog.i(TAG, "serialValidation Success: $serialValidationResponse")
                            if (!serialList.contains(binding.etSerialNumber.text.toString().trim())) {
                                if (serialValidationResponse.message != null) {
                                    showSuccessSnackBar(getString(R.string.serial_number_is_validated))
                                }
                                serialList.add(binding.etSerialNumber.text.toString().trim())
                                addSerialNumberToSerialList(binding.etSerialNumber.text.toString().trim(), serialValidationResponse.messageCode)
                                serialListAdapter.notifyDataSetChanged()
                                binding.etSerialNumber.text = null
                                count++
                                binding.tvSerialValue.text = String.format("%d/%s",count,sharedPreferences.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, null))
                                if (count == sharedPreferences.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, null)!!.toInt()) {
                                    binding.etSerialNumber.isEnabled = false
                                    sharedPreferences.edit().putInt(PreferenceKeys.Item.SCANNED_SERIAL_VAL, count).apply()
                                    count = 0
                                    saveSerialListToSharedPref()
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        val action = SerialFragmentDirections.actionSerialFragmentToStatusFragment()
                                        getNavigationController().navigate(action)
                                    }, 500)
                                }
                            } else {
                                showErrorSnackBar(getString(R.string.duplicate_serial))
                            }
                        } else {
                            serialValidationResponse.message?.let {
                                showErrorSnackBar(serialValidationResponse.message)
                            }.run {
                                if(serialValidationResponse.message == null) {
                                    FlareLog.i(TAG, "serialValidation error: $serialValidationResponse")
                                    showErrorSnackBar(getString(R.string.invalid_serial))
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        showErrorSnackBar(message!!)
                    }
                }
            }
        }
    }

    /**
     * method to save serial list to shared preferences
     */
    private fun saveSerialListToSharedPref() {
        val json = Gson().toJson(serialNumberList)
        sharedPreferences.edit().putString(PreferenceKeys.SERIAL_NUM_LIST, json).apply()
    }

    /**
     * method to add valid serial numbers to main serial list
     */
    private fun addSerialNumberToSerialList(serialNum: String, message: String) {
        when (message) {
            serialNumberExists -> {
                val serialNumber = SerialNumber(
                    serialNumber = serialNum, captureNew = false
                )
                serialNumberList.add(serialNumber)
            }
            newSerialNumber -> {
                val serialNumber = SerialNumber(
                    serialNumber = serialNum, captureNew = true
                )
                serialNumberList.add(serialNumber)
            }
        }
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = SerialAdapter(serialList)
        binding.rvSerial.adapter = serialListAdapter
    }

    /**
     * method to hide progressbar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    /**
     * method to show progressbar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etSerialNumber.setText(scan?.barcode.toString())
        binding.etSerialNumber.text?.length?.let {
            binding.etSerialNumber.setSelection(
                it
            )
            FlareLog.i(TAG, "SerialNumber field focused")
            validateSerialNumber()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}