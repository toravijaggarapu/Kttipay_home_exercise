package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentObIbContainerTransformBinding
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonResponse
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = OBIBContainerTransformFragment::class.java.simpleName.toString()
/**
 *  [OBIBContainerTransformFragment] class.
 */
@AndroidEntryPoint
class OBIBContainerTransformFragment : BaseFragment() {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentObIbContainerTransformBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentObIbContainerTransformBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpViews()
        subscribeObservers()
    }

    /**
     * Function to set up views with data
     */
    private fun setUpViews() {
        val obCartonDetails = sharedViewModel.obCartonDetails

        obCartonDetails?.let { obCarton ->
            binding.tvObContainerIdValue.text = obCarton.containerNbr
            binding.tvObCartonStatusValue.text = obCarton.statusDesc
            obCarton.itemDetails?.first()?.let { item ->
                binding.tvItemCodeValue.text = item.itemCode
                binding.tvItemDescriptionValue.text = item.itemDesc
            }
            binding.btnTransformObToIb.setOnClickListener {
                viewModel.transformObToIbCartonRequest(
                    action = OBIBTransformations.TRANSFORM.type,
                    containerId = obCarton.containerId ?: 0
                )
            }
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeTransformObToIbCartonResponse()
    }

    /**
     * Function to observe transform OB to IB Carton response
     */
    private fun observeTransformObToIbCartonResponse() {
        viewModel.obToIbCartonTransformResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleTransformObToIbCartonSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleTransformObToIbCartonErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Transform OB to IB Carton error response
     */
    private fun handleTransformObToIbCartonErrorResponse(message: String?) {
        message?.let {
            showErrorSnackBar(message = message)
        }
    }

    /**
     * Function to handle transform OB to IB Carton success response
     */
    private fun handleTransformObToIbCartonSuccessResponse(response: TransformObToIbCartonResponse?) {
        response?.let {
            if (response.success) {
                if(response.taskMessageCode == Constants.TSK_CREATE_SUCCESS) {
                    displayTaskCreateDialog()
                } else {
                    navigateToCartScreen()
                }
            }
        }
    }

    /**
     * Function to display task create dialog
     */
    private fun displayTaskCreateDialog() {
        showAlertDialog(
            title = "",
            message = getString(R.string.lbl_transform_inv_task_created),
            onPositiveClick = {
                navigateToCartScreen()
            }
        )
    }

    /**
     * Nav Handler to Cart Screen
     */
    private fun navigateToCartScreen() {
        val action = OBIBContainerTransformFragmentDirections.actionObIbContainerTransformFragmentToScanObContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }
}
