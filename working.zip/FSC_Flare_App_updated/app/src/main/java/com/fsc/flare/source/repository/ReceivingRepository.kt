package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberASNRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.receiving.ExitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockRequest
import com.fsc.flare.source.data.dto.receiving.RCSubmitReceivingLPNRequest
import com.fsc.flare.source.data.dto.receiving.RCValidateLPNRequest
import com.fsc.flare.source.data.dto.receiving.ReceivingASNRequest
import com.fsc.flare.source.data.dto.receiving.ReceivingDockDoorRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.ValidateLotNumberRequestFromLotMaster
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.CriteriaFirstInspectionRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentRequest
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.location.DockDoorLocationRequest
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumReqBody
import com.fsc.flare.source.data.dto.receivingpallet.EndReceiving
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReceivingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getLocationId(dockDoorLocationRequest: DockDoorLocationRequest) =
        apiGatewayInterface.getDockDoorLocationId(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            facility = dockDoorLocationRequest.facility,
            locationId = dockDoorLocationRequest.locationId,
            barcode = dockDoorLocationRequest.barcode,
            locationClass = dockDoorLocationRequest.locationClass
        )

    suspend fun getASN(packageInboundShipmentRequest: PackageInboundShipmentRequest) =
        apiGatewayInterface.getASN(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            responseFilter = packageInboundShipmentRequest.responseFilter,
            customerId = packageInboundShipmentRequest.customerId,
            locBarcode = packageInboundShipmentRequest.locBarcode,
            fcyId = packageInboundShipmentRequest.fcyId
        )

    suspend fun getItems(packageItemRequest: PackageItemRequest) =
        apiGatewayInterface.getItems(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            responseFilter = packageItemRequest.responseFilter,
            customerId = packageItemRequest.customerId.toString(),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
            page = packageItemRequest.page,
            itemBarcode = packageItemRequest.itemBarcode,
            itemId = ""
        )

    suspend fun getItemRecallLock(itemRecallLockRequest: ItemRecallLockRequest) =
        apiGatewayInterface.getItemRecallLock(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = itemRecallLockRequest.custId,
            buId = itemRecallLockRequest.buId,
            fcyId = itemRecallLockRequest.fcyId,
            itemCode = itemRecallLockRequest.itemCode,
            asnNumber = itemRecallLockRequest.asnNumber,
            lotNumber = itemRecallLockRequest.lotNumber,
            coo = itemRecallLockRequest.coo,
            invType = itemRecallLockRequest.invType,
            vendorName = itemRecallLockRequest.vendorName,
            expiryDate = itemRecallLockRequest.expiryDate,
            status = arrayListOf("1")
        )

    suspend fun submitReceiving(submitReceivingRequest: SubmitReceivingRequest) =
        apiGatewayInterface.submitReceiving(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            submitReceivingRequest = submitReceivingRequest
        )

    suspend fun exitReceiving(exitReceivingRequest: ExitReceivingRequest) =
        apiGatewayInterface.exitReceiving(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            exitReceivingRequest
        )

    suspend fun criteriaFirstInspection(criteriaFirstInspectionRequest: CriteriaFirstInspectionRequest) =
        apiGatewayInterface.criteriaFirstInspection(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = criteriaFirstInspectionRequest.fcyId,
            buId = criteriaFirstInspectionRequest.buId,
            custId = criteriaFirstInspectionRequest.custId,
            criteriaType = criteriaFirstInspectionRequest.criteriaType,
            itemId = criteriaFirstInspectionRequest.itemId
        )

    suspend fun validateSerialNumber(serialNumReqBody: SerialNumReqBody) =
        apiGatewayInterface.validateSerialNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            buId = serialNumReqBody.buId,
            custId = serialNumReqBody.custId,
            fcyId = serialNumReqBody.fcyId,
            asnId = serialNumReqBody.asnId,
            itemId = serialNumReqBody.itemId,
            serialNum = serialNumReqBody.serialNum
        )

    suspend fun validateLotNumber(request: ValidateLotNumberASNRequest) =
        apiGatewayInterface.validateLotNumberWithASN(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            batchNumber = request.batchNumber,
            itemName = request.itemName,
            itemId = request.itemId,
            asnId = request.asnId,
            isASN = request.isAsn,
            itemLevelReceiving = request.itemLevelReceiving
        )

    suspend fun validateLotNumberFromLotMaster(request: ValidateLotNumberRequestFromLotMaster) =
        apiGatewayInterface.validateLotNumberFromLotMaster(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            custId = request.custId,
            itemName = request.itemName
        )


    suspend fun getASNDetails(receivingASNRequest: ReceivingASNRequest) =
        apiGatewayInterface.getReceivingASNDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            customerId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            pageLimit = receivingASNRequest.pageLimit,
            asnNumber = receivingASNRequest.asnNumber
        )

    suspend fun getDockDoorDetails(receivingDockDoorRequest: ReceivingDockDoorRequest) =
        apiGatewayInterface.getReceivingDockDoorDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            customerId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            pageLimit = receivingDockDoorRequest.pageLimit,
            dockDoor = receivingDockDoorRequest.dockDoor
        )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun validateLPN(rcValidateLPNRequest: RCValidateLPNRequest) = apiGatewayInterface.validateLPN(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
        custId = rcValidateLPNRequest.custId,
        fcyId = rcValidateLPNRequest.fcyId,
        buId = rcValidateLPNRequest.buId,
        asnId = rcValidateLPNRequest.asnId,
        caseNbr = rcValidateLPNRequest.caseNbr,
        receivingType = rcValidateLPNRequest.receivingType
    )
    suspend fun validateLPNForContainer(rcValidateLPNRequest: RCValidateLPNRequest) = apiGatewayInterface.validateLPNForConainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
        custId = rcValidateLPNRequest.custId,
        fcyId = rcValidateLPNRequest.fcyId,
        buId = rcValidateLPNRequest.buId,
        asnId = rcValidateLPNRequest.asnId,
        caseNbr = rcValidateLPNRequest.caseNbr,
        receivingType = rcValidateLPNRequest.receivingType,
        palletNbr = rcValidateLPNRequest.palletNbr?:""
    )


    suspend fun validatePalletNumber(rcValidateLPNRequest: RCValidateLPNRequest) = apiGatewayInterface.validatePalletNumber(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
        custId = rcValidateLPNRequest.custId,
        fcyId = rcValidateLPNRequest.fcyId,
        buId = rcValidateLPNRequest.buId,
        asnId = rcValidateLPNRequest.asnId,
        palletNbr = rcValidateLPNRequest.caseNbr,
        receivingType = rcValidateLPNRequest.receivingType
    )

    suspend fun submitReceivingLPN(rcReceivingLPNRequest: RCSubmitReceivingLPNRequest) = apiGatewayInterface.submitReceivingLPN(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        rcReceivingLPNRequest = rcReceivingLPNRequest
    )


    suspend fun endReceiving(endReceiving: EndReceiving) = apiGatewayInterface.endReceiving(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        endReceiving = endReceiving
    )


    suspend fun validateTransactionParam(request: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = request.cust_id,
        fcyId = request.fcy_id,
        buId = request.bu_id,
        transCode = request.trans_code
    )


    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun getInventoryLockCodes(inventoryLockcodeRequest: InventoryLockcodeRequest) = apiGatewayInterface.getInventoryLockCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = inventoryLockcodeRequest.custId,
        fcyId = inventoryLockcodeRequest.fcyId,
        buId = inventoryLockcodeRequest.buId
    )

    suspend fun generatePalletCaseNumber(type: String) =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = type
        )

    suspend fun palletDetailValidate(palletNumber: String, transferType: String) =
        apiGatewayInterface.caseTransferValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            container = palletNumber,
            transferType = transferType
        )

    suspend fun getLookUps(inventoryTypesRequest: LookUpsRequest) = apiGatewayInterface.getLookUps(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = inventoryTypesRequest.cusId,
        fcyId = inventoryTypesRequest.fcyId,
        buId = inventoryTypesRequest.buId,
        lookupNames = inventoryTypesRequest.lookupNames
    )
    suspend fun validateOverReceipt(asnId: Int, itemId: Int, qty: Int, invType: String?, lotNumber: String?) = apiGatewayInterface.validateOverReceipt(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        asnId = asnId,
        itemId = itemId,
        qty = qty,
        invType = invType,
        lotNumber = lotNumber,
    )

}