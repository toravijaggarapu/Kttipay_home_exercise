package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.rewarehouse.*
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RewarehouseRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun containerDetails(containerDetailsRequest: ContainerDetailsRequest) =
        apiGatewayInterface.containerDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            cntId = containerDetailsRequest.cntId,
            cusId = containerDetailsRequest.cusId.toString(),
            whsId = containerDetailsRequest.whsId.toString()
        )

    suspend fun submitRewarehouse(submitRewarehouseRequest: SubmitRewarehouseRequest, rewareSubmitRequestBody: RewareSubmitRequestBody) =
        apiGatewayInterface.submitRewarehouse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            rewareSubmitRequestBody,
            submitRewarehouseRequest.whsId,
            submitRewarehouseRequest.cusId,
            submitRewarehouseRequest.buId,
            submitRewarehouseRequest.userId,
            submitRewarehouseRequest.cntId,
            submitRewarehouseRequest.locId,
            submitRewarehouseRequest.Weight,
            submitRewarehouseRequest.toLoc,
            submitRewarehouseRequest.sbNum,
            submitRewarehouseRequest.toCont,
            submitRewarehouseRequest.isContValidated
        )

    suspend fun rewareMoves(rewareMovesRequest: RewareMovesRequest) =
        apiGatewayInterface.rewareMoves(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            cntId = rewareMovesRequest.cntId,
            sbNum = rewareMovesRequest.sbNum,
            fromLoc = rewareMovesRequest.fromLoc,
            cusId = rewareMovesRequest.cusId.toString(),
            whsId = rewareMovesRequest.whsId.toString()
        )

    suspend fun validateToLocation(validateToLocationRequest: ValidateToLocationRequest) =
        apiGatewayInterface.validateToLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            toLoc = validateToLocationRequest.toLoc,
            cntId = validateToLocationRequest.cntId,
            cusId = validateToLocationRequest.cusId.toString(),
            whsId = validateToLocationRequest.whsId.toString(),
            sbNum = validateToLocationRequest.sbNum
        )

    suspend fun validateFromLocation(validateFromLocRequest: ValidateFromLocRequest) =
        apiGatewayInterface.validateFromLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            locId = validateFromLocRequest.locId,
            cusId = validateFromLocRequest.cusId.toString(),
            whsId = validateFromLocRequest.whsId.toString()
        )

    // MN:SbNum
    suspend fun validateSbNumber(sbNumberRequest: RewareHouseSbNumberRequest) =
        apiGatewayInterface.validateSbNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            locId = sbNumberRequest.locId,
            sbNum = sbNumberRequest.sbNum,
            cusId = sbNumberRequest.cusId.toString(),
            whsId = sbNumberRequest.whsId.toString()
        )


    suspend fun validateToContainer(toContainerRequest: ValidateToContainerRequest) =
        apiGatewayInterface.validateToContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            whsId = toContainerRequest.whsId,
            cusId = toContainerRequest.cusId,
            cntId = toContainerRequest.cntId,
            toLoc = toContainerRequest.toLoc,
            toCont = toContainerRequest.toCont,
            sbNum = toContainerRequest.sbNum
        )

    suspend fun rewareHouseSerial(serial: String) =
        apiGatewayInterface.rewareHouseSerial(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            serial = serial,
            cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        )
}