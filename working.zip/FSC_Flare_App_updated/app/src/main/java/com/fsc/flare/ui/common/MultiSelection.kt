package com.fsc.flare.ui.common

interface MultiSelection {
    fun getDisplayName(): String
    var isSelected: Boolean
}