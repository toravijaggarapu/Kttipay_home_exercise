package com.fsc.flare.ui.fragment.inventory.reversecontainertoforwardstaging

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCtaContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = RCTSContainerFragment::class.java.simpleName.toString()

/**
 * A simple [RCTSContainerFragment] class.
 */
@AndroidEntryPoint
class RCTSContainerFragment : BaseFragment(), FlareScannable {

    private val viewModel: RCTSViewModel by activityViewModels()
    private lateinit var binding: FragmentCtaContainerBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etContainer.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etContainer)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCtaContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvInventoryTransfer.text =
            sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etContainer.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to handle Touch and Focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainer)
                FlareLog.i(TAG, "Container field focused")
                if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                    validateContainer()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate container
     */
    private fun validateContainer() {
        val containerNbr = binding.etContainer.text.toString()
        viewModel.prepareInventoryTransferContainerToStagingRequest(containerNbr = containerNbr)
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeRCTSContainerResponse()
    }

    /**
     * Function to observe RCTS container response
     */
    private fun observeRCTSContainerResponse() {
        viewModel.getRCTSContainerResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { rctsContainerResponse ->
                        FlareLog.i(TAG, "rctsContainerResponse success: $rctsContainerResponse")
                        if (!rctsContainerResponse.message.isNullOrEmpty()) {
                            binding.tvContainerResponse.text = rctsContainerResponse.message
                        } else {
                            viewModel.rctsContainerResponse = rctsContainerResponse
                            val action =
                                RCTSContainerFragmentDirections.actionRctsContainerFragmentToRctsLocationFragment()
                            getNavigationController().navigate(action)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "ctaContainerResponse Error: $message")
                        binding.tvContainerResponse.text = message
                        binding.etContainer.requestFocus()
                        binding.etContainer.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etContainer)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etContainer.setText(scan?.barcode.toString())
        binding.etContainer.text?.length?.let {
            binding.etContainer.setSelection(it)
            validateContainer()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}