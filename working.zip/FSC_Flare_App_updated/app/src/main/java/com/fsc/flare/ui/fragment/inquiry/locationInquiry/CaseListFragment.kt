package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseListBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.CaseObj
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "CaseListFragment"

@AndroidEntryPoint
class CaseListFragment : BaseFragment() {

    private lateinit var caseAdapter: CaseAdapter
    private lateinit var binding: FragmentCaseListBinding
    var page = 0

    private val viewModel: InquiryViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCaseListBinding.inflate(inflater, container, false)
        setupRecyclerView()
        subscribeObservers()
        return binding.root
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(fragmentContext)
        caseAdapter = viewModel.caseListHashMap[page]?.let { CaseAdapter(it) }!!
        binding.recyclerView.adapter = caseAdapter
        caseAdapter.notifyDataSetChanged()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val locData = viewModel.getLocation()
        val palletInvResp = viewModel.palletInventoryResponse.value
        val locationInvResp = viewModel.locationInventoryResponse.value
        binding.page.text = page.plus(1).toString()
        if (locData != null) {
            if(locData.locations[0].classification == "C" ){
                binding.totalPage.text = locationInvResp?.data?.paging?.totalPages.toString()
                if (locationInvResp?.data?.paging?.next != null) {
                    binding.btnNext.visibility = View.VISIBLE
                }
            }else{
                binding.totalPage.text = palletInvResp?.data?.paging?.totalPages.toString()
                if (palletInvResp?.data?.paging?.next != null) {
                    binding.btnNext.visibility = View.VISIBLE
                }
            }
            if (viewModel.caseListHashMap.size > 1) {
                binding.btnNext.visibility = View.VISIBLE
            }
            binding.btnNext.setOnClickListener {
                page++
                binding.btnPrevious.visibility = View.VISIBLE
                if (locData.locations[0].classification == "R") {
                    if(palletInvResp?.data?.paging?.totalPages == page.plus(1)){
                        binding.btnNext.visibility = View.GONE
                    }
                    if (viewModel.caseListHashMap.containsKey(page)) {
                        binding.page.text = page.plus(1).toString()
                        setupRecyclerView()
                    }else{
                        viewModel.getPalletInventory(viewModel.selectedPallet, page, viewModel.PAGELIMIT)
                    }
                } else {
                    if (locationInvResp?.data?.paging?.totalPages == page.plus(1)) {
                        binding.btnNext.visibility = View.GONE
                    }
                    if (viewModel.caseListHashMap.containsKey(page)) {
                        binding.page.text = page.plus(1).toString()
                        setupRecyclerView()
                    } else {
                        viewModel.getLocationInventory( locData.locations[0].locationBarcode, page, viewModel.PAGELIMIT)
                    }
                }
            }

            binding.btnPrevious.setOnClickListener {
                page--
                binding.btnNext.visibility = View.VISIBLE
                binding.page.text = page.plus(1).toString()
                if(page == 0){
                    binding.btnPrevious.visibility = View.GONE
                }
                setupRecyclerView()
            }
        }
    }

    private fun subscribeObservers() {
        viewModel.palletInventoryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { palletInvResp ->
                        if (palletInvResp.containers.isNotEmpty()) {
                            val filteredCaseList = palletInvResp.containers.filter { it.containerType == "C" }
                            val caseList: MutableList<CaseObj> = mutableListOf()
                            filteredCaseList.forEach {
                                val caseObj = CaseObj(
                                    it.container,
                                    it.qty,
                                    getContainerStatus(it.containerStatus)
                                )
                                caseList.add(caseObj)
                            }
                            if (palletInvResp.paging.next == null) {
                                binding.btnNext.visibility = View.GONE
                            }
                            binding.page.text = page.plus(1).toString()
                            binding.totalPage.text = palletInvResp.paging.totalPages.toString()
                            viewModel.caseListHashMap[page] = caseList
                            setupRecyclerView()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "container error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.locationInventoryResponse.observe(viewLifecycleOwner) { locationInvResponse ->
            when (locationInvResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "locationInquiry success: $locationInvResponse")
                    hideProgressBar()
                    val locDetails = viewModel.getLocation()
                    locationInvResponse.data?.let { locationInventoryResponse ->
                        if (locationInventoryResponse.paging?.next == null) {
                            binding.btnNext.visibility = View.GONE
                        }
                        viewModel.locationContainer = locationInventoryResponse.containers?.get(0)
                        if (locDetails != null) {
                            if (locDetails.locations[0].classification == "C" && !locationInventoryResponse.containers.isNullOrEmpty()) {
                                val filteredCaseList = locationInventoryResponse.containers.filter { it.containerType == "C" }
                                val caseList: MutableList<CaseObj> = mutableListOf()
                                filteredCaseList.forEach {
                                    val caseObj = CaseObj(
                                        it.container,
                                        it.qty,
                                        getContainerStatus(it.containerStatus)
                                    )
                                    caseList.add(caseObj)
                                }
                                viewModel.caseListHashMap[page] = caseList
                                binding.page.text = page.plus(1).toString()
                                setupRecyclerView()
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    locationInvResponse.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }
}