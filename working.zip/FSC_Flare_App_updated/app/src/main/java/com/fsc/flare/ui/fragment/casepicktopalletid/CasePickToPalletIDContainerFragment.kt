package com.fsc.flare.ui.fragment.casepicktopalletid

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogBlindCartonBinding
import com.fsc.flare.databinding.FragmentCasePickToPalletIdScanContainerBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.CartonInfo
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.ui.fragment.kitting.ListDialogFragment
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_OUTBOUND_ONLY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "CasePickToPalletIDContainerFragment"
private const val PICK_FROM_CASEPICK = "20"
/**
 * A simple [CasePickToPalletIDContainerFragment] subclass.
 */
@AndroidEntryPoint
class CasePickToPalletIDContainerFragment : BaseFragment(), FlareScannable {
    private val viewModel: CasePickToPalletIDViewModel by activityViewModels()
    private lateinit var binding: FragmentCasePickToPalletIdScanContainerBinding
    private lateinit var blindCartonBinding: DialogBlindCartonBinding
    private lateinit var blindCartonDialog: Dialog
    private var isShortPick = false
    private var scannedSerialNumbers = arrayListOf<String>()
    private var totalSerialNumberCount = 0
    private var overrideCartonResponse: CartonInfo? = null
    private var customVisibilityCallback: CustomVisibilityCallback? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentCasePickToPalletIdScanContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        handleInputFieldListeners()
        subscribeObservers()
        callTransactionParamAPI()
        clickListeners()
    }

    private fun clickListeners() {
        binding.shortPickCart.setOnClickListener {
            showShortPickActionAlert()
        }

        binding.btnPickBlindCarton.setOnClickListener {
            binding.etContainer.text = null
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null && (taskData.itemSerialTracked == "0" || scannedSerialNumbers.isNotEmpty())) {
                showBlindCartonDialog()
            } else {
                binding.tvContainerRes.text =
                    getString(R.string.item_is_serially_tracked_please_scan_serial_number)
            }
        }

        binding.tvSerialCount.setOnClickListener {
            displaySerialNumberView(scannedSerialNumbers)
        }
    }


    private fun showBlindCartonDialog() {
        blindCartonBinding = DialogBlindCartonBinding.inflate(LayoutInflater.from(context))
        blindCartonDialog = Dialog(fragmentContext)

        with(blindCartonDialog) {
            setContentView(blindCartonBinding.root)
            setCancelable(false)
            show()
            val lp = WindowManager.LayoutParams()
            lp.copyFrom(window!!.attributes)
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            window!!.attributes = lp
        }

        with(blindCartonBinding) {
            etBlindContainer.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {

                }

                override fun beforeTextChanged(
                    s: CharSequence,
                    start: Int,
                    count: Int,
                    after: Int
                ) {

                }

                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    btnOk.isEnabled = s.isNotEmpty()
                    etBlindContainerRes.text = null
                }
            })
            etBlindContainer.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    btnOk.performClick()
                }
                false
            }
            btnOk.setOnClickListener {
                if (!etBlindContainer.text.isNullOrEmpty()) {
                    val containerType =
                        viewModel.validateContainerType(sharedPreferencesBase, "Carton")
                    val containerNumber = etBlindContainer.text.toString()
                    if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                        etBlindContainerRes.text = getString(
                            R.string.container_prefix_length_validation,
                            containerType.ctyId,
                            containerType.ctyContainerLength
                        )
                    } else {
                        btnOk.isEnabled = false
                        viewModel.getContainer(
                            etBlindContainer.text.toString().trim(), "Y"
                        )
                    }
                }
            }

            btnCancel.setOnClickListener {
                blindCartonDialog.dismiss()

            }

            btnCancel.setOnClickListener {
                blindCartonDialog.dismiss()
            }
        }
    }

    private fun setupUI() {
        binding.btnPickBlindCarton.visibility = View.GONE
        with(binding) {
            tvPickingBuildCart.text =
                sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)

            val data = viewModel.getPickTask()
            val taskData = viewModel.getPickTaskDetails()
            if (data != null) {
                cart.text = data.cartNbr
                if (taskData != null) {
                    taskId.text = taskData.taskId.toString()
                    item.text = taskData.itemCode
                    description.text = taskData.itemDescription
                    pickLocation.text = taskData.locationBarcode
                    pickQty.text = String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
                    totalSerialNumberCount = taskData.ibContainerQty
                }
            }
            etContainer.post { etContainer.requestFocus() }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleInputFieldListeners() {

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateContainer()
            }
            false
        }

        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (overrideCartonResponse != null
                    && overrideCartonResponse!!.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {

                    canEnableBlindCartonButton(scannedSerialNumbers.size == totalSerialNumberCount)
                } else {
                    canEnableBlindCartonButton(s.isEmpty())
                }
                binding.tvContainerRes.text = null
            }
        })
    }

    private fun canEnableBlindCartonButton(canEnable: Boolean) {
        with(binding.btnPickBlindCarton) {
            isEnabled = canEnable
        }
    }

    private fun validateContainer() {
        if (isProgressBarVisible()) {
            return
        }
        val containerNbr = binding.etContainer.text.toString()
        if (containerNbr.isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainer)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (containerNbr.trim() == taskData.containerNbr) {
                    callTaskPickCompleteAPI("")
                } else {
                    if (overrideCartonResponse != null &&
                        overrideCartonResponse!!.containerNbr == taskData.containerNbr &&
                        overrideCartonResponse!!.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {

                        val allSerialScanned = scannedSerialNumbers.size == totalSerialNumberCount
                        if (allSerialScanned) {
                            displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
                            binding.etContainer.isEnabled = false
                        } else {
                            viewModel.validateSerialNumberOrItemCodeContainer(
                                containerNbr, true, taskData.pullLocationId, taskData.itemId, overrideCartonResponse!!.containerId
                            )
                        }
                    } else {
                        callContainerOverrideAPI()
                    }
                }
            }
        }
    }

    private fun callTaskPickCompleteAPI(reasonCode: String) {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            viewModel.taskCasePickCompleteReq(
                taskQty = if (reasonCode.isEmpty()) taskData.taskQty else 0,
                expDate = if (taskData.expDate != null) formatDate(taskData.expDate!!) else "",
                lockCode = reasonCode,
                containerId = taskData.containerId,
                containerNbr = taskData.containerNbr,
                serialNumbers = scannedSerialNumbers
            )
            isShortPick = reasonCode.isNotEmpty()
        }
    }

    private fun callContainerOverrideAPI() {
        viewModel.validateContainerOverride(
            binding.etContainer.text.toString().trim(), viewModel.getPickTaskDetails()?.taskDetId
        )
    }

    /**
     * method to get transaction param info from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getShortPickTransactionParam(viewModel.shortPickTransParamsKey)
    }

    private fun subscribeObservers() {
        subscribeTransactionParamObserver()
        casePickCompleteObserver()
        caseOverrideObserver()
        subscribeSerialValidationObserver()
        subscribeContainerObserver()
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.shortPickTransactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            handleShortPickResponse(transactionParamResponse)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleShortPickResponse(transactionParamResponse: TransactionParamResponse) {
        if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
            val noOfCases = transactionParamResponse.noOfCases[0]
            binding.shortPickCart.visibility =
                if (noOfCases.transVal == viewModel.shortPickTransEnabledKey) View.VISIBLE else View.GONE
        }
    }

    private fun casePickCompleteObserver() {
        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskCasePickCompleteRes ->
                        if (taskCasePickCompleteRes.success != null && taskCasePickCompleteRes.success) {
                            binding.etContainer.text?.clear()
                            handleTaskCasePickResponse(taskCasePickCompleteRes)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskCasePickComplete error: $message")
                        handleTaskPickErrorResponse(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleTaskPickErrorResponse(message: String) {
        if (message.contains("_")) {
            val msgArray = message.split("_")
            if (msgArray.isNotEmpty()) {
                when {
                    msgArray[0] == LOCATION_IS_EMPTY -> {
                        showErrorAlert(msgArray[1])
                    }

                    msgArray[0] == TASK_CYCLE_COUNT_PENDING -> {
                        showCycleCountPendingAlert()
                    }

                    else -> {
                        displayErrorMessage(message)
                    }
                }
            }
        } else {
            displayErrorMessage(message)
        }
    }

    private fun handleTaskCasePickResponse(taskCasePickCompleteRes: TaskCasePickCompleteRes) {
        val pickMessage = if (isShortPick) getString(R.string.short_picked_continue_picking)
        else if (taskCasePickCompleteRes.message.isNullOrEmpty()) getString(R.string.case_picked_successfully)
        else taskCasePickCompleteRes.message

        if (taskCasePickCompleteRes.taskDetails != null) {
            viewModel.setPickTaskDetails(taskCasePickCompleteRes.taskDetails)
            showSuccessSnackBarStd(pickMessage) {
                navigateToPickLocation()
            }
        } else {
            if (taskCasePickCompleteRes.eligibleToStage == null || taskCasePickCompleteRes.eligibleToStage) {
                showSuccessSnackBarStd(pickMessage) {
                    getNavigationController().navigate(R.id.casePickToPalletIDStageLocationFragment)
                }
            } else {
                showAlertDialog(
                    "",
                    getString(R.string.all_tasks_in_the_pallet_is_cancelled_since_you_short_picked_stage_it)
                ) {
                    navigateToPalletNumber()
                }
            }
        }
    }

    private fun caseOverrideObserver() {
        viewModel.caseOverrideResponse.observe(viewLifecycleOwner) { containerOverrideResponse ->
            when (containerOverrideResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerOverrideResponse")
                    hideProgressBar()
                    containerOverrideResponse.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            handleCaseOverriderSuccessResponse(containerResponse)
                        } else {
                            displayErrorMessage(getString(R.string.invalid_container))
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    containerOverrideResponse.message?.let { message ->
                        FlareLog.e(TAG, "ContainerOverrideResponse error: $message")
                        displayErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleCaseOverriderSuccessResponse(overrideResponse: ValidatePalletOverrideResponse) {
        overrideCartonResponse = overrideResponse.cartonInfo
        val containerNumber = binding.etContainer.text.toString()
        if (overrideCartonResponse!!.scannedSerialType == Constants.ApplicationConstants.SERIAL_TRACK_FULL_TRACKING) {
            if (overrideCartonResponse!!.serialNumbers.isNotEmpty() && overrideCartonResponse!!.serialNumbers.contains(
                    containerNumber
                )
            ) {
                scannedSerialNumbers = overrideCartonResponse!!.serialNumbers
                binding.etContainer.text = null
                displaySuccessMessage(
                    getString(
                        R.string.successfully_scanned_serial_number_and_the_associated_case_id,
                        containerNumber,
                        overrideCartonResponse!!.containerNbr
                    )
                )
            } else {
                displayErrorMessage(resources.getString(R.string.serial_doesnot_exist))
            }
        } else if (overrideCartonResponse!!.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {
            if (!scannedSerialNumbers.contains(containerNumber)) {
                val allSerialScanned = scannedSerialNumbers.size == totalSerialNumberCount
                if (allSerialScanned) {
                    displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
                    binding.etContainer.isEnabled = false
                } else {
                    val taskData = viewModel.getPickTaskDetails()
                    if (taskData != null) {
                        viewModel.validateSerialNumberOrItemCodeContainer(
                            containerNumber,
                            true,
                            taskData.pullLocationId,
                            taskData.itemId,
                            overrideCartonResponse!!.containerId
                        )
                    }
                }
            } else {
                displayErrorMessage(resources.getString(R.string.duplicate_serial))
            }
        } else {
            updateCartonId(overrideCartonResponse!!)
        }
    }

    private fun updateCartonId(cartonResponse: CartonInfo) {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            taskData.containerNbr = cartonResponse.containerNbr
            taskData.containerId = cartonResponse.containerId
            // Update the container number and container Id from taskData to user entered one
            viewModel.setPickTaskDetails(taskData)
            callTaskPickCompleteAPI("")
        }
        binding.etContainer.text = null
    }

    private fun subscribeSerialValidationObserver() {
        viewModel.serialItemIdValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialOrItemIdValidationResponse ->
                        FlareLog.i(
                            TAG,
                            "serialValidation Response: $serialOrItemIdValidationResponse"
                        )

                        if (serialOrItemIdValidationResponse.success) {
                            if (serialOrItemIdValidationResponse.isSerialNumberValid) {
                                serialNumberUpdate()
                            } else {
                                if (serialOrItemIdValidationResponse.message != null) {
                                    displayErrorMessage(serialOrItemIdValidationResponse.message)
                                } else {
                                    displayErrorMessage(getString(R.string.something_went_wrong_services))
                                }
                            }

                        } else {
                            if (serialOrItemIdValidationResponse.message != null) {
                                displayErrorMessage(serialOrItemIdValidationResponse.message)
                            } else {
                                displayErrorMessage(getString(R.string.something_went_wrong_services))
                            }
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        displayErrorMessage(message)
                    }
                }
            }
        }
    }

    private fun subscribeContainerObserver() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            with(blindCartonBinding) {
                when (containerInquiryResponse) {
                    is Resource.Success -> {
                        FlareLog.i(TAG, "container success: $containerInquiryResponse")
                        progressBar.visibility = View.GONE
                        containerInquiryResponse.data?.let { containerResponse ->
                            viewModel.givenCartonNbr = null
                            if (containerResponse.success && containerResponse.container.isNotEmpty()) {
                                displayPopUpErrorMessage(getString(R.string.master_pallet_repack_container_exists))
                            } else {
                                btnOk.isEnabled = true
                                blindCartonDialog.dismiss()
                                viewModel.givenCartonNbr =
                                    etBlindContainer.text.toString()
                                callTaskPickCompleteAPI("")
                            }
                        }
                    }

                    is Resource.Error -> {
                        progressBar.visibility = View.GONE
                        containerInquiryResponse.message?.let { message ->
                            displayPopUpErrorMessage(message)
                            btnOk.isEnabled = false
                        }
                    }

                    is Resource.Loading -> {
                        progressBar.visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    private fun serialNumberUpdate() {
        binding.tvSerialCount.visibility = View.VISIBLE
        scannedSerialNumbers.add(binding.etContainer.text.toString().trim())
        binding.tvSerialCount.text = getString(
            R.string.serial_number_count, scannedSerialNumbers.size.toString(), totalSerialNumberCount.toString()
        )
        binding.etContainer.text = null
        val allSerialScanned = scannedSerialNumbers.size == totalSerialNumberCount
        canEnableBlindCartonButton(allSerialScanned)
        if (allSerialScanned) {
            displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
            binding.etContainer.isEnabled = false
        }
    }

    private fun displayErrorMessage(message: String) {
        FlareLog.e(TAG, "ContainerResponse error: $message")
        binding.tvContainerRes.text = message
        binding.tvContainerRes.setTextColor(ContextCompat.getColor(requireContext(), R.color.red))
        binding.etContainer.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etContainer)
    }

    private fun displaySuccessMessage(message: String) {
        binding.tvContainerRes.text = message
        binding.tvContainerRes.setTextColor(ContextCompat.getColor(requireContext(), R.color.green))
    }

    private fun displayPopUpErrorMessage(message: String) {
        with(blindCartonBinding) {
            etBlindContainerRes.text = message
            etBlindContainer.selectAll()
            showSoftKeyBoard(fragmentContext, etBlindContainer)
        }
    }

    private fun navigateToPalletNumber() {
        val action =
            CasePickToPalletIDContainerFragmentDirections.actionCasePickToPalletIDContainerToCasePickToPalletIDPalletFragment()
        getNavigationController().navigate(action)
    }

    private fun navigateToPickLocation() {
        val action =
            CasePickToPalletIDContainerFragmentDirections.actionCasePickToPalletIDContainerToCasePickToPalletIDPickLocation()
        getNavigationController().navigate(action)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showShortPickActionAlert() {
        val taskData = viewModel.getPickTaskDetails()
        val data = viewModel.getPickTask()
        val msg = if (data?.orderType != null && data.orderType.equals(
                Constants.FILL_KILL, ignoreCase = true
            )
        ) {
            getString(R.string.lbl_this_pick_task_belongs_to_a_fill_kill_order_do_you_want_to_continue)
        } else {
            getString(
                R.string.short_pick_for_casepick_alert,
                taskData?.taskQty.toString() + " " + taskData?.taskQtyUom,
                "0 " + taskData?.taskQtyUom
            )
        }
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_yes)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            viewModel.getInventoryReasonCodes()
            showReasonCode()
        }

        builder.setNegativeButton(resources.getString(R.string.alert_button_no)) { dialogInterface, _ ->
            dialogInterface.dismiss()

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showReasonCode() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            callTaskPickCompleteAPI(lockCode)
            dialog.dismiss()
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        binding.etContainer.setText(scan?.barcode.toString())
        binding.etContainer.text?.length?.let {
            binding.etContainer.setSelection(it)
        }
        FlareLog.i(TAG, "Container field focused")
        validateContainer()
    }

    private fun showErrorAlert(message: String) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }


    private fun showCycleCountPendingAlert() {
        showAlertDialog("",
            getString(R.string.cycle_count_pending_for_location),
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.getInventoryReasonCodes()
                    showReasonCode()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun displaySerialNumberView(scannedSerialList: List<String>) {
        val dialog = ListDialogFragment(getString(R.string.serial_numbers), scannedSerialList)
        dialog.show(childFragmentManager, "listDialog")
    }

    override fun onResume() {
        if (customVisibilityCallback != null) {
            customVisibilityCallback!!.onVisibilityChange(true)
        }
        super.onResume()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        customVisibilityCallback = cb!!
        customVisibilityCallback!!.onVisibilityChange(true)
    }

}