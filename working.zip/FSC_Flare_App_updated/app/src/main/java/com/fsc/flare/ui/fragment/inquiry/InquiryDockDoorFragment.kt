package com.fsc.flare.ui.fragment.inquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryDockDoorBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "DockDoorFragment"

/**
 * A simple [InquiryDockDoorFragment] class.
 */
@AndroidEntryPoint
class InquiryDockDoorFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryDockDoorBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryDockDoorBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()
        binding.dockDoor.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        binding.dockDoor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.dockDoorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.dockDoor)
        if (binding.dockDoor.isFocused && !binding.dockDoor.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Dockdoor field focused")
            hideSoftKeyBoard(fragmentContext, binding.dockDoor)
            viewModel.getDockDoorInfo(binding.dockDoor.text.toString())
        }
    }

    private fun subscribeObservers() {
        viewModel.dockDoorResponse.observe(viewLifecycleOwner) { ddInquiryResponse ->
            when (ddInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "dockDoor success: $ddInquiryResponse")
                    hideProgressBar()
                    ddInquiryResponse.data?.let { locationResponse ->
                        viewModel.setDDLocation(locationResponse)
                        binding.dockDoor.text = null
                        val navController =
                            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                        val action = InquiryDockDoorFragmentDirections.actionInquiryDockDoorToInquiryDockDoorDesc()
                        navController.navigate(action)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    ddInquiryResponse.message?.let { message ->
                        binding.dockDoorResponse.text = message
                        FlareLog.e(TAG, "dockDoor error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG,"onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.dockDoor.setText(scan?.barcode.toString())
            binding.dockDoor.text?.length?.let {
                binding.dockDoor.setSelection(it)
            }
            FlareLog.i(TAG, "Dockdoor field focused")
            viewModel.getDockDoorInfo(binding.dockDoor.text.toString())
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG,"onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}