package com.fsc.flare.utils

import com.fsc.flare.BuildConfig

object AuthConstants {

    const val LOGIN_PAGE_REDIRECT_URI = "com.fsc.flare:/oidc"
    const val LOGIN_PAGE_RESPONSE_TYPE = "code"
    const val LOGIN_PAGE_SCOPE = "openid+profile+email+offline_access"
    const val LOGIN_PAGE_URL: String = BuildConfig.BASE_AUTH_URL + BuildConfig.LOGIN_PAGE_PATH
    const val LOGIN_PAGE_URL_TEMP_USER: String = BuildConfig.TEMP_WORKER_BASE_AUTH_URL + BuildConfig.LOGIN_PAGE_PATH
    const val LOGIN_PAGE_CHALLENGE_METHOD = "S256"

    const val AUTH_GRANT_TYPE_AUTHORIZATION_CODE = "authorization_code"
    const val AUTH_GRANT_TYPE_REFRESH_TOKEN = "refresh_token"
}