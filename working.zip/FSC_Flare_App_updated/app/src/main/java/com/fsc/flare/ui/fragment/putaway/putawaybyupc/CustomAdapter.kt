package com.fsc.flare.ui.fragment.putaway.putawaybyupc

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemLayoutBinding
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.UpcItemSlpData

class CustomAdapter(
    private val context: Context,
    private val items: List<UpcItemSlpData>,
    private val listener: (UpcItemSlpData) -> Unit
) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    private var selectedPosition = -1
    var selectedItem: UpcItemSlpData? = null

    /**
     * ViewHolder class that holds the view for each item in the RecyclerView.
     */
    inner class ViewHolder(val binding: ItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.radioButton.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    selectedPosition = position
                    selectedItem = items[position]
                    notifyDataSetChanged()
                    listener(items[position])
                }
            }
        }
    }

    /**
     * Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(context)
        val binding = ItemLayoutBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.item = item
        holder.binding.position = position
        holder.binding.selectedPosition = selectedPosition
        holder.binding.executePendingBindings()
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     */
    override fun getItemCount(): Int = items.size
}