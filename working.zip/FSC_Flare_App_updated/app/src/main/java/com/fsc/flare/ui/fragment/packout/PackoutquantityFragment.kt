package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutQuantityUomBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutLotGetReq
import com.fsc.flare.source.data.dto.packout.req.PackOutQtyGetReq
import com.fsc.flare.source.data.dto.packout.req.PackOutSaveTmp
import com.fsc.flare.source.data.dto.packout.req.PrintCaseLabelPackoutReq
import com.fsc.flare.source.data.dto.packout.res.ContainerDetails
import com.fsc.flare.source.data.dto.packout.res.ItemDetailResponse
import com.fsc.flare.ui.common.BackButtonHandler
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutquantityFragment"

@AndroidEntryPoint
class PackoutquantityFragment : BaseFragment(), BackButtonHandler {

    var pickPalletQty: Int = 0
    var caseQuantity: Int = 0
    var itemQuantity: Int = 0
    var selectedUOM: String = ""

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutQuantityUomBinding
    lateinit var itemDetailRes: ItemDetailResponse

    var isQtyEntered = false
    private lateinit var uomConversionUtil: ItemUOMConversionRateUtil

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = false
        menu.findItem(R.id.logout)?.isVisible = false
        menu.findItem(R.id.account)?.isVisible = false
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutQuantityUomBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvDockDoorValue.text = viewModel.getLocationBarcode()
        if (viewModel.getPalletReqNumber() == "") {
            binding.tvPallet.visibility = View.GONE
        } else {
            binding.tvPalletValue.text = viewModel.getPalletReqNumber()
        }
        binding.btnEndPackout.isEnabled = false
        binding.tvCartonValue.text = viewModel.getcartonReqNumber()
        binding.itemCode.text = viewModel.getitemData()
        binding.tvDescValue.text = viewModel.getItemDesc()
        binding.tvInvTypeValue.text =
            viewModel.getInventoryType()?.let { getInventoryDescription(it) }

        // Lock Code Number Handling
        if (viewModel.isDekitting) {
            if (viewModel.lockCodeSelected.isNullOrEmpty()) {
                binding.tvLockCode.visibility = View.GONE
                binding.tvLotCodeValue.visibility = View.GONE
            } else {
                binding.tvLockCode.visibility = View.VISIBLE
                binding.tvLotCodeValue.visibility = View.VISIBLE
                binding.tvLotCodeValue.text = getLockCodeDescription(viewModel.lockCodeSelected)
            }
        }

        if (!viewModel.getLocationData().locations.isNullOrEmpty()) {
            val taskDetails =
                viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
            val tracking = taskDetails.tracking

            if (tracking.expirationRequired == 1 && !taskDetails.expDateAsString.isNullOrEmpty()) {
                binding.tvExpiryDate.visibility = View.VISIBLE
                binding.tvExpiryDateValue.visibility = View.VISIBLE
                binding.tvExpiryDate.text = formatExpiryDate(taskDetails.expDateAsString)
            }

            if (viewModel.lotNumberSelectedFromDeKitting && !viewModel.getlotNumber()
                    .isNullOrEmpty()
            ) {
                validateLot(viewModel.getlotNumber()!!)
            } else if (tracking.lotRequired == 1 && !taskDetails.lotNumber.isNullOrEmpty()) {
                validateLot(taskDetails.lotNumber)
            }
        }

        binding.etQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etQtyRes.text = ""
                binding.uomSelectionError.text = ""
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        subscribeObservers()
        return binding.root
    }

    private fun validateLot(lotNumber: String) {
        binding.tvLotNumber.visibility = View.VISIBLE
        binding.tvLotValue.visibility = View.VISIBLE
        binding.tvLotValue.text = lotNumber

        binding.tvExpiryDate.visibility = View.GONE
        binding.tvExpiryDateValue.visibility = View.GONE
        binding.mfg.visibility = View.GONE
        binding.mfgTv.visibility = View.GONE

        subscribeObserversPackOutLot()

        // Validate Lot Number and get ExpiryDate
        viewModel.validateLotNumber(
            PackOutLotGetReq(
                fcy_Id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                batchNumber = lotNumber.toString(),
                itemName = viewModel.getitemData(),
                itemId = viewModel.getItemId()
            )
        )
    }

    private fun subscribeObserversPackOutLot() {
        viewModel.validateLotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packOutLotResponse ->
                        FlareLog.i(TAG, "PackOutLot response:$packOutLotResponse")
                        if (packOutLotResponse.success) {
                            FlareLog.i(TAG, "PackOutLot Success:${packOutLotResponse}")
                            if (!packOutLotResponse.batchDetail.isNullOrEmpty()) {
                                var expDate = viewModel.getExpiryDateFromResponse()
                                if (!expDate.isNullOrEmpty()) {
                                    expDate = formatExpiryDate(expDate)

                                    binding.tvExpiryDate.visibility = View.VISIBLE
                                    binding.tvExpiryDateValue.visibility = View.VISIBLE
                                    binding.tvExpiryDate.text = expDate
                                }

                                var mfgDate = viewModel.getManufacturingDate()
                                if (!mfgDate.isNullOrEmpty()) {
                                    mfgDate = formatExpiryDate(mfgDate)

                                    binding.mfg.visibility = View.VISIBLE
                                    binding.mfgTv.visibility = View.VISIBLE
                                    binding.mfg.text = mfgDate
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParam Error:$message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        pickPalletQty = viewModel.tempLpnsList.size.let { it.plus(1) }
        if (!viewModel.getLocationData().locations.isNullOrEmpty()) {
            if (!viewModel.getLocationData().locations[0].items.isNullOrEmpty()) {
                itemDetailRes =
                    viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
                if (itemDetailRes.uomConversions != null) {
                    val uomConversionsList = ArrayList<String>()
                    val uomBottomList = ArrayList<String>()
                    itemDetailRes.uomConversions!!.forEach { uomConversion ->
                        if (uomConversion.toUOM == "CS") {
                            uomBottomList.add(uomConversion.toUOM + " = " + uomConversion.conversionRate + " " + uomConversion.qtyUOM)
                        }
                        if (uomConversion.toUOM != "PL") {
                            uomConversionsList.add(uomConversion.toUOM)
                        }
                        if (uomConversion.toUOM == "PL" && uomConversion.qtyUOM == "CS") {
                            pickPalletQty = uomConversion.conversionRate
                            viewModel.setpckPallet(pickPalletQty)
                        }
                        if (uomConversion.toUOM == "CS" && uomConversion.qtyUOM == "EA") {
                            caseQuantity = uomConversion.conversionRate
                        }
                        if (caseQuantity == 0) {
                            binding.bottomItemInfo.bottomRootLayout.visibility = View.GONE
                            if (uomConversion.toUOM == "EA" && uomConversion.qtyUOM == "EA") {
                                // caseQuantity = uomConversion.conversionRate
                            }
                        }
                    }
                    binding.uomspinner.setOptions(uomConversionsList)
                    for (i in 0..uomBottomList.size) {
                        if (indexExists(uomBottomList, i)) {
                            when (i) {
                                0 -> {
                                    binding.bottomItemInfo.tvSubPack.text = uomBottomList[i]
                                }

                                1 -> {
                                    binding.bottomItemInfo.tvPack.text = uomBottomList[i]
                                }

                                2 -> {
                                    binding.bottomItemInfo.tvCase.text = uomBottomList[i]
                                }

                                3 -> {
                                    binding.bottomItemInfo.tvPallet.text = uomBottomList[i]
                                }
                            }
                        }
                    }
                }
            }
        } else {
            FlareLog.i(TAG, "empty objet from onActivity")
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.etQty.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }

        binding.uomspinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            selectedUOM = isUpdated
            validateField()
        }

        binding.btnEndPackout.setOnClickListener {
            val action =
                PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutstagingFragement()
            moveToFragment(action)
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etQty)
        binding.uomSelectionError.text = ""
        binding.etQtyRes.text = ""

        when {
            binding.etQty.text.isNullOrEmpty() -> {
                binding.etQtyRes.text = getString(R.string.lbl_qty_required)
            }

            binding.etQty.text.toString().trim().toInt() <= 0 -> {
                binding.etQtyRes.text = getString(R.string.qty_cannot_ero)
            }

            binding.uomspinner.text == getString(R.string.select_uom) -> {
                binding.uomSelectionError.text = getString(R.string.select_uom)
            }

            else -> packOutQtyCall()
        }
    }


    private fun packOutQtyCall() {
        itemQuantity = binding.etQty.text.toString().toInt()
        uomConversionUtil = ItemUOMConversionRateUtil(itemDetailRes.uomConversions!!)
        uomConversionUtil.calculateQuantity(selectedUOM, itemQuantity)
        itemQuantity = uomConversionUtil.totalQuantity
        viewModel.setcasePalletQty(itemQuantity)
        when {
            itemQuantity < 0 -> {
                binding.etQtyRes.text = getString(R.string.uom_not_defined)
            }

            ((sharedPreferences.getBoolean(
                PreferenceKeys.FOLLOW_ITEM_UOMS,
                false
            ) && caseQuantity != 0) && itemQuantity !in 1..caseQuantity) -> {
                binding.etQtyRes.text =
                    getString(R.string.packout_quantity_should_not_greater_than_case_quantity)
            }

            else -> {
                viewModel.validateQtyId(
                    PackOutQtyGetReq(
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        qty = Integer.parseInt(binding.etQty.text.toString()),
                        palletQty = pickPalletQty,
                        caseQty = viewModel.getcasePalletQty(),
                        //                  caseQty = Integer.parseInt(binding.etQty.text.toString()),
                        locationBarCode = viewModel.getLocationData().locations[0].locationBarcode,
                        transactionIdentifier = viewModel.gettransIdentifier(),
                        itemId = viewModel.getItemId(),
                        isKitting = viewModel.isKitting
                    )
                )
            }
        }
    }


    private fun subscribeObservers() {
        viewModel.validateQtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "ValidateQty response:$response")
                        if (response.success) {
                            isQtyEntered = true
                            FlareLog.i(TAG, "ValidateQty Success:${response}")
                            //viewModel.setPackOutResponse(response)
                            viewModel.setQuantity(itemQuantity)
                            viewModel.tempLpnsList.add(
                                ContainerDetails(
                                    null,
                                    null,
                                    null,
                                    viewModel.getcartonReqNumber(),
                                    binding.etQty.text.toString().toLong(),
                                    null,
                                    viewModel.getItemId().toLong(),
                                    viewModel.lockCodeSelected
                                )
                            )
                            val itemDetail =
                                viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
                            val lotNumber = itemDetail.tracking.lotRequired
                            val serialNumber = itemDetail.tracking.serialNumberRequired
                            binding.etQtyRes.text = null
                            binding.uomSelectionError.text = null
                            if (viewModel.promptItemAttribute) {
                                when {
                                    lotNumber == 1 -> {
                                        val action =
                                            PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutlotFragement()
                                        moveToFragment(action)
                                    }

                                    serialNumber == 4 /*|| serialNumber == 1*/ -> {
                                        val action =
                                            PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutserialnumberFragement()
                                        moveToFragment(action)
                                    }

                                    else -> {
                                        callEndPackout()
                                    }
                                }
                            } else {
                                if (serialNumber == 4 /*|| serialNumber == 1*/) {
                                    val action =
                                        PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutserialnumberFragement()
                                    moveToFragment(action)
                                } else {
                                    callEndPackout()
                                }
                            }
                        } else {
                            binding.etQtyRes.text = response.message
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        viewModel.submitPackoutResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutLocation response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "PackOutLocation Success:${response}")
                            sharedPreferences.edit()
                                .putBoolean(PreferenceKeys.Packout.IS_PACKOUT_DONE, true).apply()
                            //  binding.etQty.text = null
                            //  binding.uomspinner.text = getString(R.string.select_uom)
                            viewModel.settransIdentifier(response.transactionIdentifier)

                            /// NEW API
                            if (viewModel.isKitting && !viewModel.isDekitting) {
                                viewModel.printCaseLabel(
                                    PrintCaseLabelPackoutReq(
                                        itemBarcode = viewModel.getItemBarcode(),
                                        itemDescription = binding.tvDescValue.text.toString(),
                                        itemName = binding.itemCode.text.toString(),
                                        caseNumber = binding.tvCartonValue.text.toString(),
                                        qty = itemQuantity.toString(),
                                        printerName = viewModel.getDefaultPrinter(),
                                        custId = sharedPreferences.getInt(
                                            PreferenceKeys.CUST_ID,
                                            -1
                                        ),
                                        fcyId = sharedPreferences.getInt(
                                            PreferenceKeys.FACILITY_ID,
                                            -1
                                        ),
                                        buId = sharedPreferences.getInt(
                                            PreferenceKeys.BUSINESS_UNIT_ID,
                                            -1
                                        )
                                    )
                                )
                            } else {
                                binding.btnEndPackout.isEnabled = true
                                // MOVE  BELOW CODE TO ABOVE API SUCCESS / FAIL / ERROR
                                val action =
                                    PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutCartonFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.PackoutCartonFragement, true)
                                    .build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                            showAlertDialog("", response.message) {}
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printCaseLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "printCaseLabelResponse response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "printCaseLabelResponse Success:${response}")
                            showSuccessSnackBarStd(resources.getString(R.string.case_lbl_printed_successfully)) {
                                val action =
                                    PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutCartonFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.PackoutCartonFragement, true)
                                    .build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            if (response.message != null) {
                                FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                                showErrorSnackBar(response.message)
                            }
                            val action =
                                PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutCartonFragment()
                            val navOptions =
                                NavOptions.Builder().setPopUpTo(R.id.PackoutCartonFragement, true)
                                    .build()
                            getNavigationController().navigate(action, navOptions)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                        val action =
                            PackoutquantityFragmentDirections.actionPackoutQuantityFragementToPackoutCartonFragment()
                        val navOptions =
                            NavOptions.Builder().setPopUpTo(R.id.PackoutCartonFragement, true)
                                .build()
                        getNavigationController().navigate(action, navOptions)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun callEndPackout() {
        viewModel.submitPackout(
            PackOutSaveTmp(
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                viewModel.getLocationBarcode(), viewModel.getLocId(),
                viewModel.getcasePalletQty(),
                viewModel.getpckPallet(),
                viewModel.getPalletReqNumber(),
                viewModel.getcartonReqNumber(),
                viewModel.getItemId().toInt(),
                viewModel.getQuantity(),
                "EA",
                viewModel.getlotNumber(),
                viewModel.getExpiryDate(),
                viewModel.gettransIdentifier(),
                arrayListOf(),
                viewModel.getInventoryType(),
                viewModel.lockCodeSelected,
                viewModel.isKitting
            )
        )
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onBackButtonPressed() {
        hideSoftKeyBoard(fragmentContext, binding.etQty)
        if (isQtyEntered) {
            showSnackBar(
                resources.getString(
                    R.string.lbl_please_end_pack_out_for,
                    viewModel.getcartonReqNumber()
                )
            )
        } else {
            findNavController().popBackStack()
        }
    }
}