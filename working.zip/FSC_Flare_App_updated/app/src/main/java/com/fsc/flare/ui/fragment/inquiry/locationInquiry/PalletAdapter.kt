package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.inquiry.location.PalletObj

class PalletAdapter(private val pallets: MutableList<PalletObj>,
                    private val listener: OnAdapterClickListener) :
    RecyclerView.Adapter<PalletAdapter.ViewHolder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pallet, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pallet = pallets[position]
        holder.bind(pallet)
    }

    override fun getItemCount(): Int {
        return pallets.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val palletNumberTextView: TextView = itemView.findViewById(R.id.palletNumberTextView)
        private val noOfCasesTextView: TextView = itemView.findViewById(R.id.noOfCasesTextView)
        private val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)
        private val view: TextView = itemView.findViewById(R.id.view)

        fun bind(pallet: PalletObj) {
            palletNumberTextView.text = pallet.palletNbr
            noOfCasesTextView.text =  pallet.noOfCases.toString()
            statusTextView.text = pallet.status
            view.text = "[VIEW]"
            view.setOnClickListener { listener.onItemSelected(pallet.palletNbr) }
        }
    }

    interface OnAdapterClickListener {
        fun onItemSelected(palletNbr: String?)
    }
}