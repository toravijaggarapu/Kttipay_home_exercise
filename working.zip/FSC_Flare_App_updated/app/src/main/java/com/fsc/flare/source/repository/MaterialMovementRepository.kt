package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inquiry.location.resp.LocationDetailsResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.materialMovement.ContainerSourceDetail
import com.fsc.flare.source.data.dto.materialMovement.TransferToLocationRequest
import com.fsc.flare.source.data.dto.materialMovement.TransferToLocationResponse
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

interface MaterialMovementRepository {
    suspend fun getLookups(lookupNames: String): Response<LookUps>

    suspend fun getMaterialMovementSourceDetails(
        movementType: String,
        transferTo: String,
        toteOrCartonOrPalletID: String
    ): Response<ContainerSourceDetail>

    suspend fun validateLocation(
        location: String?,
        locationClass: String?
    ): Response<LocationDetailsResponse>

    suspend fun transferToLocation(
        destLocBarcode: String,
        movementType: String,
        transferTo: String,
        toteOrCartonOrPalletIds: List<Long>,
        canUseInUsedQA: Boolean,
    ): Response<TransferToLocationResponse>
}

class MaterialMovementRepositoryImpl @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
): MaterialMovementRepository{

    override suspend fun getLookups(lookupNames: String) = apiGatewayInterface.getLookUps(
        gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null).orEmpty(),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        lookupNames = lookupNames
    )

    override suspend fun getMaterialMovementSourceDetails(
        movementType: String,
        transferTo: String,
        toteOrCartonOrPalletID: String
    ) = apiGatewayInterface.getMaterialMovementSourceDetails(
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyIdHeader = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buIdHeader = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        custIdHeader = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        movementType = movementType,
        transferTo = transferTo,
        toteOrCartonOrPalletID = toteOrCartonOrPalletID
    )

    override suspend fun validateLocation(
        location: String?,
        locationClass: String?
    ) = apiGatewayInterface.getLocationDetails(
        gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        barcode = location,
        locationClass = locationClass
    )

    override suspend fun transferToLocation(
        destLocBarcode: String,
        movementType: String,
        transferTo: String,
        toteOrCartonOrPalletIds: List<Long>,
        canUseInUsedQA: Boolean,
    ): Response<TransferToLocationResponse> {

        val request = TransferToLocationRequest(
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            destLocBarcode = destLocBarcode,
            movementType = movementType,
            transferTo = transferTo,
            toteOrCartonOrPalletIds = toteOrCartonOrPalletIds,
            canUseInUsedQA = canUseInUsedQA
        )

        return apiGatewayInterface.transferToLocation(
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            transferToLocationRequest = request
        )
    }
}