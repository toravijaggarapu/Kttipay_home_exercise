package com.fsc.flare.ui.fragment.totefrompackstationtopr

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteResponse
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteToPRLocationRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialResponse
import com.fsc.flare.source.repository.PackStationToPRRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PackstationToPRViewModel"
@HiltViewModel
class PackstationToPRViewModel @Inject constructor(private val repository: PackStationToPRRepository) : BaseViewModel() {
    val toteResponse: MutableLiveData<Resource<PackStationToteResponse>> = SingleLiveEvent()
    val toteTransferResponse: MutableLiveData<Resource<PickingSerialResponse>> = SingleLiveEvent()
    val locationClassResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()

    var toteDetails: PackStationToteResponse? = null
    private var toteNumberList: ArrayList<String> = ArrayList()
    var toteIdsList: ArrayList<Int> = ArrayList()
    private var shimpentCartonIds: ArrayList<Int> = ArrayList()

    fun getPackStationTote(toteNumber: String) = viewModelScope.launch {
        toteResponse.postValue(Resource.Loading())
        val response = repository.getPackStationToteDetails(toteNumber)
        toteResponse.postValue(handleToteDetailsResponse(response))
    }

    private fun handleToteDetailsResponse(response: Response<PackStationToteResponse>): Resource<PackStationToteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleToteDetailsResponse Success: $resultResponse")
                toteDetails = resultResponse
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleToteDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun updatePackStationToPRLocation(packStationToteToPRLocationRequest: PackStationToteToPRLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "updateToPackStation Request: $packStationToteToPRLocationRequest")
        toteTransferResponse.postValue(Resource.Loading())
        val response = repository.updatePackStationToPRLocation(packStationToteToPRLocationRequest)
        toteTransferResponse.postValue(handlePackStationPRLocationResponse(response))
    }

    private fun handlePackStationPRLocationResponse(response: Response<PickingSerialResponse>): Resource<PickingSerialResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handlePackStationPRLocationResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handlePackStationPRLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateStagingLocation Request: $locationClassReq")
        locationClassResponse.postValue(Resource.Loading())
        val response = repository.validatePRLocation(locationClassReq)
        locationClassResponse.postValue(handleLocationClassResponse(response))
    }

    private fun handleLocationClassResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun saveToteNumber() {
        toteNumberList.add(toteDetails!!.toteNumber!!)
    }

    fun getToteNumbersList(): ArrayList<String> {
        return toteNumberList
    }

    private fun resetToteNumbersList() {
        toteNumberList.clear()
    }

    private fun saveShipmentCartonId() {
        shimpentCartonIds.add(toteDetails!!.shipmentCartonId)
    }

    fun getShipmentCartonsList(): ArrayList<Int> {
        return shimpentCartonIds
    }

    private fun resetShipmentCartonList() {
        shimpentCartonIds.clear()
    }

    private fun resetToteIdList() {
        toteIdsList.clear()
    }

    fun resetData() {
        resetToteNumbersList()
        resetShipmentCartonList()
        resetToteIdList()
    }

    fun saveToteDetails() {
        saveToteNumber()
        saveShipmentCartonId()
    }

    fun removeUncheckedTotesAndCartonIds(checkedTotes: ArrayList<String>, checkedShipmentCartonIds: ArrayList<Int>) {
        toteNumberList.removeAll(checkedTotes)
        shimpentCartonIds.removeAll(checkedShipmentCartonIds)
    }
}