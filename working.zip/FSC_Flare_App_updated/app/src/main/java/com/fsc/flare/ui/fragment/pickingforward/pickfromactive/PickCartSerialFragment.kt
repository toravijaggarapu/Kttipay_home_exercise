package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.ui.fragment.receiving.SerialAdapter
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_OUTBOUND_ONLY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartSerialFragment"

/**
 * A simple [PickCartSerialFragment] class.
 */
@AndroidEntryPoint
class PickCartSerialFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: SerialAdapter

    private val viewModel: PickingForwardViewModel by activityViewModels()
    private lateinit var binding: FragmentPickCartSerialBinding
    private var serialList = ArrayList<String>()
    private var scannedSerial = ""
    var serialNumberList = mutableListOf<String>()
    private var isSerialTracked = false

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPickCartSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        if(!viewModel.getSerialNumberList().isNullOrEmpty()) {
            isSerialTracked = true
        }
        if(!isSerialTracked){
            subscribeObservers()
        }
        return binding.root
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeSerialValidationObserver()
    }


    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            serialNumberList = viewModel.getSerialList()
            if (isSerialTracked && !viewModel.getSerialNumberList().isNullOrEmpty()){
                serialList =  viewModel.getSerialNumberList() as ArrayList<String>
                binding.tvSerialValue.text = "(${serialNumberList.size}/${taskData.pickedQty})"
                binding.tvSerialNumberValue.visibility = View.VISIBLE
                binding.tvSerialNumberReadOnlyLbl.visibility = View.VISIBLE
                binding.tvSerialNumberValue.text = serialList.get(0)
            } else {
                isSerialTracked = false
                serialList = viewModel.getSerialList()
                binding.tvSerialValue.text = "(${serialList.size}/${taskData.pickedQty})"
                binding.tvSerialNumberValue.visibility = View.GONE
                binding.tvSerialNumberReadOnlyLbl.visibility = View.GONE
            }

        }
        setupRecyclerView()

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                    FlareLog.i(TAG, "SerialNo field focused")
                    validateEditTextValue()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                FlareLog.i(TAG, "SerialNo field focused")
                validateEditTextValue()
            }
            false
        }
        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.tvSerialNumberResponse.text = null
            }
        })
    }

    /**
     * method to verify editText value is valid or not before validate against serial number list
     */
    private fun validateEditTextValue(){
        if (isSerialTracked) {
            if (binding.etSerialNumber.text.toString().trim()
                    .isNotEmpty() && binding.tvSerialNumberValue.text.toString()
                    .trim() == binding.etSerialNumber.text.toString().trim()
            ) {
                serialNumberValidate()
            } else {
                displayErrorMessage(getString(R.string.serial_number_invalid))
            }
        } else {
            if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                validateSerialNumber()
            }
        }
    }


    /**
     * method to verify serial number from Taskpick API Response TaskDetails Object Serial number list
     */
    private fun serialNumberValidate() {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            val serialNumber = binding.etSerialNumber.text.toString().trim()
            if (serialNumberList.size < taskData.pickedQty) {
                if (!serialNumberList.contains(serialNumber)) {
                    if (isLengthValidationNeeded(taskData) && taskData.srlNbrLength?.toInt() != serialNumber.length) {
                        displayErrorMessage(resources.getString(R.string.lbl_serail_number_length_must_be,taskData.srlNbrLength))
                        return
                    }
                    if(serialList.contains(serialNumber)){
                            FlareLog.i(TAG, "serialList contains")
                            scannedSerial =
                                binding.etSerialNumber.text.toString().trim()
                            showSuccessSnackBar(resources.getString(R.string.serial_number_is_validated))
                            serialNumberUpdate()
                        }


                } else {
                    displayErrorMessage(resources.getString(R.string.duplicate_serial))
                }
            } else {
                binding.etSerialNumber.text = null
                navigateToNext(taskData)
            }
        }
    }

    /**
     * method to verify serial number from API
     */
    private fun validateSerialNumber() {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            val serialNumber = binding.etSerialNumber.text.toString().trim()
            if (serialList.size < taskData.pickedQty) {
                if (!serialList.contains(serialNumber)) {
                    if (isLengthValidationNeeded(taskData) && taskData.srlNbrLength?.toInt() != serialNumber.length) {
                        displayErrorMessage(resources.getString(R.string.lbl_serail_number_length_must_be,taskData.srlNbrLength))
                        return
                    }
                    if (scannedSerial.isNotEmpty() && scannedSerial == binding.etSerialNumber.text.toString().trim()){
                        serialNumberUpdate()
                    } else {
                        val isOutBoundOnly =
                            taskData.itemSerialTracked == SERIAL_TRACK_OUTBOUND_ONLY
                        viewModel.validateSerialNumberOrItemCode(
                            serialNumber,
                            isOutBoundOnly,
                            taskData.pullLocationId,
                            taskData.itemId,
                            taskData.taskId.toLong(),
                            taskData.containerNbr,
                            taskData.containerId
                        )
                    }
                } else {
                    displayErrorMessage(resources.getString(R.string.duplicate_serial))
                }
            } else {
                binding.etSerialNumber.text = null
                navigateToNext(taskData)
            }
        }
    }

    private fun displayErrorMessage(errorMessage: String) {
        binding.tvSerialNumberResponse.text = errorMessage
        binding.etSerialNumber.requestFocus()
        binding.etSerialNumber.selectAll()
    }

    private fun isLengthValidationNeeded(taskData: TaskDetails?): Boolean {
        return taskData != null && !taskData.srlNbrValidation.isNullOrEmpty() && taskData.itemSerialTracked == SERIAL_TRACK_OUTBOUND_ONLY && taskData.srlNbrValidation == "Y" && isValidDigit(taskData.srlNbrLength)
    }

    /**
     * method to observe serial validation response
     */
    private fun subscribeSerialValidationObserver() {
        viewModel.serialItemIdValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialOrItemIdValidationResponse ->
                        FlareLog.i(TAG, "serialValidation Response: $serialOrItemIdValidationResponse")
                        if (serialOrItemIdValidationResponse.success != null && serialOrItemIdValidationResponse.success) {
                            FlareLog.i(TAG, "serialValidation Success: $serialOrItemIdValidationResponse")
                            serialOrItemIdValidation(serialOrItemIdValidationResponse)
                        } else {
                            FlareLog.i(TAG, "serialValidation error: $serialOrItemIdValidationResponse")
                            if (serialOrItemIdValidationResponse.message != null) {
                                displayErrorMessage(serialOrItemIdValidationResponse.message)
                            }else
                            {
                                displayErrorMessage(getString(R.string.something_went_wrong_services))
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        displayErrorMessage(message)
                    }
                }
            }
        }
    }

    private fun serialOrItemIdValidation( serialOrItemIdValidationResponse : PickingSerialOrItemCodeResponse){
        if (!serialList.contains(binding.etSerialNumber.text.toString().trim())) {
            if (serialOrItemIdValidationResponse.isNew
                && (viewModel.getPickTaskDetails()?.allocationType == "10" || viewModel.getPickTaskDetails()?.allocationType == "11")
                && (scannedSerial.isEmpty() || scannedSerial != binding.etSerialNumber.text.toString().trim())) {
                scannedSerial =
                    binding.etSerialNumber.text.toString().trim()
                displayErrorMessage(getString(R.string.serial_number_not_exist_rescan_the_same_serial_number_to_add))
            } else if (serialOrItemIdValidationResponse.isSerialNumberValid) {
                serialNumberUpdate()
            } else {
                if (serialOrItemIdValidationResponse.message != null) {
                    displayErrorMessage(serialOrItemIdValidationResponse.message)
                } else {
                    displayErrorMessage(getString(R.string.something_went_wrong_services))
                }
            }
        } else {
            displayErrorMessage(resources.getString(R.string.duplicate_serial))
        }
    }

    private fun serialNumberUpdate() {
        if (isSerialTracked){
            serialNumberList.add(binding.etSerialNumber.text.toString().trim())
            serialListAdapter.notifyDataSetChanged()
            binding.etSerialNumber.text = null
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                binding.tvSerialValue.text = String.format("%d/%d",serialNumberList.size,taskData.pickedQty)
                if (serialNumberList.size == taskData.pickedQty) {
                    binding.etSerialNumber.isEnabled = false
                    saveSerialListToSharedPref()
                    navigateToNext(taskData)
                } else {
                    binding.tvSerialNumberValue.text = serialList.get(serialNumberList.size)
                }
            }
        } else {
            serialList.add(binding.etSerialNumber.text.toString().trim())
            serialNumberList.add(binding.etSerialNumber.text.toString().trim())
            serialListAdapter.notifyDataSetChanged()
            binding.etSerialNumber.text = null
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                binding.tvSerialValue.text = String.format("%d/%d",serialList.size,taskData.pickedQty)
                if (serialList.size == taskData.pickedQty) {
                    binding.etSerialNumber.isEnabled = false
                    saveSerialListToSharedPref()
                    navigateToNext(taskData)
                }
            }

        }
        scannedSerial = ""
    }

    private fun navigateToNext(taskData: TaskDetails) {
        isSerialTracked = false
        Handler(Looper.getMainLooper()).postDelayed({
            val allocationType = AllocationType.entries.find { it.code == taskData.allocationType }
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)

            when (allocationType) {
                AllocationType.ALLOCATED_FROM_ACTIVE,
                AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL,
                AllocationType.PICK_FROM_ACTIVE,
                AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV,
                AllocationType.PICK_FROM_ACTIVE_RTV-> {
                    val action = PickCartSerialFragmentDirections.actionPickCartSerialFragmentToPickCartSlotFragment()
                    navController.navigate(action)
                }
                AllocationType.PICK_FROM_CASE_PICK,
                AllocationType.ALLOCATED_FROM_CASE_PICK,
                AllocationType.PICK_FROM_CASE_PICK_RTV,
                AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV,
                AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV-> {
                    val action = PickCartSerialFragmentDirections.actionPickCartSerialFragmentToPickCartFragment()
                    navController.navigate(action)
                }
                else -> {
                    // Handle other cases if necessary or do nothing
                }
            }
        }, 500)
    }


    /**
     * method to save serial list to shared preferences
     */
    private fun saveSerialListToSharedPref() {
        val json = Gson().toJson(serialNumberList)
        sharedPreferences.edit().putString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, json).apply()
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        if(isSerialTracked)
            serialListAdapter = SerialAdapter(serialNumberList as ArrayList<String>)
        else
            serialListAdapter = SerialAdapter(serialList)

        binding.rvSerial.adapter = serialListAdapter
    }

    /**
     * method to hide progressbar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    /**
     * method to show progressbar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        binding.etSerialNumber.setText(scan?.barcode.toString())
        binding.etSerialNumber.text?.length?.let {
            binding.etSerialNumber.setSelection(
                it
            )
            FlareLog.i(TAG, "SerialNumber field focused")
            if(isSerialTracked) {
                if (binding.tvSerialNumberValue.text.toString().trim() == binding.etSerialNumber.text.toString().trim()) {
                    serialNumberValidate()
                } else {
                    displayErrorMessage(getString(R.string.serial_number_invalid))
                }
            } else{
                validateSerialNumber()
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}