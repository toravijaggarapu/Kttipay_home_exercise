package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSCReverseSkuBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuPutawayDetails
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SCReverseSkuFragment"
@AndroidEntryPoint
class SCReverseSkuFragment : BaseFragment(), FlareScannable {

    private val viewModel: SplitContainerReverseViewModel by activityViewModels()
    private lateinit var binding: FragmentSCReverseSkuBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSCReverseSkuBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //set container number
        binding.tvContainerNumberValue.text = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null)

        binding.etSku.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtSkuResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v.onTouchEvent(event)
        }

        binding.etSku.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.etSku.isFocused && !binding.etSku.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "SKU field focused")
            validateSkuAPI()
        }
    }

    /**
     * method to validate sku field from API
     */
    private fun validateSkuAPI() {
        viewModel.validateSku(
            SplitSkuRequest(
                dataSource = "RF",
                putaway = SplitSkuPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null).toString(),
                    channel = sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString(),
                    sku = binding.etSku.text.toString()
                )
            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSkuObserver()
    }


    /**
     * method for fromContainer response observer
     */
    private fun subscribeSkuObserver() {
        viewModel.skuResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skuRes ->
                        FlareLog.i(TAG, "sku response : ${response.data}")
                        when (skuRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "sku response Error : ${skuRes.statusHandler.error}")
                                binding.etSku.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etSku)
                                binding.txtSkuResponse.text = skuRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "sku response Success: $skuRes")
                                sharedPreferences.edit().putString(PreferenceKeys.SC_SKU_ITEMBARCODE, binding.etSku.text.toString()).apply()

                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = SCReverseSkuFragmentDirections.actionSCReverseSKUFragmentToSCReverseQTYFragment()
                                navController.navigate(action)

                            }
                            else ->
                                FlareLog.e(TAG, "sku response error : ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "sku response error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }




    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etSku.setText(scan?.barcode.toString())
                binding.etSku.text?.length?.let {
                    binding.etSku.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "SKU field focused")
                    validateSkuAPI()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}