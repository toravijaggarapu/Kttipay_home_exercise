package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.buildSpannedString
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentKittingSerialBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "KittingSerialFragment"

/**
 * A simple [InvMoveKSSerialFragment] class.
 */
@AndroidEntryPoint
class InvMoveKSSerialFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: InvMoveKSViewModel by activityViewModels()
    private lateinit var binding: FragmentKittingSerialBinding
    private lateinit var pallet: PalletResponse

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        viewModel.serialNumberList = mutableListOf()
        viewModel.validatedSerialNumberList = mutableListOf()
        binding.tvSerialNumberValue.text = buildSpannedString {
            append("${(viewModel.fetchValidatedSerialNumberList().size)} / ${viewModel.getMoveQty()}")
        }
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.etSerialNumber.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentKittingSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        pallet = viewModel.getPalletResponse()
        val item = viewModel.selectedItem
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        if (pallet.palletNumber != null) {
            binding.tvPalletNumberValue.text = pallet.palletNumber
        } else {
            binding.tvPalletNumber.visibility = View.GONE
            binding.tvPalletNumberValue.visibility = View.GONE
        }
        if (pallet.containerNumber != null && item?.lotRequired == "1") {
            binding.tvLotNumberValue.text = viewModel.lot
        } else {
            binding.tvLotNumber.visibility = View.GONE
            binding.tvLotNumberValue.visibility = View.GONE
        }

        if (pallet.containersList!![0].items!!.size > 1) {
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
                binding.tvTotalQtyValue.text = item.qty.toString()
            }
        } else {
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
            }
            binding.tvTotalQtyValue.text = pallet.totalQty.toString()
        }
        binding.tvKitStagingLocation.text = getString(R.string.lbl_kit_station)
        binding.tvKitStagingLocationValue.text = pallet.kitStationLocation
        binding.tvMoveQty.text = getString(R.string.transferring_qty)
        binding.tvMoveQtyValue.text = viewModel.getMoveQty()

        // Hide Kit Item Details
        binding.kittingItemLayout.visibility = View.GONE
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etSerialNumber.requestFocus()
        handleTouchAndFocusEvents()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Serial field focused")
                        isSerialExists()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                FlareLog.i(TAG, "Serial field focused")
                isSerialExists()
            }
            return@setOnEditorActionListener false
        }

        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                binding.tvSerialErrorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }


    private fun isSerialExists() {
        val item = viewModel.selectedItem

        item?.let {
            if (it.srlNbrReqd == "4") {
                // Check if serialNumbers are present in the serialNumbers
                if (it.serialNumbers != null && it.serialNumbers.containsAll(it.serialNumbers)) {
                    // If serialNumbers exist, add them to the viewModelObject
                    viewModel.serialNumberList = it.serialNumbers
                    validateSerialNumber()
                } else {
                    binding.tvSerialErrorResponse.text = getString(R.string.serial_doesnot_exist)
                    viewModel.serialNumberList = null
                }
            } else {
                binding.tvSerialErrorResponse.text = getString(R.string.serial_doesnot_exist)
                viewModel.serialNumberList = null
            }
        }
    }

    private fun validateSerialNumber() {
        val userInput = binding.etSerialNumber.text.toString().trim()

        if (userInput.isEmpty()) {
            showError(getString(R.string.input_serial_number))
            return
        }

        val serialNumberList = viewModel.fetchSerialNumberList()
        val validatedSerialNumberList = viewModel.fetchValidatedSerialNumberList()

        if (userInput in (serialNumberList ?: emptyList())) {
            if (userInput !in validatedSerialNumberList) {
                // Serial number is valid and not in the validated list
                viewModel.validatedSerialNumberList.add(userInput)
                updateCounterAndCheckCompletion()
            } else {
                // Serial number is already in the validated list
                showError("$userInput already added")
            }
        } else {
            // Invalid Serial
            showError(getString(R.string.invalid_serial_number))
        }
    }

    private fun updateCounterAndCheckCompletion() {
        binding.tvSerialNumberValue.text = buildSpannedString {
            append("${viewModel.fetchValidatedSerialNumberList().size} / ${viewModel.getMoveQty()}")
        }

        if (viewModel.getMoveQty().toInt() == viewModel.fetchValidatedSerialNumberList().size) {
            navigateToNext()
        } else {
            binding.etSerialNumber.text = null
        }
    }

    private fun showError(message: String) {
        binding.tvSerialErrorResponse.text = message
    }

    private fun navigateToNext() {
        binding.etSerialNumber.text = null
        navController.navigate(R.id.action_invMoveKSSerialFragment_to_invMoveKSdestinationLocationFragment)
    }
}