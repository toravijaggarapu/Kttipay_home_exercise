package com.fsc.flare.ui.fragment.packing

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackingInputDetailsBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packing.res.CartonInfo
import com.fsc.flare.source.data.dto.packing.res.PackingPackResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackingFragment"
private const val PACK_METHOD_LIST = "PACK_METHOD_LIST"
private const val PACK_BY_CARTON = "PACK_BY_CARTON"
private const val PRINTER_TYPE_DOCUMENT = "DOC"

@AndroidEntryPoint
class PackingFragment : BaseFragment(), FlareScannable {

    var cartonNumber:String = ""
    var toteNumber:String = ""

    lateinit var binding: FragmentPackingInputDetailsBinding
    private val viewModel: PackingViewModel  by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {

        // Inflate the layout for this fragment
        binding = FragmentPackingInputDetailsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        subscribeObservers()

        return binding.root
    }

    fun subscribeObservers() {
        // Get Pack Station List from API
        viewModel.packStationListResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packStationListResponse ->
                        FlareLog.i(TAG, "PackStationListResponse success: $packStationListResponse")

                        viewModel.printRequestorDescList.clear()
                        viewModel.printRequestorHashmap.clear()

                        if (packStationListResponse.printerConfigs.isNotEmpty()) {
                            packStationListResponse.printerConfigs.forEach {
                                if(it.printerType == PRINTER_TYPE_DOCUMENT) {
                                    viewModel.printRequestorDescList.add(it.requestor)
                                    viewModel.printRequestorHashmap[it.requestor] = it
                                }
                            }
                        }
                        viewModel.printRequestorDescList.sort()
                        binding.tvPackStationValue.setOptions(viewModel.printRequestorDescList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackStationListResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Pack Method List from API
        viewModel.packMethodListResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "packMethodListResponse success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { lookUp ->
                            if (lookUp.lookupName == PACK_METHOD_LIST && lookUp.lookupCodes.isNotEmpty()) {
                                viewModel.packMethodsLookUpList = ArrayList(lookUp.lookupCodes)

                                viewModel.packMethodsLookUpList.forEach {
                                      lookupCode ->

                                    if(lookupCode.lookupCode == PACK_BY_CARTON) {
                                        viewModel.packMethodList = ArrayList()
                                        viewModel.packMethodList.add(lookupCode.lookupCodeDescription)
                                        binding.tvPackMethodValue.setOptions(viewModel.packMethodList)
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackMethodListResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // Get Packing Status From API
        viewModel.packAPIResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packAPIResponse ->
                        FlareLog.i(TAG, "packAPIResponse success: $packAPIResponse")
                        handlePackAPIResponse(packAPIResponse)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PACK API Response error: $message")

                        if(cartonNumber.isEmpty()) {
                            binding.tvErrorTote.text = message
                            binding.etToteNumber.requestFocus()
                            binding.etToteNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etToteNumber)
                        }
                        else if(toteNumber.isEmpty()){
                            binding.tvErrorCarton.text = message
                            binding.etCartonNumber.requestFocus()
                            binding.etCartonNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etCartonNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Call PackStation API
        viewModel.getPackStationList()

        // Call PackMethod API
        viewModel.getPackMethods()

        viewModel.selectedPackMethod = null
        binding.tvPackMethodValue.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            viewModel.selectedPackMethod = null
            viewModel.packMethodsLookUpList.forEach {
                lookupCode ->
                if(lookupCode.lookupCodeDescription.equals(isUpdated,true)){
                    viewModel.selectedPackMethod = lookupCode
                }
            }
        }

        viewModel.selectedPackStation = null
        binding.tvPackStationValue.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            viewModel.selectedPackStation = null
            val selectedPackStation = viewModel.printRequestorHashmap[isUpdated]
            viewModel.selectedPackStation = selectedPackStation
        }

        binding.etCartonNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvErrorCarton.text = ""
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etCartonNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Carton Number field focused")
                validateCartonNumber(v.text.toString())
            }
            false
        }

        binding.etToteNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvErrorTote.text = ""
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etToteNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Tote Number field focused")
                validateToteNumber(v.text.toString())
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etToteNumber.isFocused && !binding.etToteNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "ToteNumber field focused")
                        validateToteNumber(binding.etToteNumber.text.toString())
                    }
                    else if (binding.etCartonNumber.isFocused && !binding.etCartonNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "CartonNumber field focused")
                        validateCartonNumber(binding.etCartonNumber.text.toString())
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }

        when {
            binding.etCartonNumber.isFocused -> {
                binding.etCartonNumber.setText(scan?.barcode.toString())
                binding.etCartonNumber.text?.length?.let {
                    binding.etCartonNumber.setSelection(it)
                }
                FlareLog.i(TAG, "CartonNumber field focused")
                validateCartonNumber(binding.etCartonNumber.text.toString())
            }

            binding.etToteNumber.isFocused -> {
                binding.etToteNumber.setText(scan?.barcode.toString())
                binding.etToteNumber.text?.length?.let {
                    binding.etToteNumber.setSelection(it)
                }
                FlareLog.i(TAG, "ToteNumber field focused")
                validateToteNumber(binding.etToteNumber.text.toString())
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    fun validateCartonNumber(cartonNumber:String){
        this.cartonNumber = cartonNumber
        this.toteNumber = ""
        binding.etToteNumber.setText("")
        callingPackAPI()
    }

    fun validateToteNumber(toteNumber:String){
        this.toteNumber = toteNumber
        this.cartonNumber = ""
        binding.etCartonNumber.setText("")
        callingPackAPI()
    }
    fun callingPackAPI(){

        if(viewModel.selectedPackMethod == null){
            showErrorSnackBar(resources.getString(R.string.select_pack_method))
            return
        }

        if(viewModel.selectedPackStation == null){
            showErrorSnackBar(resources.getString(R.string.select_pack_station))
            return
        }

        if(toteNumber.isEmpty() && cartonNumber.isEmpty()){
            return
        }
        viewModel.callPackAPI(toteNumber,cartonNumber)
    }

    fun handlePackAPIResponse(packAPIResponse:PackingPackResponse){

        // Handle Carton Status
        if(isContainerStatusValid(packAPIResponse.carton) && isPackMethodValid(packAPIResponse.carton)) {

            viewModel.cartonInfo = packAPIResponse.carton
            viewModel.cartonNumber = cartonNumber
            viewModel.toteNumber = toteNumber

            if(viewModel.isContainerManifested(packAPIResponse.carton) == true) {
                navigateToManifestFragment()
            }
            else {
                navigateToShippingMethodFragment()
            }
        }
        else {
            if(cartonNumber.isEmpty()) {
                binding.tvErrorTote.text = resources.getText(R.string.error_carton_not_eligible_packing)
                binding.etToteNumber.requestFocus()
                binding.etToteNumber.selectAll()
                showSoftKeyBoard(fragmentContext, binding.etToteNumber)
            }
            else if(toteNumber.isEmpty()){
                binding.tvErrorCarton.text = resources.getText(R.string.error_carton_not_eligible_packing)
                binding.etCartonNumber.requestFocus()
                binding.etCartonNumber.selectAll()
                showSoftKeyBoard(fragmentContext, binding.etCartonNumber)
            }
        }
    }

    fun isPackMethodValid(carton:CartonInfo):Boolean {
        return carton.packingMethod.isNullOrEmpty() || carton.packingMethod == PACK_BY_CARTON
    }

    fun isContainerStatusValid(carton:CartonInfo):Boolean {
        return viewModel.isContainerPickingCompleted(carton) == true ||
                viewModel.isContainerPackCompleted(carton) == true ||
                viewModel.isContainerManifested(carton) == true ||
                viewModel.isContainerWeighed(carton) == true
    }

    fun navigateToShippingMethodFragment(){
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)

        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackingFragmentDirections.actionPackingFragmentToPackingSelectShippingMethodFragment()
        navController.navigate(action)
    }

    fun navigateToManifestFragment(){
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)

        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackingFragmentDirections.actionPackingFragmentToPackingSuccessFragment()
        navController.navigate(action)
    }
}