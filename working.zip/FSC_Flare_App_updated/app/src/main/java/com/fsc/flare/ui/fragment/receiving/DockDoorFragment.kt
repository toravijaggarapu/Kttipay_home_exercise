package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentDockDoorBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.ExitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentRequest
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_INVENTORY_TYPES
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import org.joda.time.DateTime
import java.util.Locale
import javax.inject.Inject

private const val TAG = "DockDoorFragment"

/**
 * [DockDoorFragment] class.
 */
@AndroidEntryPoint
class DockDoorFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentDockDoorBinding

    lateinit var cb1: CustomVisibilityCallback

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    super.onTouch(v, event)
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.dockDoorId.setOnEditorActionListener { v, actionId, event ->
            super.onEditorAction(v,actionId, event)
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        //========  E N D   R E C E I V I N G ============
        binding.btnEndReceiving.setOnClickListener {
            binding.btnEndReceiving.isEnabled = false
            val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            val facilityId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            viewModel.exitReceiving(
                ExitReceivingRequest(
                    asnNumber = viewModel.getAsn().asnNumber,
                    asnStatus = "30",
                    dataSource = "RF",
                    fcyId = facilityId,
                    locations = emptyList(),
                    transactionDate = DateTime.now().toString(),
                    custId = custId,
                    buId = buId
                )
            )
        }
        //========  E N D   R E C E I V I N G ============


        callLookUpAPI()
    }

    private fun callLookUpAPI() {
        viewModel.getInventoryTypeLookUps(
            LookUpsRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                lookupNames = LOOKUP_INVENTORY_TYPES
            )
        )
    }

    /**
     * Function to observe Exi Receiving response
     */
    private fun observeExitReceivingResponse() {
        viewModel.exitReceivingResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { exitResponse ->
                        if (exitResponse.success) {
                            FlareLog.i(TAG, "exitReceiving success: $exitResponse")
                            viewModel.setAsn(null)
                            showSuccessSnackBarStd(exitResponse.message) {
                                findNavController().popBackStack()
                            }
                        } else {
                            binding.btnEndReceiving.isEnabled = true
                            showErrorSnackBar(exitResponse.message)
                            FlareLog.e(TAG, "packageItem error: ${exitResponse.message}")
                        }
                    }
                }
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    binding.btnEndReceiving.isEnabled = true
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "exitReceiving Error: $message")
                    }
                }
            }
        }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        super.onResume()
        cb1.onVisibilityChange(true)

        //Shared pref object clear the values,
        clearSharedPrefValues()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentDockDoorBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
       // binding.tvReceiving.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.dockDoorId.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.dockDoorIdResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.dockDoorId.onFocusChangeListener = this
        subscribeObservers()
        observeExitReceivingResponse()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.inBoundShipmentResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "inBoundShipment Response: ${response.data}")
                    response.data?.let { asnResponse ->
                        if (asnResponse.success) {
                            FlareLog.i(TAG, "inBoundShipment success: $asnResponse")
                            hideProgressBar()
                            if (asnResponse.inboundShipments != null) {
                                if (indexExists(asnResponse.inboundShipments, 0)) {
                                    val inboundShipment = asnResponse.inboundShipments[0]
                                    viewModel.setAsn(inboundShipment)
                                    binding.dockDoorId.text = null
                                    viewModel.emptyFirstArticleMsgShown()
                                    val action = DockDoorFragmentDirections.actionDockDoorFragmentToItemBarcodeFragment()
                                    getNavigationController().navigate(action)
                                   /* if (inboundShipment.receivingType == "ITEM") {
                                        // NO LPNs Found in the ASN proceed with the Item Level Receiving
                                        viewModel.setAsn(inboundShipment)
                                        binding.dockDoorId.text = null
                                        viewModel.emptyFirstArticleMsgShown()
                                        val action = DockDoorFragmentDirections.actionDockDoorFragmentToItemBarcodeFragment()
                                        getNavigationController().navigate(action)
                                    } else {
                                        // LPNs Found in the ASN Data. Force the user to use the Receiving by Carton / Receiving by Pallet Options
                                        showLPNsFoundAlert()
                                    }*/
                                }
                            } else {
                                displayErrorMessage(resources.getString(R.string.lbl_no_asn_found_with_arrived_status_for_this_dock_door))
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "inBoundShipment Error: $message")
                        displayErrorMessage(message)
                    }
                }
            }
        }

        viewModel.inventoryTypesLookUpResponse.observe(viewLifecycleOwner) { response ->

            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.firstOrNull { it.lookupName == LOOKUP_INVENTORY_TYPES }?.let { lookUp ->
                            val defaultInvTypeList = lookUp.lookupCodes.filter { it.destinationSystemValue == "F" }
                            if(defaultInvTypeList.isNotEmpty()) {
                                val defaultInvTypeCode = defaultInvTypeList[0].lookupCode
                                viewModel.setDefaultInvTypeCode(defaultInvTypeCode)
                                val defaultInvTypeDesc = defaultInvTypeList[0].lookupCodeDescription
                                viewModel.setDefaultInvTypeDesc(defaultInvTypeDesc)
                            }
                            viewModel.setInventoryTypesHashMap(HashMap(lookUp.lookupCodes.associate { it.lookupCode to it.lookupCodeDescription }))
                        }
                    }
                    verifyAndShowContainerType()
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                        showErrorSnackBarStd(message) {
                            findNavController().popBackStack()
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.containerTypes.observe(viewLifecycleOwner) { containerTypes ->
            containerTypes?.let {
                binding.dropMenuContainerType.setOptions(ArrayList(containerTypes))
            }
        }

        /**
         *  Container type selection callback.
         *
         *  Clear the virtual case previous data, to make a fresh start.
         *
         */
        binding.dropMenuContainerType.boolFoo.observe(viewLifecycleOwner) { selectedContainerType ->
            /**
             *  Reset previous values for next receiving.
             */
            viewModel.clearVirtualCaseFlowData()
            viewModel.selectedContainerType = selectedContainerType
            binding.dockDoorId.isEnabled = true
            binding.dockDoorTv.isEnabled = true
            binding.dockDoorTv.requestFocus()
        }
    }

    /**
     *  Based on the lookup value Container type selection enabled or disabled.
     *
     */
    private fun verifyAndShowContainerType() {
        viewModel.selectedContainerType = null
        takeIf { sharedPreferences.getBoolean(PreferenceKeys.PALLATIZE_RECEIVING_ITEM_PREFERENCE, false) }?.let {
            binding.dockDoorId.isEnabled = false
            binding.dockDoorTv.isEnabled = false
            binding.grpContainerType.visibility = View.VISIBLE
            binding.btnEndReceiving.visibility = if (viewModel.isEligibleForEndReceiving())
                View.VISIBLE
            else
                View.GONE
            viewModel.getContainerTypes()
        } ?: run {
            binding.dockDoorId.isEnabled = true
            binding.dockDoorTv.isEnabled = true
            binding.grpContainerType.visibility = View.GONE
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun validateField() {
        if (binding.dockDoorId.isFocused && !binding.dockDoorId.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.dockDoorId)
            sharedPreferences.edit().apply {
                putString(PreferenceKeys.Item.DD_NUMBER, binding.dockDoorId.text.toString().uppercase(Locale.ROOT)).apply()
            }
            FlareLog.i(TAG, "Get ASN Called")
            getASN()
        }
    }

    private fun getASN() {
        viewModel.getASN(
            PackageInboundShipmentRequest(
                "Detail",
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                binding.dockDoorId.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            )
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)

        // Block on scan function for visible progress and container type selection is empty.
        if (isProgressBarVisible() ||
            (sharedPreferences.getBoolean(
                PreferenceKeys.PALLATIZE_RECEIVING_ITEM_PREFERENCE, false) &&
                    viewModel.selectedContainerType == null)
        ) { return }

        sharedPreferences.edit().apply {
            putString(
                PreferenceKeys.Item.DD_NUMBER,
                scan?.barcode.toString().trim().uppercase(Locale.ROOT)
            ).apply()
        }
        binding.dockDoorId.setText(scan?.barcode.toString().trim())
        binding.dockDoorId.text?.length?.let { binding.dockDoorId.setSelection(it) }
        getASN()
    }

    private fun displayErrorMessage(message: String) {
        trackErrorMessage(message)
        binding.dockDoorId.requestFocus()
        binding.dockDoorId.selectAll()
        showSoftKeyBoard(fragmentContext, binding.dockDoorId)
        binding.dockDoorIdResponse.text = message
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun clearSharedPrefValues() {
        val editor = sharedPreferences.edit()
        editor.putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, "")
            .putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, "")
            .putString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, "")
            .putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, "")
            .putString(PreferenceKeys.Item.QUANTITY_INPUT, "")
            .putString(PreferenceKeys.Item.UOM_INPUT, "")
            .putString(PreferenceKeys.RECEIVING_LOT_MESSAGE, "")
            .putString(PreferenceKeys.Item.LOCATION_ID_INPUT, "")
            .apply()
    }

}