package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmTaskGroupsBinding
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmTaskGroupsViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.NavigationFromTaskGroups
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.SnackBarState
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.model.TaskGroups
import com.fsc.flare.utils.Constants.AllocationType.INVENTORY_MOVEMENT_TO_DAMAGE_CASE_PICK
import com.fsc.flare.utils.Constants.AllocationType.INVENTORY_MOVEMENT_TO_DAMAGE_RESERVE
import com.fsc.flare.utils.Constants.ErrorCode.NO_TASK_FOUND
import com.fsc.flare.utils.Constants.AllocationType.INVENTORY_MOVEMENT_TO_ISOLATED_LOCATION
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InvmTaskGroupsFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmTaskGroupsViewModel by viewModels()
    private lateinit var binding: FragmentInvmTaskGroupsBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentInvmTaskGroupsBinding.inflate(inflater, container, false)
        viewModel.getTaskGroups(INVENTORY_MOVEMENT_TO_DAMAGE_CASE_PICK.plus(",")
            .plus(INVENTORY_MOVEMENT_TO_DAMAGE_RESERVE).plus(",")
            .plus(INVENTORY_MOVEMENT_TO_ISOLATED_LOCATION))
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null).plus(" - ").plus(sharedViewModel.selectedTaskMode)
        observeEvents()
        binding.taskModesDropDown.boolFoo.observe(viewLifecycleOwner) { selectedTaskGroup ->
            sharedViewModel.selectedTaskGroup = sharedViewModel.taskGroups?.firstOrNull { it.description == selectedTaskGroup }
            sharedViewModel.selectedTaskGroup?.let { viewModel.getTasks(it) }
        }
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.incProgressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { message ->
            binding.errResponse.text = message ?: ""
        }

        viewModel.showSnackBar.observe(viewLifecycleOwner) { snackType ->
            snackType?.let {
                when (it) {
                    is SnackBarState.Success -> {
                        binding.taskModesDropDown. text = getString(R.string.select_task_group)
                        showSuccessSnackBar(it.message)
                    }

                    is SnackBarState.Error -> {
                        val errMsg = if (it.errorMessage == NO_TASK_FOUND)
                            getString(R.string.no_task_available)
                        else it.errorMessage
                        binding.taskModesDropDown. text = getString(R.string.select_task_group)
                        showErrorSnackBar(errMsg)
                    }
                }
            }
        }

        viewModel.taskGroupResponse.observe(viewLifecycleOwner){taskGroupsResp ->
            sharedViewModel.taskGroups = taskGroupsResp.taskGroups
            binding.taskGroups = sharedViewModel.taskGroups?.let { TaskGroups(it) }
            binding.executePendingBindings()
        }

        viewModel.navigateToScreen.observe(viewLifecycleOwner){navigation ->
            when(navigation){

                is NavigationFromTaskGroups.NavigateToSourceScan -> {
                    sharedViewModel.taskDetails = navigation.taskDetails
                    getNavigationController().navigate(InvmTaskGroupsFragmentDirections.actionInvmTaskGroupsFragmentToInvmSourceScanFragment())
                }
            }
        }
    }

}