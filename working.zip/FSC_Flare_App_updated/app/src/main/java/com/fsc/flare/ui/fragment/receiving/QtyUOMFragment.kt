package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentQtyUomBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.enableOrDisableField
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "QtyUOMFragment"

/**
 * A simple [QtyUOMFragment] class.
 */
@AndroidEntryPoint
class QtyUOMFragment : BaseFragment(), AlertDialogClickListener {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentQtyUomBinding
    private lateinit var itemUomConversionRateUtil: ItemUOMConversionRateUtil
    private var invTypesHashMap: HashMap<String, String> = HashMap()
    private var inventoryTypeSelected : String? = null
    private var  invTypeCode : String? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentQtyUomBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
     //   binding.tvReceiving.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObserver()
        return binding.root
    }
    private fun subscribeObserver() {
        viewModel.validateOverReceiptResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { overReceiptResponse ->
                        FlareLog.i(TAG, "ValidateOverReceipt Response: $response")
                        if ((overReceiptResponse.success) ) {
                            if(!overReceiptResponse.message.isNullOrEmpty()){
                                showAlertDialog("", overReceiptResponse.message, getString(R.string.alert_button_proceed), getString(R.string.alert_button_cancel), this)
                            }else{
                                navigateToNextScreen()
                            }
                        } else {
                            overReceiptResponse.message?.let { displayErrorMessage(it) }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "ValidateOverReceipt Error: $message")
                        displayErrorMessage(response.message)
                    }
                }
            }
        }
    }

    private fun navigateToNextScreen() {
        if (viewModel.getItem().tracking.serialNumberRequired == "4") {
            sharedPreferences.edit().putInt(PreferenceKeys.Item.SCANNED_SERIAL_VAL, 0).apply()
            val action = QtyUOMFragmentDirections.actionQtyUomFragmentToSerialFragment()
            getNavigationController().navigate(action)
        } else {
            val action = QtyUOMFragmentDirections.actionQtyUomFragmentToStatusFragment()
            getNavigationController().navigate(action)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val asnData = viewModel.getAsn()
        val item = viewModel.getItem()
        viewModel.setItem(item)
        itemUomConversionRateUtil = ItemUOMConversionRateUtil(item.uomConversions)
        binding.dockDoor.text = sharedPreferences.getString(PreferenceKeys.Item.DD_NUMBER, null)
        binding.asn.text = asnData.asnNumber
        binding.packageBarcode.text = item.itemBarCode
        binding.itemCode.text = item.itemName
        binding.packageBarcodeDesc.text = item.description
        binding.inventoryTypeDesc.text= viewModel.getInventoryTypeSelected()
        val lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
        val expirationDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
        if (item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()) {
            binding.lotTv.visibility = View.VISIBLE
            binding.lot.visibility = View.VISIBLE
            binding.lot.text = lotNumber
        }
        if (item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()) {
            binding.dateTv.visibility = View.VISIBLE
            binding.date.visibility = View.VISIBLE
            binding.date.text = parseExpiryDate(expirationDate)
        }

        if (viewModel.getManufacturingDate(viewModel.validateLotNumberResponse).isNotEmpty()) {
            binding.mfdateTv.visibility = View.VISIBLE
            binding.mfdate.visibility = View.VISIBLE
            binding.mfdate.text = parseExpiryDate(viewModel.getManufacturingDate(viewModel.validateLotNumberResponse))
        }

        if (item.tracking.countryOfOriginRequired == "1") {
            binding.cooTv.visibility = View.VISIBLE
            binding.coo.visibility = View.VISIBLE
            binding.coo.text = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null)
        }

        if(item.hazmatRequired == "Y"){
            binding.itemClassCodeTv.visibility = View.VISIBLE
            binding.itemClassCode.visibility = View.VISIBLE
            binding.itemClassCode.text = item.hazardous?.hazardClassIMDG
            binding.slash.visibility = View.VISIBLE
            binding.division.visibility = View.VISIBLE
            binding.division.text = item.hazardous?.hazmatDivisionText
        }

        showSoftKeyBoard(fragmentContext, binding.qty)
        binding.qty.setOnEditorActionListener { v, actionId, event ->
            super.onEditorAction(v, actionId, event)
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            super.onTouch(v, event)
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (viewModel.selectedContainerType != PALLET)
                        validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.qty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.quantityInputError.text=""
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.qty.onFocusChangeListener = this
        val uomBottomList = ArrayList<String>()
        item.uomConversions.forEach { uomConversion ->
            if (uomConversion.toUOM != "EA") {
                uomBottomList.add(uomConversion.toUOM + " = " + uomConversion.conversionRate + " " + uomConversion.qtyUOM)
            }
        }
        if(uomBottomList.isEmpty()){
            binding.bottomItemInfo.bottomRootLayout.visibility = View.GONE
        }else{
            for (i in 0..uomBottomList.size) {
                if (indexExists(uomBottomList, i)) {
                    when (i) {
                        0 -> {
                            binding.bottomItemInfo.tvSubPack.text = uomBottomList[i]
                        }
                        1 -> {
                            binding.bottomItemInfo.tvPack.text = uomBottomList[i]
                        }
                        2 -> {
                            binding.bottomItemInfo.tvCase.text = uomBottomList[i]
                        }
                        3 -> {
                            binding.bottomItemInfo.tvPallet.text = uomBottomList[i]
                        }
                    }
                }
            }
        }

        when (viewModel.selectedContainerType) {

            CASE -> {
                binding.qtyTv.text = getString(R.string.quantity_in_cases)
                binding.qty.hint = getString(R.string.no_of_cases_without_colon)
            }

            PALLET -> {
                binding.grpPalletNumber.visibility = View.VISIBLE
                binding.tvPalletNumber.text = viewModel.newPalletNumber
                binding.tvQuantity.text = itemUomConversionRateUtil.getEachesQtyInAPallet().toString()
                binding.uom.text = getString(R.string.pl)
                binding.qtyTv.text = getString(R.string.quantity_in_pallets)
                binding.qty.hint = getString(R.string.quantity_in_pallets)
                binding.qty.setText("1")
                binding.qty.enableOrDisableField(isEnable = false)
                binding.btProceed.visibility = View.VISIBLE
            }
        }

        binding.btProceed.setOnClickListener { validateField() }
    }

    fun validateField(){
        if (binding.qty.text.isNullOrEmpty()) {
            binding.quantityInputError.visibility = View.VISIBLE
            displayErrorMessage(getString(R.string.lbl_qty_required))
            binding.quantityInputError.text = getString(R.string.lbl_qty_required)
            Handler(Looper.getMainLooper()).postDelayed({
                binding.quantityInputError.text = null
            }, 3000)
        } else if (binding.qty.text.toString().toInt() == 0) {
            displayErrorMessage(getString(R.string.master_repack_qty_error))
        }
        else {
            val inputQuantity = binding.qty.text.toString().toInt()
            val actualQuantity = when (viewModel.selectedContainerType) {
                CASE -> {
                    viewModel.casesQuantity = inputQuantity
                    viewModel.eachQuantityInCase = itemUomConversionRateUtil.getEachesQtyInACase() ?: 0
                    inputQuantity * (viewModel.eachQuantityInCase)
                }

                PALLET -> {
                    viewModel.casesQuantity = itemUomConversionRateUtil.getCasesQtyInAPallet() ?: 0
                    viewModel.eachQuantityInCase = itemUomConversionRateUtil.getEachesQtyInACase() ?: 0
                    inputQuantity * (itemUomConversionRateUtil.getEachesQtyInAPallet() ?: 0)
                }

                else -> {
                    inputQuantity
                }
            }

            if (actualQuantity <= 0) {
                binding.quantityInputError.text = getString(R.string.umo_not_getting_properly)
                return
            }

            if ((sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS, false) &&
                        viewModel.selectedContainerType == null && itemUomConversionRateUtil.isCaseUomDefined) &&
                actualQuantity > (itemUomConversionRateUtil.getEachesQtyInACase() ?: 0)
            ) {
                displayErrorMessage(resources.getString(R.string.lbl_entered_qty_cannot_be_greater_than_defined_qty))
            }else{
                sharedPreferences.edit().putString(PreferenceKeys.Item.QUANTITY_INPUT, actualQuantity.toString()).apply()
                sharedPreferences.edit().putString(PreferenceKeys.Item.TRX_QUANTITY_INPUT,actualQuantity.toString()).apply()
                sharedPreferences.edit().putString(PreferenceKeys.Item.UOM_INPUT, "EA").apply() //as we always receive items in eaches, hardcoded the UOM to EA
                invTypesHashMap = viewModel.getInventoryTypesHashMap()
                inventoryTypeSelected = viewModel.getInventoryTypeSelected()
                invTypeCode = invTypesHashMap.entries.find { it.value == inventoryTypeSelected }?.key
                viewModel.validateOverReceipt(asnId = viewModel.getAsn().asnId,
                    itemId = viewModel.getItem().itemId,
                    qty = sharedPreferences.getString(PreferenceKeys.Item.QUANTITY_INPUT, "")?.toInt() ?: -1,
                    invType = invTypeCode,
                    lotNumber= sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
                )
            }
        }
    }
    override fun onPositiveButtonClick() {
        navigateToNextScreen()
    }
    override fun onNegativeButtonClick() {

    }

    fun displayErrorMessage(message: String) {
        trackErrorMessage(message)
        binding.quantityInputError.text = message
    }
}