package com.fsc.flare.source.data.dto

data class ErrorResponse(
    val code: String,
    val description: String
)