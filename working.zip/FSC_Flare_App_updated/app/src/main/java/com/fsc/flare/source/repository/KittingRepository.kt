package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.kitting.KittingCompleteRequest
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class KittingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun getCasePallet(
            containerNumber: String,
            transferType: String
        ) =
            apiGatewayInterface.caseTransferValidateContainer(
                "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
                sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                container = containerNumber,
                transferType = transferType
            )

    suspend fun getKittingCasePallet(
        containerNbr: String,
        locationClass: String
    ) =
        apiGatewayInterface.kittingValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNbr = containerNbr,
            locationClass = locationClass
        )

    suspend fun getKittingItemDescription(
        containerId: Int
    ) =
        apiGatewayInterface.kittingItemDescription(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerId = containerId
        )

    suspend fun getKittingStationDetail(
        locationBarcode: String,
        locationClass: String
    ) =
        apiGatewayInterface.validateKitStation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            locationBarcode = locationBarcode,
            locationClass = locationClass
        )

    suspend fun validateKittingComplete(
        kittingCompleteRequest: KittingCompleteRequest
    ) = apiGatewayInterface.validateKittingComplete(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        kittingCompleteRequest = kittingCompleteRequest
    )

    suspend fun inventoryMoveKSToKS(
        kittingCompleteRequest: KittingCompleteRequest
    ) = apiGatewayInterface.inventoryMoveKSToKS(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        kittingCompleteRequest = kittingCompleteRequest
    )

    suspend fun validateLocation(locBarCode: String) =
        apiGatewayInterface.validateLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            barcode = locBarCode,
            locationClass = "KT"
        )
    
    suspend fun getItems(packageItemRequest: PackageItemRequest) =
        apiGatewayInterface.getItemsorUPC(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            responseFilter = packageItemRequest.responseFilter,
            customerId = packageItemRequest.customerId.toString(),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
            page = packageItemRequest.page,
            itemBarcode = packageItemRequest.itemBarcode
        )

    suspend fun sendToPR(request: SendToPRRequest) =
        apiGatewayInterface.sendToPR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            request
        )
}