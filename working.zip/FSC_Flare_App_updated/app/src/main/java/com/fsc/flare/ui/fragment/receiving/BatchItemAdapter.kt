package com.fsc.flare.ui.fragment.receiving

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintSet
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemBatchDetailBinding
import com.fsc.flare.source.data.dto.packout.res.BatchDetail

class BatchItemAdapter(
    private val itemList: List<BatchDetail>,
    private val onItemSelected: (BatchDetail) -> Unit
) : RecyclerView.Adapter<BatchItemAdapter.BatchViewHolder>() {

    private var selectedItemPosition: Int = -1 // Track the selected item position

    inner class BatchViewHolder(val binding: ItemBatchDetailBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: BatchDetail, position: Int) {
            binding.item = item
            binding.isSelected = (position == selectedItemPosition) // Set the selected state

            if (item.isInvalid) {
                setDisabledItemStyle(this) // Call the method to set the disabled item style
                binding.mfgCodeLabel.visibility = View.GONE
                binding.mfgCodeValue.visibility = View.GONE
                val set = ConstraintSet()
                set.clone(binding.parentLayout) // parentLayout is a ConstraintLayout
                set.constrainPercentWidth(binding.batchNumberValue.id, .9f)
                set.applyTo(binding.parentLayout)
                binding.batchNumberValue.setTextColor(Color.RED)
                binding.root.isClickable = false
                binding.root.isEnabled = false
            } else {
                binding.root.setBackgroundColor(Color.WHITE) // Reset the background color for enabled items
                binding.root.alpha = 1.0f // Reset the alpha for enabled items
                binding.root.isClickable = true
                binding.root.isEnabled = true
                binding.radioButton.setOnClickListener {
                    selectedItemPosition = position // Update selected position
                    notifyDataSetChanged() // Refresh the list to reflect the selection
                    onItemSelected(item) // Call the item selected callback
                }
            }

            setViewVisibility(
                item.batchNbr,
                binding.batchNumberLabel,
                binding.batchNumberValue
            )
            setViewVisibility(
                item.manufacturingCode,
                binding.mfgCodeLabel,
                binding.mfgCodeValue
            )
            setViewVisibility(
                item.expirationDate,
                binding.expirationDateLabel,
                binding.expirationDateValue
            )
            setViewVisibility(
                item.manufacturingDate,
                binding.mfgDateLabel,
                binding.mfgDateValue
            )

            binding.executePendingBindings()
        }
    }

    private fun setViewVisibility(value: String?, vararg views: View) {
        val visibility = if (value.isNullOrEmpty()) View.INVISIBLE else View.VISIBLE
        views.forEach { it.visibility = visibility }
    }

    private fun setDisabledItemStyle(holder: BatchViewHolder) {
        holder.binding.root.setBackgroundColor(Color.parseColor("#B9B9B9")) // Set the desired background color for disabled items
        holder.binding.root.alpha = 0.5f // Reduce the alpha to make the item appear disabled
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BatchViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemBatchDetailBinding.inflate(inflater, parent, false)
        return BatchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BatchViewHolder, position: Int) {
        holder.bind(itemList[position], position)
    }

    override fun getItemCount(): Int = itemList.size
}
