package com.fsc.flare.ui.fragment.inventory.palletizeib

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.container.TempContainerDeleteResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerModel
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.PalletAdjustmentDetailResponse
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitRequest
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.masterpalletrepack.*
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.repository.PalletizeIbRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PalletizeIbViewModel"

@HiltViewModel
class PalletizeIbViewModel @Inject constructor(
    private val palletizeIbRepository: PalletizeIbRepository
) : BaseViewModel() {

    val palletDetailKey = "pallet"

    val containerResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()
    val deleteContainerResponse: MutableLiveData<Resource<TempContainerDeleteResponse>> = SingleLiveEvent()
    val printRequestorResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    val palletDetailResponse: MutableLiveData<Resource<CaseTransferContainerResponse>> = SingleLiveEvent()
    val generatePalletNumberResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val mprTransParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> = SingleLiveEvent()
    val locationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val printContainerLabelResponse: MutableLiveData<Resource<PrintContainerLabelResponse>> = SingleLiveEvent()
    val palletizeIbSubmitResponse: MutableLiveData<Resource<PalletizeIbSubmitResponse>> = SingleLiveEvent()
    val updateTempTableResponse: MutableLiveData<Resource<MasterPalletRepackTempContainerResponse>> = SingleLiveEvent()
    val getTempTablePalletResponse: MutableLiveData<Resource<MasterPalletRepackTempContainerResponse>> = SingleLiveEvent()
    val caseDetailResp = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val palletDetailsResp = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    var printertNameData: String = ""
    var selectedPrinterData: MutableLiveData<PrinterConfig> = MutableLiveData<PrinterConfig>()
    var palletizeIbContainerList: MutableLiveData<List<CaseTransferContainerModel>> = MutableLiveData()
    var mprTransactionParamData: MutableLiveData<MPRepackTransParamResponse> = MutableLiveData<MPRepackTransParamResponse>()
    private val transactionParamHahMap = HashMap<String, Boolean>()
    var transactionIdentifier: MutableLiveData<Int> = MutableLiveData<Int>()
    var tempTablePalletDetail: MutableLiveData<MasterPalletRepackTempContainerResponse.TemplpnEntity> = MutableLiveData<MasterPalletRepackTempContainerResponse.TemplpnEntity>()
    var itemId: MutableLiveData<Long> = MutableLiveData<Long>()
    var palletNumber: MutableLiveData<String?> = MutableLiveData()
    var palletQty: MutableLiveData<Long?> = MutableLiveData()
    var palletNbrOfCase: MutableLiveData<Long?> = MutableLiveData()
    var palletItemCode: MutableLiveData<String?> = MutableLiveData()
    var palletItemDesc: MutableLiveData<String?> = MutableLiveData()
    var palletCurrentLocation: MutableLiveData<String?> = MutableLiveData()
    var tempTablePalletDetailFinal: MutableLiveData<MasterPalletRepackTempContainerResponse.TemplpnEntity> = MutableLiveData<MasterPalletRepackTempContainerResponse.TemplpnEntity>()
    var definedCaseQtyPerPallet : MutableLiveData<Int> = MutableLiveData()
    var isPalletUomDefined: MutableLiveData<Boolean> = MutableLiveData()

   // var scannedInventoryType = ""

    var itmId:String? = null
    var invType:String? = null

    /**
     * method to get printer requestor config list
     */
    fun getPrintRequesterList(printerConfigRequest: PrinterConfigRequest) = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.getPrintRequestorList(printerConfigRequest)
        printRequestorResponse.postValue(handlePrintRequestorListResponse(response))
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handlePrintRequestorListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setSelectedPrinterData(printerConfig: PrinterConfig?) {
        this.selectedPrinterData.value = printerConfig
    }

    fun getSelectedPrinterData(): PrinterConfig? {
        return selectedPrinterData.value
    }

    fun setPrinterNameData(string: String) {
        this.printertNameData = string
    }

    fun getPrinterNameData(): String {
        return printertNameData
    }

    fun generatePalletCaseNumber(type: String) = viewModelScope.launch {
        generatePalletNumberResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.generatePalletCaseNumber(type)
        generatePalletNumberResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setChildContainerList(containerList: List<CaseTransferContainerModel>) {
        palletizeIbContainerList.value = containerList
    }

    fun getChildContainerList(): List<CaseTransferContainerModel>? {
        return palletizeIbContainerList.value
    }

    /**
     * method to get transaction param details
     */
    fun getMPRTransactionParam(mprTransParamRequest: MPRTransParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "MPRtransactionParam Request: $mprTransParamRequest")
        mprTransParamResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.getMPRTransactionParam(mprTransParamRequest)
        mprTransParamResponse.postValue(handleMPRTransactionParamResponse(response))
    }

    /**
     * method to handle MPR transaction param response
     */
    private fun handleMPRTransactionParamResponse(response: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "MPRTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "MPRTransactionParamResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setMPRTransactionParamData(transactionParamResponse: MPRepackTransParamResponse?) {
        transactionParamResponse!!.transParams?.forEach {
            transactionParamHahMap[it.transCode] = it.required
        }
        this.mprTransactionParamData.value = transactionParamResponse
    }

    fun getMPRTransactionParamData(): MPRepackTransParamResponse? {
        return mprTransactionParamData.value
    }

    /**
     * method to get transactionParam to configure
     */
    fun getTransactionParamByTransCode(transCode:String): Boolean {

        return transactionParamHahMap.containsKey(transCode) && transactionParamHahMap[transCode]!!
    }

    fun validateStagingLocation(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getLocationInfo Request: $locBarCode")
        locationResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.validateStagingLocation(locBarCode)
        locationResponse.postValue(handleLocationInquiryResponse(response))
    }

    private fun handleLocationInquiryResponse(response: Response<LocationClassRes>): Resource<LocationClassRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun printContainerLabels(printContainerLabelRequest: PrintContainerLabelRequest) = viewModelScope.launch {
        printContainerLabelResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.printContainerLabelInfo(printContainerLabelRequest)
        printContainerLabelResponse.postValue(handlePrintContainerLabelResponse(response))
    }

    private fun handlePrintContainerLabelResponse(response: Response<PrintContainerLabelResponse>): Resource<PrintContainerLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Print Container Label Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Print Container Label Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun palletizeIBSubmitAPI(palletizeIbSubmitRequest: PalletizeIbSubmitRequest) = viewModelScope.launch {
        palletizeIbSubmitResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.palletizeIBSubmitAPI(palletizeIbSubmitRequest)
        palletizeIbSubmitResponse.postValue(handlePalletizeIBSubmitAPI(response))
    }

    private fun handlePalletizeIBSubmitAPI(response: Response<PalletizeIbSubmitResponse>): Resource<PalletizeIbSubmitResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Print Container Label Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Print Container Label Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun postTempTable(palletRepackPostRequest: PalletRepackPostRequest) = viewModelScope.launch {
        updateTempTableResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.postTempContainer(palletRepackPostRequest)
        updateTempTableResponse.postValue(handleTempTablePostResponse(response))
    }

    private fun handleTempTablePostResponse(response: Response<MasterPalletRepackTempContainerResponse>): Resource<MasterPalletRepackTempContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TempContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TempContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateTempTablePallet(palletNumber: String, containerNumber: String) = viewModelScope.launch {
        getTempTablePalletResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.validateTempTable(palletNumber, containerNumber)
        getTempTablePalletResponse.postValue(handleTempContainerResponse(response))
    }

    private fun handleTempContainerResponse(response: Response<MasterPalletRepackTempContainerResponse>): Resource<MasterPalletRepackTempContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TempContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TempContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setTempTableTransactionIdentifier(transactionIdentifier: Int) {
        this.transactionIdentifier.value = transactionIdentifier
    }

    fun getTempTableTransactionIdentifier(): Int {
        return transactionIdentifier.value!!
    }

    fun setTempTableResponse(tempLpn: MasterPalletRepackTempContainerResponse.TemplpnEntity?) {
        this.tempTablePalletDetail.value = tempLpn
    }

    fun getTempTableResponse(): MasterPalletRepackTempContainerResponse.TemplpnEntity? {
       return tempTablePalletDetail.value
    }

    fun setItemId(itemId: Long?) {
        this.itemId.value = itemId
    }

    fun getItemId(): Long? {
        return itemId.value
    }

    fun setDataToDefault() {
        setPalletNumber(null)
        setPalletQty(null)
        setPalletNbrOfCase(null)
        setPalletItemCode(null)
        setPalletItemDesc(null)
        setPalletCurrentLocation(null)

        setTempTableResponse(null)
        setTempTableResponseFinal(null)
        setTempTableTransactionIdentifier(0)
        setItemId(0)
        setChildContainerList(arrayListOf())
        saveItemInfo(null, null)
    }

    fun getCaseDetails(caseNumber: String) = viewModelScope.launch {
        caseDetailResp.postValue(Resource.Loading())
        val response = palletizeIbRepository.getCaseDetails(caseNumber)
        caseDetailResp.postValue(handlePalletizeGetContainerDetail(response))
    }

    private fun handlePalletizeGetContainerDetail(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "containerPalletInquiryResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "containerPalletInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun deleteTempTableContainer(containerNum: String, transIdentifier: String) = viewModelScope.launch {
        FlareLog.i(TAG, "delete Container Request: $containerNum")
        deleteContainerResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.deleteTempTableContainer(containerNum, transIdentifier)
        deleteContainerResponse.postValue(handleDeleteContainerResponse(response))
    }

    private fun handleDeleteContainerResponse(response: Response<TempContainerDeleteResponse>): Resource<TempContainerDeleteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Delete Container Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Delete Container Response Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getContainerDetails(containerNum: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getContainer Request: $containerNum")
        containerResponse.postValue(Resource.Loading())
        val response = palletizeIbRepository.getContainerDetails(containerNum)
        containerResponse.postValue(handleContainerInquiryResponse(response))
    }

    private fun handleContainerInquiryResponse(response: Response<ContainerInventoryInquiryResponse>): Resource<ContainerInventoryInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getPalletInquiryDetail(palletNumber: String) = viewModelScope.launch {
        palletDetailsResp.postValue(Resource.Loading())
        val response = palletizeIbRepository.getPalletDetail(palletNumber)
        palletDetailsResp.postValue(handlePalletInquiryDetailResponse(response))
    }

    private fun handlePalletInquiryDetailResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "palletDetailInquiryResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "palletDetailInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setPalletNumber(strPalletNumber: String?) {
        palletNumber.value = strPalletNumber
    }

    fun getPalletNumber():String?{
        return palletNumber.value
    }

    fun setPalletQty(strPalletQty: Long?) {
        palletQty.value = strPalletQty
    }

    fun getPalletQty():Long?{
        return palletQty.value
    }

    fun setPalletNbrOfCase(strPalletNbrOfCase: Long?) {
        palletNbrOfCase.value = strPalletNbrOfCase
    }

    fun getPalletNbrOfCase():Long?{
        return palletNbrOfCase.value
    }

    fun setPalletItemCode(strPalletItemCode: String?) {
        palletItemCode.value = strPalletItemCode
    }

    fun getPalletItemCode():String?{
        return palletItemCode.value
    }

    fun setPalletItemDesc(strPalletItemDesc: String?) {
        palletItemDesc.value = strPalletItemDesc
    }

    fun getPalletItemDesc():String?{
        return palletItemDesc.value
    }

    fun setPalletCurrentLocation(currentLocation: String?) {
        palletCurrentLocation.value = currentLocation
    }

    fun getPalletCurrentLocation(): String? {
        return palletCurrentLocation.value
    }

    fun getTempTableResponseFinal(): MasterPalletRepackTempContainerResponse.TemplpnEntity? {
        return tempTablePalletDetailFinal.value
    }

    fun setTempTableResponseFinal(tempLpn: MasterPalletRepackTempContainerResponse.TemplpnEntity?) {
        this.tempTablePalletDetailFinal.value = tempLpn
    }

    fun saveItemInfo(itemId:String? , invType:String? )
    {
        this.itmId =itemId
        this.invType =invType
    }

    fun getItmID(): String? {
        return itmId
    }
    fun getInventoryType(): String? {
        return invType
    }

    fun palletUomDefined(b: Boolean) {
        isPalletUomDefined.value = b
    }

    fun isPalletUomDefined():Boolean{
        return isPalletUomDefined.value!!
    }

    fun getDefinedCaseQtyPerPallet(): Int?{
        return definedCaseQtyPerPallet.value
    }

    fun setDefinedCaseQtyPerPallet(qty :Int){
        this.definedCaseQtyPerPallet.value = qty
    }
}