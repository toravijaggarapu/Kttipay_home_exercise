package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSourceIdentifierBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SourceIdentifierFragment"

/**
 * A simple [InvMoveKitStationFragment] class.
 */
@AndroidEntryPoint
class InvMoveKitStationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: InvMoveKSViewModel by activityViewModels()
    private lateinit var binding: FragmentSourceIdentifierBinding

    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etSourceIdentifier.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSourceIdentifierBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etSourceIdentifier.requestFocus()
        binding.tvSourceIdentifier.text = getString(R.string.kit_station)
        binding.etSourceIdentifier.hint = getString(R.string.kit_station)
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                    if (binding.etSourceIdentifier.isFocused && !binding.etSourceIdentifier.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Source Identifier field focused")
                        getKitStationInfo()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSourceIdentifier.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                FlareLog.i(TAG, "Source Identifier field focused")
                getKitStationInfo()
            }
            false
        }

        binding.etSourceIdentifier.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                binding.tvSourceIdentifierResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun getKitStationInfo() {
        if (binding.etSourceIdentifier.isFocused && !binding.etSourceIdentifier.text.isNullOrEmpty()) {
            viewModel.getKittingStationDetail(binding.etSourceIdentifier.text.toString(), "KT")
        }
    }

    private fun subscribeObservers() {
        observeKittingContainerResponse()
        observeKittingDescriptionResponse()
    }

    private fun observeKittingDescriptionResponse() {
        viewModel.getKittingDescriptionResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { kittingDescriptionResponse ->
                        if (kittingDescriptionResponse.success) {

                            if(!kittingDescriptionResponse.workOrderLines.isNullOrEmpty()) {

                                // Update Kit Item Name and Item Description
                                val kitItem = KitItem()

                                for (item in kittingDescriptionResponse.workOrderLines) {

                                    if(item.finishedGoods?.isNotEmpty() == true && item.finishedGoods == "F"){
                                        kitItem.kitItemName = item.itmCode
                                        kitItem.kitItemDescription = item.itemDescription
                                    }
                                    else {
                                        kitItem.kitComponents.add(item)
                                    }
                                }

                                viewModel.setKitItem(kitItem)
                            }

                            // Handle Navigation
                            handleNavigation()
                        }
                    }
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvSourceIdentifierResponse.text = response.message
                    binding.etSourceIdentifier.requestFocus()
                    binding.etSourceIdentifier.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                }
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }


    private fun observeKittingContainerResponse() {
        viewModel.getKittingContainerResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { kittingContainerResponse ->
                        if (kittingContainerResponse.success) {
                            viewModel.setPalletResponse(kittingContainerResponse.palletInquiry)

//                            if (kittingContainerResponse.palletInquiry.containerNumber == null) {
//                                viewModel.setItem(kittingContainerResponse.palletInquiry.containersList!![0].items!![0])
//                                navController.navigate(R.id.action_invMoveKSKitStationFragment_to_invMoveKSDestinationLocationFragment)
//                            } else {
                            // Call the API here and get the Kit Item Description
//                            viewModel.getKittingItemDescription(viewModel.getPalletResponse().containerId!!)
                            // Handle Navigation
                            handleNavigation()
//                            }

                        }
                    }
                }

                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvSourceIdentifierResponse.text = response.message
                    binding.etSourceIdentifier.requestFocus()
                    binding.etSourceIdentifier.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                }

                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        binding.etSourceIdentifier.setText(scan?.barcode.toString())
        binding.etSourceIdentifier.text?.length?.let {
            binding.etSourceIdentifier.setSelection(it)
            viewModel.getKittingStationDetail(binding.etSourceIdentifier.text.toString(), "KT")
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    fun handleNavigation(){
        if (viewModel.getPalletResponse().containersList?.get(0)?.items!!.size > 1) {
            navController.navigate(R.id.action_invMoveKSKitStationFragment_to_invMoveKSItemScanFragment)
        } else {
            viewModel.getPalletResponse().containersList!![0].items?.get(
                0
            )?.let { viewModel.setItem(it) }
            navController.navigate(R.id.action_invMoveKSKitStationFragment_to_invMoveKSQtyFragment)
        }
    }
}