package com.fsc.flare.ui.fragment.totefrompackstationtopr


import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackstationToPrToteDetailsPageBinding
import com.fsc.flare.utils.Constants.Companion.ROOT_MENU_NAME
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackStationToPRToteDetailsFragment"

@AndroidEntryPoint
class PackStationToPRToteDetailsFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PackstationToPRViewModel by activityViewModels()
    lateinit var binding: FragmentPackstationToPrToteDetailsPageBinding

    private var screenTitle : String? = null

    private val checkedTotes = ArrayList<String>()
    private val checkedShipmentCartonIds = ArrayList<Int>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        handleToteCountView()
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackstationToPrToteDetailsPageBinding.inflate(inflater, container, false)
        requireArguments().getString(ROOT_MENU_NAME)?.let { menuName ->
            screenTitle = menuName
            binding.tvToteFromPackoutToPR.text = screenTitle
        }
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.toteDetails
        if (data != null) {
            binding.tvCartonIdValue.text = data.toteNumber
            binding.tvSKUsValue.text = data.totalSkus
            binding.tvTotalUnitsValue.text = ifNull(data.totalUnits.toString()) + " Units"
            binding.tvTotalPickedUnitsValue.text =
                ifNull(data.totalPickedUnits?.toString()) + " Units"
            binding.tvTotalPackedUnitsValue.text =
                ifNull(data.totalPackedUnits?.toString()) + " Units"
            binding.tvTotalCountValue.text =
                viewModel.getToteNumbersList().size.toString() + " " + getString(R.string.lbl_view)
        }
        //enableTransferCompleteButton()
        binding.btnSave.setOnClickListener {
            if (!viewModel.getToteNumbersList().contains(data!!.toteNumber)) {
                viewModel.saveToteDetails()
                //  binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString()
            }
            // enableTransferCompleteButton()
            handleToteCountView()
            getNavigationController().popBackStack()
        }
        binding.btnTransferComplete.setOnClickListener {
            if (!viewModel.getToteNumbersList().contains(data!!.toteNumber)) {
                viewModel.saveToteDetails()
            }
            val action =
                PackStationToPRToteDetailsFragmentDirections.actionPackStationToPRToteDetailFragmentToPackstationToPRLocationFragment()
            val bundle = bundleOf(
                ROOT_MENU_NAME to screenTitle
            )
            getNavigationController().navigate(action.actionId, bundle)
        }
        binding.tvTotalCountValue.setOnClickListener {
            if (viewModel.getToteNumbersList().size > 0)
                showToteList()
        }
    }

    private fun ifNull(value: String?): String {
        return value ?: "0"
    }

    private fun showToteList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.saved_totes_cartons))
        checkedTotes.clear()
        checkedShipmentCartonIds.clear()
        val totesArray = viewModel.getToteNumbersList().toTypedArray()
        builder.setMultiChoiceItems(totesArray, null) { dialog, which, isChecked ->
            if (isChecked) {
                checkedTotes.add(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            } else {
                checkedTotes.remove(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            viewModel.removeUncheckedTotesAndCartonIds(checkedTotes, checkedShipmentCartonIds)
            handleToteCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }

    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled =
            checkedTotes.size > 0
        if (checkedTotes.size > 0) {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        } else {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    private fun handleToteCountView() {
        if (viewModel.getToteNumbersList().size > 0) {
            binding.tvTotalCountValue.visibility = View.VISIBLE
            binding.tvTotalCount.visibility = View.VISIBLE
            binding.tvTotalCountValue.text =
                viewModel.getToteNumbersList().size.toString() + " " + getString(R.string.lbl_view)
        } else {
            binding.tvTotalCountValue.visibility = View.GONE
            binding.tvTotalCount.visibility = View.GONE
        }
    }

}
