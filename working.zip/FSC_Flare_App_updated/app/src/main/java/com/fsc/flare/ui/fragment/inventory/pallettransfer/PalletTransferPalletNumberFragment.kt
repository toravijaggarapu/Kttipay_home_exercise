package com.fsc.flare.ui.fragment.inventory.pallettransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletTransferPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletTransferPalletNumberFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [PalletTransferPalletNumberFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class PalletTransferPalletNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletTransferViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletTransferPalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletTransferPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvPalletResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etPalletNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                FlareLog.i(TAG, "Pallet Number field focused")
                ContainerInquiryCall()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    ContainerInquiryCall()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    private fun ContainerInquiryCall(){
        if(binding.etPalletNumber.text?.trim().toString().isNotEmpty()){
            viewModel.getContainerDetails(binding.etPalletNumber.text.toString().trim())
        }
    }

    private fun getPalletDetails() {
        if (binding.etPalletNumber.text.toString().trim().isNotEmpty()) {
            binding.tvPalletResponse.text = null
            viewModel.fetchPalletDetail(binding.etPalletNumber.text.toString().trim(), viewModel.palletDetailKey)
        }
    }

    private fun subscribeObservers() {

        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { containerResponse ->
                        if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)){
                            if(containerResponse.containers?.get(0)?.lockCode == "CC"){
                                binding.tvPalletResponse.text = getString(R.string.cycle_count_in_progress_for_given_location)
                            }else{
                                getPalletDetails()
                            }
                        }else{
                            if(containerResponse.containers?.get(0)?.cycleCountPending == "Y"){
                                binding.tvPalletResponse.text = getString(R.string.cycle_count_is_pending_for_given_location)
                            }else{
                                getPalletDetails()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        binding.tvPalletResponse.text = message
                        FlareLog.e(TAG, "container error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                FlareLog.e(TAG, "container error: ${msgArray[1]}")
                                binding.tvPalletResponse.text = msgArray[1]
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.palletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletDetailResponse ->
                        if (palletDetailResponse.success) {
                            if (palletDetailResponse.palletInquiry.noOfCase > 0) {
                                viewModel.setPalletDetails(palletDetailResponse)
                                FlareLog.i(TAG, "palletDetailResponse success: $palletDetailResponse")
                                val action = PalletTransferPalletNumberFragmentDirections.actionPalletTransferPalletNumberFragmentPalletTransferPalletDetailSplitBtnFragment()
                                getNavigationController().navigate(action)
                            } else {
                                displayErrorMessage(resources.getString(R.string.pallet_transfer_no_pallet_qty_to_transfer))
                            }
                        } else {
                            displayErrorMessage(resources.getString(R.string.invalid_pallet_number))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "locationResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    fun displayErrorMessage(errorMessage: String) {
        binding.tvPalletResponse.text = errorMessage
        binding.etPalletNumber.requestFocus()
        binding.etPalletNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etPalletNumber.setText(scan?.barcode.toString())
                binding.etPalletNumber.text?.length?.let {
                    binding.etPalletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Pallet Number field focused")
                    ContainerInquiryCall()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}