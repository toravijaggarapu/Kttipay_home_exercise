package com.fsc.flare.ui.fragment.inventory.palletizeib

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerModel
import com.google.android.material.textview.MaterialTextView
import java.util.ArrayList

class PalletizeIbContainerAdapter(
    private var containerList: ArrayList<CaseTransferContainerModel>,
    private var removeContainerInterface: RemoveContainerInterface)
    : RecyclerView.Adapter<PalletizeIbContainerAdapter.ViewHolder>() {

    lateinit var context: Context

    fun update(item: CaseTransferContainerModel) {
        containerList.add(item)
        notifyItemInserted(containerList.size)
    }

    fun clearList(){
        containerList.clear()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvContainerNumber: MaterialTextView = itemView.findViewById(R.id.tvContainerNumber)
        var tvQty: MaterialTextView = itemView.findViewById(R.id.tvQty)
        var removeCardView: CardView = itemView.findViewById(R.id.removeCardView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_casetransfer_container, parent, false)
        context = parent.context
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvContainerNumber.text = containerList[position].containerNumber
        holder.tvQty.text = context.resources.getQuantityString(
            R.plurals.case_transfer_scanned_case_units,
            containerList[position].qty.toInt(),
            containerList[position].qty)

        holder.removeCardView.setOnClickListener {
            //Click listener.
            removeContainerInterface.removeClick(position)
        }
    }

    override fun getItemCount(): Int {
        return containerList.size
    }

    interface RemoveContainerInterface{
    fun removeClick(position:Int)
    }
}