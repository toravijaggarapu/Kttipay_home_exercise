package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryCartonAdjustmentBinding
import com.fsc.flare.source.data.dto.inventory.CartonAdjustmentRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryCartonAdj"

/**
 * A simple [InventoryCartonAdjustmentFragment] class.
 */
@AndroidEntryPoint
class InventoryCartonAdjustmentFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryCartonAdjustmentBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryCartonAdjustmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryIcCtrAdj.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.packQtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { packQtyResponse ->
                        Log.d(TAG, "packQtyResponse: $packQtyResponse")
                        if (packQtyResponse.success) {
                            showSuccessSnackBarStd(packQtyResponse.message) {
                                val action =
                                    InventoryCartonAdjustmentFragmentDirections.actionInventoryCartonAdjustmentFragmentToInventoryAdjustmentContainerFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inventoryAdjustmentContainerFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }

            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                val containerData = containerList[0]
                binding.txtContainerNumberValue.text = containerData.containerNumber
                val cartonData = viewModel.getCartonInfo()
                if (cartonData != null) {
                    binding.txtItemCodeValue.text = cartonData.itemCode
                    binding.txtItemDesValue.text = cartonData.itemDesc
                    binding.txtQtyValue.text = cartonData.qty.toString()
                    binding.txtUomValue.text = cartonData.qtyUom
                    binding.tvtxtUom.text = cartonData.qtyUom
                    binding.txtAllocatedQtyValue.text = cartonData.allocatedQty
                }
            }
        }

        binding.etQty.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                sharedPreferences.edit().putString(PreferenceKeys.Item.QUANTITY_INPUT, binding.etQty.text.toString()).apply()

                val previousQty: Int = Integer.parseInt(binding.txtAllocatedQtyValue.text.toString())
                val updatedQty: Int = Integer.parseInt(binding.etQty.text.toString())
                when {
                    updatedQty > previousQty -> {
                        showErrorSnackBar(resources.getString(R.string.lbl_cannot_over_pack))
                        binding.etQty.requestFocus()
                    }
                    updatedQty == 0 -> {
                        showErrorSnackBar(resources.getString(R.string.lbl_cannot_adjust_to_zero))
                        binding.etQty.requestFocus()
                    }
                    else -> {
                        val data = viewModel.getCartonInfo()
                        viewModel.packqtyconfirm(
                            CartonAdjustmentRequest(
                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                cartonDetailId = data!!.shipmentCartonDetId,
                                packedQty = binding.etQty.text.toString(),
                                packedQtyUom = "EA"
                            )
                        )
                    }
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etQty.isFocused && !binding.etQty.text.isNullOrEmpty()) {
                        sharedPreferences.edit().putString(PreferenceKeys.Item.QUANTITY_INPUT, binding.etQty.text.toString()).apply()

                        val previousQty: Int = Integer.parseInt(binding.txtAllocatedQtyValue.text.toString())
                        val updatedQty: Int = Integer.parseInt(binding.etQty.text.toString())
                        when {
                            updatedQty > previousQty -> {
                                showErrorSnackBar(resources.getString(R.string.lbl_cannot_over_pack))
                                binding.etQty.requestFocus()
                            }
                            updatedQty == 0 -> {
                                showErrorSnackBar(resources.getString(R.string.lbl_cannot_adjust_to_zero))
                                binding.etQty.requestFocus()
                            }
                            else -> {
                                val data = viewModel.getCartonInfo()
                                viewModel.packqtyconfirm(
                                    CartonAdjustmentRequest(
                                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                        cartonDetailId = data!!.shipmentCartonDetId,
                                        packedQty = binding.etQty.text.toString(),
                                            packedQtyUom = "EA"
                                    )
                                )
                            }
                        }
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        if (binding.etQty.isFocusableInTouchMode) {
            showSoftKeyBoard(fragmentContext, binding.etQty)
        }

    }
}