package com.fsc.flare.ui.fragment.loadunloadtrailer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemPalletLoadBinding
import com.fsc.flare.source.data.dto.loadunloadtrailer.Pallet

class PalletAdapter(private val pallets: List<Pallet>) : RecyclerView.Adapter<PalletAdapter.PalletViewHolder>() {

    inner class PalletViewHolder(private val binding: ItemPalletLoadBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(pallet: Pallet) {
            binding.pallet = pallet
            binding.executePendingBindings()
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PalletViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemPalletLoadBinding.inflate(inflater, parent, false)
        return PalletViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PalletViewHolder, position: Int) {
        holder.bind(pallets[position])
    }

    override fun getItemCount() = pallets.size
}