package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.putawayreverse.ContainerRequest
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayRequest
import com.fsc.flare.source.data.dto.putawayreverse.LocationIDRequest
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PutAwayRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun validateContainer(containerRequest: ContainerRequest) =
        apiGatewayInterface.validateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerRequest
        )

    suspend fun validateLocationID(locationIDRequest: LocationIDRequest) =
        apiGatewayInterface.validateLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            locationIDRequest
        )

    suspend fun doPutaway(putawayRequest: DoPutawayRequest) =
        apiGatewayInterface.doPutAway(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            putawayRequest
        )

    suspend fun doIMEIPutaway(putawayRequest: DoPutawayRequest) =
        apiGatewayInterface.doIMEIPutAway(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            putawayRequest
        )

    suspend fun validateUpc(validateUpcRequest: ValidateUpcRequest) =
        apiGatewayInterface.validateUPC(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            validateUpcRequest = validateUpcRequest
        )

}