package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.palletize.PalletizeRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class PalletizeRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    val PACK_BY_ITEM = "PACK_BY_ITEM"

    suspend fun getPallet(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun palletize(palletizeRequest: PalletizeRequest) =
        apiGatewayInterface.palletize(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            palletizeRequest = palletizeRequest
        )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = locationClassReq.customerId,
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun palletizeContainer(palletizeContainerRequest: PalletizeContainerRequest) = apiGatewayInterface.palletizeContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        palletizeContainerRequest = palletizeContainerRequest
    )


    suspend fun getPalletizeContainer(containerNumber: String, itemInfo: String) =
        apiGatewayInterface.getPalletizeContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = containerNumber,
            itemInfo = itemInfo
        )

    suspend fun getPalletizeContainerPallet(request: PalletizeContainerPalletRequest) =
        apiGatewayInterface.getPalletizeContainerPallet(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = request.fcyId,
            custId = request.custId,
            buId = request.buId,
            palletNumber=request.palletNumber,
            ibPalletize= request.ibPalletize
        )

    suspend fun getPalletDetail(palletNumber: String) =
        apiGatewayInterface.getContainerDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = palletNumber,
            itemInfo = YES,
            fetchChild = true
        )

    suspend fun getContainerDetails(containerNum: String, itemUOMRequired: Boolean) = apiGatewayInterface.getContainerInquiryWithItemUom(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum,
        itemUOMRequired = itemUOMRequired
    )

    suspend fun getPalletDetails(containerNum: String, itemUOMRequired: Boolean) = apiGatewayInterface.getContainerInquiryWithItemUom(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum,
        itemUOMRequired = itemUOMRequired
    )

    suspend fun sendToPR(request: SendToPRRequest) =
        apiGatewayInterface.sendToPR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            request
        )

    suspend fun getCartonDetailsFromTote(toteNumber: String, obContainerNumber: String) =
        apiGatewayInterface.getCartonDetailsFromTote(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            toteNumber = toteNumber,
            obContainerNumber = obContainerNumber,
            packMethod = "PACK_BY_ITEM"
        )
}