package com.fsc.flare.ui.fragment.physicalInventory

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentNoOfContainersBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.physicalInventory.model.ContainerModel
import com.fsc.flare.utils.Constants.ContainerType.CASE
import com.fsc.flare.utils.Constants.ContainerType.PALLET
import com.fsc.flare.utils.Constants.LocationClasses.CASE_PICK
import com.fsc.flare.utils.Constants.LocationClasses.RESERVE
import com.fsc.flare.utils.Constants.PhysicalInventoryCountTypes.PRIMARY_COUNT
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "NoOfContainersFragment"
private const val ERR_COUNT_PENDING = "ERR_COUNT_PENDING"

@AndroidEntryPoint
class NoOfContainersFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentNoOfContainersBinding
    private lateinit var taskData: BatchTaskDetailsResp
    private var countType: String? = null
    private var previousScannedContainer: String? = null
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentNoOfContainersBinding.inflate(inflater, container, false)
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text =
            viewModel.batchSummaryResp?.countType.plus(" - ").plus(taskData.batchNumber)
        countType = sharedPreferencesBase.getString(
            PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
        )
        subscribeContainerInfoObserver()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleContainerCountView()
        handleTouchEvent()
        handleEnterKeyEvent()
        handleViewButtonClick()
        handleEndCountButtonClick()
        subscribeBatchTaskDetailsObserver()
        subscribeBatchSummaryObserver()
        binding.containerNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerErrResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun handleViewButtonClick() {
        binding.tvView.setOnClickListener() {
            showScannedContainers()
        }
    }

    private fun showScannedContainers() {
        showScannedMultiItemsListDialog(
            viewModel.containersList.map { it.containerNumber ?: "" } ,
            title= if (taskData.locationClass == "R") getString(R.string.pallets_scanned_colon) else getString(
                R.string.containers_scanned
            ),
            finalList = { finalList ->
                viewModel.containersList.removeAll(viewModel.containersList.filter { it.containerNumber !in finalList }.toSet())
                handleContainerCountView()
            },
            onDismissDialog ={
                handleContainerCountView()
            }
        )
    }

    private fun updateDataOnScreen() {
        binding.countType.text = sharedPreferencesBase.getString(
            PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
        )
        binding.location.text = taskData.locationBarCode
        if (taskData.locationClass == "R") {
            binding.noOfContainersTv.text = getString(R.string.lbl_no_of_pallets)
            binding.noOfContainers.hint = getString(R.string.lbl_no_of_pallets)
            binding.containersCountTv.text = getString(R.string.pallets_scanned_colon)
            binding.containerNumberTv.text = getString(R.string.pallet_number)
            binding.containerNumber.hint = getString(R.string.pallet_number)
        }
        setupScreenBasedOnConfiguration()
    }

    private fun setupScreenBasedOnConfiguration() {
        //in Recount and Audit count, only for CasePick and Reserve location have to ask count, otherwise directly show container scan.
        if (taskData.countType != "Primary Count") {
            if (taskData.locationClass !in listOf("R", "C")) {
                showContainersScanOption()
            }
            return
        }

        when (taskData.locationClass){
            "C" -> if (viewModel.casePickCountConfigType.equals("Container Id", true)) showContainersScanOption()
            "R" -> if (viewModel.reserveCountConfigType.equals("Pallet Id", true)) showContainersScanOption()
            else -> showContainersScanOption()
        }
    }

    private fun handleContainerCountView() {
        binding.containersCountLnr.visibility =
            if (viewModel.containersList.size > 0) View.VISIBLE else View.GONE
        binding.ContainersCount.text = viewModel.containersList.size.toString()
    }

    private fun handleEnterKeyEvent() {
        binding.noOfContainers.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateCount()
            }
            false
        }
        binding.containerNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateContainer()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.noOfContainers.isFocused && !binding.noOfContainers.text.isNullOrEmpty()) {
                            validateCount()
                        } else if (binding.containerNumber.isFocused && !binding.containerNumber.text.isNullOrEmpty()) {
                            validateContainer()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateCount() {
        if(binding.noOfContainers.text.toString() == "0"){
            hideSoftKeyBoard(fragmentContext,binding.rootLayout)
        }else{
            if(taskData.noOfContainers != binding.noOfContainers.text.toString().toInt() && !viewModel.isGivingCountSecondTime){
                showQuantityMismatchConfirmDialog()
            }else{
                displayContainerScan()
            }
        }
    }

    private fun displayContainerScan() {
        if (!countType.equals("Primary Count", true)) {
            showContainersScanOption()
        } else {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            disableCountScanFiled()
        }
    }

    private fun showContainersScanOption() {
        binding.noOfContainersLnr.visibility = View.GONE
        binding.containersLnr.visibility = View.VISIBLE
    }

    private fun validateContainer() {
        if (viewModel.containersList.map{it.containerNumber}.contains(binding.containerNumber.text.toString())) {
            binding.containerErrResponse.visibility = View.VISIBLE
            binding.containerErrResponse.text = getString(R.string.case_transfer_container_already_scanned)
        }else if((taskData.locationClass == RESERVE || taskData.locationClass == CASE_PICK) &&
            taskData.countType != "Primary Count" &&
            binding.noOfContainers.getLongValue() <= viewModel.containersList.size.toLong()){
            showErrorSnackBar(getString(R.string.Scanned_more_containers_than_the_given_count_please_recheck))
        }else{
            if (previousScannedContainer != null && binding.containerNumber.text.toString() == previousScannedContainer) {
                viewModel.isFirstTimeContainerScanned = false
            }
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            viewModel.getContainerInfo(binding.containerNumber.text.toString(), "Y")
        }
    }

    private fun showQuantityMismatchConfirmDialog() {
        val msg = getString(R.string.counted_qty_not_match_with_system_qty)
        showAlertDialog("", msg) {
            viewModel.isGivingCountSecondTime = true
            binding.noOfContainers.text = null
        }
    }

    private fun showLocationMismatchAlertDialog() {
        var msg = getString(R.string.location_does_not_match_for_this_container_please_reenter)
        if (taskData.locationClass == "R") {
            msg = getString(R.string.location_does_not_match_for_this_pallet_please_reenter)
        }
        showAlertDialog("", msg) {
            binding.containerNumber.text = null
            viewModel.isFirstTimeContainerScanned = true
        }
    }

    private fun subscribeContainerInfoObserver() {
        viewModel.containerInfoResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerInfoResponse ->
                        FlareLog.i(TAG, "containerInfoResponse success: $containerInfoResponse")
                        if (!containerInfoResponse.container.isNullOrEmpty()) {
                            previousScannedContainer =  containerInfoResponse.container[0].containerNumber

                            if(taskData.locationClass == RESERVE && containerInfoResponse.container[0].containerType != PALLET){
                                binding.containerErrResponse.text = getString(R.string.only_pallet_scan_allowed)
                            }else if(taskData.locationClass == CASE_PICK && containerInfoResponse.container[0].containerType != CASE){
                                binding.containerErrResponse.text = getString(R.string.pallet_scan_not_allowed)
                            }else if (viewModel.isFirstTimeContainerScanned && containerInfoResponse.container[0].currentLocationId.toString() != taskData.locationId) {
                                showLocationMismatchAlertDialog()
                            } else {
                                val container = ContainerModel(
                                    containerNumber = containerInfoResponse.container[0].containerNumber,
                                    containerId = containerInfoResponse.container[0].containerId.toString()
                                )
                                viewModel.containersList.add(container)
                                binding.containerNumber.text = null
                                viewModel.isFirstTimeContainerScanned = true
                                handleContainerCountView()
                            }
                        } else {
                            binding.containerErrResponse.text = getString(R.string.invalid_container)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "containerInfoResponse Error: $message")
                        binding.containerErrResponse.text = message
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchTaskDetailsObserver() {
        viewModel.batchTaskDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchTaskDetailsResp ->
                        FlareLog.i(TAG, "batchTaskDetails success: $batchTaskDetailsResp")
                        viewModel.batchTaskDetailsResp = batchTaskDetailsResp
                        navigateToNextScreen()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchTaskDetails Error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == ERR_COUNT_PENDING) {
                                    showConfirmationAlert(msgArray[1])
                                }else{
                                    showErrorSnackBar(msgArray[1])
                                }
                            }
                        }else{
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showConfirmationAlert(msg: String) {
        showAlertDialog(
            "",
            msg,
            getString(R.string.yes),
            getString(R.string.no),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    val updateBatchTaskReq = viewModel.prepareUpdateTaskRequest(
                        binding.noOfContainers.getLongValue(),
                        viewModel.containersList.map { it.containerId ?: "" },
                        validateCount = false
                    )
                    viewModel.updateBatchTask(updateBatchTaskReq)
                }
                override fun onNegativeButtonClick() {

                }
            }
        )
    }


    private fun subscribeBatchSummaryObserver() {
        viewModel.batchSummaryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchSummaryResp ->
                        if (!batchSummaryResp.batchNumber.isNullOrEmpty()) {
                            FlareLog.i(TAG, "batchSummary success: $batchSummaryResp")
                            viewModel.batchSummaryResp = batchSummaryResp
                            val action =
                                NoOfContainersFragmentDirections.actionNoOfContainersFragmentToBatchAcceptOrSkipFragment()
                            val navOptions = NavOptions.Builder()
                                .setPopUpTo(R.id.batchAcceptOrSkipFragment, true).build()
                            getNavigationController().navigate(action, navOptions)
                        } else {
                            showSuccessSnackBarStd(getString(R.string.no_tasks_exist)) {
                                val action =
                                    NoOfContainersFragmentDirections.actionNoOfContainersFragmentToPhysicalInventoryCountTypesFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.physicalInventoryCountTypesFragment, true)
                                    .build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchSummary Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToNextScreen() {
        taskData = viewModel.batchTaskDetailsResp!!
        if (taskData.isLastTask == "true") {
            showSuccessSnackBarStd(getString(R.string.batch_count_completed)) {
                viewModel.getBatchSummary(null,
                    "", sharedPreferencesBase.getString(
                        PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
                    )
                )
            }
        } else {
            val action =
                NoOfContainersFragmentDirections.actionNoOfContainersFragmentToScanLocationFragment()
            val navOptions =
                NavOptions.Builder().setPopUpTo(R.id.scanLocationFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }
    }

    private fun handleEndCountButtonClick() {
        binding.endCountBtn.setOnClickListener {
            if (taskData.countType != PRIMARY_COUNT && binding.noOfContainers.getLongValue().toInt() != viewModel.containersList.size) {
                showErrorSnackBar(getString(R.string.all_containers_are_not_scanned))
            } else {
                val updateBatchTaskReq = viewModel.prepareUpdateTaskRequest(
                    binding.noOfContainers.getLongValue(),
                    viewModel.containersList.map { it.containerId ?: "" },
                    validateCount = true
                )
                viewModel.updateBatchTask(updateBatchTaskReq)
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun disableCountScanFiled() {
        binding.noOfContainers.isEnabled = false
        binding.noOfContainers.isFocusable = false
        binding.noOfContainers.isFocusableInTouchMode = false
        binding.noOfContainers.alpha = 0.35f
    }

    private fun EditText.getLongValue(): Long {
        val textValue = this.text.toString()
        return if (textValue.isBlank()) 0 else textValue.toLong()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.containerNumber.setText(scan?.barcode.toString().trim())
        binding.containerNumber.text?.length?.let {
            binding.containerNumber.setSelection(it)
        }
        FlareLog.i(TAG, "noOfContainers field focused")
        validateContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}