package com.fsc.flare.ui.fragment.prtotetopackstation


import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPrtpsToteDetailBinding
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PRTPSToteDetailFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PRTPSViewModel by activityViewModels()
    lateinit var binding: FragmentPrtpsToteDetailBinding
    private val checkedTotes = ArrayList<String>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        handleToteCountView()
        super.onResume()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPrtpsToteDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (viewModel.isKitStaging) binding.tvCartToPrTransfer.text = getString(R.string.pr_tote_to_kit_staging)
        val data = viewModel.toteDetails
        if (data != null) {
            binding.tvCartonIdValue.text = data.toteNumber
            binding.tvSKUsValue.text = data.totalSKUs
            binding.tvTotalUnitsValue.text = ifNull(data.totalUnits) + " Units"
            binding.tvTotalPickedUnitsValue.text = ifNull(data.totalPickedUnits) + " Units"
            binding.tvTotalPackedUnitsValue.text = ifNull(data.totalPackedUnits) + " Units"
            binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString() +  " "+ getString(R.string.lbl_view)
            if (viewModel.isKitStaging) {
                binding.tvWorkOrderNum.visibility = View.VISIBLE
                binding.tvWorkOrderNumberValue.visibility = View.VISIBLE
                binding.tvWorkOrderNumberValue.text = data.workOrderNbr
            }
        }
        //enableTransferCompleteButton()
        binding.btnSave.setOnClickListener {
            if (!viewModel.getToteNumbersList().contains(data!!.toteNumber)) {
                viewModel.saveToteNumber()
              //  binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString()
            }
            handleToteCountView()
            getNavigationController().popBackStack()
        }
        binding.btnTransferComplete.setOnClickListener {
            if (!viewModel.getToteNumbersList().contains(data!!.toteNumber)) {
                viewModel.saveToteNumber()
                //  binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString()
            }
            val action = PRTPSToteDetailFragmentDirections.actionPrToteToPackStationDetailFragmentToPrToteToPackStationStageFragment()
            getNavigationController().navigate(action)
        }
        binding.tvTotalCountValue.setOnClickListener{
            if(viewModel.getToteNumbersList().size>0)
                showToteList()
        }
    }

    private fun ifNull(value: String?): String {
        return value ?: "0"
    }
   /* private fun enableTransferCompleteButton() {
        binding.btnTransferComplete.isEnabled = viewModel.getToteNumbersList().size>0
    }*/
    private fun handleToteCountView() {
        if(viewModel.getToteNumbersList().size>0)
        {
            binding.tvTotalCountValue.visibility = View.VISIBLE
            binding.tvTotalCount.visibility =View.VISIBLE
            binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString()  + " "+ getString(R.string.lbl_view)
           // binding.btnTransferComplete.isEnabled = true
        }else
        {
            binding.tvTotalCountValue.visibility = View.GONE
            binding.tvTotalCount.visibility =View.GONE
           // binding.btnTransferComplete.isEnabled = false
        }
    }

    private fun showToteList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.saved_totes_cartons))
        checkedTotes.clear()
        val totesArray = viewModel.getToteNumbersList().toTypedArray()
        builder.setMultiChoiceItems(totesArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedTotes.add(viewModel.getToteNumbersList()[which])
            }
            else
            {
                checkedTotes.remove(viewModel.getToteNumbersList()[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
            //    Log.d("debug", "Position:" + which)
            //   Log.d("debug", "isChecked Item:$"+viewModel.getToteNumbersList()[which])

        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            viewModel.removeUncheckedTotes(checkedTotes)
            handleToteCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }
    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedTotes.size>0
        if(checkedTotes.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }


}
