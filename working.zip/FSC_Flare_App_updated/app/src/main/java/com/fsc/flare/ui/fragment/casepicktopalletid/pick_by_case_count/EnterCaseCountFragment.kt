package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.EnterCaseCountFragmentBinding
import com.fsc.flare.databinding.ItemContainerSelectBinding
import com.fsc.flare.databinding.SelectedLabelsPrintDialogBinding
import com.fsc.flare.source.data.dto.taskgroup.GroupTask
import com.fsc.flare.source.data.dto.taskgroup.VirtualContainer
import com.fsc.flare.source.data.dto.taskgroup.getTaskPickModel
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.casepicktopalletid.CasePickToPalletIDViewModel
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.END_PALLET_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_PRINT_REQUESTERS
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_TASKS_FOUND
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.PICK_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.PRINT_REQUESTER_API_ERROR
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.SKIP_API_ERROR
import com.fsc.flare.utils.observeFlowOnUI
import com.fsc.flare.utils.setNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

const val NEXT_TASK_DATA_ARGUMENT = "NextTaskDataUpdate"

@AndroidEntryPoint
class EnterCaseCountFragment: BaseFragment() {

    @Inject
    lateinit var alertHandler: AlertHandler

    private val existingViewModel: CasePickToPalletIDViewModel by activityViewModels()
    private val sharedViewModel: PickCaseByCountSharedViewModel by activityViewModels()
    private val viewModel: EnterCaseCountViewModel by viewModels()

    private lateinit var binding: EnterCaseCountFragmentBinding
    private val preferredContainers = mutableListOf<VirtualContainer>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = EnterCaseCountFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        sharedViewModel.groupTask?.let { groupTask ->
            sharedViewModel.palletInfo?.let { palletInfo ->
                viewModel.initData(groupTask, palletInfo)
            }
        }
        initViews()
        enterCaseCountScreenState()
        observeFlowOnUI { commonScreenState() }
    }

    private suspend fun commonScreenState() {
        viewModel.screenState.filterNotNull().collect { state ->
            when(state) {
                is CaseCountFlowState.ShowProgress -> {
                    binding.progressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is CaseCountFlowState.GroupTaskData -> {
                    moveBackForNextTask(state.groupTask)
                }

                is CaseCountFlowState.ShowError -> { handleError(state) }

                is CaseCountFlowState.StagePending -> {
                    movedToStagePending(
                        cartNumber = state.cartNumber,
                        stageLocation = state.stageLocation
                    )
                }

                CaseCountFlowState.EndWithEmptyPallet -> {
                    val action = EnterCaseCountFragmentDirections.actionEnterCaseCountToPalletId()
                    findNavController().navigate(action)
                }
            }
        }
    }

    private fun handleError(error: CaseCountFlowState.ShowError) {
        when (error.errorCode) {

            PRINT_REQUESTER_API_ERROR -> {
                showErrorSnackBar(message = error.errorMessage ?: getString(R.string.lbl_something_went_wrong))
            }

            NO_PRINT_REQUESTERS -> {
                showErrorSnackBar(message = getString(R.string.no_print_requester_found))
            }

            NO_TASKS_FOUND -> {
                findNavController().popBackStack(R.id.casePickMethodScreen, inclusive = false)
            }

            SKIP_API_ERROR,
            PICK_API_ERROR,
            END_PALLET_API_ERROR -> {
                binding.tvErrorMessage.text = error.errorMessage ?: getString(R.string.lbl_something_went_wrong)
            }
        }
    }

    private fun enterCaseCountScreenState() {
        viewModel.enterCaseCountState.observe(viewLifecycleOwner) { state ->
            when(state) {
                is EnterCaseCountScreenState.PrintRequesters -> {
                    alertHandler.showPrintRequesterDialog(requesters = state.printRequesters) { requester ->
                        viewModel.printLabels(
                            containers = preferredContainers.toList(),
                            printRequester = requester
                        )
                    }
                }

                EnterCaseCountScreenState.PrintSuccess -> {
                    showSuccessSnackBar(getString(R.string.case_lbls_printed_successfully))
                }

                is EnterCaseCountScreenState.GroupTaskData -> {
                    showSuccessSnackBarStd(getString(R.string.task_picked_successfully)) {
                        moveBackForNextTask(state.groupTask)
                    }
                }

                is EnterCaseCountScreenState.StagePending -> {
                    showSuccessSnackBarStd(getString(R.string.task_picked_successfully)) {
                        movedToStagePending(
                            cartNumber = state.cartNumber,
                            stageLocation = state.stageLocation
                        )
                    }
                }

                EnterCaseCountScreenState.PickSuccessWithNoTask -> {
                    showSuccessSnackBarStd(getString(R.string.task_picked_successfully)) {
                        findNavController().popBackStack(R.id.casePickMethodScreen, inclusive = false)
                    }
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initViews() {
        requestInputFocus()

        sharedViewModel.groupTask?.let { updateTaskDataOnUI(it) }
        binding.tvView.setOnClickListener {
            showPrintCasesDialog()
        }

        binding.etNoOfCases.doAfterTextChanged {
            if (it.toString().isEmpty() ||
                (it.toString().toInt() > 0 && it.toString().toInt() <= viewModel.getNoOfCasesToBePicked())
            ) {
                binding.tvErrorMessage.text = null
                binding.btnPick.visibility = if (it.toString().isEmpty()) View.GONE else View.VISIBLE
            } else {
                val message = if (it.toString().toInt() == 0)
                    getString(R.string.input_should_be_more_than_0)
                else
                    getString(R.string.input_should_not_more_than_the_cases, viewModel.getNoOfCasesToBePicked())

                binding.tvErrorMessage.text = message
                binding.btnPick.visibility = View.GONE
            }
        }

        binding.btnSkip.setOnClickListener {
            viewModel.skipTask()
        }

        binding.btnEndPallet.setOnClickListener {
            viewModel.endPallet()
        }

        binding.btnPick.setOnClickListener {
            val inputCases = binding.etNoOfCases.text.toString().trim().toInt()
            if (inputCases == viewModel.getNoOfCasesToBePicked())
                viewModel.pickCases(
                    quantity = inputCases,
                    preferredContainers = preferredContainers
                )
            else
                alertHandler.showFlareConfirmationAlert(
                    message = getString(R.string.use_the_pick_by_case_method_to_complete_picks),
                    positiveButtonTitle = getString(R.string.alert_button_yes),
                    positiveCallBack = {
                        viewModel.pickCases(
                            quantity = inputCases,
                            preferredContainers = preferredContainers
                        )
                    }
                )
        }
    }

    private fun moveBackForNextTask(taskData: GroupTask) {
        setNavigationResult(NEXT_TASK_DATA_ARGUMENT, taskData)
        findNavController().popBackStack()
    }

    private fun movedToStagePending(cartNumber: String, stageLocation: String) {
        //==========UPDATE EXISTING FLOW VIEW MODEL DATA============
        existingViewModel.stageLocationBarcode = stageLocation
        existingViewModel.setPalletNumber(cartNumber)
        sharedViewModel.groupTask?.let {
            existingViewModel.setPickTask(
                getTaskPickModel(
                    palletInfo = sharedViewModel.palletInfo,
                    stageLocation
                )
            )
        }
        //==========UPDATE EXISTING FLOW VIEW MODEL DATA============

        alertHandler.showSimpleAlert(
            message = getString(R.string.stage_pending_pallet_message, cartNumber),
            buttonTitle = getString(R.string.stage)
        ) {
            val action = EnterCaseCountFragmentDirections.actionEnterCaseCountToPalletStage()
            findNavController().navigate(action)
        }
    }

    private fun updateTaskDataOnUI(task: GroupTask) {
        binding.tvShipment.text = task.shipmentNbr
        binding.tvStop.text = "${task.shipmentStopSeq}"
        binding.tvPalletId.text = task.cartNbr
        binding.tvItem.text = task.itemBarcode
        binding.tvDescription.text = task.itemDesc
        binding.tvPickLocation.text = task.pickLocBarcode
        binding.tvCaseToBePicked.text = "${task.numOfContainersToBePicked}"
    }

    private fun requestInputFocus() {
        binding.etNoOfCases.post {
            binding.etNoOfCases.requestFocus()
            showSoftKeyBoard(requireActivity(), binding.etNoOfCases)
        }
    }

    private fun showPrintCasesDialog() {
        val printLabelsBinding = SelectedLabelsPrintDialogBinding.inflate(layoutInflater)
        val adapter = CaseLabelsAdapter(mContext = fragmentContext)

        printLabelsBinding.rvContainerLabels.layoutManager = LinearLayoutManager(fragmentContext)

        val dialog = alertHandler.showCustomDialog(printLabelsBinding) {
            printLabelsBinding.rvContainerLabels.adapter = adapter
            adapter.resetList(viewModel.getContainersToBePick())
        }

        printLabelsBinding.btnPrint.setOnClickListener {
            dialog.dismiss()
            preferredContainers.clear()
            preferredContainers.addAll(adapter.getSelectedContainers())
            viewModel.getPrintRequesters()
        }

        printLabelsBinding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        existingViewModel.clearData()
    }
}

private class CaseLabelsAdapter(private val mContext: Context) : RecyclerView.Adapter<CaseLabelsAdapter.CaseLabelsViewHolder>() {

    private val containersList = mutableListOf<VirtualContainer>()

    fun resetList(containersList: List<VirtualContainer>) {
        this.containersList.clear()
        this.containersList.addAll(containersList)
    }

    fun getSelectedContainers(): List<VirtualContainer> {
        return containersList.filter { it.isSelected }
    }

    inner class CaseLabelsViewHolder(private val binding: ItemContainerSelectBinding) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.tvContainerNumber.setOnClickListener {
                containersList[adapterPosition].isSelected = !containersList[adapterPosition].isSelected
            }
        }

        @SuppressLint("SetTextI18n")
        fun bind(container: VirtualContainer) {
            binding.tvContainerNumber.text = container.containerNumber
            binding.tvContainerNumber.isChecked = container.isSelected
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        CaseLabelsViewHolder(ItemContainerSelectBinding.inflate(LayoutInflater.from(mContext), parent, false))

    override fun getItemCount() = containersList.size

    override fun onBindViewHolder(holder: CaseLabelsViewHolder, position: Int) {
        holder.bind(containersList[position])
    }
}