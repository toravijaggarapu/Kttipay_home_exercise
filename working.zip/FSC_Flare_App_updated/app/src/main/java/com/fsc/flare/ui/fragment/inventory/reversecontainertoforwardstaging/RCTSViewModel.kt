package com.fsc.flare.ui.fragment.inventory.reversecontainertoforwardstaging

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerLocationRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTransferGetContainerRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferLocationResponse
import com.fsc.flare.source.repository.InventoryRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = RCTSViewModel::class.java.simpleName.toString()

@HiltViewModel
class RCTSViewModel @Inject constructor(
    private val inventoryRepository: InventoryRepository,
    private var sharedPreferences: SharedPreferences,
) : BaseViewModel() {

    private val _rctsContainerResponse = SingleLiveEvent<Resource<InventoryTransferContainerResponse>>()
    private val _rctsLocationResponse = SingleLiveEvent<Resource<InventoryTransferLocationResponse>>()
    fun getRCTSContainerResponse(): LiveData<Resource<InventoryTransferContainerResponse>> {
        return _rctsContainerResponse
    }

    var rctsContainerResponse: InventoryTransferContainerResponse? = null
    fun fetchRCTSContainerResponse(): InventoryTransferContainerResponse? = rctsContainerResponse
    fun getRCTSLocationResponse(): LiveData<Resource<InventoryTransferLocationResponse>> {
        return _rctsLocationResponse
    }

    var rctsLocationResponse: InventoryTransferLocationResponse? = null
    fun fetchRCTSLocationResponse(): InventoryTransferLocationResponse? = rctsLocationResponse


    fun prepareInventoryTransferContainerToStagingRequest(containerNbr: String) = viewModelScope.launch {
        inventoryTransferContainerToStaging(
            InventoryTransferGetContainerRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                containerNbr = containerNbr,
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString()
            )
        )
    }

    private suspend fun inventoryTransferContainerToStaging(inventoryTransferGetContainerRequest: InventoryTransferGetContainerRequest) {
        _rctsContainerResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferContainerReverseToForwardResponse(inventoryTransferGetContainerRequest)
        _rctsContainerResponse.postValue(handleRCTSContainerResponse(response))
    }

    private fun handleRCTSContainerResponse(response: Response<InventoryTransferContainerResponse>): Resource<InventoryTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CTAContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CTAContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun prepareInventoryTransferContainerLocation(locBarcode: String) = viewModelScope.launch {
        val ctaContainerData = fetchRCTSContainerResponse()
        ctaContainerData?.let {
            inventoryTransferContainerLocation(
                InventoryTransferContainerLocationRequest(
                    custId = ctaContainerData.custId,
                    fcyId = ctaContainerData.fcyId,
                    buId = ctaContainerData.buId,
                    itemCode = ctaContainerData.itemCode,
                    description = ctaContainerData.description,
                    containerNbr = ctaContainerData.containerNbr,
                    scanQty = ctaContainerData.scanQty,
                    fromLocationBarcode = ctaContainerData.fromLocationBarcode,
                    toLocationBarcode = locBarcode,
                    inventoryType = ctaContainerData.inventoryType,
                    toLocationId = 0,
                    itemId = ctaContainerData.itemId,
                    userEnteredLocationBarcode = locBarcode,
                    userEnteredLocationId = null,
                    zoneGroupId = null,
                    includeCCLocation = if (sharedPreferences.getBoolean(
                            PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                            false
                        )
                    ) "Y" else "N",
                    isReverseToForward = true
                )
            )
        }
    }

    private suspend fun inventoryTransferContainerLocation(inventoryTransferContainerLocationRequest: InventoryTransferContainerLocationRequest) {
            _rctsLocationResponse.postValue(Resource.Loading())
            val response = inventoryRepository.inventoryTransferContainerLocationResponse(inventoryTransferContainerLocationRequest)
            _rctsLocationResponse.postValue(handleCTALocationResponse(response))
        }

    private fun handleCTALocationResponse(response: Response<InventoryTransferLocationResponse>): Resource<InventoryTransferLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferLocationResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}