package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingReplenishmentPutwayToCasepickBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.PickInfo
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull

private val TAG = PalletReplenishmentActiveAndCasePickDetailedFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PalletReplenishmentActiveAndCasePickDetailedFragment : BaseFragment(), FlareScannable {

    private lateinit var binding: FragmentInterleavingReplenishmentPutwayToCasepickBinding
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private val viewModel: InterLeavingExecuteTaskViewModel by viewModels()

    private val screenTitle by lazy {
        PalletReplenishmentToActiveAndCasePickArgs.fromBundle(
            requireArguments()
        ).title
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingReplenishmentPutwayToCasepickBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        disableDeviceBack()
        initiateView(sharedViewModel.validateContainerResponse?.interLeavingData?.pickInfo)
        observeFlowOnUI { observeApiResults() }
        validateDeliveryLocation()
    }

    private fun initiateView(pickInfo: PickInfo?) {
        binding.tvInterleaving.text = screenTitle
        binding.tvTaskId.text = pickInfo?.taskId.toString()
        binding.tvItemCode.text = pickInfo?.itemBarcode.toString()
        binding.tvLocation.text = pickInfo?.pickLocBarcode.toString()
        binding.tvPallet.text = pickInfo?.containerNbr.toString()
        binding.tvDeliveryLocation.text = "Location"

    }

    private suspend fun observeApiResults() {
        viewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is PutwayToReserveTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is PutwayToReserveTaskState.PickNextTask -> {
                    initiateView(state.pickInfo)
                }

                is PutwayToReserveTaskState.ShowError -> showErrorSnackBar(state.errorMessage)
                is PutwayToReserveTaskState.EnableScanCurrentLocation -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    val action =
                        PalletReplenishmentActiveAndCasePickDetailedFragmentDirections.actionPalletReplenishmentActiveAndCasePickDetailedFragmentToScanCurrentLocation()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code
                    val action =
                        PalletReplenishmentActiveAndCasePickDetailedFragmentDirections.actionPalletReplenishmentActiveAndCasePickDetailedFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToActive -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    val action =
                        PalletReplenishmentActiveAndCasePickDetailedFragmentDirections.actionPalletReplenishmentActiveAndCasePickDetailedFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PICK_FROM_RESERVE.code
                    val action =
                        PalletReplenishmentActiveAndCasePickDetailedFragmentDirections.actionPalletReplenishmentActiveAndCasePickDetailedFragmentToPickFromReserve()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun validateDeliveryLocation() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (binding.etDeliveryLoction.isFocused && !binding.etDeliveryLoction.text.isNullOrEmpty()) {
                            callTaskExecutiveService()

                        } else {
                            binding.tvShowLocationError.visibility = View.VISIBLE
                            binding.tvShowLocationError.text =
                                getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.etDeliveryLoction.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.etDeliveryLoction)
                       callTaskExecutiveService()
                   }
                   return@setOnEditorActionListener false
               }

            binding.etDeliveryLoction.doAfterTextChanged {  binding.tvShowLocationError.visibility = View.GONE }
        }
    }

    private fun callTaskExecutiveService() {
        if (binding.etDeliveryLoction.text.toString() == binding.tvDeliveryLocation.text.toString()) {
            viewModel.callExecuteTaskService(
                endTaskRequest = ExecuteTaskRequest(
                    binding.etDeliveryLoction.text.toString(),
                    sharedViewModel.taskInterLeavingResponse?.sessionId ?: "0",
                    sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                        ?: 0
                )
            )
        } else {
            binding.tvShowLocationError.visibility = View.VISIBLE
            binding.tvShowLocationError.text =
                getString(R.string.lbl_invalid_location)
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.etDeliveryLoction.isFocused && binding.etDeliveryLoction.text.isNullOrEmpty()) {
            binding.etDeliveryLoction.setText(scan?.barcode.toString())
            callTaskExecutiveService()
        }
    }

    private fun disableDeviceBack() {
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
        }
    }
}