package com.fsc.flare.source.repository


import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.utility.itemsizebyslp.UpdateItemSizeBySLPRequest
import com.fsc.flare.source.data.dto.utility.itemsizebyslp.UtilitySlpRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class UtilityRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun validateSlpFromServer(utilitySlpRequest: UtilitySlpRequest) =
        apiGatewayInterface.validateSlp(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            warehouse = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            facid = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            scnLp = utilitySlpRequest.scnLp,
            itemSizeSLP = utilitySlpRequest.itemSizeSLP
        )

    suspend fun getProductSizesLookup() =
        apiGatewayInterface.getProductSizesLookup(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        )

    suspend fun updateItemSizeBySlp(updateItemSizeBySLPRequest: UpdateItemSizeBySLPRequest) =
        apiGatewayInterface.updateItemSizeBySlp(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            warehouse = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            slp = updateItemSizeBySLPRequest.slp,
            size = updateItemSizeBySLPRequest.size
        )
}