package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenLocationScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenLocationScanFragment::class.java.simpleName.toString()
/**
 * A simple [CaseReplenLocationScanFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenLocationScanFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenLocationScanBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
                PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenLocationScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplenishHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        with(binding) {
            tvPalletCartIdValue.text = viewModel.pickCartNbr
            viewModel.replenTaskDetails.value?.let { taskDetails ->
                tvTaskNumberValue.text = taskDetails.taskId.toString()
                tvItemValue.text = taskDetails.itemCode
                tvLocationValue.text = taskDetails.locationName
            }
        }
        handleTouchAndFocusEvents()
    }


    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etScanLocation)
                    if (!binding.etScanLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Location field focused")
                        validateLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etScanLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanLocation)
                FlareLog.i(TAG, "Location field focused")
                validateLocation()
            }
            false
        }

        binding.etScanLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etScanLocation)
                binding.tvLocationErrorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun validateLocation() {
        if (!binding.etScanLocation.text.isNullOrEmpty()) {
            val taskDetails = viewModel.replenTaskDetails.value
            taskDetails?.let {
                if(it.locationBarcode == binding.etScanLocation.text.toString()) {
                    val action = CaseReplenLocationScanFragmentDirections.actionCaseReplenLocationScanToCaseReplenContainerScan()
                    getNavigationController().navigate(action)
                } else {
                    binding.tvLocationErrorResponse.text = getString(R.string.lbl_invalid_pick_location)
                }
            }
        } else {
            binding.tvLocationErrorResponse.text = getString(R.string.lbl_invalid_pick_location)
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        binding.etScanLocation.setText(scan?.barcode.toString())
        binding.etScanLocation.text?.length?.let {
            binding.etScanLocation.setSelection(it)
            validateLocation()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}