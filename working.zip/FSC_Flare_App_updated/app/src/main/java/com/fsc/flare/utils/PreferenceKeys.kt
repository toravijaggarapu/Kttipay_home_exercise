package com.fsc.flare.utils

class PreferenceKeys {

    companion object {
        // Shared Preference Files:
        const val APP_PREFERENCES: String = "com.fsc.flare.APP_PREFERENCES"

        const val LOGIN_TIME = "login_time"
        const val FEDEX_ID = "fedex_id"
        const val FEDEX_EMAIL = "fedex_email"
        const val USER_ID = "user_id"
        const val DEVICE_ID = "device_id"
        const val CUST_ID = "custId"
        const val CUST_NAME = "custName"
        const val CUST_CODE = "custCode"
        const val FACILITY_ID = "facilityId"
        const val FACILITY_NAME = "facilityName"
        const val BUSINESS_UNIT_ID = "businessUnitId"
        const val BUSINESS_UNIT_CODE = "businessUnitCode"
        const val SUB_MENU_SELECTED = "subMenuSelected"
        const val CONTAINER_TYPES = "containerTypes"
        const val APP_LANGUAGE = "language-code"
        const val DEFAULT_INV_TYPE_CODE = "defaultInvTypeCode"
        const val DEFAULT_INV_TYPE_DESC = "defaultInvTypeDesc"
        const val INVENTORY_TYPES_HASH_MAP = "InvTypesHashMap"
        const val DEFAULT_ORDER_STATUS_CODE = "defaultOrderStatusCode"
        const val DEFAULT_ORDER_STATUS_DESC = "defaultOrderStatusDesc"
        const val ORDER_STATUS_HASH_MAP = "OrderStatusHashMap"
        const val DEFAULT_CONTAINER_STATUS_CODE = "defaultContainerStatusCode"
        const val DEFAULT_CONTAINER_STATUS_DESC = "defaultContainerStatusDesc"
        const val CONTAINER_STATUS_HASH_MAP = "ContainerStatusHashMap"
        const val LOCATION_STATUS_HASH_MAP = "LocationStatusHashMap"
        const val LOCK_CODES_HASH_MAP = "LockCodesStatusHashMap"
        const val LOCATION_TYPE_HASH_MAP = "LocationTypeHashMap"
        const val LOCATION_CLASS_HASH_MAP = "LocationClassHashMap"
        const val RESTRICT_LOCKS_HASH_MAP = "RestrictLocksHashMap"
        const val LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE = "LookupLdUldTrailPalletOverride"
        const val LANGUAGES_HASH_MAP ="languagesHashMap"
        const val IS_LANGUAGE_LOOKUP_CONFIGURED = "isLanguageLookUpConfigured"
        const val AllOW_OPS_ON_CC_PENDING_LOCATION = "allowOpsOnCCPendingLocation"
        const val FOLLOW_ITEM_UOMS = "followItemUoms"
        const val LOCK_COMPARE_IN_PALLETIZE_CONT_HASH_MAP = "lockCompareinPalletizeContHashMap"
        const val DOCUMENTS_LOOKUP_MAP = "DocumentsLookupHashMap"

        const val API_GATEWAY_CLIENT_ID = "apiGatewayClientId"
        const val API_GATEWAY_SECRET = "apiGatewaySecret"
        const val API_GATEWAY_ACCESS_TOKEN = "apiGatewayToken"
        const val API_GET_ASN_URL = "apiGetASNURL"
        const val API_LOCATION_URL = "apiLocationURL"
        const val API_ITEM_URL = "apiItemURL"
        const val API_ASN_VERIFY_URL = "apiAsnVerifyUrl"

        const val OKTA_ACCESS_TOKEN = "okta_access_token"
        const val OKTA_REFRESH_TOKEN = "okta_refresh_token"
        const val OKTA_ID_TOKEN = "okta_id_token"

        const val PICKING_WEIGHT_REQ = "weightReq"
        const val PICKING_SUBMIT = "pickSubmit"
        const val PICKING_CNTIN_SAME_LOCATION = "cntsInSameLocation"
        const val PICKING_CNTIN_OTHER_LOCATION = "cntInOtherLocations"

        const val PICKING_WEIGHT = "weight"
        const val DATA_PUTAWAYFORWARD = "data_putawayforward"
        const val PICKING_TOTE_NBR = "tote_nbr"


        const val OKTA_URL = "okta_url" // Used to store the okta url(temp or internal user)
        const val OKTA_CLIENTID = "okta_clientid" // Used to store the client id(temp or internal user)
        const val ISTEMP_USER = "is_tempuser" // used to check info if its temp user or normal user
        const val TEMP_OKTA_ACCESS_TOKEN = "OktaTempJWTToken"
        const val OKTA_USER_ID = "usrId"

        const val SC_CHANNEL_TYPE = "channelType"
        const val SC_FROM_CONT = "fromCont"
        const val SC_QTY = "qty"
        const val SC_SKU_ITEMBARCODE = "skuItembarcode"
        const val RECEVEING_ASN_ID = "receivingAsn"
        const val SERIAL_NUM_LIST = "serialNumList"
        const val RECEIVING_LOCK_CODES = "receivingLockCodes"
        const val RECEIVING_LOT_MESSAGE = "receivingLotMessage"
        const val RECEIVING_FIRST_ARTICLE_INSPECTION = "receivingFirstArticleInspection"
        const val STAGING_PALLET_ID = "stagingPalletId"
        const val STAGING_PALLET_NUMBER = "stagingPalletNumber"
        const val STAGING_LOCATION = "stagingLocation"
        const val LOADTRAILER_DOCK_DOOR_BARCODE = "loadTrailerDockDoorBarcode"

        const val LD_PRINT_REQUESTER = "ldPrintRequester"
        const val LD_PRINT_ENTITY = "ldPrintEntity"

        const val FACILITY_TIMEZONE = "timeZone"
        const val FACILITY_GMT_OFFSET = "gmtOffsetHours"
        const val MIXED_ATTR_LOOKUP_CODE = "mixedAttributeLookUpCode"
        const val CUSTOMER_ENROLLMENT_TYPE = "CustomerEnrollmentTypePreference"
        const val PICK_ORD_TYPE_SELECTION_PREFERENCE = "PickOrdTypeSelectionPreference"
        const val ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE = "AllocTypeOrdTypeSelectionPreference"
        const val PCL_ORD_TYPES_PREFERENCE = "PclOrderTypesPreference"
        const val LTL_ORD_TYPES_PREFERENCE = "LTLOrderTypesPreference"
        const val LOCK_COMPARE_IN_PALLETIZE_CONT = "LOCK_COMPARE_IN_PALLETIZE_CONT"
        const val PALLATIZE_RECEIVING_ITEM_PREFERENCE = "PallatizeReceivingItemPreference"
        const val ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS = "ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS"
        const val ALLOW_REPLENISHMENT_TO_P_N_D_LOCATION = "AllowReplenishmentToPNDLocation"
        const val CASE_PICK_METHOD_LIST_PREFERENCE = "CasePickMethodListPreference"
    }

    class Item private constructor() {
        companion object {
            const val DD_NUMBER = "dd_number"
            const val ITEM_BARCODE = "itemBarCode"
            const val ITEM_BARCODE_TRACKING_LOT_NO = "lotNo"
            const val ITEM_BARCODE_TRACKING_EXPIRATION_DATE = "expirationDate"
            const val ITEM_BARCODE_TRACKING_MANUFACTURING_DATE = "manufacturingDate"
            const val ITEM_BARCODE_TRACKING_MANUFACTURING_CODE = "manufacturingCode"
            const val ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN = "countryOfOrigin"
            const val QUANTITY_INPUT = "quantityEntered"
            const val TRX_QUANTITY_INPUT = "trxquantityEntered"
            const val UOM_INPUT = "uomSelected"
            const val TRX_UOM_INPUT = "trxuomSelected"
            const val STATUS_INPUT = "statusSelected"
            const val LOCATION_ID_INPUT = "locationId"
            const val LOCATION_ID_BARCODE = "locationBarcode"
            const val CONTAINER_ID_INPUT = "containerId"
            const val SCANNED_SERIAL_VAL = "scannedSerialVal"
            const val ITEM_BARCODE_TRACKING_EXPIRATION_DATE_PFA = "expiryDateTrackedPFA"
        }
    }

    class CycleCount private constructor() {
        companion object {
            const val ACT_TASK_GROUP = "actTaskGroup"
            const val ACT_TASK_GROUP_CODE = "actTaskGroupCODE"
            const val ACT_TASK_GROUP_ALLOCATION_TYPE = "actTaskGroupAllocationType"
            const val ACT_TASK_MODE = "actTaskMode"
        }
    }

    class PalletReplenishment private constructor() {
        companion object {
            const val PALLET_REPLEN_TASK_GROUP = "palletReplenTaskGroup"
            const val PALLET_REPLEN_TASK_GROUP_CODE = "palletReplenTaskGroupCODE"
            const val PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE = "palletReplenTaskGroupAllocationType"
            const val PALLET_REPLEN_TASK_MODE = "palletReplenTaskMode"
        }
    }

    class CaseReplenishment private constructor() {
        companion object {
            const val CASE_REPLEN_TASK_GROUP = "caseReplenTaskGroup"
            const val CASE_REPLEN_TASK_GROUP_CODE = "caseReplenTaskGroupCODE"
            const val CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE = "caseReplenTaskGroupAllocationType"
            const val CASE_REPLEN_TASK_MODE = "caseReplenTaskMode"
        }
    }

    class PickingForward private constructor() {
        companion object {
            const val TASK_GROUP = "taskGroup"
            const val TASK_GROUP_CODE = "taskGroupCODE"
            const val TASK_GROUP_ALLOCATION_TYPE = "taskGroupAllocationType"
            const val TASK_MODE = "taskMode"
            const val QTY_INPUT = "qtyInput"
            const val SLOT_INPUT = "slotInput"
            const val EXPIRY_DATE_INPUT = "expiryDateInput"
            const val SERIAL_NUM_LIST = "serialNumList"
        }
    }

    class RtvPicking private constructor() {
        companion object {
            const val TASK_GROUP = "rtvTaskGroup"
            const val TASK_GROUP_CODE = "rtvTaskGroupCODE"
            const val TASK_GROUP_ALLOCATION_TYPE = "rtvTaskGroupAllocationType"
            const val TASK_MODE = "rtvTaskMode"
            const val QTY_INPUT = "qtyInput"
            const val SLOT_INPUT = "slotInput"
            const val EXPIRY_DATE_INPUT = "expiryDateInput"
            const val SERIAL_NUM_LIST = "serialNumList"
        }
    }

    class Inventory private constructor() {
        companion object {
            const val CONTAINER_NUMBER = "containerNumber"
        }
    }

    class Shipping private constructor() {
        companion object {
            const val DD_NUMBER = "ddNumber"
        }
    }

    class ReservePick private constructor() {
        companion object {
            const val BLIND_CONTAINER = "blindContainer"
            const val LOT_NUMBER = "lotNumber"
        }
    }

    class PickFromReserve private constructor() {
        companion object {
            const val IS_FIRST_TASK_UNITPICKED = "is_first_task_unitpicked"
            const val IS_PROMPT_ITEM_ATTRIBUTES = "is_prompt_item_attributes"
        }
    }
    class UserdirectedPutaway private constructor() {
        companion object {
            const val IS_SLOT_ALLOCATION_ENABLED = "is_slot_allocation_enabled"
        }
    }
    class Packout private constructor() {
        companion object {
            const val IS_PACKOUT_DONE = "isPackOutDone"
        }
    }


    class SystemdirectedPutaway private constructor() {
        companion object {
            const val IS_SLOT_ALLOCATION_ENABLED = "is_slot_allocation_enabled"
        }
    }

    class PickCart private constructor() {
        companion object {
            const val IS_PROMPT_ITEM_ATTRIBUTES = "is_prompt_item_attributes"
            const val IS_OVERRIDE_ITEM_ATTRIBUTES = "is_override_item_attributes"
        }
    }

    class PhysicalInventory private constructor(){
        companion object {
            const val SELECTED_COUNT_TYPE = "selected_count_type"
        }
    }

    class PartsReplacement private constructor(){
        companion object {
            const val REPAIR_CONTAINER_NUMBER_LIST = "repair_container_number_list"
            const val PUTAWAY_SERIAL_NUMBER_LIST = "putaway_serial_number_list"
            const val PUTAWAY_CONTAINER_NUMBER_LIST = "putaway__container_number_list"
        }
    }

}