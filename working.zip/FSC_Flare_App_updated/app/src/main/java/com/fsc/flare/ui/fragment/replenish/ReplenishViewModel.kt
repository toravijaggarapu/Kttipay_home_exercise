package com.fsc.flare.ui.fragment.replenish

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.PalletAdjustmentDetailResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.source.data.dto.pickingforward.res.CycleCountTriggerResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickActiveStagingRes
import com.fsc.flare.source.data.dto.pickingforward.res.ZeroLocationPromptResp
import com.fsc.flare.source.data.dto.replenishment.*
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.ReplenishRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class ReplenishViewModel @Inject constructor(
    private val replenishRepository: ReplenishRepository
) : BaseViewModel() {

    private var scannedPallet: MutableLiveData<String> = MutableLiveData()
    var taskTypeDesc: String = ""
    var inventoryTypeCode: String = ""
    val taskGroupResponse: MutableLiveData<Resource<TaskGroupResponse>> = SingleLiveEvent()
    val replenTaskPickResponse: MutableLiveData<Resource<TaskReplenResponse>> = SingleLiveEvent()
    val submitReplenTaskResponse: MutableLiveData<Resource<TaskReplenResponse>> = SingleLiveEvent()
    val taskReplenResponse: MutableLiveData<Resource<TaskReplenResponse>> = SingleLiveEvent()
    var endCartResponse: MutableLiveData<Resource<TaskReplenEndCartResponse>> = SingleLiveEvent()
    var skipCartResponse: MutableLiveData<Resource<SkipTaskDetailsResponse>> = SingleLiveEvent()
    var palletReplenSkipResponse: MutableLiveData<Resource<TaskReplenResponse>> = SingleLiveEvent()
    var replenUnloadResponse: MutableLiveData<Resource<TaskReplenUnloadResponse>> = SingleLiveEvent()
    var validateBlindContainerResponse: MutableLiveData<Resource<ValidateBlindContainerResponse>> = SingleLiveEvent()
    private var taskGroupCodeOptions: MutableLiveData<ArrayList<String>> = MutableLiveData()
    private var taskGroupsList: MutableLiveData<ArrayList<TaskGroup>> = MutableLiveData()
    val locationClassResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val taskstagingresponse: MutableLiveData<Resource<TaskPickActiveStagingRes>> = SingleLiveEvent()
    val palletDetailResponse: MutableLiveData<Resource<PalletAdjustmentDetailResponse>> = SingleLiveEvent()
    val validatePalletOverrideResponse: MutableLiveData<Resource<ValidatePalletOverrideResponse>> = SingleLiveEvent()
    val zeroLocationPromptResponse: MutableLiveData<Resource<ZeroLocationPromptResp>> = SingleLiveEvent()
    var canGenerateCycleCount: Boolean = false

    fun getScannedPallet(): String {
        return scannedPallet.value.orEmpty()
    }
    fun setScannedPallet(scannedPallet: String) {
        this.scannedPallet.value = scannedPallet
    }

    fun gettaskGroupCodeOptions(): ArrayList<String>? {
        return taskGroupCodeOptions.value
    }

    fun settaskGroupCodeOptions(taskGroupOptions: ArrayList<String>) {
        this.taskGroupCodeOptions.value = taskGroupOptions
    }

    fun getTaskGroupsList(): ArrayList<TaskGroup>? {
        return taskGroupsList.value
    }

    fun setTaskGroupsList(taskGroups: ArrayList<TaskGroup>) {
        this.taskGroupsList.value = taskGroups
    }

    fun getTaskGroups() = viewModelScope.launch {
        taskGroupResponse.postValue(Resource.Loading())
        val response = replenishRepository.getTaskGroups()
        taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskGroupsResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateFromLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getReplenishmentPickTask(replenPickTaskRequest: TaskReplenRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getReplenishmentPickTask Request: $replenPickTaskRequest")
        replenTaskPickResponse.postValue(Resource.Loading())
        val response = replenishRepository.getReplenPickTask(replenPickTaskRequest)
        replenTaskPickResponse.postValue(handleTaskReplenResponse(response))
    }

    fun submitReplenishmentTask(allocationType: String, replenPatchRequest: ReplenPatchRequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "submit Replenishment Task Request: $replenPatchRequest")
            submitReplenTaskResponse.postValue(Resource.Loading())
            if (allocationType == "40") {
                val response = replenishRepository.submitReplenActiveTask(replenPatchRequest)
                submitReplenTaskResponse.postValue(handleSubmitReplenTaskResponse(response))
            } else if (allocationType == "50") {
                val response = replenishRepository.submitReplenCasePickTask(replenPatchRequest)
                submitReplenTaskResponse.postValue(handleSubmitReplenTaskResponse(response))
            }
        }

    private fun handleSubmitReplenTaskResponse(response: Response<TaskReplenResponse>): Resource<TaskReplenResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenSubmitResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "ValidateFromLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }



    fun getTaskReplen(taskReplenRequest: TaskReplenRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "GetTaskReplen Request:$taskReplenRequest")
        taskReplenResponse.postValue(Resource.Loading())
        val response = replenishRepository.getTaskReplen(taskReplenRequest)
        taskReplenResponse.postValue(handleTaskReplenResponse(response))
    }

    fun getTaskCartReplen(taskReplenRequest: TaskReplenCartRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "GetTaskCartReplen Request:$taskReplenRequest")
        taskReplenResponse.postValue(Resource.Loading())
        val response = replenishRepository.getTaskCartReplen(taskReplenRequest)
        taskReplenResponse.postValue(handleTaskReplenResponse(response))
    }

    private fun handleTaskReplenResponse(response: Response<TaskReplenResponse>): Resource<TaskReplenResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateFromLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun getPalletDetail(palletNumber: String) = viewModelScope.launch {
        palletDetailResponse.postValue(Resource.Loading())
        val response = replenishRepository.getPalletDetail(palletNumber)
        palletDetailResponse.postValue(handlePalletDetailResponse(response))
    }

    private fun handlePalletDetailResponse(response: Response<PalletAdjustmentDetailResponse>): Resource<PalletAdjustmentDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private var replenTask: MutableLiveData<TaskReplenResponse> = MutableLiveData()
    private var replenTaskDetails: MutableLiveData<TaskDetails> = MutableLiveData()

    fun getReplenTask(): TaskReplenResponse? {
        return replenTask.value
    }

    fun setReplenTask(replenTask: TaskReplenResponse) {
        this.replenTask.value = replenTask
    }

    fun getReplenTaskDetails(): TaskDetails? {
        return replenTaskDetails.value
    }

    fun setReplenTaskDetails(replenTaskDetails: TaskDetails) {
        this.replenTaskDetails.value = replenTaskDetails
    }

    fun updateReplenEndCart(taskReplenEndCartRequest: TaskReplenEndCartRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "UpdateReplenEndCart Request:$taskReplenEndCartRequest")
        endCartResponse.postValue(Resource.Loading())
        val response = replenishRepository.updateReplenEndCart(taskReplenEndCartRequest)
        endCartResponse.postValue(handleTaskReplenEndCartResponse(response))
    }

    private fun handleTaskReplenEndCartResponse(response: Response<TaskReplenEndCartResponse>): Resource<TaskReplenEndCartResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenEndCartResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskReplenEndCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun palletReplenTaskSkip(skipTaskDetailsRequest: SkipTaskDetailsRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "palletReplenTaskSkip Request:$skipTaskDetailsRequest")
        palletReplenSkipResponse.postValue(Resource.Loading())
        val response = replenishRepository.replenTaskSkip(skipTaskDetailsRequest)
        palletReplenSkipResponse.postValue(handleReplenTaskSkipResponse(response))
    }

    private fun handleReplenTaskSkipResponse(response: Response<TaskReplenResponse>): Resource<TaskReplenResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateFromLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun taskReplenSkip(skipTaskDetailsRequest: SkipTaskDetailsRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "TaskReplenSkip Request:$skipTaskDetailsRequest")
        skipCartResponse.postValue(Resource.Loading())
        val response = replenishRepository.taskReplenSkip(skipTaskDetailsRequest)
        skipCartResponse.postValue(handleTaskReplenSkipCartResponse(response))
    }

    private fun handleTaskReplenSkipCartResponse(response: Response<SkipTaskDetailsResponse>): Resource<SkipTaskDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenSkipCartResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskReplenSkipCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateBlindContainer(validateBlindContainerRequest: ValidateBlindContainerRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "ValidateBlindContainer Request:$validateBlindContainerRequest")
        validateBlindContainerResponse.postValue(Resource.Loading())
        val response = replenishRepository.validateBlindContainer(validateBlindContainerRequest)
        validateBlindContainerResponse.postValue(handleBlindContainerResponse(response))
    }

    private fun handleBlindContainerResponse(response: Response<ValidateBlindContainerResponse>): Resource<ValidateBlindContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "BlindContainerResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "BlindContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun unloadReplen(taskReplenUnloadRequest: TaskReplenUnloadRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "UnloadReplen Request:$taskReplenUnloadRequest")
        replenUnloadResponse.postValue(Resource.Loading())
        val response = replenishRepository.unloadReplen(taskReplenUnloadRequest)
        replenUnloadResponse.postValue(handlereplenUnloadResponse(response))
    }

    private fun handlereplenUnloadResponse(response: Response<TaskReplenUnloadResponse>): Resource<TaskReplenUnloadResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "replenUnloadResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "replenUnload Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateStagingLocation Request: $locationClassReq")
        locationClassResponse.postValue(Resource.Loading())
        val response = replenishRepository.validateStagingLocation(locationClassReq)
        locationClassResponse.postValue(handleLocationClassResponse(response))
    }

    private fun handleLocationClassResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun taskstaging(taskStagingRequest: TaskStagingRequest) = viewModelScope.launch {
        taskstagingresponse.postValue(Resource.Loading())
        val response = replenishRepository.taskstaging(taskStagingRequest)
        taskstagingresponse.postValue(handleTaskStagingResponse(response))
    }

    private fun handleTaskStagingResponse(response: Response<TaskPickActiveStagingRes>): Resource<TaskPickActiveStagingRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskStaging Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validatePalletOverride(validatePalletOverrideRequest : ValidatePalletOverrideRequest) = viewModelScope.launch {
        validatePalletOverrideResponse.postValue(Resource.Loading())
        val response = replenishRepository.validatePalletOverride(validatePalletOverrideRequest)
        validatePalletOverrideResponse.postValue(handleValidatePalletOverride(response))
    }
    private fun handleValidatePalletOverride(response: Response<ValidatePalletOverrideResponse>): Resource<ValidatePalletOverrideResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleValidatePalletOverride Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleValidatePalletOverride Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _generateCCforLocationResponse =
        SingleLiveEvent<Resource<CycleCountTriggerResponse>>()
    val generateCCforLocationResponse: LiveData<Resource<CycleCountTriggerResponse>>
        get() = _generateCCforLocationResponse

    fun generateCycleCount(cycleCountTriggerRequest: CycleCountTriggerRequest, pullLocationId: Int) =
        viewModelScope.launch {
            _generateCCforLocationResponse.postValue(Resource.Loading())
            val response = replenishRepository.generateCCForLocation(cycleCountTriggerRequest, pullLocationId)
            _generateCCforLocationResponse.postValue(handleGenerateCycleCountResponse(response))
            canGenerateCycleCount = false
        }

    private fun handleGenerateCycleCountResponse(response: Response<CycleCountTriggerResponse>): Resource<CycleCountTriggerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskReplenResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun zeroLocationPromptCall(locationId: Long, skipPalletId: List<Long>) = viewModelScope.launch {
        zeroLocationPromptResponse.postValue(Resource.Loading())
        val response = replenishRepository.zeroLocationPromptCall(locationId, skipPalletId)
        zeroLocationPromptResponse.postValue(handleZeroLocationPromptCall(response))
    }

    private fun handleZeroLocationPromptCall(response: Response<ZeroLocationPromptResp>): Resource<ZeroLocationPromptResp>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "zeroLocationPromptResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "zeroLocationPromptResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateDeliveryLocation(
        inputLocation: String,
        isPnDFeatureEnabled: Boolean = false
    ): Boolean {
        return if (isPnDFeatureEnabled) {
            inputLocation == getReplenTaskDetails()?.destLocationBarcode ||
                    getReplenTaskDetails()?.dropLocations?.any { it == inputLocation } == true
        } else {
            inputLocation == getReplenTaskDetails()?.destLocationBarcode
        }
    }
}
