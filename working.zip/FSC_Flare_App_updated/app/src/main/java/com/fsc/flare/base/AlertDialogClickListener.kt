package com.fsc.flare.base

interface AlertDialogClickListener {
    fun onPositiveButtonClick()
    fun onNegativeButtonClick()
}