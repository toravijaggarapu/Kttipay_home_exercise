package com.fsc.flare.ui.fragment.replenish.rewarehouse

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.rewarehouse.*
import com.fsc.flare.source.repository.RewarehouseRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "RewarehouseViewModel"

@HiltViewModel
class RewarehouseViewModel @Inject constructor(
    private val rewareHouseRepository: RewarehouseRepository
) : BaseViewModel() {
    val containerDetailsRes: MutableLiveData<Resource<ContainerDetailsResponse>> = SingleLiveEvent()
    val rewareMovesRes: MutableLiveData<Resource<RewareMovesResponse>> = SingleLiveEvent()
    val valToLocRes: MutableLiveData<Resource<ValidateToLocResponse>> = SingleLiveEvent()
    val valFromLocRes: MutableLiveData<Resource<ValidateFromLocationResponse>> = SingleLiveEvent()
    val valToContRes: MutableLiveData<Resource<ValidateToContainerResponse>> = SingleLiveEvent()
    val sbNumberRes: MutableLiveData<Resource<RewareHouseSbNumberResponse>> = SingleLiveEvent()
    val rewareHouseSubmitRes: MutableLiveData<Resource<SubmitRewarehouseResponse>> = SingleLiveEvent()
    val rewareHouseSerialRes: MutableLiveData<Resource<RewareHouseSerialResponse>> = SingleLiveEvent()
    val noNetworkUpdate: MutableLiveData<String> = SingleLiveEvent()

    fun containerDetails(containerDetailsRequest: ContainerDetailsRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "containerDetails() REQ called with $containerDetailsRequest")
        try {
            FlareLog.i(TAG, "Container details request: $containerDetailsRequest")
            containerDetailsRes.postValue(Resource.Loading())
            val response = rewareHouseRepository.containerDetails(containerDetailsRequest)
            FlareLog.i(TAG, "containerDetails() RES called with ${response.body()}")
            containerDetailsRes.postValue(handleContainerDetailsRes(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun rewareMoves(rewareMovesRequest: RewareMovesRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Rware moves request: $rewareMovesRequest")
        try {
            rewareMovesRes.postValue(Resource.Loading())
            val response = rewareHouseRepository.rewareMoves(rewareMovesRequest)
            FlareLog.i(TAG, "rewareMoves() RES called with ${response.body()}")
            rewareMovesRes.postValue(handleRewareMovesRes(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                FlareLog.e("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun validateToLocation(validateToLocationRequest: ValidateToLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validate ToLocation request: $validateToLocationRequest")
        try {
            valToLocRes.postValue(Resource.Loading())
            val toLocResponse = rewareHouseRepository.validateToLocation(validateToLocationRequest)
            FlareLog.i(TAG, "validateToLocation() RES called with ${toLocResponse.body()}")
            valToLocRes.postValue(handleValidateToLocRes(toLocResponse))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun validateFromLocation(validateFromLocRequest: ValidateFromLocRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validate FromLocation request: $validateFromLocRequest")
        try {
            valFromLocRes.postValue(Resource.Loading())
            val fromLocResponse = rewareHouseRepository.validateFromLocation(validateFromLocRequest)
            FlareLog.i(TAG, "validateFromLocation() RES called with ${fromLocResponse.body()}")
            valFromLocRes.postValue(handleValidateFromLocRes(fromLocResponse))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun validateToContainer(validateToContainerRequest: ValidateToContainerRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validate ToContainer request: $validateToContainerRequest")
        try {
            valToContRes.postValue(Resource.Loading())
            val valToContResponse = rewareHouseRepository.validateToContainer(validateToContainerRequest)
            valToContRes.postValue(handleValidateToContRes(valToContResponse))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleValidateToContRes(response: Response<ValidateToContainerResponse>): Resource<ValidateToContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateToContResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateToCont Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // MN:SbNum   Validate SB number will return success or failure message
    fun validateSbNumber(sbNumberRequest: RewareHouseSbNumberRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validate SBNumber request: $sbNumberRequest")
        sbNumberRes.postValue(Resource.Loading())
        val response = rewareHouseRepository.validateSbNumber(sbNumberRequest)
        FlareLog.i(TAG, "validateFromLocation() RES called with ${response.body()}")
        sbNumberRes.postValue(handleValidateSbNumber(response))
        try {
            sbNumberRes.postValue(Resource.Loading())
            sbNumberRes.postValue(handleValidateSbNumber(rewareHouseRepository.validateSbNumber(sbNumberRequest)))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    // MN:SbNum
    private fun handleValidateSbNumber(response: Response<RewareHouseSbNumberResponse>): Resource<RewareHouseSbNumberResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateSbNumberResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateSbNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleValidateFromLocRes(response: Response<ValidateFromLocationResponse>): Resource<ValidateFromLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateFromLocResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateFromLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleValidateToLocRes(response: Response<ValidateToLocResponse>): Resource<ValidateToLocResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateToLocResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateToLoc Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleRewareMovesRes(response: Response<RewareMovesResponse>): Resource<RewareMovesResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "RewareMovesResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "RewareMoves Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleContainerDetailsRes(response: Response<ContainerDetailsResponse>): Resource<ContainerDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Container Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun rewareHouseSubmit(submitRewarehouseRequest: SubmitRewarehouseRequest, rewareSubmitRequestBody: RewareSubmitRequestBody) =
        viewModelScope.launch {
            FlareLog.i(TAG, "Rewarehouse submit  request: $submitRewarehouseRequest")
            try {
                rewareHouseSubmitRes.postValue(Resource.Loading())
                val response = rewareHouseRepository.submitRewarehouse(submitRewarehouseRequest, rewareSubmitRequestBody)
                rewareHouseSubmitRes.postValue(handleRewareHouseSubmitRes(response))
            } catch (e: Exception) {
                FlareLog.e("Connection Issue", e.message.toString())
                if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                    noNetworkUpdate.postValue("No Network")
                }
            }
        }

    private fun handleRewareHouseSubmitRes(response: Response<SubmitRewarehouseResponse>): Resource<SubmitRewarehouseResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleRewareHouseResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "RewareHouseSubmit Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun rewareHouseSerial(serial: String) {
        viewModelScope.launch {
            FlareLog.i(TAG, "Rewarehouse serial  request: $serial")
            try {
                rewareHouseSerialRes.postValue(Resource.Loading())
                val serialResponse = rewareHouseRepository.rewareHouseSerial(serial)
                rewareHouseSerialRes.postValue(handleRewarehouseSerialRes(serialResponse))
            } catch (e: Exception) {
                FlareLog.e("Connection Issue", e.message.toString())
                if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                    noNetworkUpdate.postValue("No Network")
                } else {
                    rewareHouseSerialRes.postValue(Resource.Error("Socket Timeout Exception"))
                }
            }
        }
    }

    private fun handleRewarehouseSerialRes(response: Response<RewareHouseSerialResponse>): Resource<RewareHouseSerialResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "RewarehouseSerialResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "RewarehouseSerial Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}