package com.fsc.flare.transactiontracker.dto

data class FSCTransactionDetailModel(
    var seqNo: Int,
    val screenName: String,
    var objType: String,
    var objName: String,
    var objAction: String,
    val eventTimeStamp: String,
    var labelName: String = "",
    var labelValue: String = "",
    var labelInputType: String = "",
    var apiTriggers : ArrayList<FSCTrackerContainerDetailModel> = ArrayList()
)