package com.fsc.flare.ui.fragment.inventory.containertoactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCtaContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.ui.fragment.inventory.inventorytransfer.InventoryTransferContainerFragmentDirections
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CTAContainerFragment::class.java.simpleName.toString()

/**
 * A simple [CTAContainerFragment] class.
 */
@AndroidEntryPoint
class CTAContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: CTAViewModel by activityViewModels()
    private lateinit var binding: FragmentCtaContainerBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etContainer.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etContainer)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCtaContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvInventoryTransfer.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etContainer.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainer)
                FlareLog.i(TAG, "Container field focused")
                if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                    validateContainer()
                }
            }
            false
        }

        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun validateContainer() {
        viewModel.inventoryTransferContainer(
            GetContDetailRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                containerNbr = binding.etContainer.text.toString(),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                includeCCLocation = if (sharedPreferences.getBoolean(
                        PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                        false
                    )
                ) "Y" else "N",
                locClass = "A"
            )
        )
    }

    private fun subscribeObservers() {
        observeCTAContainerResponse()
    }

    private fun observeCTAContainerResponse() {
        viewModel.getCTAContainerResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { ctaContainerResponse ->
                        FlareLog.i(TAG, "ctaContainerResponse success: $ctaContainerResponse")
                        if (!ctaContainerResponse.message.isNullOrEmpty()) {
                            when (ctaContainerResponse.messageCode) {
                                "ERR-INV-DYS-001", "ERR-INV-DYS-002" -> {
                                    showSuccessSnackBarStd(ctaContainerResponse.message) {
                                        viewModel.ctaContainerResponse = ctaContainerResponse
                                        val action = CTAContainerFragmentDirections.actionCtaContainerFragmentToCtaLocationFragment()
                                        getNavigationController().navigate(action)
                                    }
                                }
                                else -> {
                                    binding.tvContainerResponse.text = ctaContainerResponse.message
                                }
                            }
                        } else {
                            viewModel.ctaContainerResponse = ctaContainerResponse
                            val action = CTAContainerFragmentDirections.actionCtaContainerFragmentToCtaLocationFragment()
                            getNavigationController().navigate(action)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(
                            TAG,
                            "ctaContainerResponse Error: $message"
                        )
                        binding.tvContainerResponse.text = message
                        binding.etContainer.requestFocus()
                        binding.etContainer.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etContainer)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etContainer.setText(scan?.barcode.toString())
        binding.etContainer.text?.length?.let {
            binding.etContainer.setSelection(it)
            validateContainer()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}