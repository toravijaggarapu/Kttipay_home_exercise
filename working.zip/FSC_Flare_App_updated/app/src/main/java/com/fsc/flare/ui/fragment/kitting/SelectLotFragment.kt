package com.fsc.flare.ui.fragment.kitting

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSelectLotBinding
import com.fsc.flare.source.data.dto.kitting.LotNumbers
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [SelectLotFragment] class.
 */
@AndroidEntryPoint
class SelectLotFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: KittingViewModel by activityViewModels()
    private lateinit var binding: FragmentSelectLotBinding
    private lateinit var pallet: PalletResponse

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSelectLotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        handleLotSelection()
        return binding.root
    }

    private fun setUpViews() {
        pallet = viewModel.getPalletResponse()
        // These fields are not required to show in kit staging to kit station but showing in kit station to kit station.
        binding.tvTotalQty.visibility = View.GONE
        binding.tvTotalQtyValue.visibility = View.GONE
        binding.tvMoveQty.visibility = View.GONE
        binding.tvMoveQtyValue.visibility = View.GONE

        val item = viewModel.selectedItem
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        if (pallet.palletNumber != null) {
            binding.tvPalletNumberValue.text = pallet.palletNumber
        } else {
            binding.tvPalletNumber.visibility = View.GONE
            binding.tvPalletNumberValue.visibility = View.GONE
        }
        if (pallet.containersList!![0].items!!.size > 1) {

            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
            }
        } else {
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
            }
        }
        binding.tvKitStagingLocationValue.text = pallet.kitStagingLocation
        binding.kittingItemLayoutInclude.tvKitItemNameValue.text = viewModel.kitItem.kitItemName
        binding.kittingItemLayoutInclude.tvKitItemDescValue.text = viewModel.kitItem.kitItemDescription
        binding.kittingItemLayoutInclude.tvKitViewButton.setOnClickListener {
            showKitItemDialog(viewModel.kitItem!!) {

            }
        }
        item.let { lotItem ->
            val lotNumbers = lotItem?.lotNumbers

            if (lotNumbers != null) {
                if (lotNumbers.size > 1) {
                    val lotList = lotNumbers.map { it.lotNumber }
                    val distinctLOT = lotList.distinct()

                    if (distinctLOT.size > 1) {
                        binding.lotNumberDropDown.setOptions(lotList as ArrayList<String>)
                    } else {
                        updateTheLotQty(lotNumbers, distinctLOT.first())
                        viewModel.setLot(distinctLOT.first(), false)
                        navigateToNext()
                    }
                } else if (lotNumbers.isNotEmpty()) {
                    updateTheLotQty(lotNumbers, lotNumbers[0].lotNumber)
                    viewModel.setLot(lotNumbers[0].lotNumber, false)
                    navigateToNext()
                }
            }
        }

    }

    private fun updateTheLotQty(lotNumbers: List<LotNumbers>, selectedLot: String) {
        val distinctLot: List<LotNumbers> = lotNumbers.filter { it.lotNumber == selectedLot}
        if(distinctLot.isNotEmpty())
        {
            if(distinctLot[0].qty!=0)
            {
                viewModel.updateLotQty(distinctLot[0].qty)
            }
        }
    }

    private fun handleLotSelection() {
        binding.lotNumberDropDown.boolFoo.observe(viewLifecycleOwner) { selectedLot ->

            val item = viewModel.selectedItem
            val lotNumbers = item?.lotNumbers
            if(lotNumbers!!.isNotEmpty())
            {
                updateTheLotQty(lotNumbers, selectedLot)
            }
            viewModel.setLot(selectedLot, false)
            navigateToNext()
        }
    }

    private fun navigateToNext() {
        val item = viewModel.selectedItem
        navController.navigate(R.id.action_selectLotFragment_to_moveQtyFragment)
    }
}