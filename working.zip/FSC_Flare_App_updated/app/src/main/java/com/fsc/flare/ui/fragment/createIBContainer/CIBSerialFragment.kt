package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.receiving.SerialAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBLotFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBSerialFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBSerialFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBSerialBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: SerialAdapter
    private var tempSerialList = ArrayList<String>()
    private var count = 0
    val serialNumberList = mutableListOf<String>()


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSerialNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val itemData = viewModel.getItemBarcodeData()
        if(itemData!=null){
            binding.tvItemCodeValue.text = itemData.itemBarCode
            binding.tvItemDescValue.text = itemData.description
        }
        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        setupRecyclerView()

        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                FlareLog.i(TAG, "Serial Number field focused")
                if (!binding.etSerialNumber.text.isNullOrEmpty()) {
                    validateSerialNumber()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Serial Number field focused")
                        validateSerialNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = SerialAdapter(tempSerialList)
        binding.rvSerial.adapter = serialListAdapter
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSerialNumberObserver()
    }


    /**
     * method to validate Serial Number
     */
    private fun validateSerialNumber() {
        if (!tempSerialList.contains(binding.etSerialNumber.text.toString())) {
            viewModel.validateSerialNumber(binding.etSerialNumber.text.toString().trim())
        }else {
            binding.tvSerialNumberResponse.text = resources.getString(R.string.duplicate_serial)
            binding.etSerialNumber.requestFocus()
            binding.etSerialNumber.selectAll()
        }
    }

    /**
     * method to subscribe SerialNumber observer
     */
    private fun subscribeSerialNumberObserver() {
        viewModel.serialNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { serialValidationResponse ->
                        if (serialValidationResponse!=null && serialValidationResponse.success) {
                            val itemData = viewModel.getItemBarcodeData()
                            if (itemData!=null && serialValidationResponse.itemId == itemData.itemId) {
                                binding.tvSerialNumberResponse.text = resources.getString(R.string.invalid_serial)
                                binding.etSerialNumber.requestFocus()
                                binding.etSerialNumber.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                            } else {
                                addSerialNumberToTempList()
                            }
                        } else {
                            if (serialValidationResponse!=null) {
                                FlareLog.i(TAG, "serialValidation error: $serialValidationResponse")
                                if (serialValidationResponse.message != null) {
                                    displayErrorMessage(serialValidationResponse.message)
                                } else {
                                    displayErrorMessage(resources.getString(R.string.invalid_serial))
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    /**
     * method to add valid serial numbers to main serial list
     */
    private fun addSerialNumberToTempList() {
        if (!tempSerialList.contains(binding.etSerialNumber.text.toString())) {
            tempSerialList.add(binding.etSerialNumber.text.toString())
            serialListAdapter.notifyDataSetChanged()
            binding.etSerialNumber.text = null
            count++
            binding.tvSerialValue.text = String.format("%d/%d",count,viewModel.getInputQtyInUnits())
            if (count == viewModel.getInputQty()) {
                binding.etSerialNumber.isEnabled = false
                count = 0
                saveFinalSerialList()
                Handler(Looper.getMainLooper()).postDelayed({
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBSerialFragmentDirections.actionSerialFragmentToLockReasonCodeFragment()
                    navController.navigate(action)
                }, 200)
            }
        } else {
            displayErrorMessage(resources.getString(R.string.duplicate_serial))
        }
    }


    private fun displayErrorMessage(errorMessage: String) {
        binding.tvSerialNumberResponse.text = errorMessage
        binding.etSerialNumber.requestFocus()
        binding.etSerialNumber.selectAll()
    }

    /**
     * method to save final serial list to view model
     */
    private fun saveFinalSerialList() {
        viewModel.setSerialNumberList(tempSerialList)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etSerialNumber.setText(scan?.barcode.toString())
                binding.etSerialNumber.text?.length?.let {
                    binding.etSerialNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Serial Number field focused")
                    validateSerialNumber()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}