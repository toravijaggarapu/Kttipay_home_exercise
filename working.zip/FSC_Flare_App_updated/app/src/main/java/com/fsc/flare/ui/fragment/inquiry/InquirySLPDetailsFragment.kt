package com.fsc.flare.ui.fragment.inquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquirySLPDetailsBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquirySLPDetailsFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [InquirySLPDetailsFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InquirySLPDetailsFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquirySLPDetailsBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquirySLPDetailsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val slpData = viewModel.getSLPDetails()
        if (slpData != null) {
            binding.tvSlpValue.text = slpData.slp
            binding.tvLocationIdValue.text = slpData.locationId
            binding.tvContainerIdValue.text = slpData.containerId
            binding.tvSlotByNbrValue.text = slpData.slotByNumber
            binding.tvSlpStatusValue.text = slpData.slpStatus
            binding.tvBlNbrValue.text = slpData.blNumber
            binding.tvItemIdValue.text = slpData.itemId
            binding.tvInventoryTypeValue.text = slpData.inventoryType?.let { getInventoryDescription(it) }
            binding.tvZoneValue.text = slpData.zone
        }

        binding.btnOk.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                val navController =
                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                val action =
                    InquirySLPDetailsFragmentDirections.actionInquirySLPDetailsToInquirySLPFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.InquirySLPFragment, true).build()
                navController.navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
        }

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")

    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}