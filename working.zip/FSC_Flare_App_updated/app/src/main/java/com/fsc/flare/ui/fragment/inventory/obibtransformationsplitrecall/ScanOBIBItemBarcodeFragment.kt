package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogRecallItemBinding
import com.fsc.flare.databinding.FragmentScanObIbItemBarcodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.Item
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private val TAG = ScanOBIBItemBarcodeFragment::class.java.simpleName.toString()
/**
 *  [ScanOBIBItemBarcodeFragment] class.
 */
@AndroidEntryPoint
class ScanOBIBItemBarcodeFragment : BaseFragment(), FlareScannable {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentScanObIbItemBarcodeBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etScanItemCode.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etScanItemCode)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentScanObIbItemBarcodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etScanItemCode.requestFocus()
        setUpViews()
        handleTouchAndFocusEvents()
    }

    /**
     * Function to set up views with data
     */
    private fun setUpViews() {
        sharedViewModel.obCartonDetails?.let { obCarton ->
            binding.tvObContainerIdValue.text = obCarton.containerNbr
        }

        binding.tvIbCartonIdValue.text = sharedViewModel.blindIbContainerNumber.orEmpty()

        binding.tvViewRecallItemsValue.setOnClickListener {
            displayRecallItemsDialog(sharedViewModel.obCartonDetails)
        }
    }

    /**
     * Function to display recall items dialog
     */
    private fun displayRecallItemsDialog(obCartonDetails: OBCartonDetails?) {
        obCartonDetails?.let { details ->
            val recallItemsList = filterItemsEligibleWithLockRC(details)
            val dialogView = LayoutInflater.from(fragmentContext).inflate(R.layout.dialog_recall_item, null)
            val binding = DataBindingUtil.bind<DialogRecallItemBinding>(dialogView)

            binding?.apply {
                titleTextView.text = getString(R.string.lbl_recall_items)

                // Determine visibility based on recallItemsList
                if (recallItemsList.isEmpty()) {
                    noItemsTextView.visibility = View.VISIBLE // Show the message
                    itemRecyclerView.visibility = View.GONE // Hide the RecyclerView
                } else {
                    noItemsTextView.visibility = View.GONE // Hide the message
                    itemRecyclerView.visibility = View.VISIBLE // Show the RecyclerView
                    setupRecyclerView(recallItemsList)
                }
            }

            // Show the dialog
            MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                .setView(dialogView)
                .setCancelable(false)
                .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        }
    }

    /**
     * Extension Function to setup recyclerview
     */
    private fun DialogRecallItemBinding.setupRecyclerView(recallItemsList: List<Item>) {
        itemRecyclerView.layoutManager = LinearLayoutManager(fragmentContext)
        itemRecyclerView.adapter = ItemAdapter(recallItemsList)

        val dividerItemDecoration = DividerItemDecoration(itemRecyclerView.context, DividerItemDecoration.VERTICAL).apply {
            setDrawable(ContextCompat.getDrawable(fragmentContext, R.drawable.item_divider)!!)
        }
        itemRecyclerView.addItemDecoration(dividerItemDecoration)
    }

    /**
     * Function to filter Items with RC lock
     */
    private fun filterItemsEligibleWithLockRC(cartonDetails: OBCartonDetails): List<Item> {
        return cartonDetails.itemDetails?.filter { item ->
            item.eligible && item.locks!!.any { lock -> lock.contains("RC", ignoreCase = true) }
        } ?: emptyList()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etScanItemCode.isFocused && !binding.etScanItemCode.text.isNullOrEmpty()) {
                        validateItemBarcode()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etScanItemCode.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanItemCode)
                if (binding.etScanItemCode.isFocused && !binding.etScanItemCode.text.isNullOrEmpty()) {
                    validateItemBarcode()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etScanItemCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvItemCodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate Item Barcode
     */
    private fun validateItemBarcode() {
        val itemBarcode = binding.etScanItemCode.text.toString().trim()
        val obCartonDetails = sharedViewModel.obCartonDetails ?: return // Early return if obCartonDetails is null

        // Filter items with RC lock and find all valid items based on the barcode
        val validItems = filterItemsEligibleWithLockRC(cartonDetails = obCartonDetails)
            .filter { it.itemBarcode == itemBarcode }

        when (validItems.size) {
            0 -> handleInvalidItemBarcode() // No valid items found
            1 -> {
                // Navigate directly if only one valid item is found
                sharedViewModel.itemDetails = validItems.first()
                navigateToNext(validItems.first())
            }
            else -> {
                // Show a dialog for selection if multiple valid items are found
                showBatchSelectionDialog(validItems)
            }
        }
    }

    /**
     * Function to show Batch Selection Dialog
     */
    private fun showBatchSelectionDialog(validItems: List<Item>) {
        val itemNames = validItems.map { "${it.batchNumber}" }.toTypedArray()
        var selectedPosition = -1 // To keep track of the selected item position

        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme).apply {
            setTitle(getString(R.string.select_lot_number))
            setSingleChoiceItems(itemNames, -1) { _, pos ->
                // User selected an item
                selectedPosition = pos // Update the selected position
            }
            setPositiveButton(getString(R.string.alert_button_ok)) { dialogInterface, _ ->
                // Handle positive button click
                if (selectedPosition != -1) {
                    val selectedItem = validItems[selectedPosition]
                    sharedViewModel.itemDetails = selectedItem
                    navigateToNext(selectedItem)
                }
                dialogInterface.dismiss() // Dismiss the dialog
            }
            setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
                dialog.cancel() // Cancel the dialog
            }
            create().apply {
                setCancelable(false)
                show()
            }
        }
    }


    /**
     * Function to handle Invalid Item barcode number
     */
    private fun handleInvalidItemBarcode() {
        with(binding) {
            tvItemCodeResponse.text = getString(R.string.lbl_invalid_barcode)
            etScanItemCode.requestFocus()
            etScanItemCode.selectAll()
            showSoftKeyBoard(requireContext(), etScanItemCode)
        }
    }

    /**
     * Nav Handler to Next Screen based on tracking information of Item
     */
    private fun navigateToNext(item: Item?) {
        item?.let {
            sharedViewModel.lotNumber = item.batchNumber
            sharedViewModel.expiryDate = item.expiryDate
            clearScanItemCode()

            val action = when {
                !it.coo.isNullOrEmpty() -> {
                    ScanOBIBItemBarcodeFragmentDirections.actionScanOBIBItemBarcodeFragmentToScanOBIBCooFragment()
                }
                else -> {
                    ScanOBIBItemBarcodeFragmentDirections.actionScanOBIBItemBarcodeFragmentToScanOBIBItemQtyFragment()
                }
            }
            getNavigationController().navigate(action)
        }
    }

    /**
     * Clear the scan item code input field
     */
    private fun clearScanItemCode() {
        binding.etScanItemCode.text = null
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etScanItemCode.setText(scan?.barcode.toString())
        binding.etScanItemCode.text?.length?.let {
            binding.etScanItemCode.setSelection(it)
            validateItemBarcode()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}