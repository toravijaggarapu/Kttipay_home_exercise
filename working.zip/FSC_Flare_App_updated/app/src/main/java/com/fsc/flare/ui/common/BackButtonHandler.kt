package com.fsc.flare.ui.common

interface BackButtonHandler {
    fun onBackButtonPressed()
}