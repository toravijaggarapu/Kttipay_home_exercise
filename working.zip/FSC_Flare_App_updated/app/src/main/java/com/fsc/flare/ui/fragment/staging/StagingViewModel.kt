package com.fsc.flare.ui.fragment.staging

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.cyclecount.LocationInventoryCount
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintDocAndLabelResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentDocumentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationRequest
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationResponse
import com.fsc.flare.source.repository.StagingRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.RecallCodes
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class StagingViewModel @Inject constructor(
    private val stagingRepository: StagingRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val printRequestorResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    val palletNumberResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val stagingLocationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val stagingPalletLocationResponse: MutableLiveData<Resource<StagingPalletLocationResponse>> = SingleLiveEvent()
    val printInputResponse: MutableLiveData<Resource<ValidateInputResponse>> = SingleLiveEvent()
    private var containerRes: MutableLiveData<OBCartonDetails> = MutableLiveData()

    private val _obCartonRCLockResponse = SingleLiveEvent<Resource<OBCartonRCLockResponse>>()

    internal val obCartonRCLockResponse: LiveData<Resource<OBCartonRCLockResponse>>
        get() = _obCartonRCLockResponse

    private val _obContainerResponse = SingleLiveEvent<Resource<ValidateCartonHandlerTypeResponse>>()
    internal val obContainerResponse: LiveData<Resource<ValidateCartonHandlerTypeResponse>>
        get() = _obContainerResponse

    private val _printInternationalDocumentResponse: MutableLiveData<Resource<PrintDocAndLabelResponse>> = SingleLiveEvent()
    val printInternationalDocumentResponse: LiveData<Resource<PrintDocAndLabelResponse>> = _printInternationalDocumentResponse

    private var validateInput: ValidateInputResponse? = null

    val palletInventoryCountResponse: MutableLiveData<Resource<LocationInventoryCount>> = SingleLiveEvent()
    var casesInPallet = 0

    fun validatePalletNumber(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "PalletNumber Request: $container, $itemInfo")
        palletNumberResponse.postValue(Resource.Loading())
        val response = stagingRepository.validatePalletNumber(container, itemInfo)
        palletNumberResponse.postValue(handlePalletNumberResponse(response))
    }

    private fun handlePalletNumberResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "PalletNumberResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "StagingLocation Request: $locationClassReq")
        stagingLocationResponse.postValue(Resource.Loading())
        val response = stagingRepository.validateStagingLocation(locationClassReq)
        stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "StagingLocation Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validatePalletStagingLocation(stagingPalletLocationRequest: StagingPalletLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "StagingPalletLocation Request: $stagingPalletLocationRequest")
        stagingPalletLocationResponse.postValue(Resource.Loading())
        val response = stagingRepository.validateStagingPalletLocation(stagingPalletLocationRequest)
        stagingPalletLocationResponse.postValue(handleStagingPalletLocationResponse(response))
    }

    private fun handleStagingPalletLocationResponse(response: Response<StagingPalletLocationResponse>): Resource<StagingPalletLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "StagingPalletLocationResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "StagingPalletLocation Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setContainerResponse(containerRes: OBCartonDetails?) {
        this.containerRes.value = containerRes
    }

    fun getContainerResponse(): OBCartonDetails? {
        return containerRes.value
    }

    private fun getInput(): ValidateInputResponse? {
        return validateInput
    }

    fun setInput(validateInput: ValidateInputResponse) {
        this.validateInput = validateInput
    }

    private val printConfigs = mutableListOf<PrinterConfig>()

    fun setPrintConfigs(configs: List<PrinterConfig>) {
        printConfigs.clear()
        printConfigs.addAll(configs)
    }

    fun viewRecallContainersAPIRequest(cartonNumber: String) {
        viewModelScope.launch {
            fetchRCLockOBCartonDetails(
                OBCartonRCLockRequest(
                    palletNbr = cartonNumber,
                    lock = RecallCodes.RECALL_LOCK,
                )
            )
        }
    }

    private suspend fun fetchRCLockOBCartonDetails(obCartonRCLockRequest: OBCartonRCLockRequest) {
        _obCartonRCLockResponse.postValue(Resource.Loading())
        val response = stagingRepository.fetchRecallLockOBContainerDetails(obCartonRCLockRequest)
        _obCartonRCLockResponse.postValue(handleRCLockObCartonDetailsResponse(response))
    }

    private fun handleRCLockObCartonDetailsResponse(response: Response<OBCartonRCLockResponse>): Resource<OBCartonRCLockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun obCartonDetailsRequest(obContainerNumber: String) {
        viewModelScope.launch {
            fetchOBCartonDetails(
                ValidateCartonHandlerTypeRequest(
                    cartonNbr = obContainerNumber,
                    type = OBIBTransformations.OB_STG.type,
                    responseLevel = "SUMMARY"
                )
            )
        }
    }

    private suspend fun fetchOBCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest) {
        _obContainerResponse.postValue(Resource.Loading())
        val response = stagingRepository.fetchObCartonDetails(validateCartonHandlerTypeRequest)
        _obContainerResponse.postValue(handleObCartonDetailsResponse(response))
    }

    private fun handleObCartonDetailsResponse(response: Response<ValidateCartonHandlerTypeResponse>): Resource<ValidateCartonHandlerTypeResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun validateInputForPrinting(validateInputRequest: ValidateInputRequest) = viewModelScope.launch {
        printInputResponse.postValue(Resource.Loading())
        val response = stagingRepository.validateInputForPrinting(validateInputRequest)
        printInputResponse.postValue(handlePrintInputResponse(response))
    }

    private fun handlePrintInputResponse(response: Response<ValidateInputResponse>): Resource<ValidateInputResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintInputResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintInput Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun printInternationalDocuments(printRequest: String) {
        viewModelScope.launch {
            val request = PrintShipmentDocumentRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                orderId = getInput()?.orderId ?: 0,
                documentPrinterName = printConfigs.firstOrNull { it.requestor == printRequest }?.printerName.orEmpty(),
                packingSlipType = getInput()?.packingSlipType.orEmpty(),
                printRequestor = printRequest
            )
            _printInternationalDocumentResponse.postValue(Resource.Loading())
            val response = stagingRepository.printInternationalShipmentDocuments(request)
            _printInternationalDocumentResponse.postValue(handlePrintDocumentResponse(response))
        }
    }

    private fun handlePrintDocumentResponse(response: Response<PrintDocAndLabelResponse>): Resource<PrintDocAndLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintDocumentsResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintDocumentsResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get printer requester config list
     */
    fun getPrintRequesterList(printerConfigRequest: PrinterConfigRequest) = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = stagingRepository.getPrintRequestorList(printerConfigRequest)
        printRequestorResponse.postValue(handlePrintRequesterListResponse(response))
    }

    /**
     * method to handle printer requester config response
     */
    private fun handlePrintRequesterListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getPalletInventory(locationId: String?, palletId: Int?) = viewModelScope.launch {
        palletInventoryCountResponse.postValue(Resource.Loading())
        val response = stagingRepository.getLocationInventoryCount(locationId, palletId)
        palletInventoryCountResponse.postValue(handleLocationInfoWithInventoryCountResponse(response))
    }

    private fun handleLocationInfoWithInventoryCountResponse(response: Response<LocationInventoryCount>):Resource<LocationInventoryCount>?{
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            return Resource.Error(errorResponse)
        }
        return null
    }

}