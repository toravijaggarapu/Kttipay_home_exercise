package com.fsc.flare.ui.fragment.commontasks

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.repository.InventoryMovementRepository
import com.fsc.flare.utils.Constants.Companion.NO
import com.fsc.flare.utils.Constants.Companion.TRANSFER_TYPE_PALLET
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val CONTAINER_TYPE ="Pallet"

@HiltViewModel
class CreateBlindPalletViewModel @Inject constructor(
    private val inventoryMovementRepository: InventoryMovementRepository,
    sharedPreferences: SharedPreferences
) : BaseViewModel() {

    private val _blindPalletViewState = MutableStateFlow<CreateBlindPalletEvent?>(null)
    val blindPalletViewState = _blindPalletViewState.asStateFlow()

    private val _blindPalletErrorState = MutableStateFlow<ErrorMessage?>(null)
    val blindPalletErrorState = _blindPalletErrorState.asStateFlow()

    private val containerType = validateContainerType(sharedPreferences, TRANSFER_TYPE_PALLET)

    /**
     * Generate new pallet number from the Server.
     *
     *  Developed in TDD approach.
     *
     */
    fun generatePalletNumber(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _blindPalletErrorState.emit(ErrorMessage.ClearError)
            _blindPalletViewState.emit(CreateBlindPalletEvent.ProgressBar(isShowProgress = true))
            val response = inventoryMovementRepository.generatePalletNumber(CONTAINER_TYPE)
            _blindPalletViewState.emit(CreateBlindPalletEvent.ProgressBar(isShowProgress = false))
            response.takeIf { it.isSuccessful && response.body() != null && response.body()?.numbers?.isNotEmpty() == true }?.body()?.let {
                _blindPalletViewState.emit(CreateBlindPalletEvent.GeneratedPalletNumber(it.numbers[0].value))
            } ?: run {
                _blindPalletErrorState.emit(ErrorMessage.Error(errorMessage = response.getGiltErrorMessage()))
            }
        }
    }

    /**
     * Validate user entered pallet number.
     *
     */
    fun validatePallet(palletNbr: String, scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _blindPalletErrorState.emit(ErrorMessage.ClearError)
            if (containerType != null && (!palletNbr.startsWith(containerType.ctyId ?: "") ||
                        palletNbr.length != (containerType.ctyContainerLength?.toInt() ?: -1))) {
                _blindPalletErrorState.emit(ErrorMessage.InvalidPalletError(containerType))
            } else {
                _blindPalletViewState.emit(CreateBlindPalletEvent.ProgressBar(isShowProgress = true))
                val response = inventoryMovementRepository.getPalletDetails(palletNbr, NO)
                _blindPalletViewState.emit(CreateBlindPalletEvent.ProgressBar(isShowProgress = false))
                response.takeIf { it.isSuccessful && response.body() != null }?.body()?.let {
                    if (it.container.isEmpty()) {
                        _blindPalletViewState.emit(CreateBlindPalletEvent.GeneratedPalletNumber(palletNbr))
                    } else {
                        _blindPalletErrorState.emit(ErrorMessage.PalletAlreadyExist)
                    }
                } ?: run {
                    _blindPalletErrorState.emit(ErrorMessage.Error(errorMessage = response.getGiltErrorMessage()))
                }
            }
        }
    }
}

/**
 * Sealed class for blind pallet screen events.
 */
sealed class CreateBlindPalletEvent {
    data class ProgressBar(val isShowProgress: Boolean) : CreateBlindPalletEvent()
    data class GeneratedPalletNumber(val palletNumber: String) : CreateBlindPalletEvent()
}

/**
 * Sealed class for blind pallet screen errors.
 */
sealed class ErrorMessage {
    data class Error(val errorMessage: String) : ErrorMessage()
    data class InvalidPalletError(val containerType: CustomerContainerTypes.ContainerTypesEntity) : ErrorMessage()
    data object PalletAlreadyExist : ErrorMessage()
    data object SomethingWentWrong: ErrorMessage()
    data object ClearError: ErrorMessage()
}

