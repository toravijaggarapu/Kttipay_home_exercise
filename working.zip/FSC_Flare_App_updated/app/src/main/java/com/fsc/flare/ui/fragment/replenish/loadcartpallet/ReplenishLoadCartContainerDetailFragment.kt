package com.fsc.flare.ui.fragment.replenish.loadcartpallet


import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishContainerDetailBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ReplenishLoadCartContai"
@AndroidEntryPoint
class ReplenishLoadCartContainerDetailFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishContainerDetailBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishContainerDetailBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        binding.tvReplenish.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.endCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endCartResponse ->
                        FlareLog.i(TAG, "endCart Response: $endCartResponse")
                        if (endCartResponse.success) {
                            FlareLog.i(TAG, "endCart success: $endCartResponse")
                            when {
                                endCartResponse.taskDetails != null -> {
                                    viewModel.setReplenTaskDetails(endCartResponse.taskDetails)
                                    val action = ReplenishLoadCartContainerDetailFragmentDirections.actionLoadCartContainerToFillCasePickContainer()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenFillCasePickContainer, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                                endCartResponse.promptStage -> {
                                    val action =
                                        ReplenishLoadCartContainerDetailFragmentDirections.actionLoadCartContainerToReplenStagingLocationFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenStagingLocationFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                                else -> {
                                    val action = ReplenishLoadCartContainerDetailFragmentDirections.actionLoadCartContainerToLoadCartTaskGroup()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenLoadCartOrPallet, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "endCart error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        FlareLog.i(TAG, "skipCart response : $skipCartResponse")
                        if (skipCartResponse.success) {
                            FlareLog.i(TAG, "skipCart success : $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.setReplenTaskDetails(skipCartResponse.taskDetails)
                                binding.txtTaskIDRes.text = skipCartResponse.taskDetails.taskId.toString()
                                binding.txtItemRes.text = skipCartResponse.taskDetails.itemCode
                                binding.txtDesRes.text = skipCartResponse.taskDetails.itemDescription
                                binding.txtLocationRes.text = skipCartResponse.taskDetails.locationName
                                binding.txtContainerRes.text = skipCartResponse.taskDetails.containerNbr
                                binding.txtPickQtyRes.text =
                                    String.format("%d %s",skipCartResponse.taskDetails.taskQty,skipCartResponse.taskDetails.taskQtyUom)
                            } else {
                                showErrorSnackBar(skipCartResponse.message)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipCart error : $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()
        if (data != null) {
            binding.txtCartPalletRes.text = data.cartNbr
            if (taskData != null) {
                binding.txtTaskIDRes.text = taskData.taskId.toString()
                binding.txtItemRes.text = taskData.itemCode
                binding.txtDesRes.text = taskData.itemDescription
                binding.txtLocationRes.text = taskData.locationName
                binding.txtContainerRes.text = taskData.containerNbr
                binding.txtPickQtyRes.text = String.format("%d %s",taskData.taskQty,taskData.taskQtyUom)
            }
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Navigated to Blindcontainer")
                    navigateToBlindContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
        binding.endCart.setOnClickListener {
            FlareLog.i(TAG, "endCart API called")
            viewModel.updateReplenEndCart(
                TaskReplenEndCartRequest(
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!.toInt(),
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    binding.txtCartPalletRes.text.toString()
                )
            )
        }
        binding.skipCart.setOnClickListener {
            FlareLog.i(TAG, "skipCart API called")
            if (data != null) {
                viewModel.taskReplenSkip(
                    SkipTaskDetailsRequest(
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        binding.txtCartPalletRes.text.toString(),
                        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                        sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                        binding.txtTaskIDRes.text.toString(),
                        skipTaskDetId =  ""
                    )
                )
            }
        }
        binding.etContainerNo.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Navigated to BlindContainer")
                navigateToBlindContainer()
            }
            false
        }
        binding.etContainerNo.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.containerIdResponse.text = null
            }
        })
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "OnScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etContainerNo.setText(scan?.barcode.toString())
            binding.etContainerNo.text?.length?.let {
                binding.etContainerNo.setSelection(it)
            }
            navigateToBlindContainer()
    }

    private fun navigateToBlindContainer() {
        if (!binding.etContainerNo.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainerNo)
            if (binding.txtContainerRes.text == binding.etContainerNo.text.toString()) {
                binding.etContainerNo.text?.clear()
                getNavigationController().navigate(R.id.action_loadCartContainerDetails_to_loadCartBlindContainerDetails)
            } else {
                binding.containerIdResponse.text = getString(R.string.invalid_container)
                binding.etContainerNo.selectAll()
                showSoftKeyBoard(fragmentContext, binding.etContainerNo)
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}
