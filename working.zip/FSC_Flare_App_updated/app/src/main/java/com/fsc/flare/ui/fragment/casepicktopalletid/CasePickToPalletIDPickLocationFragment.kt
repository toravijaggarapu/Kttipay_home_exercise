package com.fsc.flare.ui.fragment.casepicktopalletid

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasePickToPalletIdPickLocationBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromcasepick.NO_TASKS_FOR_CARTNUM_PICKCART
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.DropDown
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "CasePickToPalletIDPickLocationFragment"

/**
 * A simple [CasePickToPalletIDPickLocationFragment] subclass.
 */
@AndroidEntryPoint
class CasePickToPalletIDPickLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: CasePickToPalletIDViewModel by activityViewModels()
    lateinit var binding: FragmentCasePickToPalletIdPickLocationBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentCasePickToPalletIdPickLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        subscribeObservers()
        inputFieldsListeners()
        clickListeners()
    }

    private fun setupUI() {
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        with(binding) {
            tvPickingBuildCart.text =
                sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)

            if (data != null) {
                cart.text = data.cartNbr
                if (taskData != null) {
                    taskId.text = "${taskData.taskId}"
                    item.text = taskData.itemCode
                    description.text = taskData.itemDescription
                    pickLocation.text = taskData.locationBarcode
                    pickQty.text = String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun inputFieldsListeners() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "PickLocation focused")
                    validatePickLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.pickLocationInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "PickLocation field focused")
                validatePickLocation()
            }
            false
        }

        binding.pickLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.pickLocationTvRes.text = null
            }
        })
    }

    private fun clickListeners() {
        binding.endCart.setOnClickListener {
            binding.endCart.isEnabled = false
            viewModel.pickEndCart(viewModel.getPickTask()?.cartId)
        }
        binding.skipCart.setOnClickListener {
            val taskDetails = viewModel.getPickTaskDetails()
            if (taskDetails != null) {
                viewModel.buildSkipCart(taskDetails.taskId)
            }
        }

        binding.skipLineItem.setOnClickListener {
            val taskDetails = viewModel.getPickTaskDetails()
            if (taskDetails != null) {
                viewModel.buildSkipLineItem(taskDetails.taskDetId, taskDetails.taskDetId)
            }
        }
    }

    private fun validatePickLocation() {
        if (isProgressBarVisible()) {
            return
        }
        if (!binding.pickLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.pickLocationInput)
            if (binding.pickLocationInput.text.toString() == binding.pickLocation.text.toString()) {
                binding.pickLocationInput.text?.clear()
                viewModel.validatePickLocation()
            } else {
                binding.pickLocationTvRes.text = getString(R.string.wrong_pick_location)
                binding.pickLocationInput.selectAll()
                showSoftKeyBoard(fragmentContext, binding.pickLocationInput)
            }
        }
    }

    private fun subscribeObservers() {
        subscribeEndCartObserver()
        subscribeSkipCartObserver()
        subscribeLocationClassObserver()
        subscribeCasePickCompleteObserver()
    }

    private fun subscribeEndCartObserver() {
        viewModel.endCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endPickCartResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (endPickCartResponse.success != null && endPickCartResponse.success) {
                            if (endPickCartResponse.promptStage == true) {
                                getNavigationController().navigate(R.id.casePickToPalletIDStageLocationFragment)
                            } else {
                                navigateToPallet()
                            }
                        } else {
                            binding.endCart.isEnabled = true
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.endCart.isEnabled = true
                        FlareLog.e(TAG, "endCart error: $message")
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeSkipCartObserver() {
        viewModel.skipCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                setupUI()
                            } else {
                                skipCartResponse.message?.let { showErrorMessage(it) }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorMessage(message)
                        FlareLog.e(TAG, "skipPickCart error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeLocationClassObserver() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationDetailsResponse ->
                        if (locationDetailsResponse.success && locationDetailsResponse.locations.isNotEmpty()) {
                            handleLocationResponseSuccess(locationDetailsResponse)
                        } else {
                            showErrorMessage(getString(R.string.invalid_location))
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleLocationResponseSuccess(locationDetailsResponse: LocationClassRes) {
        val reserveLocation = locationDetailsResponse.locations[0]
        if (sharedPreferencesBase.getBoolean(
                PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false
            )
        ) {

            if (reserveLocation.lockCode == "CC") {
                val msg = getString(R.string.cycle_count_progress_for_location)
                showCycleCountPendingAlert(msg)
            } else {
                navigateToContainer()
            }
        } else {
            if (reserveLocation.cycleCountPending == "Y") {
                val msg = getString(R.string.cycle_count_pending_for_location)
                showCycleCountPendingAlert(msg)
            } else {
                navigateToContainer()
            }
        }
    }

    private fun subscribeCasePickCompleteObserver() {
        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { casePickCompleteRes ->
                        if (casePickCompleteRes.success != null && casePickCompleteRes.success) {
                            FlareLog.i(TAG, "taskCasePickComplete success: $casePickCompleteRes")
                            binding.pickLocationInput.text?.clear()
                            handleCasePickCompleteSuccessResponse(casePickCompleteRes)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskCasePickComplete error: $message")
                        handleCasePickCompleteErrorResponse(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleCasePickCompleteErrorResponse(message: String) {
        if (message.contains("_")) {
            val msgArray = message.split("_")
            if (msgArray.isNotEmpty()) {
                when {
                    msgArray[0] == LOCATION_IS_EMPTY -> {
                        showAlertDialog("", msgArray[1]) {}
                    }

                    msgArray[0] == TASK_CYCLE_COUNT_PENDING -> {
                        val msg = getString(R.string.cycle_count_pending_for_location)
                        showCycleCountPendingAlert(msg)
                    }

                    else -> {
                        showErrorMessage(message)
                    }
                }
            }
        } else {
            showErrorMessage(message)
        }
    }

    private fun handleCasePickCompleteSuccessResponse(casePickCompleteRes: TaskCasePickCompleteRes) {
        if (casePickCompleteRes.taskDetails != null) {
            viewModel.setPickTaskDetails(casePickCompleteRes.taskDetails)
            setupUI()
        } else {
            // implement when task details is null
            if (casePickCompleteRes.eligibleToStage == null || casePickCompleteRes.eligibleToStage) {
                getNavigationController().navigate(R.id.casePickToPalletIDStageLocationFragment)
            } else {
                showAlertDialog(
                    "",
                    getString(R.string.all_tasks_in_the_pallet_is_cancelled_since_you_short_picked_stage_it)
                ) {
                    navigateToPallet()
                }
            }
        }
    }

    fun showErrorMessage(message: String) {
        with(binding) {
            if (message.contains("##")) {
                val msgArray = message.split("##")
                if (msgArray.isNotEmpty()) {
                    if (msgArray[0] == NO_TASKS_FOR_CARTNUM_PICKCART) {
                        navigateToPallet()
                    } else {
                        pickLocationTvRes.text = (msgArray[1])
                    }
                }
            } else {
                pickLocationTvRes.text = message
            }
            pickLocationInput.selectAll()
            showSoftKeyBoard(fragmentContext, pickLocationInput)
        }
    }

    private fun showCycleCountPendingAlert(msg: String) {
        showAlertDialog("",
            msg,
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.getInventoryReasonCodes()
                    showReasonCode()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    var reasonCode: View? = null
    private fun showReasonCode() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(layoutInflater)
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        reasonCode = dialogView.reasonCodeDropDown
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        (reasonCode as DropDown?)!!.setOptions(inventoryLockList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        (reasonCode as DropDown?)!!.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            callCasePickCompleteAPI(lockCode)
            dialog.dismiss()
        }
    }

    private fun callCasePickCompleteAPI(reasonCode: String) {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            viewModel.taskCasePickCompleteReq(
                taskQty = 0,
                expDate = if (taskData.expDate != null) formatDate(taskData.expDate!!) else "",
                lockCode = reasonCode,
                containerId = taskData.containerId,
                containerNbr = taskData.containerNbr,
                serialNumbers = arrayListOf()
            )
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        binding.pickLocationInput.setText(scan?.barcode.toString())
        binding.pickLocationInput.text?.length?.let {
            binding.pickLocationInput.setSelection(it)
        }
        FlareLog.i(TAG, "PickLocation field focused")
        validatePickLocation()
    }

    private fun navigateToPallet() {
        val action =
            CasePickToPalletIDPickLocationFragmentDirections.actionCasePickToPalletIDPickLocationToCasePickToPalletIDPalletFragment()
        getNavigationController().navigate(action)
    }

    private fun navigateToContainer() {
        getNavigationController().navigate(R.id.casePickToPalletIDContainerFragment)
    }
}