package com.fsc.flare.ui.fragment.prtotetopackstation

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialResponse
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteResponse
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteStageReq
import com.fsc.flare.source.repository.PRToteToPackStationRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PRTPSViewModel"

@HiltViewModel
class PRTPSViewModel @Inject constructor(private val prToteToPackStationRepository: PRToteToPackStationRepository) : BaseViewModel() {
    val toteResponse: MutableLiveData<Resource<PRToteResponse>> = SingleLiveEvent()
    val kitToteResponse: MutableLiveData<Resource<PRToteResponse>> = SingleLiveEvent()
    val toteStageResponse: MutableLiveData<Resource<PickingSerialResponse>> = SingleLiveEvent()
    val locationClassResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()

    var toteDetails: PRToteResponse? = null
    var toteNumberList: ArrayList<String> = ArrayList()
    var isKitStaging = false
    fun getPRToteDetails(toteNumber: String) = viewModelScope.launch {
        toteResponse.postValue(Resource.Loading())
        val response = prToteToPackStationRepository.getPRToteDetails(toteNumber)
        toteResponse.postValue(handleToteDetailsResponse(response))
    }

    private fun handleToteDetailsResponse(response: Response<PRToteResponse>): Resource<PRToteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getTaskPickResponse Success: $resultResponse")
                toteDetails = resultResponse
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getTaskPick Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getKitPRToteDetails(toteNumber: String, workOrderNbr: String) = viewModelScope.launch {
        kitToteResponse.postValue(Resource.Loading())
        val response = prToteToPackStationRepository.getKitPRToteDetails(toteNumber, workOrderNbr)
        kitToteResponse.postValue(handleToteDetailsResponse(response))
    }


    fun updateToPackStation(prToteStageReq: PRToteStageReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickEndCart Request: $prToteStageReq")
        toteStageResponse.postValue(Resource.Loading())
        val response: Response<PickingSerialResponse> = if (!isKitStaging) {
            prToteToPackStationRepository.updatePRLocToPackStation(prToteStageReq)
        } else {
            prToteStageReq.allocationType = "12"
            prToteToPackStationRepository.updatePRLocToKitStaging(prToteStageReq)
        }
        toteStageResponse.postValue(handlePackStationStagingResponse(response))
    }

    private fun handlePackStationStagingResponse(response: Response<PickingSerialResponse>): Resource<PickingSerialResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickEndCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "pickEndCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateStagingLocation Request: $locationClassReq")
        locationClassResponse.postValue(Resource.Loading())
        val response = prToteToPackStationRepository.validateStagingLocation(locationClassReq)
        locationClassResponse.postValue(handleLocationClassResponse(response))
    }

    private fun handleLocationClassResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun saveToteNumber() {
        toteNumberList.add(toteDetails!!.toteNumber!!)
    }

    fun getToteNumbersList(): ArrayList<String> {
        return toteNumberList
    }

    fun resetToteNumbersList() {
        toteNumberList.clear()
    }

    fun removeUncheckedTotes(checkedTotes: ArrayList<String>) {
        toteNumberList.removeAll(checkedTotes)
    }
}