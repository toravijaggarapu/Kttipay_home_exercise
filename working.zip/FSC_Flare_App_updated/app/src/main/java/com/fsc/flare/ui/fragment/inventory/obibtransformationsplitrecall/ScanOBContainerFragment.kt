package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanObContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private val TAG = ScanOBContainerFragment::class.java.simpleName.toString()
/**
 *  [ScanOBContainerFragment] class.
 */
@AndroidEntryPoint
class ScanOBContainerFragment : BaseFragment(), FlareScannable {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentScanObContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etObContainer.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etObContainer)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentScanObContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etObContainer.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etObContainer.isFocused && !binding.etObContainer.text.isNullOrEmpty()) {
                        validateOBContainer()
                    } else {
                        binding.tvObContainerResponse.text = getString(R.string.lbl_input_required)
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etObContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etObContainer)
                if (binding.etObContainer.isFocused && !binding.etObContainer.text.isNullOrEmpty()) {
                    validateOBContainer()
                } else {
                    binding.tvObContainerResponse.text = getString(R.string.lbl_input_required)
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etObContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvObContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate OB Container
     */
    private fun validateOBContainer() {
        val obContainerNumber = binding.etObContainer.text.toString().trim()
        viewModel.obCartonDetailsRequest(obContainerNumber = obContainerNumber)
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeOBContainerResponse()
    }

    /**
     * Function to observe OB Container Response
     */
    private fun observeOBContainerResponse() {
        viewModel.obContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObContainerSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObContainerErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle OB Container error response
     */
    private fun handleObContainerErrorResponse(message: String?) {
        message?.let {
            with(binding) {
                tvObContainerResponse.text = message
                etObContainer.requestFocus()
                etObContainer.selectAll()
                showSoftKeyBoard(requireContext(), etObContainer)
            }
        }
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleObContainerSuccessResponse(response: ValidateCartonHandlerTypeResponse?) {
        response?.containerDetails?.let { obCartonDetails ->
            sharedViewModel.obCartonDetails = obCartonDetails.first()
            when (obCartonDetails.first().eligibleAction) {
                OBIBTransformations.SPLIT.type -> {
                    navigateToBlindIBContainerFragment()
                }
                OBIBTransformations.TRANSFORM.type -> {
                    navigateToTransformFragment()
                }
                OBIBTransformations.HYBRID.type -> {
                    displaySplitTransformDialog()
                }
            }
        }
    }

    /**
     * Nav Handler to OB to IB Transform fragment
     */
    private fun navigateToTransformFragment() {
        binding.etObContainer.text = null
        val action = ScanOBContainerFragmentDirections.actionScanObContainerFragmentToObIbContainerTransformFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to display selection of SPLIT/TRANSFORM workflow dialog
     */
    private fun displaySplitTransformDialog() {
        val obContainerNumber = binding.etObContainer.text.toString().trim()
        val dialog = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setMessage(getString(R.string.lbl_ob_ib_hybrid_dialog_title, obContainerNumber))
            .setPositiveButton(OBIBTransformations.TRANSFORM.type) { dialog, _ ->
                dialog.dismiss()
                navigateToTransformFragment()
            }
            .setNeutralButton(OBIBTransformations.SPLIT.type) { dialog, _ ->
                dialog.dismiss()
                navigateToBlindIBContainerFragment()
            }
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            val neutralButton = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            val primaryDarkColor = ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark)
            val whiteColor = ContextCompat.getColor(requireContext(), R.color.white)

            neutralButton.apply {
                setBackgroundColor(primaryDarkColor)
                setTextColor(whiteColor)
            }
        }

        dialog.show()
    }

    /**
     * Nav Handler to Blind IB Container fragment
     */
    private fun navigateToBlindIBContainerFragment() {
        binding.etObContainer.text = null
        val action = ScanOBContainerFragmentDirections.actionScanObContainerFragmentToScanBlindIbContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etObContainer.setText(scan?.barcode.toString())
        binding.etObContainer.text?.length?.let {
            binding.etObContainer.setSelection(it)
            validateOBContainer()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}