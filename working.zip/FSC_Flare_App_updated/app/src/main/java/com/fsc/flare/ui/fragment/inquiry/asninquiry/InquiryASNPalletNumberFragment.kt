package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryAsnPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPalletInquiryRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryASNPalletNumberFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [InquiryASNPalletNumberFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InquiryASNPalletNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryAsnPalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)

    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquiryAsnPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etPalletNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                FlareLog.i(TAG, "Pallet Number field focused")
                getPalletDetails()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etPalletNumber.isFocused && !binding.etPalletNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Pallet Number field focused")
                        getPalletDetails()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvPalletResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to get Pallet details from API
     */
    private fun getPalletDetails() {
        viewModel.getPalletDetails(
            ASNPalletInquiryRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                container = binding.etPalletNumber.text.toString()
            )
        )
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribePalletObserver()
    }

    /**
     * method to subscribe Pallet observer
     */
    private fun subscribePalletObserver() {
        viewModel.palletDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletDetailsResponse ->
                        // Check the response have pallet details or not. If have then save the details and move to next screen
                        if (palletDetailsResponse.palletInquiry != null) {
                            viewModel.setPalletDetails(palletDetailsResponse.palletInquiry)
                            val action =
                                InquiryASNPalletNumberFragmentDirections.actionInquiryAsnPalletNumberFragmentToInquiryAsnDetailsFragment()
                            getNavigationController().navigate(action)
                        } else {
                            showErrorSnackBar(resources.getString(R.string.pallet_details_not_available))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvPalletResponse.text = message
                        binding.etPalletNumber.requestFocus()
                        binding.etPalletNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.onVisibilityChange(true)
        cb1 = cb!!
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etPalletNumber.setText(scan?.barcode.toString())
                binding.etPalletNumber.text?.length?.let {
                    binding.etPalletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Pallet Number field focused")
                    getPalletDetails()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}