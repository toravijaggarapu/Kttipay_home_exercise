package com.fsc.flare.ui.fragment.inventory.ibpalletadjustment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletLockAdjustmentDetailBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletLockUnlockAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.inventory.PalletLockRequest
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.Constants.LockCodes.FIRST_ARTICLE_INSPECTION
import com.fsc.flare.utils.Constants.LockCodes.INCUBATION_HOLD
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletLockAdjustmentDetailsFragment"
private const val LOCK_ALREADY_EXISTS = "LOCK_ALREADY_EXISTS"

private const val MIXED = "Mixed"

/**
 * A simple [PalletLockAdjustmentDetailsFragment] class.
 */
@AndroidEntryPoint
class PalletLockAdjustmentDetailsFragment : BaseFragment(){

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    lateinit var viewModel: InventoryViewModel
    private lateinit var binding: FragmentPalletLockAdjustmentDetailBinding
    private lateinit var lockObj : InventoryLockcode

    private var lockUnlockDropDownList = ArrayList<String>()
    private var lockCodeHashMap = HashMap<String, InventoryLockcode>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Call the API to get the general configured lock list's.
        viewModel.getInventoryLockcodes(
            InventoryLockcodeRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            )
        )
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletLockAdjustmentDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvIbPalletAdjHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val palletData = viewModel.getPalletResponse()

        binding.tvPalletNumberValue.text = palletData.container
        binding.tvCurrentLocationValue.text = palletData.currentLocNumber
        binding.tvNumberOfCaseValue.text = palletData.noOfCases.toString()
        binding.tvTotalPalletQtyValue.text = palletData.qty.toString()
        binding.tvInvTypeValue.text = getInventoryDescription(palletData.inventoryType)

        if (viewModel.isItemMixed()) {
            binding.tvItemCodeValue.text = MIXED
        }else{
            binding.tvItemCodeValue.text = palletData.item
        }
        if(viewModel.isItemDescMixed()){
            binding.tvItemDescValue.text = MIXED
        }else{
            binding.tvItemDescValue.text = palletData.itemDesc
        }


        if (viewModel.isShowItemAttributes()) {

            if(!palletData.lotNumber.isNullOrEmpty()){
                binding.tvLot.visibility = View.VISIBLE
                binding.tvLotValue.visibility = View.VISIBLE
                binding.tvLotValue.text = palletData.lotNumber
            }
            if(!palletData.expiryDate.isNullOrEmpty()){
                binding.tvExpDate.visibility = View.VISIBLE
                binding.tvExpDateValue.visibility = View.VISIBLE
                binding.tvExpDateValue.text = palletData.expiryDate
            }
            if(!palletData.manufacturedDate.isNullOrEmpty()){
                binding.tvMfgDate.visibility = View.VISIBLE
                binding.tvMfgDateValue.visibility = View.VISIBLE
                binding.tvMfgDateValue.text = palletData.manufacturedDate
            }
            if(!palletData.coo.isNullOrEmpty()){
                binding.tvCoo.visibility = View.VISIBLE
                binding.tvCooValue.visibility = View.VISIBLE
                binding.tvCooValue.text = palletData.coo
            }

            binding.tvCooValue.text = palletData.coo
            if(viewModel.isLotMixed()){
                binding.tvLotValue.text = MIXED
            }else{
                binding.tvLotValue.text = palletData.lotNumber
            }
            if(viewModel.isExpDateMixed()){
                binding.tvExpDateValue.text = MIXED
            }else{
                binding.tvExpDateValue.text = palletData.expiryDate
            }
            if(viewModel.isMfgDateMixed()){
                binding.tvMfgDateValue.text = MIXED
            }else{
                binding.tvMfgDateValue.text = palletData.manufacturedDate
            }
        } else {
            binding.displayItemLayout.visibility = View.GONE
        }

        //Button click listener
        binding.btnConfirm.setOnClickListener {
            confirmApiCall()
        }

        //Observers
        subscribeObservers()
    }

    private fun subscribeObservers(){
        //For Drop down spinner list.
        binding.lockCodeDropDown.boolFoo.observe(viewLifecycleOwner, fun(updatedItem: String) {
            if (updatedItem != "Select Lock Code") {
                lockObj = lockCodeHashMap[updatedItem]!!
                enableConfirmButton(true)
            }
        })

        //General configured lock codes.
        viewModel.inventoryLockcodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lockCodeRes ->
                        FlareLog.i(TAG, "lockCodeResponse success: $lockCodeRes")
                        if (lockCodeRes.lockCodes != null && lockCodeRes.lockCodes.isNotEmpty()) {
                            lockUnlockDropDownList.clear()
                            lockCodeRes.lockCodes.forEach {
                                if (it.code != INCUBATION_HOLD && it.code != FIRST_ARTICLE_INSPECTION) {
                                    lockUnlockDropDownList.add(it.description)
                                }
                                lockCodeHashMap[it.description] = it
                            }
                            binding.lockCodeDropDown.setOptions(lockUnlockDropDownList)
                        } else {
                            showErrorSnackBar(resources.getString(R.string.lockcodes_not_available))
                        }

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lockCodeResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //Inventory confirm click response
        viewModel.inventoryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let {
                        if (it.locksMessage != null && it.locksMessage.isNotEmpty() && it.locksMessage[0].message != null){
                                isLockExist = it.messageCode!=null && it.messageCode == LOCK_ALREADY_EXISTS
                                showAlertDialog("", it.locksMessage[0].message!!, onDialogYesClicked) }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    enableConfirmButton(true)
                    if(response.message!=null){
                        showErrorSnackBar(response.message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun enableConfirmButton(isEnable: Boolean) {
        binding.btnConfirm.isEnabled = isEnable
    }

    private fun confirmApiCall(){
        enableConfirmButton(false)
        val palletData = viewModel.getPalletResponse()
        viewModel.inventoryIbPalletLockUnlockAdjustment(
            InventoryIbPalletLockUnlockAdjustmentRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                containerId = palletData.containerId,
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                containerType = palletData.containerType,
                invMasterId = 0, // For pallets we need to give this as 0
                qtyUom = "EA",// For pallets qtyUom could be EA
                locks = getLockCodeList()
            )
        )
    }

    private fun getLockCodeList():List<PalletLockRequest>{
        //Y-> MEANS REMOVING THE LOCK
        //N -> MEANS CREATE NEW LOCK
        val lockCodesList = mutableListOf<PalletLockRequest>()
        lockCodesList.add(PalletLockRequest(lockObj.code!!,lockObj.lockCodeId!!.toString(), "N"))
        return lockCodesList
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    var isLockExist = false
    // Callback from dialog positive button
    private val onDialogYesClicked = {
        if(!isLockExist){
            val action =
                PalletLockAdjustmentDetailsFragmentDirections.actionPalletLockAdjustmentDetailFragmentToPalletLockAdjustmentFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.palletLockAdjustmentFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }
    }
}

