package com.fsc.flare.ui.fragment.physicalInventory

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanLocationBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "ScanLocationFragment"

@AndroidEntryPoint
class ScanLocationFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentScanLocationBinding
    private lateinit var taskData: BatchTaskDetailsResp
    lateinit var cb1: CustomVisibilityCallback

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentScanLocationBinding.inflate(inflater, container, false)
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType ?: ""
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType.plus( " - " ).plus(taskData.batchNumber)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleTouchEvent()
        handleEnterKeyEvent()
        binding.scanLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun updateDataOnScreen() {
        binding.countType.text =
            sharedPreferencesBase.getString(PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, "")
        binding.location.text = taskData.locationBarCode
    }

    private fun handleEnterKeyEvent() {
        binding.scanLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                validateLocation()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.scanLocation.isFocused && !binding.scanLocation.text.isNullOrEmpty()) {
                            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                            validateLocation()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateLocation() {
        if (binding.scanLocation.text.toString().trim() == taskData.locationBarCode) {
            resetData()
            navigateToNextScreen()
        } else {
            binding.errResponse.text = getString(R.string.lbl_invalid_location)
            binding.scanLocation.selectAll()
        }
    }

    private fun resetData() {
        viewModel.selectedItem = null
        viewModel.scannedItemListIds = mutableListOf()
        viewModel.itemDetails = mutableListOf()
        viewModel.selectedItemDetails = null
        viewModel.isGivingCountSecondTime = false
        viewModel.scannedItemListIds = mutableListOf()
        viewModel.containersList.clear()
    }

    private fun navigateToNextScreen() {
        if (taskData.locationClass == "A" || taskData.locationClass == "KT") {
            val action = ScanLocationFragmentDirections.actionScanLocationFragmentToScanItemFragment()
            getNavigationController().navigate(action)
        } else {
            val action = ScanLocationFragmentDirections.actionScanLocationFragmentToNoOfContainersFragment()
            getNavigationController().navigate(action)
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.scanLocation.setText(scan?.barcode.toString())
        binding.scanLocation.text?.length?.let {
            binding.scanLocation.setSelection(it)
        }
        FlareLog.i(TAG, "ScanLocation field focused")
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        validateLocation()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}