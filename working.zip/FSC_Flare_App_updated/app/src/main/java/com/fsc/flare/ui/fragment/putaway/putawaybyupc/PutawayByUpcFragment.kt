package com.fsc.flare.ui.fragment.putaway.putawaybyupc

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPutawayByUpcBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.ResponseCode
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.PutawayResponse
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.UpcItemSlpData
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textview.MaterialTextView
import dagger.hilt.android.AndroidEntryPoint

private val TAG = PutawayByUpcFragment::class.java.simpleName.toString()

/**
 * A simple PutawayByUpcFragment class.
 */
@AndroidEntryPoint
class PutawayByUpcFragment : BaseFragment(), FlareScannable {

    private val viewModel: PutawayByUpcViewModel by activityViewModels()
    private lateinit var binding: FragmentPutawayByUpcBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPutawayByUpcBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPutaway.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etUpc.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to handle touch and focus events
     */
    private fun handleTouchAndFocusEvents() {
        handleRootLayoutTouchAndFocusEvents()
        handleUPCTouchAndFocusEvents()
        handleToContainerTouchAndFocusEvents()
    }

    /**
     * Function to handle root layout touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleRootLayoutTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            if (event?.action == MotionEvent.ACTION_DOWN) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)

                val upcText = binding.etUpc.text.toString()
                val containerIdText = binding.etContainerId.text.toString()
                val locationIdText = binding.etLocationId.text.toString()

                when {
                    binding.etUpc.isFocused && upcText.isNotEmpty() -> {
                        validateUpc()
                    }

                    binding.etContainerId.isFocused && upcText.isNotEmpty() && containerIdText.isNotEmpty() -> {
                        validateToContainer()
                    }

                    upcText.isNotEmpty() && containerIdText.isNotEmpty() && locationIdText.isNotEmpty() -> processPutaway()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    /**
     * Function to handle UPC touch and focus events
     */
    private fun handleUPCTouchAndFocusEvents() {
        binding.etUpc.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                hideSoftKeyBoard(fragmentContext, binding.etUpc)
                if(binding.etUpc.isFocused && !binding.etUpc.text.isNullOrEmpty()) {
                    validateUpc()
                } else {
                    binding.upcResponse.text = getString(R.string.please_enter_upc_code_and_try_again)
                }
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }

        binding.etUpc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.upcResponse.text = null
                binding.etContainerId.text = null
                binding.etQuantity.text = null
                binding.etLocationId.text = null
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    /**
     * Function to handle container touch and focus events
     */
    private fun handleToContainerTouchAndFocusEvents() {
        binding.etContainerId.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                hideSoftKeyBoard(fragmentContext, binding.etContainerId)
                if (binding.etContainerId.isFocused && !binding.etUpc.text.isNullOrEmpty() && !binding.etContainerId.text.isNullOrEmpty()) {
                    validateToContainer()
                } else {
                    binding.containerIdResponse.text = getString(R.string.please_enter_to_container_and_try_again)
                }
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }

        binding.etContainerId.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerIdResponse.text = null
                binding.etQuantity.text = null
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    /**
     * Function to validate upc
     */
    private fun validateUpc() {
        viewModel.validateUpcRequest(
            upcText = binding.etUpc.text.toString()
        )
    }

    /**
     * Function to validate ToContainer
     */
    private fun validateToContainer() {
        viewModel.validateContainerRequest(
            containerText = binding.etContainerId.text.toString()
        )
    }

    /**
     * Function to process putaway
     */
    private fun processPutaway() {
        viewModel.validatePutawayRequest(
            upcText = binding.etUpc.text.toString(),
            containerText = binding.etContainerId.text.toString(),
            locationText = binding.etLocationId.text.toString()
        )
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeValidateUpcResponse()
        observeContainerResponse()
        observeProcessPutawayResponse()
    }

    /**
     * Function to observe Upc response
     */
    private fun observeValidateUpcResponse() {
        viewModel.validateupcresponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleSuccessResponse(response.data)
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { binding.upcResponse.text = it }
                }
            }
        }
    }

    /**
     * Function to handle upc success response
     */
    private fun handleSuccessResponse(data: ValidateUpcResponse?) {
        hideProgressBar()
        data?.let { validateUpcResponse ->
            when (validateUpcResponse.statusHandler.statusCode) {
                ResponseCode.SUCCESS.value -> handleValidUpcResponse(validateUpcResponse.putaway)
                ResponseCode.FAILURE.value -> {
                    binding.etUpc.selectAll()
                    setErrorText(binding.upcResponse, validateUpcResponse.statusHandler.message)
                    showSoftKeyBoard(fragmentContext, binding.etUpc)
                }

                else -> setErrorText(binding.upcResponse, validateUpcResponse.statusHandler.message)
            }
        }
    }

    /**
     * Function to handle upc response object
     */
    private fun handleValidUpcResponse(putawayResponse: PutawayResponse) {
        val upcItemsSlpDataList = putawayResponse.upcItemSlpData
        val distinctUpcItemsSlpDataList = upcItemsSlpDataList.distinctBy { it.group }
        when {
            distinctUpcItemsSlpDataList.isNotEmpty() -> {
                when {
                    distinctUpcItemsSlpDataList.size > 1 -> displayUpcItemsSlpDataDialog(upcItemsSlpDataList, putawayResponse)
                    else -> {
                        viewModel.selectedItem = upcItemsSlpDataList[0]
                        binding.etLocationId.setText(putawayResponse.locId)
                        binding.etContainerId.requestFocus()
                    }
                }
            }
        }
    }

    /**
     * Function to observe Container response
     */
    private fun observeContainerResponse() {
        viewModel.validatecontainerresponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateContainerResponse ->
                        when (validateContainerResponse.statusHandler.statusCode) {
                            ResponseCode.SUCCESS.value -> {
                                if (validateContainerResponse.putaway != null) {
                                    if (validateContainerResponse.putaway.locId.isNotEmpty()) {
                                        if(binding.etLocationId.text.toString() == validateContainerResponse.putaway.locId)
                                        {
                                            binding.etLocationId.setText(validateContainerResponse.putaway.locId)
                                            binding.etQuantity.setText("${validateContainerResponse.putaway.cntQty}")
                                            processPutaway()
                                        }else
                                        {
                                            showErrorSnackBar(getString(R.string.container_is_from_different_location),false)
                                        }
                                    } else {
                                        setErrorText(binding.containerIdResponse, validateContainerResponse.statusHandler.message)
                                        binding.etContainerId.requestFocus()
                                    }
                                } else {
                                    processPutaway()
                                }
                            }

                            ResponseCode.FAILURE.value -> {
                                binding.etContainerId.selectAll()
                                setErrorText(binding.containerIdResponse, validateContainerResponse.statusHandler.message)
                                showSoftKeyBoard(fragmentContext, binding.etContainerId)
                            }

                            else -> {
                                setErrorText(binding.containerIdResponse, validateContainerResponse.statusHandler.message)
                            }
                        }
                    }
                }

                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.etContainerId.selectAll()
                        setErrorText(binding.containerIdResponse, message)
                        showSoftKeyBoard(fragmentContext, binding.etContainerId)
                    }
                }
            }
        }
    }

    /**
     * Function to observe putaway response
     */
    private fun observeProcessPutawayResponse() {
        viewModel.validateputawayresponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { doPutawayResponse ->
                        when (doPutawayResponse.statusHandler.statusCode) {
                            ResponseCode.SUCCESS.value -> {
                                showSuccessSnackBarStd(doPutawayResponse.statusHandler.message) {
                                    getNavigationController().navigate(R.id.action_putAwayByUpcFragment_to_putAwayByUpcFragment)
                                }
                            }

                            ResponseCode.FAILURE.value -> {
                                showErrorSnackBar(doPutawayResponse.statusHandler.message)
                                binding.etLocationId.requestFocus()
                            }

                            else -> {
                                showErrorSnackBar(doPutawayResponse.statusHandler.message)
                            }
                        }
                    }
                }

                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    /**
     * Function to set error text on any MaterialTextView
     */
    private fun setErrorText(view: MaterialTextView, text: String) {
        view.text = text
    }

    /**
     * Function to display UpcItemsSlpDataDialog
     */
    private fun displayUpcItemsSlpDataDialog(
        upcItemsSlpDataList: List<UpcItemSlpData>,
        putawayResponse: PutawayResponse
    ) {
        val inflater = LayoutInflater.from(requireContext())
        val headerView = inflater.inflate(R.layout.header_layout, null)

        val adapter = CustomAdapter(requireContext(), upcItemsSlpDataList) { selectedItem ->
            // Handle the selected item
            FlareLog.i(TAG, selectedItem.group)
        }

        val recyclerView = RecyclerView(requireContext()).apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        val dialogLayout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            addView(headerView)
            addView(recyclerView)
        }

        MaterialAlertDialogBuilder(requireContext(), R.style.AlertDialogTheme)
            .setView(dialogLayout)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                // Handle OK button click
                val selectedItem = adapter.selectedItem
                selectedItem?.let {
                    FlareLog.i(TAG, it.group)
                    viewModel.selectedItem = it
                    binding.etLocationId.setText(putawayResponse.locId)
                    binding.etContainerId.requestFocus()
                    dialog.dismiss()
                }
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        scan?.let {
            val scannedBarcode = it.barcode
            when {
                binding.etUpc.isFocused -> {
                    binding.etUpc.setText(scannedBarcode)
                    validateUpc()
                }

                binding.etContainerId.isFocused -> {
                    binding.etContainerId.setText(scannedBarcode)
                    validateToContainer()
                }
            }
        }
    }
}