package com.fsc.flare.ui.fragment.physicalInventory

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.google.android.material.textview.MaterialTextView

class ScannedContainersAdapter(
    private var containersList: MutableList<String>
) : RecyclerView.Adapter<ScannedContainersAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_containers, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvContainerNumber.text = containersList[position]
    }

    override fun getItemCount(): Int {
        return containersList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvContainerNumber: MaterialTextView = itemView.findViewById(R.id.tvContainer)
    }
}