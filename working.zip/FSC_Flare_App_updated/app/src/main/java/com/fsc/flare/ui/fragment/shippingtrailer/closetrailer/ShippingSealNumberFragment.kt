package com.fsc.flare.ui.fragment.shippingtrailer.closetrailer

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentShippingSealNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerRequest
import com.fsc.flare.ui.fragment.shippingtrailer.ShippingTrailerViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ShippingSealNumberFragment"

/**
 * [ShippingSealNumberFragment] class.
 */
@AndroidEntryPoint
class ShippingSealNumberFragment : BaseFragment(), FlareScannable {

    private val RECALL_CLOSE_TRAILER_ERROR_CODE = "ERR-CT-RC-01"

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ShippingTrailerViewModel by activityViewModels()
    private lateinit var binding: FragmentShippingSealNumberBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentShippingSealNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.sealEt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.sealResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.closeTrailerResponse.observe(viewLifecycleOwner) { closeTrailerResponse ->
            when (closeTrailerResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "closeTrailerResponse success: $closeTrailerResponse")
                    hideProgressBar()
                    closeTrailerResponse.data?.let { response ->
                        showSuccessSnackBarStd(response.message) {
                            val action =
                                ShippingSealNumberFragmentDirections.actionShippingSealNumberFragmentToShippingDockDoorFragment()
                            val navOptions =
                                NavOptions.Builder().setPopUpTo(R.id.shippingDockDoorFragment, true)
                                    .build()
                            getNavigationController().navigate(action, navOptions)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    closeTrailerResponse.message?.let { message ->
                        FlareLog.e(TAG, "closeTrailerResponse error: $message")
                        handleCloseTrailerErrorResponse(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        observeRecallContainersResponse()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (binding.sealEt.isFocused && !binding.sealEt.text.isNullOrEmpty()) {
                        hideSoftKeyBoard(fragmentContext, binding.sealEt)
                        val data = viewModel.getDockDoorShipment()
                        if (data != null) {
                            viewModel.closeTrailer(
                                CloseTrailerRequest(
                                    binding.sealEt.text.toString(),
                                    data.shipmentId
                                )
                            )
                        }
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.sealEt.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.sealEt)
                FlareLog.i(TAG, "sealEt field focused")
                val data = viewModel.getDockDoorShipment()
                if (data != null) {
                    viewModel.closeTrailer(
                        CloseTrailerRequest(
                            binding.sealEt.text.toString(),
                            data.shipmentId
                        )
                    )
                }
            }
            false
        }
        val data = viewModel.getDockDoorShipment()
        if (data != null) {
            binding.shipment.text = data.shipmentNumber
            binding.trailer.text = data.trailerNbr
            binding.dockdoor.text = sharedPreferences.getString(PreferenceKeys.Shipping.DD_NUMBER, "")
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            sharedPreferences.edit().putString(PreferenceKeys.Item.DD_NUMBER, scan?.barcode.toString()).apply()
            binding.sealEt.setText(scan?.barcode.toString())
            binding.sealEt.text?.length?.let {
                binding.sealEt.setSelection(
                    it
                )
            }
            val data = viewModel.getDockDoorShipment()
            if (data != null) {
                viewModel.closeTrailer(
                    CloseTrailerRequest(
                        binding.sealEt.text.toString(),
                        data.shipmentId
                    )
                )
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun handleCloseTrailerErrorResponse(msg: String) {
        val errorMessage = msg.split("##")
        val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
        when {
            errorMessage[0].equals(RECALL_CLOSE_TRAILER_ERROR_CODE, ignoreCase = true) -> {
                displayRecallContainers(responseMessage)
            }
            else -> {
                binding.sealResponse.text = responseMessage
            }
        }
    }

    private fun displayRecallContainers(errorMessage: String) {
        showAlertDialog("",errorMessage,getString(R.string.alert_button_ok), onPositiveClick = {
            dialog: DialogInterface -> dialog.dismiss()

        },getString(R.string.lbl_view_recall_pallets), onNegativeClick = {
                dialog: DialogInterface -> dialog.dismiss()
                val dockDoorId = viewModel.dockDoorResponse.value?.data?.location?.locationId?:0
                if(dockDoorId > 0) {
                    viewModel.viewRecallContainersAPIRequest(dockDoorId)
                }
        })
    }

    /**
     * Function to observe Recall Containers Api response
     */
    private fun observeRecallContainersResponse() {
        viewModel.obCartonRCLockResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObCartonRCLockSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObCartonRCLockErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Recall Containers success response
     */
    private fun handleObCartonRCLockSuccessResponse(data: OBCartonRCLockResponse?) {
        data?.containers?.let { containers ->
            displayRecallContainersDialog(containers)
        }
    }

    /**
     * Function to handle Recall Containers error response
     */
    private fun handleObCartonRCLockErrorResponse(message: String?) {
        message?.let { errorMessage -> binding.sealResponse.text = errorMessage }
    }

    /**
     * Function to display Recall Containers dialog
     */
    private fun displayRecallContainersDialog(containers: List<Container>) {
       showAlertDialog(getString(R.string.lbl_recalled_pallets),containers.map { it.containerNumber }.toTypedArray(),getString(R.string.alert_dialog_close_btn))
    }
}