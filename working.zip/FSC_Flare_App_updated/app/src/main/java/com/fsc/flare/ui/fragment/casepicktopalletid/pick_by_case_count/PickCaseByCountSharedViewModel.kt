package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.taskgroup.GroupTask

class PickCaseByCountSharedViewModel : ViewModel() {

    var palletInfo: PalletInformation? = null
    var groupTask: GroupTask? = null

    fun pickLocationBarCode() = groupTask?.pickLocBarcode.orEmpty()

    fun clearData() {
        palletInfo = null
        groupTask = null
    }
}

data class PalletInformation(
    val palletNumber: String,
    val cartNumber: String,
    val cartId: Int,
)

fun TaskPickResponse.toPalletInformation() = PalletInformation(
    palletNumber = this.cartNbr.orEmpty(),
    cartNumber = this.cartNbr.orEmpty(),
    cartId = this.cartId
)
