package com.fsc.flare.ui.fragment.replenish.rewarehouse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRewarehouseSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.rewarehouse.ContainerDetailsRequest
import com.fsc.flare.source.data.dto.rewarehouse.RewareHouseSbNumberRequest
import com.fsc.flare.source.data.dto.rewarehouse.RewareMovesRequest
import com.fsc.flare.source.data.dto.rewarehouse.RewareSubmitRequestBody
import com.fsc.flare.source.data.dto.rewarehouse.SubmitParams
import com.fsc.flare.source.data.dto.rewarehouse.SubmitRewarehouseRequest
import com.fsc.flare.source.data.dto.rewarehouse.Update
import com.fsc.flare.source.data.dto.rewarehouse.ValidateFromLocRequest
import com.fsc.flare.source.data.dto.rewarehouse.ValidateToContainerRequest
import com.fsc.flare.source.data.dto.rewarehouse.ValidateToLocationRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "RewarehouseSerial"

/**
 * A simple [RewarehouseSerialFragment] class.
 */
@AndroidEntryPoint
class RewarehouseSerialFragment : BaseFragment(), FlareScannable {

    private val viewModel: RewarehouseViewModel by activityViewModels()
    private lateinit var binding: FragmentRewarehouseSerialBinding
    private var isContValidated: Boolean = false

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun validateFields() {
        if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "serialNumber field focused")
            validateSerialNumber()
        } else if (binding.etFromContainer.isFocused && !binding.etFromContainer.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "fromContainer field focused")
            validateFromContainer()
        } else if (binding.etToLocation.isFocused && !binding.etToLocation.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "toLocation field focused")
            validateToLocation()
        } else if (binding.etFromLocation.isFocused && !binding.etFromLocation.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "fromLocation field focused")
            validateFromLocation()
        } else if (binding.etSbNumber.isFocused && !binding.etSbNumber.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "SBNumber field focused")
            validateSbNumber()
        } else if (binding.etToCont.isFocused && !binding.etToCont.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "toContainer field focused")
            validateToContainer()
        } else if (binding.etToCont.isFocused && binding.etToCont.text.isNullOrEmpty()) {
            if(binding.grpWeight.visibility == View.VISIBLE)
            {
                binding.etWeight.text?.length?.let {
                    binding.etWeight.setSelection(it)
                }
                binding.etWeight.requestFocus()
                enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = true)
            }
            else
            {
                validateRewarehouseSubmit()
            }
        } else {
            FlareLog.i(TAG, "Rewarehouse submit called")
            validateRewarehouseSubmit()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateFields()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etSerialNumberResponse.text = null
                binding.etFromContainer.text = null
                binding.etFromLocation.text = null
                binding.etSbNumber.text = null
                binding.etWeight.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etFromContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etFromContainerResponse.text = null
                binding.etFromLocationResponse.text = null
                binding.txtToLocationResponse.text = null
                binding.txtSbNumberResponse.text = null
                binding.txttoContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etFromLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etFromContainerResponse.text = null
                binding.etFromLocationResponse.text = null
                binding.txtToLocationResponse.text = null
                binding.txtSbNumberResponse.text = null
                binding.txttoContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        binding.etToLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etFromContainerResponse.text = null
                binding.etFromLocationResponse.text = null
                binding.txtToLocationResponse.text = null
                binding.txtSbNumberResponse.text = null
                binding.txttoContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etSbNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etFromContainerResponse.text = null
                binding.etFromLocationResponse.text = null
                binding.txtToLocationResponse.text = null
                binding.txtSbNumberResponse.text = null
                binding.txttoContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etToCont.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etFromContainerResponse.text = null
                binding.etFromLocationResponse.text = null
                binding.txtToLocationResponse.text = null
                binding.txtSbNumberResponse.text = null
                binding.txttoContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etToCont.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etToCont)
                validateFields()
            }
            false
        }
        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                validateFields()
            }
            false
        }
        binding.etFromContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etFromContainer)
                validateFields()
            }
            false
        }
        binding.etFromLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etFromLocation)
                validateFields()
            }
            false
        }
        binding.etToLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etToLocation)
                validateFields()
            }
            false
        }
        binding.etSbNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSbNumber)
                validateFields()
            }
            false
        }


    }

    private fun subscribeObservers() {
        viewModel.rewareHouseSerialRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { rewarehouseSerialRes ->
                        FlareLog.i(TAG, "rewarehouseSerialRes : ${response.data}")
                        if (rewarehouseSerialRes != null) {
                            when (rewarehouseSerialRes.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "rewarehouseSerialRes error : ${rewarehouseSerialRes.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                                    binding.etSerialNumber.selectAll()
                                    binding.etSerialNumberResponse.text = rewarehouseSerialRes.statusHandler.error
                                    enableDisableText(fromCont = false, fromLoc = false, sbNum = false, toLoc = false, toCont = false, wt = false)
                                }
                                "200" -> {
                                    FlareLog.i(TAG, "rewarehouseSerialRes success : $rewarehouseSerialRes")
                                    binding.etSerialNumber.setText(rewarehouseSerialRes.serial)
                                    binding.etFromContainer.setText(rewarehouseSerialRes.fromCont)
                                    binding.etFromLocation.setText(rewarehouseSerialRes.fromLoc)
                                    binding.etSbNumber.setText(rewarehouseSerialRes.sbNum)
                                    binding.etWeight.setText(rewarehouseSerialRes.weight)

                                    if (rewarehouseSerialRes.showToCnt != null && rewarehouseSerialRes.showToCnt == "Y") {
                                        binding.grpToCont.visibility = View.VISIBLE
                                    }

                                    if (rewarehouseSerialRes.showWeight != null && rewarehouseSerialRes.showWeight == "Y") {
                                        binding.grpWeight.visibility = View.VISIBLE
                                        binding.etWeight.setText(rewarehouseSerialRes.weight)
                                    }
                                    enableDisableText(fromCont = false, fromLoc = false, sbNum = false, toLoc = true, toCont = false, wt = false)
                                    binding.etToLocation.requestFocus()
                                }
                                else -> binding.etSerialNumber.requestFocus()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.containerDetailsRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { containerResponse ->
                        FlareLog.i(TAG, "containerDetailsRes : ${response.data}")
                        if (containerResponse != null) {
                            when (containerResponse.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "containerDetailsRes error : ${containerResponse.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etFromContainer)
                                    binding.etFromContainer.selectAll()
                                    binding.etFromContainerResponse.text = containerResponse.statusHandler.error
                                    enableDisableText(fromCont = true, fromLoc = false, sbNum = false, toLoc = false, toCont = false, wt = false)
                                }
                                "200" -> {
                                    FlareLog.i(TAG, "containerDetailsRes success: $containerResponse")
                                    if (containerResponse.showToCnt != null && containerResponse.showToCnt == "Y") {
                                        binding.grpToCont.visibility = View.VISIBLE
                                    }
                                    if (containerResponse.showWeight != null && containerResponse.showWeight == "Y") {
                                        binding.grpWeight.visibility = View.VISIBLE
                                        binding.etWeight.setText(containerResponse.weight)
                                    }
                                    binding.etFromLocation.setText(containerResponse.fromLoc)
                                    binding.etSbNumber.setText(containerResponse.sbNum)
                                    when {
                                        binding.etFromLocation.text.isNullOrEmpty() -> {
                                            enableDisableText(
                                                fromCont = true,
                                                fromLoc = true,
                                                sbNum = false,
                                                toLoc = false,
                                                toCont = false,
                                                wt = false
                                            )
                                            binding.etFromLocation.requestFocus()
                                        }
                                        binding.etSbNumber.text.isNullOrEmpty() -> {
                                            enableDisableText(
                                                fromCont = true,
                                                fromLoc = true,
                                                sbNum = true,
                                                toLoc = false,
                                                toCont = false,
                                                wt = false
                                            )
                                            binding.etSbNumber.requestFocus()
                                        }
                                        else -> {
                                            enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = false, wt = false)
                                            binding.etToLocation.requestFocus()
                                        }
                                    }

                                    when (containerResponse.skipRewareMoves) {
                                        "N" -> {
                                            viewModel.rewareMoves(
                                                RewareMovesRequest(
                                                    binding.etFromContainer.text.toString(),
                                                    binding.etSbNumber.text.toString(),
                                                    binding.etFromLocation.text.toString(),
                                                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                                                )
                                            )
                                        }
                                        else -> FlareLog.i(TAG, "containerResponse.skipRewareMoves: ${containerResponse.skipRewareMoves}")
                                    }
                                }
                                else -> FlareLog.e(TAG, "ContainerDetailsResponse ${response.data?.statusHandler?.message}")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.rewareMovesRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data != null) {
                        FlareLog.i(TAG, "Rewaremoves response: ${response.data}")
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "Rewaremoves error: ${response.data.statusHandler.error}")
                                // binding.txtToLocationResponse.text = response.data.statusHandler.error
                                enableDisableText(fromCont = true, fromLoc = false, sbNum = false, toLoc = true, toCont = false, wt = false)
                                binding.etToLocation.requestFocus()
                            }
                            "200" -> {
                                FlareLog.i(TAG, "Rewaremoves success: ${response.data}")
                                enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = false)
                                binding.etToLocation.setText(response.data.toLoc)
                                binding.etToCont.requestFocus()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.rewareHouseSubmitRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { submitResponse ->
                        FlareLog.i(TAG, "Rewarehouse submit response: ${response.data}")
                        if (submitResponse != null) {
                            when (submitResponse.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "Rewarehouse submit error: ${submitResponse.statusHandler.error}")
                                    showErrorSnackBar(submitResponse.statusHandler.error)
                                }
                                "200" -> {
                                    FlareLog.i(TAG, "Rewarehouse submit success: $submitResponse")
                                    showSuccessSnackBarStd(submitResponse.statusHandler.message) {
                                        val action = RewarehouseSerialFragmentDirections.actionRewarehouseSerialFragmentToRewarehouseSerialFragment()
                                        val navOptions = NavOptions.Builder().setPopUpTo(R.id.rewarehouseSerialFragment, true).build()
                                        getNavigationController().navigate(action, navOptions)
                                    }
                                }
                                else -> Log.d(TAG, "subscribeObservers: ")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.valFromLocRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()

                    response.data.let { fromLocationResponse ->
                        FlareLog.i(TAG, "FromLocation response: ${response.data}")
                        if (fromLocationResponse != null) {
                            when (fromLocationResponse.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "FromLocation error: ${fromLocationResponse.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etFromLocation)
                                    binding.etFromLocation.selectAll()
                                    binding.etFromLocationResponse.text = fromLocationResponse.statusHandler.error
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = false, toLoc = false, toCont = false, wt = false)
                                }
                                "200" -> {
                                    FlareLog.i(TAG, "FromLocation success: $fromLocationResponse")
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = false, toCont = false, wt = false)
                                    binding.etSbNumber.requestFocus()
                                }
                                else -> {

                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }

            }
        }

        viewModel.sbNumberRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { sbNumberResponse ->
                        FlareLog.i(TAG, "SBNumber response: ${response.data}")
                        if (sbNumberResponse != null) {
                            when (sbNumberResponse.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "SBNumber error: ${sbNumberResponse.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etSbNumber)
                                    binding.etSbNumber.selectAll()
                                    binding.txtSbNumberResponse.text = sbNumberResponse.statusHandler.error
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = false, toCont = false, wt = false)
                                }
                                "200" -> {
                                    FlareLog.e(TAG, "SBNumber success: $sbNumberResponse")
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = false, wt = false)
                                    binding.etToLocation.requestFocus()
                                }
                                else -> Log.d(TAG, "SB Number Validation ${response.data?.statusHandler?.statusCode}")
                            }

                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        viewModel.valToLocRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { toLocationResponse ->
                        FlareLog.i(TAG, "ToLocation response: ${response.data}")
                        if (toLocationResponse != null) {
                            when (toLocationResponse.statusHandler.statusCode) {
                                "500" -> {
                                    FlareLog.e(TAG, "ToLocation error: ${toLocationResponse.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etToLocation)
                                    binding.etToLocation.selectAll()
                                    binding.txtToLocationResponse.text = toLocationResponse.statusHandler.error
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = false, wt = false)
                                }
                                "200" -> {
                                    FlareLog.i(TAG, "ToLocation success: $toLocationResponse")
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = true)
                                    when {
                                        binding.grpToCont.visibility == View.VISIBLE -> {
                                            binding.etToCont.text?.length?.let {
                                                binding.etToCont.setSelection(it)
                                            }
                                            binding.etToCont.requestFocus()
                                        }
                                        binding.grpWeight.visibility == View.VISIBLE -> {
                                            binding.etWeight.text?.length?.let {
                                                binding.etWeight.setSelection(it)
                                            }
                                            binding.etWeight.requestFocus()
                                        }
                                        // else -> binding.etToLocation.requestFocus()
                                        else -> validateRewarehouseSubmit()
                                    }
                                }
                                else -> FlareLog.e(TAG, "valToLocRes ${response.data?.statusHandler?.message}")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.valToContRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { toContainerResponse ->
                        FlareLog.i(TAG, "ToContainer response: ${response.data}")
                        if (toContainerResponse != null) {
                            if (toContainerResponse.statusHandler.statusCode != null) {
                                if (toContainerResponse.statusHandler.statusCode == "500") {
                                    FlareLog.e(TAG, "ToContainer error: ${toContainerResponse.statusHandler.error}")
                                    showSoftKeyBoard(fragmentContext, binding.etToCont)
                                    binding.etToCont.selectAll()
                                    binding.txttoContRes.text = toContainerResponse.statusHandler.error
                                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = false)
                                } else if (toContainerResponse.statusHandler.statusCode == "200") {
                                    FlareLog.i(TAG, "ToContainer success: $toContainerResponse")
                                    if (toContainerResponse.statusHandler.message.contains("create")) {
                                        showConfirmationDialog()
                                    } else {
                                        isContValidated = true
                                        if(binding.grpWeight.visibility == View.VISIBLE)
                                        {
                                            enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = true)
                                            binding.etWeight.text?.length?.let {
                                                binding.etWeight.setSelection(it)
                                            }
                                            binding.etWeight.requestFocus()
                                        }else{
                                            validateRewarehouseSubmit()
                                        }

                                    }
                                }
                            } else {
                                binding.txttoContRes.text = toContainerResponse.statusHandler.error
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.noNetworkUpdate.observe(viewLifecycleOwner)
        { response ->
            if (response != null) {
                hideProgressBar()
                showErrorSnackBar(resources.getString(R.string.network_connect_failure))
            }
        }
    }

    private fun validateToLocation() {
        viewModel.validateToLocation(
            ValidateToLocationRequest(
                binding.etToLocation.text.toString(),
                binding.etFromContainer.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                sbNum = binding.etSbNumber.text.toString()
            )
        )
    }

    /**
     * Method to validate serial number field before API call.
     */
    private fun validateSerialNumber() {
        viewModel.rewareHouseSerial(binding.etSerialNumber.text.toString())
    }

    private fun validateFromContainer() {
        viewModel.containerDetails(
            ContainerDetailsRequest(
                binding.etFromContainer.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            )
        )
    }

    private fun validateFromLocation() {
        viewModel.validateFromLocation(
            ValidateFromLocRequest(
                binding.etFromLocation.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            )
        )
    }

    private fun validateRewarehouseSubmit() {
        when {
            binding.etSerialNumber.text.isNullOrEmpty() -> {
                binding.etSerialNumberResponse.text = getString(R.string.serial_number_required)
            }
            binding.etFromContainer.text.isNullOrEmpty() -> {
                binding.etFromContainerResponse.text = getString(R.string.from_container_required)
            }
            binding.etFromLocation.text.isNullOrEmpty() -> {
                binding.etFromLocationResponse.text = getString(R.string.from_location_required)
            }
            binding.etSbNumber.text.isNullOrEmpty() -> {
                binding.txtSbNumberResponse.text = getString(R.string.slot_by_number_required)
            }
            binding.etToLocation.text.isNullOrEmpty() -> {
                binding.txtToLocationResponse.text = getString(R.string.to_location_required)
            }
            else -> {
                callRewareHouseSubmit()
            }
        }
    }

    /**
     * Method to show dialog to get confirmation on submit container data
     */
    private fun showConfirmationDialog() {
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(getString(R.string.create_container_title))
            .setCancelable(true)
            .setPositiveButton(getString(R.string.alert_button_yes)) { dialog, _ ->
                isContValidated = true
                dialog.dismiss()

                if(binding.grpWeight.visibility == View.VISIBLE)
                {
                    enableDisableText(fromCont = true, fromLoc = true, sbNum = true, toLoc = true, toCont = true, wt = true)
                    binding.etWeight.text?.length?.let {
                        binding.etWeight.setSelection(it)
                    }
                    binding.etWeight.requestFocus()
                }else{
                    validateRewarehouseSubmit()
                }
            }
            .setNegativeButton(getString(R.string.alert_button_no)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun callRewareHouseSubmit() {
        if (!binding.etFromContainer.text.isNullOrEmpty() && !binding.etFromLocation.text.isNullOrEmpty() &&
            !binding.etSbNumber.text.isNullOrEmpty() && !binding.etToLocation.text.isNullOrEmpty()
        ) {
            viewModel.rewareHouseSubmit(
                SubmitRewarehouseRequest(
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    userId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!.toInt(),
                    cntId = binding.etFromContainer.text.toString(),
                    locId = binding.etFromLocation.text.toString(),
                    Weight = binding.etWeight.text.toString(),
                    toLoc = binding.etToLocation.text.toString(),
                    sbNum = binding.etSbNumber.text.toString(),
                    toCont = binding.etToCont.text.toString(),
                    isContValidated = getIsContValidated()
                ),
                RewareSubmitRequestBody(
                    SubmitParams(
                        null,
                        null,
                        null,
                        listOf(
                            Update(
                                "a",
                                "cntId",
                                binding.etFromContainer.text.toString()
                            ),
                            Update(
                                "a",
                                "locId",
                                binding.etFromLocation.text.toString()
                            ),
                            Update(
                                "a",
                                "toLoc",
                                binding.etToLocation.text.toString()
                            ),
                            Update(
                                "a",
                                "sbNum",
                                binding.etSbNumber.text.toString()
                            ),
                            Update(
                                "a",
                                "Weight",
                                binding.etWeight.text.toString()
                            ),
                            Update(
                                "a",
                                "toCont",
                                binding.etToCont.text.toString()
                            ),
                            Update(
                                "a",
                                "cusId",
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
                            ),
                            Update(
                                "a",
                                "whsId",
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                            ),
                            Update(
                                "a",
                                "buId",
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                            ),
                            Update(
                                "a",
                                "userId",
                                sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!.toInt()
                            )
                        )
                    )
                )
            )
        }
    }

    /**
     * method to get if toContainer is validated status
     */
    private fun getIsContValidated(): String {
        if (isContValidated) {
            return "Y"
        }
        return "N"
    }

    private fun validateSbNumber() {
        viewModel.validateSbNumber(
            RewareHouseSbNumberRequest(
                binding.etFromLocation.text.toString(),
                binding.etSbNumber.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            )
        )
    }

    private fun validateToContainer() {
        viewModel.validateToContainer(
            ValidateToContainerRequest(
                whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                cntId = binding.etFromContainer.text.toString(),
                toLoc = binding.etToLocation.text.toString(),
                sbNum = binding.etSbNumber.text.toString(),
                toCont = binding.etToCont.text.toString()
            )
        )
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRewarehouseSerialBinding.inflate(inflater, container, false)
        binding.rewareHouseViewModel = viewModel
        binding.lifecycleOwner = this
        subscribeObservers()
        isContValidated = false
        return binding.root
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            binding.etSerialNumber.isFocused -> {
                binding.etSerialNumber.setText(scan?.barcode.toString())
                binding.etSerialNumber.text?.length?.let {
                    binding.etSerialNumber.setSelection(
                        it
                    )
                    validateSerialNumber()
                }
            }
            binding.etSbNumber.isFocused -> {
                binding.etSbNumber.setText(scan?.barcode.toString())
                binding.etSbNumber.text?.length?.let {
                    binding.etSbNumber.setSelection(
                        it
                    )
                    validateSbNumber()
                }

            }
            binding.etFromContainer.isFocused -> {
                binding.etFromContainer.setText(scan?.barcode.toString())
                binding.etFromContainer.text?.length?.let {
                    binding.etFromContainer.setSelection(
                        it
                    )
                    validateFromContainer()
                }
            }
            binding.etFromLocation.isFocused -> {
                binding.etFromLocation.setText(scan?.barcode.toString())
                binding.etFromLocation.text?.length?.let {
                    binding.etFromLocation.setSelection(
                        it
                    )
                    validateFromLocation()
                }
            }

            binding.etToLocation.isFocused -> {
                binding.etToLocation.setText(scan?.barcode.toString())
                binding.etToLocation.text?.length?.let {
                    binding.etToLocation.setSelection(
                        it
                    )
                    validateToLocation()
                }
            }
            binding.etToCont.isFocused -> {
                binding.etToCont.setText(scan?.barcode.toString())
                binding.etToCont.text?.length?.let {
                    binding.etToCont.setSelection(
                        it
                    )
                    validateToContainer()
                }
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError:$scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun enableDisableText(fromCont: Boolean, fromLoc: Boolean, sbNum: Boolean, toLoc: Boolean, toCont: Boolean, wt: Boolean) {
        binding.etFromContainer.isEnabled = fromCont
        binding.etFromLocation.isEnabled = fromLoc
        binding.etSbNumber.isEnabled = sbNum
        binding.etToLocation.isEnabled = toLoc
        binding.etToCont.isEnabled = toCont
        binding.etWeight.isEnabled = wt
    }

}