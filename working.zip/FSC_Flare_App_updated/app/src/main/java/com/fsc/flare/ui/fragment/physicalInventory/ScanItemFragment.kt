package com.fsc.flare.ui.fragment.physicalInventory

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.core.text.HtmlCompat
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanItemBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.itembarcode.Item
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "ScanItemFragment"

@AndroidEntryPoint
class ScanItemFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentScanItemBinding
    private lateinit var taskData: BatchTaskDetailsResp
    lateinit var cb1: CustomVisibilityCallback

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentScanItemBinding.inflate(inflater, container, false)
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType ?: ""
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text =
            viewModel.batchSummaryResp?.countType.plus(" - ").plus(taskData.batchNumber)
        subscribeValidateItemObservers()
        subscribeBatchTaskDetailsObserver()
        subscribeBatchSummaryObserver()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleTouchEvent()
        handleEnterKeyEvent()
        handleEndCountButtonClick()
        handleEnterKeyEvent()
        binding.itemScan.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun updateDataOnScreen() {
        binding.countType.text =
            sharedPreferencesBase.getString(
                PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE,
                ""
            )
        binding.location.text = taskData.locationBarCode
    }

    private fun handleEnterKeyEvent() {
        binding.itemScan.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext,binding.rootLayout)
                getItemCall()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.itemScan.isFocused && !binding.itemScan.text.isNullOrEmpty()) {
                            hideSoftKeyBoard(fragmentContext,binding.rootLayout)
                            getItemCall()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun handleEndCountButtonClick() {
        binding.endCount.setOnClickListener {
            val updateBatchTaskReq = viewModel.prepareUpdateTaskRequest(null, null, false)
            viewModel.updateBatchTask(updateBatchTaskReq)
        }
    }

    private fun getItemCall() {
        viewModel.selectedItemDetails = null
        viewModel.getInquiryItemInfo(binding.itemScan.text.toString().trim())
    }

    private fun subscribeValidateItemObservers() {
        viewModel.itemBarcodeResponse.observe(viewLifecycleOwner) { itemInquiryResponse ->
            when (itemInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "itemBarcode success: $itemInquiryResponse")
                    hideProgressBar()
                    itemInquiryResponse.data?.let { itemBarcodeResponse ->
                        if (itemBarcodeResponse.items != null) {
                            if (itemBarcodeResponse.items.size == 1) {
                                binding.itemScan.setText(itemBarcodeResponse.items[0].itemName)
                                binding.itemScan.text?.length?.let {
                                    binding.itemScan.setSelection(it)
                                }
                                viewModel.selectedItem = itemBarcodeResponse.items[0].itemName
                                viewModel.selectedItemDetails = itemBarcodeResponse.items[0]
                                binding.itemScan.text = null
                                validateItem(itemBarcodeResponse.items[0])
                            } else {
                                //implement multiple item barcode logic
                                // setup the alert builder
                                val builder = AlertDialog.Builder(fragmentContext)
                                val str =
                                    "<font color='#340e5f'>" + resources.getString(R.string.lbl_select_item) + "</font>"
                                builder.setTitle(
                                    HtmlCompat.fromHtml(
                                        str, HtmlCompat.FROM_HTML_MODE_LEGACY
                                    )
                                )
                                val items = itemBarcodeResponse.items
                                val itemsList = ArrayList<String>()
                                for (item in items) {
                                    val itemType = "${item.itemId} - ${item.description}"
                                    itemsList.add(itemType)
                                }
                                val itemsArray: Array<String> = itemsList.toTypedArray()
                                builder.setItems(itemsArray) { _, position ->
                                    binding.itemScan.setText(items[position].itemName)
                                    binding.itemScan.text?.length?.let {
                                        binding.itemScan.setSelection(it)
                                    }
                                    viewModel.selectedItem = items[position].itemName
                                    viewModel.selectedItemDetails = items[position]
                                    binding.itemScan.text = null
                                    validateItem(items[position])
                                }
                                // create and show the alert dialog
                                val dialog = builder.create()
                                dialog.setCancelable(false)
                                dialog.show()
                            }
                        } else {
                            binding.errResponse.text = getString(R.string.no_items_found)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    itemInquiryResponse.message?.let { message ->
                        binding.errResponse.text = message
                        FlareLog.e(TAG, "ItemInquiry Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchTaskDetailsObserver() {
        viewModel.batchTaskDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchTaskDetailsResp ->
                        FlareLog.i(TAG, "batchTaskDetails success: $batchTaskDetailsResp")
                        viewModel.batchTaskDetailsResp = batchTaskDetailsResp
                        if (batchTaskDetailsResp.isLastTask == "true") {
                            showSuccessSnackBarStd(getString(R.string.batch_count_completed)) {
                                viewModel.getBatchSummary(null,"", sharedPreferencesBase.getString(
                                    PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE,
                                    ""
                                ))
                            }
                        } else {
                            viewModel.isActiveLocationEmpty = batchTaskDetailsResp.itemDetails.isNullOrEmpty()
                            val action = ScanItemFragmentDirections.actionScanItemFragmentToScanLocationFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.scanLocationFragment, true).build()
                            getNavigationController().navigate(action,navOptions)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchTaskDetails Error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                showErrorSnackBar(msgArray[1])
                            }
                        } else {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchSummaryObserver() {
        viewModel.batchSummaryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchSummaryResp ->
                        if (!batchSummaryResp.batchNumber.isNullOrEmpty()) {
                            viewModel.batchSummaryResp = batchSummaryResp
                            FlareLog.i(TAG, "batchSummary success: $batchSummaryResp")
                            val action =
                                ScanItemFragmentDirections.actionScanItemFragmentToBatchAcceptOrSkipFragment()
                            val navOptions = NavOptions.Builder()
                                .setPopUpTo(R.id.batchAcceptOrSkipFragment, true).build()
                            getNavigationController().navigate(action, navOptions)
                        } else {
                            showSuccessSnackBarStd(getString(R.string.no_tasks_exist)) {
                                val action =
                                    ScanItemFragmentDirections.actionScanItemFragmentToPhysicalInventoryCountTypesFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.physicalInventoryCountTypesFragment, true)
                                    .build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchSummary Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToNextScreen() {
        viewModel.serialList.clear()
        viewModel.currentScanQty = 0
        viewModel.scannedLotNumber = null
        if (viewModel.selectedItemDetails?.tracking?.lotRequired == "1") {
            val action = ScanItemFragmentDirections.actionScanItemFragmentToScanLotFragment()
            getNavigationController().navigate(action)
        } else {
            val action = ScanItemFragmentDirections.actionScanItemFragmentToScanQuantityFragment()
            getNavigationController().navigate(action)
        }
    }

    /*
    * validates the item is already scanned or not and also throws alert if mismatch item is scanned*/
    private fun validateItem(selectedItemDetail: Item) {
        val taskItemIds = taskData.itemDetails?.map { it.itemBarCode }
        if (taskItemIds?.contains(viewModel.selectedItemDetails?.itemId) == true) {
            if (viewModel.scannedItemListIds.isNotEmpty()) {
                if (viewModel.scannedItemListIds.contains(selectedItemDetail.itemId)) {
                    binding.errResponse.text = getString(R.string.item_already_scanned_please_end_count)
                } else {
                    viewModel.scannedItemListIds.add(selectedItemDetail.itemId)
                    navigateToNextScreen()
                }
            } else {
                viewModel.scannedItemListIds.add(selectedItemDetail.itemId)
                navigateToNextScreen()
            }

        } else {
            if (viewModel.scannedItemListIds.isNotEmpty()) {
                if (viewModel.scannedItemListIds.contains(selectedItemDetail.itemId)) {
                    binding.errResponse.text =
                        getString(R.string.item_already_scanned_please_end_count)
                } else {
                    showItemMismatchAlert(
                        taskData.locationBarCode,
                        viewModel.selectedItem!!,
                        selectedItemDetail
                    )
                }
            } else {
                if (taskItemIds?.contains(viewModel.selectedItemDetails?.itemId) == true) {
                    viewModel.scannedItemListIds.add(selectedItemDetail.itemId)
                    navigateToNextScreen()
                } else {
                    showItemMismatchAlert(
                        taskData.locationBarCode,
                        viewModel.selectedItem!!,
                        selectedItemDetail
                    )
                }
            }
        }
    }


    private fun showItemMismatchAlert(location: String, item: String, selectedItemDetail: Item) {
        val msg = getString(
            R.string.item_mismatched_does_the_scanned_item_present_in_the_location,
            item,
            location
        )
        showAlertDialog(
            "",
            msg,
            getString(R.string.alert_button_yes),
            getString(R.string.alert_button_no),
            object :
                AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.scannedItemListIds.add(selectedItemDetail.itemId)
                    navigateToNextScreen()
                }

                override fun onNegativeButtonClick() {
                    viewModel.scannedItemListIds.remove(viewModel.selectedItemDetails?.itemId)
                    binding.itemScan.text = null
                }
            })
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.itemScan.setText(scan?.barcode.toString())
        binding.itemScan.text?.length?.let {
            binding.itemScan.setSelection(it)
        }
        FlareLog.i(TAG, "ScanLocation field focused")
        getItemCall()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}