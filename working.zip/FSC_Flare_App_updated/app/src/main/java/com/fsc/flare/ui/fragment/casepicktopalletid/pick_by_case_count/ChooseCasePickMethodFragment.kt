package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.PickMethodFragmentBinding
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.casepicktopalletid.CasePickToPalletIDViewModel
import com.fsc.flare.ui.fragment.casepicktopalletid.FetchTaskState
import com.fsc.flare.utils.PickByCaseMethod.PIK_BY_CASE
import com.fsc.flare.utils.PickByCaseMethod.PIK_BY_CNT
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.observeFlowOnUI
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

@AndroidEntryPoint
class ChooseCasePickMethodFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreference: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    private lateinit var binding: PickMethodFragmentBinding

    private val sharedViewModel: PickCaseByCountSharedViewModel by activityViewModels()
    private val existingViewModel: CasePickToPalletIDViewModel by activityViewModels()

    private val pickMethods by lazy {
        val lookupsString = sharedPreference.getString(PreferenceKeys.CASE_PICK_METHOD_LIST_PREFERENCE, "")
        Gson().fromJson(lookupsString, Array<String>::class.java).map {
            when (it) {
                PIK_BY_CNT -> getString(R.string.pick_by_case_count)
                PIK_BY_CASE -> getString(R.string.pick_by_case)
                else -> it
            }
        }
    }

    private val palletInfo by lazy { existingViewModel.getPickTask()?.toPalletInformation() }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = PickMethodFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        observeFlowOnUI { refreshTaskState() }
    }

    private fun initView() {

        binding.tvPalletNumber.text = palletInfo?.palletNumber
        binding.dropPickMethod.setOptions(pickMethods)

        binding.dropPickMethod.boolFoo.observe(viewLifecycleOwner) { selectedOption ->

            when (selectedOption) {
                getString(R.string.pick_by_case_count) -> {
                    sharedViewModel.clearData()
                    sharedViewModel.palletInfo = palletInfo
                    val action = ChooseCasePickMethodFragmentDirections.actionCasePickMethodToCasePickLocation()
                    findNavController().navigate(action)
                }

                getString(R.string.pick_by_case) -> {
                    existingViewModel.refreshAssignedTask(palletNumber = palletInfo?.palletNumber.orEmpty())
                }

                else -> {
                    showErrorSnackBar(getString(R.string.invalid_pick_method))
                }
            }
        }
    }

    private suspend fun refreshTaskState() {
        existingViewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is FetchTaskState.ShowProgress -> {
                    binding.progressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is FetchTaskState.StagePending -> {
                    showStagePendingDialog(state.cartNumber)
                }

                is FetchTaskState.TaskFetchError -> {
                    showErrorSnackBar(state.errorMessage)
                    binding.dropPickMethod.text = null
                }

                FetchTaskState.TaskFetchSuccess -> {
                    val action = ChooseCasePickMethodFragmentDirections.actionCasePickMethodToPalletIDPickLocation()
                    findNavController().navigate(action)
                }
            }
        }
    }

    /**
     * Function to show stage pending dialog
     */
    private fun showStagePendingDialog(cartNbr: String) {
        alertHandler.showSimpleAlert(
            message = getString(R.string.stage_pending_pallet_message, cartNbr),
            buttonTitle = getString(R.string.stage)
        ) {
            val action = ChooseCasePickMethodFragmentDirections.actionCasePickMethodToStateLocation()
            findNavController().navigate(action)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        existingViewModel.clearData()
    }
}