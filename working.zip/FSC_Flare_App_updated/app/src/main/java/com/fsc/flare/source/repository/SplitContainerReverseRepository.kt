package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.splitcontainerreverse.QtyBaseReq
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContDetailsRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class SplitContainerReverseRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun validateFromContainer(splitContDetailsRequest: SplitContDetailsRequest) =
        apiGatewayInterface.validateFromContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            splitContDetailsRequest = splitContDetailsRequest
        )

    suspend fun validateSku(skuRequest: SplitSkuRequest) =
        apiGatewayInterface.validateSku(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            splitSkuRequest = skuRequest
        )
    suspend fun validateItemBarcode(skuRequest: SplitSkuRequest) =
        apiGatewayInterface.validateItemBarcode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            splitSkuRequest = skuRequest
        )

    suspend fun validateQty(qtyBaseReq: QtyBaseReq) =
        apiGatewayInterface.validateQty(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            qtyBaseReq = qtyBaseReq
        )

    suspend fun validateSubmitContainer(splitContSubmitRequest: SplitContSubmitRequest) =
        apiGatewayInterface.validateSubmitContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            splitContSubmitRequest = splitContSubmitRequest
        )
}