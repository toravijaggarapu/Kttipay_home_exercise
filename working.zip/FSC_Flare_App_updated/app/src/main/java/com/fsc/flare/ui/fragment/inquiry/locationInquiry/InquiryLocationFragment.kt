package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryLocBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.CaseObj
import com.fsc.flare.source.data.dto.inquiry.location.PalletObj
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [InquiryLocationFragment] class.
 */

private const val TAG = "InquiryLocFragment"

@AndroidEntryPoint
class InquiryLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryLocBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryLocBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()
        binding.locationBarcode.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        binding.locationBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.locBarcodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.locationBarcode.isFocused && !binding.locationBarcode.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "LocationBarcode field focused")
            viewModel.caseListHashMap.clear()
            viewModel.lotNumbersList.clear()
            viewModel.expiredDatesList.clear()
            viewModel.cooCodesList.clear()
            viewModel.getLocationInfo(binding.locationBarcode.text.toString())
        }
    }

    private fun subscribeObservers() {
        viewModel.locationResponse.observe(viewLifecycleOwner) { locationInquiryResponse ->
            when (locationInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "locationInquiry success: $locationInquiryResponse")
                    hideProgressBar()
                    locationInquiryResponse.data?.let { locationResponse ->
                        if (locationResponse.locations.isNotEmpty()) {
                            viewModel.setLocation(locationResponse)
                            if (locationResponse.locations[0].status != "0") {
                                if (locationResponse.locations[0].locType == "F") {
                                    val storageLocationsClassificationList = arrayOf("A", "C", "R")
                                    if (locationResponse.locations[0].classification in storageLocationsClassificationList) {
                                        viewModel.getLocationInventoryCount(locationResponse.locations[0].locationId.toString())
                                    } else {
                                        navigateToNonStorageOrEmptyLocationDetails()
                                    }
                                } else {
                                    viewModel.getRlogLocationInquiry(locationResponse.locations[0].locationBarcode)
                                }
                            } else {
                                navigateToNonStorageOrEmptyLocationDetails()
                            }
                        } else {
                            binding.locBarcodeResponse.text = getString(R.string.alert_no_location_found)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    locationInquiryResponse.message?.let { message ->
                        binding.locBarcodeResponse.text = message
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

            viewModel.locationInventoryCountResponse.observe(viewLifecycleOwner) { locInvCountResponse ->
                when (locInvCountResponse) {
                    is Resource.Success -> {
                        FlareLog.i(TAG, "locationInquiry success: $locInvCountResponse")
                        hideProgressBar()
                        locInvCountResponse.data?.let { locInvCountResp ->
                            viewModel.locInventoryCounts = locInvCountResp
                            viewModel.getLocationInventory(binding.locationBarcode.text.toString(),0, viewModel.PAGELIMIT)
                        }
                    }

                    is Resource.Error -> {
                        hideProgressBar()
                        locInvCountResponse.message?.let { message ->
                            binding.locBarcodeResponse.text = message
                            FlareLog.e(TAG, "locInvCountResponse Error: $message")
                        }
                    }

                    is Resource.Loading -> {
                        showProgressBar()
                    }
                }
            }

        viewModel.locationInventoryResponse.observe(viewLifecycleOwner) { locationInvResponse ->
            when (locationInvResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "locationInquiry success: $locationInvResponse")
                    hideProgressBar()
                    val locDetails = viewModel.getLocation()
                    locationInvResponse.data?.let { locationInventoryResponse ->
                        viewModel.locationContainer = locationInventoryResponse.containers?.get(0)
                        if (locDetails != null) {
                            if (locDetails.locations[0].classification == "R" && !locationInventoryResponse.containers.isNullOrEmpty()) {
                                val palletFilteredList = locationInventoryResponse.containers.filter { it.containerType == "P" }
                                viewModel.lotNumbersList = locationInventoryResponse.containers .filter { it.lotNumber != null }.map{it.lotNumber}.distinct().toMutableList()
                                viewModel.expiredDatesList = locationInventoryResponse.containers.filter { it.expiryDate != null }.map{it.expiryDate}.distinct().toMutableList()
                                viewModel.cooCodesList = locationInventoryResponse.containers.filter { it.cooCode != null }.map{it.cooCode}.distinct().toMutableList()
                                viewModel.invTypesList = locationInventoryResponse.containers.filter { it.inventoryType != null }.map{it.inventoryType}.distinct().toMutableList()
                                val palletList = palletFilteredList.map {
                                    PalletObj(
                                        palletNbr = it.container,
                                        qty = it.qty,
                                        status = getContainerStatus(it.containerStatus),
                                        noOfCases = it.noOfCases
                                    )
                                }.toMutableList()
                                viewModel.palletListHashMap[0] = palletList
                                navigateToStorageLocationDetails()
                            } else if (locDetails.locations[0].classification == "C" && !locationInventoryResponse.containers.isNullOrEmpty()) {
                                val caseFilteredList = locationInventoryResponse.containers.filter { it.containerType == "C" }
                                viewModel.lotNumbersList = locationInventoryResponse.containers.filter { it.lotNumber != null }.map{it.lotNumber}.distinct().toMutableList()
                                viewModel.expiredDatesList = locationInventoryResponse.containers.filter { it.expiryDate != null }.map{it.expiryDate}.distinct().toMutableList()
                                viewModel.cooCodesList = locationInventoryResponse.containers.filter { it.cooCode != null }.map{it.cooCode}.distinct().toMutableList()
                                viewModel.invTypesList = locationInventoryResponse.containers.filter { it.inventoryType != null }.map{it.inventoryType}.distinct().toMutableList()
                                var caseList = caseFilteredList.map {
                                    CaseObj(
                                        caseNbr = it.container,
                                        qty = it.qty,
                                        getContainerStatus(it.containerStatus)
                                    )
                                }.toMutableList()
                                viewModel.caseListHashMap[0] = caseList
                                navigateToStorageLocationDetails()
                            } else if (locDetails.locations[0].classification == "A") {
                                viewModel.lotNumbersList = locationInventoryResponse.containers!!.filter { it.lotNumber != null }.map{it.lotNumber}.distinct().toMutableList()
                                viewModel.expiredDatesList = locationInventoryResponse.containers.filter { it.expiryDate != null }.map{it.expiryDate}.distinct().toMutableList()
                                viewModel.cooCodesList = locationInventoryResponse.containers.filter { it.cooCode != null }.map{it.cooCode}.distinct().toMutableList()
                                viewModel.invTypesList = locationInventoryResponse.containers.filter { it.inventoryType != null }.map{it.inventoryType}.distinct().toMutableList()
                                navigateToStorageLocationDetails()
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    navigateToNonStorageOrEmptyLocationDetails()
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.rLogLocationInquiryResponse.observe(viewLifecycleOwner) { locationInquiryResponse ->
            when (locationInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "locationInquiry success: $locationInquiryResponse")
                    hideProgressBar()
                    locationInquiryResponse.data?.let { locationInquiryResponse ->
                        viewModel.rLogLocationInquiry = locationInquiryResponse
                        navigateToReverseLocationDetails()
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    locationInquiryResponse.message?.let { message ->
                        binding.locBarcodeResponse.text = message
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToStorageLocationDetails() {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = InquiryLocationFragmentDirections.actionInquiryLocationToStorageLocationDesc()
        navController.navigate(action)
    }

    private fun navigateToReverseLocationDetails() {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = InquiryLocationFragmentDirections.actionInquiryLocationToReverseLocationDesc()
        navController.navigate(action)
    }

    private fun navigateToNonStorageOrEmptyLocationDetails() {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action =
            InquiryLocationFragmentDirections.actionInquiryLocationToNonStorageLocationDesc()
        navController.navigate(action)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.locationBarcode.setText(scan?.barcode.toString())
        binding.locationBarcode.text?.length?.let {
            binding.locationBarcode.setSelection(it)
        }
        FlareLog.i(TAG, "LocationBarcode field focused")
        viewModel.getLocationInfo(binding.locationBarcode.text.toString())
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}