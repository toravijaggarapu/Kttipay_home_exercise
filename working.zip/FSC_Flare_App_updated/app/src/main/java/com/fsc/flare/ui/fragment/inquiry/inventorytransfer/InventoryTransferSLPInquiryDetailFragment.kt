package com.fsc.flare.ui.fragment.inquiry.inventorytransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryTransferSlpInquiryDetailBinding
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [Fragment] subclass.
 * Use the [InventoryTransferSLPInquiryDetailFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InventoryTransferSLPInquiryDetailFragment : BaseFragment() {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryTransferSlpInquiryDetailBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInventoryTransferSlpInquiryDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val slpInquiryDetail = viewModel.getInventoryTransferSlpInquiryDetail()
        //If the response is come from the SLP Api, need to show the slp number.
        //If the response is come from the Serial Api, need to show the serial number.
        //Above condition is can be check using the 'isFromSlpDetail' value from viewModel.
        if(viewModel.isFromSlpDetail()){
            binding.tvSlpValue.text = slpInquiryDetail.slp
        }else{
            binding.tvSlpValue.text = slpInquiryDetail.serialNumber
        }

        binding.tvInventoryTypeValue.text = getInventoryDescription(slpInquiryDetail.inventoryType)
        binding.tvItemValue.text = slpInquiryDetail.itemCode
        binding.tvDescriptionValue.text = slpInquiryDetail.description
        binding.tvQtyValue.text = slpInquiryDetail.scanQty.toString()
        binding.tvFromLocationValue.text = slpInquiryDetail.fromLocationBarcode
        binding.tvToLocationValue.text = slpInquiryDetail.toLocationBarcode
        binding.tvAreaValue.text = slpInquiryDetail.area
        binding.tvZoneValue.text = slpInquiryDetail.zone
        binding.tvAisleValue.text = slpInquiryDetail.aisle
        binding.tvBayValue.text = slpInquiryDetail.bay
        binding.tvLevelValue.text = slpInquiryDetail.level
        binding.tvPositionValue.text = slpInquiryDetail.position

        binding.btnOk.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                val action =
                    InventoryTransferSLPInquiryDetailFragmentDirections.actionInventoryTransferSlpInquiryDetailFragmentToInventoryTransferSlpInquiryFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inventoryTransferSlpInquiryFragment, true).build()
                getNavigationController().navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME_500)
        }
    }

}