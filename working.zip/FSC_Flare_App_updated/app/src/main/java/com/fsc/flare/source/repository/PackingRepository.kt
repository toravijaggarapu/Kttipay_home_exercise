package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.packing.req.DeManifestRequest
import com.fsc.flare.source.data.dto.packing.req.ManifestRequest
import com.fsc.flare.source.data.dto.packing.req.PackingConfirmQtyRequest
import com.fsc.flare.source.data.dto.packing.req.PrintLabelRequest
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.req.UnPackRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PackingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun confirmPackQty(packingConfirmQtyRequest: PackingConfirmQtyRequest) =
        apiGatewayInterface.confirmPackQty(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            packingConfirmQtyRequest = packingConfirmQtyRequest
        )

    suspend fun validateSerialNumberOrItemCode(serialNumberOrItemCode: String, responseFilter: String,isPackStation:Boolean) =
        apiGatewayInterface.validateSerialNumberOrItemCode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            serialNumberOrItemCode = serialNumberOrItemCode,
            responseFilter = responseFilter,
            isPackStation = isPackStation
        )


    suspend fun sendToPR(request:SendToPRRequest) =
        apiGatewayInterface.sendToPR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            request
        )

    suspend fun printLabel(printLabelRequest:PrintLabelRequest) =
        apiGatewayInterface.printPackedItem(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            printLabelRequest
        )

    suspend fun manifest(manifestRequest:ManifestRequest) =
        apiGatewayInterface.manifest(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            manifestRequest
        )

    suspend fun demanifest(manifestRequest:DeManifestRequest) =
        apiGatewayInterface.demanifest(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            manifestRequest
        )

    suspend fun pack(toteNumber: String, obContainerNumber: String) =
        apiGatewayInterface.pack(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            toteNumber = toteNumber,
            obContainerNumber = obContainerNumber,
        )

    suspend fun getPackStationList() =
        apiGatewayInterface.getPackStationList(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            page = 0,
            pageLimit = 100
        )

    suspend fun getPackMethodList() =
        apiGatewayInterface.getPackMethodList(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        )

    suspend fun getShipmentMethods() =
        apiGatewayInterface.getShipmentMethods(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        )

    suspend fun getCartonTypes() =
        apiGatewayInterface.cartontypes(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            )

    suspend fun unpack(unpackRequest:UnPackRequest) =
        apiGatewayInterface.unpack(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            unpackRequest
        )
}