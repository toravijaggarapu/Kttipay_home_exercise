package com.fsc.flare.ui.fragment.interleaving

import androidx.lifecycle.viewModelScope
import com.fsc.flare.R
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingResponse
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTask
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTaskResponse
import com.fsc.flare.source.data.dto.interleaving.RegisterLocationRequest
import com.fsc.flare.source.data.dto.interleaving.ResisterLocationResponse
import com.fsc.flare.source.data.dto.interleaving.TaskInterLeavingData
import com.fsc.flare.source.data.dto.interleaving.ValidateContainerRequest
import com.fsc.flare.source.repository.InterLeavingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class InterLeavingTaskTypeIdentifierViewModel @Inject constructor(
    private val interLeavingRepository: InterLeavingRepository,
) : BaseViewModel() {

    private val _fetchTaskState = MutableStateFlow<InterLeavingLocationTaskState?>(null)
    val fetchTaskState = _fetchTaskState.asStateFlow()

    fun registerLocation(scope: CoroutineScope = viewModelScope, taskType: String, registerLocationRequest: RegisterLocationRequest) {
        scope.launch {
            val response = interLeavingRepository.interLeavingResisterLocation(taskType, registerLocationRequest)
            _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.let { handleRegisterLocationApiSuccessResponse(it) }
                FlareLog.i(TAG, "interLeaving ResisterLocation Success:${body()}")
            } ?: run {
                handleRegisterLocationErrorResponse(response)
            }
        }
    }

    private suspend fun handleRegisterLocationErrorResponse(response: Response<ResisterLocationResponse>) {
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "interLeaving ResisterLocation Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowError(errorMessage))
    }

    private suspend fun handleRegisterLocationApiSuccessResponse(interLeavingData: ResisterLocationResponse) {
        if (interLeavingData.success){
            _fetchTaskState.emit(InterLeavingLocationTaskState.LocationRegisterSuccess(R.string.location_register_success))
        }
    }

    fun sendValidateContainerRequest(scope: CoroutineScope = viewModelScope, taskType: String, containerRequest: ValidateContainerRequest) {
        scope.launch {
            val response = interLeavingRepository.validateContainer(taskType, containerRequest)
            _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = true))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.let { handleValidateContainerApiSuccessResponse(it) }
                FlareLog.i(TAG, "ValidateContainer Success:${body()}")
            } ?: run {
                handleContainerValidateErrorResponse(response)
            }
        }
    }

    private suspend fun handleContainerValidateErrorResponse(response: Response<GetInterLeavingResponse>) {
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "ValidateContainer Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowError(errorMessage))
    }

    private suspend fun handleValidateContainerApiSuccessResponse(getInterLeavingResponse: GetInterLeavingResponse) {
        _fetchTaskState.emit(InterLeavingLocationTaskState.ContainerResponse(getInterLeavingResponse))
    }

    fun sendEndTaskRequest(scope: CoroutineScope = viewModelScope, interLeavingEndTask: InterLeavingEndTask) {
        scope.launch {
            val response = interLeavingRepository.endInterleavingTask(interLeavingEndTask)
            _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = true))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = false))
                body()?.let {  _fetchTaskState.emit(InterLeavingLocationTaskState.EndTaskSuccess) }
                FlareLog.i(TAG, "EndTask Success:${body()}")
            } ?: run {
                handleEndTaskErrorResponse(response)
            }
        }
    }

    private suspend fun handleEndTaskErrorResponse(response: Response<InterLeavingEndTaskResponse>) {
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = false))
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "EndTask Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowError(errorMessage))
    }

    fun callInterLeavingService(scope: CoroutineScope = viewModelScope, interLeavingPayload : GetInterLeavingRequest) {
        scope.launch {

            val response = interLeavingRepository.getInterLeaving(interLeavingPayload)
            _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = false))

            response.takeIf { it.isSuccessful && it.body() != null }?.apply {
                FlareLog.i(TAG, "task interleaving api Success:${body()}")
                body()?.let { handleInterLeavingApiSuccessResponse(it) }
            } ?: run {
                 handleInterLeavingApiErrorResponse(response)
            }
        }
    }

    private suspend fun handleInterLeavingApiErrorResponse(response: Response<GetInterLeavingResponse>) {
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowProgress(show = false))
        val errorMessage = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        FlareLog.e(TAG, "EndTask Error Response: $errorMessage")
        _fetchTaskState.emit(InterLeavingLocationTaskState.ShowError(errorMessage))
    }

    private suspend fun handleInterLeavingApiSuccessResponse(leavingResponse: GetInterLeavingResponse) {
        when (leavingResponse.interLeavingData?.pickInfo?.taskType) {
            InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingLocationTaskState.NavigateToPalletPutwayToReserve(
                        leavingResponse.interLeavingData)
                )
            }

            InterLeavingTaskType.PICK_FROM_RESERVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingLocationTaskState.NavigateToPickFromReserve(
                        leavingResponse.interLeavingData
                    )
                )
            }

            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code -> {
                _fetchTaskState.emit(
                    InterLeavingLocationTaskState.NavigateToPalletReplenishmentToCasePick(
                        leavingResponse.interLeavingData,
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.description
                    )
                )
            }

            InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code -> {
                _fetchTaskState.emit(
                    InterLeavingLocationTaskState.NavigateToPalletReplenishmentToActive(
                        leavingResponse.interLeavingData,
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.description
                    )
                )
            }
        }
    }
}

sealed class InterLeavingLocationTaskState {
    data class ShowProgress(val show: Boolean) : InterLeavingLocationTaskState()
    data class ShowError(val errorMessage: String) : InterLeavingLocationTaskState()
    data class LocationRegisterSuccess(val message: Int) : InterLeavingLocationTaskState()
    data class ContainerResponse(val getInterLeavingResponse: GetInterLeavingResponse) : InterLeavingLocationTaskState()
    data object EndTaskSuccess : InterLeavingLocationTaskState()
    data class NavigateToPalletPutwayToReserve(val response: TaskInterLeavingData?) : InterLeavingLocationTaskState()
    data class NavigateToPalletReplenishmentToCasePick(val response: TaskInterLeavingData?, val screenTitle : Int) : InterLeavingLocationTaskState()
    data class NavigateToPalletReplenishmentToActive(val response: TaskInterLeavingData?, val screenTitle : Int) : InterLeavingLocationTaskState()
    data class NavigateToPickFromReserve(val response: TaskInterLeavingData?) : InterLeavingLocationTaskState()
}