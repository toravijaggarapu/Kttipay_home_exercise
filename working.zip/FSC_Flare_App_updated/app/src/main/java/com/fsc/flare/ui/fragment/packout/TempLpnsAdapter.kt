package com.fsc.flare.ui.fragment.packout

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.packout.res.ContainerDetails
import com.google.android.material.textview.MaterialTextView
import java.util.ArrayList

class TempLpnsAdapter(
    private var tempLpnsList: ArrayList<ContainerDetails>)
    : RecyclerView.Adapter<TempLpnsAdapter.ViewHolder>() {

    lateinit var context: Context

    fun update(item: ContainerDetails) {
        tempLpnsList.add(item)
        notifyItemInserted(tempLpnsList.size)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvContainerNumber: MaterialTextView = itemView.findViewById(R.id.tvContainerNumber)
        var tvQty: MaterialTextView = itemView.findViewById(R.id.tvQty)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.packout_cartons, parent, false)
        context = parent.context
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvContainerNumber.text = tempLpnsList[position].containerNumber
        holder.tvQty.text = context.resources.getQuantityString(
            R.plurals.case_transfer_scanned_case_units,
            tempLpnsList[position].containerQty.toInt(),
            tempLpnsList[position].containerQty)
    }

    override fun getItemCount(): Int {
        return tempLpnsList.size
    }
}