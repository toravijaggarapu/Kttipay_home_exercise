package com.fsc.flare.ui.fragment.submenu

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSubMenuBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.Children
import com.fsc.flare.source.data.dto.login.Module
import com.fsc.flare.source.data.dto.login.UserModulesByCustomer
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.home.HomeAdapter
import com.fsc.flare.ui.fragment.home.HomeViewModel
import com.fsc.flare.ui.fragment.outBound.materialMovement.MaterialMovementSharedViewModel
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.Constants.Companion.ROOT_MENU_NAME
import com.fsc.flare.utils.Constants.SubMenu.Companion.TNR_MOVE_TASK
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.StringUtils
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject

private const val ARG_PARAM1 = "displayName"
private const val ARG_PARAM2= "rootMenuName"
private const val TAG = "SubMenuFragment"

/**
 * A simple [SubMenuFragment] class.
 */
@AndroidEntryPoint
class SubMenuFragment : BaseFragment(), SubMenuAdapter.OnAdapterClickListener {

    private var displayName: String? = null
    private var rootMenuName:String?=null

    lateinit var subMenuAdapter: SubMenuAdapter
    private lateinit var binding: FragmentSubMenuBinding
    lateinit var navController: NavController
    private val viewModel: HomeViewModel by activityViewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    override fun onResume() {
        sendTrackerDataToServer()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            arguments?.let {
                displayName = it.getString(ARG_PARAM1)
                rootMenuName =it.getString(ARG_PARAM2)
            }
        //viewModel.fetchAuthorizedMenu()
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.main_menu, menu)
        val item = menu.findItem(R.id.action_search)
        val searchView = item.actionView as SearchView
        searchView.maxWidth = Int.MAX_VALUE
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setIconifiedByDefault(true)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                subMenuAdapter.filter.filter(newText)
                return false
            }
        })
        item?.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }

            override fun onMenuItemActionCollapse(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }
        })
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.account)?.isVisible = true
        menu.findItem(R.id.action_search)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.language)?.isVisible = false
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSubMenuBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        binding.tvDisplayName.text = displayName
        if(viewModel.fetchUserModulesByCustomerList().isNotEmpty()) {
            generateSubMenuList(viewModel.fetchUserModulesByCustomerList())
        } else {
            viewModel.fetchAuthorizedMenu()
        }
    }

    private fun subscribeObservers() {
        viewModel.fetchAuthMenu.observe(viewLifecycleOwner) { authorizedMenusResponse ->
            FlareLog.i(TAG, "AuthMenuResponse: ${authorizedMenusResponse.data}")
            handleAuthorizedMenusResponse(authorizedMenusResponse)
        }
    }

    private fun handleAuthorizedMenusResponse(authorizedMenusResponse: Resource<AuthorizedMenu>) {
        when (authorizedMenusResponse) {
            is Resource.Success -> {
                hideProgressBar()
                if (authorizedMenusResponse.data != null) {
                    val userModulesByCustomer = authorizedMenusResponse.data.userModulesByCustomer
                    generateSubMenuList(userModulesByCustomer)
                }
            }
            is Resource.Error -> {
                hideProgressBar()
                authorizedMenusResponse.message?.let { message ->
                    FlareLog.i(TAG, "authorizedMenusResponseError: $message")
                }
            }
            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun generateSubMenuList(userModulesByCustomer: List<UserModulesByCustomer>) {
        val navItemsList = arrayListOf<Children>()
        val currentCustomerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)

        // Flag to check if we found a matching cusId
        var foundMatchingCusId = false

        // First, check for matching cusId
        userModulesByCustomer.forEach { userModule ->
            if (userModule.cusId.toInt() == currentCustomerId) {
                foundMatchingCusId = true
                userModule.modules.forEach { module ->
                    addNavItemsToList(module, navItemsList)
                }
            }
        }

        // If no matching cusId was found, check for cusId == -1
        if (!foundMatchingCusId) {
            userModulesByCustomer.forEach { userModule ->
                if (userModule.cusId.toInt() == -1) {
                    userModule.modules.forEach { module ->
                        addNavItemsToList(module, navItemsList)
                    }
                }
            }
        }

        setupRecyclerView(navItemsList)
    }
    
    private fun addNavItemsToList(module: Module, navItemsList: MutableList<Children>) {
        module.navItems.forEach { navItem ->
            // Check if display name matches rootMenuName
            if (rootMenuName.equals(navItem.displayName.uppercase(Locale.ROOT))) {
                // Add children to the set, automatically handling duplicates
                navItem.children?.let { children ->
                    navItemsList.addAll(children) // Add all children to the set
                }
            }
        }
    }

    private fun setupRecyclerView(navItemsList: ArrayList<Children>) {
        subMenuAdapter = SubMenuAdapter(navItemsList, this, fragmentContext)
        binding.submenuRecycler.apply {
            adapter = subMenuAdapter
            layoutManager = GridLayoutManager(activity, 2)
        }
    }

    private fun hideProgressBar() {
        binding.progressBarHome.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBarHome.visibility = View.VISIBLE
    }


    override fun onItemSelected(item: String?, menuId:String?) {
        val menuName = StringUtils.langConvertedName(menuId,item, context)
        if (viewModel.isPILockEnabledForFeature(item)) {
            FlareLog.e(TAG, "Pi inprogress, dialog visible.")
            showCustomDialog(getString(R.string.pi_count_inprogress_operation_not_allowed)) {
                FlareLog.e(TAG, "Pi inprogress, dialog dismissed.")
            }
            return
        }
        sharedPreferences.apply {
            sharedPreferences.edit().putString(PreferenceKeys.SUB_MENU_SELECTED, menuName).apply()
        }
        trackerInstance.setModuleName(item!!)
        when (item) {
            "PUTAWAY BY SLP/CNT" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentPutAway()
                findNavController().navigate(action)
            }
            "PUTAWAY BY UPC" -> {
                val action = R.id.action_subMenuFragment_to_putAwayByUpcFragment
                findNavController().navigate(action)
            }
            "PUTAWAY BY SERIAL#" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentPutAwaySerial()
                findNavController().navigate(action)
            }
            "PUTAWAY CONTAINER" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPutawayForwardFragment()
                findNavController().navigate(action)
            }
            "RECEIVING" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentDockDoor()
                findNavController().navigate(action)
            }

//            "PACKOUT" -> {
//                val navController =
//                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentDockDoor()
//                findNavController().navigate(action)
//            }

            "REWAREHOUSE", "RE-WAREHOUSE" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentRewarehouse()
                //val action = SubMenuFragmentDirections.actionSubMenuFragmentToPalletReplenishmentTaskGroup()
                findNavController().navigate(action)
            }
            "PALLET REPLENISHMENT" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPalletReplenishmentTaskGroup()
                findNavController().navigate(action)
            }
            "CASE REPLENISHMENT" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToCaseReplenishmentTaskGroup()
                findNavController().navigate(action)
            }
            "REPLENISHMENT DELIVERY" -> {
                val isPnDDeliveryEnabled = sharedPreferences.getBoolean(
                    PreferenceKeys.ALLOW_REPLENISHMENT_TO_P_N_D_LOCATION,
                    false
                )
                if (isPnDDeliveryEnabled) {
                    val action = SubMenuFragmentDirections.actionSubMenuFragmentToReplenishmentDeliveryTaskGroup()
                    findNavController().navigate(action)
                } else {
                    alertHandler.showSimpleAlert(message = getString(R.string.message_replenishment_from_p_d_not_enabled))
                }
            }
            "LOAD CART/PALLET" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToReplenLoadCartOrPallet()
                findNavController().navigate(action)
            }
            "FILL CASE PICK" -> {
                Toast.makeText(requireActivity(), "$item", Toast.LENGTH_SHORT)
                    .show()
            }
            "BUILD CART" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPickingTaskGroup()
                findNavController().navigate(action)
            }
            "PICK CART" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPickCartPalletFragment()
                findNavController().navigate(action)
            }
            "PACKING" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPackingFragment()
                findNavController().navigate(action)
            }
            "BL PICKING" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentPicking()
                findNavController().navigate(action)
            }
            "CONTAINER TRACKING" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToContainerTracking()
                findNavController().navigate(action)
            }

            "CYCLE COUNT RESERVE & CASE PICK" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToReserveCCTaskModeFragment()
                findNavController().navigate(action)
            }
            "CYCLE COUNT ACTIVE" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToActiveCCTaskModeFragment()
                findNavController().navigate(action)
            }
            "CYCLE COUNT BY PALLET COUNT" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToCycleCountBulkLocationByPalletCountTaskMode()
                findNavController().navigate(action)
            }
            "CYCLE COUNT BY PALLET ID / CONTAINER ID" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToCycleCountByPalletContainerIdTaskMode()
                findNavController().navigate(action)
            }
            "REVERSE  CYCLE COUNT BY (PALLET/  CONTAINER ID)" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                val navController =
                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(
                    R.id.action_subMenuFragment_to_reverseCycleCountTaskMode,
                    bundle
                )
            }
            "REWAREHOUSE BY SERIAL#" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToFragmentRewarehouseSerial()
                findNavController().navigate(action)
            }
            "STAGING" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToStagingPalletFragment()
                findNavController().navigate(action)
            }
            "PALLETIZE CARTONS" -> {
                val bundle = bundleOf(
                    "screenTagName" to "PALLETIZE"
                )
                findNavController().navigate(R.id.action_submenuFragment_to_PalletizePalletFragment, bundle)
            }
            "DE-PALLETIZE CARTONS" -> {
                val bundle = bundleOf(
                    "screenTagName" to "DE-PALLETIZE"
                )
                findNavController().navigate(R.id.action_submenuFragment_to_PalletizePalletFragment, bundle)
            }
            "CLOSE TRAILER" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToShippingDockDoorFragment()
                findNavController().navigate(action)
            }
            "LOAD TRAILER" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToLoadDockdoorFragment()
                findNavController().navigate(action)
            }
            "UNLOAD TRAILER" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToUnLoadDockdoorFragment()
                findNavController().navigate(action)
            }
            "PICK FROM RESERVE" -> {
                //TODO: Do not delete below code, It is needed for other customers
                /*val navController =
                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPickFromReserveFragment()
                findNavController().navigate(action)*/

                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToTivoTaskGroupFragment()
                findNavController().navigate(action)
            }
            "PACK STATION TOTE TO PR" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPackStationToPRLocation()
                val bundle = bundleOf(
                    ROOT_MENU_NAME to item
                )
                findNavController().navigate(action.actionId, bundle)
            }
            "KIT STAGING TO PR" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPackStationToPRLocation()
                val bundle = bundleOf(
                    ROOT_MENU_NAME to item
                )
                findNavController().navigate(action.actionId, bundle)
            }
            "PR TOTE TO PACK STATION" -> {
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPrToteToPackStation()
                findNavController().navigate(action)
            }
            "PR TOTE TO KIT STAGING" -> {
                // By using bundle value to reuse the PR to Pack station navigation
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_prToteToPackStation, bundle)
            }
            "LABELS & DOCUMENTS" -> {
                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToLabelsAndDocuments()
                findNavController().navigate(action)
            }
            "RECEIVING CARTON" -> {
                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToReceivingCartonFragment()
                findNavController().navigate(action)
            }
            "RECEIVING PALLET" -> {
                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPalletDockDoorASNFragment()
                findNavController().navigate(action)
            }
            "PRESCAN" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPreScanFragment()
                findNavController().navigate(action)
            }

            TNR_MOVE_TASK -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPartsReplacementTaskTypeFragment()
                findNavController().navigate(action)
            }

            "INQUIRY", "ADJUSTMENT", "USER DIRECTED PUTAWAY", "SYSTEM DIRECTED PUTAWAY", "INVENTORY TRANSFER" -> {
                trackerInstance.setModuleName("")
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_submenuchildrenfragment, bundle)
            }

            "PACKOUT FROM ACTIVE" -> {
                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPackOutLocation()
                findNavController().navigate(action)

            }

            "PALLETIZE CONTAINER" -> {
                
                val action = SubMenuFragmentDirections.actionSubmenuFragmentToPalletizeContainerPalletFragment()
                findNavController().navigate(action)
            }

            "MIXED SB PUTAWAY" -> {
                /*val bundle = bundleOf(
                    "displayName" to "MIXED SB PUTAWAY"
                )*/
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                
                findNavController().navigate(R.id.action_submenuFragment_to_mixedSBPutawayFragment, bundle)
            }

            "PALLET TRANSFER" -> {
                val action = SubMenuFragmentDirections.actionSubMenuFragmentToPalletTransferPalletNumberFragment()
                findNavController().navigate(action)
            }

            "IB PALLET - SPLIT/COMBINE" -> {
                /*val bundle = bundleOf(
                    "displayName" to "IB PALLET - SPLIT/COMBINE"
                )*/
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_submenuchildrenfragment, bundle)
            }

            "MASTER PALLET REPACK" -> {
                /*val bundle = bundleOf(
                    "displayName" to "MASTER PALLET REPACK"
                )*/
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_palletRepackPrintRequesterFragment, bundle)
            }

            "CREATE IB CONTAINER" -> {
                /*val bundle = bundleOf(
                    "displayName" to "CREATE IB CONTAINER"
                )*/
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                
                findNavController().navigate(R.id.action_submenuFragment_to_cibContainerFragment, bundle)
            }


            "RENAME PALLET" -> {
                findNavController().navigate(R.id.action_submenuFragment_to_renamePalletFragment)
            }

            "PALLETIZE IB" ->{

                /*val bundle = bundleOf(
                    "displayName" to "PALLETIZE IB"
                )*/
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_palletizeIbPrintRequesterFragment, bundle)
            }
            "INV MOVE - KIT STAGING TO KIT STATION" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_sourceIdentifierFragment, bundle)
            }
            "INV MOVE - KIT STATION TO KIT STATION" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_submenuFragment_to_invMoveKitStationFragment, bundle)
            }
            "OB/IB TRANSFORMATION & SPLIT RECALL" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_scanObContainerFragment, bundle)
            }
            "CYCLE COUNT BY LOCATION IN EACHES" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_cycleCountByLocationInEachesTaskMode, bundle)
            }
            "CASE PICK TO PALLET ID" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_casePickToPalletId, bundle)
            }
            "PHYSICAL INVENTORY COUNTS" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_physicalInventoryCountTypesFragment, bundle)
            }
            "CHANGE ITEM SIZE BY SLP" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_utilitySLPFragment, bundle)

            }
            "INVENTORY MOVEMENT" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_invmTaskModesFragment, bundle)
            }
            "STAGE TO PR" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item
                )
                findNavController().navigate(R.id.action_subMenuFragment_to_stageToPRPalletScanFragment, bundle)
            }

            "RTV PICKING" -> {
                val bundle = bundleOf(
                    "displayName" to menuName,
                    "rootMenuName" to item,
                    IS_RTV to true
                )
                getNavigationController().navigate(R.id.action_subMenuFragment_to_pickingTaskGroup, bundle)
            }

            "OUTBOUND MATERIAL MOVEMENT" -> {
                val bundle = bundleOf(
                    "displayName" to menuName, "rootMenuName" to item
                )

                val materialMovementViewModel: MaterialMovementSharedViewModel by activityViewModels()
                materialMovementViewModel.clearData()

                getNavigationController().navigate(R.id.actionSubMenuToMaterialMovement, bundle)
            }

            else -> Toast.makeText(requireActivity(), "Clicked on $item", Toast.LENGTH_SHORT)
                .show()
        }
    }

}