package com.fsc.flare.ui.fragment.pickfromreverse


import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentContDetailsPickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "FragmentContDetailsPickFromReverse"

@AndroidEntryPoint
class FragmentContDetailsPickFromReverse : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentContDetailsPickFromReserveBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentContDetailsPickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.reservePickCompleteResponse.observe(viewLifecycleOwner) { reservePickCompleteResponse ->
            when (reservePickCompleteResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickCompleteResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBar(response.message)
                            viewModel.reservepickstage()
                        } else {
                            viewModel.setPickTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveContainerFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveContainerFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickCompleteResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickCompleteResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) {reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showErrorSnackBar(response.message)
                            Handler(Looper.getMainLooper()).postDelayed({
                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveFragment, true).build()
                                navController.navigate(action, navOptions)
                            }, 1000)
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveStageFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveStageFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.taskIdTVRes.text = data.taskId.toString()
            binding.itemCodeTvRes.text = data.itemCode
            binding.desTvRes.text = data.itemDescription
            binding.quantityTvRes.text = String.format("%d %s",data.ibContainerQty,data.ibContainerUom)
            binding.locaitonTvRes.text = data.locationName
            binding.containerTvRes.text = data.containerNbr
        }
        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.containerlblEdtRes.text = null
            }
        })
        binding.stage.setOnClickListener {
            viewModel.reservepickstage()
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainer)
                FlareLog.i(TAG, "etContainer field focused")
                validateContainer()
            }
            false
        }
    }

    private fun validateContainer() {
        if (!binding.etContainer.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainer)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (binding.etContainer.text.toString() == taskData.containerNbr) {
                    when {
                        taskData.promptBlind -> {
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveBlindContainerFragment()
                            navController.navigate(action)
                        }
                        taskData.itemLotTracked != "0" -> {
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveLotFragment()
                            navController.navigate(action)
                        }
                        taskData.itemExpDateTracked != "0" -> {
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveExpiryDateFragment()
                            navController.navigate(action)
                        }
                        else -> {
                            viewModel.taskReservePickComplete(
                                ReservePickCompleteRequest(
                                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                    taskData.containerId,
                                    taskData.containerNbr,
                                    taskData.locationBarcode,
                                    taskData.locationName,
                                    taskData.taskQty,
                                    taskData.taskQtyUom,
                                    taskData.taskDetId,
                                    "PFR",
                                    taskData.taskId,
                                    null,
                                    null
                                )
                            )
                        }
                    }
                } else {
                    binding.containerlblEdtRes.text = getString(R.string.wrong_container_picked)
                    binding.etContainer.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etContainer)
                }
            }
        }
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etContainer.setText(scan?.barcode.toString())
            binding.etContainer.text?.length?.let {
                binding.etContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Container field focused")
            validateContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}