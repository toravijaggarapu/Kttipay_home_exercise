package com.fsc.flare.ui.fragment.packout

import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutExpiraryDateBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutSaveTmp
import com.fsc.flare.source.data.dto.packout.req.PrintCaseLabelPackoutReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

private const val TAG = "PackoutexpiryFragment"
@AndroidEntryPoint
class PackoutexpirydateFragment: BaseFragment(), FlareScannable{
var count=1

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutExpiraryDateBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutExpiraryDateBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvDockDoorValue.text=viewModel.getLocationBarcode()
        if(viewModel.getPalletReqNumber()=="") {
            binding.tvPallet.visibility = View.GONE
        }
        else{
            binding.tvPalletValue.text=viewModel.getPalletReqNumber()
        }
        binding.btnEndPackout.isEnabled = false
        binding.tvCartonValue.text = viewModel.getcartonReqNumber()
        binding.itemCode.text = viewModel.getitemData()
        binding.tvQtyValue.text = viewModel.getcasePalletQty().toString()
        binding.tvDescValue.text = viewModel.getItemDesc()

        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //binding.date.text = SimpleDateFormat("MM/dd/yyyy").format(System.currentTimeMillis())
        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)

            binding.etExp.text = sdf.format(cal.time)
            if (!binding.etExp.text.isNullOrEmpty()) {
                //sharedPreferences.edit().putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, binding.etExp.text.toString()).apply()
                viewModel.setExpiryDate(binding.etExp.text.toString() )
            }
            val taskDetails = viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
            val serialNumber= taskDetails.tracking.serialNumberRequired
            if(serialNumber==4/*||serialNumber==1*/) {
                val action = PackoutexpirydateFragmentDirections.actionPackoutexpirydateFragementToPackoutserialnumberFragement()
                moveToFragment(action)
            }
            else{
                viewModel.submitPackout(
                    PackOutSaveTmp(
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        viewModel.getLocationBarcode(), viewModel.getLocId(),
                        viewModel.getcasePalletQty(),
                        viewModel.getpckPallet(),
                        viewModel.getPalletReqNumber(),
                        viewModel.getcartonReqNumber(),
                        viewModel.getItemId(),
                        viewModel.getQuantity(),
                        "EA",
                        viewModel.getlotNumber().toString(),
                        viewModel.getExpiryDate(),
                        viewModel.gettransIdentifier(),
                        viewModel.getSerialNumberList(),
                        viewModel.getInventoryType(),
                        viewModel.lockCodeSelected,
                        viewModel.isKitting
                    )
                )
                binding.btnEndPackout.isEnabled=true
            }
        }
        binding.etExp.setOnClickListener {
            FlareLog.i(TAG, "Date field clicked")
            DatePickerDialog(
                    fragmentContext, dateSetListener,
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        binding.btnEndPackout.setOnClickListener {
            val action = PackoutexpirydateFragmentDirections.actionPackoutexpirydateFragementToPackoutstagingFragment()
            getNavigationController().navigate(action)
        }

        binding.etExp.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                //binding.containerIdResponse.text = null
                binding.etExpRes.text = null
            }
        })
    }



    private fun palitizeCartonLogic(coun:Int){
        if(viewModel.getTpData()== viewModel.palletizeCartonsTransValue){
            val fg=viewModel.getFlag()
            val data=viewModel.getpckPallet()
            if (coun < data) {
                viewModel.setFlag(fg+1)
                val action=PackoutexpirydateFragmentDirections.actionPackoutexpirydateFragementToPackoutCartonFragment()
                moveToFragment(action)
            }
            else{
                binding.btnEndPackout.isEnabled=true
        }
    }
    }

    private fun subscribeObservers() {
        viewModel.submitPackoutResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutLocation response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "PackOutLocation Success:${response}")
                            sharedPreferences.edit().putBoolean(PreferenceKeys.Packout.IS_PACKOUT_DONE,true).apply()
                            binding.etExpRes.text = null
                            binding.btnEndPackout.isEnabled=true
                            viewModel.settransIdentifier(response.transactionIdentifier)

                            if (response.message.isNotEmpty()) {
                                showSuccessSnackBar(response.message)
                            }
                            if(viewModel.isKitting)
                            {
                                callToPrintCaseLabel()
                            }
                            else
                            {
                                palitizeCartonLogic(count)
                            }
                        } else {
                            //  FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                            // Todo error message changes
                            binding.etExpRes.text=resources.getString(R.string.lbl_error)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printCaseLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "printCaseLabelResponse response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "printCaseLabelResponse Success:${response}")
                            showSuccessSnackBarStd(resources.getString(R.string.case_lbl_printed_successfully)) {
                                palitizeCartonLogic(count)
                            }
                        } else {
                            if(response.message!=null)
                            {
                                FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                                showErrorSnackBar(response.message)
                            }
                            palitizeCartonLogic(count)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                        palitizeCartonLogic(count)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        binding.etExp.text = scan?.barcode.toString()
        binding.etExp.text?.length?.let {
          // binding.etExp.setSelection(it)
        }
        FlareLog.i(TAG, "location field focused")
       // packOutExpCall()
    }

    private fun callToPrintCaseLabel() {
        if (viewModel.isKitting) {
            viewModel.printCaseLabel(
                PrintCaseLabelPackoutReq(
                    itemBarcode = viewModel.getItemBarcode(),
                    itemDescription = viewModel.getItemDesc(),
                    itemName = viewModel.getitemData(),
                    caseNumber = viewModel.getcartonReqNumber(),
                    qty = viewModel.getcasePalletQty().toString(),
                    printerName = viewModel.getDefaultPrinter(),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

}