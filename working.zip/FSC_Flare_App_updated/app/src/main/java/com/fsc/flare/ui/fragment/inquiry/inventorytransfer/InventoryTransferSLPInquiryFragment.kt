package com.fsc.flare.ui.fragment.inquiry.inventorytransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryTransferSlpInquiryBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryTransferSLPInquiryFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [InventoryTransferSLPInquiryFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InventoryTransferSLPInquiryFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryTransferSlpInquiryBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInventoryTransferSlpInquiryBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etSlp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSlpResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etSlp.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "SLP field focused")
                getSLPDetails()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etSlp.isFocused && !binding.etSlp.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "SLP field focused")
                        getSLPDetails()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }


    /**
     * method to get SLP details from API
     */
    private fun getSLPDetails() {
        viewModel.getInventoryTransferSlpInquiryDetail(binding.etSlp.text.toString())
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeInventoryTransferSlpInquiryDetail()
        subscribeInventoryTransferSerialInquiryDetail()
    }

    /**
     * method to subscribe SLP observer
     */
    private fun subscribeInventoryTransferSlpInquiryDetail() {
        viewModel.inventoryTransferSlpInquiryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { slpInquiryResponse ->
                        //TODO for demo purpose, if condition is added.
                        if(slpInquiryResponse.serialNumber!=null){
                            getSerialDetails(slpInquiryResponse.serialNumber)
                        }else{
                            viewModel.setInventoryTransferSlpInquiryDetail(slpInquiryResponse)
                            viewModel.setIsFromSlpDetail(true)
                            val action =
                                InventoryTransferSLPInquiryFragmentDirections.actionInventoryTransferSlpInquiryFragmentToInventoryTransferSlpInquiryDetailFragment()
                            getNavigationController().navigate(action)
                        }

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
//                        binding.tvSlpResponse.text = message
//                        binding.etSlp.requestFocus()
//                        binding.etSlp.selectAll()
//                        showSoftKeyBoard(fragmentContext, binding.etSlp)

                        if(message.contains("Item Slot", true)){
                            binding.tvSlpResponse.text = message
                        }else {
                            //Slp API not getting the data so we try with Serial API to get the detail,
                            getSerialDetails(binding.etSlp.text.toString())
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etSlp.setText(scan?.barcode.toString())
                binding.etSlp.text?.length?.let {
                    binding.etSlp.setSelection(it)
                    FlareLog.i(TAG, "SLP field focused")
                    getSLPDetails()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    /**
     * method to get Serial details from API
     */
    private fun getSerialDetails(serialData:String) {
        viewModel.getInventoryTransferSerialInquiryDetail(serialData)
    }

    /**
     * method to subscribe Serial observer
     */
    private fun subscribeInventoryTransferSerialInquiryDetail() {
        viewModel.inventoryTransferSerialInquiryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialInquiryResponse ->
                        viewModel.setInventoryTransferSlpInquiryDetail(serialInquiryResponse)
                        viewModel.setIsFromSlpDetail(false)
                        val action =
                            InventoryTransferSLPInquiryFragmentDirections.actionInventoryTransferSlpInquiryFragmentToInventoryTransferSlpInquiryDetailFragment()
                        getNavigationController().navigate(action)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvSlpResponse.text = message
                        binding.etSlp.requestFocus()
                        binding.etSlp.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etSlp)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

}