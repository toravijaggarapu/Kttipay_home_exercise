package com.fsc.flare.ui.fragment.physicalInventory

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanLotBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "ScanLotFragment"

@AndroidEntryPoint
class ScanLotFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentScanLotBinding
    private lateinit var taskData: BatchTaskDetailsResp
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var callback: OnBackPressedCallback

    override fun onAttach(context: Context) {
        super.onAttach(context)
        callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewModel.scannedItemListIds.contains(viewModel.selectedItemDetails?.itemId)) {
                    viewModel.scannedItemListIds.remove(viewModel.selectedItemDetails?.itemId)
                }
                requireActivity().supportFragmentManager.popBackStack()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }
    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentScanLotBinding.inflate(inflater, container, false)
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text =
            viewModel.batchSummaryResp?.countType.plus(" - ").plus(taskData.batchNumber)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleTouchEvent()
        handleEnterKeyEvent()
        subscribeLotNumberObserver()
        binding.lotScan.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun updateDataOnScreen() {
        binding.countType.text =
            sharedPreferencesBase.getString(
                PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE,
                ""
            )
        binding.location.text = taskData.locationBarCode
        binding.itemBarcode.text = viewModel.selectedItem
    }

    private fun handleEnterKeyEvent() {
        binding.lotScan.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                callLotValidateAPI()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.lotScan.isFocused && !binding.lotScan.text.isNullOrEmpty()) {
                            callLotValidateAPI()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun callLotValidateAPI() {
        viewModel.selectedItemDetails?.itemId?.let {
            viewModel.validateLotOrMfgCodeRequest(
                it,
                binding.lotScan.text.toString().trim()
            )
        }
    }

    private fun subscribeLotNumberObserver() {

        viewModel.validateLotOrMfgCodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success != null && response.success) {
                            val request = ValidateLotNumberRequest(
                                buId = sharedPreferencesBase.getInt(
                                    PreferenceKeys.BUSINESS_UNIT_ID,
                                    -1
                                ),
                                custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                                fcyId = sharedPreferencesBase.getInt(
                                    PreferenceKeys.FACILITY_ID,
                                    -1
                                ),
                                batchNumber = response.lotNumber,
                                itemName = viewModel.selectedItemDetails?.itemName ?: "",
                                itemId = viewModel.selectedItemDetails?.itemId ?: -1
                            )
                            viewModel.validateItemLotNumber(request)
                        } else {
                            FlareLog.i(TAG, "lotValidation error: $response")
                            binding.errResponse.text = response.errorMessage
                            binding.lotScan.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.lotScan)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Lot Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.validateLotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success != null && response.success) {
                            if (!response.batchDetail.isNullOrEmpty()) {
                                if (response.batchDetail[0].expirationDateFormat == null || response.batchDetail[0].expirationDateFormat!!.isEmpty()) {
                                    binding.errResponse.text =
                                        resources.getString(R.string.lbl_expiry_date_not_added_for_this_lot_number)
                                    binding.lotScan.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.lotScan)
                                } else {
                                    viewModel.scannedLotNumber = response.batchDetail[0].batchNbr
                                    navigateToNextScreen()
                                }
                            } else {
                                FlareLog.i(TAG, "lotValidation error: $response")
                                binding.errResponse.text =
                                    getString(R.string.batch_details_not_found)
                                binding.lotScan.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.lotScan)
                            }
                        } else {
                            FlareLog.i(TAG, "lotValidation error: $response")
                            binding.errResponse.text = response.message
                            binding.lotScan.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.lotScan)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Lot Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun navigateToNextScreen() {
        val action = ScanLotFragmentDirections.actionScanLotFragmentToScanQuantityFragment()
        getNavigationController().navigate(action)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.lotScan.setText(scan?.barcode.toString())
        binding.lotScan.text?.length?.let {
            binding.lotScan.setSelection(it)
        }
        FlareLog.i(TAG, "ScanLot field focused")
        callLotValidateAPI()
    }
    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
    override fun onDetach() {
        super.onDetach()
        callback.remove()
    }
}