package com.fsc.flare.ui.fragment.replenish.palletreplenishment

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishmentMainPageBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletReplenishmentMainPage"
@AndroidEntryPoint
class PalletReplenishmentMainPage: BaseFragment(){

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: ReplenishViewModel by activityViewModels()
    lateinit var binding: FragmentReplenishmentMainPageBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentReplenishmentMainPageBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = this

        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.palletReplenSkipResponse.observe(viewLifecycleOwner){ response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplenSkip Response: $taskReplenResponse")
                        if (taskReplenResponse != null) {
                            if (taskReplenResponse.success !=null && taskReplenResponse.success) {
                                viewModel.setReplenTask(taskReplenResponse)
                                if (taskReplenResponse.taskDetails != null) {
                                    val taskData = viewModel.getReplenTaskDetails()
                                    if (taskReplenResponse.taskDetails.taskId == taskData!!.taskId){
                                        showSnackBar(resources.getString(R.string.lbl_no_more_task_available_to_skip))
                                    }
                                    viewModel.setReplenTaskDetails(taskReplenResponse.taskDetails)
                                }else
                                {
                                    showSnackBar(resources.getString(R.string.lbl_no_more_task_available))
                                }
                                initData()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskReplenSkip Error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initData()
        binding.skipTask.setOnClickListener{
            FlareLog.i(TAG, "skipTask clicked")
            callTaskSkipAPI()
        }

        binding.acceptTask.setOnClickListener{
            FlareLog.i(TAG, "acceptTask clicked")
            val action = PalletReplenishmentMainPageDirections.actionReplenishmentMainFragmentToReplenishmentScanLocationFragment()
            getNavigationController().navigate(action)
        }
    }

    private fun callTaskSkipAPI() {

        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()
        if(data!=null)
        {
            if(taskData!=null)
            {
              viewModel.palletReplenTaskSkip(SkipTaskDetailsRequest(
                  custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                  buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                  fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                  pickCartNbr = null,
                  assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                  allocationType = sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null)?:"40",
                  skipTaskId = taskData.taskId.toString(),
                  skipTaskDetId = ""
              ))
            }
        }
    }

    private fun initData() {
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()

        if(data!=null)
        {
            if (taskData != null) {
                binding.taskId.text = taskData.taskId.toString()
                binding.locationVal.text = taskData.locationBarcode
                binding.waveid.text = taskData.waveNumber
                binding.taskType.text = String.format("%s - %s",taskData.taskType,viewModel.taskTypeDesc)
                binding.taskPriority.text=taskData.priority
                binding.statusVal.text = String.format("%s - %s",taskData.taskStatus,taskData.taskStatusDescription)
            }
        }else
        {
            showErrorSnackBar(resources.getString(R.string.lbl_task_details_are_not_found))
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

}