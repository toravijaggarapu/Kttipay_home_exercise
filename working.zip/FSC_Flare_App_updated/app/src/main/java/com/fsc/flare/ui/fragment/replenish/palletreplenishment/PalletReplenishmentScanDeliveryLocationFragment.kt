package com.fsc.flare.ui.fragment.replenish.palletreplenishment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.app.ActivityCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishmentScanDeliveryLocationPageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountHeader
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.replenishment.ReplenPatchRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenResponse
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletReplenishmentScanDeliveryLocationFragment"

@AndroidEntryPoint
class PalletReplenishmentScanDeliveryLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    private val isReplenToPnDLocationEnable by lazy {
        sharedPreferences.getBoolean(PreferenceKeys.ALLOW_REPLENISHMENT_TO_P_N_D_LOCATION, false)
    }

    private var isPalletDroppedAtPnDLocation = false

    private val viewModel: ReplenishViewModel by activityViewModels()
    lateinit var binding: FragmentReplenishmentScanDeliveryLocationPageBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentReplenishmentScanDeliveryLocationPageBinding.inflate(inflater, container, false)
        if (sharedPreferences.getString(
                PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE,
                null,
            ) == "40"
        ) {
            binding.tvPalletReplenishHeader.text = getString(R.string.pallet_repln_active_header)
        } else if (sharedPreferences.getString(
                PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE,
                null,
            ) == "50"
        ) {
            binding.tvPalletReplenishHeader.text = getString(R.string.pallet_repln_casepick_header)
        }

        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.submitReplenTaskResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplenSubmit Response: $taskReplenResponse")
                        if (taskReplenResponse != null) {
                            if (taskReplenResponse.success) {
                                if (viewModel.canGenerateCycleCount) {
                                    generateCycleCountAPI()
                                }
                                updateResponseHandle(taskReplenResponse)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskReplenSkip Error: $message")
                        if (message != null) {
                            displayErrorMessage(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationDetailsResponse ->
                        if (locationDetailsResponse.success) {
                            val scannedLocation = binding.scanDeliveryLocationVal.text.toString().trim()
                            FlareLog.i(TAG, "locationDetailsResponse success: $locationDetailsResponse")
                            if (locationDetailsResponse.locations.isNotEmpty()) {
                                val reserveLocation = locationDetailsResponse.locations[0]
                                if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) {
                                    if (reserveLocation.lockCode == "CC") {
                                        binding.scanDeliveryLocationResponse.text =
                                            getString(R.string.cycle_count_in_progress_for_given_location)
                                    } else {
                                        callSubmitReplenishment(scannedLocation)
                                    }
                                } else {
                                    if (reserveLocation.cycleCountPending == "Y") {
                                        binding.scanDeliveryLocationResponse.text =
                                            getString(R.string.cycle_count_is_pending_for_given_location)
                                    } else {
                                        callSubmitReplenishment(scannedLocation)
                                    }
                                }
                            } else {
                                showErrorSnackBar("Invalid Location")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.generateCCforLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cycleCountTriggerResponse ->
                        FlareLog.e(TAG, "Generate cc Response: ${cycleCountTriggerResponse.message}")
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Generate cc Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun updateResponseHandle(taskReplenResponse: TaskReplenResponse) {
        val successMessage =
            if (isPalletDroppedAtPnDLocation)
                getString(R.string.dropped_successfully, binding.palletVal.text)
            else
                taskReplenResponse.message ?: getString(R.string.replen_success_msg)

        showSuccessSnackBarStd(message = successMessage) {
            navigateToNext(taskReplenResponse)
        }
    }

    private fun generateCycleCountAPI() {
        viewModel.generateCycleCount(
            cycleCountTriggerRequest =
                CycleCountTriggerRequest(
                    cycleCountHeader =
                        CycleCountHeader(
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        ),
                    skipErrIfCCPending = true,
                ),
            pullLocationId = viewModel.getReplenTaskDetails()?.pullLocationId ?: 0
        )
    }

    private fun navigateToNext(taskReplenResponse: TaskReplenResponse) {
        if (taskReplenResponse.taskDetails != null) {
            viewModel.setReplenTask(taskReplenResponse)
            viewModel.setReplenTaskDetails(taskReplenResponse.taskDetails)
            val action =
                PalletReplenishmentScanDeliveryLocationFragmentDirections
                    .actionReplenishmentScanDeliveryLocationFragmentToReplenishmentMainFragment()
            val navOptions =
                NavOptions.Builder().setPopUpTo(R.id.palletReplenishmentTaskGroup, true).build()
            findNavController().navigate(action, navOptions)
        } else {
            val action =
                PalletReplenishmentScanDeliveryLocationFragmentDirections
                    .actionReplenishmentScanDeliveryLocationFragmentToPalletReplenishmentTaskGroup()
            val navOptions =
                NavOptions.Builder().setPopUpTo(R.id.palletReplenishmentTaskGroup, true).build()
            findNavController().navigate(action, navOptions)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Delivery Location field focused")
                    validateDeliveryLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        initData()

        binding.scanDeliveryLocationVal.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Delivery Location field focused")
                validateDeliveryLocation()
            }
            false
        }

        binding.scanDeliveryLocationVal.doAfterTextChanged {
            binding.scanDeliveryLocationResponse.text = null
        }

        binding.tvDropLocation.setOnClickListener {
            if ((viewModel.getReplenTaskDetails()?.dropLocations?.size ?: 0) > 1) {
                alertHandler.showSimpleListDialog(
                    title = getString(R.string.drop_locations),
                    displayList = viewModel.getReplenTaskDetails()?.dropLocations ?: emptyList(),
                )
            }
        }
    }

    private fun validateDeliveryLocation() {
        val deliveryLocation = (binding.scanDeliveryLocationVal.text?.trim() ?: "").toString()
        if (deliveryLocation.isEmpty()) {
            val message = if (isReplenToPnDLocationEnable && viewModel.getReplenTaskDetails()?.dropLocations?.isNotEmpty() == true)
                getString(R.string.delivery_drop_location_is_required)
            else
                getString(R.string.delivery_location_is_required)

            displayErrorMessage(message)
            return
        }
        hideSoftKeyBoard(fragmentContext, binding.scanDeliveryLocationVal)
        if (viewModel.validateDeliveryLocation(deliveryLocation, isReplenToPnDLocationEnable)) {
            isPalletDroppedAtPnDLocation =
                viewModel.getReplenTaskDetails()?.dropLocations?.any { it == deliveryLocation } == true
            viewModel.validateStagingLocation(
                LocationClassReq(
                    customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    barcode = binding.scanDeliveryLocationVal.text.toString()
                )
            )
        } else {
            val message = if (isReplenToPnDLocationEnable && viewModel.getReplenTaskDetails()?.dropLocations?.isNotEmpty() == true)
                getString(R.string.wrong_delivery_drop_location)
            else
                getString(R.string.error_wrong_delivery_location)
            displayErrorMessage(message)
        }
    }

    private fun callSubmitReplenishment(scannedLocation: String){
        val taskData = viewModel.getReplenTaskDetails()
        if (taskData != null) {
            viewModel.submitReplenishmentTask(
                sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, "").orEmpty(),
                ReplenPatchRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    taskId = taskData.taskId,
                    taskDetId = taskData.taskDetId,
                    scannedDestLocation = scannedLocation,
                    destLocationId = taskData.destLocationId.takeIf { !isReplenToPnDLocationEnable }
                )
            )
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.scanDeliveryLocationResponse.text = message
        binding.scanDeliveryLocationVal.selectAll()
    }

    private fun initData() {
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()

        takeIf { data != null && taskData != null }?.let {
            binding.taskId.text = "${taskData?.taskId}"
            binding.itemVal.text = taskData?.itemCode
            binding.locationVal.text = taskData?.locationBarcode
            binding.palletVal.text = viewModel.getScannedPallet()
            binding.palletInventoryVal.text = getInventoryDescription(viewModel.inventoryTypeCode)
            binding.replenishQtyVal.text = String.format(
                getString(R.string.format_num_str_label),
                taskData?.taskQty,
                taskData?.taskQtyUom
            )

            if (taskData?.dropLocations?.isNotEmpty() == true && isReplenToPnDLocationEnable) {
                binding.txtScanDeliveryLocation.text = getString(R.string.scan_delivery_drop_location)
                binding.scanDeliveryLocationVal.hint = getString(R.string.scan_delivery_drop_location)
                binding.grpDropLocation.visibility = View.VISIBLE
                binding.tvDropLocation.text = taskData.dropLocations.firstOrNull()
                if (taskData.dropLocations.size > 1) {
                    binding.tvDropLocation.text = getString(R.string.many_s)
                    binding.tvDropLocation.setTextColor(ActivityCompat.getColor(requireContext(), R.color.skyBlue))
                    binding.tvDropLocation.setTypeface(binding.tvDropLocation.typeface, Typeface.BOLD)
                    binding.tvDropLocation.paintFlags = binding.tvDropLocation.paintFlags or Paint.UNDERLINE_TEXT_FLAG
                } else {
                    binding.tvDropLocation.setTextColor(ActivityCompat.getColor(requireContext(), R.color.colorPrimary))
                    binding.tvDropLocation.setTypeface(binding.tvDropLocation.typeface, Typeface.NORMAL)
                    binding.tvDropLocation.paintFlags = binding.tvDropLocation.paintFlags and Paint.UNDERLINE_TEXT_FLAG.inv()
                }
            } else {
                binding.grpDropLocation.visibility = View.GONE
            }

            binding.deliveryLocationVal.text = taskData?.destLocationBarcode
        } ?: displayErrorMessage(getString(R.string.lbl_task_details_are_not_found))
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        disableTouch()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        enableTouch()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) return

        binding.scanDeliveryLocationVal.setText(scan?.barcode)
        binding.scanDeliveryLocationVal.text?.length?.let {
            binding.scanDeliveryLocationVal.setSelection(it)
        }
        FlareLog.i(TAG, "Scan Delivery Location field focused")
        validateDeliveryLocation()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}