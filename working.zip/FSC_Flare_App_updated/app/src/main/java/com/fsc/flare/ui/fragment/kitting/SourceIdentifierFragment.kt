package com.fsc.flare.ui.fragment.kitting

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSourceIdentifierBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SourceIdentifierFragment"
private const val INV_RC_ERROR_LOCK_CODE = "ERR-INV-RC-LOCK-001"
private const val INV_RC_LOCK_CODE = "RC"

/**
 * A simple [SourceIdentifierFragment] class.
 */
@AndroidEntryPoint
class SourceIdentifierFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: KittingViewModel by activityViewModels()
    private lateinit var binding: FragmentSourceIdentifierBinding

    lateinit var cb1: CustomVisibilityCallback
    var reasonCode: String? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etSourceIdentifier.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSourceIdentifierBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etSourceIdentifier.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                    if (binding.etSourceIdentifier.isFocused && !binding.etSourceIdentifier.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Source Identifier field focused")
                        getPalletOrCaseInfo()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSourceIdentifier.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                FlareLog.i(TAG, "Source Identifier field focused")
                getPalletOrCaseInfo()
            }
            false
        }

        binding.etSourceIdentifier.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                binding.tvSourceIdentifierResponse.text = null
                binding.btnSendToPr.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })

        binding.btnSendToPr.setOnClickListener { callSendToPRAPI() }
    }

    private fun getPalletOrCaseInfo() {
        if (binding.etSourceIdentifier.isFocused && !binding.etSourceIdentifier.text.isNullOrEmpty()) {
            viewModel.getKittingCasePallet(binding.etSourceIdentifier.text.toString(), getString(R.string.kitting_location_class))
        }
    }

    private fun subscribeObservers() {
        observeKittingContainerResponse()
        observeKittingDescriptionResponse()
        observeSendToPrResponse()
    }

    private fun observeKittingDescriptionResponse() {
        viewModel.getKittingDescriptionResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { kittingDescriptionResponse ->
                        if (kittingDescriptionResponse.success) {

                            if(!kittingDescriptionResponse.workOrderLines.isNullOrEmpty()) {

                                // Update Kit Item Name and Item Description
                                val kitItem = KitItem()

                                for (item in kittingDescriptionResponse.workOrderLines) {

                                    if(item.finishedGoods?.isNotEmpty() == true && item.finishedGoods == "F"){
                                        kitItem.kitItemName = item.itmCode
                                        kitItem.kitItemDescription = item.itemDescription
                                    }
                                    else {
                                        kitItem.kitComponents.add(item)
                                    }
                                }

                                viewModel.setKitItem(kitItem)
                            }

                            // Handle Navigation
                            handleKittingContainerResponse()
                        }
                    }
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvSourceIdentifierResponse.text = response.message
                    binding.etSourceIdentifier.requestFocus()
                    binding.etSourceIdentifier.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                }
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun observeKittingContainerResponse() {
        viewModel.getKittingContainerResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { kittingContainerResponse ->
                        if (kittingContainerResponse.success) {

                            viewModel.setPalletResponse(kittingContainerResponse.palletInquiry)
                            if (viewModel.getPalletResponse().containerNumber == null) {
                                viewModel.setItem(viewModel.getPalletResponse().containersList!![0].items!![0])
                            }

                            if(viewModel.getPalletResponse().containerType == "P")
                            {
                                    // Call the API here and get the Kit Item Description
                                viewModel.getKittingItemDescription(viewModel.getPalletResponse().palletId)
                            }else
                            {
                                   // Call the API here and get the Kit Item Description
                                viewModel.getKittingItemDescription(viewModel.getPalletResponse().containerId!!)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    if (response.message != null) {
                        if (response.message.contains("##")) {
                            val msg = response.message.split("##")
                            binding.btnSendToPr.visibility =
                                if (response.message.contains(INV_RC_ERROR_LOCK_CODE)) View.VISIBLE else View.GONE
                            binding.tvSourceIdentifierResponse.visibility =
                                if (response.message.contains(INV_RC_ERROR_LOCK_CODE)) View.VISIBLE else View.GONE
                            binding.tvSourceIdentifierResponse.text = msg[1]
                            if (msg[0] == INV_RC_ERROR_LOCK_CODE) {
                                reasonCode = INV_RC_LOCK_CODE
                            }
                        } else {
                            binding.tvSourceIdentifierResponse.text = response.message
                            binding.btnSendToPr.visibility = View.GONE
                            binding.etSourceIdentifier.requestFocus()
                            binding.etSourceIdentifier.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etSourceIdentifier)
                        }
                    }
                }
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    /** Observe the Packing Status From API*/
    private fun observeSendToPrResponse() {
        viewModel.sendToPRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { sendToPRResponse ->
                        FlareLog.i(TAG,
                            "sendToPRResponse success: $sendToPRResponse"
                        )
                        showSuccessSnackBar(sendToPRResponse.message)
                        refreshUiPostApiResponse()
                    }
                }

                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    response.message?.let { message ->
                        FlareLog.e(TAG,
                            "sendToP API Response error: $message"
                        )
                        showErrorSnackBar(message)
                        refreshUiPostApiResponse()
                    }
                }

                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    /**
     * Update the UI based on sendToPr object response
     */
    private fun refreshUiPostApiResponse() {
        binding.tvSourceIdentifierResponse.text = ""
        binding.etSourceIdentifier.setText("")
        binding.tvSourceIdentifierResponse.visibility = View.GONE
        binding.btnSendToPr.visibility = View.GONE
    }

    fun handleKittingContainerResponse(){
        // Show the Kit Name and
        if (viewModel.getPalletResponse().containerNumber == null) {
            navController.navigate(R.id.action_sourceIdentifierFragment_to_destinationLocationFragment)
        } else {
            if (viewModel.getPalletResponse().containersList?.get(0)?.items!!.size > 1) {
                navController.navigate(R.id.action_sourceIdentifierFragment_to_itemScanFragment)
            } else {
                val item =  viewModel.getPalletResponse().containersList!![0].items?.get(0)
                if (item != null) {
                    viewModel.setItem(item)
                    if(item.lotRequired == "1"){
                        navController.navigate(R.id.action_sourceIdentifierFragment_to_selectLotFragment)
                    }else{
                        navController.navigate(R.id.action_sourceIdentifierFragment_to_moveQtyFragment)
                    }
                }
            }
        }
    }

    /**
     * initiate the api call for Packing Status
     */
    private fun callSendToPRAPI() {
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
        val request = SendToPRRequest(
            fcyId = fcyId,
            custId = custId,
            buId = buId,
            cartonDetailIds = null,
            reasonCode = reasonCode ?: "",
            cartonNumber = binding.etSourceIdentifier.text.toString()
        )
        viewModel.sendToPR(request)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etSourceIdentifier.setText(scan?.barcode.toString())
            binding.etSourceIdentifier.text?.length?.let {
                binding.etSourceIdentifier.setSelection(it)
                viewModel.getKittingCasePallet(binding.etSourceIdentifier.text.toString(), getString(R.string.kitting_location_class))
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}