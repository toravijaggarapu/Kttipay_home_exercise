package com.fsc.flare.ui.fragment.replenish.loadcartpallet


import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishCartPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "ReplenishLoadCartPallet"
@AndroidEntryPoint
class ReplenishLoadCartPalletFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishCartPalletBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishCartPalletBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        binding.tvReplenish.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "GetTaskReplen called")
                    getTaskReplen()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.etCartPallet.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "GetTaskReplen called")
                getTaskReplen()
            }
            false
        }
        binding.etCartPallet.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.txtCartPalletRes.text = null
            }
        })
    }

    private fun subscribeObservers() {
        viewModel.taskReplenResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplen Response: $taskReplenResponse")
                        if (taskReplenResponse.success) {
                            FlareLog.i(TAG, "taskReplen success: $taskReplenResponse")
                            if (taskReplenResponse.cartNbr == null) {
                            } else {
                                viewModel.setReplenTask(taskReplenResponse)
                                if (taskReplenResponse.taskDetails != null) {
                                    viewModel.setReplenTaskDetails(taskReplenResponse.taskDetails)
                                }
                                val action = ReplenishLoadCartPalletFragmentDirections.actionLoadCartPalletToLoadCartContainer()
                                getNavigationController().navigate(action)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskReplen error: $message")
                        binding.txtCartPalletRes.text = message
                        binding.etCartPallet.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etCartPallet)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun getTaskReplen() {
        if (!binding.etCartPallet.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etCartPallet)
            viewModel.getTaskCartReplen(
                TaskReplenCartRequest(
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null)!!,
                    binding.etCartPallet.text.toString()
                )
            )
        } else {
            binding.txtCartPalletRes.text = getString(R.string.cart_pallet_required)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etCartPallet.setText(scan?.barcode.toString())
            binding.etCartPallet.text?.length?.let {
                binding.etCartPallet.setSelection(it)
            }
            getTaskReplen()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}