package com.fsc.flare.ui.fragment.putaway.mixedSBPutaway

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayRequest
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayResponse
import com.fsc.flare.source.data.dto.mixedSBPutaway.PutawayRes
import com.fsc.flare.source.repository.MixedSBPutAwayRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "MixedSBPutAwayViewModel"

@HiltViewModel
class MixedSBPutAwayViewModel @Inject constructor(
    private val mixedSBPutAwayRepository: MixedSBPutAwayRepository
) : BaseViewModel() {

    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()
    val toContainerResponse: MutableLiveData<Resource<MSBPutawayResponse>> = SingleLiveEvent()
    val toLocationResponse: MutableLiveData<Resource<MSBPutawayResponse>> = SingleLiveEvent()
    val serialNumberResponse: MutableLiveData<Resource<MSBPutawayResponse>> = SingleLiveEvent()
    val submitPutawayResponse: MutableLiveData<Resource<MSBPutawayResponse>> = SingleLiveEvent()

    /**
     * method to validate toContainer
     */
    fun validateToContainer(msbPutawayRequest: MSBPutawayRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "validateToContainer Request: $msbPutawayRequest")
            toContainerResponse.postValue(Resource.Loading())
            val response = mixedSBPutAwayRepository.validateToContainer(msbPutawayRequest)
            toContainerResponse.postValue(handleContainerResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    /**
     * method to handle toContainer response
     */
    private fun handleContainerResponse(response: Response<MSBPutawayResponse>): Resource<MSBPutawayResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ToContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        FlareLog.e(TAG, "ToContainerResponse Error: $response.message()")
        return Resource.Error(response.message())
    }

    /**
     * method to validate toLocation
     */
    fun validateToLocation(msbPutawayRequest: MSBPutawayRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "validateToLocation Request: $msbPutawayRequest")
            toLocationResponse.postValue(Resource.Loading())
            val response = mixedSBPutAwayRepository.validateToLocation(msbPutawayRequest)
            toLocationResponse.postValue(handleLocationResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    /**
     * method to handle toLocation response
     */
    private fun handleLocationResponse(response: Response<MSBPutawayResponse>): Resource<MSBPutawayResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ToLocationResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        FlareLog.e(TAG, "ToLocationResponse Error: $response.message()")
        return Resource.Error(response.message())
    }

    /**
     * method to validate serialNumber
     */
    fun validateSerialNumber(msbPutawayRequest: MSBPutawayRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "validateSerialNumber Request: $msbPutawayRequest")
            serialNumberResponse.postValue(Resource.Loading())
            val response = mixedSBPutAwayRepository.validateSerialNumber(msbPutawayRequest)
            serialNumberResponse.postValue(handleLocationResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }
    /**
     * method to submit putaway
     */
    fun submitPutaway(msbPutawayRequest: MSBPutawayRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "submitPutaway Request: $msbPutawayRequest")
            submitPutawayResponse.postValue(Resource.Loading())
            val response = mixedSBPutAwayRepository.submitPutaway(msbPutawayRequest)
            submitPutawayResponse.postValue(handleLocationResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    //data to be saved in view model
    var containerData: MutableLiveData<PutawayRes> = MutableLiveData<PutawayRes>()
    var locationData: MutableLiveData<PutawayRes> = MutableLiveData<PutawayRes>()

    fun setContainerData(putawayRes: PutawayRes) {
        this.containerData.value = putawayRes
    }

    fun getContainerData(): PutawayRes {
        return containerData.value!!
    }

    fun setLocationData(putawayRes: PutawayRes) {
        this.locationData.value = putawayRes
    }

    fun getLocationData(): PutawayRes {
        return locationData.value!!
    }

}