package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryAsnNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.ReceivingASNRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryASNNumberFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [InquiryASNNumberFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InquiryASNNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryAsnNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquiryAsnNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etAsnNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                if (binding.etAsnNumber.isFocused && !binding.etAsnNumber.text.isNullOrEmpty()) {
                    FlareLog.i(TAG, "ASN Number field focused")
                    getASNDetails()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etAsnNumber.isFocused && !binding.etAsnNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "ASN Number field focused")
                        getASNDetails()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etAsnNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvAsnResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to get ASN details from API
     */
    private fun getASNDetails() {
        viewModel.getASNDetails(
            ReceivingASNRequest(
                pageLimit = "1",
                asnNumber = binding.etAsnNumber.text.toString()
            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeASNObserver()
    }


    /**
     * method to subscribe ASN observer
     */
    private fun subscribeASNObserver() {
        viewModel.asnDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { asnDetailsResponse ->
                        if (asnDetailsResponse.inboundShipments != null && asnDetailsResponse.inboundShipments.isNotEmpty()) {
                            val asnDetails = asnDetailsResponse.inboundShipments[0]
                            viewModel.setAsnDetailsData(asnDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                InquiryASNNumberFragmentDirections.actionInquiryAsnNumberFragmentToInquiryAsnPalletNumberFragment()
                            navController.navigate(action)
                        } else {
                            binding.tvAsnResponse.text = resources.getString(R.string.invalid_asn_number)
                            binding.etAsnNumber.requestFocus()
                            binding.etAsnNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etAsnNumber)
                        }

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvAsnResponse.text = message
                        binding.etAsnNumber.requestFocus()
                        binding.etAsnNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etAsnNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etAsnNumber.setText(scan?.barcode.toString())
                binding.etAsnNumber.text?.length?.let {
                    binding.etAsnNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ASN Number field focused")
                    getASNDetails()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}