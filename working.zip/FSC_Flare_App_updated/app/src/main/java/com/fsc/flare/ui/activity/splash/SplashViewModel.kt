package com.fsc.flare.ui.activity.splash

import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.Token
import com.fsc.flare.ui.activity.splash.SplashActivity.Companion.ACTION_REAUTHENTICATE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.CUSTOMER_ENROLLMENT_TYPE
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

private const val TAG = "SplashViewModel"

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    private var mIntent: Intent? = null
    private var mIsReauthentication = false
    val finishReAuthentication: MutableLiveData<String?> = SingleLiveEvent()
    val logoutToast: MutableLiveData<Boolean> = SingleLiveEvent()
    val showReAuthenticateMessage: MutableLiveData<Boolean> = SingleLiveEvent()
    val showLoginCriticalErrorMessage: MutableLiveData<Boolean> = SingleLiveEvent()
    val navigateToHome: MutableLiveData<Boolean> = SingleLiveEvent()
    val showLoginIdMismatch: MutableLiveData<Boolean> = SingleLiveEvent()
    val showProgress: MutableLiveData<Boolean> = SingleLiveEvent()

    var userIdInToken: String? = null
    var userIdScanned: String? = null

    fun initialize(intent: Intent) {
        mIntent = intent

        // Reset Enrollment type value on application load, will be updated back with the enrollment type after customer selection.
        sharedPreferences.edit().putString(CUSTOMER_ENROLLMENT_TYPE, "").apply()

        if (isIntentLoggingOut()) {
            logout()
            return
        }
        when {
            isIntentReAuthentication() -> {
                mIsReauthentication = true
                showReAuthenticateMessage()
            }
            else -> {
                navigateToCoreAppOrRemainHere()
            }
        }
    }

    private fun navigateToCoreAppOrRemainHere() {
        mIsReauthentication = false
        //navigate to home screen
        if (sharedPreferences.getString(PreferenceKeys.LOGIN_TIME, null) != null) {
            navigateToHome.postValue(true)
        }
    }


    private fun showReAuthenticateMessage() {
        showReAuthenticateMessage.postValue(true)
    }

    private fun isIntentReAuthentication(): Boolean {
        return mIntent?.action != null && mIntent?.action == ACTION_REAUTHENTICATE
    }

    private fun logout() {
        Log.i(TAG, "Arrived at authenticate in order to perform logout.")
        mIntent?.removeExtra(SplashActivity.EXTRA_LOGGING_OUT)
        FlareLog.reset()
        clearSharedPreferences()
        showLoggedOutToast()
    }

    private fun showLoggedOutToast() {
        logoutToast.postValue(true)
    }

    private fun clearSharedPreferences() {
        sharedPreferences.apply {
            sharedPreferences.edit().clear().apply()
        }
    }

    fun handleTokenRequestResult(token: Token) {
        if (mIsReauthentication) {
            Log.d(TAG, "ReAuthenticated, re-syncing.")
            finishReAuthentication(token.accessToken)
        } else {
            navigateToHome.postValue(true)
        }
    }

    private fun finishReAuthentication(authToken: String?) {
        finishReAuthentication.postValue(authToken)
    }

    private fun isIntentLoggingOut(): Boolean {
        return mIntent?.getBooleanExtra(SplashActivity.EXTRA_LOGGING_OUT, false) == true
    }
}