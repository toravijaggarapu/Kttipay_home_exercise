package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutBlindCartonBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferNumbers
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.packout.req.PackOutPalletGetReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutFragment"

@AndroidEntryPoint
class PackoutcartonFragment : BaseFragment(), FlareScannable {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutBlindCartonBinding
    lateinit var cb1: CustomVisibilityCallback
    lateinit var adapter: TempLpnsAdapter

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
        if (viewModel.isKitting) {
            if (viewModel.printRequestorDescList.isEmpty()) {
                callGetPrintRequesterListAPI()
            } else {
                initPrinterView()
            }
            if (viewModel.getDefaultPrinter() == null) {
                binding.printEntityDropDown.visibility = View.VISIBLE
                handleCartonViewsVisible(false)
                callToGetPrinterForTheKitStation(viewModel.getLocId())
            } else {
                initDefaultPrinterToView()
            }
        } else {
            handleCartonViewsVisible(true)
        }
    }

    private fun handleCartonViewsVisible(visible: Boolean) {

        if (!visible) {
            binding.etBlindCarton.isEnabled = false
            binding.etBlindCarton.alpha = 0.25f
            binding.btnNewContainer.isEnabled = false
            binding.btnNewContainer.alpha = 0.25f
        } else {
            binding.etBlindCarton.isEnabled = true
            binding.etBlindCarton.alpha = 1f
            binding.btnNewContainer.isEnabled = true
            binding.btnNewContainer.alpha = 1f
        }
    }

    private fun handleContainerCountView() {
        if (viewModel.tempLpnsList.size > 0) {
            binding.lnrContainerList.visibility = View.VISIBLE
            binding.tvTotalCountValue.text =
                viewModel.tempLpnsList.size.toString() + " " + getString(R.string.lbl_view)
            binding.btnEndPackout.isEnabled = true
        } else {
            binding.lnrContainerList.visibility = View.GONE
            binding.btnEndPackout.isEnabled = false
        }
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutBlindCartonBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvLocationValue.text = viewModel.getLocationBarcode()
        if (viewModel.getPalletReqNumber() == "") {
            binding.tvPallet.visibility = View.GONE
        } else {
            binding.tvPalletValue.text = viewModel.getPalletReqNumber()
        }
        binding.btnEndPackout.isEnabled = false
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (viewModel.tempLpnsList.size >= 1) {
            binding.btnEndPackout.isEnabled = true
        }
//        setupRecyclerView()
        if (!viewModel.tempLpnsList.isNullOrEmpty()) {
            binding.lnrCartonsList.visibility = View.VISIBLE
            binding.tvTotalCountValue.text =
                viewModel.tempLpnsList.size.toString() + " " + getString(R.string.lbl_view)
            viewModel.setCartonReqNumber(viewModel.tempLpnsList[viewModel.tempLpnsList.size - 1].containerNumber)
            viewModel.setItemId(viewModel.tempLpnsList[viewModel.tempLpnsList.size - 1].itemId!!.toInt())
        }
        if (viewModel.gettransIdentifier().isNullOrEmpty()) {
            viewModel.tempLpnsList.clear()
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.btnEndPackout.setOnClickListener {
            val action =
                PackoutcartonFragmentDirections.actionPackoutCartonFragementToPackoutstagingFragment()
            moveToFragment(action)
        }

        binding.tvTotalCountValue.setOnClickListener {
            showRecyclerViewInAlertDialog()
        }

        binding.btnNewContainer.setOnClickListener {
            getNewContainerNumber()
        }
        handleContainerCountView()

        binding.printEntityDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            viewModel.setDefaultPrinter(selection)
            handleCartonViewsVisible(true)
            binding.printRequestorName.text = selection
            binding.printEntityDropDown.visibility = View.GONE
            binding.changePrintRequestor.visibility = View.VISIBLE
        }

        binding.changePrintRequestor.setOnClickListener {
            binding.printEntityDropDown.visibility = View.VISIBLE
            binding.changePrintRequestor.visibility = View.GONE
        }

        binding.etBlindCarton.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                //binding.containerIdResponse.text = null
                binding.etBlindCartonRes.text = null
            }
        })

        binding.etBlindCarton.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }

    }

    /**
     * method to generate container from API
     */
    private fun getNewContainerNumber() {
        //Call new container API.
        viewModel.generateCaseNumber(viewModel.newCaseNumberKey)
    }

    fun showRecyclerViewInAlertDialog() {
        // Inflate the custom dialog layout
        val inflater = LayoutInflater.from(context)
        val customDialogView = inflater.inflate(R.layout.custom_recyclerview_dialog_layout, null)

        // Find your existing RecyclerView in the custom layout
        val recyclerView = customDialogView.findViewById<RecyclerView>(R.id.rvCartons)
        recyclerView.adapter = TempLpnsAdapter(viewModel.tempLpnsList)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Create and show the AlertDialog with your custom content
        val alertDialogBuilder = AlertDialog.Builder(fragmentContext)
            .setTitle(getString(R.string.lbl_containers_packed_out_from_the_scanned_location))
            .setView(customDialogView)
            .setNegativeButton("Cancel") { dialog, _ ->
                // Handle the Cancel button click if needed
                dialog.dismiss()
            }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }

//    private fun setupRecyclerView() {
//        binding.rvCartons.layoutManager = LinearLayoutManager(fragmentContext)
//        adapter = TempLpnsAdapter(viewModel.tempLpnsList)
//        binding.rvCartons.adapter = adapter
//        adapter.notifyDataSetChanged()
//    }

    private fun packOutCartonCall() {
        viewModel.validateCartonId(
            PackOutPalletGetReq(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                ibCartonNumber = binding.etBlindCarton.text.toString(),
                palletNumber = viewModel.getPalletReqNumber()
            )
        )
    }

    var isNewContainer: Boolean = false

    private fun subscribeObservers() {
        subscribeInventoryContainerObserver()

        viewModel.printerForTheKitStationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { kittingStageLocResponse ->
                        if (kittingStageLocResponse.success != null && kittingStageLocResponse.orderProcessingLocations.isNotEmpty()) {
                            viewModel.setDefaultPrinter(kittingStageLocResponse.orderProcessingLocations[0].printerName)
                            initDefaultPrinterToView()
                        } else {
                            binding.changePrintRequestor.visibility = View.GONE
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "KitStationPrinter error: $message")
                        showErrorSnackBar(message)
                        binding.changePrintRequestor.visibility = View.GONE
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printRequestorResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printRes ->
                        if (printRes.printerConfigs.isNotEmpty()) {
                            printRes.printerConfigs.forEach {
                                viewModel.printRequestorDescList.add(it.requestor)
                                viewModel.printRequestorHashmap.put(it.requestor, it)
                            }
                            initPrinterView()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.validateCartonIdResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutCarton response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "PackOutCarton Success:${response}")
                            if (!response.lpnTemp.isNullOrEmpty()) {
                                viewModel.settransIdentifier(response.lpnTemp[0].transactionIdentifier)
                            }
                            viewModel.setPackOutCartonResponse(response)
                            binding.etBlindCartonRes.text = null
                            viewModel.setCartonReqNumber(binding.etBlindCarton.text.toString())
                            isNewContainer = false
                            checkDekkitting()
                        } else {
                            //  FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                            // Todo error message changes
                            binding.etBlindCartonRes.text = response.errors.errorMessage
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackOutCarton Error:$message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //New container generate response
        viewModel.newContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Container number.
                            var newContainerNumber = ""
                            var list = generatePalletCaseNumberResponse.numbers.filter { palletValue:CaseTransferNumbers -> (palletValue.type!=viewModel.palletTransferTypeKey) }
                           if(!list.isNullOrEmpty()) {
                               newContainerNumber = list.first().value
                           }

                            if (newContainerNumber.isNotEmpty()) {
                                isNewContainer = true
                                binding.etBlindCartonRes.text = null
                                viewModel.setCartonReqNumber(newContainerNumber)
                                if (viewModel.getTpData() == viewModel.palletizeCartonsTransValue) {
                                    if (sharedPreferences.getBoolean(
                                            PreferenceKeys.FOLLOW_ITEM_UOMS,
                                            false
                                        ) && viewModel.ispalletUomConfigured
                                    ) {
                                        if (viewModel.tempLpnsList.size < viewModel.caseQtyForPallet) {
                                            checkDekkitting()
                                        } else {
                                            binding.etBlindCartonRes.text =
                                                getString(R.string.lbl_max_pallet_capacity_is_reached)
                                        }
                                    } else {
                                        checkDekkitting()
                                    }
                                } else {
                                    checkDekkitting()
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun getLockCodesFromContainer() {
        // check and pass palletnumber if we can get locks
        val cartonNumber = viewModel.getcartonReqNumber()
        viewModel.getContainer(cartonNumber, "Y")
    }

    private fun subscribeInventoryContainerObserver() {
        viewModel.inventoryContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (!containerResponse.container.isNullOrEmpty()) {
                            val containerData = containerResponse.container[0]
                            viewModel.containerLockCode = ""
                            containerData.lockCodes?.forEach {
                                it.lockCode?.let { lockCode ->
                                    if (!lockCode.isNullOrEmpty() && lockCode != viewModel.ASN_LOCK_CODE) {
                                        viewModel.containerLockCode = lockCode
                                    }
                                }
                            }
                        }
                    }
                    navigateToItemFrag()
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        Log.i(TAG, message)
                    }
                    navigateToItemFrag()
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun initDefaultPrinterToView() {
        if (viewModel.printRequestorDescList.isNotEmpty() && viewModel.printRequestorDescList.contains(
                viewModel.getDefaultPrinter()
            )
        ) {
            binding.printEntityDropDown.setSelectedValue(viewModel.getDefaultPrinter())
        }
    }

    private fun initPrinterView() {
        if (viewModel.isKitting) {
            binding.printRequesterLayout.visibility = View.VISIBLE
            binding.printEntityDropDown.setOptions(null)
            if (viewModel.printRequestorDescList.isNotEmpty())
                binding.printEntityDropDown.setOptions(viewModel.printRequestorDescList)
        }
    }

    private fun checkDekkitting() {
         if(viewModel.tempLpnsList.isNullOrEmpty()){
             viewModel.containerLockCode = ""
             if (isNewContainer) {
                 navigateToItemFrag()
             } else {
                 getLockCodesFromContainer()
             }
         }
         else {
            for (container in viewModel.tempLpnsList) {
                if (!container.lockCode.isNullOrEmpty() && container.lockCode != viewModel.ASN_LOCK_CODE) {
                    viewModel.containerLockCode = container.lockCode
                    break
                }
            }
             navigateToItemFrag()
         }
    }

    private fun navigateToItemFrag() {
        val action =
            PackoutcartonFragmentDirections.actionPackoutCartonFragementToPackoutitemFragement()
        getNavigationController().navigate(action)
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etBlindCarton)

        if (!binding.etBlindCarton.text?.trim().isNullOrEmpty()) {
            FlareLog.i(TAG, "CartonId field focused")
            val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
            val containerNumber = binding.etBlindCarton.text.toString()
            if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.etBlindCartonRes.text =
                    getString(
                        R.string.container_prefix_length_validation,
                        containerType.ctyId,
                        containerType.ctyContainerLength
                    )
            } else {
                if ((viewModel.getTempTableLpnsList()
                        .map { it.containerNumber }).contains(binding.etBlindCarton.text.toString())
                ) {
                    binding.etBlindCartonRes.text =
                        getString(R.string.case_transfer_container_already_scanned)
                } else if (viewModel.getTpData() != viewModel.palletizeCartonsTransValue) {
                    packOutCartonCall()
                } else {
                    if (sharedPreferences.getBoolean(
                            PreferenceKeys.FOLLOW_ITEM_UOMS,
                            false
                        ) && viewModel.ispalletUomConfigured
                    ) {
                        if (viewModel.tempLpnsList.size < viewModel.caseQtyForPallet) {
                            packOutCartonCall()
                        } else {
                            binding.etBlindCartonRes.text =
                                getString(R.string.lbl_max_pallet_capacity_is_reached)
                        }
                    } else {
                        packOutCartonCall()
                    }
                }
            }
        } else {
            binding.etBlindCartonRes.text = resources.getString(R.string.lbl_enter_carton_number)
        }
    }

    private fun callGetPrintRequesterListAPI() {
        viewModel.getPrintRequesterList(
            PrinterConfigRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                page = 0,
                pageLimit = 100,
                printerType = "LBL"
            )
        )
    }

    private fun callToGetPrinterForTheKitStation(locationId: Int) {
        viewModel.getPrinterForTheKitStation(locationId)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etBlindCarton.setText(scan?.barcode.toString())
        binding.etBlindCarton.text?.length?.let {
            binding.etBlindCarton.setSelection(it)
        }
        FlareLog.i(TAG, "location field focused")
        validateField()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}