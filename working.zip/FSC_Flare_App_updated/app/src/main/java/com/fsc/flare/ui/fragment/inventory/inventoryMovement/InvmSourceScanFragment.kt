package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSourceScanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSourceScanViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.NavigationFromInvmSourceScan
import com.fsc.flare.utils.Constants.TaskModes.SYSTEM_DIRECTED
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "InvmSourceScanFragment"

@AndroidEntryPoint
class InvmSourceScanFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmSourceScanViewModel by viewModels()
    private lateinit var binding: FragmentSourceScanBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentSourceScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null).plus(" - ").plus(sharedViewModel.selectedTaskMode)
        setupUI()
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        handleSkipButtonClick()
        observeEvents()
    }

    private fun setTextChangedListener() {
        binding.scanSource.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun handleSkipButtonClick() {
        binding.skipTaskBtn.setOnClickListener {
            binding.scanSource.text = null
            viewModel.skipTask(sharedViewModel.selectedTaskGroup?.allocationType, sharedViewModel.taskDetails.taskId)
        }
    }

    private fun setupUI() {
        if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED) {
            binding.taskDetailsGroup.visibility = View.VISIBLE
            binding.skipTaskBtn.visibility = View.VISIBLE
            binding.taskDetails = sharedViewModel.taskDetails
            binding.scanSource.hint = getString(R.string.source_id)
            binding.sourceTextView.text = getString(R.string.source_id)
            binding.executePendingBindings()
        } else {
            binding.scanSource.hint = getString(R.string.source_pallet_container_location)
            binding.sourceTextView.text = getString(R.string.source_pallet_container_location)
        }
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.incProgressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { message ->
            if (message.isNotEmpty()) {
                binding.scanSource.selectAll()
            }
            binding.errResponse.text = message ?: ""
        }

        viewModel.skipTaskResponse.observe(viewLifecycleOwner){taskDetails ->
            sharedViewModel.taskDetails = taskDetails
            setupUI()
        }

        viewModel.navigateToScreen.observe(viewLifecycleOwner) { inventoryNavigation ->
            when (inventoryNavigation) {

                is NavigationFromInvmSourceScan.NavigateReasonCodes -> {
                    sharedViewModel.sourceDetails = inventoryNavigation.sourceDetails
                    binding.scanSource.text = null
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    getNavigationController().navigate(InvmSourceScanFragmentDirections.actionInvmSourceScanFragmentToInvmReasonCodeSelectFragment())
                }

                is NavigationFromInvmSourceScan.NavigateItemAndQty -> {
                    sharedViewModel.sourceDetails = inventoryNavigation.sourceDetails
                    binding.scanSource.text = null
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    getNavigationController().navigate(InvmSourceScanFragmentDirections.actionInvmSourceScanFragmentToInvmItemAndQtyScanViewModel())
                }

                is NavigationFromInvmSourceScan.NavigateContainerScan -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    showAlertDialog(
                        title = "",
                        message = inventoryNavigation.message,
                        onPositiveClick = {
                            navigateToContainerScanScreen()
                        }
                    )
                }
            }
        }

        viewModel.getDestinationLocation.observe(viewLifecycleOwner) { response ->
            response?.let {
                sharedViewModel.getDestinationLocationResponse = response
                binding.scanSource.text = null
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                getNavigationController().navigate(InvmSourceScanFragmentDirections.actionInvmSourceScanFragmentToInvmDestinationLocationFragment())
            }
        }
    }

    private fun navigateToContainerScanScreen() {
        binding.scanSource.text = null
        getNavigationController().navigate(InvmSourceScanFragmentDirections.actionInvmSourceScanFragmentToInvmContainerScanFragment())
    }

    private fun handleEnterKeyEvent() {
        binding.scanSource.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateSource()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.scanSource.isFocused && !binding.scanSource.text.isNullOrEmpty()) {
                            validateSource()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateSource() {
        if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED) {
            if (sharedViewModel.taskDetails.containerNbr == binding.scanSource.text.toString().trim()) {
                viewModel.getDestinationLocation(binding.scanSource.text.toString().trim(), sharedViewModel.taskDetails.reasonCode ?: "")
            } else {
                binding.errResponse.text = getString(R.string.invalid_source_id)
            }
        } else {
            sharedViewModel.sourceId = binding.scanSource.text.toString().trim()
            viewModel.validateSourceInput(binding.scanSource.text.toString().trim())
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        binding.scanSource.setText(scan?.barcode.toString())
        binding.scanSource.text?.length?.let {
            binding.scanSource.setSelection(it)
        }
        validateSource()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}