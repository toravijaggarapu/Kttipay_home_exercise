package com.fsc.flare.ui.fragment.palletizecarton

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeCartonBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.palletize.PalletizeRequest
import com.fsc.flare.source.data.dto.palletize.PalletizeResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeCartonFragment"
private const val ARG_PARAM1 = "screenTagName"
private const val OB_CARTON_TIED_TO_ANOTHER ="OB_CARTON_TIED_TO_ANOTHER"
private const val RECORD_EXISTS_WITH_PALLET_NUM = "RECORD_EXISTS_WITH_PALLET_NUM"

@AndroidEntryPoint
class PalletizeCartonFragment : BaseFragment(), FlareScannable {

    val RECALL_PALLETIZE_ERROR_CASES_UOM = "ERR-PAL-100"
    val RECALL_PALLETIZE_ERROR_EACHES_UOM = "ERR-PAL-101"
    val RECALL_DE_PALLETIZE_ERROR_LTL_UOM = "ERR-DPL-001"
    val RECALL_DE_PALLETIZE_ERROR_PARCEL_UOM = "DPL-001"
    val RECALL_LOCK_CODE = "RC"

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var screenTagName: String? = null

    private val viewModel: PalletizeViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeCartonBinding
    lateinit var cb1: CustomVisibilityCallback
    private var caseNbrList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            arguments?.let {
                screenTagName = it.getString(ARG_PARAM1)
            }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }


    var containerNumber:String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizeCartonBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.carton.isFocused && !binding.carton.text?.trim().isNullOrEmpty()) {

                        containerNumber = binding.carton.text?.trim().toString()

                        FlareLog.i(TAG, "Carton field focused")
                        binding.cartonResponse.text = null
                        if (screenTagName!!.contains("DE")) {
                            dePalletizeCarton(false)
                        } else {
                            checkforCartonsInTote()
                        }
                    }else {
                        binding.cartonResponse.text = resources.getString(R.string.lbl_enter_valid_carton_number)
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.carton.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.carton)
                binding.cartonResponse.text = null
                containerNumber = binding.carton.text?.trim().toString()
                FlareLog.i(TAG, "Carton field focused")
                if (screenTagName!!.contains("DE")) {
                    dePalletizeCarton(false)
                } else {
                    checkforCartonsInTote()
                }
            }
            false
        }

        val containerListData = viewModel.getContainerInfo()
        if (containerListData != null) {
            if (containerListData.isNotEmpty()) {
                val containerData = containerListData[0]
                binding.pallet.text = containerData.containerNumber
            } else {
                binding.pallet.text = sharedPreferences.getString(PreferenceKeys.Inventory.CONTAINER_NUMBER, "")
            }
        }
        binding.endPalletize.setOnClickListener {
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            navController.popBackStack()
        }
        binding.carton.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.cartonResponse.text = null
            }
        })

        binding.tvTotalCountValue.setOnClickListener {
            if (caseNbrList.size > 0)
                showScannedContainersList()
        }

        subscribeObservers()
        resetViews()
    }


    private fun checkforCartonsInTote() {
        viewModel.getCartonDetailsFromTote(containerNumber,"")
    }

    /**
     * method to palletize carton
     */
    private fun palletizeCarton(containerNbr:String) {
        val containerListData = viewModel.getContainerInfo()
        if (!containerListData.isNullOrEmpty()) {
            val containerData = containerListData[0]
            viewModel.palletize(
                PalletizeRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    newpallet = false,
                    obContainerNbr = containerNbr,
                    overrideExistingPallet = false,
                    palletId = containerData.containerId,
                    palletNbr = containerData.containerNumber,
                    palletize = true
                )
            )
        } else {
            viewModel.palletize(
                PalletizeRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    newpallet = true,
                    obContainerNbr = containerNbr,
                    overrideExistingPallet = false,
                    palletId = null,
                    palletNbr = sharedPreferences.getString(
                        PreferenceKeys.Inventory.CONTAINER_NUMBER,
                        ""
                    )!!,
                    palletize = true
                )
            )
        }
    }

    /**
     * method to depalletize carton
     */
    private fun dePalletizeCarton(markPalletForPR:Boolean) {
        val containerListData = viewModel.getContainerInfo()
        if (containerListData != null) {
            if (containerListData.isNotEmpty()) {
                val containerData = containerListData[0]
                viewModel.depalletize(
                    PalletizeRequest(
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        newpallet = false,
                        containerNumber,
                        overrideExistingPallet = false,
                        palletId = containerData.containerId,
                        palletNbr = containerData.containerNumber,
                        palletize = false,
                        markPalletForPR = markPalletForPR
                    )
                )
            }
        }
    }

    /**
     * method to override palletize carton
     */
    private fun palletizeOverrideCarton(message: String) {
        binding.cartonResponse.text = null
        val containerListData = viewModel.getContainerInfo()
        if (containerListData != null) {
            if (containerListData.isNotEmpty()) {
                val containerData = containerListData[0]
                MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                    //.setTitle(message)
                    .setMessage(resources.getString(R.string.lbl_are_you_sure_want_to_associate_with_the_pallet, containerNumber,containerData.containerNumber))
                    .setPositiveButton(getString(R.string.alert_button_yes)) { dialogInterface, i ->
                        dialogInterface.dismiss()
                        viewModel.palletize(
                            PalletizeRequest(
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                newpallet = false,
                                containerNumber,
                                overrideExistingPallet = true,
                                palletId = containerData.containerId,
                                palletNbr = containerData.containerNumber,
                                palletize = true
                            )
                        )
                    }
                    .setNegativeButton(getString(R.string.alert_button_no)) { dialogInterface, i ->
                        dialogInterface.dismiss()
                        resetViews()
                    }
                    .setCancelable(false)
                    .show()
            } else {
                MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                    //.setTitle(message)
                    .setMessage(
                        resources.getString(R.string.lbl_are_you_sure_want_to_associate_with_the_pallet,containerNumber,sharedPreferences.getString(
                            PreferenceKeys.Inventory.CONTAINER_NUMBER,
                            ""
                        )!!
                        )
                    )
                    .setPositiveButton(getString(R.string.alert_button_yes)) { dialogInterface, i ->
                        dialogInterface.dismiss()
                        viewModel.palletize(
                            PalletizeRequest(
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                newpallet = true,
                                containerNumber,
                                overrideExistingPallet = true,
                                palletNbr = sharedPreferences.getString(PreferenceKeys.Inventory.CONTAINER_NUMBER, "")!!,
                                palletize = true
                            )
                        )
                    }
                    .setNegativeButton(getString(R.string.alert_button_no)) { dialogInterface, i ->
                        dialogInterface.dismiss()
                        resetViews()
                    }
                    .setCancelable(false)
                    .show()
            }
        }
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
       subscribePalletizeObserver()
       subscribeDePalletizeObserver()
       subscribeSentToPRObserver()
    }

    private fun subscribePalletizeObserver() {
        viewModel.cartonDetailsFromToteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    response.data?.let { cartonDetailsFromToteResponse ->
                        if (cartonDetailsFromToteResponse.success && !cartonDetailsFromToteResponse.cartons.isNullOrEmpty() && cartonDetailsFromToteResponse.cartons.size > 1) {
                            hideProgressBar()

                            var containerNumberSelected = ""
                            val containersList = ArrayList<String>()
                            for(carton in cartonDetailsFromToteResponse.cartons){
                                containersList.add(carton.obContainerNumber)
                            }

                            MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
                                .setTitle(resources.getString(R.string.select_container_associated_with_the_tote,containerNumber))
                                .setSingleChoiceItems(containersList.toTypedArray(), -1) { dialog_, index ->
                                    containerNumberSelected = containersList[index]
                                }
                                .setPositiveButton(getString(R.string.alert_button_ok)) { dialogInterface, i ->
                                    dialogInterface.dismiss()
                                    if(containerNumberSelected.isNotEmpty()) {
                                        containerNumber = containerNumberSelected
                                        palletizeCarton(containerNumber)
                                    }
                                }
                                .setNegativeButton(getString(R.string.alert_button_cancel)) { dialogInterface, i ->
                                    dialogInterface.dismiss()
                                    resetViews()
                                }
                                .setCancelable(false)
                                .show()
                        }
                        else {
                            palletizeCarton(containerNumber)
                        }
                    }
                }

                is Resource.Error -> {
                   palletizeCarton(containerNumber)
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.palletizeCartonResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletizeResponse ->
                        handlePalletizeResponse(palletizeResponse)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        handlePalletizeContainerErrorResponse(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeSentToPRObserver() {
        viewModel.sendToPRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                        binding.carton.setText("")
                        response.data?.let { sendToPRResponse ->
                            FlareLog.i(TAG, "sendToPRResponse success: $sendToPRResponse")
                            showSuccessSnackBar(sendToPRResponse.message)
                        }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "sendToPRResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeDePalletizeObserver() {
        viewModel.dePalletizeCartonResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletizeResponse ->
                        handlePalletizeResponse(palletizeResponse)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        handleDePalletizeContainerErrorResponse(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handlePalletizeResponse(palletizeResponse: PalletizeResponse){
        if (palletizeResponse.success) {
            if (palletizeResponse.messageCode != null && palletizeResponse.messageCode == OB_CARTON_TIED_TO_ANOTHER ) {
                palletizeOverrideCarton(palletizeResponse.message)
            } else if (palletizeResponse.messageCode == RECORD_EXISTS_WITH_PALLET_NUM && palletizeResponse.messageCode != null) {
                showSuccessSnackBar(palletizeResponse.message)
                palletizeExistingPallet(palletizeResponse.palletId)
            } else {
                if (screenTagName!!.contains("DE")) {
                    if (caseNbrList.contains(binding.carton.text.toString()))
                        caseNbrList.remove(binding.carton.text.toString())
                } else {
                    if (!caseNbrList.contains(binding.carton.text.toString()))
                        caseNbrList.add(binding.carton.text.toString())
                }
                resetViews()
                showSuccessSnackBarStd(palletizeResponse.message){}
            }
        }
    }

    private fun resetViews() {
        binding.carton.text = null
        containerNumber = ""
        binding.cartonResponse.text = null
        if (caseNbrList.isNotEmpty()){
            binding.lnrContainerList.visibility = View.VISIBLE
        } else {
            binding.lnrContainerList.visibility = View.GONE
        }
    }

    /**
     * method to palletize with existing pallet
     */
    private fun palletizeExistingPallet(palletId: Int) {
        binding.cartonResponse.text = null
        viewModel.palletize(
            PalletizeRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                newpallet = false,
                obContainerNbr = containerNumber,
                overrideExistingPallet = true,
                palletId = palletId,
                palletNbr = sharedPreferences.getString(PreferenceKeys.Inventory.CONTAINER_NUMBER, "")!!,
                palletize = true
            )
        )
    }

    private fun showScannedContainersList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.containers_scanned))

        builder.setItems(caseNbrList.toTypedArray(), null)
        builder.setNegativeButton(getString(R.string.alert_button_cancel)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.carton.setText(scan?.barcode.toString())
            binding.carton.text?.length?.let {
                binding.carton.setSelection(it)
            }
            if (!binding.carton.text?.trim().isNullOrEmpty()) {
                containerNumber = binding.carton.text?.trim().toString()

                FlareLog.i(TAG, "Carton field focused")
                binding.cartonResponse.text = null
                if (screenTagName!!.contains("DE")) {
                    dePalletizeCarton(false)
                } else {
                    checkforCartonsInTote()
                }

            }else{
                binding.cartonResponse.text = resources.getString(R.string.lbl_enter_valid_carton_number)
            }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    fun callSendToPRAPI() {
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)

        val containerDetailList = emptyList<Int>()
        val cartonNumber = binding.carton.text?.trim().toString()

        val request = SendToPRRequest(fcyId,custId,buId,containerDetailList, cartonNumber, RECALL_LOCK_CODE)
        viewModel.sendToPR(request)
    }

    private fun handleDePalletizeContainerErrorResponse(msg: String) {
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            when {
                errorMessage[0].equals(RECALL_DE_PALLETIZE_ERROR_LTL_UOM, ignoreCase = true) ||
                        errorMessage[0].equals(RECALL_DE_PALLETIZE_ERROR_PARCEL_UOM, ignoreCase = true)
                -> {
                    displayDePalletizeErrorAlert(responseMessage)
                }
                else -> {
                    displayErrorMessage(responseMessage)
                }
            }
    }

    private fun displayDePalletizeErrorAlert(responseMessage:String){
        showAlertDialog(title="",
            message = responseMessage,
            onPositiveClick = {
                dePalletizeCarton(markPalletForPR = true)
            },
            onNegativeClick = {}
        )
    }

    private fun displayErrorMessage(responseMessage:String){
        binding.cartonResponse.text = responseMessage
        binding.carton.selectAll()
        showSoftKeyBoard(fragmentContext, binding.carton)
    }

    private fun displaySendToPRAlert(responseMessage:String){
        val positiveButton = resources.getString(R.string.SEND_TO_PR)
        showAlertDialog(
            title = "",
            message = responseMessage,
            positiveButton = positiveButton,
            negativeButton = getString(R.string.cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    callSendToPRAPI()
                }
                override fun onNegativeButtonClick() {

                }
            }
        )
    }

    private fun handlePalletizeContainerErrorResponse(msg: String) {
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            when {
                errorMessage[0].equals(RECALL_PALLETIZE_ERROR_CASES_UOM, ignoreCase = true) ||
                        errorMessage[0].equals(RECALL_PALLETIZE_ERROR_EACHES_UOM, ignoreCase = true)
                -> {
                    displaySendToPRAlert(responseMessage)
                }
                else -> {
                    displayErrorMessage(responseMessage)
                }
            }
    }

}