package com.fsc.flare.ui.fragment.loadunloadtrailer.loadtrailer

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogPalletLoadBinding
import com.fsc.flare.databinding.FragmentLoadCartonPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.ContainerStatus
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerPatchRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.Pallet
import com.fsc.flare.source.data.dto.loadunloadtrailer.ValidationResult
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.ui.fragment.loadunloadtrailer.LoadUnloadViewModel
import com.fsc.flare.ui.fragment.loadunloadtrailer.PalletAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private val TAG = LoadCartonPalletFragment::class.java.simpleName.toString()
private const val PALLET_LOAD_SUCCESS_MSG_CODE = "PALLET_LOAD_SUCCESS"

@AndroidEntryPoint
class LoadCartonPalletFragment : BaseFragment(), FlareScannable {
    private val viewModel: LoadUnloadViewModel by activityViewModels()
    private lateinit var binding: FragmentLoadCartonPalletNumberBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLoadCartonPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.etCartonPallet.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpViews()
    }

    /**
     * Function to set up views with data
     */
    private fun setUpViews() {
        val dockDoorShipmentData = viewModel.dockDoorShipment
        dockDoorShipmentData?.let {
            binding.tvTotalStopValue.text = it.totalStops.toString()
        }
        viewModel.loadTrailer?.let { data ->
            // Set Trailer information
            binding.apply {
                tvShipmentNumberValue.text = data.shipmentNumber
                tvCartonPalletValue.text = data.palletNumber
                tvLoadingStopValue.text = data.stopSequence.toString()
                tvStagingLocationValue.text = data.stageLocationName
            }

            // Setup click listener and update pallet count
            data.palletsForStop?.let { palletList ->
                val loadedPalletsListSize = palletList.count { it.status == ContainerStatus.LOADED_ON_TRUCK.code }
                val totalPalletsToLoadSize = palletList.size
                binding.tvCartonPalletCountValue.text = getString(
                    R.string.lbl_carton_pallet_count_value,
                    loadedPalletsListSize,
                    totalPalletsToLoadSize
                )

                binding.tvCartonPalletCountView.setOnClickListener {
                    showPalletLoadStatusDialog(palletList)
                }
            }
        }
    }

    /**
     * Function to display pallet load status dialog
     */
    private fun showPalletLoadStatusDialog(palletList: List<Pallet>) {
        val dialogView = LayoutInflater.from(fragmentContext).inflate(R.layout.dialog_pallet_load, null)
        val binding = DataBindingUtil.bind<DialogPalletLoadBinding>(dialogView)

        binding?.run {
            titleTextView.text = getString(R.string.lbl_pallet_load_unload_status)
            // Set up the RecyclerView with the adapter
            palletRecyclerView.layoutManager = LinearLayoutManager(fragmentContext) // Set LayoutManager
            palletRecyclerView.adapter = PalletAdapter(palletList)

            val dividerItemDecoration = DividerItemDecoration(
                palletRecyclerView.context,
                DividerItemDecoration.VERTICAL
            )
            //set a custom drawable
            dividerItemDecoration.setDrawable(ContextCompat.getDrawable(fragmentContext, R.drawable.item_divider)!!)
            // Add the divider decoration
            palletRecyclerView.addItemDecoration(
                dividerItemDecoration
            )
        }

        // show the dialog
        val dialog = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setView(dialogView)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ -> dialog.dismiss() }
            .create()
        dialog.show()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            etCartonPallet.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    tvCartonPalletResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })

            btnEnd.setOnClickListener {
                navigateToDockDoorFragment()
            }

            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (etCartonPallet.isFocused && !etCartonPallet.text.isNullOrEmpty()) {
                            FlareLog.i(TAG, "Carton/Pallet field focused")
                            validateOBContainer()
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            etCartonPallet.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, etCartonPallet)
                    FlareLog.i(TAG, "Carton/Pallet field focused")
                    validateOBContainer()
                }
                return@setOnEditorActionListener false
            }
        }

    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to validate OB Container
     */
    private fun validateOBContainer() {
        val obContainerNumber = binding.etCartonPallet.text.toString().trim()
        viewModel.obCartonDetailsRequest(obContainerNumber = obContainerNumber)
    }



    /**
     * Function to validate pallet/carton and call load trailer patch api
     */
    private fun validateCartonPallet() {
        val data = viewModel.loadTrailer
        val palletToLoad = binding.etCartonPallet.text.toString()

        data?.let { loadTrailerResponse ->
            val validationResult = validatePalletNumber(loadTrailerResponse, palletToLoad)

            if (validationResult.isValidPallet) {
                validationResult.containerId?.let { palletId ->
                    callLoadTrailerPatchAPI(palletId)
                }
            } else {
                handleInvalidPallet(validationResult.isOverrideActive)
            }
        }
    }

    /**
     * Function to handle Invalid Pallet
     */
    private fun handleInvalidPallet(isOverrideActive: Boolean) {
        val palletToload = binding.etCartonPallet.text.toString()
        binding.tvCartonPalletResponse.text = if (isOverrideActive) {
            val loadTrailerResponse = viewModel.loadTrailer ?: return
            loadTrailerResponse.palletsForStop?.asSequence()
                ?.filter { it.status == ContainerStatus.LOADED_ON_TRUCK.code }
                ?.find { it.containerNumber == palletToload }
                ?.let {
                    getString(R.string.lbl_is_already_loaded, it.containerNumber)
                } ?: getString(R.string.lbl_invalid_pallet_to_load)
        } else {
            getString(R.string.lbl_given_pallet_is_not_the_system_directed_pallet)
        }
        binding.etCartonPallet.requestFocus()
        binding.etCartonPallet.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etCartonPallet)
    }

    /**
     * Function to validate Pallet Number from Same Stop
     */
    private fun validatePalletNumber(
        response: LoadTrailerResponse,
        inputPalletNumber: String
    ): ValidationResult {
        val isOverrideActive = sharedPreferencesBase.getBoolean(PreferenceKeys.LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE, false)

        return if (isOverrideActive) {
            // Filter pallets and check for a match
            response.palletsForStop?.asSequence()
                ?.filter { it.status == ContainerStatus.OUTBOUND_STAGED.code }
                ?.find { it.containerNumber == inputPalletNumber }
                ?.let { matchingPallet ->
                    ValidationResult(isOverrideActive = true, isValidPallet = true, containerId = matchingPallet.containerId)
                } ?: ValidationResult(isOverrideActive = true, isValidPallet = false)
        } else {
            // Direct comparison when override is not active
            if (inputPalletNumber == response.palletNumber) {
                ValidationResult(isOverrideActive = false, isValidPallet = true, containerId = response.palletId)
            } else {
                ValidationResult(isOverrideActive = false, isValidPallet = false)
            }
        }
    }

    /**
     * Function to call load trailer patch API
     */
    private fun callLoadTrailerPatchAPI(palletId: Int) {
        val data = viewModel.loadTrailer
        if (data != null) {
            viewModel.loadTrailerPatch(
                LoadTrailerPatchRequest(
                    buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                    palletId = palletId,
                    shipmentId = data.shipmentId,
                    stopSequence = data.stopSequence
                )
            )
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeLoadTrailerPatchObserver()
        observeOBContainerResponse()
        observeSendToPRAPIResponse()
        observeRecallContainersResponse()
    }

    /**
     * Function to subscribe Load Trailer Patch response
     */
    private fun subscribeLoadTrailerPatchObserver() {
        viewModel.loadTrailerPatchResponse.observe(viewLifecycleOwner) { loadTrailerPatchResponse ->
            when (loadTrailerPatchResponse) {
                is Resource.Success -> {
                    handleLoadTrailerPatchSuccessResponse(loadTrailerPatchResponse.data)
                }
                is Resource.Error -> {
                    handleLoadTrailerPatchErrorResponse(loadTrailerPatchResponse.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Load Trailer Patch api
     */
    private fun handleLoadTrailerPatchSuccessResponse(data: LoadTrailerResponse?) {
        data?.let { trailerPatchResponse ->
            if(trailerPatchResponse.success) {
                hideProgressBar()
                showSuccessSnackBarStd(trailerPatchResponse.message) {
                    when {
                        trailerPatchResponse.messageCode != null && trailerPatchResponse.messageCode == PALLET_LOAD_SUCCESS_MSG_CODE -> {
                            navigateToDockDoorFragment()
                        }
                        else -> {
                            viewModel.loadTrailer = trailerPatchResponse
                            binding.etCartonPallet.text = null
                            binding.etCartonPallet.requestFocus()
                            setUpViews()
                        }
                    }
                }
            } else {
                handleLoadTrailerPatchErrorResponse(trailerPatchResponse.message)
            }
        }
    }

    /**
     * Nav Handler to dockdoor fragment
     */
    private fun navigateToDockDoorFragment() {
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.LoadDockDoorFragment, true).build()
        getNavigationController().navigate(
            R.id.action_loadCartonPalletFragment_to_loadDockDoorFragment,
            null,
            navOptions
        )
    }

    /**
     * Function to handle load trailer error response
     */
    private fun handleLoadTrailerPatchErrorResponse(errorMessage: String?) {
        hideProgressBar()
        errorMessage?.let { message ->
            showErrorSnackBar(message)
            binding.etCartonPallet.requestFocus()
            binding.etCartonPallet.selectAll()
        }
    }

    /**
     * Function to observe OB Container Response
     */
    private fun observeOBContainerResponse() {
        viewModel.obContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObContainerSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObContainerErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleObContainerSuccessResponse(response: ValidateCartonHandlerTypeResponse?) {
        response?.containerDetails?.let { obCartonDetails ->
            if(response.success) {
                viewModel.obCartonDetails = obCartonDetails.first()
                validateCartonPallet()
            }
        }
    }

    /**
     * Function to handle OB Container error response
     */
    private fun handleObContainerErrorResponse(message: String?) {
        message?.let { msg ->
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg

            when {
                errorMessage[0].equals("ERR-LD-RC-01", ignoreCase = true) -> {
                    displaySendToPRAlert(errorMessage[1])
                }
                errorMessage[0].equals("ERR-LD-RC-02", ignoreCase = true) -> {
                    displayRecallContainers(errorMessage[1])
                }
                else -> {
                    displayErrorMessage(responseMessage)
                }
            }
        }
    }

    /**
     * Function to display Send To PR alert dialog
     */
    private fun displaySendToPRAlert(errorMessage: String) {
        val cartonNumber = binding.etCartonPallet.text.toString().trim()
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(errorMessage)
            .setPositiveButton(getString(R.string.SEND_TO_PR)) { dialog, _ ->
                viewModel.sendToPRAPIRequest(lockCode = "RC", cartonNumber = cartonNumber)
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to display Recall containers alert dialog
     */
    private fun displayRecallContainers(errorMessage: String) {
        val cartonNumber = binding.etCartonPallet.text.toString().trim()
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setMessage(errorMessage)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.lbl_view_recall_containers)) { dialog, _ ->
                dialog.dismiss()
                // call view recall containers api
                viewModel.viewRecallContainersAPIRequest(cartonNumber)
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to display Error Message on UI
     */
    private fun displayErrorMessage(message: String) {
        with(binding) {
            tvCartonPalletResponse.text = message
            etCartonPallet.requestFocus()
            etCartonPallet.selectAll()
            showSoftKeyBoard(requireContext(), etCartonPallet)
        }
    }

    /**
     * Function to observe Send To PR api response
     */
    private fun observeSendToPRAPIResponse() {
        viewModel.sendToPRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleSendToPRSuccessResponse(response.data?.message)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleSendToPRErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Send To PR success response
     */
    private fun handleSendToPRSuccessResponse(message: String?) {
        binding.etCartonPallet.setText("")
        message?.let { message ->
            FlareLog.i(TAG, "sendToPRResponse success: $message")
            showSuccessSnackBar(message)
        }
    }

    /**
     * Function to handle Send To PR error response
     */
    private fun handleSendToPRErrorResponse(message: String?) {
        message?.let { errorMessage -> displayErrorMessage(message = errorMessage) }
    }

    /**
     * Function to observe Recall Containers Api response
     */
    private fun observeRecallContainersResponse() {
        viewModel.obCartonRCLockResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObCartonRCLockSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObCartonRCLockErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Recall Containers success response
     */
    private fun handleObCartonRCLockSuccessResponse(data: OBCartonRCLockResponse?) {
        binding.etCartonPallet.setText("")
        data?.containers?.let { containers ->
            displayRecallContainersDialog(containers)
        }
    }

    /**
     * Function to display Recall Containers dialog
     */
    private fun displayRecallContainersDialog(containers: List<Container>) {

        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(getString(R.string.lbl_recalled_containers))
            .setItems(containers.map { it.containerNumber }.toTypedArray(), null)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to handle Recall Containers error response
     */
    private fun handleObCartonRCLockErrorResponse(message: String?) {
        message?.let { errorMessage -> displayErrorMessage(message = errorMessage) }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etCartonPallet.setText(scan?.barcode.toString())
        binding.etCartonPallet.text?.length?.let {
            binding.etCartonPallet.setSelection(
                it
            )
            FlareLog.i(TAG, "Carton/Pallet field focused")
            validateOBContainer()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}