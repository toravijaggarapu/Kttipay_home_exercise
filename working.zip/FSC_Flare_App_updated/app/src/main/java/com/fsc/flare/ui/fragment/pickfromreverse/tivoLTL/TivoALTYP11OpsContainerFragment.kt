package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLOpsContainerBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.UnitPickCompleteTaskDetailsRequest
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "TivoALTYP11ContainerFragment"
private const val TASK_RE_ASSIGNED = "ERR-TASK-043"
private const val TASK_CYCLE_COUNT_PENDING = "ERR-TASK-049"
private const val TASK_ALREADY_PICKED = "ERR-TASK-051"
private const val TASK_ASSIGNED_TO_OTHER_USER = "ERR-TASK-052"
const val LOCATION_IS_EMPTY = "ERR-TASK-055"

/**
 * A simple [Fragment] subclass.
 * Use the [TivoALTYP11ContainerFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11ContainerFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLOpsContainerBinding
    private var taskDetails: TaskDetails? = null
    lateinit var cb1: CustomVisibilityCallback


    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLOpsContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etOpsContainerNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvOpsContainerNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        taskDetails = viewModel.getPickTaskDetails()
        binding.tvTaskIdValue.text = taskDetails?.taskId.toString()
        binding.tvItemCodeValue.text = taskDetails?.itemCode
        binding.tvDescriptionValue.text = taskDetails?.itemDescription
        binding.tvPickQtyValue.text = String.format("%d Units",taskDetails?.taskQty)
//        binding.tvPickedQtyValue.text = taskDetails?.taskQty.toString() + " Units"
        binding.tvPickedQtyValue.text = resources.getQuantityString(R.plurals.pallet_transfer_units, viewModel.getQtyEntered(), viewModel.getQtyEntered())

        if (taskDetails != null) {
            if (taskDetails?.itemLotTracked == "1" && !taskDetails?.lotNumber.isNullOrEmpty()) {
                binding.tvLotNumber.visibility = View.VISIBLE
                binding.tvLotValue.visibility = View.VISIBLE
                binding.tvLotValue.text = taskDetails?.lotNumber
            }
            if (taskDetails?.itemExpDateTracked == "1" && !taskDetails?.expDate.isNullOrEmpty()) {
                binding.tvExpiryDate.visibility = View.VISIBLE
                binding.tvExpiryDateValue.visibility = View.VISIBLE
                binding.tvExpiryDate.text = formatExpiryDate(taskDetails?.expDate)
            }
        }

        if (sharedPreferences.getBoolean(PreferenceKeys.PickFromReserve.IS_FIRST_TASK_UNITPICKED, false)) {
            binding.btnStage.isEnabled = true
        }

        binding.etOpsContainerNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etOpsContainerNumber)
                FlareLog.i(TAG, "Container Number field focused")
                callUnitPickCompleteAPI()
            }
            false
        }


        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etOpsContainerNumber.isFocused && !binding.etOpsContainerNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container Number field focused")
                        callUnitPickCompleteAPI()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnStage.setOnClickListener {
            viewModel.reservepickstage()
        }
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeUnitPickCompleteObserver()
        subscribeReservePickStageReleaseObserver()
    }

    /**
     * method to call unitPickComplete API
     */
    private fun callUnitPickCompleteAPI() {
        val expiryDateTrack = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE_PFA, null)
        val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
        val containerNumber = binding.etOpsContainerNumber.text.toString()
        if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
            binding.tvOpsContainerNumberResponse.text =
                getString(R.string.container_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
        } else {
            viewModel.unitPickComplete(
                TivoUnitPickCompleteRequest(
                    UnitPickCompleteTaskDetailsRequest(
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        taskId = taskDetails?.taskId!!,
                        taskDetId = taskDetails?.taskDetId!!,
                        itemCode = taskDetails?.itemCode!!,
                        opsCartonNumber = binding.etOpsContainerNumber.text.toString().trim(),
                        taskQty = taskDetails?.taskQty!!,
                        locationBarcode = taskDetails?.locationBarcode!!,
                        taskQtyUom = taskDetails?.taskQtyUom!!,
//                    pickedQty = taskDetails?.taskQty!!,
                        pickedQty = viewModel.getQtyEntered(),// New Approach.
                        itemSerialTracked = taskDetails?.itemSerialTracked!!,
                        serialNumbers = viewModel.getSerialNumberList(),
                        orderShipmentMap = getOrderShipmentList(),
                        lotNumber = taskDetails?.lotNumber,
                        expDate = expiryDateTrack,
                        reasonCode = lockCode,
                    )
                )
            )
        }
    }


    /**
     * method to get order shipment list
     */
    private fun getOrderShipmentList(): List<List<Int>> {
        val orderShipmentMap = taskDetails?.orderShipmentMap
        if (orderShipmentMap != null) {
            return orderShipmentMap
        }
        return emptyList()
    }

    /**
     * method to subscribe opscontainer/unitpickcomplete  observer
     */
    private fun subscribeUnitPickCompleteObserver() {
        viewModel.unitPickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    lockCode = ""
                    response.data?.let { unitPickCompleteResponse ->
                        if (unitPickCompleteResponse.taskDetails != null) {
                            if(viewModel.getTaskId() == unitPickCompleteResponse.taskDetails.taskId) {
                                //if task id's are same, continue to allow same process.
                                unitPickCompleteResponse.taskDetails.let {
                                    viewModel.setPickTaskDetails(it)
                                    viewModel.setTaskId(it.taskId)
                                    viewModel.setOrderId(it.orderId)
                                    viewModel.setCustomerOrderNumber(it.customerOrderNumber)
                                }
                                val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToLocationFragment()
                                getNavigationController().navigate(action)
                            } else{
                                enableStageButton()
                                if(viewModel.getOrderId() == unitPickCompleteResponse.taskDetails.orderId){
                                    //if task id's are not same then show alert to do the action based on the user choice.
                                    showTaskIdDifferentAlert(viewModel.getTaskId(), unitPickCompleteResponse.taskDetails.taskId, unitPickCompleteResponse.taskDetails)
                                }else{
                                    showOrderDifferentAlert(viewModel.getTaskId(), viewModel.getCustomerOrderNumber()?:"", unitPickCompleteResponse.taskDetails.taskId,
                                        unitPickCompleteResponse.taskDetails.customerOrderNumber?:"")
                                }
                            }
                        } else {
                            enableStageButton()
                            showSuccessSnackBar(unitPickCompleteResponse.message)
                            binding.btnStage.performClick()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("_")){
                            val msgArray = message.split("_")
                            if(msgArray.isNotEmpty()){
                                if(msgArray[0] == TASK_RE_ASSIGNED){
                                    //Regarding the defect D-93281 if the next task is assigned to the another user then API will
                                    //throw error of 'Task is re-assigned to user: user id'.
                                    callTaskPickAPI()
                                } else if(msgArray[0] == TASK_CYCLE_COUNT_PENDING){
                                    showCycleCountPendingAlert()
                                } else if(msgArray[0] == TASK_ALREADY_PICKED || msgArray[0] == TASK_ASSIGNED_TO_OTHER_USER)
                                {
                                    showErrorAlert(msgArray[1], navigate = true, locationEmpty = false)
                                }else if (msgArray[0] == LOCATION_IS_EMPTY )
                                {
                                    showErrorAlert(msgArray[1], navigate = false, locationEmpty = true)
                                }else{
                                    binding.etOpsContainerNumber.requestFocus()
                                    binding.etOpsContainerNumber.selectAll()
                                    binding.tvOpsContainerNumberResponse.text = msgArray[1]
                                    showSoftKeyBoard(fragmentContext, binding.etOpsContainerNumber)
                                }
                            }
                        }else{
                            binding.tvOpsContainerNumberResponse.text = message
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    var lockCode:String = ""

    private fun showCycleCountPendingAlert() {
        viewModel.getInventoryReasonCodes()
        showAlertDialog(
            "",
            getString(R.string.cycle_count_pending_for_location),
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
                    val dialog = Dialog(fragmentContext)
                    dialog.setContentView(dialogView.root)
                    dialog.setCancelable(false)
                    dialog.show()
                    val lp = WindowManager.LayoutParams()
                    lp.copyFrom(dialog.window!!.attributes)
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT
                    lp.height =  ViewGroup.LayoutParams.MATCH_PARENT
                    dialog.window!!.attributes = lp
                    dialogView.btnCancel.setOnClickListener {
                        dialog.dismiss()
                    }
                    dialogView.btnOk.setOnClickListener {
                        viewModel.setQtyEntered(0)
                        callUnitPickCompleteAPI()
                        dialog.dismiss()
                    }
                    viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
                        when (response) {
                            is Resource.Success -> {
                                hideProgressBar()
                                response.data?.let { lookUpResponse ->
                                    FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                                    val inventoryLockList = ArrayList<String>()
                                    val inventoryLockCodeList = ArrayList<String>()
                                    lookUpResponse.lookups.forEach { lookUp ->
                                        lookUp.lookupCodes.forEach {
                                            inventoryLockList.add(it.lookupCodeDescription)
                                            inventoryLockCodeList.add(it.lookupCode)
                                        }
                                    }
                                    viewModel.setInventoryLocksList(lookUpResponse.lookups)
                                    dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                                }
                            }
                            is Resource.Error -> {
                                hideProgressBar()
                                response.message?.let { message ->
                                    FlareLog.e(TAG, "lookUpResponse Error: $message")
                                }
                            }
                            is Resource.Loading -> {
                                showProgressBar()
                            }
                        }
                    }
                    dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
                        val lookups = viewModel.getInventoryLocksList()
                        lookups.forEach { lookupCode ->
                            lookupCode.lookupCodes.forEach { lookup ->
                                if (lookup.lookupCodeDescription == selection) {
                                    FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                                    lockCode = lookup.lookupCode
                                    dialogView.btnOk.isEnabled = true
                                }
                            }
                        }
                    }
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    /**
     * method to subscribe reserve pick stage release observer
     */
    private fun subscribeReservePickStageReleaseObserver() {
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.success) {
                            if (response.taskDetails == null) {
                                showSuccessSnackBarStd(response.message) {
                                    val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToTaskgroupsFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                            } else {
                                viewModel.setStageTaskDetails(response.taskDetails)
                                val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            FlareLog.e(TAG, "reservePickStageResponse error: ${response.message}")
                            if (response.message == "No stage pending task details to stage."){
                                navigateToTaskGroup()
                            } else {
                                showErrorSnackBar(response.message)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to enable stage button
     */
    private fun enableStageButton() {
        sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_FIRST_TASK_UNITPICKED, true).apply()
        binding.btnStage.isEnabled = true
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etOpsContainerNumber.setText(scan?.barcode.toString())
                binding.etOpsContainerNumber.text?.length?.let {
                    binding.etOpsContainerNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container Number field focused")
                    callUnitPickCompleteAPI()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun showTaskIdDifferentAlert(completedTaskId:Int, newTaskId:Int, taskDetails: TaskDetails) {
        val msg = getString(R.string.task_id_different_alert, completedTaskId.toString(), newTaskId.toString())
        val newMsg = setBoldSpan(msg, listOf(completedTaskId.toString(), newTaskId.toString()))
        showCustomDialogPFA(false, newMsg, stageClick = {
            // Stage action
            binding.btnStage.performClick()
            //
        }, newTaskClick = {
            //New Task action
            taskDetails.let {
                viewModel.setPickTaskDetails(it)
                viewModel.setTaskId(it.taskId)
                viewModel.setOrderId(it.orderId)
                viewModel.setCustomerOrderNumber(it.customerOrderNumber)
                val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToLocationFragment()
                getNavigationController().navigate(action)
            }
        })
    }

    private fun showOrderDifferentAlert(completedTaskId:Int, completedCustomerOrder:String, newTaskId:Int, newCustomerOrder:String) {
        val msg = getString(R.string.order_id_different_alert, completedTaskId.toString(), completedCustomerOrder, newTaskId.toString(), newCustomerOrder)
        val newMsg = setBoldSpan(msg, listOf(completedTaskId.toString(), completedCustomerOrder, newTaskId.toString(), newCustomerOrder))
        showCustomDialogPFA(true, newMsg, stageClick = {
            // Stage action
            binding.btnStage.performClick()
            //
        }, newTaskClick={})
    }

    private fun callTaskPickAPI(){

        subscribeTaskDetailsObserver()

        viewModel.tivoGetTaskPick(
            TaskPickReq(
                allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                custId =  sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskGroup = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null)!!,
                isLTLcubing = viewModel.isLTLCubingEnabled
            )
        )

    }

    /**
     * method to subscribe task details observer
     */
    private fun subscribeTaskDetailsObserver() {
        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success == true) {
                            FlareLog.i(TAG, "taskPickResponse success: $taskpickResponse")
                            if (taskpickResponse.taskDetails == null) {
                                if(taskpickResponse.message!=null) {
                                    showErrorSnackBar(taskpickResponse.message)
                                }
                                navigateToTaskGroup()
                            } else {
                                viewModel.setPickTaskDetails(taskpickResponse.taskDetails)
                                //Set the task Id for duplicate loop check and restrict.
                                viewModel.setTaskId(taskpickResponse.taskDetails.taskId)
                                viewModel.setOrderId(taskpickResponse.taskDetails.orderId)
                                viewModel.setCustomerOrderNumber(taskpickResponse.taskDetails.customerOrderNumber)
                                when (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!) {
                                    "11" -> {
                                        val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToLocationFragment()
                                        getNavigationController().navigate(action)
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPickResponse Error: $message")
                        showErrorSnackBar(message)
                        navigateToTaskGroup()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToTaskGroup(){
        Handler(Looper.getMainLooper()).postDelayed({
            val action = TivoALTYP11ContainerFragmentDirections.actionContainerFragmentToTaskgroupsFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
    }
    private fun showErrorAlert(message:String, navigate:Boolean , locationEmpty:Boolean) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            if (navigate) {
                navigateToTaskGroup()
            }
            if (locationEmpty) {
                viewModel.setQtyEntered(0)
                callUnitPickCompleteAPI()
            }

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}