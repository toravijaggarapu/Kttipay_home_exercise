package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutItemCodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.res.ItemDetailResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutitemFragment"

@AndroidEntryPoint
class PackoutitemFragment: BaseFragment(), FlareScannable {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutItemCodeBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var currentItem: ItemDetailResponse

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutItemCodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
         binding.tvDockDoorValue.text = viewModel.getLocationBarcode()
        if(viewModel.getPalletReqNumber()=="") {
            binding.tvPallet.visibility = View.GONE
        }
        else{
            binding.tvPalletValue.text=viewModel.getPalletReqNumber()
        }
        binding.btnEndPackout.isEnabled=false
         //binding.tvPalletValue.text=viewModel.getPalletReqNumber()
        binding.tvCartonValue.text=viewModel.getcartonReqNumber()

        return binding.root
    }

    private fun packOutItemCall() {
        if (!viewModel.getLocationData().locations.isNullOrEmpty()) {
            var itemsList = viewModel.getLocationData().locations[0].items
            itemsList = itemsList.filter { it.itemName == binding.etItem.text.toString() }
            if (!itemsList.isNullOrEmpty()) {
                currentItem = itemsList[0]
                itemsValidation()
            } else {
                currentItem = viewModel.getLocationData().locations[0].items[0]
                validateUPCorSLP(currentItem.itemName)
            }
        }

    }

    private fun itemsValidation() {
        if (currentItem.uomConversions == null || currentItem.uomConversions!!.isEmpty()) {
            binding.txtItemRes.text = getString(R.string.uom_not_defined)
        } else if (viewModel.getItemId() != 0 && viewModel.getItemId() != currentItem.itemId) {
            binding.txtItemRes.text = getString(R.string.mixed_item_is_not_allowed)
        } else if (currentItem.itemName.isNotEmpty()) {
            navigateQtyPage()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etItem.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
             binding.txtItemRes.text = null
            }
        })

        binding.etItem.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        subscribeUPCObserver()
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etItem)
        if (!binding.etItem.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "ItemId field focused")
            packOutItemCall()
        }
    }

    private fun validateUPCorSLP(itemBarCode: String) {
        //API call to validate the UPC or SLP code.
        viewModel.validateUPCorSLP(itemCode = itemBarCode,
            upcOrSlp = binding.etItem.text.toString().trim())
    }

    private fun subscribeUPCObserver() {
        viewModel.upcOrSlpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { upcOrSlpResponse ->
                        if (upcOrSlpResponse.success) {
                            navigateQtyPage()
                        } else {
                            upcOrSlpResponse.message?.let { message ->
                                showErrorMessage(message)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showErrorMessage(message: String) {
        binding.txtItemRes.text = message
        binding.etItem.requestFocus()
        binding.etItem.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etItem)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etItem.setText(scan?.barcode.toString())
                binding.etItem.text?.length?.let {
                    binding.etItem.setSelection(it)
                }
                FlareLog.i(TAG, "Item field focused")
               packOutItemCall()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun navigateQtyPage(){
        binding.txtItemRes.text = null
        viewModel.setItemDesc(currentItem.description)
        viewModel.setItemId(currentItem.itemId)
        viewModel.setitemData(currentItem.itemName)
        viewModel.setlotNumber(currentItem.lotNumber ?: "")
        viewModel.setExpiryDate(currentItem.expDateAsString ?: "")
        viewModel.setInventoryType(currentItem.inventoryType)

        if(viewModel.isDekitting) {
            handleDeKittingScenarios()
        }
        else {
            navigateToQtyFragment()
        }
    }

    private fun handleDeKittingScenarios(){

        viewModel.lotNumberSelectedFromDeKitting = false;
        viewModel.lockCodeSelected = ""
        viewModel.currentItemBarCode = currentItem.itemBarCode

        if(viewModel.isItemHasMultipleLotNumbers()){
            // Show LotNumbersFragment
            val action = PackoutitemFragmentDirections.actionPackoutitemFragementToPackoutLotNumbersFragment()
            moveToFragment(action)
        }
        else if(viewModel.isItemHasMultipleInventoryTypes()) {
            // Show InvTypesFragment
            val action = PackoutitemFragmentDirections.actionPackoutitemFragementToPackoutInventoryTypesFragment()
            moveToFragment(action)
        }
        else {
            // Show LockCodesFragment
            val action = PackoutitemFragmentDirections.actionPackoutitemFragementToPackoutLockCodeFragment()
            moveToFragment(action)
        }
    }

    private fun navigateToQtyFragment(){
        val action = PackoutitemFragmentDirections.actionPackoutitemFragementToPackoutQuantityFragement()
        moveToFragment(action)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }
}