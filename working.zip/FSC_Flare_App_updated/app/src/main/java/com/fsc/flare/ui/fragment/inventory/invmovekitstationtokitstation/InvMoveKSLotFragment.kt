package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSelectLotBinding
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [InvMoveKSLotFragment] class.
 */
@AndroidEntryPoint
class InvMoveKSLotFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: InvMoveKSViewModel by activityViewModels()
    private lateinit var binding: FragmentSelectLotBinding
    private lateinit var pallet: PalletResponse
    val lotNumberHashMap = HashMap<String, Int>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSelectLotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        handleLotSelection()
        return binding.root
    }

    private fun setUpViews() {
        pallet = viewModel.getPalletResponse()
        val item = viewModel.selectedItem
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        if (pallet.palletNumber != null) {
            binding.tvPalletNumberValue.text = pallet.palletNumber
        } else {
            binding.tvPalletNumber.visibility = View.GONE
            binding.tvPalletNumberValue.visibility = View.GONE
        }
        val selectedItems =
            pallet.containersList!![0].items!!.filter { it.itemBarCode == item!!.itemBarCode }
        binding.tvItemNameValue.text = selectedItems[0].itemName
        binding.tvItemDescValue.text = selectedItems[0].itemDesc
        binding.tvTotalQtyValue.text = selectedItems[0].qty.toString()
        binding.tvKitStagingLocation.text = getString(R.string.lbl_kit_station)
        binding.tvKitStagingLocationValue.text = pallet.kitStationLocation

        // Hide Kit Item Details
        binding.kittingItemLayout.visibility = View.GONE

        binding.tvMoveQty.text = getString(R.string.transferring_qty)
        binding.tvMoveQtyValue.text = viewModel.getMoveQty()

        selectedItems.forEach { lotNumberHashMap[it.lotNumber] = it.qty }
        if (lotNumberHashMap.isNotEmpty()) {
            if (lotNumberHashMap.size > 1) {
                binding.lotNumberDropDown.setOptions(ArrayList(lotNumberHashMap.keys))
            } else {
                viewModel.setLot(lotNumberHashMap.keys.first(), false)
                validateLotQty(lotNumberHashMap[lotNumberHashMap.keys.first()]!!)
            }
        }
    }

    private fun validateLotQty(lotQty: Int) {
        if (lotQty <= viewModel.getMoveQty().toInt()) {
            navigateToNext()
        } else {
            showErrorSnackBar(getString(R.string.this_lot_number_does_not_have_enough_quantity))
        }
    }

    private fun handleLotSelection() {
        binding.lotNumberDropDown.boolFoo.observe(viewLifecycleOwner) { selectedLot ->
            viewModel.setLot(selectedLot, false)
            validateLotQty(lotNumberHashMap[selectedLot]!!.toInt())
        }
    }

    private fun navigateToNext() {
        val item = viewModel.selectedItem
        if (item?.srlNbrReqd == "4") {
            navController.navigate(R.id.action_invMoveKSLotFragment_to_invMoveKSSerialFragment)
        } else {
            navController.navigate(R.id.action_invMoveKSLotFragment_to_invMoveKSDestinationLocationFragment)
        }
    }
}