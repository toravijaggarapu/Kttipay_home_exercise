package com.fsc.flare.ui.fragment.packing

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackingSelectCartonTypeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackingSelectCartonTypeFragment"

@AndroidEntryPoint
class PackingSelectCartonTypeFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPackingSelectCartonTypeBinding
    private val viewModel: PackingViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPackingSelectCartonTypeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        subscribeObservers()

        return binding.root
    }

    fun subscribeObservers() {
        // Get Carton Types from API
        viewModel.cartonTypesResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cartonTypesResponse ->
                        FlareLog.i(
                            TAG,
                            "CartonTypesResponse success: $cartonTypesResponse"
                        )

                        val cartonTypes = ArrayList<String>()
                        cartonTypesResponse.cartonTypes.forEach {
                              cartonTypes.add(it.getCartonType())
                        }

                        viewModel.cartonTypesList = ArrayList(cartonTypesResponse.cartonTypes)
                        binding.cartonTypeSpinner.setOptions(cartonTypes)

                        // Set Carton Type associated with the Carton
                        val list = viewModel.cartonTypesList.filter { it.type == viewModel.getCartonType() && it.size == viewModel.getCartonSize() }
                        if(list.isNotEmpty()){
                            binding.cartonTypeSpinner.setSelectedValue(list[0].getCartonType())
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "CartonTypesResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Call Carton Types API
        viewModel.getCartonTypes()

        // Set Pack method
        binding.tvPackMethodValue.text = viewModel.getPackMethodDescription()

        // Set Pack Station
        binding.tvPackStationValue.text = viewModel.getPackStationDescription()


        if(viewModel.cartonNumber.isEmpty()){
            // Set Tote Number

            binding.cartonNumberGroup.visibility = View.GONE

            binding.toteNumberGroup.visibility = View.VISIBLE
            binding.tvToteNumberValue.text = viewModel.toteNumber
        }
        else {
            // Set Carton Number
            binding.toteNumberGroup.visibility = View.GONE

            binding.cartonNumberGroup.visibility = View.VISIBLE
            binding.tvCartonNumberValue.text = viewModel.cartonNumber
        }

       // Set Shipping Method
        binding.tvShippingMethodValue.text = viewModel.getShipmentMethodDescription()

        viewModel.selectedCartonType = null
        binding.cartonTypeSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
                viewModel.selectedCartonType = null
                viewModel.cartonTypesList.forEach { cartontype ->
                    if (cartontype.getCartonType().equals(isUpdated,true)) {
                        viewModel.selectedCartonType = cartontype
                    }
                }
        }

        binding.ldNextButton.setOnClickListener {
            if(viewModel.selectedCartonType == null){
                showErrorSnackBar(resources.getString(R.string.select_carton_type))
            }
            else {
                navigateToSelectDeliverFragment()
            }
        }

    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    fun navigateToSelectDeliverFragment(){
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackingSelectCartonTypeFragmentDirections.actionPackingSelectCartonMethodFragmentToPackingSelectDeliveryFragment()
        navController.navigate(action)
    }
}