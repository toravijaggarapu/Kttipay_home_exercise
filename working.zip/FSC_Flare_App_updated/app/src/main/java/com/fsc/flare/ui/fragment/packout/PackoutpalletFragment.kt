package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutPalletGetReq
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutPalletFragment"

@AndroidEntryPoint
class PackoutpalletFragment : BaseFragment(), FlareScannable {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutPalletBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    //** need to change as per api
    private fun packOutpalletCall() {
        viewModel.validatePalletId(
            PackOutPalletGetReq(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                palletNumber = binding.etPallet.text.toString(),
            )
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.tvLocationValue.text = viewModel.getLocationBarcode()
        binding.btnEndPackout.isEnabled = false
        binding.etPallet.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.etPalletRes.text = null
            }
        })
        binding.etPallet.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            getNewPalletNumber()
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etPallet)
        if (!binding.etPallet.text?.trim().isNullOrEmpty()) {
            FlareLog.i(TAG, "PalletId field focused")
            val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
            val palletNumber = binding.etPallet.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.etPalletRes.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                packOutpalletCall()
            }
        } else {
            binding.etPalletRes.text = resources.getString(R.string.lbl_enter_pallet_number)
        }
    }

    /**
     * method to generate pallet from API
     */
    private fun getNewPalletNumber() {
        //Call new pallet API.
        viewModel.generatePalletNumber(viewModel.palletDetailKey)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etPallet.setText(scan?.barcode.toString())
                binding.etPallet.text?.length?.let {
                    binding.etPallet.setSelection(it)
                }
                FlareLog.i(TAG, "PalletId field focused")
                validateField()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showConfirmationDialog() {
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(resources.getString(R.string.lbl_pallet_in_scan_process_want_to_continue))
            .setCancelable(true)
            .setPositiveButton(getString(R.string.alert_button_yes)) { dialog, _ ->
               navigateToCartonPage()
            }
            .setNegativeButton(getString(R.string.alert_button_no)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }


    private fun subscribeObservers() {
        //locIdResponse to be change with packoutpalletresponse
        viewModel.validatePalletIdResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutPallet response:$response")

                        if (response.success) {
                            FlareLog.i(TAG, "PalletResponse Success:${response}")
                            viewModel.setPackOutPalletResponse(response)
                            binding.etPalletRes.text = null
                            viewModel.setPalletReqNumber(binding.etPallet.text.toString())
                            if (!response.lpnTemp.isNullOrEmpty()) {
                                viewModel.settransIdentifier(response.lpnTemp[0].transactionIdentifier)
                            } else {
                                viewModel.settransIdentifier("")
                            }
                            val data = viewModel.getPackOutPalletResponse().lpnTemp
                            if (!data.isNullOrEmpty()) {
                                showConfirmationDialog()
                            } else {
                                navigateToCartonPage()
                            }
                        } else {
                            FlareLog.e(TAG, "PackOutPallet Error:${response.errors.errorMessage}")
                            binding.etPalletRes.text = response.errors.errorMessage
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            if (generatePalletCaseNumberResponse.numbers[0].type.equals(Constants.TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                binding.etPalletRes.text = null
                                viewModel.setPalletReqNumber(generatePalletCaseNumberResponse.numbers[0].value)
                                viewModel.settransIdentifier("")
                                navigateToCartonPage()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToCartonPage() {
        val action = PackoutpalletFragmentDirections.actionPackoutPalletFragementToPackoutCartonFragement()
        getNavigationController().navigate(action)
    }

}