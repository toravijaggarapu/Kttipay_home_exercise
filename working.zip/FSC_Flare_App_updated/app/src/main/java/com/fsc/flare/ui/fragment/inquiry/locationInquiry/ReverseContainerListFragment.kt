package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReverseContainerListBinding
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ReverseContainerListFragment : BaseFragment() {
    private lateinit var reverseContainerAdapter: ReverseContainerAdapter
    private lateinit var binding: FragmentReverseContainerListBinding

    private val viewModel: InquiryViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReverseContainerListBinding.inflate(inflater, container, false)
        setupRecyclerView()
        return binding.root
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(fragmentContext)
        reverseContainerAdapter = ReverseContainerAdapter(viewModel.reverseContainerList)
        binding.recyclerView.adapter = reverseContainerAdapter
        reverseContainerAdapter.notifyDataSetChanged()
    }
}