package com.fsc.flare.utils;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.fsc.flare.R;
import com.fsc.flare.source.data.MenuType;
import com.google.android.material.textview.MaterialTextView;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MainMenuAdapter extends ExpandableRecyclerAdapter<MainMenuAdapter.ListItem> {

    private final Context context;
    private final OnItemClickListener onItemClickListener;

    public MainMenuAdapter(Context context, List<ListItem> items, OnItemClickListener onItemClickListener) {
        super(context);
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        setItems(items);

    }

    public static class ListItem extends ExpandableRecyclerAdapter.ListItem {
        public int mCustId;
        public String mCustCode;
        public String mCustName;
        public String mBusinessUnitCode;
        public int mFacilityId;
        public int mBusinessUnitId;
        public int Icon;
        public boolean New = false;

        public ListItem(int custId, String custCode, String custName, int facilityId, int businessUnitId, int icon, MenuType type) {
            super(type.getValue());
            mCustId = custId;
            mCustCode = custCode;
            mCustName = custName;
            mFacilityId = facilityId;
            mBusinessUnitId = businessUnitId;
            Icon = icon;
        }

        public ListItem(int custId, @Nullable String custCode, @NotNull String custName, int facilityId, int businessUnitId, @NotNull String businessUnitCode, int icon, @NotNull MenuType type) {
            super(type.getValue());
            mCustId = custId;
            mCustCode = custCode;
            mCustName = custName;
            mFacilityId = facilityId;
            mBusinessUnitId = businessUnitId;
            Icon = icon;
            mBusinessUnitCode = businessUnitCode;
        }
    }

    /**
     * ClassView for menu with icon and text
     */
    public class PlainViewHolder extends ViewHolder {
        View view;
        MaterialTextView name;
        ImageView icon;

        public PlainViewHolder(View view) {
            super(view);
            this.view = view;
            name = view.findViewById(R.id.item_menu_group_name);
            icon = view.findViewById(R.id.item_menu_group_image);
        }

        public void bind(final int position) {
            name.setText(visibleItems.get(position).mCustName);
            icon.setImageResource(visibleItems.get(position).Icon);
            view.setOnClickListener(view -> onItemClickListener.onItemClick(view, visibleItems.get(position).mCustId, visibleItems.get(position).mCustCode, visibleItems.get(position).mCustName, visibleItems.get(position).mFacilityId, visibleItems.get(position).mBusinessUnitId, visibleItems.get(position).mBusinessUnitCode));
        }
    }

    /**
     * ClassView for menu with icon, text and expandable feature
     */
    public class MainHeaderViewHolder extends HeaderViewHolder {
        MaterialTextView name;
        ImageView icon;

        public MainHeaderViewHolder(View view) {
            super(view, view.findViewById(R.id.item_arrow));
            name = view.findViewById(R.id.item_menu_group_name);
            icon = view.findViewById(R.id.item_menu_group_image);
        }

        public void bind(final int position) {
            super.bind(position);
            name.setText(visibleItems.get(position).mCustName);
            icon.setImageResource(visibleItems.get(position).Icon);
        }
    }

    /**
     * ClassView for menu with text and sub header from HeaderViewHolder
     */
    public class SubHeaderViewHolder extends ViewHolder {
        View view;
        MaterialTextView name;

        public SubHeaderViewHolder(View view) {
            super(view);
            this.view = view;
            name = view.findViewById(R.id.item_menu_sub_group_name);
        }

        public void bind(final int position) {
            name.setText(visibleItems.get(position).mCustName);
            view.setOnClickListener(view -> onItemClickListener.onItemClick(view, visibleItems.get(position).mCustId, visibleItems.get(position).mCustCode, visibleItems.get(position).mCustName, visibleItems.get(position).mFacilityId, visibleItems.get(position).mBusinessUnitId, visibleItems.get(position).mBusinessUnitCode));
        }
    }

    /**
     * ClassView for menu divider line
     */
    public class DividerViewHolder extends ViewHolder {
        TextView name;

        public DividerViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.item_menu_divider_name);
        }

        public void bind(int position) {
            if (visibleItems.get(position).mCustName == null) {
                name.setVisibility(View.GONE);
            } else {
                name.setVisibility(View.VISIBLE);
                name.setText(visibleItems.get(position).mCustName);
            }
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View divider = new View(context);
        divider.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2));
        divider.setBackgroundColor(ContextCompat.getColor(
                context,
                R.color.greyDark
        ));
        if (viewType == NORMAL) {
            return new PlainViewHolder(inflate(R.layout.item_menu_plain, parent));
        } else if (viewType == HEADER) {
            return new MainHeaderViewHolder(inflate(R.layout.item_menu_group, parent));
        } else if (viewType == SUB_HEADER) {
            return new SubHeaderViewHolder(inflate(R.layout.item_menu_sub_group, parent));
        } else if (viewType == DIVIDER) {
            return new DividerViewHolder(inflate(R.layout.item_menu_divider, parent));
        } else {
            return new PlainViewHolder(inflate(R.layout.item_menu_group, parent));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ExpandableRecyclerAdapter.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        if (viewType == NORMAL) {
            ((PlainViewHolder) holder).bind(position);
        } else if (viewType == HEADER) {
            ((MainHeaderViewHolder) holder).bind(position);
        } else if (viewType == SUB_HEADER) {
            ((SubHeaderViewHolder) holder).bind(position);
        } else if (viewType == DIVIDER) {
            ((DividerViewHolder) holder).bind(position);
        } else {
            ((SubHeaderViewHolder) holder).bind(position);
        }
    }


    public interface OnItemClickListener {
        void onItemClick(View view, int custId, String custCode, String custName, int facilityId, int businessUnitId, String businessUnitCode);
    }
}
