package com.fsc.flare.base.logs

import com.fsc.flare.log.FlareLog
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.zip.GZIPOutputStream
import javax.inject.Inject

class LogsCompressor @Inject constructor() {
    fun writeCompressedLogFile(files: List<File>): ByteArray {
        var totalBytes: Long = 0
        var byteOutputStream: ByteArrayOutputStream? = null
        var gzipOutputStream: GZIPOutputStream? = null
        try {
            byteOutputStream = ByteArrayOutputStream()
            gzipOutputStream = GZIPOutputStream(byteOutputStream)
            for (file in files) {
                totalBytes += file.length()
                try {
                    FileInputStream(file).use { fileInputStream ->
                        val buffer = ByteArray(65535) // 64KB
                        var len: Int
                        while (fileInputStream.read(buffer).also { len = it } != -1) {
                            gzipOutputStream.write(buffer, 0, len)
                        }
                    }
                } catch (ex: Exception) {
                    FlareLog.e(
                        LOG_TAG,
                        "Exception occurred while compressing file : " + file.name,
                        ex
                    )
                }
            }
            val compressionRatio: Double =
                if (totalBytes > 0) byteOutputStream.size().toDouble() / totalBytes * 100 else 0.0
            FlareLog.i(LOG_TAG, "Compression Ratio achieved was " + Math.round(compressionRatio))
        } catch (ex: Exception) {
            FlareLog.e(LOG_TAG, "Exception occurred while compressing multiple files ", ex)
        } finally {
            closeStreams(byteOutputStream, gzipOutputStream)
        }
        return if (byteOutputStream == null) byteArrayOf() else byteOutputStream.toByteArray()
    }

    private fun closeStreams(
        byteOutputStream: ByteArrayOutputStream?,
        gzipOutputStream: GZIPOutputStream?
    ) {
        if (byteOutputStream != null) {
            try {
                byteOutputStream.close()
            } catch (e: Exception) {
                FlareLog.e(LOG_TAG, "Failed to close Byte output stream.")
            }
        }
        if (gzipOutputStream != null) {
            try {
                gzipOutputStream.close()
            } catch (e: IOException) {
                FlareLog.e(LOG_TAG, "Failed to close GZIP output stream.")
            }
        }
    }

    companion object {
        private const val LOG_TAG = "LogsCompressor"
    }
}