package com.fsc.flare.ui.fragment.palletizecontainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeContainerStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject

private const val TAG = "PalletizeContainerStagingLocationFragment"

@AndroidEntryPoint
class PalletizeContainerStagingLocationFragment : BaseFragment(), FlareScannable {
    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: PalletizeContainerViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeContainerStagingLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    val RECALL_PALLETIZE_ERROR = "ERR-PAL-100"
    val RECALL_LOCK_CODE = "RC"

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPalletizeContainerStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                FlareLog.i(TAG, "StagingLocation field focused")
                validateStagingLocation()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "StagingLocation field focused")
                        validateStagingLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        init()
        setListener()
    }

    private fun init() {
        viewModel.getPalletizeContainerPalletInfo()?.let {
            binding.tvPalletNumberValue.text = it.palletNumber

        }
    }

    private fun setListener() {

        binding.etStagingLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvStagingLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeStagingLocationObserver()
        subscribePalletizeContainerObserver()
        subscribeSendToPRObserver()
    }


    /**
     * method to validate staging location from API
     */
    private fun validateStagingLocation() {
        viewModel.validateStagingLocation(
            LocationClassReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etStagingLocation.text.toString(),
                "S"
            )
        )
    }

    /**
     * method to subscribe staging location observer
     */
    private fun subscribeStagingLocationObserver() {
        viewModel.stagingLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { stagingLocationResponse ->
                        if (stagingLocationResponse.success) {
                            FlareLog.i(TAG, "stagingLocationResponse success: $stagingLocationResponse")
                            if (stagingLocationResponse.locations != null && stagingLocationResponse.locations.isNotEmpty()) {
                                callPalletizeContainerAPI(stagingLocationResponse.locations[0].locationId)
                            } else {
                                binding.tvStagingLocationResponse.text = resources.getString(R.string.invalid_location)
                                requestFocusInputField(binding.etStagingLocation)

                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to palletize container API
     */
    private fun callPalletizeContainerAPI(locationId: Int) {
        viewModel.getPalletizeContainerPalletInfo()?.let {
            viewModel.palletizeContainer(
                PalletizeContainerRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    ibContainerIds = viewModel.associatedContainersIds,
                    ibPalletize = true,
                    newpallet = it.noOfCasesAllowed == null,
                    palletNbr = it.palletNumber ?: "",
                    stageLocId = locationId,
                    palletId = it.palletId
                )
            )
        }

    }

    private fun navigate() {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        navController.popBackStack()
        navController.popBackStack()
    }

    private fun subscribeSendToPRObserver() {
        viewModel.sendToPRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    binding.etStagingLocation.setText("")
                    response.data?.let { sendToPRResponse ->
                        FlareLog.i(TAG, "sendToPRResponse success: $sendToPRResponse")
                        showSuccessSnackBar(sendToPRResponse.message)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "sendToPRResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe palletize container observer
     */
    private fun subscribePalletizeContainerObserver() {
        viewModel.palletizeContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletizeContainerResponse ->
                        if (palletizeContainerResponse.success == true) {
                            FlareLog.e(TAG, "palletizeContainerResponse success: $palletizeContainerResponse")
                            showSuccessSnackBarStd(palletizeContainerResponse.message ?: ""){
                                navigate()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "palletizeContainerResponse error: $message")
                        handlePalletizeContainerErrorResponse(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun displaySendToPRAlert(responseMessage:String){
        val positiveButton = resources.getString(R.string.SEND_TO_PR)
        showAlertDialog(
            title = "",
            message = responseMessage,
            positiveButton = positiveButton,
            negativeButton = getString(R.string.cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    callSendToPRAPI()
                }
                override fun onNegativeButtonClick() {

                }
            }
        )
    }

    private fun handlePalletizeContainerErrorResponse(msg: String) {
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            when {
                errorMessage[0].equals(RECALL_PALLETIZE_ERROR, ignoreCase = true) -> {
                    displaySendToPRAlert(responseMessage)
                }
                else -> {
                    showErrorSnackBar(responseMessage)
                }
            }
    }

    fun callSendToPRAPI() {
        val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)

        val containerDetailList = viewModel.associatedContainersIds

        val request = SendToPRRequest(fcyId,custId,buId,containerDetailList,"",RECALL_LOCK_CODE)
        viewModel.sendToPR(request)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etStagingLocation.setText(scan?.barcode.toString())
                binding.etStagingLocation.text?.length?.let {
                    binding.etStagingLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "StagingLocation field focused")
                    validateStagingLocation()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}