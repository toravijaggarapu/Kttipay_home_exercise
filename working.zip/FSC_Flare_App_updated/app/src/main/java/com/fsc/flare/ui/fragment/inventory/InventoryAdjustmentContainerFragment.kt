package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryAdjustmentContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryAdjustFragment"

/**
 * A simple [InventoryAdjustmentContainerFragment] class.
 */
@AndroidEntryPoint
class InventoryAdjustmentContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryAdjustmentContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryAdjustmentContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryIcCtrAdj.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.containerNumberEdt)
                    if (binding.containerNumberEdt.isFocused && !binding.containerNumberEdt.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        binding.containerNumberEdt.clearFocus()
                        viewModel.getContainer(binding.containerNumberEdt.text.toString(), "Y")
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.containerNumberEdt.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.containerNumberEdt)
                FlareLog.i(TAG, "Container field focused")
                binding.containerNumberEdt.clearFocus()
                viewModel.getContainer(binding.containerNumberEdt.text.toString(), "Y")
            }
            false
        }

        binding.containerNumberEdt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        subscribeObservers()
    }

    private fun subscribeObservers() {
        viewModel.adjustmentResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.container.isNotEmpty()) {
                            val containerData = containerResponse.container[0]
                            if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)){
                                if(containerData.lockCode == "CC"){
                                    binding.containerResponse.text = getString(R.string.cycle_count_in_progress_for_given_location)
                                }else{
                                    validateContainer(containerData, containerResponse)
                                }
                            }else{
                                if(containerData.cyclePending == "Y"){
                                    binding.containerResponse.text = getString(R.string.cycle_count_is_pending_for_given_location)
                                }else{
                                    validateContainer(containerData, containerResponse)
                                }
                            }
                        }else{
                            binding.containerResponse.text = resources.getString(R.string.invalid_ib_container)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.containerNumberEdt.requestFocus()
                        binding.containerResponse.text = message
                        binding.containerNumberEdt.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.containerNumberEdt)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun validateContainer(containerData: Container, containerResponse: InventoryContainerResponse) {
        if (containerData.ibObCode == "OB" && containerData.status == "170") {
            viewModel.setContainerInfo(containerResponse.container)
            binding.containerNumberEdt.text = null
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = InventoryAdjustmentContainerFragmentDirections.actionInventoryAdjustmentContainerFragmentToInventoryAdjustmentItemBarcodeFragment()
            navController.navigate(action)
        } else if (containerData.ibObCode == "IB" && containerData.status == "20" && containerData.cyclePending == "N") {
            viewModel.setContainerInfo(containerResponse.container)
            binding.containerNumberEdt.text = null
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = InventoryAdjustmentContainerFragmentDirections.actionInventoryAdjustmentContainerFragmentToInventoryAdjustmentContainerDetailFragment()
            navController.navigate(action)
        } else {
            binding.containerNumberEdt.requestFocus()
            binding.containerResponse.text = resources.getString(R.string.lbl_invalid_contianer, containerData.ibObCode)
            binding.containerNumberEdt.selectAll()
            showSoftKeyBoard(fragmentContext, binding.containerNumberEdt)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.containerNumberEdt.setText(scan?.barcode.toString())
            binding.containerNumberEdt.text?.length?.let {
                binding.containerNumberEdt.setSelection(it)
            }
            FlareLog.i(TAG, "Container field focused")
            viewModel.getContainer(binding.containerNumberEdt.text.toString(), "Y")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


}

