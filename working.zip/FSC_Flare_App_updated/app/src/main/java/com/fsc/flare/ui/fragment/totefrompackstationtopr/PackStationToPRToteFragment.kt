package com.fsc.flare.ui.fragment.totefrompackstationtopr

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutToPrLocationTotePageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.Constants.Companion.ROOT_MENU_NAME
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "PackStationToPRToteFragment"
@AndroidEntryPoint
class PackStationToPRToteFragment :BaseFragment(),FlareScannable{

    lateinit var binding: FragmentPackoutToPrLocationTotePageBinding
    private val viewModel: PackstationToPRViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private var screenTitle : String? = null

    private val checkedTotes = ArrayList<String>()
    private val checkedShipmentCartonIds = ArrayList<Int>()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        handleToteCountView()
        super.onResume()
        cb1.onVisibilityChange(true)
    }
    private fun handleToteCountView() {
        if(viewModel.getToteNumbersList().size>0)
        {
            binding.tvTotalCountValue.visibility = View.VISIBLE
            binding.tvTotalCount.visibility =View.VISIBLE
            binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString() + " "+ getString(R.string.lbl_view)
            binding.btnTransferComplete.isEnabled = true
        }else
        {
            binding.tvTotalCountValue.visibility = View.GONE
            binding.tvTotalCount.visibility =View.GONE
            binding.btnTransferComplete.isEnabled = false
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPackoutToPrLocationTotePageBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        requireArguments().getString(ROOT_MENU_NAME)?.let { menuName ->
            screenTitle = menuName
            binding.tvToteFromPackoutToPR.text = screenTitle
        }
        subscribeLTLTransactionParamObserver()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    FlareLog.i(TAG, "Cart field focused")
                    validateTote()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.btnTransferComplete.setOnClickListener {
            binding.toteInput.text = null
            val action = PackStationToPRToteFragmentDirections.actionPackStationToPRToteFragmentToPackstationToPRLocationFragment()
            getNavigationController().navigate(action)
        }
        binding.tvTotalCountValue.setOnClickListener{
            if(viewModel.getToteNumbersList().isNotEmpty())
                showToteList()
        }
        binding.toteInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.toteInput)
                FlareLog.i(TAG, "Tote field focused")
                validateTote()
            }
            false
        }
        binding.toteInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.toteInputErrRes.text = null
            }
        })
    }

    private fun showToteList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.saved_totes_cartons))
        checkedTotes.clear()
        checkedShipmentCartonIds.clear()
        val totesArray = viewModel.getToteNumbersList().toTypedArray()
        builder.setMultiChoiceItems(totesArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedTotes.add(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            }
            else
            {
                checkedTotes.remove(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
        //    Log.d("debug", "Position:" + which)
         //   Log.d("debug", "isChecked Item:$"+viewModel.getToteNumbersList()[which])

        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            viewModel.removeUncheckedTotesAndCartonIds(checkedTotes,checkedShipmentCartonIds)
            handleToteCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }
    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedTotes.size>0
        if(checkedTotes.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }


    /**
     * method to get tote/carton is valid info from API
     */
    private fun validateTote() {
        if (binding.toteInput.text.toString().trim().isNotEmpty()) {
            viewModel.getPackStationTote(binding.toteInput.text.toString())
        }else
        {
            binding.toteInputErrRes.text = getString(R.string.enter_tote_carton)
        }
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeLTLTransactionParamObserver() {
        viewModel.toteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { prToteResponse ->
                        if (prToteResponse != null && prToteResponse.success) {
                            FlareLog.i(TAG, "PRTote response success: $prToteResponse")
                            binding.toteInput.text = null
                            val action = PackStationToPRToteFragmentDirections.actionPackStationToPRToteFragmentToPackStationToPRToteDetailFragment()
                            val bundle = bundleOf(
                                ROOT_MENU_NAME to screenTitle
                            )
                            getNavigationController().navigate(action.actionId, bundle)                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "PRTote response error: $message")
                        binding.toteInputErrRes.text = message
                        binding.toteInput.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.toteInput)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.toteInput.setText(scan?.barcode.toString())
            binding.toteInput.text?.length?.let {
                binding.toteInput.setSelection(it)
            }
            FlareLog.i(TAG, "Tote field focused")
            validateTote()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.resetData()
    }
}