package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsForwardRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsReverseRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedRequest
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetailRequest
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTaskResponse
import com.fsc.flare.source.data.dto.cyclecount.EndUserDirectedCCRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountDetailsRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateVirtualContainersCountRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesContainerRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesEndCCRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesLocationRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesQtyRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CycleCountRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getTaskGroups(allocationTypes: String) = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = allocationTypes
    )

    suspend fun getCycleCountTask(locationId: String? = null): Response<CycleCountTaskResponse> {
        val taskMode = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_MODE, null)
        val taskGroupCode =
            sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null)
        return apiGatewayInterface.getCycleCountTask(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            taskMode = taskMode,
            taskType = taskGroupCode,
            locationId = if (taskGroupCode == Constants.TaskTypes.CC_REVERSE_RECOUNT || taskGroupCode == Constants.TaskTypes.CC_REVERSE_COUNT) locationId else null
        )
    }

    suspend fun getSystemDirectedCycleCountTask() = apiGatewayInterface.getCycleCountTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        taskMode = "S",
        taskType = "UCP,CCP" //Pallet count CC should pass both type to user directed flow
    )

    suspend fun getItems(packageItemRequest: PackageItemRequest) =
        apiGatewayInterface.getItemsorUPC(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            responseFilter = packageItemRequest.responseFilter,
            customerId = packageItemRequest.customerId.toString(),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
            page = packageItemRequest.page,
            itemBarcode = packageItemRequest.itemBarcode
        )

    suspend fun cyclecountcontainer(locationId: Int, ccHeaderId: Int, containerNbr: String, createNewExcessInventory: String, acceptBlindCase: Boolean, taskType: String?, reasonCode: String? ) =
        apiGatewayInterface.cyclecountcontainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            ccHeaderId = ccHeaderId,
            locationId = locationId,
            containerNbr = containerNbr,
            createNewExcessInventory = createNewExcessInventory,
            acceptBlindCase = acceptBlindCase,
            taskType = taskType,
            reasonCode = reasonCode
        )

    suspend fun qtyUpdate(updateCycleCountRequest: UpdateCycleCountRequest, ccDetId: Long) =
        apiGatewayInterface.ccQtyUpdate(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            updateCycleCountRequest = updateCycleCountRequest,
            ccDetId = ccDetId
        )

    suspend fun endCycleCount(ccHeaderId: Int, override: Boolean) =
        apiGatewayInterface.endCycleCount(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            override = override,
            ccHeaderId = ccHeaderId
        )

    suspend fun validateSlp(ccHeaderId: Int, slp: String, containerId: Long) =
        apiGatewayInterface.validateSlp(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            ccHeaderId = ccHeaderId,
            slp = slp,
            containerId = containerId
        )

    suspend fun updateCycleCountDetails(cycleCountDetails: UpdateCycleCountDetailsRequest) =
        apiGatewayInterface.updateCycleCountDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            cycleCountDetails = cycleCountDetails
        )


    suspend fun getLocationDetails(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun getLocationInquiry(location: String, containerNumber: String, itemId: String) = apiGatewayInterface.getLocationInquiry(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId=sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId=sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationBarcode = location,
        containerNumber = containerNumber,
        itemId = itemId,
    )

    suspend fun getLocationInquiryWithContainerInfo(locationId: String) = apiGatewayInterface.getLocationInquiryWithContainerInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId=sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId=sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
        itemInfo = "N"
    )

    suspend fun getLocationInventoryCount(locationId: String) = apiGatewayInterface.getLocationInventoryCount(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId=sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId=sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
    )

    suspend fun getContainerInquiry(containerId: String, itemId: String) = apiGatewayInterface.getContainerInquiry(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId=sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId=sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerId = containerId,
        itemId = itemId,
        itemInfo = "N"
    )

    suspend fun cycleCountUserDirected(CCUserDirectedRequest: CCUserDirectedRequest) = apiGatewayInterface.cycleCountUserDirected(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        CCUserDirectedRequest = CCUserDirectedRequest
    )

    suspend fun ccUserDirectedDetailsForward(ccUserDirectedDetailsForwardRequest: CCUserDirectedDetailsForwardRequest) =
        apiGatewayInterface.ccUserDirectedDetailsForward(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            ccUserDirectedDetailsForwardRequest = ccUserDirectedDetailsForwardRequest
        )

    suspend fun ccUserDirectedDetailsForwardUserId(ccUserDirectedDetailsForwardRequest: CCUserDirectedDetailsForwardRequest) =
        apiGatewayInterface.ccUserDirectedDetailsForward(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
            ccUserDirectedDetailsForwardRequest = ccUserDirectedDetailsForwardRequest
        )

    suspend fun ccUserDirectedDetailsReverse(ccUserDirectedDetailsReverseRequest: CCUserDirectedDetailsReverseRequest) =
        apiGatewayInterface.ccUserDirectedDetailsReverse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            ccUserDirectedDetailsReverseRequest = ccUserDirectedDetailsReverseRequest
        )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun endUserDirectedCycleCount(endUserDirectedCCRequest: EndUserDirectedCCRequest) =
        apiGatewayInterface.endUserDirectedCycleCount(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            endUserDirectedCCRequest = endUserDirectedCCRequest
        )

    suspend fun endUserDirectedCycleCountUserId(endUserDirectedCCRequest: EndUserDirectedCCRequest) =
        apiGatewayInterface.endUserDirectedCycleCount(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
            endUserDirectedCCRequest = endUserDirectedCCRequest
        )

    suspend fun cycleCountTaskAssignedCheck(taskType: String) =
        apiGatewayInterface.cycleCountTaskAssignedCheck(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            taskType =  taskType,
            assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString()
        )

    suspend fun cycleCountTaskAssignUpdate(locationId: Int) =
        apiGatewayInterface.cycleCountTaskAssignUpdate(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            locationId =  locationId,
        )

    suspend fun cycleCountTaskForLocation(locationId: Int , status:String, responseFilter:String) =
        apiGatewayInterface.getCycleCountTaskForLocation(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId=sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            status =status,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            responseFilter =responseFilter,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            locationId =  locationId,
        )

    suspend fun cycleCountTaskForLocationPending(status:String, responseFilter:String, taskType: String) =
        apiGatewayInterface.getCycleCountTaskForLocationPending(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId=sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            status = status,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            responseFilter = responseFilter,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            taskType = taskType,
            userID = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
        )

    suspend fun getValidateLPN(container: String) =
        apiGatewayInterface.getValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            pageLimit = 1,
            excludeLocationInfo = false,
            containerType = "P"
        )

    suspend fun getValidateContainer(container: String) =
        apiGatewayInterface.getValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            pageLimit = 1,
            excludeLocationInfo = false,
            containerType = "C"
        )

    suspend fun updateValidContainer(cycleCountDetails: CycleCountDetailRequest) =
        apiGatewayInterface.updateScannedPalletsDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            cycleCountDetails = cycleCountDetails
        )

    suspend fun validateLotNumber(lotNumReqBody: LotNumReqBody) =
        apiGatewayInterface.validateLotNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "null")!!,
            custId = lotNumReqBody.custId,
            fcyId = lotNumReqBody.fcyId,
            buId = lotNumReqBody.buId,
            lotNumber = lotNumReqBody.lotNumber,
            asnId = lotNumReqBody.asnId,
            itemId = lotNumReqBody.itemId,
            lotNumberCheck = true
        )

    suspend fun validateSerialNumberWithItemCode(serialNumberOrItemId: String, isOutBoundOnly: Boolean) =
        apiGatewayInterface.validateSerialNumberWithItemCode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            serialNumberOrItemId = serialNumberOrItemId,
            isOutBoundOnly = isOutBoundOnly
        )

    suspend fun getEmptyLocationLookups(inventoryLookupsRequest: InventoryLookupsRequest) = apiGatewayInterface.getInventoryLookups(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = inventoryLookupsRequest.fcyId,
        cusId = inventoryLookupsRequest.cusId,
        buId = inventoryLookupsRequest.buId,
        lookupNames = inventoryLookupsRequest.lookupNames
    )

    suspend fun getEnableQtyCapture() = apiGatewayInterface.getEnableQtyCapture(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
    )

    suspend fun getEnableContainerScanning() = apiGatewayInterface.getEnableContainerScanning(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
    )

    suspend fun validateLotNumber(request: ValidateLotNumberRequest) =
        apiGatewayInterface.validateLotNumberTivoPFR(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            buId = request.buId,
            custId = request.custId,
            fcyId = request.fcyId,
            batchNumber = request.batchNumber,
            itemName = request.itemName,
            itemId = request.itemId,
        )

    suspend fun validateLotOrMfgCodeRequest(itemId: Int,lotOrMfgCode: String) = apiGatewayInterface.validateLotOrMfgCodeRequest(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
            lotOrMfgCode = lotOrMfgCode,
            itemId = itemId
    )

    suspend fun validationLocation(ccByLocationInEachesReq: CCByLocationInEachesLocationRequest) = apiGatewayInterface.validateCCLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        ccByLocationInEachesReq
    )

    suspend fun validateCCContainer(ccByLocationInEachesContainerRequest: CCByLocationInEachesContainerRequest,ccHeaderId:String) = apiGatewayInterface.validateCCContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        ccHeaderId,
        ccByLocationInEachesContainerRequest)

    suspend fun validateCCQty(ccByLocationInEachesQtyRequest: CCByLocationInEachesQtyRequest,ccHeaderId:String) = apiGatewayInterface.validateCCQty(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        ccHeaderId,
        ccByLocationInEachesQtyRequest)

    suspend fun endSummaryLevelCycleCount(ccHeaderId:String,ccMode:String, ccByLocationInEachesEndCCReq: CCByLocationInEachesEndCCRequest) = apiGatewayInterface.endSummaryLevelCycleCount(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        ccHeaderId,
        ccMode,
        ccByLocationInEachesEndCCReq)

    suspend fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = apiGatewayInterface.validateUPCorSLP(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        itemCode = itemCode,
        upcOrSlp = upcOrSlp
    )

    suspend fun getLookUps(inventoryTypesRequest: LookUpsRequest) = apiGatewayInterface.getLookUps(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        custId = inventoryTypesRequest.cusId,
        fcyId = inventoryTypesRequest.fcyId,
        buId = inventoryTypesRequest.buId,
        lookupNames = inventoryTypesRequest.lookupNames
    )

    suspend fun getCountPendingContainers(locationId: Int, ccHeaderId: Int, itemId: Int, lotNumber: String?, invType: String?, palletNbr: String?, palletId: Int?, palletLocationId: Int?) = apiGatewayInterface.getCountPendingContainers(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
        ccHeaderId = ccHeaderId,
        itemId = itemId,
        lotNumber = lotNumber,
        invType = invType,
        palletNbr = palletNbr,
        palletId = palletId,
        palletLocationId = palletLocationId
    )

    suspend fun updateVirtualContainersCount(updateVirtualContainersCountRequest: UpdateVirtualContainersCountRequest) =
        apiGatewayInterface.updateVirtualContainersCount(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            updateVirtualContainersCountRequest = updateVirtualContainersCountRequest
        )

    suspend fun getItemDetailByLocationBarcode(locationBarcode: String) =
        apiGatewayInterface.rlogLocationInquiry(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
            customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            warehouse = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            locationBarcode = locationBarcode,
        )

    suspend fun createCycleCountDetails(cycleCountDetails: UpdateCycleCountDetailsRequest) =
        apiGatewayInterface.createCycleCountDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            cycleCountDetails = cycleCountDetails
        )

}