package com.fsc.flare.ui.activity.authentication

import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.database.dao.FlareDao
import com.fsc.flare.database.entities.RFlog
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.AppProperties
import com.fsc.flare.source.data.dto.login.GatewayToken
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.login.Token
import com.fsc.flare.source.data.dto.login.UserInfo
import com.fsc.flare.source.data.dto.login.externaluser.ExternalUserResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.repository.AuthenticationRepository
import com.fsc.flare.source.repository.TokenRepository
import com.fsc.flare.transactiontracker.FSCTransactionTracker
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.joda.time.DateTime
import retrofit2.Response
import javax.inject.Inject
import androidx.core.content.edit
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.transformWhile

@HiltViewModel
class AuthenticationViewModel @Inject constructor(
    private val authenticationRepository: AuthenticationRepository,
    private val tokenRepository: TokenRepository,
    private val sharedPreferences: SharedPreferences,
    private val trackerInstance: FSCTransactionTracker,
    private val flareDao: FlareDao
) : BaseViewModel() {

    val oktaTokenResponse: MutableLiveData<Resource<Token>> = MutableLiveData()
    val gatewayTokenResponse: MutableLiveData<Resource<GatewayToken>> = MutableLiveData()
    val appPropertiesResponse: MutableLiveData<Resource<AppProperties>> = MutableLiveData()
    val userInfoResponse: MutableLiveData<Resource<UserInfo>> = MutableLiveData()
    val externalUserIDResponse: MutableLiveData<Resource<ExternalUserResponse>> = MutableLiveData()
    val updateLastLoginResponse: MutableLiveData<Resource<LangUpdateResponse>> = MutableLiveData()
    val lookUpResponse: MutableLiveData<Resource<LookUps>> = MutableLiveData()

    private var isTrackerDataUploadInProgress = false

    fun storeLoginTime() {
        sharedPreferences.edit { putString(PreferenceKeys.LOGIN_TIME, DateTime.now().toString()) }
    }

    fun fetchToken(authCode: String, mVerifier: String) = viewModelScope.launch {
        oktaTokenResponse.postValue(Resource.Loading())
        val response = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            tokenRepository.getInitialTokenTemp(authCode, mVerifier)
        } else {
            tokenRepository.getInitialToken(authCode, mVerifier)
        }
        oktaTokenResponse.postValue(handleTokenResponse(response))
    }
    fun updateLastLoginTime() = viewModelScope.launch {
        updateLastLoginResponse.postValue(Resource.Loading())
        val response = authenticationRepository.updateLastLoginTimeDetails(sharedPreferences.getInt(PreferenceKeys.USER_ID, -1))
        updateLastLoginResponse.postValue(handleLastLoginResponse(response))
    }

    fun fetchAppProperties() = viewModelScope.launch {
        appPropertiesResponse.postValue(Resource.Loading())
        val response = authenticationRepository.fetchAppProperties()
        appPropertiesResponse.postValue(handleAppPropertiesResponse(response))
    }

    fun fetchGatewayToken(apiGatewayClientId: String, apiGatewaySecret: String) = viewModelScope.launch {
        gatewayTokenResponse.postValue(Resource.Loading())
        val response = authenticationRepository.fetchGatewayToken(apiGatewayClientId, apiGatewaySecret)
        gatewayTokenResponse.postValue(handleGatewayTokenResponse(response))
    }

    fun fetchUserInfo() = viewModelScope.launch {
        userInfoResponse.postValue(Resource.Loading())
        val token = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            sharedPreferences.getString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, null)!!
        } else {
            sharedPreferences.getString(PreferenceKeys.OKTA_ACCESS_TOKEN, null)!!
        }
        val response = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            authenticationRepository.fetchTempUserInfo(token)
        } else {
            authenticationRepository.fetchUserInfo(token)
        }
        userInfoResponse.postValue(handleUserInfoResponse(response))
    }

    fun fetchUserID() = viewModelScope.launch {
        externalUserIDResponse.postValue(Resource.Loading())
        val token = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            sharedPreferences.getString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, null)!!
        } else {
            sharedPreferences.getString(PreferenceKeys.OKTA_ACCESS_TOKEN, null)!!
        }
        val response = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            authenticationRepository.fetchExternalUserDetails("T", token)
        } else {
            authenticationRepository.fetchExternalUserDetails("I", token)
        }
        externalUserIDResponse.postValue(handleExternalUserIDResponse(response))
    }


    private fun handleExternalUserIDResponse(response: Response<ExternalUserResponse>): Resource<ExternalUserResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }


    private fun handleUserInfoResponse(response: Response<UserInfo>): Resource<UserInfo> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

    private fun handleAppPropertiesResponse(response: Response<AppProperties>): Resource<AppProperties> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

    private fun handleTokenResponse(response: Response<Token>): Resource<Token> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

    private fun handleGatewayTokenResponse(response: Response<GatewayToken>): Resource<GatewayToken> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

    private fun handleLastLoginResponse(response: Response<LangUpdateResponse>): Resource<LangUpdateResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun fetchRefreshToken() = viewModelScope.launch {
        oktaTokenResponse.postValue(Resource.Loading())
        val response = tokenRepository.getRefreshedToken(sharedPreferences.getString(PreferenceKeys.OKTA_REFRESH_TOKEN, "")!!)
        oktaTokenResponse.postValue(handleTokenResponse(response))
    }

    fun getLookUps(lookUpsRequest: LookUpsRequest) = viewModelScope.launch {
        lookUpResponse.postValue(Resource.Loading())
        val response = authenticationRepository.getLookUps(lookUpsRequest)
        lookUpResponse.postValue(handleInventoryTypesResponse(response))
    }

    private fun handleInventoryTypesResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getLookUpResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getLookUpError Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun updateTransactionData(uploadDataFromFile: Boolean = false) = viewModelScope.launch(Dispatchers.IO) {
        val inputData = if (uploadDataFromFile)
            trackerInstance.readTrackerData()
        else
            trackerInstance.getTrackerData()

        if (inputData == null || inputData.transactionType.isEmpty() || isTrackerDataUploadInProgress)
            return@launch

        isTrackerDataUploadInProgress = true
        tokenRepository.updateTransactionData(inputData).apply {
            if (isSuccessful && body() != null) {
                trackerInstance.resetData()
            }
        }
        isTrackerDataUploadInProgress = false
    }

    private var isUpdateGoingOn = false

    fun startLogging() {
        viewModelScope.launch {

            flareDao.getRequestedLogs(50).filterNotNull().collect { data ->
                if (data.isNotEmpty() && !isUpdateGoingOn) {
                    Log.i("DB-LOGS", "Logs to be updated: ${data.size}")
//                    updateAndDeleteLogs(data)
                }
            }
//            flareDao.getRequestedLogs(50).transformWhile { logs ->
//                emit(logs)
//                logs.size < 50
//            }.collect { data ->
//                if (data.isNotEmpty() && !isUpdateGoingOn) {
//                    updateAndDeleteLogs(data)
//                }
//            }
        }
    }

    private fun updateAndDeleteLogs(logs: List<RFlog>) {
        viewModelScope.launch {
            isUpdateGoingOn = true
            //TODO:: Implement API push
            //TODO:: Check the API Status
            flareDao.deleteLogs(logs)
            isUpdateGoingOn = false
        }
    }
}