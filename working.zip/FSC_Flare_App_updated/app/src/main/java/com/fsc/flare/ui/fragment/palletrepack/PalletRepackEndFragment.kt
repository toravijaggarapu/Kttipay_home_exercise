package com.fsc.flare.ui.fragment.palletrepack

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRepackEndBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.masterpalletrepack.MasterPalletRepackItemCodeResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostData
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostSerialNumber
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.ui.fragment.receiving.SerialAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletRepackEnd"

/**
 * A simple [PalletRepackEnd]
 */
@AndroidEntryPoint
class PalletRepackEnd : BaseFragment(), FlareScannable, AlertDialogClickListener {

    private val viewModel: PalletRepackViewModel by activityViewModels()
    private lateinit var binding: FragmentRepackEndBinding
    lateinit var serialListAdapter: SerialAdapter
    private var serialList = ArrayList<String>()
    private var containerQty = 0
    private var isEnded = false

    private var lTempTableContainerSize : Int =0

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        binding.btnEndRepack.isEnabled = viewModel.containerInfo.size > 0
        updateItemAndQtyDetails()
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRepackEndBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etItemCode.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etItemCode)
                FlareLog.i(TAG, "Container field focused")
                validateItemCode()
            }
            false
        }

        binding.etQty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etQty)
                FlareLog.i(TAG, "Container field focused")
                validateQty()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etItemCode.isFocused && binding.etItemCode.text.toString().trim().isNotEmpty()) {
                        validateItemCode()
                    }
                    if (binding.etQty.isFocused && !(viewModel.getItemResponse().itemSerial!!.itemSerialTracked)) {
                        validateQty()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnEndRepack.setOnClickListener {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            FlareLog.i(TAG, "Container field focused")
            isEnded = true
            if(containerQty>0) {
                updateTempTableData()
            }else {
                navigateLocationScreen()
            }
        }
        binding.btnEndContainer.setOnClickListener {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            FlareLog.i(TAG, "Container field focused")
            isEnded = false
            if(containerQty>0) {
                updateTempTableData()
            }else {
                if (viewModel.getItemResponse().itemSerial!!.maxCase == lTempTableContainerSize) {
                    maxPalletReachAlert()
                } else {
                    getNavigationController().popBackStack()
                }
            }
        }

        //    updateItemAndQtyDetails()
        setupRecyclerView()
        binding.etItemCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvItemCodeResponse.text = null
                binding.etQty.text = null
                //  binding.etQty.isEnabled = false
                //enableEndPalletButton(viewModel.containerInfo.size>0)
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvRepackQtyResponse.text = null
//                if(binding.etQty.isFocused) {
//                    enableEndPalletButton(viewM)
//                }
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun updateItemAndQtyDetails() {
        val palletData = viewModel.getPalletData()
        binding.tvPalletNumber.text = palletData.palletNumber
        binding.tvContainerNumber.text = palletData.containerNumber
        containerQty = palletData.quantity

        if (containerQty > 0) {
            binding.tvRepackQty.text = resources.getQuantityString(R.plurals.pallet_transfer_units, containerQty, containerQty)
            binding.btnEndContainer.isEnabled = containerQty > 0
            enableEndPalletButton(true)
            enableContainerButton(true)
        } else {
            binding.tvRepackQty.text = resources.getString(R.string.zero_unit)
            binding.btnEndContainer.isEnabled = false
        }

        val containerSerialNumbers = viewModel.getContainerSerialNumbers()
        if (!containerSerialNumbers.isNullOrEmpty()) {
            for (serialNumber in containerSerialNumbers) {
                serialList.add(serialNumber.serialNumber!!)
            }
        }

        if (palletData.itemCode.isNotEmpty()) {
            binding.tvItemCodeValue.text = palletData.itemCode
            binding.tvItemDescValue.text = palletData.itemDesc
            binding.lnrSerialTrackContainer.visibility = View.VISIBLE
        }
    }

    private fun validateItemCode() {

        if (binding.etItemCode.text.toString().trim().isNotEmpty()) {
            val itemCode = binding.etItemCode.text.toString().trim()
            if ((viewModel.getSerialNumbers().contains(itemCode)) || serialList.contains(itemCode)) {
                displayErrorMessage(resources.getString(R.string.duplicate_serial))
            } else {
                viewModel.validateItemCode(itemCode)
            }
        }
    }

    private fun validateQty() {
        if (binding.etQty.text.toString().trim().isNotEmpty()) {
            //  enableEndPalletButton(false)
            if (viewModel.getTransactionParamByTransCode("IUU")) {
                itemUOMDefinedNonSerialFlow()
            } else {
                itemUOMNotDefinedNonSerialFlow()
            }
        } /*else {
            enableEndPalletButton(false)
        }*/
    }

    private fun itemUOMNotDefinedNonSerialFlow() {
        val typedQty = binding.etQty.text.toString().toInt()
        when {
            typedQty < 1 -> {
                binding.tvRepackQtyResponse.text = resources.getString(R.string.master_repack_qty_error)
            }
            else -> {
                containerQty += typedQty
                val palletData = viewModel.getPalletData()
                palletData.quantity = containerQty
                binding.tvRepackQty.text =
                    resources.getQuantityString(R.plurals.pallet_transfer_units, containerQty, containerQty)
                binding.etQty.text?.clear()
                binding.etItemCode.text?.clear()
                binding.etItemCode.requestFocus()
                hideQtyField()
                if(containerQty>0) {
                    enableEndPalletButton(true)
                    enableContainerButton(true)
                }
            }
        }
    }

    private fun itemUOMDefinedNonSerialFlow() {
        val typedQty = binding.etQty.text.toString().toInt()
        val getCaseQtyUOM = viewModel.getItemResponse().itemSerial!!.maxEaches
        when {
            typedQty < 1 -> {
                binding.tvRepackQtyResponse.text = resources.getString(R.string.master_repack_qty_error)
            }
            ((containerQty + typedQty) > getCaseQtyUOM) -> {
                binding.tvRepackQtyResponse.text = getString(R.string.master_pallet_repack_qty_can_not_greater_than_case_qty)
            }
            else -> {
                if (getCaseQtyUOM == containerQty) {
                    showAlertDialog(
                        "", getString(R.string.master_pallet_repack_container_reached_max_case_qty),
                        getString(R.string.button_continue), getString(R.string.alert_button_cancel), this
                    )
                    return
                }
                containerQty += typedQty
                val palletData = viewModel.getPalletData()
                palletData.quantity = containerQty
                binding.tvRepackQty.text =
                    resources.getQuantityString(R.plurals.pallet_transfer_units, containerQty, containerQty)
                binding.etQty.text?.clear()
                binding.etItemCode.text?.clear()
                binding.etItemCode.requestFocus()
                hideQtyField()
                if(containerQty>0) {
                    enableEndPalletButton(true)
                    enableContainerButton(true)
                }
//                if (viewModel.getTempTableData() != null && viewModel.getTempTableData()!!.tempLpn != null && viewModel.getTempTableData()!!.tempLpn!!.containerDetails != null && viewModel.getTempTableData()!!.tempLpn!!.containerDetails!!.size == viewModel.getItemResponse().itemSerial!!.maxCase) {
//                    maxPalletReachAlert()
//                }

            }
        }
    }

    private fun enableEndPalletButton(isEnable: Boolean) {
        binding.btnEndRepack.isEnabled = isEnable
    }

    private fun enableContainerButton(isEnable: Boolean) {
        binding.btnEndContainer.isEnabled = isEnable
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        viewModel.itemCodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { response ->
                        if (response!!.success) {
                            if (viewModel.getTransactionParamByTransCode("IUU")) {
                                itemUOMDefinedFlow(response)
                            } else {
                                itemUOMNotDefinedFlow(response)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        displayErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.masterPalletRepackTempPostResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tempTableSubmitResponse ->
                        if (tempTableSubmitResponse.success) {
                            viewModel.setTempTableTransactionIdentifier(tempTableSubmitResponse.tempLpn!!.transactionIdentifier)
                            val palletData = viewModel.getPalletData()
                            palletData.palletNumber = tempTableSubmitResponse.tempLpn!!.palletNumber!!
                            val containersList = tempTableSubmitResponse.tempLpn!!.containerDetails
                            if (containersList != null) {
                                viewModel.setSerialNumbers(containersList)
                                palletData.palletQty = viewModel.getPalletQuantity(containersList)
                                palletData.noOfContainer = containersList.size
                                palletData.itemCode = tempTableSubmitResponse.tempLpn!!.itemCode!!
                                palletData.itemDesc = tempTableSubmitResponse.tempLpn!!.itemDescription!!
                            }
                            binding.etItemCode.text = null
                            binding.etQty.text = null

                            viewModel.saveContainerSerialNumbers(arrayListOf())
                            viewModel.saveContainerNumber(binding.tvContainerNumber.text.toString())

                            lTempTableContainerSize = response.data.tempLpn!!.containerDetails!!.size

                             if(viewModel.getPrintCaseLabelData())
                             {
                                 printContainerLabels()
                             }
                            else
                             {
                                 handleNavigationAfterTempPostData()
                             }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printContainerLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { response ->
                        if (response!!.success) {
                            handleNavigationAfterTempPostData()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showSnackBar(message)
                        handleNavigationAfterTempPostData()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleNavigationAfterTempPostData() {
        if (viewModel.getTransactionParamByTransCode("IUU")) {
            when {
                isEnded -> {
                    navigateLocationScreen()
                }
                viewModel.getItemResponse().itemSerial!!.maxCase == lTempTableContainerSize -> {
                    maxPalletReachAlert()
                }
                else -> getNavigationController().popBackStack()
            }
        } else {
            navigateLocationScreen()
        }
    }

    private fun printContainerLabels() {

        if(viewModel.getPrinterNameData().isNotEmpty())
        {
            val printContainerLabelRequest = PrintContainerLabelRequest(
                containerNumber = binding.tvContainerNumber.text.toString(),
                itemId = viewModel.getItemId(),
                containerQty = containerQty.toString(),
                printRequester = viewModel.getPrinterNameData(),
                serialNumbers = serialList
            )
            viewModel.printContainerLabels(printContainerLabelRequest)
        }else
        {
            FlareLog.i(TAG, "Print Requester is not selected")
        }
    }

    private fun itemUOMNotDefinedFlow(response: MasterPalletRepackItemCodeResponse) {
        if (response.itemSerial == null)
            return
        else {
            if (response.itemSerial.itemSerialTracked)  // Item Serial Tracked Flow
            {
                if (viewModel.getItemId().isNotEmpty() && viewModel.getItemId() != response.itemSerial.itemId.toString()) {
                    displayErrorMessage(getString(R.string.mixed_item_is_not_allowed))
                    return
                }
                if (response.itemSerial.serialNumber == null) {
                    displayErrorMessage(getString(R.string.master_pallet_repack_item_serial_tracked))
                    return
                } else {
                    val allSerialNumberList = viewModel.getSerialNumbers()
                    if (!allSerialNumberList.contains(response.itemSerial.serialNumber) && !serialList.contains(response.itemSerial.serialNumber)) {
                        hideQtyField()
                        viewModel.setItemResponse(response)
                        viewModel.setItem(response.itemSerial.itemId.toString())
                        //Add serial number to list if not exists
                        hideAllViews()
                        binding.lnrSerialTrackContainer.visibility = View.VISIBLE
                        binding.rvSerial.visibility = View.GONE
                        serialList.add(response.itemSerial.serialNumber)
                        serialListAdapter.notifyDataSetChanged()
                        containerQty = serialList.size
                        setItemCodeDesc(response.itemSerial)
                        binding.tvRepackQty.text =
                            resources.getQuantityString(R.plurals.pallet_transfer_units, containerQty, containerQty)
                        if(containerQty>0)
                        {
                            enableEndPalletButton(true)
                            enableContainerButton(true)
                        }

                        binding.etItemCode.text = null
                        binding.etQty.text = null
                    } else {
                        displayErrorMessage(resources.getString(R.string.duplicate_serial))
                    }
                }
            } else  // Item Non Serial Tracked Flow
            {
                if (viewModel.getItemId().isNotEmpty() && viewModel.getItemId() != response.itemSerial.itemId.toString()) {
                    displayErrorMessage(getString(R.string.mixed_item_is_not_allowed))
                    return
                }
                showQtyField()
                viewModel.setItemResponse(response)
                viewModel.setItem(response.itemSerial.itemId.toString())
                hideAllViews()
                // Allow user to enter the quantity when item is non serial tracked
                //binding.etQty.isEnabled = true
                binding.lnrSerialTrackContainer.visibility = View.VISIBLE
                setItemCodeDesc(response.itemSerial)
                if(containerQty>0)
                {
                    enableEndPalletButton(true)
                    enableContainerButton(true)
                }
            }
        }
    }

    private fun showQtyField() {
        binding.repackQtyLayout.visibility = View.VISIBLE
        binding.etQty.isEnabled = true
        binding.etQty.requestFocus()
    }

    private fun hideQtyField() {
        binding.repackQtyLayout.visibility = View.GONE
    }

    private fun itemUOMDefinedFlow(response: MasterPalletRepackItemCodeResponse) {
        if (response.itemSerial!!.screenMessage != null) {
            displayErrorMessage(response.itemSerial.screenMessage!!)
            return
        } else if (response.itemSerial.caseUom.isNullOrEmpty() || response.itemSerial.maxCase == 0) {
            displayErrorMessage(getString(R.string.uom_not_defined))
            return
        }
        if (response.itemSerial.itemSerialTracked) // Item Serial Tracked Flow
        {
            if (viewModel.getItemId().isNotEmpty() && viewModel.getItemId() != response.itemSerial.itemId.toString()) {
                displayErrorMessage(getString(R.string.mixed_item_is_not_allowed))
                return
            }
            if (response.itemSerial.serialNumber == null) //Scanned item is not a serial nbr.
            {
                //display message due to item scanned which is serially tracked
                displayErrorMessage(getString(R.string.master_pallet_repack_item_serial_tracked))
            } else {

                if (response.itemSerial.maxEaches == serialList.size) {
                    showAlertDialog(
                        "", getString(R.string.master_pallet_repack_container_reached_max_case_qty),
                        getString(R.string.button_continue), getString(R.string.alert_button_cancel), this
                    )
                    return
                }
                val allSerialNumberList = viewModel.getSerialNumbers()

                if (!allSerialNumberList.contains(response.itemSerial.serialNumber) && !serialList.contains(response.itemSerial.serialNumber)) {
                    hideQtyField()
                    viewModel.setItemResponse(response)
                    viewModel.setItem(response.itemSerial.itemId.toString())
                    //Add serial number to list if not exists
                    hideAllViews()
                    binding.lnrSerialTrackContainer.visibility = View.VISIBLE
                    binding.rvSerial.visibility = View.GONE
                    serialList.add(response.itemSerial.serialNumber)
                    serialListAdapter.notifyDataSetChanged()
                    containerQty = serialList.size
                    binding.tvRepackQty.text =
                        resources.getQuantityString(R.plurals.pallet_transfer_units, containerQty, containerQty)
                    if(containerQty>0)
                    {
                        enableEndPalletButton(true)
                        enableContainerButton(true)
                    }
                    setItemCodeDesc(response.itemSerial)
                    binding.etItemCode.text = null
                    binding.etQty.text = null
                } else {
                    displayErrorMessage(resources.getString(R.string.duplicate_serial))
                }
            }

        } else // Item Non Serial Tracked Flow
        {
            if (viewModel.getItemId().isNotEmpty() && viewModel.getItemId() != response.itemSerial.itemId.toString()) {
                displayErrorMessage(getString(R.string.mixed_item_is_not_allowed))
                return
            }
            if (response.itemSerial.maxEaches == containerQty) {
                showAlertDialog(
                    "", getString(R.string.master_pallet_repack_container_reached_max_case_qty),
                    getString(R.string.button_continue), getString(R.string.alert_button_cancel), this
                )
                return
            }
            viewModel.setItemResponse(response)
            viewModel.setItem(response.itemSerial.itemId.toString())
            hideAllViews()
            showQtyField()
            // Allow user to enter the quantity when item is non serial tracked
            //   binding.etQty.isEnabled = true
            binding.lnrSerialTrackContainer.visibility = View.VISIBLE
            setItemCodeDesc(response.itemSerial)
            if(containerQty>0)
            {
                enableEndPalletButton(true)
                enableContainerButton(true)
            }
        }
    }

    private fun setItemCodeDesc(itemSerial: MasterPalletRepackItemCodeResponse.ItemSerialEntity) {
        binding.tvItemCodeValue.text = itemSerial.itemCode
        binding.tvItemDescValue.text = itemSerial.itemDescription
        val palletData = viewModel.getPalletData()
        palletData.itemCode = itemSerial.itemCode.toString()
        palletData.itemDesc = itemSerial.itemDescription.toString()
        palletData.quantity = containerQty
    }

    private fun hideAllViews() {

        binding.etQty.text = null
        // binding.etQty.isEnabled = false
        // binding.lnrSerialTrackContainer.visibility = View.GONE
        binding.rvSerial.visibility = View.GONE
    }

    private fun displayErrorMessage(message: String) {
        binding.etItemCode.requestFocus()
        binding.tvItemCodeResponse.text = message
        binding.etItemCode.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etItemCode)
    }

    private fun navigateLocationScreen() {
        val action = PalletRepackEndDirections.actionPalletRepackPrintRequesterFragmentToPalletRepackDestLocationFragment()
        getNavigationController().navigate(action)
    }

    private fun maxPalletReachAlert() {
        showAlertDialog(
            "",
            getString(R.string.master_pallet_repack_pallet_reached_max_qty),
            getString(R.string.button_continue),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    navigateLocationScreen()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        serialListAdapter = SerialAdapter(serialList)
        binding.rvSerial.adapter = serialListAdapter
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etItemCode.setText(scan?.barcode.toString())
                binding.etItemCode.text?.length?.let {
                    binding.etItemCode.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container field focused")
                    validateItemCode()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    override fun onPositiveButtonClick() {
        //Ok button click will save and go back.
        updateTempTableData()
    }

    override fun onNegativeButtonClick() {

    }

    private fun updateTempTableData() {
        if(viewModel.getItemResponse().itemSerial == null){
            return
        }
        if ((viewModel.getItemResponse().itemSerial!!.itemSerialTracked && serialList.isNotEmpty()) || !viewModel.getItemResponse().itemSerial!!.itemSerialTracked) {

            val serialNewList = arrayListOf<PalletRepackPostSerialNumber>()
            val qty = if (serialList.isNotEmpty()) {
                for (serialData in serialList) {
                    serialNewList.add(PalletRepackPostSerialNumber(serialData))
                }
                containerQty
            } else {
                containerQty
            }
            val palletRepackPostData = PalletRepackPostData(
                containerNumber = binding.tvContainerNumber.text.toString(),
                itemId = viewModel.getItemId(),
                containerQty = qty.toString(),
                qtyUom = "EA",
                serialNumbers = serialNewList
            )
            val containerList = arrayListOf<PalletRepackPostData>()
            containerList.add(palletRepackPostData)

            val palletRepackPostRequest = PalletRepackPostRequest(
                palletNumber = binding.tvPalletNumber.text.toString(),
                containerDetails = containerList
            )

            viewModel.postTempTable(palletRepackPostRequest)
        }
    }

}