package com.fsc.flare.ui.fragment.pickingforward.pickfromactive


import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentExpiryDatePickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject


private const val TAG = "PickCartExpiryDateFragment"

@AndroidEntryPoint
class PickCartExpiryDateFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickingForwardViewModel by activityViewModels()
    private lateinit var binding: FragmentExpiryDatePickFromReserveBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExpiryDatePickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPickingBuildCart.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.taskIdTVRes.text = data.taskId.toString()
            binding.itemCodeTvRes.text = data.itemCode
            binding.desTvRes.text = data.itemDescription
            binding.quantityTvRes.text = String.format("%d %s",data.ibContainerQty,data.ibContainerUom)
            binding.locaitonTvRes.text = data.locationBarcode
            binding.containerTvRes.text = data.containerNbr
            if (data.itemLotTracked == "1") {
                binding.lotTv.visibility = View.VISIBLE
                binding.lot.visibility = View.VISIBLE
                binding.lot.text = data.lotNumber
            }
            if(!data.toteNumber.isNullOrEmpty())
            {
                showToteLayout(true)
                binding.toteNumber.text = data.toteNumber
            }else
                showToteLayout(false)
        }

        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            binding.expiryEdt.text = sdf.format(cal.time)
            if (!binding.expiryEdt.text.isNullOrEmpty()) {
                val taskData = viewModel.getPickTaskDetails()
                if (taskData != null) {
                    when {
                        viewModel.isOverrideItemAttributes == 1 -> {
                            saveExpiryDate(binding.expiryEdt.text.toString())
                        }
                        isExpiryDateSame(binding.expiryEdt.text.toString()) -> {
                            saveExpiryDate(binding.expiryEdt.text.toString())
                        }
                        else -> {
                            binding.expiryDateEdt.text = getString(R.string.alert_invalid_expiry_date)
                        }
                    }
                }
            }
        }
        binding.expiryEdt.setOnClickListener {
            val calendar = Calendar.getInstance()
            FlareLog.i(TAG, "Date field clicked")

            binding.expiryDateEdt.text = ""
            val datePickerDialog = DatePickerDialog(
                fragmentContext, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePickerDialog.datePicker.minDate = calendar.timeInMillis
            datePickerDialog.show()
        }
    }

    private fun moveToSerialFragment(canMove: Boolean) {
        if (canMove) {
            val action = PickCartExpiryDateFragmentDirections.actionPickCartExpiryDateToPickCartSerialFragment()
            getNavigationController().navigate(action)
        } else {
            val action = PickCartExpiryDateFragmentDirections.actionPickCartExpiryDateToPickCartSlotFragment()
            getNavigationController().navigate(action)
        }
    }

    private fun saveExpiryDate(expDate: String) {
        val taskData = viewModel.getPickTaskDetails()
        sharedPreferences.edit().putString(PreferenceKeys.PickingForward.EXPIRY_DATE_INPUT, expDate).apply()
        taskData!!.expDate = expDate
        when (taskData.allocationType) {
            "10", "11" -> {
                moveToSerialFragment(taskData.itemSerialTracked == "4" || taskData.itemSerialTracked == "1")
            }
            "12" -> {
                moveToSerialFragment (taskData.itemSerialTracked == "4")
            }
            "20", "21" -> {
                val action = PickCartExpiryDateFragmentDirections.actionPickCartExpiryDateToPickCartCartFragment()
                getNavigationController().navigate(action)
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun isExpiryDateSame(selectedDate: String): Boolean {
        val myFormat1 = "yyyy-MM-dd" // mention the format you need
        val myFormat = "yyyy-MM-dd hh:mm:ss" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        val sdf1 = SimpleDateFormat(myFormat1, Locale.US)

        if (viewModel.getPickTaskDetails()?.expDate != null && viewModel.getPickTaskDetails()?.expDate != "") {
            val getApiExpiryDate = sdf.parse(viewModel.getPickTaskDetails()?.expDate!!)
            val taskDetailExpDate = sdf1.format(getApiExpiryDate!!)
            if (taskDetailExpDate.isNotEmpty() && taskDetailExpDate.equals(selectedDate, true)) {
                return true
            }
        } else {
            return true
        }
        return false
    }

    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

}