package com.fsc.flare.ui.fragment.receiving

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter
import java.util.Locale

class StartsWithFilterAdapter
    (
    context: Context,
    private val suggestions: List<String>
) : ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, suggestions) {
    private val filter = CustomFilter()
    private val originalSuggestions = ArrayList(suggestions)

    override fun getFilter(): Filter {
        return filter
    }

    inner class CustomFilter : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val results = FilterResults()
            val filteredList = ArrayList<String>()

            if (constraint == null || constraint.isEmpty()) {
                // If the input is empty, return all original suggestions
                filteredList.addAll(originalSuggestions)
            } else {
                val filterPattern = constraint.toString().lowercase().trim()

                for (item in originalSuggestions) {
                    if (item.lowercase().startsWith(filterPattern)) {
                        filteredList.add(item)
                    }
                }
            }

            results.values = filteredList
            results.count = filteredList.size
            return results
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            clear()
            if (results != null && results.count > 0) {
                addAll(results.values as List<String>)
                notifyDataSetChanged()
            } else {
                notifyDataSetInvalidated()
            }
        }
    }
}