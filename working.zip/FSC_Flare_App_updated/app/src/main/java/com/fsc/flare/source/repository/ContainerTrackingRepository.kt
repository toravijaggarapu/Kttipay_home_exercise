package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.containertracking.screenconfig.ScreenConfigReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseReq
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject



class ContainerTrackingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getContTracking(getContDetailRequest: GetContDetailRequest) =
        apiGatewayInterface.getContTracking(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = getContDetailRequest.custId,
            buId = getContDetailRequest.buId,
            fcyId = getContDetailRequest.fcyId,
            containerNbr = getContDetailRequest.containerNbr,
            includeCCLocation = getContDetailRequest.includeCCLocation
        )

    suspend fun getScreenConfig(screenConfigReq: ScreenConfigReq) =
        apiGatewayInterface.getScreenConfig(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            program = screenConfigReq.program,
            cusId = screenConfigReq.cusId,
            whsId = screenConfigReq.whsId,
            deletedFlag = screenConfigReq.deletedFlag
        )

    suspend fun sendContainerTracking(sendContainerTrackingBaseReq: SendContainerTrackingBaseReq) =
        apiGatewayInterface.saveContTracking(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            sendContainerTrackingBaseReq
        )
}