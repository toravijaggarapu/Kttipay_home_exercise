package com.fsc.flare.ui.fragment.casepicktopalletid

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasePickToPalletIdScanPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PickByCaseMethod.PIK_BY_CNT
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CasePickToPalletIDPalletFragment"

/**
 * A simple [CasePickToPalletIDPalletFragment] subclass.
 */
@AndroidEntryPoint
class CasePickToPalletIDPalletFragment : BaseFragment(), FlareScannable {

    private val viewModel: CasePickToPalletIDViewModel by activityViewModels()
    private lateinit var binding: FragmentCasePickToPalletIdScanPalletBinding
    private var customVisibilityCallback: CustomVisibilityCallback? = null

    @Inject
    lateinit var alertHandler: AlertHandler

    @Inject
    lateinit var sharedPreference: SharedPreferences

    private val pickMethodCodes by lazy {
        val lookupsString = sharedPreference.getString(PreferenceKeys.CASE_PICK_METHOD_LIST_PREFERENCE, "[]")
        Gson().fromJson(lookupsString, Array<String>::class.java).toList()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentCasePickToPalletIdScanPalletBinding.inflate(inflater, container, false)
        binding.tvCasePickToPalletIdHeader.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getLTLTransactionParam(viewModel.ltlCubeTransParamsKey)
        viewModel.getTaskGroups()
        binding.etPalletNumber.post { binding.etPalletNumber.requestFocus() }
        handleTouchAndClickEvents()
        subscribeObservers()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndClickEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        val palletNumber = etPalletNumber.text.toString()
                        when {
                            etPalletNumber.isFocused && palletNumber.isNotEmpty() -> {
                                val containerType = viewModel.validateContainerType(
                                    sharedPreferencesBase, viewModel.palletDetailKey
                                )
                                if (containerType != null && !viewModel.validateInputType(
                                        palletNumber, containerType
                                    )
                                ) {
                                    tvPalletNumberResponse.text = getString(
                                        R.string.pallet_prefix_length_validation,
                                        containerType.ctyId,
                                        containerType.ctyContainerLength
                                    )
                                } else {
                                    validatePalletNumber(palletNumber)
                                }
                            }
                        }
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
            etPalletNumber.addTextChangedListener {
                tvPalletNumberResponse.text = null
            }

            btnNewPallet.setOnClickListener {
                viewModel.generatePalletNumber()
            }
        }

    }

    private fun validatePalletNumber(palletNumber: String) {
        if (isProgressBarVisible()) {
            return
        }
        viewModel.validatePalletId(palletNumber)
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        subscribePalletValidationObserver()
        subscribeAssignedTaskValidationObserver()
        subscribeNewPalletObserver()
        subscribeTaskGroupObserver()
    }

    private fun subscribeTaskGroupObserver(){
        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrp Response: $taskGroupResponse")
                        taskGroupResponse?.taskGroups?.forEach { taskGroup ->
                            if(taskGroup.allocationType == viewModel.allocationType){
                                viewModel.setTaskGroup(taskGroup.code)
                            }
                        }
                    }
                    viewModel.checkAssignedTasks()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskGrp Error: $message")

                    }
                    viewModel.checkAssignedTasks()
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }
    }

    private fun subscribeNewPalletObserver() {
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            if (generatePalletCaseNumberResponse.numbers[0].type.equals(
                                    Constants.TRANSFER_TYPE_PALLET, ignoreCase = true
                                )
                            ) {
                                binding.etPalletNumber.text = null
                                validatePalletNumber(generatePalletCaseNumberResponse.numbers[0].value)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showErrorMessage(message: String) {
        with(binding) {
            etPalletNumber.selectAll()
            tvPalletNumberResponse.text = message
            showSoftKeyBoard(fragmentContext, etPalletNumber)
        }
    }


    private fun disableFields() {
        with(binding) {
            etPalletNumber.isEnabled = false
            etPalletNumber.isFocusable = false
            etPalletNumber.isFocusableInTouchMode = false
            etPalletNumber.alpha = 0.35f
            btnNewPallet.isEnabled = false
        }
    }

    /**
     * Function to subscribe task assigned response
     */
    private fun subscribeAssignedTaskValidationObserver() {
        viewModel.validateAssignedTaskResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateTaskAssignedResponse ->
                        if (validateTaskAssignedResponse.success != null && validateTaskAssignedResponse.success) {
                            FlareLog.i(TAG, "Pallet success: $validateTaskAssignedResponse")
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        disableFields()
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    /**
     * Function to subscribe pallet number validation
     */
    private fun subscribePalletValidationObserver() {
        viewModel.validatePalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletResponse ->
                        handlePalletSuccessResponse(palletResponse)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handlePalletSuccessResponse(palletResponse: TaskPickResponse) {
        viewModel.setPickTask(palletResponse)
        if (palletResponse.success != null && palletResponse.success) {
            FlareLog.i(TAG, "Pallet response success: $palletResponse")
            if (palletResponse.cartNbr != null) {
                palletResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
                navigateToPickLocation()
            }
        } else {
            FlareLog.i(TAG, "Pallet response fail: $palletResponse")
            if (palletResponse.cartIsReadyToEnd) {
                palletResponse.cartNbr?.let { showStagePendingDialog(it) }
            }
        }
    }

    /**
     * Function to show stage pending dialog
     */
    private fun showStagePendingDialog(cartNbr: String) {
        alertHandler.showSimpleAlert(
            message = getString(R.string.stage_pending_pallet_message, cartNbr),
            buttonTitle = getString(R.string.stage)
        ) {
            findNavController().navigate(R.id.casePickToPalletIDStageLocationFragment)
        }
    }

    /**
     * Function to navigate to pick location screen
     */
    private fun navigateToPickLocation() {
        val isCaseCountActive = pickMethodCodes.any { it == PIK_BY_CNT }
        val action = if (isCaseCountActive)
            CasePickToPalletIDPalletFragmentDirections.actionScanPalletIdToCasePickMethod()
        else
            CasePickToPalletIDPalletFragmentDirections.actionCasePickToPalletIDPalletToCasePickToPalletIDPickLocationFragment()

        findNavController().navigate(action)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.incProgressBar.visibility = View.VISIBLE
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.incProgressBar.visibility = View.GONE
    }

    /**
     * Function to scan the location barcode
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        val scannedValue = scan?.barcode.toString()
        binding.etPalletNumber.setText(scannedValue)
        binding.etPalletNumber.text?.length?.let {
            binding.etPalletNumber.setSelection(it)
        }
        FlareLog.i(TAG, "Pallet field focused")
        validatePalletNumber(scannedValue)
    }

    override fun onResume() {
        customVisibilityCallback?.onVisibilityChange(true)
        super.onResume()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        customVisibilityCallback = cb
        customVisibilityCallback?.onVisibilityChange(true)
    }
}