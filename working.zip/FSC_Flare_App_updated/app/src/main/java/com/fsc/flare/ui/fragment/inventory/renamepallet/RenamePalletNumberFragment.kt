package com.fsc.flare.ui.fragment.inventory.renamepallet

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRenamePalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventorymanagement.PalletDetailData
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "RenamePalletNumber"

/**
 * A simple RenamePalletNumberFragment
 */
@AndroidEntryPoint
class RenamePalletNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: RenamePalletViewModel by activityViewModels()
    private lateinit var binding: FragmentRenamePalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRenamePalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etPalletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                FlareLog.i(TAG, "Container field focused")
                validatePallet()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    /**
     * method to validate pallet from API
     */
    private fun validatePallet() {
        if (binding.etPalletNumber.text.toString().trim().isNotEmpty()) {
            //Get pallet detail.
            viewModel.getPalletDetail(binding.etPalletNumber.text.toString(), Constants.TRANSFER_TYPE_PALLET)
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        viewModel.palletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletDetailResponse ->
                        if (palletDetailResponse.success) {
                            val palletDetail = palletDetailResponse.palletInquiry
                            viewModel.setPalletDetailData(
                                PalletDetailData(
                                    palletDetail.palletNumber,
                                    palletDetail.currentLocation!!,
                                    palletDetail.noOfCase,
                                    palletDetail.palletQuantity,
                                    palletDetail.itemCode!!,
                                    palletDetail.itemDescription!!
                                )
                            )
                            navigateContainerView()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { it ->
                        binding.etPalletNumber.requestFocus()
                        binding.palletNumberResponse.text = it
                        binding.etPalletNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateContainerView() {
        binding.etPalletNumber.text = null
        val action = RenamePalletNumberFragmentDirections.actionRenamePalletNumberFragmentToRenamePalletDetailFragment()
        getNavigationController().navigate(action)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etPalletNumber.setText(scan?.barcode.toString())
                binding.etPalletNumber.text?.length?.let {
                    binding.etPalletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container field focused")
                    validatePallet()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}