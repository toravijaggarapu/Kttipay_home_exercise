package com.fsc.flare.ui.fragment.account

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentAccountBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.MenuType
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.UserCustomer
import com.fsc.flare.source.data.dto.login.UserFacilityBusinessUnit
import com.fsc.flare.source.data.dto.login.UserModulesByCustomer
import com.fsc.flare.ui.fragment.home.HomeAdapter
import com.fsc.flare.utils.ExpandableRecyclerAdapter
import com.fsc.flare.utils.MainMenuAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.StringUtils
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "AccountFragment"

/**
 * A simple [AccountFragment] class.
 */
@AndroidEntryPoint
class AccountFragment : BaseFragment(), HomeAdapter.OnAdapterClickListener {

    private val viewModel: AccountViewModel by activityViewModels()
    private var adapterCustomer: MainMenuAdapter? = null
    private var adapterWhs: MainMenuAdapter? = null
    private lateinit var binding: FragmentAccountBinding
    lateinit var navController: NavController
    private var userModulesByCustomer: List<UserModulesByCustomer>? = null
    private var userCustomers: List<UserCustomer>? = null

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        (activity as AppCompatActivity).supportActionBar?.title = getString(R.string.lbl_flare)
        super.onResume()
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.logout)?.isVisible = true
        if(sharedPreferences.getBoolean(PreferenceKeys.IS_LANGUAGE_LOOKUP_CONFIGURED,false)){
            menu.findItem(R.id.language)?.isVisible = true
        }
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentAccountBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.fetchAuthMenu.observe(viewLifecycleOwner) { authorizedMenusResponse ->
            handleAuthorizedMenusResponse(authorizedMenusResponse)
        }

        viewModel.updateLanguage.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data != null) {
                        FlareLog.i(TAG, "Language Update Response: ${response.data}")
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()

                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.customerDetailsState.observe(viewLifecycleOwner) { customerState ->
            customerState?.let {
                when(it) {
                    CustomerDetailsFetchState.Loading -> {
                        binding.progressBarAccount.visibility = View.VISIBLE
                    }

                    CustomerDetailsFetchState.NavigateToHome -> {
                        binding.progressBarAccount.visibility = View.GONE
                        viewModel.clearStates()
                        val action = AccountFragmentDirections.actionAccountFragmentToHomeFragment()
                        getNavigationController().navigate(action)
                    }
                }
            }
        }
    }

    private fun handleAuthorizedMenusResponse(authorizedMenusResponse: Resource<AuthorizedMenu>) {
        when (authorizedMenusResponse) {
            is Resource.Success -> {
                hideProgressBar()
                if (authorizedMenusResponse.data != null) {
                    FlareLog.i(TAG, "AuthMenuResponse: $authorizedMenusResponse")
                    if (authorizedMenusResponse.data.success) {
                        FlareLog.i(TAG, "AuthMenuResponse success: ${authorizedMenusResponse.data}")
                        userCustomers = authorizedMenusResponse.data.userCustomers
                        userModulesByCustomer = authorizedMenusResponse.data.userModulesByCustomer

                        binding.customerSelectionLayout.visibility = View.VISIBLE
                        val userCustomerList: MutableList<MainMenuAdapter.ListItem> = generateUserCustomersMultipleBU(userCustomers!!)
                        initCustomerMenuMultipleBU(userCustomerList)

                      /*  if (userCustomers?.size == 1) {
                            // Single Customer
                            sharedPreferences.apply {
                                sharedPreferences.edit().putInt(PreferenceKeys.CUST_ID, userCustomers!![0].custId).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.CUST_CODE, userCustomers!![0].custCode).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.CUST_NAME, userCustomers!![0].custName).apply()
                            }
                            if (userCustomers?.isNotEmpty()==true&&userCustomers?.get(0)?.userFacilityBusinessUnits?.size == 1) {
                                // Single Customer - Single Business Unit
                                sharedPreferences.apply {
                                    sharedPreferences.edit()
                                        .putInt(PreferenceKeys.FACILITY_ID, userCustomers!![0].userFacilityBusinessUnits[0].facilityId)
                                        .apply()
                                    sharedPreferences.edit().putInt(
                                        PreferenceKeys.BUSINESS_UNIT_ID,
                                        userCustomers!![0].userFacilityBusinessUnits[0].businessUnitId
                                    ).apply()
                                }
                                binding.customerSelectionLayout.visibility = View.GONE
                                binding.menuRecycler.visibility = View.VISIBLE
                             //   tempFIxSingleCustomerSingleBusinessUnit(userCustomers!![0].custId,userCustomers!![0].custCode,userCustomers!![0].custName,userCustomers!![0].userFacilityBusinessUnits[0].facilityId,userCustomers!![0].userFacilityBusinessUnits[0].businessUnitId)
                                generateSubMenuListSingleCustomer(userModulesByCustomer!!)
                            } else {
                                // Single Customer - Multiple Business Units
                                binding.customerRecycler.visibility = View.GONE
                                binding.tvCustomer.visibility = View.VISIBLE
                                binding.tvCustomer.text = sharedPreferences.getString(PreferenceKeys.CUST_NAME, null)
                                val businessUnits = userCustomers?.get(0)?.userFacilityBusinessUnits
                                businessUnits?.let {
                                    val businessUnitList: MutableList<MainMenuAdapter.ListItem> = generateBusinessUnitBySelectedCustomer(businessUnits)
                                    initBusinessUnitMenu(businessUnitList)
                                }

                            }
                        } else if (userCustomers!!.size > 1) {
                            // Multiple Customer - Multiple Business Unit
                            binding.customerSelectionLayout.visibility = View.VISIBLE
                            val userCustomerList: MutableList<MainMenuAdapter.ListItem> = generateUserCustomersMultipleBU(userCustomers!!)
                            initCustomerMenuMultipleBU(userCustomerList)
                        }*/
                    }
                }
            }
            is Resource.Error -> {
                hideProgressBar()
                authorizedMenusResponse.message?.let { message ->
                    FlareLog.e(TAG, "AuthMenuResponse error: $message")
                    showErrorSnackBar(message)
                }
            }
            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun tempFIxSingleCustomerSingleBusinessUnit(custId: Int, custCode: String, custName: String, facilityId: Int, businessUnitId: Int) {
            sharedPreferences.apply {
                sharedPreferences.edit().putInt(PreferenceKeys.FACILITY_ID, facilityId).apply()
                sharedPreferences.edit().putInt(PreferenceKeys.BUSINESS_UNIT_ID, businessUnitId).apply()
                sharedPreferences.edit().putString(PreferenceKeys.CUST_NAME, custName).apply()
                sharedPreferences.edit().putString(PreferenceKeys.CUST_CODE, custCode).apply()
                sharedPreferences.edit().putInt(PreferenceKeys.CUST_ID, custId).apply()
            }
        viewModel.fetchSelectedCustomerDetailsAndSaveEnrollmentType(custId)
    }

    private fun initCustomerMenuMultipleBU(userCustomerList: MutableList<MainMenuAdapter.ListItem>) {
        adapterCustomer = MainMenuAdapter(
            requireContext(), userCustomerList
        ) { _, custId, custCode, custname, facilityId, _, _ ->
            onMenuItemMultiCustomerMultiBUSelected(
                custId,
                custCode,
                custname,
                facilityId
            )
        }
        adapterCustomer!!.mode = ExpandableRecyclerAdapter.MODE_ACCORDION
        binding.customerRecycler.layoutManager = LinearLayoutManager(requireContext())
        binding.customerRecycler.isNestedScrollingEnabled = false
        binding.customerRecycler.adapter = adapterCustomer
    }

    private fun onMenuItemMultiCustomerMultiBUSelected(custId: Int, custCode: String?, custName: String?, facilityId: Int) {
        sharedPreferences.apply {
            sharedPreferences.edit().putString(PreferenceKeys.CUST_NAME, custName).apply()
            sharedPreferences.edit().putString(PreferenceKeys.CUST_CODE, custCode).apply()
            sharedPreferences.edit().putInt(PreferenceKeys.CUST_ID, custId).apply()
        }

        var businessUnits = userCustomers!![facilityId].userFacilityBusinessUnits
        if(businessUnits.size == 1){
            // Save the BusinessUnit Data and Navigate to HomeFragment
            val businessUnitList: MutableList<MainMenuAdapter.ListItem> = generateBusinessUnitBySelectedCustomer(businessUnits)
            val busiessUnit = businessUnitList[1]
            saveUserSelectedCustomerAndBusinessUnitData(busiessUnit.mCustId,busiessUnit.mCustCode,busiessUnit.mCustName,busiessUnit.mFacilityId,busiessUnit.mBusinessUnitId,busiessUnit.mBusinessUnitCode)
            viewModel.fetchSelectedCustomerDetailsAndSaveEnrollmentType(busiessUnit.mCustId)
        }
        else {
          // Display "Select Business Unit" View
            binding.facilityRecycler.visibility = View.VISIBLE
            val businessUnitList: MutableList<MainMenuAdapter.ListItem> = generateBusinessUnitBySelectedCustomer(businessUnits)
            initBusinessUnitMenu(businessUnitList)
        }
    }

    private fun generateUserCustomersMultipleBU(userCustomers: List<UserCustomer>): MutableList<MainMenuAdapter.ListItem> {
        val items: MutableList<MainMenuAdapter.ListItem> = ArrayList()
        items.add(MainMenuAdapter.ListItem(-1, null, getString(R.string.lbl_select_customer), -1, -1, R.drawable.perm_identity, MenuType.HEADER))
        for (customer in userCustomers) {
            items.add(
                MainMenuAdapter.ListItem(
                    customer.custId,
                    customer.custCode,
                    customer.custName,
                    userCustomers.indexOf(customer),
                    userCustomers.indexOf(customer),
                    -1,
                    MenuType.SUB_HEADER
                )
            )
        }
        return items
    }

    private fun initBusinessUnitMenu(businessUnitList: MutableList<MainMenuAdapter.ListItem>) {
        adapterWhs = MainMenuAdapter(
            requireContext(), businessUnitList
        ) { _, custId, custCode, custname, facilityId, businessUnitId, businessUnitCode ->
            onSubMenuItemSelected(
                custId,
                custCode,
                custname,
                facilityId,
                businessUnitId,
                businessUnitCode
            )
        }
        adapterWhs!!.mode = ExpandableRecyclerAdapter.MODE_ACCORDION
        binding.facilityRecycler.layoutManager = LinearLayoutManager(requireContext())
        binding.facilityRecycler.isNestedScrollingEnabled = false
        binding.facilityRecycler.adapter = adapterWhs
    }

    private fun generateBusinessUnitBySelectedCustomer(businessUnits: List<UserFacilityBusinessUnit>): MutableList<MainMenuAdapter.ListItem> {
        val items: MutableList<MainMenuAdapter.ListItem> = ArrayList()
        items.add(MainMenuAdapter.ListItem(-1, null, getString(R.string.lbl_select_business_unit), -1, -1, R.drawable.ic_settings, MenuType.HEADER))
        businessUnits.forEach { businessUnit ->
            items.add(
                MainMenuAdapter.ListItem(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getString(PreferenceKeys.CUST_CODE, null),
                    businessUnit.businessUnitName + " - " + businessUnit.facilityName,
                    businessUnit.facilityId,
                    businessUnit.businessUnitId,
                    businessUnit.businessUnitCode,
                    -1,
                    MenuType.SUB_HEADER
                )
            )
        }
        return items
    }

    private fun hideProgressBar() {
        binding.progressBarAccount.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBarAccount.visibility = View.VISIBLE
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        if (isNetworkConnected()) {
            viewModel.fetchAuthorizedMenu()
        } else {
            showErrorSnackBar(resources.getString(R.string.network_error_occurred))
        }
    }

    private fun onMenuItemMultiCustomerSingleBUSelected(custId: Int, custCode: String, custName: String, facilityId: Int, businessUnitId: Int) {
        sharedPreferences.apply {
            sharedPreferences.edit().putInt(PreferenceKeys.FACILITY_ID, facilityId).apply()
            sharedPreferences.edit().putInt(PreferenceKeys.BUSINESS_UNIT_ID, businessUnitId).apply()
            sharedPreferences.edit().putString(PreferenceKeys.CUST_NAME, custName).apply()
            sharedPreferences.edit().putString(PreferenceKeys.CUST_CODE, custCode).apply()
            sharedPreferences.edit().putInt(PreferenceKeys.CUST_ID, custId).apply()
        }
        viewModel.fetchSelectedCustomerDetailsAndSaveEnrollmentType(custId)
    }

    override fun onItemSelected(item: String?, menuID:String?) {
        val menuName = StringUtils.langConvertedName(menuID,item, context)
        val bundle = bundleOf(
            "displayName" to menuName,
            "rootMenuName" to item
        )
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
        /*when (item) {
            "INBOUND" -> {
              *//*  val bundle = bundleOf(
                    "displayName" to "INBOUND"
                )*//*
                FlareLog.i(TAG,"INBOUND selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            "OUTBOUND" -> {
                *//*val bundle = bundleOf(
                    "displayName" to "OUTBOUND"
                )*//*
                FlareLog.i(TAG,"OUTBOUND selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            "REPLENISH" -> {
               *//* val bundle = bundleOf(
                    "displayName" to "REPLENISH"
                )*//*
                FlareLog.i(TAG,"REPLENISH selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            "CYCLE COUNT" -> {
               *//* val bundle = bundleOf(
                    "displayName" to "CYCLE COUNT"
                )*//*
                FlareLog.i(TAG,"CYCLECOUNT selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            "INQUIRY" -> {
               *//* val bundle = bundleOf(
                    "displayName" to "INQUIRY"
                )*//*
                FlareLog.i(TAG,"INQUIRY selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            "SHIPPING" -> {
               *//* val bundle = bundleOf(
                    "displayName" to "SHIPPING"
                )*//*
                FlareLog.i(TAG,"SHIPPING selected")
                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                navController.navigate(R.id.action_accountFragment_to_submenufragment, bundle)
            }
            else -> Toast.makeText(requireActivity(), "Clicked on $item", Toast.LENGTH_SHORT)
                .show()
        }*/
    }

    private fun onSubMenuItemSelected(custId: Int, custCode: String, custName: String, facilityId: Int, businessUnitId: Int, businessUnitCode: String) {
        saveUserSelectedCustomerAndBusinessUnitData(custId,
            custCode,
            custName,
            facilityId,
            businessUnitId,
            businessUnitCode)
        viewModel.fetchSelectedCustomerDetailsAndSaveEnrollmentType(custId)
    }
    fun updateLanguage()
    {
        val selectedLang = sharedPreferences.getString(PreferenceKeys.APP_LANGUAGE, "en")
        viewModel.updateAppLanguage(selectedLang!!)
    }

    fun saveUserSelectedCustomerAndBusinessUnitData(custId: Int, custCode: String?, custName: String?, facilityId: Int, businessUnitId: Int, businessUnitCode: String){
        sharedPreferences.apply {
            sharedPreferences.edit().putInt(PreferenceKeys.FACILITY_ID, facilityId).apply()
            sharedPreferences.edit().putInt(PreferenceKeys.BUSINESS_UNIT_ID, businessUnitId).apply()
            sharedPreferences.edit().putString(PreferenceKeys.BUSINESS_UNIT_CODE, businessUnitCode).apply()

            var facilityName = custName ?: ""
            val facilityNames =  facilityName.split(" - ")
            facilityName = if(facilityNames.size > 1) facilityNames[1] else facilityNames[0]

            sharedPreferences.edit().putString(PreferenceKeys.FACILITY_NAME, facilityName).apply()
            FlareLog.d(TAG, "FacilityName: " + facilityName)
            FlareLog.i(TAG, "SubmenuItem- FacilityID:" + facilityId + "BusinessId:" + businessUnitId)
        }
    }

}