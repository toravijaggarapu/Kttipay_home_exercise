package com.fsc.flare.ui.fragment.staging

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStagingPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "StagingPalletFragment"
@AndroidEntryPoint
class StagingPalletFragment : BaseFragment(), FlareScannable {

    private val RECALL_PALLET_STAGING_ERROR_CODE = "ERR-STG-RC-001"

    private val viewModel: StagingViewModel by activityViewModels()
    private lateinit var binding: FragmentStagingPalletBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStagingPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvPalletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etPalletNumber.isFocused && !binding.etPalletNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "PalletNumber field focused")
                        validatePalletNumber()

                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etPalletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                FlareLog.i(TAG, "PalletNumber field focused")
                validatePalletNumber()
            }
            false
        }
    }

    /**
     * method to validate carton/pallet number
     */
    private fun validatePalletNumber() {
        viewModel.obCartonDetailsRequest(obContainerNumber = binding.etPalletNumber.text.toString())
    }


    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        observeOBContainerResponse()
        observeRecallContainersResponse()
        observePalletInventoryResponse()
    }

    /**
     * method to subscribe pallet number observer
     */
    private fun observeOBContainerResponse() {
        viewModel.obContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { obContainerResponse ->
                        if (obContainerResponse.containerDetails.isNullOrEmpty()) {
                            binding.tvPalletNumberResponse.text = resources.getString(R.string.invalid_pallet_number)
                            binding.etPalletNumber.requestFocus()
                            binding.etPalletNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                        } else {
                                FlareLog.i(TAG, "obContainerResponse Success response: $obContainerResponse")
                                val containerData = obContainerResponse.containerDetails[0]
                                if (containerData.status != 99 && containerData.status != 300 && containerData.containerType == "P") {
                                    viewModel.setContainerResponse(containerData)
                                    sharedPreferences.edit().putString(PreferenceKeys.STAGING_PALLET_NUMBER, binding.etPalletNumber.text.toString())
                                        .apply()
                                    sharedPreferences.edit().putInt(PreferenceKeys.STAGING_PALLET_ID, containerData.containerId?:0)
                                        .apply()
                                    binding.etPalletNumber.text = null
                                    viewModel.getPalletInventory(null, palletId = obContainerResponse.containerDetails[0].containerId)
                                } else {
                                    binding.tvPalletNumberResponse.text = resources.getString(R.string.invalid_pallet_number)
                                    binding.etPalletNumber.requestFocus()
                                    binding.etPalletNumber.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
                                }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "palletNumberResponse Error response: $message")
                        handleValidatePalletNumberErrorResponse(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun observePalletInventoryResponse() {
        viewModel.palletInventoryCountResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { invResponse ->
                        if (invResponse != null) {
                            if (invResponse.success) {
                                viewModel.casesInPallet = invResponse.caseCount
                                navigateToNextScreen()
                            } else {
                                binding.tvPalletNumberResponse.text = getString(R.string.invalid_pallet_number)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToNextScreen() {
        val action = StagingPalletFragmentDirections.actionStagingPalletNumberToStagingLocationFragment()
        findNavController().navigate(action)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etPalletNumber.setText(scan?.barcode.toString())
                binding.etPalletNumber.text?.length?.let {
                    binding.etPalletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "PalletNumber field focused")
                    validatePalletNumber()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun handleValidatePalletNumberErrorResponse(msg: String) {
        val errorMessage = msg.split("##")
        val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
        when {
            errorMessage[0].equals(RECALL_PALLET_STAGING_ERROR_CODE, ignoreCase = true) -> {
                displayRecallContainers(responseMessage)
            }
            else -> {
                displayErrorMessage(responseMessage)
            }
        }
    }

    private fun displayErrorMessage(message:String){
        binding.etPalletNumber.requestFocus()
        binding.tvPalletNumberResponse.text = message
        binding.etPalletNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etPalletNumber)
    }

    private fun displayRecallContainers(errorMessage: String) {
        showAlertDialog("",errorMessage,getString(R.string.alert_button_ok), onPositiveClick = {
                dialog: DialogInterface -> dialog.dismiss()

        },getString(R.string.lbl_view_recall_containers), onNegativeClick = {
                dialog: DialogInterface ->

            dialog.dismiss()
            val palletNumber = binding.etPalletNumber.text.toString()
            if(palletNumber.isNotEmpty()) {
                // call view recall containers api
                viewModel.viewRecallContainersAPIRequest(palletNumber)
            }
        })
    }

    /**
     * Function to observe Recall Containers Api response
     */
    private fun observeRecallContainersResponse() {
        viewModel.obCartonRCLockResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObCartonRCLockSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObCartonRCLockErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Recall Containers success response
     */
    private fun handleObCartonRCLockSuccessResponse(data: OBCartonRCLockResponse?) {
        binding.etPalletNumber.setText("")
        data?.containers?.let { containers ->
            displayRecallContainersDialog(containers)
        }
    }

    /**
     * Function to handle Recall Containers error response
     */
    private fun handleObCartonRCLockErrorResponse(message: String?) {
        message?.let { errorMessage -> displayErrorMessage(errorMessage) }
    }

    /**
     * Function to display Recall Containers dialog
     */
    private fun displayRecallContainersDialog(containers: List<Container>) {
        showAlertDialog(getString(R.string.lbl_recalled_containers),containers.map { it.containerNumber }.toTypedArray(),getString(R.string.alert_dialog_close_btn))
    }

}