package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MixedSBPutAwayRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun validateToContainer(msbPutawayRequest: MSBPutawayRequest) =
        apiGatewayInterface.mixedSBPutawayValidateToContainer(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            msbPutawayRequest = msbPutawayRequest
        )

    suspend fun validateToLocation(msbPutawayRequest: MSBPutawayRequest) =
        apiGatewayInterface.mixedSBPutawayValidateToLocation(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            msbPutawayRequest = msbPutawayRequest
        )

    suspend fun validateSerialNumber(msbPutawayRequest: MSBPutawayRequest) =
        apiGatewayInterface.mixedSBPutawayValidateSerialNumber(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            msbPutawayRequest = msbPutawayRequest
        )

    suspend fun submitPutaway(msbPutawayRequest: MSBPutawayRequest) =
        apiGatewayInterface.mixedSBPutawaySubmit(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            msbPutawayRequest = msbPutawayRequest
        )

}