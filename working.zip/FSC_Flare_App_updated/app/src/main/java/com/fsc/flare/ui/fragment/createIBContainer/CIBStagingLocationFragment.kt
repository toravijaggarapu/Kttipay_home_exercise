package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.createIBContainer.CIBPostRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBStagingLocationFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBStagingLocationFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBStagingLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBStagingLocationBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etStagingLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvStagingLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val itemData = viewModel.getItemBarcodeData()
        if(itemData!=null){
            binding.tvItemCodeValue.text = itemData.itemBarCode
            binding.tvItemDescValue.text = itemData.description
        }
        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.tvQtyUomValue.text = String.format("%d units",viewModel.getInputQtyInUnits())
        if (viewModel.getInputLockCode() == null) {
            binding.glLockCode.visibility = View.GONE
        } else {
            binding.glLockCode.visibility = View.VISIBLE
            binding.tvLockCodeValue.text = viewModel.getInputLockCode()?.description
        }
        if (viewModel.getInputReasonCode() == null) {
            binding.glReasonCode.visibility = View.GONE
        } else {
            binding.glReasonCode.visibility = View.VISIBLE
            binding.tvReasonCodeValue.text = viewModel.getInputReasonCode()?.lookupCodeDescription
        }

        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                FlareLog.i(TAG, "Staging Location field focused")
                if (!binding.etStagingLocation.text.isNullOrEmpty()) {
                    validateStagingLocation()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Staging Location field focused")
                        validateStagingLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnSubmit.setOnClickListener {
            callCreateIBContainerAPI()
        }

    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeStagingLocationObserver()
        subscribeCreateIBContainerObserver()
    }


    /**
     * method to validate Staging Location from API
     */
    private fun validateStagingLocation() {
        viewModel.validateStagingLocation(
            LocationClassReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etStagingLocation.text.toString(),
                "S"
            )
        )
    }

    /**
     * method to subscribe Staging Location observer
     */
    private fun subscribeStagingLocationObserver() {
        viewModel.stagingLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { stagingLocationResponse ->
                        if (stagingLocationResponse != null && stagingLocationResponse.success) {
                            if (stagingLocationResponse.locations != null && stagingLocationResponse.locations.isNotEmpty()) {
                                viewModel.setInputStagingLocation(binding.etStagingLocation.text.toString())
                                binding.btnSubmit.isEnabled = true
                            } else {
                                stageLocationError()
                            }
                        } else {
                            stageLocationError()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { showErrorSnackBar(it) }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to call post API to create IB Container
     */
    private fun callCreateIBContainerAPI() {
        viewModel.createIBContainer(
            CIBPostRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                caseNbr = viewModel.getInputContainerNumber()?:"",
                coo = viewModel.getInputCoo(),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                expiryDate = getExpiryDate(),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                itemId = viewModel.getItemBarcodeData()?.itemId?:0,
                locationCode = viewModel.getInputStagingLocation()?:"",
                lockCodes = getLockCodes(),
                lotNumber = viewModel.getInputLotNumber(),
                qty = viewModel.getInputQty()?:0,
                qtyUom = viewModel.getInputQtyUom()?:"",
                reasonCode = getReasonCode(),
                serialNumbers = viewModel.getSerialNumberList()?: arrayListOf()
            )
        )
    }

    /**
     * method to get expiry date with time format
     */
    private fun getExpiryDate(): String? {
        if (viewModel.getInputExpiryDate() != null) {
            return viewModel.getInputExpiryDate()
        }
        return null
    }

    /**
     * method to subscribe create IB Container observer
     */
    private fun subscribeCreateIBContainerObserver() {
        viewModel.cibPostResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success) {
                            if (response.message != null) {
                                showCustomDialog(response.message) { navigateToContainerScreen() }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to navigate back to Container screen
     */
    private fun navigateToContainerScreen() {
        viewModel.resetToDefault()
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action =
            CIBStagingLocationFragmentDirections.actionStagingLocationFragmentToContainerFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.cibContainerFragment, true).build()
        navController.navigate(action, navOptions)
    }

    /**
     * method to get user selected reason code
     */
    private fun getReasonCode(): String {
        val reasonCode = viewModel.getInputReasonCode()
        if (reasonCode != null) {
            return reasonCode.lookupCode
        }
        return ""
    }

    /**
     * method to get user selected lock code with default lock code "Pending Putaway"
     */
    private fun getLockCodes(): List<String> {
        val lockCodeList = ArrayList<String>()
        val defaultLockCode = viewModel.getDefaultLockCode()!!.code
        if (defaultLockCode != null) {
            lockCodeList.add(defaultLockCode)
        }
        val userSelectedLockCode = viewModel.getInputLockCode()
        if (userSelectedLockCode != null) {
            userSelectedLockCode.code?.let {
                if (userSelectedLockCode.code != defaultLockCode)
                    lockCodeList.add(it)
            }
        }
        return lockCodeList
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etStagingLocation.setText(scan?.barcode.toString())
                binding.etStagingLocation.text?.length?.let {
                    binding.etStagingLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Staging Location field focused")
                    validateStagingLocation()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun stageLocationError(){
        binding.tvStagingLocationResponse.text = resources.getString(R.string.invalid_location)
        binding.etStagingLocation.requestFocus()
        binding.etStagingLocation.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etStagingLocation)
    }
}