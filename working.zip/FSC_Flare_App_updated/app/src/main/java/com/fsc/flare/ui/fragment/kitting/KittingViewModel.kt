package com.fsc.flare.ui.fragment.kitting

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.kitting.Item
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.source.data.dto.kitting.KittingCompleteRequest
import com.fsc.flare.source.data.dto.kitting.KittingCompleteResponse
import com.fsc.flare.source.data.dto.kitting.KittingContainerResponse
import com.fsc.flare.source.data.dto.kitting.KittingDescriptionResponse
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.repository.KittingRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "KittingViewModel"

@HiltViewModel
class KittingViewModel @Inject constructor(private val kittingRepository: KittingRepository) :
    BaseViewModel() {

    private val _kittingpalletorcaseresponse = SingleLiveEvent<Resource<CaseTransferContainerResponse>>()
    private val _kittingcontainerresponse = SingleLiveEvent<Resource<KittingContainerResponse>>()
    private val _kittingcompleteresponse = SingleLiveEvent<Resource<KittingCompleteResponse>>()
    private val _locationResponse = SingleLiveEvent<Resource<LocationClassRes>>()
    private val _kittingdescriptionResponse = SingleLiveEvent<Resource<KittingDescriptionResponse>>()
    val packageItemResponse: MutableLiveData<Resource<PackageItemResponse>> = SingleLiveEvent()
    private val palletResponse: MutableLiveData<PalletResponse> = MutableLiveData()

    // Send PR API
    val sendToPRResponse: MutableLiveData<Resource<SendToPRResponse>> = SingleLiveEvent()
    private lateinit var moveQty: String
    private lateinit var selectedLot: String
    private lateinit var item: Item
    private var destinationLocation: String? = null
    private var destinationLocationId: Int = 0

    fun getMoveQty(): String {
        return moveQty
    }

    fun setMoveQty(qty: String) {
        this.moveQty = qty
    }

    private var _lot: String? = null
    val lot: String?
        get() = _lot

    // Function to set lot value
    fun setLot(lotValue: String, isApiSuccess: Boolean) {
        _lot = if (isApiSuccess) {
            null
        } else {
            lotValue
        }
    }

    private var _selectedItem: Item? = null

    val selectedItem: Item?
        get() = _selectedItem

    fun setItem(item: Item) {
        _selectedItem = item
    }

    private var _kitItem = KitItem()

    val kitItem: KitItem
        get() = _kitItem

    fun setKitItem(item: KitItem) {
        _kitItem = item
    }

    fun getDestinationLocation(): String {
        return destinationLocation ?: ""
    }

    fun setDestinationLocation(destinationLocation: String) {
        this.destinationLocation = destinationLocation
    }

    fun getDestinationLocationId(): Int {
        return destinationLocationId
    }

    fun setDestinationLocationId(destinationLocationId: Int) {
        this.destinationLocationId = destinationLocationId
    }

    fun getPalletResponse(): PalletResponse {
        return palletResponse.value!!
    }

    fun setPalletResponse(palletResponse: PalletResponse) {
        this.palletResponse.value = palletResponse
    }

    fun getKittingContainerResponse(): LiveData<Resource<KittingContainerResponse>> {
        return _kittingcontainerresponse
    }

    fun updateLotQty(qty:Int) {
        val palletResponse = getPalletResponse()
        if (palletResponse != null) {
            palletResponse.totalQty = qty
        }
    }
    fun getKittingDescriptionResponse() : LiveData<Resource<KittingDescriptionResponse>>{
        return _kittingdescriptionResponse
    }

    fun getKittingCompleteResponse(): LiveData<Resource<KittingCompleteResponse>> {
        return _kittingcompleteresponse
    }

    fun getLocationResponse(): LiveData<Resource<LocationClassRes>> {
        return _locationResponse
    }

    var serialNumberList: List<String>? = null
    fun fetchSerialNumberList(): List<String>? {
        return serialNumberList
    }

    var validatedSerialNumberList = mutableListOf<String>()
    fun fetchValidatedSerialNumberList(): MutableList<String> {
        return validatedSerialNumberList
    }

    val lotSerialsMap: MutableMap<String, List<String>> = mutableMapOf()

    fun getSerialNumbersFromLot(lotNumber: String): List<String> {
        return lotSerialsMap[lotNumber] ?: emptyList()
    }

    fun getCasePallet(container: String, itemInfo: String) = viewModelScope.launch {
        _kittingpalletorcaseresponse.postValue(Resource.Loading())
        val response = kittingRepository.getCasePallet(container, itemInfo)
        _kittingpalletorcaseresponse.postValue(handleContainerResponse(response))
    }

    fun getKittingCasePallet(containerNbr: String, locationClass: String) = viewModelScope.launch {
        _kittingcontainerresponse.postValue(Resource.Loading())
        val response = kittingRepository.getKittingCasePallet(containerNbr, locationClass)
        _kittingcontainerresponse.postValue(handleKittingContainerResponse(response))
    }

    fun getKittingItemDescription(containerId: Int) = viewModelScope.launch {
        _kittingdescriptionResponse.postValue(Resource.Loading())
        val response = kittingRepository.getKittingItemDescription(containerId)
        _kittingdescriptionResponse.postValue(handleKittingDescriptionResponse(response))
    }

    private fun handleContainerResponse(response: Response<CaseTransferContainerResponse>): Resource<CaseTransferContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingPalletOrCaseResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingPalletOrCaseResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun handleKittingContainerResponse(response: Response<KittingContainerResponse>): Resource<KittingContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingContainerResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    private fun handleKittingDescriptionResponse(response: Response<KittingDescriptionResponse>): Resource<KittingDescriptionResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingDescriptionResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingDescriptionResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateKittingComplete(kittingCompleteRequest: KittingCompleteRequest) = viewModelScope.launch {
        _kittingcompleteresponse.postValue(Resource.Loading())
        val response = kittingRepository.validateKittingComplete(kittingCompleteRequest = kittingCompleteRequest)
        _kittingcompleteresponse.postValue(handleKittingCompleteResponse(response))
    }

    private fun handleKittingCompleteResponse(response: Response<KittingCompleteResponse>): Resource<KittingCompleteResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingCompleteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingCompleteResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateDestinationLocation(locBarcode: String) = viewModelScope.launch {
        _locationResponse.postValue(Resource.Loading())
        val response = kittingRepository.validateLocation(locBarcode)
        _locationResponse.postValue(handleLocationResponse(response))
    }

    private fun handleLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { locationResponse ->
                FlareLog.i(TAG, "LocationResponse Success: $locationResponse")
                return Resource.Success(locationResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getItems(packageItemRequest: PackageItemRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getItems Request: $packageItemRequest")
        packageItemResponse.postValue(Resource.Loading())
        val packageItemRes = kittingRepository.getItems(packageItemRequest)
        packageItemResponse.postValue(handlePackageItemResponse(packageItemRes))
    }

    private fun handlePackageItemResponse(packageItemResponse: Response<PackageItemResponse>): Resource<PackageItemResponse>? {
        if (packageItemResponse.isSuccessful) {
            packageItemResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackageItemResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(packageItemResponse.code(), packageItemResponse.errorBody(), packageItemResponse.message())
            FlareLog.e(TAG, "PackageItemResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun sendToPR(request: SendToPRRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm SendToPR Request:")
        sendToPRResponse.postValue(Resource.Loading())
        val response = kittingRepository.sendToPR(request)
        sendToPRResponse.postValue(handleSendToPRResponse(response))
    }

    private fun handleSendToPRResponse(response: Response<SendToPRResponse>): Resource<SendToPRResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SendToPRResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "SendToPRResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}