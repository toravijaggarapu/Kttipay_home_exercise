package com.fsc.flare.ui.fragment.palletrepack

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletRepackDestLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRSubmitRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "PalletRepackDestLocationFragment"

@AndroidEntryPoint
class PalletRepackDestLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletRepackViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletRepackDestLocationBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletRepackDestLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etDestLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvDestLocationResponse.text = null
                binding.btnSubmit.isEnabled = s.toString().trim().isNotEmpty()
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val palletRepackData = viewModel.getPalletData()
        binding.tvPalletNumberValue.text = palletRepackData.palletNumber
        binding.tvNoOfContainerValue.text =
            resources.getQuantityString(R.plurals.pallet_transfer_cases, palletRepackData.noOfContainer, palletRepackData.noOfContainer)
        binding.tvPalletQtyValue.text =
            resources.getQuantityString(R.plurals.pallet_transfer_units, palletRepackData.palletQty, palletRepackData.palletQty)
        binding.tvItemCodeValue.text = palletRepackData.itemCode
        binding.tvItemDescValue.text = palletRepackData.itemDesc

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etDestLocation.isFocused && binding.etDestLocation.text.toString().trim().isNotEmpty()) {
                        FlareLog.i(TAG, "Destination Location field focused")
                        validateDestLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etDestLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etDestLocation)
                FlareLog.i(TAG, "Destination Location field focused")
                validateDestLocation()
            }
            false
        }

        binding.btnSubmit.setOnClickListener {
            callSubmitMPRAPI()
        }

    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSubmitMPRObserver()
    }


    /**
     * method to validate destination location
     */
    private fun validateDestLocation() {
        if (!binding.etDestLocation.text.isNullOrEmpty()) {
            binding.btnSubmit.isEnabled = true
        }
    }

    /**
     * method to call Submit MPR API
     */
    private fun callSubmitMPRAPI() {
        viewModel.submitMPR(
            MPRSubmitRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                destinationLocation = binding.etDestLocation.text.toString(),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                palletNumber = viewModel.getPalletData().palletNumber,
                printCaseLabel = false,
                printPalletLabel = false,
                printer = "",
                transactionIdentifier = viewModel.getTempTableTransactionIdentifier()
            )
        )
    }

    /**
     * method to subscribe Submit MPR response observer
     */
    private fun subscribeSubmitMPRObserver() {
        viewModel.mprSubmitResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { submitMPRResponse ->
                        if (submitMPRResponse.success) {
                            if (submitMPRResponse.message != null) {
                                viewModel.setDataToDefault()
                                showCustomDialog(submitMPRResponse.message) {
                                    val navController =
                                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action =
                                        PalletRepackDestLocationFragmentDirections.actionPalletRepackDestLocationFragmentToPalletRepackPalletNumberFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.palletRepackPalletNumberFragment, true).build()
                                    navController.navigate(action, navOptions)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.etDestLocation.requestFocus()
                        binding.tvDestLocationResponse.text = message
                        binding.etDestLocation.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etDestLocation)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etDestLocation.setText(scan?.barcode.toString())
                binding.etDestLocation.text?.length?.let {
                    binding.etDestLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Destination Location field focused")
                    validateDestLocation()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}