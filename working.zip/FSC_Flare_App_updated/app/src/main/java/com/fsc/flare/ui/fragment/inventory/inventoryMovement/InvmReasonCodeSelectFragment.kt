package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReasonCodeSelectBinding
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.ReasonCodesResponse
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmReasoncodesSelectViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.utils.Constants.DamageReasonCodes.DAMAGE_IN_CONCEALED
import com.fsc.flare.utils.Constants.DamageReasonCodes.DAMAGE_IN_FACILITY
import com.fsc.flare.utils.Constants.DamageReasonCodes.DAMAGE_IN_TRANSIT
import com.fsc.flare.utils.Constants.TaskModes.USER_DIRECTED
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class InvmReasonCodeSelectFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmReasoncodesSelectViewModel by viewModels()
    private lateinit var binding: FragmentReasonCodeSelectBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View {
        binding = FragmentReasonCodeSelectBinding.inflate(inflater, container, false)
        observeEvents()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        handleNextButtonClick()
        binding.reasonCodesDropDown.boolFoo.observe(viewLifecycleOwner) { selectedReasonCode ->
            sharedViewModel.selectedReasonCode = sharedViewModel.reasonCodes?.firstOrNull { it.reasonCode == selectedReasonCode.substringBefore("-").trim() }
            viewModel.getDestinationLocation(sharedViewModel.sourceDetails.container, sharedViewModel.selectedReasonCode?.reasonCode ?: "")
        }
    }

    private fun handleNextButtonClick() {
        binding.btnNext.setOnClickListener {
            viewModel.getDestinationLocation(sharedViewModel.sourceDetails.container, sharedViewModel.selectedReasonCode?.reasonCode ?: "")
        }
    }

    private fun setupUI() {
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null).plus(" - ").plus(sharedViewModel.selectedTaskMode)
        binding.sourceDetails = sharedViewModel.sourceDetails
        binding.executePendingBindings()
        handleReasonCodeDropDown()
    }

    private fun handleReasonCodeDropDown() {
        callToGetReasonCodes()
    }

    private fun enableOrDisableReasonCode(isEnable: Boolean) {
        binding.reasonCodesDropDown.isEnabled = isEnable
        binding.reasonCodesDropDown.isFocusable = isEnable
        binding.reasonCodesDropDown.isFocusableInTouchMode = isEnable
        binding.reasonCodesDropDown.alpha = if (isEnable) 1f else 0.35f
    }

    private fun callToGetReasonCodes() {
        viewModel.getReasonCodes(sourceDetails = sharedViewModel.sourceDetails)
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.progressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { message ->
            binding.errResponse.text = message ?: ""
        }

        viewModel.listOfReasonCodes.observe(viewLifecycleOwner) { reasonCodes ->
            sharedViewModel.reasonCodes = reasonCodes
            val taskReasonCode = sharedViewModel.sourceDetails.data?.taskInfo?.taskDetails?.get(0)?.reasonCode
            val damageLocks = listOf(DAMAGE_IN_TRANSIT, DAMAGE_IN_FACILITY, DAMAGE_IN_CONCEALED)
            if (sharedViewModel.selectedTaskMode == USER_DIRECTED && damageLocks.contains(taskReasonCode)){
                val reasonCode = sharedViewModel.reasonCodes?.first { it.reasonCode == taskReasonCode }
                binding.btnNext.visibility = View.VISIBLE
                sharedViewModel.selectedReasonCode = reasonCode
                binding.reasonCodesDropDown.text = reasonCode?.reasonCode.plus(" - ").plus(reasonCode?.reasonCodeDescription)
                enableOrDisableReasonCode(false)
            }else{
                binding.reasonCodes = ReasonCodesResponse(data = reasonCodes)
            }
        }

        viewModel.getDestinationLocation.observe(viewLifecycleOwner) { response ->
            response?.let {
                sharedViewModel.getDestinationLocationResponse = response
                getNavigationController().navigate(InvmReasonCodeSelectFragmentDirections.actionInvmReasonCodeSelectFragmentToInvmDestinationLocationFragment())
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearStates()
    }

}