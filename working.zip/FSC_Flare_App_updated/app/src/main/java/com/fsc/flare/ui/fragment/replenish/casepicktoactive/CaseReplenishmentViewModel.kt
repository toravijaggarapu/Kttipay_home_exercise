package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.res.CycleCountTriggerResponse
import com.fsc.flare.source.data.dto.replenishment.ReplenPatchRequest
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.source.data.dto.replenishment.TaskDetails
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateRequest
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.ReplenishRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = CaseReplenishmentViewModel::class.java.simpleName.toString()
@HiltViewModel
class CaseReplenishmentViewModel @Inject constructor(
    private val replenishRepository: ReplenishRepository,
    sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)

    var givenCartonNbr = ""

    private val _caseOverride = SingleLiveEvent<Resource<ValidatePalletOverrideResponse>>()
    val caseOverrideResponse: LiveData<Resource<ValidatePalletOverrideResponse>>
        get() = _caseOverride

    private val _taskGroupResponse = SingleLiveEvent<Resource<TaskGroupResponse>>()
    val taskGroupResponse: LiveData<Resource<TaskGroupResponse>>
        get() = _taskGroupResponse

    val _taskGroupCodeOptions = MutableLiveData<ArrayList<String>>()
    val taskGroupCodeOptions: LiveData<ArrayList<String>>
        get() = _taskGroupCodeOptions

    val _taskGroupList = MutableLiveData<ArrayList<TaskGroup>>()
    val taskGroupList: LiveData<ArrayList<TaskGroup>>
        get() = _taskGroupList

    var _enableEndCart: Boolean = false

    val enableEndCart: Boolean
        get() = _enableEndCart

    var _pickCartNbr: String? = null

    val pickCartNbr: String?
        get() = _pickCartNbr

    var _scannedContainerList = mutableListOf<String>()

    val scannedContainerList: List<String>
        get() = _scannedContainerList

    fun getTaskGroups() = viewModelScope.launch {
        _taskGroupResponse.postValue(Resource.Loading())
        val response = replenishRepository.getCaseReplenTaskGroups()
        _taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskGroupsResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskGroupsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _replenCaseTaskPickResponse = SingleLiveEvent<Resource<TaskReplenResponse>>()
    val replenCaseTaskPickResponse: LiveData<Resource<TaskReplenResponse>>
        get() = _replenCaseTaskPickResponse

    val _replenTaskDetails = MutableLiveData<TaskDetails?>()
    val replenTaskDetails: LiveData<TaskDetails?>
        get() = _replenTaskDetails

    fun getReplenCaseToActivePickTask(taskReplenCartRequest: TaskReplenCartRequest) =
        viewModelScope.launch {
            _replenCaseTaskPickResponse.postValue(Resource.Loading())
            val response =
                replenishRepository.getReplenCaseToActivePickTask(taskReplenCartRequest)
            _replenCaseTaskPickResponse.postValue(handleTaskReplenResponse(response))
        }

    private fun handleTaskReplenResponse(response: Response<TaskReplenResponse>): Resource<TaskReplenResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenCaseToActiveResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskReplenCaseToActiveResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _replenCaseSkipTaskResponse = SingleLiveEvent<Resource<TaskReplenResponse>>()
    val replenCaseSkipTaskResponse: LiveData<Resource<TaskReplenResponse>>
        get() = _replenCaseSkipTaskResponse

    fun replenCaseSkipTask(skipTaskDetailsRequest: SkipTaskDetailsRequest) = viewModelScope.launch {
        _replenCaseSkipTaskResponse.postValue(Resource.Loading())
        val response = replenishRepository.replenTaskSkip(skipTaskDetailsRequest)
        _replenCaseSkipTaskResponse.postValue(handleReplenCaseSkipTaskResponse(response))
    }

    private fun handleReplenCaseSkipTaskResponse(response: Response<TaskReplenResponse>): Resource<TaskReplenResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ReplenCaseSkipTask Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "ReplenCaseSkipTask Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _replenEndCartResponse = SingleLiveEvent<Resource<TaskReplenEndCartResponse>>()
    val replenEndCartResponse: LiveData<Resource<TaskReplenEndCartResponse>>
        get() = _replenEndCartResponse

    fun updateReplenEndCart(taskReplenEndCartRequest: TaskReplenEndCartRequest) =
        viewModelScope.launch {
            _replenEndCartResponse.postValue(Resource.Loading())
            val response = replenishRepository.updateReplenEndCart(taskReplenEndCartRequest)
            _replenEndCartResponse.postValue(handleTaskReplenEndCartResponse(response))
        }

    private fun handleTaskReplenEndCartResponse(response: Response<TaskReplenEndCartResponse>): Resource<TaskReplenEndCartResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenEndCartResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskReplenEndCartResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _taskRCAInterimUpdateResponse =
        SingleLiveEvent<Resource<TaskRCAInterimUpdateResponse>>()
    val taskRCAInterimUpdateResponse: LiveData<Resource<TaskRCAInterimUpdateResponse>>
        get() = _taskRCAInterimUpdateResponse

    fun handleTaskRCAInterimUpdate(taskRCAInterimUpdateRequest: TaskRCAInterimUpdateRequest) =
        viewModelScope.launch {
            _taskRCAInterimUpdateResponse.postValue(Resource.Loading())
            // Copy the list before adding the new container number
            val initialList = _scannedContainerList.toList()

            // Add the container number to the list
            _scannedContainerList.add(taskRCAInterimUpdateRequest.containerNum)
            val response =
                replenishRepository.handleTaskRCAInterimUpdate(taskRCAInterimUpdateRequest)
            // Handle the response
            val handledResponse = handleTaskRCAInterimUpdateResponse(response)

            // If response is not successful, remove the added container number from the list
            if (handledResponse is Resource.Error) {
                _scannedContainerList.clear()
                _scannedContainerList.addAll(initialList)
            }
            else {
                if(!handledResponse?.data?.taskDetails?.pickedContainers.isNullOrEmpty()) {
                    _scannedContainerList.clear()
                    handledResponse?.data?.taskDetails?.pickedContainers?.let {
                        _scannedContainerList.addAll(
                            it
                        )
                    }
                }
            }
            _taskRCAInterimUpdateResponse.postValue(handledResponse!!)
        }

    private fun handleTaskRCAInterimUpdateResponse(response: Response<TaskRCAInterimUpdateResponse>): Resource<TaskRCAInterimUpdateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskRCAInterimUpdateResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskRCAInterimUpdateResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _containerInquiryResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val containerInquiryResponse: LiveData<Resource<InventoryContainerResponse>>
        get() = _containerInquiryResponse

    fun validateContainer(containerNumber: String, itemInfo: String) = viewModelScope.launch {
        _containerInquiryResponse.postValue(Resource.Loading())
        val response = replenishRepository.validateContainer(containerNumber, itemInfo)
        _containerInquiryResponse.postValue(handleInventoryContainerResponse(response))
    }

    private fun handleInventoryContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "InventoryContainerResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _submitReplenCaseToActiveTaskResponse =
        SingleLiveEvent<Resource<TaskRCAInterimUpdateResponse>>()
    val submitReplenCaseToActiveTaskResponse: LiveData<Resource<TaskRCAInterimUpdateResponse>>
        get() = _submitReplenCaseToActiveTaskResponse

    fun submitReplenCaseToActive(replenCaseToActiveRequest: ReplenPatchRequest) =
        viewModelScope.launch {
            _submitReplenCaseToActiveTaskResponse.postValue(Resource.Loading())
            val response =
                replenishRepository.submitReplenCaseToActiveTask(replenCaseToActiveRequest)
            _submitReplenCaseToActiveTaskResponse.postValue(
                handleSubmitReplenCaseToActiveTaskResponse(response)
            )
        }

    private fun handleSubmitReplenCaseToActiveTaskResponse(response: Response<TaskRCAInterimUpdateResponse>): Resource<TaskRCAInterimUpdateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskReplenResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private val _generateCCforLocationResponse =
        SingleLiveEvent<Resource<CycleCountTriggerResponse>>()
    val generateCCforLocationResponse: LiveData<Resource<CycleCountTriggerResponse>>
        get() = _generateCCforLocationResponse

    fun generateCycleCount(
        cycleCountTriggerRequest: CycleCountTriggerRequest,
        pullLocationId: Int
    ) =
        viewModelScope.launch {
            _generateCCforLocationResponse.postValue(Resource.Loading())
            val response = replenishRepository.generateCCForLocation(cycleCountTriggerRequest, pullLocationId)
            _generateCCforLocationResponse.postValue(handleGenerateCycleCountResponse(response)
            )
        }

    private fun handleGenerateCycleCountResponse(response: Response<CycleCountTriggerResponse>): Resource<CycleCountTriggerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskReplenResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "TaskReplenResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateContainerOverride(containerId: String, taskDetId: Int?) = viewModelScope.launch {
        val request = ValidateCaseOverrideRequest(
            givenContainerNbr = containerId,
            taskDetId = taskDetId,
            custId = custId,
            fcyId = fcyId,
            buId = buId,
        )
        _caseOverride.postValue(Resource.Loading())
        val response = replenishRepository.validateCaseOverride(request)
        _caseOverride.postValue(handleValidateContainerOverride(response))
    }

    private fun handleValidateContainerOverride(response: Response<ValidatePalletOverrideResponse>): Resource<ValidatePalletOverrideResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handlevalidateContainerOverride Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorDescription(
            response.code(), response.errorBody(), response.message()
        )
        FlareLog.e(TAG, "handlevalidateContainerOverride Error: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateDeliveryLocation(
        inputLocation: String,
        isPnDFeatureEnabled: Boolean = false
    ): Boolean {
        return if (isPnDFeatureEnabled) {
            inputLocation == _replenTaskDetails.value?.destLocationBarcode ||
                    _replenTaskDetails.value?.dropLocations?.any { it == inputLocation } == true
        } else {
            inputLocation == _replenTaskDetails.value?.destLocationBarcode
        }
    }
}