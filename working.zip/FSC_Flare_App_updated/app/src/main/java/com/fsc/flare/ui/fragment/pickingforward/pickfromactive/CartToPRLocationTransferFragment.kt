package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCartToPrLocationTransferBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteCartonReq
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.textfield.TextInputEditText
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CartToPRLocationTransferFragment"

@AndroidEntryPoint
class CartToPRLocationTransferFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentCartToPrLocationTransferBinding
    lateinit var cb1: CustomVisibilityCallback
    var position = 0
    var locationId = 1

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentCartToPrLocationTransferBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                binding.tvSlotValue.text = taskData.slot
                binding.tvToteCartonValue.text = taskData.toteNumber
            }
        }
        binding.prLocationInput.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "PR Location field focused")
                validatePRLocation()
            }
            false
        }
        binding.etScanToteCarton.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Scan Tote field focused")
                validateToteCarton()
            }
            false
        }
        binding.prLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.prLocationErrRes.text = null
            }
        })
        binding.etScanToteCarton.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.tvScanToteCartonErrRes.text = null
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "PR Location focused")
                    if (binding.prLocationInput.isFocused)
                        validatePRLocation()
                    else
                        validateToteCarton()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnTransferComplete.setOnClickListener {
            val shortPickData = viewModel.getShortPickedList()
            if (shortPickData.promptStage) {
                val action = CartToPRLocationTransferFragmentDirections.actionPrLocationFragmentToPickCartStagingLocFragment()
                getNavigationController().navigate(action)
            } else {
                if (viewModel.isComingFromPickCartFlow) {
                    val action = CartToPRLocationTransferFragmentDirections.actionPrLocationSlotFragmentToPickCartPalletFragment()
                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartPalletFragment, true).build()
                    getNavigationController().navigate(action, navOptions)
                } else {
                    val action = CartToPRLocationTransferFragmentDirections.actionPrLocationSlotFragmentToBuildCartTaskGroup()
                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    private fun validatePRLocation() {
        if (binding.prLocationInput.isFocused && !binding.prLocationInput.text.isNullOrEmpty()) {
            viewModel.validateStagingLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    binding.prLocationInput.text.toString(),
                    "PR"
                )
            )
        }
    }

    private fun validateToteCarton() {
        if (binding.etScanToteCarton.isFocused && binding.etScanToteCarton.text.toString().isNotEmpty()) {
            if (binding.etScanToteCarton.text.toString() == binding.tvToteCartonValue.text.toString()) {
                val data = viewModel.getShortPickedList()
                var toteId = 0L
                for (toteDetail in data.toteDetails!!){
                    if (toteDetail.refContainerNbr == binding.etScanToteCarton.text.toString()) {
                        toteId = toteDetail.refContainerId?.toLong() ?: 0L
                        break
                    }
                }
                viewModel.validateToteCarton(
                    ValidateToteCartonReq(
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        locationId = locationId,
                        toteNumber = binding.etScanToteCarton.text.toString(),
                        cartId = data.cartId,
                        cartNumber = data.cartNbr,
                        toteId = toteId
                    )
                )
                binding.etScanToteCarton.text = null
            } else {
                binding.tvScanToteCartonErrRes.text = getString(R.string.not_a_valid_tote_carton)
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun subscribeObservers() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (locationResponse.success != null && locationResponse.success) {
                            FlareLog.i(TAG, "endPickCart success: $locationResponse")
                            val data = viewModel.getShortPickedList()
                            if (locationResponse.locations.isNotEmpty()) {
                                locationId = locationResponse.locations[0].locationId
                                if (data != null) {
                                    binding.cart.text = data.cartNbr
                                    if (data.toteDetails!!.isNotEmpty()) {
                                        binding.tvSlotValue.text = data.toteDetails[position].slot
                                        binding.tvToteCartonValue.text = data.toteDetails[position].refContainerNbr
                                    }
                                    binding.clToteLayout.visibility = View.VISIBLE
                                    binding.btnTransferComplete.visibility = View.VISIBLE
                                }
                            } else {
                                locationId = 0
                                binding.clToteLayout.visibility = View.GONE
                                binding.btnTransferComplete.visibility = View.GONE
                                binding.prLocationErrRes.text = getString(R.string.not_a_valid_pr_location)
                                binding.prLocationInput.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.prLocationInput)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.prLocationErrRes.text = message
                        binding.prLocationInput.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.prLocationInput)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.transferTotePRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { prTransferResponse ->
                        if (prTransferResponse.success != null && prTransferResponse.success) {
                            showSuccessSnackBar(prTransferResponse.message.toString())
                            FlareLog.i(TAG, "PR location transfer success: $prTransferResponse")
                            position += 1
                            val data = viewModel.getShortPickedList()
                            if (data != null) {
                                if (position < data.toteDetails!!.size) {
                                    binding.cart.text = data.cartNbr
                                    if (data.toteDetails.isNotEmpty()) {
                                        binding.tvSlotValue.text = data.toteDetails[position].slot
                                        binding.tvToteCartonValue.text = data.toteDetails[position].refContainerNbr
                                    }
                                } else {
                                    binding.btnTransferComplete.isEnabled = true
                                    disableInputFields(binding.prLocationInput)
                                    disableInputFields(binding.etScanToteCarton)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvScanToteCartonErrRes.text = message
                        binding.etScanToteCarton.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etScanToteCarton)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun disableInputFields(input: TextInputEditText) {
        input.isEnabled = false
        input.isFocusable = false
        input.isFocusableInTouchMode = false
        input.alpha = 0.5f
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        if (binding.prLocationInput.isFocused) {
            binding.prLocationInput.setText(scan?.barcode.toString())
            binding.prLocationInput.text?.length?.let {
                binding.prLocationInput.setSelection(it)
            }
            FlareLog.i(TAG, "PickLocation field focused")
            validatePRLocation()
        } else if (binding.etScanToteCarton.isFocused) {
            binding.etScanToteCarton.setText(scan?.barcode.toString())
            binding.etScanToteCarton.text?.length?.let {
                binding.etScanToteCarton.setSelection(it)
            }
            FlareLog.i(TAG, "ToteCarton field focused")
            validateToteCarton()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

}