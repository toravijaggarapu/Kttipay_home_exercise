package com.fsc.flare.utils

import com.fsc.flare.utils.FlareDateTimeFormats.SERVER_TIME_STAMP_WITH_ZONE
import com.fsc.flare.utils.FlareDateTimeFormats.SERVER_TIME_UTC_TIME_STAMP
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object FlareDateTimeFormats {
    const val SERVER_TIME_STAMP_WITH_ZONE = "yyyy MMM dd HH:mm:ss.SSS zzz"
    const val SERVER_TIME_UTC_TIME_STAMP = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"

    const val ICP_SERVER_TIME_FORMAT = "yyyy-MM-dd"
    const val ICP_DISPLAY_DATE_FORMAT = "yyyy-MM-dd"

    const val NOT_AVAILABLE = "N/A"
}

fun Calendar.getMachineTimeStamp(): String {
    val dateFormat = SimpleDateFormat(SERVER_TIME_STAMP_WITH_ZONE, Locale.getDefault())
    return dateFormat.format(time)
}

fun String.getDateFromString(format: String) = try {
    val dateFormat = SimpleDateFormat(format, Locale.getDefault())
    dateFormat.parse(this) ?: null
} catch (e: Exception) {
    null
}

fun Date.getStringFromDate(format: String) = try {
    val dateFormat = SimpleDateFormat(format, Locale.getDefault())
    dateFormat.format(this) ?: null
} catch (e: Exception) {
    null
}

fun Date.getUTCServerTimeStamp(): String {
    val dateFormat = SimpleDateFormat(SERVER_TIME_UTC_TIME_STAMP, Locale.getDefault())
    dateFormat.timeZone = TimeZone.getTimeZone("UTC")
    return dateFormat.format(this)
}