package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementTaskdetailsDeviceholdContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.CompleteMoveTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementDeviceHoldContainerFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementDeviceHoldContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    private lateinit var partsReplacementDeviceholdContainerBinding: FragmentPartsReplacementTaskdetailsDeviceholdContainerBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementDeviceholdContainerBinding =
            FragmentPartsReplacementTaskdetailsDeviceholdContainerBinding.inflate(
                inflater,
                container,
                false
            )
        partsReplacementDeviceholdContainerBinding.lifecycleOwner = this
        return partsReplacementDeviceholdContainerBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addListeners()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()

        taskDetails?.let {
            with(partsReplacementDeviceholdContainerBinding) {
                tvTaskIdValue.text = it.get(viewModel.getDeviceContainerCountValue()).taskId
                tvDeviceContainerValue.text =
                    it.get(viewModel.getDeviceContainerCountValue()).obContainerNumber
                tvToteValue.text = it.get(viewModel.getDeviceContainerCountValue()).toteNumber
            }
        }

        partsReplacementDeviceholdContainerBinding.etContainerValue.doAfterTextChanged {
            partsReplacementDeviceholdContainerBinding.errResponses.text = null
        }

        partsReplacementDeviceholdContainerBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(
                        fragmentContext,
                        partsReplacementDeviceholdContainerBinding.etContainerValue
                    )
                    if (partsReplacementDeviceholdContainerBinding.etContainerValue.isFocused) {
                        FlareLog.i(TAG, "Pallet field focused")
                        validateDeviceHoldContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementDeviceholdContainerBinding.etContainerValue.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(
                    fragmentContext,
                    partsReplacementDeviceholdContainerBinding.etContainerValue
                )
                FlareLog.i(TAG, "Pallet field focused")
                validateDeviceHoldContainer()
            }
            false
        }
    }

    private fun validateDeviceHoldContainer() {
        val containerValue =
            partsReplacementDeviceholdContainerBinding.etContainerValue.text.toString().trim()
        if (containerValue.isNotEmpty()) {
            partsReplacementDeviceholdContainerBinding.etContainerValue.text = null
            if (partsReplacementDeviceholdContainerBinding.tvDeviceContainerValue.text.toString()
                    .trim() == containerValue
            ) {
                completeMoveTaskRf()
            } else {
                displayErrorMessage(resources.getString(R.string.parts_replacement_hold_container_device_error_message))
            }
        }
    }

    private fun getRepairTaskRf(taskList: List<Task>) {
        taskList?.let {
            viewModel.getRepairTaskRf(
                GetRepairTaskRf(
                    partRunnerCart = it.get(viewModel.getDeviceContainerCountValue()).partRunnerCart,
                    taskType = Constants.PartsReplacement.TASK_TYPE_REPAIR,
                    taskgroup = Constants.PartsReplacement.TASK_GROUP_TNR,
                    actionType = Constants.PartsReplacement.ACTION_TYPE_FETCH
                )
            )
        }
    }

    private fun completeMoveTaskRf() {
        viewModel.completeMoveTaskRf(
            CompleteMoveTaskRf(
                taskType = Constants.PartsReplacement.TASK_TYPE_REPAIR,
                taskId = taskDetails.get(viewModel.getDeviceContainerCountValue()).taskId
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.compeleteMoveTaskDetailsRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { compeleteMoveTaskRfResponse ->
                        FlareLog.e(
                            TAG,
                            "compeleteMoveTaskRfResponse : ${compeleteMoveTaskRfResponse.toString()}"
                        )

                        showSuccessSnackBarStd(getString(R.string.parts_replacement_task_completed)) {
                            getRepairTaskRf(viewModel.getMoveTaskList())
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "compeleteMoveTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                else -> {}
            }
        }
        viewModel.getRepairTaskRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { getMoveTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(getMoveTaskRfResponse)
                        FlareLog.e(
                            TAG,
                            "getRepairTaskRfResponse : ${getMoveTaskRfResponse.toString()}"
                        )
                        navigateToPartsReplacementDeviceIDFragment()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "palletDetailResponse error: $msg")
                        showAlert()
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun showAlert() {
        alertHandler.showSimpleAlert(
            message = getString(R.string.parts_replacement_cart_complete)
        ) {
            navigateToPartsReplacementTaskTypeFragment()
        }
    }

    private fun hideProgressBar() {
        partsReplacementDeviceholdContainerBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementDeviceholdContainerBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementDeviceholdContainerBinding.etContainerValue.setText(scan?.barcode.toString())
        partsReplacementDeviceholdContainerBinding.etContainerValue.text?.length?.let {
            partsReplacementDeviceholdContainerBinding.etContainerValue.setSelection(it)
        }
        FlareLog.i(TAG, "Pallet field focused")
        validateDeviceHoldContainer()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementDeviceholdContainerBinding.errResponses.text = errorMessage
        partsReplacementDeviceholdContainerBinding.etContainerValue.requestFocus()
        partsReplacementDeviceholdContainerBinding.etContainerValue.selectAll()
        showSoftKeyBoard(
            fragmentContext,
            partsReplacementDeviceholdContainerBinding.etContainerValue
        )
    }

    private fun navigateToPartsReplacementTaskTypeFragment() {
            val action =
                PartsReplacementDeviceHoldContainerFragmentDirections.actionPartsReplacementDeviceHoldContainerFragmentToPartsReplacementTaskTypeFragment()
            findNavController().navigate(action)
    }

    private fun navigateToPartsReplacementDeviceIDFragment() {
            val action =
                PartsReplacementDeviceHoldContainerFragmentDirections.actionPartsReplacementDeviceHoldContainerFragmentToPartsReplacementDeviceHoldTaskIDFragment()
            findNavController().navigate(action)
    }

}