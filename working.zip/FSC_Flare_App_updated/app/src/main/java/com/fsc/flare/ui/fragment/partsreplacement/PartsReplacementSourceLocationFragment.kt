package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementTaskdetailsSourcelocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.Labelinfo
import com.fsc.flare.source.data.dto.partsreplacement.request.PrintTaskLabelRequest
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.ACTION_TYPE_GET
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_TYPE_REPAIR
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementSourceLocationFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementSourceLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var partsReplacementSourcelocationBinding: FragmentPartsReplacementTaskdetailsSourcelocationBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementSourcelocationBinding =
            FragmentPartsReplacementTaskdetailsSourcelocationBinding.inflate(
                inflater,
                container,
                false
            )
        partsReplacementSourcelocationBinding.lifecycleOwner = this
        return partsReplacementSourcelocationBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        taskDetails.firstOrNull()?.let {
            partsReplacementSourcelocationBinding.tvTaskIdValue.text = it.taskId
            partsReplacementSourcelocationBinding.tvSourceLocationValue.text =
                it.sourceLocation
        }
        addListeners()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        printLabel()
        partsReplacementSourcelocationBinding.etSourceLocation.doAfterTextChanged {
            partsReplacementSourcelocationBinding.errResponses.text = null
        }

        partsReplacementSourcelocationBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(
                        fragmentContext,
                        partsReplacementSourcelocationBinding.etSourceLocation
                    )
                    if (partsReplacementSourcelocationBinding.etSourceLocation.isFocused) {
                        validateSourceLocations()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementSourcelocationBinding.etSourceLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(
                    fragmentContext,
                    partsReplacementSourcelocationBinding.etSourceLocation
                )
                validateSourceLocations()
            }
            false
        }
    }

    private fun printLabel() {
        taskDetails.firstOrNull()?.let {
            viewModel.printPartsReplacementRf(
                PrintTaskLabelRequest(
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    labelinfo = listOf(Labelinfo(Integer.parseInt(it.taskId)))
                )
            )
        }
    }


    private fun subscribeObservers() {
        viewModel.printPartsReplacementRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printLabelResponse ->
                        FlareLog.e(TAG, "printPartsReplacementRfResponse SUCCESS: $printLabelResponse")
                        if(!printLabelResponse.responseMessage.isNullOrEmpty() ) {
                            showAlertDialog("", printLabelResponse.responseMessage) {}
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "printPartsReplacementRfResponse error: $msg")
                        showAlertDialog("", getString(R.string.parts_replacement_print_api_error)) {}

                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.updateMoveTaskDetailsRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { updateTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(updateTaskRfResponse)
                        navigateToPartsReplacementContainerFragment()
                        FlareLog.e(
                            TAG,
                            "getMoveTaskRfResponse : ${updateTaskRfResponse.toString()}"
                        )
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "getMoveTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun validateSourceLocations() {
        val sourceLocation =
            partsReplacementSourcelocationBinding.etSourceLocation.text.toString().trim()
        if (sourceLocation.isNotEmpty()) {
            partsReplacementSourcelocationBinding.errResponses.text = null

            if (partsReplacementSourcelocationBinding.tvSourceLocationValue.text.toString()
                    .trim() == sourceLocation
            ) {
                taskDetails.firstOrNull()?.let {
                    viewModel.updateMoveTaskDetailsRf(
                        UpdateMoveTaskDetailsRequest(
                            taskId = it.taskId,
                            taskType = TASK_TYPE_REPAIR,
                            actionType = "",
                            toteNumber = it.toteNumber ?: "",
                            toteId = it.refContainerId ?: "",
                            partRunnerCart = task.get(0).partRunnerCart,
                            partRunnerCartId = task.get(0).partRunnerCartId?.toIntOrNull() ?: 0
                        )
                    )
                }
            } else {
                displayErrorMessage(resources.getString(R.string.parts_replacement_source_loc_error_message))
            }
        }
    }

    private fun hideProgressBar() {
        partsReplacementSourcelocationBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementSourcelocationBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementSourcelocationBinding.etSourceLocation.setText(scan?.barcode.toString())
        partsReplacementSourcelocationBinding.etSourceLocation.text?.length?.let {
            partsReplacementSourcelocationBinding.etSourceLocation.setSelection(it)
        }
        FlareLog.i(TAG, "onScan focused")
        validateSourceLocations()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementSourcelocationBinding.errResponses.text = errorMessage
        partsReplacementSourcelocationBinding.etSourceLocation.requestFocus()
        partsReplacementSourcelocationBinding.etSourceLocation.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementSourcelocationBinding.etSourceLocation)
    }

    private fun navigateToPartsReplacementContainerFragment() {
        val action =
            PartsReplacementSourceLocationFragmentDirections.actionPartsReplacementSourceLocationFragmentToPartsReplacementSourceContainerFragment()
        findNavController().navigate(action)
    }
}