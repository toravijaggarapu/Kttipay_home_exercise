package com.fsc.flare.ui.fragment.labelsanddocuments

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemDocumentBinding
import com.fsc.flare.source.data.dto.labelsanddocuments.Document
import com.fsc.flare.source.data.dto.labelsanddocuments.DocumentOption

class DocumentPrintAdapter(
    private val isEnablePrinting: (Boolean, Boolean) -> Unit
) : RecyclerView.Adapter<DocumentPrintAdapter.DocumentViewHolder>() {

    private val documentList = mutableListOf<DocumentOption>()

    @SuppressLint("NotifyDataSetChanged")
    fun resetList(documentList: List<DocumentOption>) {
        this.documentList.clear()
        this.documentList.addAll(documentList)
        notifyDataSetChanged()
    }

    fun getSelectedDocList() = documentList.filter { it.isChecked }.map { Document(docType = it.docId) }

    @SuppressLint("NotifyDataSetChanged")
    fun manageAllDocumentSelection(isSelected: Boolean) {
        documentList.forEach { it.isChecked = isSelected }
        notifyDataSetChanged()
        isEnablePrinting(documentList.any { it.isChecked }, isSelected)
    }

    inner class DocumentViewHolder(val binding: ItemDocumentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.cbDocumentEntry.setOnClickListener {
                val document = documentList[adapterPosition]
                document.isChecked = !document.isChecked
                isEnablePrinting(documentList.any { it.isChecked }, documentList.count { it.isChecked } == documentList.size)
            }
        }

        fun bind(document: DocumentOption) {
            binding.cbDocumentEntry.text = document.name
            binding.cbDocumentEntry.isChecked = document.isChecked
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return DocumentViewHolder(ItemDocumentBinding.inflate(layoutInflater, parent, false))
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) =
        holder.bind(documentList[position])

    override fun getItemCount() = documentList.size
}
