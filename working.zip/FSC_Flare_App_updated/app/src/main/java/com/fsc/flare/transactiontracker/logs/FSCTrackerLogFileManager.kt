package com.fsc.flare.transactiontracker.logs

import com.fsc.flare.BuildConfig
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.google.gson.Gson
import java.io.File
import java.io.FileReader
import java.io.FileWriter

object FSCTrackerLogFileManager {
    private const val TRACKER_FILE_NAME = "FlareTransaction"
    private const val TRACKER_DIRECTORY = "/tracker/"
    var fileName = ""
    private var mFilePath = ""

    fun initializeFileManager(filePath: String) {
        mFilePath = filePath + TRACKER_DIRECTORY
        fileName = mFilePath + TRACKER_FILE_NAME
    }

    fun writeTransaction(trackerData: String) {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            try {
                if (!File(mFilePath).exists())
                    File(mFilePath).mkdir()

                val fileWriter = FileWriter(("$fileName.txt"), false)
                fileWriter.write(trackerData + "\n")
                fileWriter.close()
            } catch (exception: Exception) {
                println(exception.message)
            }
        }
    }

    fun readTrackerData(): FSCTrackerListModel? {
        var trackerArray: FSCTrackerListModel? = null
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            if (File("${fileName}.txt").exists()) {
                val existingJson = Gson().fromJson(
                    FileReader(File("$fileName.txt")),
                    FSCTrackerListModel::class.java
                )
                trackerArray = existingJson
            }
        }
        return trackerArray
    }

    fun deleteTrackerData() {
        if (File("${fileName}.txt").exists()) {
            File("${fileName}.txt").delete()
        }
    }
}