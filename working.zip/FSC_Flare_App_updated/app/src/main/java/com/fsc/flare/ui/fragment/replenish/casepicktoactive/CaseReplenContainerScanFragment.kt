package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogBlindCartonBinding
import com.fsc.flare.databinding.FragmentCaseReplenContainerScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.TaskStatus
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountHeader
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateRequest
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateResponse
import com.fsc.flare.ui.fragment.kitting.ListDialogFragment
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenContainerScanFragment::class.java.simpleName.toString()

/**
 * A simple [CaseReplenContainerScanFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenContainerScanFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenContainerScanBinding

    private lateinit var blindCartonBinding: DialogBlindCartonBinding
    private lateinit var blindCartonDialog: Dialog

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(
                PreferenceKeys.FEDEX_ID, null
            )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenContainerScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplenishHeader.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        observeData()
        return binding.root
    }

    private fun observeData() {
        observeTaskRCAInterimUpdateData()
        observeContainerInquiryData()
        caseOverrideObserver()
    }

    private fun observeContainerInquiryData() {
        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    blindCartonBinding.progressBar.visibility = View.GONE
                    containerInquiryResponse.data?.let { containerResponse ->
                        if (containerResponse.success && containerResponse.container.isNotEmpty()) {
                            viewModel.givenCartonNbr = ""
                            displayPopUpErrorMessage(getString(R.string.master_pallet_repack_container_exists))
                        } else {
                            blindCartonBinding.btnOk.isEnabled = true
                            blindCartonDialog.dismiss()
                            postInterimUpdateOnContainer()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    viewModel.givenCartonNbr = ""
                    blindCartonBinding.progressBar.visibility = View.GONE
                    containerInquiryResponse.message?.let { message ->
                        displayPopUpErrorMessage(message)
                        blindCartonBinding.btnOk.isEnabled = false
                    }
                }

                is Resource.Loading -> {
                    blindCartonBinding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun displayPopUpErrorMessage(message: String) {
        blindCartonBinding.etBlindContainerRes.text = message
        blindCartonBinding.etBlindContainer.selectAll()
        showSoftKeyBoard(fragmentContext, blindCartonBinding.etBlindContainer)
    }


    private fun observeTaskRCAInterimUpdateData() {
        viewModel.taskRCAInterimUpdateResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskRCAInterimUpdateResponse ->
                        if (taskRCAInterimUpdateResponse.success) {
                            if (taskRCAInterimUpdateResponse.zeroLocation != null && taskRCAInterimUpdateResponse.zeroLocation == "Y") {
                                viewModel.replenTaskDetails.value?.let { data ->
                                    showAlertDialog("",
                                        getString(
                                            R.string.lbl_does_the_location_empty_after_picking,
                                            data.locationBarcode
                                        ),
                                        getString(R.string.alert_button_yes),
                                        getString(R.string.alert_button_no),
                                        object : AlertDialogClickListener {
                                            override fun onPositiveButtonClick() {
                                                updateResponseHandle(taskRCAInterimUpdateResponse)
                                            }

                                            override fun onNegativeButtonClick() {
                                                generateCycleCountAPI()
                                                updateResponseHandle(taskRCAInterimUpdateResponse)
                                            }
                                        })
                                }
                            } else {
                                updateResponseHandle(taskRCAInterimUpdateResponse)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { errorMessage ->
                        binding.etScanContainer.text?.length?.let {
                            binding.etScanContainer.setSelection(it)
                        }
                        binding.tvContainerErrorResponse.text = errorMessage
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.generateCCforLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cycleCountTriggerResponse ->
                        if (cycleCountTriggerResponse.success) {
                            FlareLog.e(
                                TAG,
                                "GENERATE CC SUCCESS ${cycleCountTriggerResponse.message}"
                            )
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "GENERATE CC ERROR: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun generateCycleCountAPI() {
        viewModel.generateCycleCount(
            CycleCountTriggerRequest(
                CycleCountHeader(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                ), skipErrIfCCPending = true
            ), viewModel.replenTaskDetails.value?.pullLocationId!!
        )
    }

    private fun updateResponseHandle(taskRCAInterimUpdateResponse: TaskRCAInterimUpdateResponse) {
        if (taskRCAInterimUpdateResponse.taskDetails != null) {
            taskRCAInterimUpdateResponse.taskDetails.let { taskDetails ->
                when (taskDetails.taskStatus) {
                    TaskStatus.TASK_ASSIGNED.value -> {
                        viewModel.apply {
                            _scannedContainerList.clear()
                            _enableEndCart = true
                            _pickCartNbr = taskRCAInterimUpdateResponse.cartNbr
                            _replenTaskDetails.value = taskDetails
                        }
                        getNavigationController().navigate(CaseReplenContainerScanFragmentDirections.actionCaseReplenContainerScanToCaseReplenTaskDetails())
                    }

                    TaskStatus.TASK_IN_PROGRESS.value -> {
                        viewModel.apply {
                            _pickCartNbr = taskRCAInterimUpdateResponse.cartNbr
                            _replenTaskDetails.value = taskDetails
                        }
                        getNavigationController().navigate(CaseReplenContainerScanFragmentDirections.actionCaseReplenContainerScanToCaseReplenContainerScan())
                    }

                    TaskStatus.TASK_INTERIM_UPDATE.value -> {
                        viewModel.apply {
                            _pickCartNbr = taskRCAInterimUpdateResponse.cartNbr
                            _replenTaskDetails.value = taskDetails
                        }
                        getNavigationController().navigate(CaseReplenContainerScanFragmentDirections.actionCaseReplenContainerScanToCaseReplenDropCaseScan())
                    }
                }
            }
        } else {
            viewModel._enableEndCart = false
            val action =
                CaseReplenContainerScanFragmentDirections.actionCaseReplenContainerScanToCaseReplenishmentTaskGroup()
            getNavigationController().navigate(action)
        }
    }

    private fun setUpViews() {
        with(binding) {
            viewModel.replenTaskDetails.value?.let { taskDetails ->
                tvPalletCartIdValue.text = viewModel.pickCartNbr
                tvTaskNumberValue.text = taskDetails.taskId.toString()
                tvItemValue.text = taskDetails.itemCode
                tvScanLocationValue.text = taskDetails.locationName
                tvReplenishQtyValue.text = getString(
                    R.string.lbl_replenish_qty_value,
                    taskDetails.taskQty,
                    taskDetails.taskQtyUom
                )
                tvTotalQtyValue.text = getString(
                    R.string.lbl_total_qty_value,
                    taskDetails.taskQtyInUnits,
                    taskDetails.ibContainerUom ?: taskDetails.taskQtyUom
                )
                setGroupVisibility(taskDetails.numOfTaskDetPicked > 0)
                tvNoOfContainersScannedValue.text = getString(
                    R.string.lbl_no_of_containers_scanned,
                    taskDetails.numOfTaskDetPicked,
                    taskDetails.totNumOfTaskDet
                )
                btnContainerView.setOnClickListener {
                    displayContainerView(viewModel.scannedContainerList)
                }

                tvContainerNumberValue.text = taskDetails.containerNbr
                tvContainerQtyValue.text = getString(
                    R.string.lbl_total_qty_value,
                    taskDetails.ibContainerQty,
                    taskDetails.ibContainerUom ?: taskDetails.taskQtyUom
                )
            }
        }
        handleTouchAndFocusEvents()
        handleClickEvents()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleClickEvents() {
        binding.btnPickBlindCarton.setOnClickListener {
            binding.etScanContainer.text = null
            binding.tvContainerErrorResponse.visibility = View.GONE
            showBlindCartonDialog()
        }
    }

    private fun showBlindCartonDialog() {
        blindCartonBinding = DialogBlindCartonBinding.inflate(LayoutInflater.from(context))
        blindCartonDialog = Dialog(fragmentContext)
        blindCartonDialog.setContentView(blindCartonBinding.root)
        blindCartonDialog.setCancelable(false)
        blindCartonDialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(blindCartonDialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
        blindCartonDialog.window!!.attributes = lp
        blindCartonBinding.etBlindContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                blindCartonBinding.btnOk.isEnabled = s.isNotEmpty()
                blindCartonBinding.etBlindContainerRes.text = null
            }
        })
        blindCartonBinding.etBlindContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                blindCartonBinding.btnOk.performClick()
            }
            false
        }
        blindCartonBinding.btnOk.setOnClickListener {
            val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
            val containerNumber = blindCartonBinding.etBlindContainer.text.toString()
            if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                blindCartonBinding.etBlindContainerRes.text = getString(
                    R.string.container_prefix_length_validation,
                    containerType.ctyId,
                    containerType.ctyContainerLength
                )
            } else {
                blindCartonBinding.btnOk.isEnabled = false
                viewModel.givenCartonNbr =
                    blindCartonBinding.etBlindContainer.text.toString().trim()
                viewModel.validateContainer(viewModel.givenCartonNbr, "Y")
            }
        }

        blindCartonBinding.btnCancel.setOnClickListener {
            blindCartonDialog.dismiss()
        }
    }

    private fun displayContainerView(scannedContainerList: List<String>) {
        val dialog =
            ListDialogFragment(getString(R.string.containers_scanned), scannedContainerList)
        dialog.show(childFragmentManager, "listDialog")
    }

    private fun setGroupVisibility(isVisible: Boolean) {
        val visibility = if (isVisible) View.VISIBLE else View.GONE
        binding.tvNoOfContainersScanned.visibility = visibility
        binding.tvNoOfContainersScannedValue.visibility = visibility
        binding.btnContainerView.visibility = visibility
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etScanContainer)
                    if (binding.etScanContainer.isFocused && !binding.etScanContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etScanContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanContainer)
                FlareLog.i(TAG, "Container field focused")
                validateContainer()
            }
            return@setOnEditorActionListener false
        }

        binding.etScanContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                canEnableBlindCartonButton(s)
                showSoftKeyBoard(fragmentContext, binding.etScanContainer)
                binding.tvContainerErrorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })

    }

    private fun canEnableBlindCartonButton(enteredText: CharSequence) {
        with(binding.btnPickBlindCarton) {
            isEnabled = enteredText.isEmpty()
        }
    }

    private fun validateContainer() {
        val scannedContainerNumber = binding.etScanContainer.text.toString()
        val taskDetails = viewModel.replenTaskDetails.value
        if (scannedContainerNumber.isNotEmpty() && !viewModel.scannedContainerList.contains(
                scannedContainerNumber
            )
        ) {
            viewModel.givenCartonNbr = ""
            if (scannedContainerNumber == taskDetails?.containerNbr) {
                // if picker scans container nbr & its matching with wave allocated container number, then call "taskRCAInterimUpdate" API.
                postInterimUpdateOnContainer()
            } else {
                // if picker scans container nbr/serial number & its not matching with wave allocated container number, then, call "outbound override" API.
                callContainerOverrideAPI()
            }
        } else {
            binding.tvContainerErrorResponse.text = getString(R.string.invalid_container)
        }
    }

    private fun postInterimUpdateOnContainer() {
        val taskDetails = viewModel.replenTaskDetails.value
        taskDetails?.let {
            viewModel.handleTaskRCAInterimUpdate(
                TaskRCAInterimUpdateRequest(
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    it.taskDetId,
                    binding.etScanContainer.text.toString().ifEmpty { taskDetails.containerNbr },
                    viewModel.givenCartonNbr
                )
            )
        }
    }

    private fun caseOverrideObserver() {
        viewModel.caseOverrideResponse.observe(viewLifecycleOwner) { containerOverrideResponse ->
            when (containerOverrideResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerOverrideResponse")
                    hideProgressBar()
                    containerOverrideResponse.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            handleCaseOverriderSuccessResponse(containerResponse)
                        } else {
                            displayErrorMessage(getString(R.string.invalid_container))
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    containerOverrideResponse.message?.let { message ->
                        FlareLog.e(TAG, "ContainerOverrideResponse error: $message")
                        displayErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun callContainerOverrideAPI() {
        viewModel.validateContainerOverride(
            binding.etScanContainer.text.toString().trim(),
            viewModel.replenTaskDetails.value?.taskDetId
        )
    }

    private fun handleCaseOverriderSuccessResponse(overrideResponse: ValidatePalletOverrideResponse) {
        val cartonResponse = overrideResponse.cartonInfo
        val containerNumber = binding.etScanContainer.text.toString()
        if (cartonResponse.scannedSerialType == Constants.ApplicationConstants.SERIAL_TRACK_FULL_TRACKING) {
            if (!cartonResponse.serialNumbers.isNullOrEmpty() && cartonResponse.serialNumbers.contains(
                    containerNumber
                )
            ) {
                binding.etScanContainer.text = null
                displaySuccessMessage(
                    getString(
                        R.string.successfully_scanned_serial_number_and_the_associated_case_id,
                        containerNumber,
                        cartonResponse.containerNbr
                    )
                )
            } else {
                //displayErrorMessage(resources.getString(R.string.serial_doesnot_exist))
                postInterimUpdateOnContainer()
            }
        } else if (cartonResponse.scannedSerialType == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY) {
            if (!cartonResponse.containerNbr.isNullOrEmpty() && cartonResponse.containerNbr == (containerNumber)) {
                binding.etScanContainer.text = null
                displaySuccessMessage(
                    getString(
                        R.string.successfully_scanned_serial_number_and_the_associated_case_id,
                        containerNumber,
                        cartonResponse.containerNbr
                    )
                )
            } else {
                //displayErrorMessage(resources.getString(R.string.duplicate_serial))
                postInterimUpdateOnContainer()
            }
        } else {
            postInterimUpdateOnContainer()
        }
    }

    private fun displaySuccessMessage(message: String) {
        binding.tvContainerErrorResponse.text = message
        binding.tvContainerErrorResponse.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.green
            )
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        if (binding.etScanContainer.isFocused) {
            binding.etScanContainer.setText(scan?.barcode.toString())
            binding.etScanContainer.text?.length?.let {
                binding.etScanContainer.setSelection(it)
                validateContainer()
            }
        } else if (::blindCartonDialog.isInitialized && blindCartonDialog.isShowing) {
            blindCartonBinding.etBlindContainer.setText(scan?.barcode.toString())
            blindCartonBinding.etBlindContainer.text?.length?.let {
                blindCartonBinding.etBlindContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Blind Container field focused")
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun displayErrorMessage(message: String) {
        FlareLog.e(TAG, "ContainerResponse error: $message")
        binding.tvContainerErrorResponse.text = message
        binding.tvContainerErrorResponse.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.red
            )
        )
        binding.etScanContainer.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etScanContainer)
    }
}