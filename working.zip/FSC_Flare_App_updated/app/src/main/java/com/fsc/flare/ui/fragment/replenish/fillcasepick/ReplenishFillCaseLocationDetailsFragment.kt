package com.fsc.flare.ui.fragment.replenish.fillcasepick

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishFillcaseLocationDetailBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.TaskReplenUnloadRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ReplenishFillCaseLocationDetailsFragment"

@AndroidEntryPoint
class ReplenishFillCaseLocationDetailsFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishFillcaseLocationDetailBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun unLoadReplen() {
        if (!binding.etLocation.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etLocation)
            val data = viewModel.getReplenTask()
            val taskDetail = viewModel.getReplenTaskDetails()
            if (data != null && taskDetail != null) {
                if (binding.etLocation.text.toString() == taskDetail.locationBarcode) {
                    viewModel.unloadReplen(
                        TaskReplenUnloadRequest(
                            sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            data.cartNbr.toString(),
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskDetail.taskDetId,
                            taskDetail.taskId
                        )
                    )
                } else {
                    showSoftKeyBoard(fragmentContext, binding.rootLayout)
                    binding.locationResponse.text = getString(R.string.location_mismatch)
                    binding.etLocation.selectAll()
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishFillcaseLocationDetailBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.replenUnloadResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { replenUnloadResponse ->
                        FlareLog.i(TAG, "replenUnload Response: $response")
                        if (replenUnloadResponse.success) {
                            FlareLog.i(TAG, "replenUnload success: $replenUnloadResponse")
                            if (replenUnloadResponse.taskDetails != null) {
                                viewModel.setReplenTaskDetails(replenUnloadResponse.taskDetails)
                                val action =
                                    ReplenishFillCaseLocationDetailsFragmentDirections.actionReplenFillCasePickLocationToFillCasePickContainer()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenFillCasePickContainer, true).build()
                                getNavigationController().navigate(action, navOptions)
                            } else {
                                // When User comes from Load replen Cart Transaction to Fill casepick Transaction, set a flag and go back to taskgroup dropdown selection
                                // - ReplenLoadCart Transaction
                                val action =
                                    ReplenishFillCaseLocationDetailsFragmentDirections.actionReplenFillCasePickLocationToLoadCartTaskGroup()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenLoadCartOrPallet, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "replenUnload error: $message")
                        binding.locationResponse.text = message
                        binding.etLocation.selectAll()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "unLoadReplen called")
                    unLoadReplen()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()
        if (data != null) {
            binding.txtCartPalletRes.text = data.cartNbr
            if (taskData != null) {
                binding.txtTaskIDRes.text = taskData.taskId.toString()
                binding.txtItemRes.text = taskData.itemCode
                binding.txtDesRes.text = taskData.itemDescription
                binding.txtLocationRes.text = taskData.locationName
                binding.txtContainerRes.text = taskData.containerNbr
                binding.txtPickQtyRes.text = String.format("%d %s",taskData.taskQty,taskData.taskQtyUom)
            }
        }
        binding.etLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "unLoadReplen called")
                unLoadReplen()
            }
            false
        }
        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.locationResponse.text = null
            }
        })
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etLocation.setText(scan?.barcode.toString())
            binding.etLocation.text?.length?.let {
                binding.etLocation.setSelection(it)
            }
            unLoadReplen()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}