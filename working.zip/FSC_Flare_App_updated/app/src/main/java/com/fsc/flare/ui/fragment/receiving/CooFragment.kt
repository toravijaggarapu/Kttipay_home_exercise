package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCooBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "CooFragment"

/**
 * A simple [CooFragment] Fragment class.
 */
@AndroidEntryPoint
class CooFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentCooBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getCountriesLookup()
    }

    /**
     * Function to retrieve countries from lookup
     */
    private fun getCountriesLookup() {
        viewModel.getCountriesLookUps(
            LookUpsRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                lookupNames = "COUNTRIES"
            )
        )
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
        setCountryAdapter()
    }

    /**
     * Adapter to bind countries data
     */
    private fun setCountryAdapter() {
        if (viewModel.countriesWithCodesList.isNotEmpty()) {
            val asnItemLines = viewModel.getAsn().itemLPN[0].itemdetails

            val adapter = StartsWithFilterAdapter(requireContext(), viewModel.countriesWithCodesList)
            binding.countryoforigin.setAdapter(adapter)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCooBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    /**
     * Function to setup data onto views
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val asnData = viewModel.getAsn()
        val item = viewModel.getItem()
        with(binding) {
            dockDoor.text = sharedPreferences.getString(PreferenceKeys.Item.DD_NUMBER, null)
            asn.text = asnData.asnNumber
            packageBarcode.text = item.itemBarCode
            itemCode.text = item.itemName
            packageBarcodeDesc.text = item.description
            inventoryTypeDesc.text = viewModel.getInventoryTypeSelected()
            val lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
            val expirationDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
            lotTv.isVisible = item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()
            lot.isVisible = item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()
            lot.text = lotNumber

            dateTv.isVisible = item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()
            date.isVisible = item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()
            date.text = expirationDate

            val isMfgDateNotEmpty = viewModel.getManufacturingDate(viewModel.validateLotNumberResponse).isNotEmpty()
            if (isMfgDateNotEmpty) {
                mfdateTv.isVisible = true
                mfdate.isVisible = true
                mfdate.text = parseExpiryDate(viewModel.getManufacturingDate(viewModel.validateLotNumberResponse))
            }

            countryoforigin.setOnClickListener {
                sclContainer.fullScroll(View.FOCUS_DOWN)
            }

            countryoforigin.setOnItemClickListener { parent, v, position, id ->
                super.onItemClick(parent,v, position, id)
                val regex = Regex("\\((.*?)\\)")
                val selectedItem = parent.getItemAtPosition(position) as String
                val countryCode = regex.find(selectedItem)?.groupValues?.get(1)
                countryoforigin.text = null
                sharedPreferences.edit().putString(
                    PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN,
                    countryCode
                ).apply()
                navigateToNextScreen()
            }
            countryoforigin.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {
                    if (s.length > 1) {
                        hideSoftKeyBoard(fragmentContext, countryoforigin)
                    }
                }

                override fun beforeTextChanged(
                    s: CharSequence, start: Int,
                    count: Int, after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence, start: Int,
                    before: Int, count: Int
                ) {
                }
            })

            if(item.hazmatRequired == "Y"){
                itemClassCodeTv.visibility =View.VISIBLE
                itemClassCode.visibility = View.VISIBLE
                slash.visibility = View.VISIBLE
                division.visibility = View.VISIBLE
                itemClassCode.text = item.hazardous?.hazardClassIMDG
                division.text = item.hazardous?.hazmatDivisionText
            }
        }
        binding.countryoforigin.onFocusChangeListener = this
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeCountriesLookupResponse()
    }

    private fun observeCountriesLookupResponse() {
        viewModel.countriesLookUpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val countriesHashMap: HashMap<String, String> = HashMap()
                        val countriesWithCodesList: ArrayList<String>
                        if (lookUpResponse.lookups.isNotEmpty()) {
                            lookUpResponse.lookups.forEach { lookUp ->
                                lookUp.lookupCodes.forEach { lookupCode ->
                                    countriesHashMap[lookupCode.lookupCode] =
                                        lookupCode.lookupCodeDescription
                                }
                            }
                            viewModel.countriesHashMap = countriesHashMap
                            val itemBarcode = viewModel.getItem().itemBarCode
                            val invTypeCode = viewModel.getInventoryTypesHashMap().entries.find { it.value == viewModel.getInventoryTypeSelected() }?.key
                            val lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
                            val countryCodesFromAsnLines = viewModel.getAsn().itemLPN[0].itemdetails.filter { it.itemCode == itemBarcode && it.invnType == invTypeCode && it.batchNumber == lotNumber }.map { it.countryOfOrigin }
                            countriesWithCodesList =   countriesHashMap.filterKeys{ it in countryCodesFromAsnLines }.map { (key, value) -> "$value ($key)" }.toCollection(ArrayList())
                            viewModel.countriesWithCodesList = countriesWithCodesList
                            setCountryAdapter()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBarHome.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBarHome.visibility = View.VISIBLE
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        if (scan != null && viewModel.countriesHashMap.keys.contains(scan.barcode)) {
            navigateToNextScreen()
        } else {
            hideSoftKeyBoard(fragmentContext, binding.countryoforigin)
            showErrorSnackBar(resources.getString(R.string.lbl_invalid_country_code))
        }
    }

    /**
     * Nav Handler to Next Screen
     */
    private fun navigateToNextScreen() {
        val action = CooFragmentDirections.actionCooFragmentToInventoryTypeFragment()
        getNavigationController().navigate(action)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}