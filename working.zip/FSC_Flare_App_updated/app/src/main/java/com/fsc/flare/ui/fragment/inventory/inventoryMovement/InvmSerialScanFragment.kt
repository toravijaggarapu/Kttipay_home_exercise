package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmSerialScanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InventorySerialErrors
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSerialScanViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.SnackBarState
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "InvmContainerScanFragment"

@AndroidEntryPoint
class InvmSerialScanFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmSerialScanViewModel by viewModels()
    private lateinit var binding: FragmentInvmSerialScanBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInvmSerialScanBinding.inflate(inflater, container, false)
        viewModel.setDataElements(
            sourceDetails = sharedViewModel.sourceDetails,
            quantity = sharedViewModel.getRequiredQuantity()
        )
        updateSerialValues(sharedViewModel.scannedSerials)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.location.text = sharedViewModel.sourceDetails.data?.currentLocNumber
        binding.tvItemBarcodeValue.text =  sharedViewModel.sourceDetails.data?.item
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        handleViewButtonClick()
        observeEvents()
    }

    private fun setTextChangedListener() {
        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.incProgressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { errorType ->
            val errorMessage = errorType?.let {
                when (it) {
                    is InventorySerialErrors.ApiError -> it.errorMessage
                    InventorySerialErrors.CanNotScanMoreThanQuantity -> getString(R.string.cannot_scan_more)
                    InventorySerialErrors.SerialNumberAlreadyAdded -> getString(R.string.duplicate_serial)
                    InventorySerialErrors.InvalidSerial -> getString(R.string.invalid_serial)
                }
            } ?: ""
            if (errorMessage.isNotEmpty()) {
                binding.etSerialNumber.selectAll()
            }
            binding.errResponse.text = errorMessage
        }

        viewModel.showSnackBar.observe(viewLifecycleOwner) { snackType ->
            snackType?.let {
                when (it) {
                    is SnackBarState.Success -> {
                        showSuccessSnackBar(it.message)
                    }

                    is SnackBarState.Error -> {
                        showErrorSnackBar(it.errorMessage)
                    }
                }
            }
        }

        viewModel.serialNbrList.observe(viewLifecycleOwner) { serialNumbers ->
            serialNumbers?.let {
                updateSerialValues(serialNumbers)
                if (serialNumbers.isNotEmpty()) {
                    binding.etSerialNumber.text = null
                    if (serialNumbers.size == sharedViewModel.getRequiredQuantity()) {
                        enableSerialField(false)
                        sharedViewModel.scannedSerials.clear()
                        sharedViewModel.scannedSerials.addAll(viewModel.getScannedSerials())
                        getNavigationController().navigate(InvmSerialScanFragmentDirections.actionInvmSerialScanFragmentToInvmReasonCodeSelectFragment())
                    } else {
                        enableSerialField(true)
                    }
                } else {
                    enableSerialField(true)
                }
            }
        }
    }

    private fun updateSerialValues(serialNumbers: List<String>) {
        binding.tvView.visibility = if (serialNumbers.isNotEmpty()) View.VISIBLE else View.GONE
        binding.tvSerialValue.text = String.format(
            getString(R.string.actual_by_required),
            serialNumbers.size,
            sharedViewModel.getRequiredQuantity()
        )
    }

    private fun handleViewButtonClick() {
        binding.tvView.setOnClickListener {
            showScannedMultiItemsListDialog(
                viewModel.getScannedSerials(),
                title = binding.tvSerial.text.toString() + "(${viewModel.getScannedSerials().size}/${sharedViewModel.getRequiredQuantity()})",
                finalList = { viewModel.updateScannedSerialsList(it) }
            )
        }
    }

    private fun enableSerialField(isEnable: Boolean) {
        binding.etSerialNumber.isEnabled = isEnable
        binding.etSerialNumber.isFocusable = isEnable
        binding.etSerialNumber.isFocusableInTouchMode = isEnable
        binding.etSerialNumber.alpha = if (isEnable) 1f else 0.35f
        if (isEnable) binding.etSerialNumber.post { binding.etSerialNumber.requestFocus() }
    }

    private fun handleEnterKeyEvent() {
        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateSerial()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        validateSerial()
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateSerial() {
        if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            viewModel.validateSerialNumber(serialNbr = binding.etSerialNumber.text.toString().trim())
        } else {
            if (sharedViewModel.scannedSerials.size == sharedViewModel.getRequiredQuantity()) {
                sharedViewModel.scannedSerials.addAll(viewModel.getScannedSerials())
                getNavigationController().navigate(InvmSerialScanFragmentDirections.actionInvmSerialScanFragmentToInvmReasonCodeSelectFragment())
            } else {
                binding.errResponse.text = getString(R.string.please_scan_all_serials)
            }
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        binding.etSerialNumber.setText(scan?.barcode.toString())
        binding.etSerialNumber.text?.length?.let {binding.etSerialNumber.setSelection(it)}
        validateSerial()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.disposeObservables()
    }
}