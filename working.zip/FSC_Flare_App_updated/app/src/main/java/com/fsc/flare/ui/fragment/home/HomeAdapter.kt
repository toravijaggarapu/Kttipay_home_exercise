package com.fsc.flare.ui.fragment.home

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.login.NavItem
import com.fsc.flare.utils.Constants.HomeAdapter.Companion.INTERLEAVING
import com.fsc.flare.utils.Constants.HomeAdapter.Companion.TECH_RF
import com.fsc.flare.utils.StringUtils
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textview.MaterialTextView
import java.util.Locale

class HomeAdapter(
    private val customerMenuList: ArrayList<NavItem>,
    private val listener: OnAdapterClickListener,
    context: Context
) : RecyclerView.Adapter<HomeAdapter.ViewHolder>(), Filterable {

    companion object {
        var row_index = -1
    }

    var filterList = ArrayList<NavItem>()
    private val mContext: Context

    init {
        filterList = customerMenuList
        mContext = context
        row_index = -1
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var homeiv: ImageView = itemView.findViewById(R.id.placeholder_home)
        var itemData: MaterialTextView = itemView.findViewById(R.id.customer_tv)
        var itemLayout: MaterialCardView = itemView.findViewById(R.id.customer_layout)

    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.item_menu, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item: String = filterList[position].displayName.uppercase(Locale.ROOT)
        val menuName = StringUtils.langConvertedName(filterList[position].id,filterList[position].displayName, mContext)

        when (item) {
            "INBOUND" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_forward))
            }
            "OUTBOUND" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_reverse))
            }
            "REPLENISH" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_replenish))
            }
            "CYCLE COUNT" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_cyclecount))
            }
            "INQUIRY" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_inquiry))
            }
            "PUTAWAY" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_putaway))
            }
            "INVENTORY" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_inventory))
            }
            "SHIPPING" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_shipping))
            }
            "KIT/DE-KIT" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_kitting))
            }
            "UTILITIES" -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_utility))
            }
            TECH_RF -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_techrf))
            }
            INTERLEAVING -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_dynamic_interleaving))
            }
            else -> {
                viewHolder.homeiv.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_home))
            }
        }
        viewHolder.itemData.apply {
            //text = item
            text = menuName
        }
        viewHolder.itemLayout.setOnClickListener {
            row_index = position
            listener.onItemSelected(item,filterList[position].id)
            notifyDataSetChanged()
        }
        viewHolder.itemView.apply {
            if (row_index == position) {
                viewHolder.itemView.backgroundTintList =
                    ContextCompat.getColorStateList(mContext, R.color.colorAccent)
            } else {
                viewHolder.itemView.backgroundTintList =
                    ContextCompat.getColorStateList(mContext, R.color.colorPrimary)
            }
        }
    }

    override fun getItemCount(): Int {
        return filterList.size
    }

    interface OnAdapterClickListener {
        fun onItemSelected(item: String?, menuID:String?)
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                filterList = if (charSearch.isEmpty()) {
                    customerMenuList
                } else {
                    val resultList = ArrayList<NavItem>()
                    for (row in customerMenuList) {
                        if (row.displayName.lowercase(Locale.ROOT)
                                .contains(charSearch.lowercase(Locale.ROOT))
                        ) {
                            resultList.add(row)
                        }
                    }
                    resultList
                }
                val filterResults = FilterResults()
                filterResults.values = filterList
                return filterResults
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filterList = results?.values as ArrayList<NavItem>
                notifyDataSetChanged()
            }
        }
    }
}