package com.fsc.flare.ui.fragment.putaway.damage

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRepackPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.setNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import java.lang.Boolean
import javax.inject.Inject
import kotlin.CharSequence
import kotlin.Exception
import kotlin.Int
import kotlin.String
import kotlin.getValue
import kotlin.let
import kotlin.toString

private val TAG = DamagePutawayNewPalletFragment::class.java.simpleName.toString()

/**
 * A simple [DamagePutawayNewPalletFragment] subclass.
 */
@AndroidEntryPoint
class DamagePutawayNewPalletFragment : BaseFragment(), FlareScannable {

    private val viewModel: DamagePutawayViewModel by activityViewModels()
    private lateinit var binding: FragmentRepackPalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        binding.tvMasterPalletRepack.text =
            if (viewModel.isUserDirected) getString(R.string.user_directed_putaway_damaged)
            else getString(R.string.system_directed_putaway_damaged)
        cb1.onVisibilityChange(true)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentRepackPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleViewsListeners()
        subscribePalletDetailsObservers()
        subscribeNewPalletObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleViewsListeners() {
        binding.palletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validatePallet()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.palletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.btnNewPallet.setOnClickListener {
            getNewPalletDetail()
        }
    }

    /**
     * method to validate pallet from API
     */
    private fun validatePallet() {
        hideSoftKeyBoard(fragmentContext, binding.palletNumber)
        FlareLog.i(TAG, "Pallet field focused")
        if (binding.palletNumber.text.toString().trim().isNotEmpty()) {
            val containerType = viewModel.validateContainerType(
                sharedPreferences, Constants.TRANSFER_TYPE_PALLET
            )
            val palletNumber = binding.palletNumber.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.palletNumberResponse.text = getString(
                    R.string.pallet_prefix_length_validation,
                    containerType.ctyId,
                    containerType.ctyContainerLength
                )
            } else {
                //Get pallet detail.
                viewModel.getPalletDetails(binding.palletNumber.text.toString())
            }
        }
    }

    /**
     * method to generate pallet from API
     */
    private fun getNewPalletDetail() {
        //Call new pallet API.
        viewModel.generatePalletCaseNumber()
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribePalletDetailsObservers() {
        viewModel.palletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handlePalletDetailSuccessResponse(response.data)
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { displayErrorMessage(it) }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handlePalletDetailSuccessResponse(palletResponse: InventoryContainerResponse?) {
        if (palletResponse!!.container.isNotEmpty()) {
            binding.palletNumberResponse.text = getString(R.string.pallet_already_exist)
        } else {
            if (binding.palletNumber.text.toString().trim().isNotEmpty()) {
                viewModel.setPalletNumberValue(
                    binding.palletNumber.text.toString().trim()
                )
                navigateLocation()
            }
        }
    }

    private fun subscribeNewPalletObservers() {
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        handleNewPalletSuccessResponse(generatePalletCaseNumberResponse)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        displayErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleNewPalletSuccessResponse(generatePalletCaseNumberResponse: CaseTransferPalletGenerateResponse) {
        if (generatePalletCaseNumberResponse.success) {
            //Save the Pallet number.
            if (generatePalletCaseNumberResponse.numbers[0].type.equals(
                    Constants.TRANSFER_TYPE_PALLET, ignoreCase = true
                )
            ) {
                viewModel.setPalletNumberValue(generatePalletCaseNumberResponse.numbers[0].value)
                navigateLocation()
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.palletNumber.requestFocus()
        binding.palletNumberResponse.text = message
        binding.palletNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.palletNumber)
    }

    private fun navigateLocation() {
        binding.palletNumber.text = null
        setNavigationResult(key = SAVED_STATE_CALL_PRINTER,result = Boolean.TRUE.toString())
        getNavigationController().popBackStack()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.palletNumber.setText(scan?.barcode.toString())
        binding.palletNumber.text?.length?.let {
            binding.palletNumber.setSelection(
                it
            )
            validatePallet()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}