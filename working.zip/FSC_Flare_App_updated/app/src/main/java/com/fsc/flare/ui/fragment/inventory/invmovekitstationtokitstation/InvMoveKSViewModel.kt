package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.Item
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.source.data.dto.kitting.KittingCompleteRequest
import com.fsc.flare.source.data.dto.kitting.KittingCompleteResponse
import com.fsc.flare.source.data.dto.kitting.KittingContainerResponse
import com.fsc.flare.source.data.dto.kitting.KittingDescriptionResponse
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.repository.KittingRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "KittingViewModel"

@HiltViewModel
class InvMoveKSViewModel @Inject constructor(private val kittingRepository: KittingRepository) :
    BaseViewModel() {
    private val _kittingContainerResponse = SingleLiveEvent<Resource<KittingContainerResponse>>()
    private val _kittingCompleteResponse = SingleLiveEvent<Resource<KittingCompleteResponse>>()
    private val _kittingdescriptionResponse = SingleLiveEvent<Resource<KittingDescriptionResponse>>()
    private val _locationResponse = SingleLiveEvent<Resource<LocationClassRes>>()
    val packageItemResponse: MutableLiveData<Resource<PackageItemResponse>> = SingleLiveEvent()
    private val palletResponse: MutableLiveData<PalletResponse> = MutableLiveData()
    private lateinit var moveQty: String
    private var destinationLocationId: Int = 0

    fun getMoveQty(): String {
        return moveQty
    }

    fun setMoveQty(qty: String) {
        this.moveQty = qty
    }

    private var _lot: String? = null
    val lot: String?
        get() = _lot

    // Function to set lot value
    fun setLot(lotValue: String, isApiSuccess: Boolean) {
        _lot = if (isApiSuccess) {
            null
        } else {
            lotValue
        }
    }

    private var _selectedItem: Item? = null

    val selectedItem: Item?
        get() = _selectedItem

    fun setItem(item: Item) {
        _selectedItem = item
    }

    private var _kitItem = KitItem()

    val kitItem: KitItem
        get() = _kitItem

    fun setKitItem(item: KitItem) {
        _kitItem = item
    }

    fun getDestinationLocationId(): Int {
        return destinationLocationId
    }

    fun setDestinationLocationId(destinationLocationId: Int) {
        this.destinationLocationId = destinationLocationId
    }

    fun getPalletResponse(): PalletResponse {
        return palletResponse.value!!
    }

    fun setPalletResponse(palletResponse: PalletResponse) {
        this.palletResponse.value = palletResponse
    }

    fun getKittingContainerResponse(): LiveData<Resource<KittingContainerResponse>> {
        return _kittingContainerResponse
    }

    fun getKittingCompleteResponse(): LiveData<Resource<KittingCompleteResponse>> {
        return _kittingCompleteResponse
    }

    fun getLocationResponse(): LiveData<Resource<LocationClassRes>> {
        return _locationResponse
    }

    var serialNumberList: List<String>? = null
    fun fetchSerialNumberList(): List<String>? {
        return serialNumberList
    }

    var validatedSerialNumberList = mutableListOf<String>()
    fun fetchValidatedSerialNumberList(): MutableList<String> {
        return validatedSerialNumberList
    }

    val lotSerialsMap: MutableMap<String, List<String>> = mutableMapOf()

    fun getSerialNumbersFromLot(lotNumber: String): List<String> {
        return lotSerialsMap[lotNumber] ?: emptyList()
    }

    fun getKittingCasePallet(containerNbr: String, locationClass: String) = viewModelScope.launch {
        _kittingContainerResponse.postValue(Resource.Loading())
        val response = kittingRepository.getKittingCasePallet(containerNbr, locationClass)
        _kittingContainerResponse.postValue(handleKittingContainerResponse(response))
    }

    fun getKittingStationDetail(locationBarcode: String, locationClass: String) =
        viewModelScope.launch {
            _kittingContainerResponse.postValue(Resource.Loading())
            val response = kittingRepository.getKittingStationDetail(locationBarcode, locationClass)
            _kittingContainerResponse.postValue(handleKittingContainerResponse(response))
        }

    private fun handleKittingContainerResponse(response: Response<KittingContainerResponse>): Resource<KittingContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingContainerResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun inventoryMoveKSToKS(kittingCompleteRequest: KittingCompleteRequest) =
        viewModelScope.launch {
            _kittingCompleteResponse.postValue(Resource.Loading())
            val response =
                kittingRepository.inventoryMoveKSToKS(kittingCompleteRequest = kittingCompleteRequest)
            _kittingCompleteResponse.postValue(handleKittingCompleteResponse(response))
        }

    private fun handleKittingCompleteResponse(response: Response<KittingCompleteResponse>): Resource<KittingCompleteResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingCompleteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingCompleteResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateDestinationLocation(locBarcode: String) = viewModelScope.launch {
        _locationResponse.postValue(Resource.Loading())
        val response = kittingRepository.validateLocation(locBarcode)
        _locationResponse.postValue(handleLocationResponse(response))
    }

    private fun handleLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { locationResponse ->
                FlareLog.i(TAG, "LocationResponse Success: $locationResponse")
                return Resource.Success(locationResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getItems(packageItemRequest: PackageItemRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getItems Request: $packageItemRequest")
        packageItemResponse.postValue(Resource.Loading())
        val packageItemRes = kittingRepository.getItems(packageItemRequest)
        packageItemResponse.postValue(handlePackageItemResponse(packageItemRes))
    }

    private fun handlePackageItemResponse(packageItemResponse: Response<PackageItemResponse>): Resource<PackageItemResponse>? {
        if (packageItemResponse.isSuccessful) {
            packageItemResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackageItemResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                packageItemResponse.code(),
                packageItemResponse.errorBody(),
                packageItemResponse.message()
            )
            FlareLog.e(TAG, "PackageItemResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getKittingItemDescription(containerId: Int) = viewModelScope.launch {
        _kittingdescriptionResponse.postValue(Resource.Loading())
        val response = kittingRepository.getKittingItemDescription(containerId)
        _kittingdescriptionResponse.postValue(handleKittingDescriptionResponse(response))
    }

    private fun handleKittingDescriptionResponse(response: Response<KittingDescriptionResponse>): Resource<KittingDescriptionResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "KittingDescriptionResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "KittingDescriptionResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getKittingDescriptionResponse() : LiveData<Resource<KittingDescriptionResponse>>{
        return _kittingdescriptionResponse
    }

}