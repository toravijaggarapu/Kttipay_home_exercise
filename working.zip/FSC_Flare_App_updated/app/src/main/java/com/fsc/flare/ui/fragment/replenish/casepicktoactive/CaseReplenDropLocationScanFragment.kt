package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.app.ActivityCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenDropLocationScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.ReplenPatchRequest
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenDropLocationScanFragment::class.java.simpleName.toString()

/**
 * A simple [CaseReplenDropLocationScanFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenDropLocationScanFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    lateinit var navController: NavController

    private val isReplenToPnDLocationEnable by lazy {
        sharedPreferences.getBoolean(PreferenceKeys.ALLOW_REPLENISHMENT_TO_P_N_D_LOCATION, false)
    }

    private var isPalletDroppedAtPnDLocation = false

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenDropLocationScanBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenDropLocationScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplenishHeader.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        observeData()
        return binding.root
    }

    private fun observeData() {
        observeSubmitReplenCaseToActiveData()
    }

    private fun setUpViews() {
        with(binding) {
            tvPalletCartIdValue.text = viewModel.pickCartNbr
            viewModel.replenTaskDetails.value?.let { taskDetails ->
                tvTaskNumberValue.text = "${taskDetails.taskId}"
                tvItemValue.text = taskDetails.itemCode
                tvPickContainerValue.text = taskDetails.toteNumber?.takeIf { it.isNotEmpty() } ?: taskDetails.containerNbr
                tvDeliveryQtyValue.text = getString(
                    R.string.lbl_delivery_qty_value,
                    taskDetails.taskQty,
                    taskDetails.taskQtyUom,
                    taskDetails.ibContainerQty,
                    taskDetails.ibContainerUom ?: taskDetails.taskQtyUom
                )
                tvDeliveryLocationValue.text = taskDetails.destLocationBarcode

                if (taskDetails.dropLocations?.isNotEmpty() == true && isReplenToPnDLocationEnable) {
                    tvScanDeliveryLocation.text = getString(R.string.scan_delivery_drop_location)
                    etScanDeliveryLocation.hint = getString(R.string.scan_delivery_drop_location)
                    grpDropLocation.visibility = View.VISIBLE
                    tvDropLocation.text = taskDetails.dropLocations.firstOrNull()
                    if (taskDetails.dropLocations.size > 1) {
                        tvDropLocation.text = getString(R.string.many_s)
                        binding.tvDropLocation.setTextColor(ActivityCompat.getColor(requireContext(), R.color.skyBlue))
                        tvDropLocation.setTypeface(tvDropLocation.typeface, Typeface.BOLD)
                        binding.tvDropLocation.paintFlags = binding.tvDropLocation.paintFlags or Paint.UNDERLINE_TEXT_FLAG
                    } else {
                        binding.tvDropLocation.setTextColor(ActivityCompat.getColor(requireContext(), R.color.colorPrimary))
                        tvDropLocation.setTypeface(tvDropLocation.typeface, Typeface.NORMAL)
                        binding.tvDropLocation.paintFlags = binding.tvDropLocation.paintFlags and Paint.UNDERLINE_TEXT_FLAG.inv()
                    }

                    tvDropLocation.setOnClickListener {
                        val details = viewModel.replenTaskDetails.value
                        if ((details?.dropLocations?.size ?: 0) > 1) {
                            alertHandler.showSimpleListDialog(
                                title = getString(R.string.drop_locations),
                                displayList = details?.dropLocations ?: emptyList(),
                            )
                        }
                    }
                } else {
                    binding.grpDropLocation.visibility = View.GONE
                }
            }
        }
        handleTouchAndFocusEvents()
    }


    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etScanDeliveryLocation)
                    if (binding.etScanDeliveryLocation.isFocused && !binding.etScanDeliveryLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Location field focused")
                        validateDeliveryLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etScanDeliveryLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanDeliveryLocation)
                FlareLog.i(TAG, "Location field focused")
                validateDeliveryLocation()
            }
            return@setOnEditorActionListener false
        }

        binding.etScanDeliveryLocation.doAfterTextChanged {
            showSoftKeyBoard(fragmentContext, binding.etScanDeliveryLocation)
            binding.tvLocationErrorResponse.text = null
        }
    }

    private fun validateDeliveryLocation() {
        val inputString = (binding.etScanDeliveryLocation.text?.trim() ?: "").toString()
        if (binding.etScanDeliveryLocation.isFocused && inputString.isNotEmpty()) {
            val interimTaskDetails = viewModel.replenTaskDetails.value
            interimTaskDetails?.let { task ->
                if (viewModel.validateDeliveryLocation(inputString, isReplenToPnDLocationEnable)) {
                    isPalletDroppedAtPnDLocation =
                        viewModel.replenTaskDetails.value?.dropLocations?.any { it == inputString } == true
                    viewModel.submitReplenCaseToActive(
                        ReplenPatchRequest(
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskId = task.taskId,
                            taskDetId = task.taskDetId,
                            scannedDestLocation = inputString,
                            destLocationId = task.destLocationId.takeIf { !isReplenToPnDLocationEnable }
                        )
                    )
                } else {
                    val message = if (isReplenToPnDLocationEnable && viewModel.replenTaskDetails.value?.dropLocations?.isNotEmpty() == true)
                        getString(R.string.wrong_delivery_drop_location)
                    else
                        getString(R.string.error_wrong_delivery_location)
                    binding.tvLocationErrorResponse.text = message
                }
            }
        } else {
            val message = if (isReplenToPnDLocationEnable && viewModel.replenTaskDetails.value?.dropLocations?.isNotEmpty() == true)
                getString(R.string.delivery_drop_location_is_required)
            else
                getString(R.string.delivery_location_is_required)
            binding.tvLocationErrorResponse.text = message
        }
    }

    private fun observeSubmitReplenCaseToActiveData() {
        viewModel.submitReplenCaseToActiveTaskResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success) {
                            taskReplenResponse.taskDetails?.let { taskDetails ->
                                viewModel._replenTaskDetails.value = taskDetails
                                val message = if (isPalletDroppedAtPnDLocation)
                                    getString(R.string.dropped_successfully, binding.tvPickContainerValue.text)
                                else
                                    getString(R.string.replen_success_msg)

                                showSuccessSnackBarStd(message) {
                                    val action =
                                        CaseReplenDropLocationScanFragmentDirections.actionCaseReplenDropLocationScanToCaseReplenDropCaseScan()
                                    getNavigationController().navigate(action)
                                }
                            } ?: run {
                                // This block will execute if taskDetails is null
                                viewModel._enableEndCart = false
                                val message = if (isPalletDroppedAtPnDLocation)
                                    getString(R.string.dropped_successfully, binding.tvPickContainerValue.text)
                                else
                                    getString(R.string.replenishment_tasks_completed)
                                showSuccessSnackBarStd(message) {
                                    val action =
                                        CaseReplenDropLocationScanFragmentDirections.actionCaseReplenDropLocationScanToCaseReplenishmentTaskGroup()
                                    getNavigationController().navigate(action)
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { errorMessage ->
                        binding.etScanDeliveryLocation.text?.length?.let {
                            binding.etScanDeliveryLocation.setSelection(it)
                        }
                        binding.tvLocationErrorResponse.text = errorMessage
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etScanDeliveryLocation.setText(scan?.barcode.toString())
        binding.etScanDeliveryLocation.text?.length?.let {
            binding.etScanDeliveryLocation.setSelection(it)
            validateDeliveryLocation()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        disableTouch()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        enableTouch()
    }
}