package com.fsc.flare.ui.fragment.kitting

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.DialogFragment
import com.fsc.flare.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textview.MaterialTextView
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ListDialogFragment(private val title: String, private val items: List<String>) : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.dialog_list_layout, null)

        // Set title
        view.findViewById<MaterialTextView>(R.id.dialogTitle).text = title

        // Set up the list view
        val listView = view.findViewById<ListView>(R.id.listView)
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        // Set up cancel button
        view.findViewById<MaterialButton>(R.id.cancelButton).setOnClickListener {
            dismiss()
        }

        // Build the dialog
        val builder = AlertDialog.Builder(requireActivity())
        builder.setView(view)

        return builder.create()
    }
}
