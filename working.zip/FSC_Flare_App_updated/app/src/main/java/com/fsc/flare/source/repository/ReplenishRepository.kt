package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.replenishment.ReplenPatchRequest
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenUnloadRequest
import com.fsc.flare.source.data.dto.replenishment.ValidateBlindContainerRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReplenishRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getTaskGroups() = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = "40,50"
    )

    suspend fun getCaseReplenTaskGroups() = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = "60"
    )

    suspend fun getReplenPickTask(replenPickTaskRequest: TaskReplenRequest) = apiGatewayInterface.getReplenTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        replenPickTaskRequest = replenPickTaskRequest
    )

    suspend fun getReplenCaseToActivePickTask(taskReplenCartRequest: TaskReplenCartRequest) = apiGatewayInterface.getReplenCaseToActiveTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskReplenCartRequest = taskReplenCartRequest
    )

    suspend fun submitReplenCasePickTask(replenPatchRequest: ReplenPatchRequest) = apiGatewayInterface.submitReplenCasePickTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        replenCasePickTaskRequest = replenPatchRequest
    )

    suspend fun submitReplenActiveTask(replenPatchRequest: ReplenPatchRequest) = apiGatewayInterface.submitReplenActiveTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        replenActivePickTaskRequest = replenPatchRequest
    )

    suspend fun submitReplenCaseToActiveTask(replenCaseToActiveRequest: ReplenPatchRequest) = apiGatewayInterface.submitReplenCaseToActiveTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        replenCaseToActiveRequest = replenCaseToActiveRequest
    )


    suspend fun generateCCForLocation(
        cycleCountTriggerRequest: CycleCountTriggerRequest,
        pullLocationId: Int
    ) = apiGatewayInterface.generateCycleCountToVerifyZeroLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        locationId = pullLocationId.toLong(),
        cycleCountTriggerRequest = cycleCountTriggerRequest,
    )

    suspend fun getTaskReplen(taskReplenRequest: TaskReplenRequest) = apiGatewayInterface.getTaskReplen(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskReplenRequest = taskReplenRequest
    )

    suspend fun getTaskCartReplen(taskReplenRequest: TaskReplenCartRequest) = apiGatewayInterface.getTaskCartReplen(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskReplenRequest = taskReplenRequest
    )

    suspend fun updateReplenEndCart(taskReplenEndCartRequest: TaskReplenEndCartRequest) = apiGatewayInterface.updateReplenEndCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskReplenEndCartRequest = taskReplenEndCartRequest
    )

    suspend fun handleTaskRCAInterimUpdate(taskRCAInterimUpdateRequest: TaskRCAInterimUpdateRequest) = apiGatewayInterface.handleTaskRCAInterimUpdate(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskRCAInterimUpdateRequest = taskRCAInterimUpdateRequest
    )

    suspend fun validateContainer(containerNumber: String, itemInfo: String) = apiGatewayInterface.getContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = containerNumber,
        itemInfo = itemInfo
    )

    suspend fun replenTaskSkip(skipTaskDetailsRequest: SkipTaskDetailsRequest) = apiGatewayInterface.replenTaskSkip(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = skipTaskDetailsRequest.fcyId,
        custId = skipTaskDetailsRequest.custId,
        buId = skipTaskDetailsRequest.buId,
        pickCartNbr = skipTaskDetailsRequest.pickCartNbr,
        assignedTo = skipTaskDetailsRequest.assignedTo,
        allocationType = skipTaskDetailsRequest.allocationType,
        skipTaskId = skipTaskDetailsRequest.skipTaskId,
        skipTaskDetId = skipTaskDetailsRequest.skipTaskDetId
    )

    suspend fun taskReplenSkip(skipTaskDetailsRequest: SkipTaskDetailsRequest) = apiGatewayInterface.taskReplenSkip(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = skipTaskDetailsRequest.fcyId,
        custId = skipTaskDetailsRequest.custId,
        buId = skipTaskDetailsRequest.buId,
        pickCartNbr = skipTaskDetailsRequest.pickCartNbr,
        assignedTo = skipTaskDetailsRequest.assignedTo,
        allocationType = skipTaskDetailsRequest.allocationType,
        skipTaskId = skipTaskDetailsRequest.skipTaskId,
        skipTaskDetId = skipTaskDetailsRequest.skipTaskDetId
    )

    suspend fun validateBlindContainer(validateBlindContainerRequest: ValidateBlindContainerRequest) = apiGatewayInterface.validateBlindContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        validateBlindContainerRequest = validateBlindContainerRequest
    )

    suspend fun unloadReplen(taskReplenUnloadRequest: TaskReplenUnloadRequest)= apiGatewayInterface.unloadReplen(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskReplenUnloadRequest = taskReplenUnloadRequest
    )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun taskstaging(taskStagingRequest: TaskStagingRequest) = apiGatewayInterface.taskstaging(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskStagingRequest = taskStagingRequest
    )

    suspend fun getPalletDetail(palletNumber: String) =
        apiGatewayInterface.getPalletDetail(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = palletNumber
        )

    suspend fun validatePalletOverride(validatePalletOverrideRequest : ValidatePalletOverrideRequest) =
        apiGatewayInterface.validatePalletOverride(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            validatePalletOverrideRequest = validatePalletOverrideRequest
        )

    suspend fun validateCaseOverride(validateCaseOverrideRequest : ValidateCaseOverrideRequest) =
        apiGatewayInterface.validatePalletOverride(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            validateCaseOverrideRequest = validateCaseOverrideRequest
        )

    suspend fun zeroLocationPromptCall(locationId: Long, skipPalletId: List<Long>) = apiGatewayInterface.zeroLocationPromptCall(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        location_id = locationId,
        skip_pallet_id = skipPalletId,
    )

}