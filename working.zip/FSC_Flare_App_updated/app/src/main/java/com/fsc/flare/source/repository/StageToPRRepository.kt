package com.fsc.flare.source.repository


import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteToPRLocationRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteStageReq
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrRequest
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrResponse
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

class StageToPRRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getPackStationToteDetails(toteNumber: String) = apiGatewayInterface.getPackStationToteDetails(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")?:"",
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        toteOrCartonNo = toteNumber
    )

    suspend fun fetchObCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest): Response<ValidateCartonHandlerTypeResponse> =
        apiGatewayInterface.fetchObCartonDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            cartonNbr = validateCartonHandlerTypeRequest.cartonNbr,
            type = validateCartonHandlerTypeRequest.type,
            responseLevel = validateCartonHandlerTypeRequest.responseLevel
        )

    suspend fun inventoryStagePrReCall(inventoryStagePrReCallRequest: InventoryStageToPrRequest): Response<InventoryStageToPrResponse> =
        apiGatewayInterface.inventoryStagePrReCall(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            inventoryStagePrReCallRequest
        )
}