package com.fsc.flare.ui.fragment.createIBContainer

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBContainerFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBContainerFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBContainerFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel  by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBContainerBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etContainerNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainerNumber)
                FlareLog.i(TAG, "Container Number field focused")
                validateContainer()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etContainerNumber.isFocused && !binding.etContainerNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container Number field focused")
                        validateContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnNewContainer.setOnClickListener {
//            binding.etContainerNumber.text = null
//            binding.etContainerNumber.requestFocus()
            getNewContainerNumber()
        }

        binding.etContainerNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvContainerNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeContainerObserver()
    }


    /**
     * method to validate container from API
     */
    private fun validateContainer() {
        val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
        val containerNumber = binding.etContainerNumber.text.toString()
        if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
            binding.tvContainerNumberResponse.text =
                getString(R.string.container_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
        } else {
            viewModel.resetToDefault()
            viewModel.getContainerDetails(binding.etContainerNumber.text.toString())
        }
    }

    /**
     * method to subscribe validate container observer
     */
    private fun subscribeContainerObserver() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            binding.etContainerNumber.requestFocus()
                            binding.tvContainerNumberResponse.text = resources.getString(R.string.master_pallet_repack_container_exists)
                            binding.etContainerNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etContainerNumber)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if (message == "Err-Inv-000021") {
                            viewModel.setInputContainerNumber(binding.etContainerNumber.text.toString())
                            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                CIBContainerFragmentDirections.actionContainerFragmentToItemBarcodeFragment()
                            navController.navigate(action)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //New container generate response
        viewModel.newContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            var getNewContainerNumber = ""
                            for (palletValue in generatePalletCaseNumberResponse.numbers) {
                                if (palletValue.type != viewModel.palletTransferTypeKey) {
                                    getNewContainerNumber = palletValue.value
                                    break
                                }
                            }

                            if(getNewContainerNumber.isNotEmpty()){
                                viewModel.setInputContainerNumber(getNewContainerNumber)
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    CIBContainerFragmentDirections.actionContainerFragmentToItemBarcodeFragment()
                                navController.navigate(action)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etContainerNumber.setText(scan?.barcode.toString())
                binding.etContainerNumber.text?.length?.let {
                    binding.etContainerNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container Number field focused")
                    validateContainer()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    /**
     * method to generate container from API
     */
    private fun getNewContainerNumber() {
        //Call new container API.
        viewModel.generatePalletCaseNumber(viewModel.newCaseNumberKey)
    }
}