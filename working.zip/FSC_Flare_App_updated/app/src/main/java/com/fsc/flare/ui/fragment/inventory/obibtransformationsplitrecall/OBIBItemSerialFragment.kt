package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentObIbItemSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.NextScreen
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.SplitInfo
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonResponse
import com.fsc.flare.ui.fragment.receiving.SerialAdapter
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = OBIBItemSerialFragment::class.java.simpleName.toString()
/**
 *  [OBIBItemSerialFragment] class.
 */
@AndroidEntryPoint
class OBIBItemSerialFragment : BaseFragment(), FlareScannable {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentObIbItemSerialBinding
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var serialList: ArrayList<String>
    private lateinit var serialListAdapter: SerialAdapter

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etScanItemSerial.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etScanItemSerial)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentObIbItemSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etScanItemSerial.requestFocus()
        setUpViews()
        subscribeObservers()
        handleTouchAndFocusEvents()
        setUpRecyclerView()
    }

    /**
     * Function to setup recyclerview to display serial numbers
     */
    private fun setUpRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = SerialAdapter(serialList)
        binding.rvSerial.adapter = serialListAdapter
    }

    /**
     * Function to setup views with data
     */
    private fun setUpViews() {
        val obCartonDetails = sharedViewModel.obCartonDetails
        val itemDetails = sharedViewModel.itemDetails
        val blindIbContainerNumber = sharedViewModel.blindIbContainerNumber.orEmpty()
        val lotNumber = sharedViewModel.lotNumber
        val expiryDate = sharedViewModel.expiryDate
        val coo = sharedViewModel.coo
        val itemQty = sharedViewModel.itemQty

        obCartonDetails?.let {
            binding.tvObContainerIdValue.text = it.containerNbr
        }
        itemDetails?.let { item ->
            binding.tvItemCodeValue.text = item.itemBarcode
            binding.tvItemDescriptionValue.text = item.itemDesc
            binding.tvItemQtyValue.text = buildString {
                append(itemQty)
                append(" ")
                append(item.qtyUom)
            }
        }
        serialList = arrayListOf()

        binding.apply {
            tvIbCartonIdValue.text = blindIbContainerNumber
            tvItemLotValue.text = lotNumber
            tvItemExpiryValue.text = expiryDate
            tvItemCooValue.text = coo
            tvSerialValue.text = String.format("%d/%s",serialList.size, itemQty)
            btnSplitContainer.setOnClickListener {
                handleSplitBtnClick(obCartonDetails, lotNumber, coo, itemQty, serialList)
            }
        }

        updateViewVisibility(lotNumber, expiryDate, coo)
    }

    /**
     * Function to handle Split Btn click
     */
    private fun handleSplitBtnClick(obCartonDetails: OBCartonDetails?, lotNumber: String?, coo: String?, itemQty: String?, serialList: List<String>?) {
        // Retrieve item details from the shared view model
        val itemDetails = sharedViewModel.itemDetails ?: return

        // Ensure obCartonDetails is not null
        obCartonDetails?.let { obCarton ->
            // Prepare the SplitInfo
            val splitInfo = SplitInfo(
                blindCaseNbr = sharedViewModel.blindIbContainerNumber.orEmpty(),
                itemId = itemDetails.itemId,
                qty = itemQty?.toIntOrNull() ?: 0,
                lotNumber = lotNumber,
                coo = coo,
                serialNbrs = serialList
            )

            // Transform OB to IB carton request
            viewModel.transformObToIbCartonRequest(
                action = OBIBTransformations.SPLIT.type,
                containerId = obCarton.containerId ?: 0,
                splitInfoList = listOf(splitInfo)
            )
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeTransformObToIbCartonResponse()
    }

    /**
     * Function to observe transform OB to IB Carton response
     */
    private fun observeTransformObToIbCartonResponse() {
        viewModel.obToIbCartonTransformResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleTransformObToIbCartonSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleTransformObToIbCartonErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Transform OB to IB Carton error response
     */
    private fun handleTransformObToIbCartonErrorResponse(message: String?) {
        message?.let {
            showErrorSnackBar(message = message)
        }
    }

    /**
     * Function to handle transform OB to IB Carton success response
     */
    private fun handleTransformObToIbCartonSuccessResponse(response: TransformObToIbCartonResponse?) {
        response?.let {
            if (response.success) {
                if(response.taskMessageCode == Constants.TSK_CREATE_SUCCESS) {
                    displayTaskCreateDialog(response)
                } else {
                    navigateToNextScreen(response)
                }
            }
        }
    }

    /**
     * Function to navigate to next screen based on response
     */
    private fun navigateToNextScreen(
        response: TransformObToIbCartonResponse
    ) {
        response.containerDetails?.first()?.let {
            it.nextScreen.let { nextScreenValue ->
                NextScreen.fromValue(nextScreenValue)?.let { nextScreen ->
                    when (nextScreen) {
                        NextScreen.OB_SCAN -> navigateToCartScreen()
                        NextScreen.IB_CASE_SCAN -> navigateToIBCaseScreen(response.containerDetails.first())
                    }
                }
            }
        }
    }

    /**
     * Function to display task create dialog
     */
    private fun displayTaskCreateDialog(response: TransformObToIbCartonResponse) {
        showAlertDialog(
            title = "",
            message = getString(R.string.lbl_split_inv_task_created),
            onPositiveClick = {
                navigateToNextScreen(response)
            }
        )
    }

    /**
     * Nav Handler to IB Case Scan Screen
     */
    private fun navigateToIBCaseScreen(obCartonDetails: OBCartonDetails) {
        sharedViewModel.obCartonDetails = obCartonDetails
        val action = OBIBItemSerialFragmentDirections.actionScanOBIBItemSerialFragmentToScanBlindIbContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Nav Handler to Cart Screen
     */
    private fun navigateToCartScreen() {
        val action = OBIBItemSerialFragmentDirections.actionScanOBIBItemSerialFragmentToScanObContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to update view visibility
     */
    private fun updateViewVisibility(lotNumber: String?, expiryDate: String?, coo: String?) {
        // Update visibility for lot number
        setViewVisibility(lotNumber, binding.tvItemLot, binding.tvItemLotValue)

        // Update visibility for Expiry Date
        setViewVisibility(expiryDate, binding.tvItemExpiry, binding.tvItemExpiryValue)

        // Update visibility for country of origin
        setViewVisibility(coo, binding.tvItemCoo, binding.tvItemCooValue)
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etScanItemSerial.isFocused && !binding.etScanItemSerial.text.isNullOrEmpty()) {
                        validateItemLotSerialNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etScanItemSerial.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanItemSerial)
                if (binding.etScanItemSerial.isFocused && !binding.etScanItemSerial.text.isNullOrEmpty()) {
                    validateItemLotSerialNumber()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etScanItemSerial.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvItemSerialResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate serial number
     */
    private fun validateItemLotSerialNumber() {
        val serialNumber = binding.etScanItemSerial.text.toString().trim()
        // Retrieve carton details and item details from sharedViewModel
        val obCartonDetails = sharedViewModel.obCartonDetails
        val itemDetails = sharedViewModel.itemDetails

        // Find the matching item based on itemId from itemDetails
        val matchingItem = obCartonDetails?.itemDetails?.find { it.itemId == itemDetails?.itemId }

        matchingItem?.let { item ->
            val matchingSerial = item.serialNbrs?.any { it == serialNumber }
            if(matchingSerial == true) {
                addToSerialList(serialNumber)
            } else {
                handleSerialError()
            }
        }
    }

    /**
     * Function to handle serial error
     */
    private fun handleSerialError() {
        binding.tvItemSerialResponse.text = getString(R.string.invalid_serial_number)
    }

    /**
     * Function to add to serial list
     */
    private fun addToSerialList(serialNumber: String) {
        val position = serialList.indexOf(serialNumber)

        if (position == -1) { // Serial number not already in the list
            binding.etScanItemSerial.text?.clear()
            serialList.add(serialNumber)
            val newPosition = serialList.size - 1 // Get the position of the newly added item
            serialListAdapter.notifyItemInserted(newPosition) // Notify that an item was inserted
            binding.tvSerialValue.text = String.format("%d/%s", serialList.size, sharedViewModel.itemQty)
            binding.btnSplitContainer.isEnabled = serialList.size.toString() == sharedViewModel.itemQty
        } else {
            binding.tvItemSerialResponse.text = getString(R.string.duplicate_serial)
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etScanItemSerial.setText(scan?.barcode.toString())
        binding.etScanItemSerial.text?.length?.let {
            binding.etScanItemSerial.setSelection(it)
            validateItemLotSerialNumber()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}