package com.fsc.flare.ui.fragment.pickfromreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBlindContainerPickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "FragmentBlindContainerPickFromReverse"

@AndroidEntryPoint
class FragmentBlindContainerPickFromReverse : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentBlindContainerPickFromReserveBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBlindContainerPickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.taskIdTVRes.text = data.taskId.toString()
            binding.itemCodeTvRes.text = data.itemCode
            binding.desTvRes.text = data.itemDescription
            binding.quantityTvRes.text = String.format("%d %s",data.ibContainerQty,data.ibContainerUom)
            binding.locaitonTvRes.text = data.locationName
            binding.containerTvRes.text = data.containerNbr
        }
        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.blindcontainerlblEdtRes.text = null
            }
        })
        binding.stage.setOnClickListener {
            viewModel.reservepickstage()
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainer)
                FlareLog.i(TAG, "etContainer field focused")
                validateContainer()
            }
            false
        }
    }

    private fun validateContainer() {
        if (!binding.etContainer.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainer)
            val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
            val containerNumber = binding.etContainer.text.toString()
            if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.blindcontainerlblEdtRes.text =
                    getString(R.string.container_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                val taskData = viewModel.getPickTaskDetails()
                if (taskData != null) {
                    when {
                        taskData.itemLotTracked == "1" -> {
                            sharedPreferences.edit().putString(PreferenceKeys.ReservePick.BLIND_CONTAINER, binding.etContainer.text.toString())
                                .apply()
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentContDetailsPickFromReverseDirections.actionPickFromReserveContainerFragmentToPickFromReserveLotFragment()
                            navController.navigate(action)
                        }
                        else -> {
                            viewModel.taskReservePickComplete(
                                ReservePickCompleteRequest(
                                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                    taskData.containerId,
                                    taskData.containerNbr,
                                    binding.etContainer.text.toString(),
                                    taskData.locationBarcode,
                                    taskData.locationName,
                                    taskData.taskQty,
                                    taskData.taskQtyUom,
                                    taskData.taskDetId,
                                    "PFR",
                                    taskData.taskId,
                                    null,
                                    null
                                )
                            )
                        }
                    }
                } else {
                    binding.blindcontainerlblEdtRes.text = resources.getString(R.string.lbl_no_task_data_available)
                    binding.etContainer.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etContainer)
                }
            }
        } else {
            binding.blindcontainerlblEdtRes.text = resources.getString(R.string.lbl_input_required)
            binding.etContainer.selectAll()
            showSoftKeyBoard(fragmentContext, binding.etContainer)
        }
    }

    private fun subscribeObservers() {
        viewModel.reservePickCompleteResponse.observe(viewLifecycleOwner) { reservePickCompleteResponse ->
            when (reservePickCompleteResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickCompleteResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBar(response.message)
                            viewModel.reservepickstage()
                        } else {
                            viewModel.setPickTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentBlindContainerPickFromReverseDirections.actionPickFromReserveBlindContainerFragmentToPickFromReserveContainerFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveContainerFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickCompleteResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickCompleteResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) {reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showErrorSnackBar(response.message)
                            Handler(Looper.getMainLooper()).postDelayed({
                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    FragmentBlindContainerPickFromReverseDirections.actionPickFromReserveBlindContainerFragmentToPickFromReserveFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveFragment, true).build()
                                navController.navigate(action, navOptions)
                            }, 1000)
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentBlindContainerPickFromReverseDirections.actionPickFromReserveBlindContainerFragmentToPickFromReserveStageFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveStageFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etContainer.setText(scan?.barcode.toString())
            binding.etContainer.text?.length?.let {
                binding.etContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Blind Container field focused")
            validateContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}