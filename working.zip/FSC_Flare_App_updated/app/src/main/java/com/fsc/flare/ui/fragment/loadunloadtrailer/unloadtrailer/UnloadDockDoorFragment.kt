package com.fsc.flare.ui.fragment.loadunloadtrailer.unloadtrailer

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentLoadUnloadDockDoorBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorResponse
import com.fsc.flare.ui.fragment.loadunloadtrailer.LoadUnloadViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = UnloadDockDoorFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class UnloadDockDoorFragment : BaseFragment(), FlareScannable{

    private val viewModel: LoadUnloadViewModel by activityViewModels()
    private lateinit var binding: FragmentLoadUnloadDockDoorBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLoadUnloadDockDoorBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvTitle.text = getString(R.string.unload_trailer)
        binding.etDockdoor.requestFocus()
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleTouchAndFocusEvents()
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        when {
                            etDockdoor.isFocused && !etDockdoor.text.isNullOrEmpty() -> getDockDoorId()
                            else -> tvDockdoorResponse.text = getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            etDockdoor.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, etDockdoor)
                    getDockDoorId()
                }
                return@setOnEditorActionListener false
            }

            etDockdoor.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    tvDockdoorResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to get dock doorId from dock door barcode
     */
    private fun getDockDoorId() {
        val dockDoorBarcode = binding.etDockdoor.text.toString()
        when {
            dockDoorBarcode.isNotEmpty() -> viewModel.getDockDoorId(dockDoorBarcode)
            else -> binding.tvDockdoorResponse.text = getString(R.string.lbl_input_required)
        }
    }

    /**
     * Function to validate shipment dock door from API
     */
    private fun callValidateDockDoorAPI(dockDoorId: Int) {
        viewModel.validateShipmentDockDoor(
            ShipmentDockDoorRequest(
                buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                dockDoorId = dockDoorId,
                false
            )
        )
    }


    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeDockDoorObserver()
        subscribeShipmentDockDoorObserver()
    }


    /**
     * Function to subscribe dock door observer
     */
    private fun subscribeDockDoorObserver() {
        viewModel.dockDoorIdResponse.observe(viewLifecycleOwner) { dockDoorResponse ->
            hideProgressBar() // Hide progress bar by default

            when (dockDoorResponse) {
                is Resource.Success -> handleDockDoorIdSuccess(dockDoorResponse.data)
                is Resource.Error -> handleDockDoorIdError(dockDoorResponse.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle DockDoor ID success response
     */
    private fun handleDockDoorIdSuccess(dockDoorResponse: LocationInquiryResponse?) {
        dockDoorResponse?.let { locationResponse ->
            if (locationResponse.success) {
                if(locationResponse.location != null) {
                    callValidateDockDoorAPI(locationResponse.location.locationId)
                } else {
                    handleDockDoorIdError(getString(R.string.invalid_location))
                }
            }
        }
    }

    /**
     * Function to display dock door Id Error response
     */
    private fun handleDockDoorIdError(dockDoorResponseMessage: String?) {
        dockDoorResponseMessage?.let {
            binding.tvDockdoorResponse.text = dockDoorResponseMessage
            binding.etDockdoor.requestFocus()
            binding.etDockdoor.selectAll()
            showSoftKeyBoard(fragmentContext, binding.etDockdoor)
        }
    }

    /**
     * Function to subscribe shipment dock door observer
     */
    private fun subscribeShipmentDockDoorObserver() {
        viewModel.shipmentDDResponse.observe(viewLifecycleOwner) { shipmentDDResponse ->
            hideProgressBar() // Hide progress bar by default
            when (shipmentDDResponse) {
                is Resource.Success -> handleShipmentDDSuccess(shipmentDDResponse.data)
                is Resource.Error -> handleShipmentDDError(shipmentDDResponse.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle shipment dd success response
     */
    private fun handleShipmentDDSuccess(response: ShipmentDockDoorResponse?) {
        response?.let { shipmentDDResponse ->
            if (shipmentDDResponse.success) {
                viewModel.dockDoorShipment = shipmentDDResponse
                navigateToUnloadTrailer()
            } else {
                handleShipmentDDError(shipmentDDResponse.message)
            }
        }
    }

    /**
     * Nav Handler to Unload Trailer screen
     */
    private fun navigateToUnloadTrailer() {
        binding.etDockdoor.text = null
        val action = UnloadDockDoorFragmentDirections.actionUnloadDockdoorToUnloadTrailerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to display error message
     */
    private fun handleShipmentDDError(message: String?) {
        message?.let {
            binding.tvDockdoorResponse.text = message
            binding.etDockdoor.requestFocus()
            binding.etDockdoor.selectAll()
            showSoftKeyBoard(fragmentContext, binding.etDockdoor)
        }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etDockdoor.setText(scan?.barcode.toString())
        binding.etDockdoor.text?.length?.let {
            binding.etDockdoor.setSelection(
                it
            )
            FlareLog.i(TAG, "DockDoor field focused")
            getDockDoorId()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}
