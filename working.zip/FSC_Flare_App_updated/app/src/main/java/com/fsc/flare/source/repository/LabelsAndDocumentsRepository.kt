package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.labelsanddocuments.*
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class LabelsAndDocumentsRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getPrinterConfigs(printerConfigReq: PrinterConfigReq) = apiGatewayInterface.getPrinterConfigs(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        "EDI",
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigReq.fcyId,
        requestor = printerConfigReq.requestor
    )

    suspend fun getPrintEntity() = apiGatewayInterface.getLookup(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        "PRINT_ENTITY"
    )

    suspend fun getPrinterName() = apiGatewayInterface.getLookup(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        "PRINTER_NAME"
    )

    suspend fun validateInputForPrinting(validateInputRequest: ValidateInputRequest) =
        apiGatewayInterface.validateInputForPrinting(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            validateInputRequest.searchEntity,
            validateInputRequest.inputVal,
            validateInputRequest.custId,
            validateInputRequest.buId,
            validateInputRequest.fcyId
        )

    suspend fun printOrder(printOrderRequest: PrintOrderRequest) =
        apiGatewayInterface.printOrder(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            printOrderRequest
        )

    suspend fun printCarton(printCartonRequest: PrintCartonRequest) =
        apiGatewayInterface.printCarton(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            printCartonRequest
        )

    suspend fun printShipment(printShipmentRequest: PrintShipmentRequest) =
        apiGatewayInterface.printShipment(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            printShipmentRequest
        )

    suspend fun printPalletNew(printPalletRequestNew: PrintPalletRequestNew) =
        apiGatewayInterface.printPalletNew(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            printPalletRequestNew
        )

    suspend fun getInternationalShipmentDocuments(requestParams: Map<String, String>) =
        apiGatewayInterface.getInternationShipmentPrintDocs(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            queryMap = requestParams
        )

    suspend fun printInternationalShipmentDocuments(printRequest: ReprintShipmentDocumentRequest) =
        apiGatewayInterface.rePrintInternationalShipmentDocuments(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            printOrderRequest = printRequest
        )
}