package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickingStagingLocationFragment"

@AndroidEntryPoint
class PickingStagingLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentReplenStagingLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentReplenStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvReplenishStage.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val data = viewModel.getPickTask()
        if (data != null) {
            binding.cart.text = data.cartNbr
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "StagingLocation field focused")
                    validateStagingLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.stagingLoc.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "StagingLocation field focused")
                validateStagingLocation()
            }
            false
        }
        binding.stagingLoc.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.stagingLocResponse.text = null
            }
        })
    }

    private fun subscribeObservers() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationClassResponse ->
                        if (locationClassResponse.success) {
                            FlareLog.i(TAG, "locationClass success: $locationClassResponse")
                            if (locationClassResponse.locations.isNotEmpty()) {
                                val data = viewModel.getPickTask()
                                val taskData = viewModel.getPickTaskDetails()
                                if (indexExists(locationClassResponse.locations, 0)) {
                                    val location = locationClassResponse.locations[0]
                                    val locationClass = location.classification
                                    if (locationClass == "S") {
                                        val stagingLocationId = location.locationId
                                        if (data != null) {
                                            if (taskData != null) {
                                                val allocationType = when {
                                                    viewModel.isRTV -> {
                                                        sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
                                                    }
                                                    else -> {
                                                        sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")
                                                    }
                                                }
                                                viewModel.taskstaging(
                                                    TaskStagingRequest(
                                                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                        taskId = taskData.taskId,
                                                        assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                                                        pickCartNbr = data.cartNbr,
                                                        allocationType = data.taskDetails?.allocationType,
                                                        locationId = stagingLocationId
                                                    )
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    binding.stagingLocResponse.text = getString(R.string.invalid_staging_location)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.taskstagingresponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { pickStagingResponse ->
                        FlareLog.d(TAG, "taskstagingresponse: $pickStagingResponse")
                        if (pickStagingResponse.success != null && pickStagingResponse.success) {

                            if(viewModel.isComingFromPickCartFlow)
                            {
                                if (viewModel.isRTV){

                                    Handler(Looper.getMainLooper()).postDelayed({

                                        val bundle = bundleOf( "isRTV" to true) // Replace with your actual key-value pairs

                                        val navOptions = NavOptions.Builder()
                                            .setPopUpTo(R.id.buildCartTaskGroup, inclusive = true) // Specify the destination to pop up to
                                            .build()

                                        val action = PickingStagingLocationFragmentDirections.actionPickingStagingLocationFragmentToBuildCartTaskGroup()
                                        getNavigationController().navigate(action.actionId, bundle, navOptions)
                                    }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
                                }else {
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        val navController = Navigation.findNavController(
                                            requireActivity(),
                                            R.id.nav_host_fragment
                                        )
                                        val action =
                                            PickingStagingLocationFragmentDirections.actionPickingStagingLocationFragmentToPickCartPalletFragment()
                                        val navOptions = NavOptions.Builder()
                                            .setPopUpTo(R.id.pickCartPalletFragment, true).build()
                                        navController.navigate(action, navOptions)
                                    }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
                                }
                            }else{
                                Handler(Looper.getMainLooper()).postDelayed({
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action = PickingStagingLocationFragmentDirections.actionPickingStagingLocationFragmentToBuildCartTaskGroup()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                    navController.navigate(action, navOptions)
                                }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
                            }

                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskstaging error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.stagingLoc.setText(scan?.barcode.toString())
            binding.stagingLoc.text?.length?.let {
                binding.stagingLoc.setSelection(it)
            }
            FlareLog.i(TAG, "StagingLocation field focused")
            validateStagingLocation()
    }

    private fun validateStagingLocation() {
        if (!binding.stagingLoc.text.isNullOrEmpty()) {
            viewModel.validateStagingLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    binding.stagingLoc.text.toString(),
                    "S"
                )
            )
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }
}