package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.SplitInfo
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.repository.OBIBTransSplitRecallRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class OBIBTransSplitRecallViewModel @Inject constructor(
    private val obIbTransSplitRecallRepository: OBIBTransSplitRecallRepository,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {

    private val _obContainerResponse = SingleLiveEvent<Resource<ValidateCartonHandlerTypeResponse>>()
    val obContainerResponse: LiveData<Resource<ValidateCartonHandlerTypeResponse>>
        get() = _obContainerResponse

    private val _ibContainerResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val ibContainerResponse: LiveData<Resource<InventoryContainerResponse>>
        get() = _ibContainerResponse

    private val _itemResponse = SingleLiveEvent<Resource<PackageItemResponse>>()
    val itemResponse: LiveData<Resource<PackageItemResponse>>
        get() = _itemResponse

    private val _obToIbCartonTransformResponse = SingleLiveEvent<Resource<TransformObToIbCartonResponse>>()
    val obToIbCartonTransformResponse: LiveData<Resource<TransformObToIbCartonResponse>>
        get() = _obToIbCartonTransformResponse

    private val _blindIbCartonResponse = SingleLiveEvent<Resource<CaseTransferPalletGenerateResponse>>()
    val blindIbCartonResponse: LiveData<Resource<CaseTransferPalletGenerateResponse>>
        get() = _blindIbCartonResponse

    private val _countriesLookUpResponse = SingleLiveEvent<Resource<LookUps>>()
    val countriesLookUpResponse: LiveData<Resource<LookUps>>
        get() = _countriesLookUpResponse

    fun obCartonDetailsRequest(obContainerNumber: String) {
        viewModelScope.launch(dispatcher) {
            fetchOBCartonDetails(
                ValidateCartonHandlerTypeRequest(
                    cartonNbr = obContainerNumber,
                    type = OBIBTransformations.RECALL_PR.type,
                    responseLevel = "DETAIL"
                )
            )
        }
    }

    private suspend fun fetchOBCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest) {
        _obContainerResponse.postValue(Resource.Loading())
        val response = obIbTransSplitRecallRepository.fetchObCartonDetails(validateCartonHandlerTypeRequest)
        _obContainerResponse.postValue(handleObCartonDetailsResponse(response))
    }

    private fun handleObCartonDetailsResponse(response: Response<ValidateCartonHandlerTypeResponse>): Resource<ValidateCartonHandlerTypeResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun ibCartonDetailsRequest(blindIbContainerNumber: String) {
        viewModelScope.launch(dispatcher) {
            fetchIBContainerDetails(
                blindIbContainerNumber = blindIbContainerNumber
            )
        }
    }

    private suspend fun fetchIBContainerDetails(blindIbContainerNumber: String) {
        _ibContainerResponse.postValue(Resource.Loading())
        val response = obIbTransSplitRecallRepository.fetchIBContainerDetails(blindIbContainerNumber = blindIbContainerNumber)
        _ibContainerResponse.postValue(handleIbContainerDetailsResponse(response))
    }

    private fun handleIbContainerDetailsResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun transformObToIbCartonRequest(action: String, containerId: Int, splitInfoList: List<SplitInfo>? = null) {
        viewModelScope.launch (dispatcher) {
            transformObToIbCarton(
                TransformObToIbCartonRequest(
                    action = action,
                    containerId = containerId,
                    splitInfo = splitInfoList
                )
            )
        }
    }

    private suspend fun transformObToIbCarton(transformObToIbCartonRequest: TransformObToIbCartonRequest) {
        _obToIbCartonTransformResponse.postValue(Resource.Loading())
        val response = obIbTransSplitRecallRepository.transformObToIbCarton(transformObToIbCartonRequest = transformObToIbCartonRequest)
        _obToIbCartonTransformResponse.postValue(handleTransformObToIbCartonResponse(response))
    }

    private fun handleTransformObToIbCartonResponse(response: Response<TransformObToIbCartonResponse>): Resource<TransformObToIbCartonResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun generateBlindIBCartonRequest() {
        viewModelScope.launch (dispatcher) {
            generateBlindIBCarton(
                type = "CASENUM"
            )
        }
    }

    private suspend fun generateBlindIBCarton(type: String) {
        _blindIbCartonResponse.postValue(Resource.Loading())
        val response = obIbTransSplitRecallRepository.generateBlindIBCartonNumber(type = type)
        _blindIbCartonResponse.postValue(handleBlindIbCartonResponse(response))
    }

    private fun handleBlindIbCartonResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun getCountriesLookup() {
        viewModelScope.launch (dispatcher) {
            fetchCountriesLookup()
        }
    }

    private suspend fun fetchCountriesLookup() {
        _countriesLookUpResponse.postValue(Resource.Loading())
        val response = obIbTransSplitRecallRepository.fetchCountriesLookup()
        _countriesLookUpResponse.postValue(handleCountriesLookUpResponse(response))
    }

    private fun handleCountriesLookUpResponse(response: Response<LookUps>): Resource<LookUps> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }
}
