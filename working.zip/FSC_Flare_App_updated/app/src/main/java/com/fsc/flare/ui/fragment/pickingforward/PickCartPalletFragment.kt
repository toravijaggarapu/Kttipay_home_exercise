package com.fsc.flare.ui.fragment.pickingforward

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.enumeration.FlareTaskStatus
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.res.SkipPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartPalletFragment"

@AndroidEntryPoint
class PickCartPalletFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPickCartPalletBinding
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    var shortToteCallIndeed: Boolean = true
    @Inject
    lateinit var sharedPreferences: SharedPreferences
    var taskId = 0

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callLTLTransactionParamAPI()
        callCartToPRLocationTransactionParamAPI()
        viewModel.resetSerialNumber()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeLTLTransactionParamObserver()
        subscribeCartToPRTransactionParamObserver()
        subscribeTransactionParamObserver()
        observeAllocationTypeResponse()
        subscribeObservers()
        return binding.root
    }

    private fun observeAllocationTypeResponse() {
        viewModel.allocationTypeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { allocationTypeResponse ->
                        if (allocationTypeResponse.success) {
                            allocationTypeResponse.data?.let { data ->
                                viewModel.isRTV = when (data.allocationType.toString()) {
                                    AllocationType.PICK_FROM_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code,
                                    AllocationType.PICK_FROM_ACTIVE_RTV.code,
                                    AllocationType.PICK_FROM_RESERVE_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code,
                                    AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code,
                                    AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code -> {
                                        true
                                    }

                                    else -> {
                                        false
                                    }
                                }
                                fetchTaskDetailsBasedOnAllocationType(data.allocationType)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "AllocationTypeResponse error: $message")
                        binding.cartResponse.text = message
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to get transaction param info from API
     */
    private fun callLTLTransactionParamAPI() {
        viewModel.getLTLTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "LTLCUBE"
            )
        )
    }

    private fun callCartToPRLocationTransactionParamAPI() {
        viewModel.getCartToPRransactionParam(
                TransactionParamRequest(
                        cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        trans_code = "TOTETOPR"
                )
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    FlareLog.i(TAG, "Cart field focused")
                    fetchAllocationType()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etCart.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etCart)
                FlareLog.i(TAG, "Cart field focused")
                fetchAllocationType()
            }
            false
        }
        binding.etCart.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.cartResponse.text = null
            }
        })
    }

    private fun fetchAllocationType() {
        val pickCartNumber = binding.etCart.text.toString().trim()
        if (pickCartNumber.isNotEmpty()) {
            viewModel.getAllocationType(cartNbr = pickCartNumber)
        } else {
            binding.cartResponse.text = resources.getString(R.string.lbl_enter_valid_cart_number)
        }
    }

    /**
     * method to get transaction param info from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "PIA"
            )
        )
    }
    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeLTLTransactionParamObserver() {
        viewModel.ltlTransactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (transactionParamResponse.noOfCases != null && transactionParamResponse.noOfCases.isNotEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transVal == viewModel.ltlFLowEnabledKey) {
                                    Log.d("debug", "LTL Cubing Enabled")
                                    viewModel.isLTLCubingEnabled = true
                                    callTransactionParamAPI()
                                } else {
                                    Log.d("debug", "LTL Cubing Disabled")
                                    viewModel.isLTLCubingEnabled = false
                                    callTransactionParamAPI()
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                viewModel.isLTLCubingEnabled = false
                                callTransactionParamAPI()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        viewModel.isLTLCubingEnabled = false
                        callTransactionParamAPI()
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

   /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeCartToPRTransactionParamObserver() {
        viewModel.cartToPrLocationTransParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (transactionParamResponse.noOfCases != null && transactionParamResponse.noOfCases.isNotEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                viewModel.setToteToPrTransParamValue(noOfCases.transVal)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }



    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.transactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (transactionParamResponse.noOfCases != null && transactionParamResponse.noOfCases.isNotEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transValDesc.equals("Prompt Item Attributes", true)) {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, true).apply()
                                } else {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        showErrorSnackBar(message)
                        sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }
    private fun fetchTaskDetailsBasedOnAllocationType(allocationType: Int) {
        viewModel.pickSkipCart(
            SkipPickCartReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etCart.text.toString().trim(),
                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                allocationType = allocationType.toString(),
                skipTaskId = "",
                skipTaskDetId = "",
                replenType = "fill",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun callSkipBuildCartCasePickType() {
        viewModel.pickSkipCartCasePick(
            SkipPickCartReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etCart.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                allocationType = "20",
                skipTaskId = "",
                skipTaskDetId = "",
                replenType = "fill",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun callSkipBuildCartLTLType() {
        viewModel.pickSkipCartLTL(
            SkipPickCartReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etCart.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                allocationType = "11",
                skipTaskId = "",
                skipTaskDetId = "",
                replenType = "fill",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun callSkipBuildCartKittingActiveType() {
        viewModel.pickSkipCartKittingActive(
            SkipPickCartReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etCart.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                allocationType = "12",
                skipTaskId = "",
                skipTaskDetId = "",
                replenType = "fill",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun callSkipBuildCartKittingCasePickType() {
        viewModel.pickSkipCartKittingCasepick(
            SkipPickCartReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etCart.text.toString(),
                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                allocationType = "21",
                skipTaskId = "",
                skipTaskDetId = "",
                replenType = "fill",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }


    private fun subscribeObservers() {
        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success != null && taskReplenResponse.success) {
                            FlareLog.i(TAG, "taskPick success: $taskReplenResponse")
                            if (taskReplenResponse.cartNbr == null) {

                            } else {
                                viewModel.setPickTask(taskReplenResponse)
                                taskReplenResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                              //  val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartPickLocationFragment()
                                navController.navigate(action)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPick error: $message")
                        binding.cartResponse.text = message
                        binding.etCart.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etCart)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            viewModel.isComingFromPickCartFlow = true
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                // Store allocation type in shared preferences
                                when (skipCartResponse.taskDetails.allocationType) {
                                    AllocationType.PICK_FROM_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code,
                                    AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code,
                                    AllocationType.PICK_FROM_ACTIVE_RTV.code,
                                    AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code,
                                    AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code,
                                    AllocationType.PICK_FROM_RESERVE_RTV.code,
                                    AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code -> {
                                        sharedPreferences.edit().putString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, skipCartResponse.taskDetails.allocationType).apply()
                                    }
                                    else -> sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, skipCartResponse.taskDetails.allocationType).apply()
                                }
                                if (skipCartResponse.taskDetails.taskStatus == FlareTaskStatus.STAGE_PENDING.code) {
                                    if (skipCartResponse.taskDetails.allocationType == AllocationType.ALLOCATED_FROM_ACTIVE.code ||
                                        skipCartResponse.taskDetails.allocationType == AllocationType.PICK_FROM_ACTIVE_RTV.code ||
                                        skipCartResponse.taskDetails.allocationType == AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code ||
                                        skipCartResponse.taskDetails.allocationType == AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL.code &&
                                        viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()
                                    ) {
                                        val taskResp = TaskPickResponse(
                                            skipCartResponse.pickCartId,
                                            binding.etCart.text.toString().trim(),
                                            skipCartResponse.taskDetails.priority,
                                            skipCartResponse.requestIdentifier,
                                            skipCartResponse.success,
                                            false,
                                            skipCartResponse.taskDetails,
                                            skipCartResponse.transactionDate,
                                            skipCartResponse.message,
                                            skipCartResponse.orderType
                                        )
                                        viewModel.setPickTask(taskResp)
                                        viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                        taskId = skipCartResponse.taskDetails.taskId
                                        viewModel.getShortPickedTotes(
                                            binding.etCart.text.toString(),
                                            skipCartResponse.pickCartId
                                        )
                                    } else if (viewModel.isRTV || skipCartResponse.taskDetails.allocationType == AllocationType.ALLOCATED_FROM_CASE_PICK.code) {
                                        prepareTaskPickResponse(skipCartResponse)
                                        showStagePendingAlert(
                                            binding.etCart.text.toString().trim(),
                                            taskId
                                        )
                                    } else if (skipCartResponse.taskDetails.allocationType == AllocationType.PICK_FROM_ACTIVE.code ||
                                        skipCartResponse.taskDetails.allocationType == AllocationType.PICK_FROM_ACTIVE_RTV.code
                                    ) {
                                        val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                            binding.etCart.text.toString().trim() ,
                                            skipCartResponse.taskDetails.priority ,
                                            skipCartResponse.requestIdentifier,
                                            skipCartResponse.success,
                                            false,
                                            skipCartResponse.taskDetails,
                                            skipCartResponse.transactionDate,
                                            skipCartResponse.message,
                                            skipCartResponse.orderType
                                        )
                                        viewModel.setPickTask(taskResp)
                                        viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                        taskId = skipCartResponse.taskDetails.taskId
                                        if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                            viewModel.getShortPickedTotes(
                                                binding.etCart.text.toString(),
                                                skipCartResponse.pickCartId
                                            )
                                        } else {
                                            viewModel.setKitStageLocation(skipCartResponse.kitStageLocBarcode)
                                            showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                        }
                                    } else if (skipCartResponse.taskDetails.allocationType == AllocationType.PICK_FROM_CASE_PICK.code) {
                                        prepareTaskPickResponse(skipCartResponse)
                                        viewModel.setKitStageLocation(skipCartResponse.kitStageLocBarcode)
                                        showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                    }
                                } else {
                                    val action = when (skipCartResponse.taskDetails.allocationType) {
                                        AllocationType.ALLOCATED_FROM_ACTIVE.code,
                                        AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL.code -> {
                                            val taskResp = TaskPickResponse(
                                                cartId = skipCartResponse.taskDetails.containerId,
                                                cartNbr = binding.etCart.text.toString().trim(),
                                                priority = skipCartResponse.taskDetails.priority,
                                                requestIdentifier = skipCartResponse.requestIdentifier,
                                                success = skipCartResponse.success,
                                                cartIsReadyToEnd = false,
                                                taskDetails = skipCartResponse.taskDetails,
                                                transactionDate = skipCartResponse.transactionDate,
                                                message = skipCartResponse.message,
                                                orderType = skipCartResponse.orderType
                                            )
                                            viewModel.setPickTask(taskResp)
                                            viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                            PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartLocationFragment()
                                        }
                                        AllocationType.ALLOCATED_FROM_CASE_PICK.code -> {
                                            prepareTaskPickResponse(skipCartResponse)
                                            PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartPickLocationFragment()
                                        }
                                        AllocationType.PICK_FROM_ACTIVE.code,
                                        AllocationType.PICK_FROM_ACTIVE_RTV.code,
                                        AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code -> {
                                            val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                                binding.etCart.text.toString().trim() ,
                                                skipCartResponse.taskDetails.priority ,
                                                skipCartResponse.requestIdentifier,
                                                skipCartResponse.success,
                                                false,
                                                skipCartResponse.taskDetails,
                                                skipCartResponse.transactionDate,
                                                skipCartResponse.message,
                                                skipCartResponse.orderType
                                            )
                                            viewModel.setPickTask(taskResp)
                                            viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                            PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartLocationFragment()
                                        }
                                        AllocationType.PICK_FROM_CASE_PICK.code -> {
                                            prepareTaskPickResponse(skipCartResponse)
                                            PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartPickLocationFragment()
                                        }
                                        else -> PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartLocationFragment()
                                    }
                                    getNavigationController().navigate(action)
                                }
                            } else {
                                if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                    shortToteCallIndeed = false
                                    viewModel.getShortPickedTotes(
                                        binding.etCart.text.toString(),
                                        skipCartResponse.pickCartId
                                    )
                                } else {
                                    skipCartResponse.message?.let { showErrorSnackBar(it) }
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        handleError(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponseLTL.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            viewModel.isComingFromPickCartFlow = true
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "11").apply()
                                if(skipCartResponse.taskDetails.taskStatus == 35)
                                {
                                    val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                        binding.etCart.text.toString().trim() ,
                                        skipCartResponse.taskDetails.priority ,
                                        skipCartResponse.requestIdentifier,
                                        skipCartResponse.success,
                                        false,
                                        skipCartResponse.taskDetails,
                                        skipCartResponse.transactionDate,
                                        skipCartResponse.message,
                                        skipCartResponse.orderType
                                    )
                                    viewModel.setPickTask(taskResp)
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    taskId = skipCartResponse.taskDetails.taskId
                                    if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                        viewModel.getShortPickedTotes(
                                            binding.etCart.text.toString(),
                                            skipCartResponse.pickCartId
                                        )
                                    } else {
                                        showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                    }
                                }else
                                {
                                    val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                        binding.etCart.text.toString().trim() ,
                                        skipCartResponse.taskDetails.priority ,
                                        skipCartResponse.requestIdentifier,
                                        skipCartResponse.success,
                                        false,
                                        skipCartResponse.taskDetails,
                                        skipCartResponse.transactionDate,
                                        skipCartResponse.message,
                                        skipCartResponse.orderType
                                    )
                                    viewModel.setPickTask(taskResp)
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartLocationFragment()
                                    getNavigationController().navigate(action)
                                }
                            } else {
                                //skipCartResponse.message?.let { showErrorSnackBar(it) }
                                callSkipBuildCartCasePickType()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        //showErrorSnackBar(message)
                        callSkipBuildCartCasePickType()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponseCasePick.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            viewModel.isComingFromPickCartFlow = true
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "20").apply()
                                if(skipCartResponse.taskDetails.taskStatus == 35){
                                    prepareTaskPickResponse(skipCartResponse)
                                    showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                }else{
                                    prepareTaskPickResponse(skipCartResponse)
                                    //  taskReplenResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    //  val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                                    val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartPickLocationFragment()
                                    navController.navigate(action)
                                }

                            } else {
                               // skipCartResponse.message?.let { showErrorSnackBar(it) }
                                callSkipBuildCartKittingActiveType()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                       // showErrorSnackBar(message)
                        callSkipBuildCartKittingActiveType()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponseKittingActive.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            viewModel.isComingFromPickCartFlow = true
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "12").apply()
                                if(skipCartResponse.taskDetails.taskStatus == 35)
                                {
                                    val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                        binding.etCart.text.toString().trim() ,
                                        skipCartResponse.taskDetails.priority ,
                                        skipCartResponse.requestIdentifier,
                                        skipCartResponse.success,
                                        false,
                                        skipCartResponse.taskDetails,
                                        skipCartResponse.transactionDate,
                                        skipCartResponse.message,
                                        skipCartResponse.orderType
                                    )
                                    viewModel.setPickTask(taskResp)
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    taskId = skipCartResponse.taskDetails.taskId
                                    if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                        viewModel.getShortPickedTotes(
                                            binding.etCart.text.toString(),
                                            skipCartResponse.pickCartId
                                        )
                                    } else {
                                        viewModel.setKitStageLocation(skipCartResponse.kitStageLocBarcode)
                                        showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                    }
                                }else
                                {
                                    val taskResp = TaskPickResponse(skipCartResponse.pickCartId,
                                        binding.etCart.text.toString().trim() ,
                                        skipCartResponse.taskDetails.priority ,
                                        skipCartResponse.requestIdentifier,
                                        skipCartResponse.success,
                                        false,
                                        skipCartResponse.taskDetails,
                                        skipCartResponse.transactionDate,
                                        skipCartResponse.message,
                                        skipCartResponse.orderType
                                    )
                                    viewModel.setPickTask(taskResp)
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    //  taskReplenResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    //  val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                                    val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartLocationFragment()
                                    navController.navigate(action)
                                }
                            } else {
                                //skipCartResponse.message?.let { showErrorSnackBar(it) }
                                callSkipBuildCartKittingCasePickType()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        //showErrorSnackBar(message)
                        callSkipBuildCartKittingCasePickType()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponseKittingCasepick.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            viewModel.isComingFromPickCartFlow = true
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "21").apply()
                                if(skipCartResponse.taskDetails.taskStatus == 35){
                                    prepareTaskPickResponse(skipCartResponse)
                                    viewModel.setKitStageLocation(skipCartResponse.kitStageLocBarcode)
                                    showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                                }else{
                                    prepareTaskPickResponse(skipCartResponse)
                                    //  taskReplenResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    //  val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                                    val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartPickLocationFragment()
                                    navController.navigate(action)
                                }
                            } else {
                                if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                    shortToteCallIndeed = false
                                    viewModel.getShortPickedTotes(
                                        binding.etCart.text.toString(),
                                        skipCartResponse.pickCartId
                                    )
                                }else
                                {
                                    skipCartResponse.message?.let { showErrorSnackBar(it) }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                            shortToteCallIndeed = false
                            viewModel.getShortPickedTotes(
                                binding.etCart.text.toString(),
                                viewModel.getPickTask()?.cartId ?: 0
                            )
                        }else
                        {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.shortPickTotesResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shortPickToteResponse ->
                        if (shortPickToteResponse.toteDetails != null && shortPickToteResponse.toteDetails.isNotEmpty()) {
                            viewModel.setShortPickTotesList(shortPickToteResponse)
                            if (!shortPickToteResponse.prLocExist) {
                                showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                            } else {
                                val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPrLocationFragment()
                                getNavigationController().navigate(action)
                            }
                        } else { //not shortpicked
                            if (shortPickToteResponse.promptStage) //stage pending task
                                showStagePendingAlert(binding.etCart.text.toString().trim(), taskId)
                            else {
                                //zero pick
                                if(shortToteCallIndeed)
                                {
                                    binding.cartResponse.text = getString(R.string.no_totes_available_to_stage)
                                }else
                                {
                                    binding.cartResponse.text =
                                        getString(R.string.no_task_assigned_to_the_user_with_given_cart_number)
                                }
                                binding.etCart.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etCart)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Get short pick error: $message")
                        binding.cartResponse.text = message
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleError(message: String) {
        with(binding) {
            cartResponse.text = message
            etCart.requestFocus()
            etCart.selectAll()
            showSoftKeyBoard(requireContext(), etCart)
        }
    }

    private fun prepareTaskPickResponse(skipCartResponse: SkipPickCartRes){
        val taskResp = TaskPickResponse(
            skipCartResponse.pickCartId,
            skipCartResponse.pickCartNbr,
            skipCartResponse.taskDetails?.priority,
            skipCartResponse.requestIdentifier,
            skipCartResponse.success,
            false,
            skipCartResponse.taskDetails,
            skipCartResponse.transactionDate,
            skipCartResponse.message,
            skipCartResponse.orderType
        )
        viewModel.setPickTask(taskResp)
        skipCartResponse.taskDetails?.let { viewModel.setPickTaskDetails(it) }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etCart.setText(scan?.barcode.toString())
            binding.etCart.text?.length?.let {
                binding.etCart.setSelection(it)
            }
            FlareLog.i(TAG, "Cart field focused")
            fetchAllocationType()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    private fun showStagePendingAlert(cartNumber:String , taskId:Int) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = if (taskId == 0) {
            getString(R.string.stage_pending_alert_casepick, cartNumber)
        } else {
            getString(R.string.stage_pending_alert, cartNumber, taskId.toString())
        }
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.lbl_stage_cart)) { dialogInterface, which ->
            dialogInterface.dismiss()
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartStagingLocFragment()
            navController.navigate(action)
        }

        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}