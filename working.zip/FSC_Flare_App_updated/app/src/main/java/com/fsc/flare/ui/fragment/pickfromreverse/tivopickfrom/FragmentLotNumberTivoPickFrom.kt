package com.fsc.flare.ui.fragment.pickfromreverse.tivopickfrom

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavDirections
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentLotNoTivoPickFromReverseBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.util.*
import javax.inject.Inject


private const val TAG = "FragmentContainerSerialNumberTivoPickFrom"

@AndroidEntryPoint
class FragmentLotNumberTivoPickFrom : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentLotNoTivoPickFromReverseBinding
    private var pkdQty = 1

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        binding.btnStage.isEnabled = viewModel.getTasksCompletedList()?.isNotEmpty() == true
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLotNoTivoPickFromReverseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateLotNumber()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etLotNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLotNumber)
                FlareLog.i(TAG, "etLotNumber field focused")
                validateLotNumber()
            }
            false
        }

        init()
        setListener()
    }

    private fun updatePickedQuantity() {
        if (viewModel.isPallet(viewModel.getPickTaskDetails())) {
            binding.tvPickedQuantityValue.text = if (pkdQty > 1) "$pkdQty pallets" else "$pkdQty pallet"
            viewModel.markTaskCompleteRequest?.let {
                binding.tvPalletNumberValue.text = it.palletNumber
            }
            binding.tvContainerNumber.visibility = View.GONE
            binding.tvContainerNumberValue.visibility = View.GONE

        } else {
            binding.tvPickedQuantityValue.text = if (pkdQty > 1) "$pkdQty cases" else "$pkdQty case"
            binding.tvPalletNumberValue.text = viewModel.getPickTaskDetails()?.containerNbr
            viewModel.markTaskCompleteRequest?.let { it ->
                binding.tvContainerNumberValue.text = it.containers?.let {
                    if (it.isNotEmpty()) {
                        it.first()?.containerNumber
                    } else ""
                } ?: ""
            }
        }
    }

    private fun init() {
        pkdQty=0
        viewModel.getPickTaskDetails()?.let {
            binding.tvTaskIdValue.text = it.taskId.toString()
            binding.itemCodeValue.text = it.itemCode
            binding.tvDescValue.text = it.itemDescription

            updatePickedQuantity()
           // binding.tvContainerNumberValue.text = "${it.containerId}"
            binding.tvLocationValue.text = it.locationBarcode

            if (viewModel.isPallet(it)) {
                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} pallets" else "${it.taskQty} pallet"
            } else {
                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} cases" else "${it.taskQty} case"
            }
        }
    }

    private fun setListener() {
        binding.btnStage.setOnClickListener {
            moveToStagingScreen()
        }
    }

    private fun validateLotNumber() {

        if (!binding.etLotNumber.text.isNullOrEmpty()) {
            binding.tvError.text =""
            FlareLog.i(TAG, "lot Number field focused")
            val lotNumber = binding.etLotNumber.text.toString().trim()
            // Check for valid or invalid lot number
            val request = ValidateLotNumberRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                batchNumber = lotNumber,
                itemName = viewModel.getPickTaskDetails()?.itemCode ?: "",
                itemId = viewModel.getPickTaskDetails()?.itemId ?: 0
            )
            viewModel.tivoPickFromReserveValidateLotNumber(request)
        } else {
            binding.tvError.text = getString(R.string.alert_enter_lot_number)
        }
    }

    private fun completeTask() {
        val lotNumber = binding.etLotNumber.text.toString().trim()
        // Add lot number to request
        viewModel.markTaskCompleteRequest?.lotNumber = lotNumber

        val action = checkCurrentTaskType()
        if (action != null) {
            moveToFragment(action)
            return
        }
        binding.tvError.text = ""
        viewModel.markTaskCompleteRequest?.let {
            viewModel.taskReservePickCompleteTivoPFR(it)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun moveToStagingScreen() {
        val action = FragmentLotNumberTivoPickFromDirections.actionLotNumberTivoPickFromFragmentToStagingLocationTivoPickFromFragment()
        moveToFragment(action)
    }

    private fun saveCompletedTask() {
        var taskList = viewModel.getTasksCompletedList()
        if (taskList == null) {
            taskList = ArrayList()
        }

        taskList.add(viewModel.getPickTaskDetails())
        viewModel.setTasksCompletedList(taskList)

    }

    private fun subscribeObservers() {

        viewModel.markTaskCompleteTivoPFRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success == true) {
                            saveCompletedTask()
                            binding.etLotNumber.setText("")
                            FlareLog.i(TAG, "markTaskCompleteTivoPFRResponse success: $taskpickResponse")
                            binding.btnStage.isEnabled = true
                            if (taskpickResponse.taskDetails == null) {
                                showSuccessSnackBar(taskpickResponse.message ?: getString(R.string.alert_all_tasks_completed))
                                binding.btnStage.performClick()
                            }else
                            {
                                pkdQty++
                                updatePickedQuantity()
                                viewModel.markTaskCompleteRequest = null //reset the request
                                taskpickResponse.taskDetails.let {
                                    viewModel.setPickTaskDetails(it)
                                }
                                checkNextTaskType(viewModel.getPickTaskDetails())
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.tivoPickFromReserveValidateLotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        if (response.success == true) {
                            completeTask()
                        } else {
                            showErrorSnackBar(response.message ?: "")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


    }





    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etLotNumber.setText(scan?.barcode.toString())
            binding.etLotNumber.text?.length?.let {
                binding.etLotNumber.setSelection(
                    it
                )
                FlareLog.i(TAG, "lot  number field focused")

            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun checkCurrentTaskType(): NavDirections? {
        return viewModel.getPickTaskDetails()?.let {
            val isExpiredTracked = it.itemExpDateTracked
            val action =
                when {
                    isExpiredTracked != "0" -> {
                        FragmentLotNumberTivoPickFromDirections.actionPalletContainerSerialNumberUserDirectedPickFromFragmentToExpiryDateTivoPickFromFragment()
                    }
                    else -> {
                        null
                    }
                }

            action
        }
    }

    private fun checkNextTaskType(taskDetail: TaskDetails?) {
         taskDetail.let {
            val serialTracked = it?.itemSerialTracked
             val uom = it?.taskQtyUom?.lowercase(Locale.ROOT)

            if ((serialTracked == "1" && uom == "pallets") || (serialTracked == "0" && uom == "pallets") || (serialTracked == "4" && uom == "pallets")) {
                moveToScreen(1)
            } else if ((serialTracked == "1" && uom == "cases") || (serialTracked == "0" && uom == "cases") || (serialTracked == "4" && uom == "cases")) {
                moveToScreen(2)
            }


        }
    }

    private fun moveToScreen(type: Int) {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)

        when (type) {
            1 -> // pallet screen
            {
                navController.navigate(
                    R.id.palletSerialNumberTwoTivoPickFromFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.id.palletSerialNumberTwoTivoPickFromFragment, true)
                        .build()
                )
            }

            2 -> // case screen
            {
                navController.navigate(
                    R.id.containerSerialNumberTivoPickFromFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.id.containerSerialNumberTivoPickFromFragment, true)
                        .build()
                )
            }
        }
    }

}