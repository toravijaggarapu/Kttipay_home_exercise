package com.fsc.flare.ui.common

import android.app.Dialog
import android.content.Context
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.annotation.DrawableRes
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewbinding.ViewBinding
import com.fsc.flare.R
import com.fsc.flare.databinding.DialogMultiSelectListBinding
import com.fsc.flare.databinding.DialogPrintRequesterCommonBinding
import com.fsc.flare.databinding.DialogSimpleListBinding
import com.fsc.flare.databinding.RfConfirmAlertDialogBinding
import com.fsc.flare.databinding.RfContentCenterDialogBinding
import com.fsc.flare.utils.AlertConstants
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * @AlertHandler Handles the Alert dialogs
 */
interface AlertHandler {

    fun showSimpleAlert(
        title: String? = null,
        message: String,
        @DrawableRes icon: Int? = null,
        isCancelable: Boolean = false,
        autoDismissDuration: Long = 0L,
        buttonTitle: String? = AlertConstants.POSITIVE_BUTTON_TITLE,
        callBack: () -> Unit = {}
    )

    fun showConfirmationAlert(
        title: String? = null,
        message: String,
        @DrawableRes icon: Int? = null,
        isCancelable: Boolean = false,
        positiveButtonTitle: String = AlertConstants.POSITIVE_BUTTON_TITLE,
        negativeButtonTitle: String = AlertConstants.NEGATIVE_BUTTON_TITLE,
        positiveCallBack: () -> Unit,
        negativeCallBack: () -> Unit = {}
    )

    fun showFlareSimpleAlert(
        title: String? = null,
        message: String,
        @DrawableRes icon: Int? = null,
        autoDismissDuration: Long = 0L,
        isCancelable: Boolean = false,
        buttonTitle: String? = AlertConstants.POSITIVE_BUTTON_TITLE,
        callBack: () -> Unit = {}
    )

    fun showFlareConfirmationAlert(
        title: String? = null,
        message: String,
        @DrawableRes icon: Int? = null,
        isCancelable: Boolean = false,
        positiveButtonTitle: String = AlertConstants.POSITIVE_BUTTON_TITLE,
        negativeButtonTitle: String = AlertConstants.NEGATIVE_BUTTON_TITLE,
        positiveCallBack: () -> Unit,
        negativeCallBack: () -> Unit = {}
    )

    fun showCustomDialog(binding: ViewBinding, initView: () -> Unit = {}): Dialog

    fun showPrintRequesterDialog(
        isCancelable: Boolean = false, requesters: List<String>, onItemSelected: (String) -> Unit
    )

    fun showSimpleListDialog(
        title: String? = null,
        displayList: List<String>,
        isCancelable: Boolean = false,
        positiveButtonTitle: String = AlertConstants.POSITIVE_BUTTON_TITLE,
        positiveCallBack: () -> Unit = {},
    )

    fun <T : MultiSelection> showMultiSelectionDialog(
        title: String? = null,
        displayList: List<T>,
        isCancelable: Boolean = false,
        positiveButtonTitle: String = AlertConstants.POSITIVE_BUTTON_TITLE,
        negativeButtonTitle: String = AlertConstants.NEGATIVE_BUTTON_TITLE,
        positiveCallBack: (List<T>) -> Unit = {},
        negativeCallBack: () -> Unit = {}
    )
}

class AlertHandlerImpl(private val context: Context) : AlertHandler {

    private lateinit var dialogBuilder: MaterialAlertDialogBuilder
    private lateinit var layoutInflater: LayoutInflater

    /**
     * Initialize the dialog components
     */
    private fun initializeDialogComponents() {
        dialogBuilder = MaterialAlertDialogBuilder(context, R.style.AlertDialogTheme)
        layoutInflater = LayoutInflater.from(context)
    }

    /**
     * Show simple alert dialog [Android default alert view]
     */
    override fun showSimpleAlert(
        title: String?,
        message: String,
        @DrawableRes icon: Int?,
        isCancelable: Boolean,
        autoDismissDuration: Long,
        buttonTitle: String?,
        callBack: () -> Unit
    ) {
        initializeDialogComponents()
        val dialog = dialogBuilder.apply {
            title?.let { setTitle(it) }
            setMessage(message)
            setCancelable(isCancelable)
            buttonTitle?.let {
                setPositiveButton(buttonTitle) { dialog, _ ->
                    dialog.dismiss()
                    callBack.invoke()
                }
            }
        }.show()

        if (autoDismissDuration > 0) {
            Handler(Looper.getMainLooper()).postDelayed({
                dialog.dismiss()
            }, autoDismissDuration)
        }
    }

    /**
     * Show confirmation alert dialog [Android default alert view]
     */
    override fun showConfirmationAlert(
        title: String?,
        message: String,
        @DrawableRes icon: Int?,
        isCancelable: Boolean,
        positiveButtonTitle: String,
        negativeButtonTitle: String,
        positiveCallBack: () -> Unit,
        negativeCallBack: () -> Unit
    ) {
        initializeDialogComponents()
        dialogBuilder.apply {
            title?.let { setTitle(it) }
            setMessage(message)
            setCancelable(isCancelable)
            icon?.let { setIcon(icon) }

            setPositiveButton(positiveButtonTitle) { dialog, _ ->
                dialog.dismiss()
                positiveCallBack.invoke()
            }

            setNegativeButton(negativeButtonTitle) { dialog, _ ->
                dialog.dismiss()
                negativeCallBack.invoke()
            }
        }.show()
    }

    /**
     * Show flare simple alert dialog [Custom alert view FLARE Specific]
     */
    override fun showFlareSimpleAlert(
        title: String?,
        message: String,
        @DrawableRes icon: Int?,
        autoDismissDuration: Long,
        isCancelable: Boolean,
        buttonTitle: String?,
        callBack: () -> Unit
    ) {
        initializeDialogComponents()
        val binding = RfContentCenterDialogBinding.inflate(layoutInflater).apply {
            title?.let {
                tvTitle.visibility = View.VISIBLE
                tvTitle.text = it
            }

            tvMessage.text = message

            icon?.let {
                ivIcon.visibility = View.VISIBLE
                ivIcon.setImageResource(it)
            }

            buttonTitle?.let {
                btnOk.visibility = View.VISIBLE
                btnOk.text = it
            }
        }

        val dialog = dialogBuilder.apply {
            setView(binding.root)
            setCancelable(isCancelable)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }

        binding.btnOk.setOnClickListener {
            dialog.dismiss()
            callBack.invoke()
        }

        if (autoDismissDuration > 0) {
            Handler(Looper.getMainLooper()).postDelayed({
                dialog.dismiss()
            }, autoDismissDuration)
        }
    }

    /**
     * Show flare confirmation alert dialog [Custom alert view FLARE Specific]
     *
     */
    override fun showFlareConfirmationAlert(
        title: String?,
        message: String,
        @DrawableRes icon: Int?,
        isCancelable: Boolean,
        positiveButtonTitle: String,
        negativeButtonTitle: String,
        positiveCallBack: () -> Unit,
        negativeCallBack: () -> Unit
    ) {
        initializeDialogComponents()
        val binding = RfConfirmAlertDialogBinding.inflate(layoutInflater).apply {

            icon?.let {
                ivIcon.visibility = View.VISIBLE
                ivIcon.setImageResource(icon)
            } ?: run {
                ivIcon.visibility = View.GONE
            }

            title?.let {
                tvTitle.visibility = View.VISIBLE
                tvTitle.text = it
            }

            tvMessage.text = message
            btnPositive.text = positiveButtonTitle
            btnNegative.text = negativeButtonTitle
        }

        val dialog = dialogBuilder.apply {
            setView(binding.root)
            setCancelable(isCancelable)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }

        binding.btnPositive.setOnClickListener {
            dialog.dismiss()
            positiveCallBack.invoke()
        }

        binding.btnNegative.setOnClickListener {
            dialog.dismiss()
            negativeCallBack.invoke()
        }
    }

    override fun showCustomDialog(binding: ViewBinding, initView: () -> Unit): Dialog {
        val dialog = Dialog(context).apply {
            setContentView(binding.root)
            setCancelable(false)
        }
        dialog.show()
        binding.root.post {
            binding.root.requestLayout()
            initView.invoke()
        }
        dialog.apply {
            window?.setBackgroundDrawableResource(android.R.color.transparent)
            window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dialog
    }

    /**
     * Show print requester dialog [Custom alert FLARE Specific]
     */
    override fun showPrintRequesterDialog(
        isCancelable: Boolean, requesters: List<String>, onItemSelected: (String) -> Unit
    ) {
        initializeDialogComponents()
        val dialogBinding = DialogPrintRequesterCommonBinding.inflate(layoutInflater)
        var selectedPrinter = requesters[0]
        val dialog = dialogBuilder.apply {
            setView(dialogBinding.root)
            setCancelable(isCancelable)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }

        dialogBinding.dropDownPrintRequester.setOptions(ArrayList(requesters))
        dialogBinding.dropDownPrintRequester.text = selectedPrinter
        dialogBinding.dropDownPrintRequester.addTextChangedListener { text ->
            selectedPrinter = text.toString()
        }
        dialogBinding.btnPrint.setOnClickListener {
            dialog.dismiss()
            onItemSelected(selectedPrinter)
        }
    }

    override fun showSimpleListDialog(
        title: String?,
        displayList: List<String>,
        isCancelable: Boolean,
        positiveButtonTitle: String,
        positiveCallBack: () -> Unit
    ) {
        initializeDialogComponents()
        val dialogBinding = DialogSimpleListBinding.inflate(layoutInflater)
        val dialog = dialogBuilder.apply {
            setView(dialogBinding.root)
            setCancelable(isCancelable)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }
        with(dialogBinding) {
            tvTitle.text = title
            btPositive.text = positiveButtonTitle
            tvTitle.paintFlags = tvTitle.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            rvSimpleList.layoutManager = LinearLayoutManager(context)
            rvSimpleList.adapter = SimpleListAdapter(displayList)
            btPositive.setOnClickListener {
                dialog.dismiss()
                positiveCallBack.invoke()
            }
        }
        dialogBinding.root.post { dialogBinding.root.requestLayout() }
    }

    override fun <T : MultiSelection> showMultiSelectionDialog(
        title: String?,
        displayList: List<T>,
        isCancelable: Boolean,
        positiveButtonTitle: String,
        negativeButtonTitle: String,
        positiveCallBack: (List<T>) -> Unit,
        negativeCallBack: () -> Unit
    ) {
        initializeDialogComponents()
        val dialogBinding = DialogMultiSelectListBinding.inflate(layoutInflater)
        val dialog = dialogBuilder.apply {
            setView(dialogBinding.root)
            setCancelable(isCancelable)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }
        with(dialogBinding) {
            tvTitle.text = title
            btnPositive.text = positiveButtonTitle
            btnNegative.text = negativeButtonTitle
            tvErrorMessage.text = null
            tvTitle.paintFlags = tvTitle.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            rvSimpleList.layoutManager = LinearLayoutManager(context)
            val adapter = MultiSelectionListAdapter(displayList) { tvErrorMessage.text = null }
            rvSimpleList.adapter = adapter
            btnPositive.setOnClickListener {
                if (adapter.getSelectedItemsList().isNotEmpty()) {
                    dialog.dismiss()
                    positiveCallBack.invoke(adapter.getSelectedItemsList())
                } else {
                    tvErrorMessage.text = context.getString(R.string.no_items_selected_for_action)
                }
            }

            btnNegative.setOnClickListener {
                dialog.dismiss()
                negativeCallBack.invoke()
            }
        }
        dialogBinding.root.post { dialogBinding.root.requestLayout() }
    }
}