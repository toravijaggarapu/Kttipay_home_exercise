package com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.source.repository.GroupTaskRepository
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.NO_TASKS_FOUND
import com.fsc.flare.ui.fragment.casepicktopalletid.pick_by_case_count.CaseCountScreenError.TASK_FETCH_API_ERROR
import com.fsc.flare.utils.GroupTaskAPI
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CaseCountPickLocationViewModel @Inject constructor(
    private val repository: GroupTaskRepository,
    private val sharedPreferences: SharedPreferences
) : CaseCountBaseViewModel(repository, sharedPreferences) {

    val screenState = innerScreenState.asStateFlow()

    fun getGroupTaskData(scope: CoroutineScope = viewModelScope, pallet: PalletInformation) {
        scope.launch {
            palletInfo = pallet
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = true))
            val requestMap = HashMap<String, String>()
            requestMap[GroupTaskAPI.CARTON_NUMBER] = palletInfo.cartNumber
            requestMap[GroupTaskAPI.CARTON_ID] = "${palletInfo.cartId}"

            val taskResponse = repository.fetchGroupedTask(requestMap)
            innerScreenState.emit(CaseCountFlowState.ShowProgress(show = false))

            taskResponse.takeIf { it.isSuccessful && it.body() != null }?.apply {
                body()?.taskInfo?.let {
                    when {
                        it.eligibleToStage -> {
                            innerScreenState.emit(
                                CaseCountFlowState.StagePending(
                                    cartNumber = it.groupTask.cartNbr,
                                    stageLocationId = it.stageLocId ?: 0,
                                    stageLocation = it.stageLocBarcode.orEmpty()
                                )
                            )
                        }

                        !it.eligibleToStage && it.groupTask.containersToBePicked?.isNotEmpty() == true -> {
                            groupTask = it.groupTask.copy()
                            innerScreenState.emit(CaseCountFlowState.GroupTaskData(groupTask))
                        }

                        else -> {
                            innerScreenState.emit(CaseCountFlowState.ShowError(NO_TASKS_FOUND))
                        }
                    }
                } ?: innerScreenState.emit(CaseCountFlowState.ShowError(TASK_FETCH_API_ERROR))
            } ?: run {
                val errorMessage = handleForwardErrorResponse(
                    taskResponse.code(),
                    taskResponse.errorBody(),
                    taskResponse.message()
                )
                innerScreenState.emit(CaseCountFlowState.ShowError(TASK_FETCH_API_ERROR, errorMessage))
            }
        }
    }

    fun clearData() {
        innerScreenState.value = null
    }
}

