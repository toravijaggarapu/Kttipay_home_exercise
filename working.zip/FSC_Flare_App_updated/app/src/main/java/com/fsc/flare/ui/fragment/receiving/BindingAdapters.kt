package com.fsc.flare.ui.fragment.receiving

import androidx.databinding.BindingAdapter
import com.fsc.flare.utils.Constants
import com.google.android.material.textview.MaterialTextView
import java.text.SimpleDateFormat
import java.util.Locale

@BindingAdapter("app:manufactureDate")
fun setManufactureDate(view: MaterialTextView, expirationDate: String?) {
    expirationDate?.let {
        val formattedDate = formatMfgDate(it)
        view.text = formattedDate
    }
}

private fun formatMfgDate(expirationDate: String): String {
    return try {
        // Define the input and output date formats
        val inputFormat = SimpleDateFormat(Constants.DateFormatter.INPUT_DATE_FORMAT, Locale.getDefault())
        val outputFormat = SimpleDateFormat(Constants.DateFormatter.OUTPUT_DATE_FORMAT, Locale.getDefault())

        // Parse the input date string
        val date = inputFormat.parse(expirationDate)

        // Format the date to the desired output format
        outputFormat.format(date ?: return "")
    } catch (e: Exception) {
        // Handle any parsing exceptions
        e.printStackTrace()
        ""
    }
}