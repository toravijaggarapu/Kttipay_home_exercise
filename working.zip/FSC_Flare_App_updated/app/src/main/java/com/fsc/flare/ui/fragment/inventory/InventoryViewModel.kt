package com.fsc.flare.ui.fragment.inventory

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.inventorytransfer.InventoryTransferSlpInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.inventory.*
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.pallettransfer.PalletDetailResponse
import com.fsc.flare.source.data.dto.pallettransfer.PalletInquiryEntity
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.repository.InventoryRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "InventoryViewModel"

@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val inventoryRepository: InventoryRepository
) : BaseViewModel() {

    val palletDetailKey = "Pallet"

    val palletResponse: MutableLiveData<Resource<PalletCombineDetailResponse>> = SingleLiveEvent()
    val combinePalletResponse: MutableLiveData<Resource<CombinePalletResponse>> = SingleLiveEvent()
    val adjustmentResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val inventoryLocksResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val inventoryResponse: MutableLiveData<Resource<InventoryPalletLockUnlockResponse>> = SingleLiveEvent()
    val cartonDetailsResponse: MutableLiveData<Resource<CartonDetailsResponse>> = SingleLiveEvent()
    val packQtyResponse: MutableLiveData<Resource<CartonAdjustmentResponse>> = SingleLiveEvent()
    val serialValidationResponse: MutableLiveData<Resource<InventoryTaskSerialNumberResponse>> = SingleLiveEvent()
    val lookupsResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val palletDetailResponse: MutableLiveData<Resource<PalletAdjustmentDetailResponse>> = SingleLiveEvent()
    val palletLockListResponse: MutableLiveData<Resource<LockListResponse>> = SingleLiveEvent()
    val caseTransferContainerResponse: MutableLiveData<Resource<CaseTransferContainerResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val caseTransferSubmitLocResponse: MutableLiveData<Resource<CaseTransferSubmitResponse>> = SingleLiveEvent()
    /*Inventory transfer*/
    val inventoryTransferResponse: MutableLiveData<Resource<InventoryTransferSlpInquiryResponse>> = SingleLiveEvent()
    val inventoryTransferSerialResponse: MutableLiveData<Resource<InventoryTransferSlpInquiryResponse>> = SingleLiveEvent()
    var isFromSlpDetail: MutableLiveData<Boolean> = MutableLiveData<Boolean>()
    var inventoryTransferSlpInquiryDetail: MutableLiveData<InventoryTransferSlpInquiryResponse> = MutableLiveData<InventoryTransferSlpInquiryResponse>()
    val inventoryTransferLocationResponse: MutableLiveData<Resource<InventoryTransferLocationResponse>> = SingleLiveEvent()

    /*Inventory transfer container*/
    val inventoryTransferContainerResponse: MutableLiveData<Resource<InventoryTransferContainerResponse>> = SingleLiveEvent()
    val inventoryTransferContainerLocationResponse: MutableLiveData<Resource<InventoryTransferLocationResponse>> = SingleLiveEvent()

    /*Inventory transfer*/
    val inventoryLockcodeResponse: MutableLiveData<Resource<InventoryLockCodeResponse>> = SingleLiveEvent()
    val transactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val containerInquiryResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()

    val caseDetailsByPalletResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()


    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        adjustmentResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getContainer(container, itemInfo)
        adjustmentResponse.postValue(handleContainerResponse(response))
    }

    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }


    fun getInventoryReasonCodes() = viewModelScope.launch {
        inventoryLocksResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getInventoryReasonCodes()
        inventoryLocksResponse.postValue(handleInventoryLocksResponse(response))
    }

    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryLocksResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryLocksResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun inventoryLockAdjustment(inventoryAdjustmentRequest: InventoryAdjustmentRequest) = viewModelScope.launch {
        inventoryResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryLockAdjustment(inventoryAdjustmentRequest)
        inventoryResponse.postValue(handleInventoryResponse(response))
    }

    private fun handleInventoryResponse(response: Response<InventoryPalletLockUnlockResponse>): Resource<InventoryPalletLockUnlockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryAdjustmentResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryAdjustmentResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun lockInventory(inventoryLockRequest: InventoryLockRequest) = viewModelScope.launch {
        inventoryResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryLockRequest(inventoryLockRequest)
        inventoryResponse.postValue(handleInventoryResponse(response))
    }


    fun shipmentCartons(cartonDetailsRequest: CartonDetailsRequest) = viewModelScope.launch {
        cartonDetailsResponse.postValue(Resource.Loading())
        val response = inventoryRepository.shipmentCartons(cartonDetailsRequest)
        cartonDetailsResponse.postValue(handleCartonDetailsResponse(response))
    }

    private fun handleCartonDetailsResponse(response: Response<CartonDetailsResponse>): Resource<CartonDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CartonDetailsResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CartonDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun packqtyconfirm(cartonAdjustmentRequest: CartonAdjustmentRequest) = viewModelScope.launch {
        packQtyResponse.postValue(Resource.Loading())
        val response = inventoryRepository.packqtyconfirm(cartonAdjustmentRequest)
        packQtyResponse.postValue(handlePackQtyResponse(response))
    }

    private fun handlePackQtyResponse(response: Response<CartonAdjustmentResponse>): Resource<CartonAdjustmentResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackQtyResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PackQtyResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate serial number API
     */
    fun validateTaskSerialNumber(inventoryTaskSerialNumberRequest: InventoryTaskSerialNumberRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validateTaskSerialNumber Request: $inventoryTaskSerialNumberRequest")
        serialValidationResponse.postValue(Resource.Loading())
        val serialNumberValidationRes = inventoryRepository.validateInventoryTaskSerialNumber(inventoryTaskSerialNumberRequest)
        serialValidationResponse.postValue(handleSerialNumberValidationResponse(serialNumberValidationRes))
    }

    /**
     * method to handle serial validation response
     */
    private fun handleSerialNumberValidationResponse(response: Response<InventoryTaskSerialNumberResponse>): Resource<InventoryTaskSerialNumberResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SerialNumberResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SerialNumberResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get inventory lookups
     */
    fun getInventoryLookups(inventoryLookupsRequest: InventoryLookupsRequest) = viewModelScope.launch {
        lookupsResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getInventoryLookups(inventoryLookupsRequest)
        lookupsResponse.postValue(handleLookupsResponse(response))
    }

    /**
     * method to handle inventory lookups response
     */
    private fun handleLookupsResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryLookupsResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getInventoryLookupsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /*Inventory transfer*/
    fun inventoryTransferSlp(getContDetailRequest: GetContDetailRequest) = viewModelScope.launch {
        inventoryTransferResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferSlpResponse(getContDetailRequest)
        inventoryTransferResponse.postValue(handleInventoryTransferSlpResponse(response))
    }

    private fun handleInventoryTransferSlpResponse(response: Response<InventoryTransferSlpInquiryResponse>): Resource<InventoryTransferSlpInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferSlpResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferSlpResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun inventoryTransferLocation(inventoryTransferLocationRequest: InventoryTransferLocationRequest) = viewModelScope.launch {
        inventoryTransferLocationResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferLocationResponse(inventoryTransferLocationRequest)
        inventoryTransferLocationResponse.postValue(handleInventoryTransferLocationResponse(response))
    }

    private fun handleInventoryTransferLocationResponse(response: Response<InventoryTransferLocationResponse>): Resource<InventoryTransferLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferLocationResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /*Inventory transfer*/

    /**
     * method to get inventory lockcodes
     */
    fun getInventoryLockcodes(inventoryLockcodeRequest: InventoryLockcodeRequest) = viewModelScope.launch {
        inventoryLockcodeResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getInventoryLockCodes(inventoryLockcodeRequest)
        inventoryLockcodeResponse.postValue(handleInventoryLockCodesResponse(response))
    }

    /**
     * method to handle inventory lockcodes response
     */
    private fun handleInventoryLockCodesResponse(response: Response<InventoryLockCodeResponse>): Resource<InventoryLockCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryLockcodesResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getInventoryLockcodesResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /*Inventory transfer*/
    fun inventoryTransferContainer(getContDetailRequest: GetContDetailRequest) = viewModelScope.launch {
        inventoryTransferContainerResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferContainerResponse(getContDetailRequest)
        inventoryTransferContainerResponse.postValue(handleInventoryTransferContainerResponse(response))
    }

    private fun handleInventoryTransferContainerResponse(response: Response<InventoryTransferContainerResponse>): Resource<InventoryTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun inventoryTransferContainerLocation(inventoryTransferContainerLocationRequest: InventoryTransferContainerLocationRequest) =
        viewModelScope.launch {
            inventoryTransferContainerLocationResponse.postValue(Resource.Loading())
            val response = inventoryRepository.inventoryTransferContainerLocationResponse(inventoryTransferContainerLocationRequest)
            inventoryTransferContainerLocationResponse.postValue(handleInventoryTransferContainerLocationResponse(response))
        }

    private fun handleInventoryTransferContainerLocationResponse(response: Response<InventoryTransferLocationResponse>): Resource<InventoryTransferLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferLocationResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get transaction param details
     */
    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionParamResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getTransactionParam(transactionParamRequest)
        transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(transactionParamResponse.code(), transactionParamResponse.errorBody(), transactionParamResponse.message())
            FlareLog.e(TAG, "TransactionParamResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun inventoryIbPalletAdjustment(inventoryAdjustmentRequest: InventoryIbPalletAdjustmentRequest) = viewModelScope.launch {
        inventoryResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryIbPalletAdjustment(inventoryAdjustmentRequest)
        inventoryResponse.postValue(handleIbPalletAdjustmentResponse(response))
    }

    private fun handleIbPalletAdjustmentResponse(response: Response<InventoryPalletLockUnlockResponse>): Resource<InventoryPalletLockUnlockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "IbPalletAdjustmentResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "IbPalletAdjustmentResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    //Use below section to save data into viewmodel

   var inventoryTransferContainerDetail: MutableLiveData<InventoryTransferContainerResponse> = MutableLiveData()
    var serialNumberList: MutableLiveData<List<String>> = MutableLiveData()
    var cartonDetails: MutableLiveData<CartonDetailsResponse> = MutableLiveData()
    var inventoryLocksOptions: MutableLiveData<ArrayList<String>> = MutableLiveData()
    var inventoryLocksList: MutableLiveData<List<Lookup>> = MutableLiveData()
    var container: MutableLiveData<ArrayList<Container>> = MutableLiveData()
    var palletAdjustmentResponse: MutableLiveData<PalletAdjustmentResponse> = MutableLiveData()
    var showItemAttributes: MutableLiveData<Boolean> = MutableLiveData()
    var containerList: MutableLiveData<List<PalletAdjustmentResponse>> = MutableLiveData()
    var caseTransferContainerList: MutableLiveData<List<CaseTransferContainerModel>?> = MutableLiveData()
    var caseTransferPalletDetail: MutableLiveData<CaseTransferContainer?> = MutableLiveData()
    var caseTransferNewPalletNumber: MutableLiveData<String?> = MutableLiveData()
    var caseScannedCountValue: MutableLiveData<Int> = MutableLiveData()
    var caseQtyUnitsValue: MutableLiveData<Int> = MutableLiveData()
    var definedCaseQtyPerPallet : MutableLiveData<Int> = MutableLiveData()
    var isPalletUomDefined: MutableLiveData<Boolean> = MutableLiveData()

    fun palletUomDefined(b: Boolean) {
        isPalletUomDefined.value = b
    }

    fun isPalletUomDefined():Boolean{
        return isPalletUomDefined.value!!
    }

    fun getDefinedCaseQtyPerPallet(): Int?{
        return definedCaseQtyPerPallet.value
    }

    fun setDefinedCaseQtyPerPallet(qty :Int){
        this.definedCaseQtyPerPallet.value = qty
    }

    fun getContainerInfo(): ArrayList<Container>? {
        return container.value
    }

    fun setContainerInfo(container: ArrayList<Container>) {
        this.container.value = container
    }

    fun getInventoryLocksList(): List<Lookup> {
        return inventoryLocksList.value!!
    }

    fun setInventoryLocksList(inventoryLocksList: List<Lookup>) {
        this.inventoryLocksList.value = inventoryLocksList
    }

    fun setInventoryLocksOptions(inventoryLocksOptions: ArrayList<String>) {
        this.inventoryLocksOptions.value = inventoryLocksOptions
    }

    fun getCartonInfo(): CartonDetailsResponse? {
        return cartonDetails.value
    }

    fun setCartonInfo(cartonDetails: CartonDetailsResponse) {
        this.cartonDetails.value = cartonDetails
    }

    fun getSerialNumberList(): List<String>? {
        return serialNumberList.value
    }

    fun setSerialNumberList(serialList: List<String>) {
        this.serialNumberList.value = serialList
    }

    fun getInventoryTransferContainerDetail(): InventoryTransferContainerResponse {
        return inventoryTransferContainerDetail.value!!
    }

    fun setInventoryTransferContainerDetail(container: InventoryTransferContainerResponse) {
        this.inventoryTransferContainerDetail.value = container
    }


    /*Inventory transfer serial*/
    fun inventoryTransferSerial(getContDetailRequest: GetContDetailRequest) = viewModelScope.launch {
        inventoryTransferSerialResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferSerialResponse(getContDetailRequest)
        inventoryTransferSerialResponse.postValue(handleInventoryTransferSerialResponse(response))
    }

    private fun handleInventoryTransferSerialResponse(response: Response<InventoryTransferSlpInquiryResponse>): Resource<InventoryTransferSlpInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferSerialResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferSerialResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun isFromSlpDetail(): Boolean {
        return isFromSlpDetail.value!!
    }

    fun setIsFromSlpDetail(boolean: Boolean) {
        this.isFromSlpDetail.value = boolean
    }

    fun getInventoryTransferSlpInquiryDetail(): InventoryTransferSlpInquiryResponse {
        return inventoryTransferSlpInquiryDetail.value!!
    }

    fun setInventoryTransferSlpInquiryDetail(inventoryTransferSlpInquiryResponse: InventoryTransferSlpInquiryResponse) {
        this.inventoryTransferSlpInquiryDetail.value = inventoryTransferSlpInquiryResponse
    }

    fun getPalletDetail(palletNumber: String) = viewModelScope.launch {
        palletDetailResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getPalletDetail(palletNumber)
        palletDetailResponse.postValue(handlePalletDetailResponse(response))
    }

    fun getPalletCombineDetails(palletNumber: String,transferType: String) = viewModelScope.launch {
        palletResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getPalletCombineDetails(palletNumber, transferType)
        palletResponse.postValue(handlePalletCombineDetailsResponse(response))
    }

    fun combinePallet(srcPallet: String,destinationPallet: String) = viewModelScope.launch {
        combinePalletResponse.postValue(Resource.Loading())
        val request = CombinePalletRequest(srcPallet,destinationPallet)
        val response = inventoryRepository.combinePallet(request)
        combinePalletResponse.postValue(handleCombinePalletResponse(response))
    }

    private fun handleCombinePalletResponse(response: Response<CombinePalletResponse>): Resource<CombinePalletResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handlePalletCombineDetailsResponse(response: Response<PalletCombineDetailResponse>): Resource<PalletCombineDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handlePalletDetailResponse(response: Response<PalletAdjustmentDetailResponse>): Resource<PalletAdjustmentDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setPalletDetail(palletObject: PalletAdjustmentResponse) {
        palletAdjustmentResponse.value = palletObject
    }

    fun getPalletResponse(): PalletAdjustmentResponse {
       return palletAdjustmentResponse.value!!
    }

    fun showItemAttributes(b: Boolean) {
        showItemAttributes.value = b
    }
    fun isShowItemAttributes():Boolean{
        return showItemAttributes.value!!
    }

    fun getLockList(containerId: Long) = viewModelScope.launch {
        palletLockListResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getLockList(containerId)
        palletLockListResponse.postValue(handlePalletLockListResponse(response))
    }

    private fun handlePalletLockListResponse(response: Response<LockListResponse>): Resource<LockListResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun inventoryIbPalletLockUnlockAdjustment(inventoryIbPalletLockUnlockAdjustmentRequest: InventoryIbPalletLockUnlockAdjustmentRequest) = viewModelScope.launch {
        inventoryResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryIbPalletLockUnlockAdjustment(inventoryIbPalletLockUnlockAdjustmentRequest)
        inventoryResponse.postValue(handleIbPalletLockUnlockAdjustmentResponse(response))
    }

    private fun handleIbPalletLockUnlockAdjustmentResponse(response: Response<InventoryPalletLockUnlockResponse>): Resource<InventoryPalletLockUnlockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "IbPalletAdjustmentResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "IbPalletAdjustmentResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setContainerList(containers: List<PalletAdjustmentResponse>) {
        containerList.value = containers
    }

    fun getContainerList(): List<PalletAdjustmentResponse>? {
        return containerList.value
    }

    fun isItemMixed():Boolean{
        var itemName:String? = null
        var isItemMixed = false
        var isUpdatedOnce = false
        if(getContainerList() != null && getContainerList()!!.isNotEmpty()){
            for (containerObj in getContainerList()!!){
                if(containerObj.containerType.equals("C", true)){
                    if(!isUpdatedOnce){
                        isUpdatedOnce = true
                        itemName = containerObj.item
                    }else {
                        if (containerObj.item != itemName) {
                            isItemMixed = true
                            break
                        }
                    }
                }
            }
        }
        return isItemMixed
    }

    fun isItemDescMixed():Boolean{
        var itemDesc:String? = null
        var isItemDescMixed = false
        var isUpdatedOnce = false
        if(getContainerList() != null && getContainerList()!!.isNotEmpty()){
            for (containerObj in getContainerList()!!){
                if(containerObj.containerType.equals("C", true)){
                    if(!isUpdatedOnce){
                        isUpdatedOnce = true
                        itemDesc = containerObj.itemDesc
                    }else{
                        if(containerObj.itemDesc!=itemDesc){
                            isItemDescMixed = true
                            break
                        }
                    }

                }
            }
        }
        return isItemDescMixed
    }

    fun isLotMixed():Boolean{
        var lot:String? = null
        var isLotMixed = false
        var isUpdatedOnce = false
        if(getContainerList() != null && getContainerList()!!.isNotEmpty()){
            for (containerObj in getContainerList()!!){
                if(containerObj.containerType.equals("C", true)){
                    if(!isUpdatedOnce){
                        isUpdatedOnce = true
                        lot = containerObj.lotNumber
                    }else {
                        if (containerObj.lotNumber != lot) {
                            isLotMixed = true
                            break
                        }
                    }
                }
            }
        }
        return isLotMixed
    }

    fun isExpDateMixed():Boolean{
        var exp:String? = null
        var isExpMixed = false
        var isUpdatedOnce = false
        if(getContainerList() != null && getContainerList()!!.isNotEmpty()){
            for (containerObj in getContainerList()!!){
                if(containerObj.containerType.equals("C", true)){
                    if(!isUpdatedOnce){
                        isUpdatedOnce = true
                        exp = containerObj.expiryDate
                    }else {
                        if (containerObj.expiryDate != exp) {
                            isExpMixed = true
                            break
                        }
                    }
                }
            }
        }
        return isExpMixed
    }

    fun isMfgDateMixed():Boolean{
        var mfg:String? = null
        var isMfgMixed = false
        var isUpdatedOnce = false
        if(getContainerList() != null && getContainerList()!!.isNotEmpty()){
            for (containerObj in getContainerList()!!){
                if(containerObj.containerType.equals("C", true)){
                    if(!isUpdatedOnce){
                        isUpdatedOnce = true
                        mfg = containerObj.manufacturedDate
                    }else {
                        if (containerObj.manufacturedDate != mfg) {
                            isMfgMixed = true
                            break
                        }
                    }
                }
            }
        }

        return isMfgMixed
    }

    fun caseTransferValidateContainer(containerNumber: String, transferType: String) = viewModelScope.launch {
        caseTransferContainerResponse.postValue(Resource.Loading())
        val response = inventoryRepository.caseTransferValidateContainer(containerNumber, transferType)
        caseTransferContainerResponse.postValue(handleCaseTransferContainerResponse(response))
    }

    private fun handleCaseTransferContainerResponse(response: Response<CaseTransferContainerResponse>): Resource<CaseTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CaseTransferContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CaseTransferContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setCaseTransferContainerList(containerList: List<CaseTransferContainerModel>?) {
        caseTransferContainerList.value = containerList
    }

    fun getCaseTransferContainerList(): List<CaseTransferContainerModel>? {
        return caseTransferContainerList.value
    }

    fun generatePalletCaseNumber() = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = inventoryRepository.generatePalletCaseNumber()
        newPalletDetailResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CaseTransferPalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CaseTransferPalletGenerateResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun caseTransferSubmitDestinationLocation(caseTransferSubmitRequest: CaseTransferSubmitRequest) = viewModelScope.launch {
        caseTransferSubmitLocResponse.postValue(Resource.Loading())
        val response = inventoryRepository.caseTransferSubmitDestinationLocation(caseTransferSubmitRequest)
        caseTransferSubmitLocResponse.postValue(handleCaseTransferSubmitDestinationLocation(response))
    }

    private fun handleCaseTransferSubmitDestinationLocation(response: Response<CaseTransferSubmitResponse>): Resource<CaseTransferSubmitResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CaseTransferSubmitResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CaseTransferSubmitResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setCaseTransferPalletDetail(palletDetail: CaseTransferContainer?) {
        caseTransferPalletDetail.value = palletDetail
    }

    fun getCaseTransferPalletDetail(): CaseTransferContainer? {
        return caseTransferPalletDetail.value
    }

    fun setNewPalletNumber(palletNbr: String?) {
        caseTransferNewPalletNumber.value = palletNbr
    }

    fun getNewPalletNumber(): String? {
        return caseTransferNewPalletNumber.value
    }

    val locationResponse: MutableLiveData<Resource<LocationInquiryResponse>> = SingleLiveEvent()
    fun getLocationInfo(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getLocationInfo Request: $locBarCode")
        locationResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getLocationInfo(locBarCode)
        locationResponse.postValue(handleLocationInquiryResponse(response))
    }

    private fun handleLocationInquiryResponse(response: Response<LocationInquiryResponse>): Resource<LocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getContainerDetails(containerNum: String,itemUOMRequired: Boolean) = viewModelScope.launch {
        FlareLog.i(TAG, "getContainer Request: $containerNum")
        containerInquiryResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getContainerDetails(containerNum,itemUOMRequired)
        containerInquiryResponse.postValue(handleContainerInquiryResponse(response))
    }

    private fun handleContainerInquiryResponse(response: Response<ContainerInventoryInquiryResponse>): Resource<ContainerInventoryInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getCaseDetailsByPallet(palletId: String) = viewModelScope.launch {
        caseDetailsByPalletResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getCaseDetailsByPallet(palletId)
        caseDetailsByPalletResponse.postValue(handleCaseDetailsByPalletResponse(response))
    }

    private fun handleCaseDetailsByPalletResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CaseDetailsByPalletResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "CaseDetailsByPalletResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun setCaseScannedCount(caseScannedCount: Int) {
        caseScannedCountValue.value = caseScannedCount
    }

    fun getCaseScannedCount(): Int {
        return caseScannedCountValue.value!!
    }

    fun setCaseQtyUnits(caseQtyUnits: Int) {
        caseQtyUnitsValue.value = caseQtyUnits
    }

    fun getCaseQtyUnits():Int {
        return caseQtyUnitsValue.value!!
    }

    var itemId:String? = null
    var itemInentoryType:String? = null
    var itemBarCode:String? = null

    var ccLock : Boolean = false
    var ccPending : Boolean = false

     var caseTransferPalletResponse : MutableLiveData<CaseTransferContainerResponse> = MutableLiveData()

    fun setCaseTransferPalletResponse(response: CaseTransferContainerResponse){
        caseTransferPalletResponse.value = response
    }

    fun getCaseTransferPalletResponse(): CaseTransferContainerResponse{
        return caseTransferPalletResponse.value!!
    }

    fun getItemID(): String? {
        return itemId
    }
    fun getItemCode(): String? {
        return itemBarCode
    }
    fun getInventoryType(): String? {
        return itemInentoryType
    }

    var palletCombineInquiryEntity:PalletCombineInquiryEntity? = null

    fun setPalletInquiryDetails(palletInquiryEntity: PalletCombineInquiryEntity) {
        this.palletCombineInquiryEntity = palletInquiryEntity
    }

    fun getPalletInquiryDetails(): PalletCombineInquiryEntity? {
        return palletCombineInquiryEntity
    }
}