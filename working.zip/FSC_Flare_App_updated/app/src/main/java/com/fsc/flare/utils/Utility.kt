package com.fsc.flare.utils

import com.fsc.flare.FlareApplication
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import kotlin.experimental.and
import kotlin.experimental.or

class Utility {

    companion object {

        fun isHardScanCapable(): Boolean {
            return FlareApplication.getScanner() != null && FlareApplication.getScanner()?.isHardScanEnabled!!
        }

        /**
         * Ripped from [UUID.randomUUID], except with a new SecureRandom every time. This prevents
         * a strange bug where re-deploying Flare causes the same UUIDs to be generated
         * that were generated on a previous deploy.
         */
        fun generateUUID(): String {
            val bytes = ByteArray(100000)
            Random().nextBytes(bytes)
            val ng = SecureRandom(bytes)
            val randomBytes = ByteArray(16)
            ng.nextBytes(randomBytes)
            randomBytes[6] = randomBytes[6] and 0x0f /* clear version        */
            randomBytes[6] = randomBytes[6] or 0x40 /* set to version 4     */
            randomBytes[8] = randomBytes[8] and 0x3f /* clear variant        */
            randomBytes[8] = randomBytes[8] or 0x80.toByte() /* set to IETF variant  */
            var msb: Long = 0
            var lsb: Long = 0
            for (i in 0..7) msb = msb shl 8 or ((randomBytes[i] and 0xff.toByte()).toLong())
            for (i in 8..15) lsb = lsb shl 8 or ((randomBytes[i] and 0xff.toByte()).toLong())
            return UUID(msb, lsb).toString()
        }

    }
}