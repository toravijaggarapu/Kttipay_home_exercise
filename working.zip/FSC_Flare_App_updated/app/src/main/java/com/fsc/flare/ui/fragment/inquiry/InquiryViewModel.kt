package com.fsc.flare.ui.fragment.inquiry

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.cyclecount.LocationInventoryCount
import com.fsc.flare.source.data.dto.inquiry.asn.*
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.inventorytransfer.InventoryTransferContainerInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.inventorytransfer.InventoryTransferSlpInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.itembarcode.Item
import com.fsc.flare.source.data.dto.inquiry.itembarcode.ItemBarcodeResponse
import com.fsc.flare.source.data.dto.inquiry.location.CaseObj
import com.fsc.flare.source.data.dto.inquiry.location.resp.LocationDetailsResponse
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.location.LocationInventoryResponse
import com.fsc.flare.source.data.dto.inquiry.location.PalletObj
import com.fsc.flare.source.data.dto.inquiry.location.ReverseContObj
import com.fsc.flare.source.data.dto.inquiry.location.resp.RlogLocationInquiryResp
import com.fsc.flare.source.data.dto.inquiry.slp.InquirySLPResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.PalletAdjustmentDetailResponse
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.receiving.ReceivingASNRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.InboundShipment
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentResponse
import com.fsc.flare.source.repository.InquiryRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import java.math.BigInteger
import javax.inject.Inject

private const val TAG = "InquiryViewModel"

@HiltViewModel
class InquiryViewModel @Inject constructor(
    private val inquiryRepository: InquiryRepository
) : BaseViewModel() {

    //Sample commit for github
    val containerResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()
    val locationResponse: MutableLiveData<Resource<LocationDetailsResponse>> = SingleLiveEvent()
    val dockDoorResponse: MutableLiveData<Resource<LocationInquiryResponse>> = SingleLiveEvent()
    val itemBarcodeResponse: MutableLiveData<Resource<ItemBarcodeResponse>> = SingleLiveEvent()
    val slpDetailsResponse: MutableLiveData<Resource<InquirySLPResponse>> = SingleLiveEvent()
    val inventoryTransferSlpInquiryResponse: MutableLiveData<Resource<InventoryTransferSlpInquiryResponse>> = SingleLiveEvent()
    val inventoryTransferContainerInquiryResponse: MutableLiveData<Resource<InventoryTransferContainerInquiryResponse>> = SingleLiveEvent()
    val inventoryTransferSerialInquiryResponse: MutableLiveData<Resource<InventoryTransferSlpInquiryResponse>> = SingleLiveEvent()
    val asnDetailsResponse: MutableLiveData<Resource<PackageInboundShipmentResponse>> = SingleLiveEvent()
    val palletDetailsResponse: MutableLiveData<Resource<ASNPalletInquiryResponse>> = SingleLiveEvent()
    val printRequestorResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    val inquiryASNTransParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val renamePalletResponse: MutableLiveData<Resource<RenamePalletResponse>> = SingleLiveEvent()
    val asnPrintPalletResponse: MutableLiveData<Resource<ASNPalletInquiryPrintLabelResponse>> = SingleLiveEvent()
    val locationInventoryResponse: MutableLiveData<Resource<LocationInventoryResponse>> = SingleLiveEvent()
    val palletInventoryResponse: MutableLiveData<Resource<PalletAdjustmentDetailResponse>> = SingleLiveEvent()
    val locationInventoryCountResponse: MutableLiveData<Resource<LocationInventoryCount>> = SingleLiveEvent()
    val rLogLocationInquiryResponse: MutableLiveData<Resource<RlogLocationInquiryResp>> = SingleLiveEvent()
    var palletListHashMap: HashMap<Int, MutableList<PalletObj>> = HashMap()
    var caseListHashMap: HashMap<Int, MutableList<CaseObj>> = HashMap()
    var locationContainer: LocationInventoryResponse.ContainersEntity? = null
    var locInventoryCounts: LocationInventoryCount? = null
    var rLogLocationInquiry: RlogLocationInquiryResp? = null
    var reverseContainerList: MutableList<ReverseContObj> = mutableListOf()
    val PAGELIMIT = 100
    var lotNumbersList: MutableList<String?> = mutableListOf()
    var expiredDatesList: MutableList<String?> = mutableListOf()
    var cooCodesList: MutableList<String?> = mutableListOf()
    var invTypesList: MutableList<String?> = mutableListOf()

    private var _selectedPallet: String = ""
    var selectedPallet: String
        get() = _selectedPallet
        set(value) {
            _selectedPallet = value
        }

//    private var _page: Int = 0
//    var page: Int
//        get() = _page
//        set(value) {
//            _page = value
//        }

    fun getItemsInContainer(containerNum: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getItemsInContainer Request: $containerNum")
        containerResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getItemsInContainer(containerNum)
        containerResponse.postValue(handleContainerInquiryResponse(response))
    }

    fun getLocationInfo(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getLocationInfo Request: $locBarCode")
        locationResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getLocationInfo(locBarCode)
        locationResponse.postValue(handleLocationDetailsResponse(response))
    }

    fun getDockDoorInfo(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getDockDoorInfo Request: $locBarCode")
        dockDoorResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getDockDoorInfo(locBarCode)
        dockDoorResponse.postValue(handleDockDoorInquiryResponse(response))
    }

    fun getInquiryItemInfo(itemBarcode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getInquiryItemInfo Request: $itemBarcode")
        itemBarcodeResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getInquiryItemInfo(itemBarcode)
        itemBarcodeResponse.postValue(handleItemInquiryResponse(response))
    }

    /**
     * method to get printer requestor config list
     */
    fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getPrintRequestorList(printerConfigRequest)
        printRequestorResponse.postValue(handlePrintRequestorListResponse(response))
    }

    /**
     * method to get transaction param details
     */
    fun getInquiryASNTransactionParam(mprTransParamRequest: MPRTransParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "InquiryASNtransactionParam Request: $mprTransParamRequest")
        inquiryASNTransParamResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getMPRTransactionParam(mprTransParamRequest)
        inquiryASNTransParamResponse.postValue(handleInquiryASNTransactionParamResponse(response))
    }

    private fun handleItemInquiryResponse(response: Response<ItemBarcodeResponse>): Resource<ItemBarcodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ItemInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ItemInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleLocationDetailsResponse(response: Response<LocationDetailsResponse>): Resource<LocationDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleDockDoorInquiryResponse(response: Response<LocationInquiryResponse>): Resource<LocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DockDoorInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "DockDoorInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleContainerInquiryResponse(response: Response<ContainerInventoryInquiryResponse>): Resource<ContainerInventoryInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handlePrintRequestorListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to handle MPR transaction param response
     */
    private fun handleInquiryASNTransactionParamResponse(response: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InquiryASNTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InquiryASNTransactionParamResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to get slp details
     */
    fun getSLPDetails(slp: BigInteger) = viewModelScope.launch {
        FlareLog.i(TAG, "getSLPDetails Request: $slp")
        slpDetailsResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getSLPDetails(slp)
        slpDetailsResponse.postValue(handleSLPDetailsResponse(response))
    }

    /**
     * method to handle SLP details response
     */
    private fun handleSLPDetailsResponse(response: Response<InquirySLPResponse>): Resource<InquirySLPResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SLPInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SLPInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get Inventory transfer SLP inquiry detail
     */
    fun getInventoryTransferSlpInquiryDetail(slp: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getSLPDetails Request: $slp")
        inventoryTransferSlpInquiryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getInventoryTransferSlpInquiryDetail(slp)
        inventoryTransferSlpInquiryResponse.postValue(handleInventoryTransferSlpInquiryDetail(response))
    }

    /**
     * method to handle Inventory transfer SLP inquiry detail.
     */
    private fun handleInventoryTransferSlpInquiryDetail(response: Response<InventoryTransferSlpInquiryResponse>): Resource<InventoryTransferSlpInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferSLPInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferSLPInquiryResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get ASN details
     */
    fun getASNDetails(receivingASNRequest: ReceivingASNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getASNDetails Request: $receivingASNRequest")
        asnDetailsResponse.postValue(Resource.Loading())
        val asnDetailsRes = inquiryRepository.getASNDetails(receivingASNRequest)
        asnDetailsResponse.postValue(handleASNDetailsResponse(asnDetailsRes))
    }

    /**
     * method to handle ASN details from response
     */
    private fun handleASNDetailsResponse(asnDetailsResponse: Response<PackageInboundShipmentResponse>): Resource<PackageInboundShipmentResponse>? {
        if (asnDetailsResponse.isSuccessful) {
            asnDetailsResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "asnDetailsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(asnDetailsResponse.code(), asnDetailsResponse.errorBody(), asnDetailsResponse.message())
            FlareLog.e(TAG, "asnDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get ASN details
     */
    fun getPalletDetails(asnPalletInquiryRequest: ASNPalletInquiryRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getPalletDetails Request: $asnPalletInquiryRequest")
        palletDetailsResponse.postValue(Resource.Loading())
        val palletDetailsRes = inquiryRepository.getPalletDetails(asnPalletInquiryRequest)
        palletDetailsResponse.postValue(handlePalletDetailsResponse(palletDetailsRes))
    }

    /**
     * method to handle Pallet details from response
     */
    private fun handlePalletDetailsResponse(response: Response<ASNPalletInquiryResponse>): Resource<ASNPalletInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "palletDetailsResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "palletDetailsResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to generate new pallet
     */
    fun newPalletNumberGenerate() = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = inquiryRepository.generatePalletCaseNumber()
        newPalletDetailResponse.postValue(handleNewPalletNumberGenerateResponse(response))
    }

    /**
     * method to handle new pallet response
     */
    private fun handleNewPalletNumberGenerateResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerate Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to rename pallet
     */
    fun renamePalletNumberCall(renamePalletRequest: ASNRenamePalletRequest) = viewModelScope.launch {
        renamePalletResponse.postValue(Resource.Loading())
        val response = inquiryRepository.renamePalletNumber(renamePalletRequest)
        renamePalletResponse.postValue(handleRenamePalletNumberResponse(response))
    }

    /**
     * method to handle rename pallet response
     */
    private fun handleRenamePalletNumberResponse(response: Response<RenamePalletResponse>): Resource<RenamePalletResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletRenameResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletRename Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    var item: MutableLiveData<ContainerInventoryInquiryResponse> = MutableLiveData<ContainerInventoryInquiryResponse>()
    var location: MutableLiveData<LocationDetailsResponse> = MutableLiveData<LocationDetailsResponse>()
    var dockdoor: MutableLiveData<LocationInquiryResponse> = MutableLiveData<LocationInquiryResponse>()
    var itemBarcode: MutableLiveData<Item> = MutableLiveData<Item>()
    var slpDetails: MutableLiveData<InquirySLPResponse> = MutableLiveData<InquirySLPResponse>()
    var inventoryTransferSlpInquiryDetail: MutableLiveData<InventoryTransferSlpInquiryResponse> =
        MutableLiveData<InventoryTransferSlpInquiryResponse>()
    var asnDetailsData: MutableLiveData<InboundShipment> = MutableLiveData<InboundShipment>()
    var palletDetailsData: MutableLiveData<PalletInquiry> = MutableLiveData<PalletInquiry>()
    var inventoryTransferContainerInquiryDetail: MutableLiveData<InventoryTransferContainerInquiryResponse> = MutableLiveData<InventoryTransferContainerInquiryResponse>()
    var isFromSlpDetail: MutableLiveData<Boolean> = MutableLiveData<Boolean>()
    var selectedPrinterData: MutableLiveData<PrinterConfig> = MutableLiveData<PrinterConfig>()
    var mprTransactionParamData: MutableLiveData<MPRepackTransParamResponse> = MutableLiveData<MPRepackTransParamResponse>()
    private val transactionParamHahMap = HashMap<String, Boolean>()

    fun getItem(): ContainerInventoryInquiryResponse? {
        return item.value
    }

    fun setItem(item: ContainerInventoryInquiryResponse) {
        this.item.value = item
    }

    fun getLocation(): LocationDetailsResponse? {
        return location.value
    }

    fun setLocation(location: LocationDetailsResponse) {
        this.location.value = location
    }

    fun getDDLocation(): LocationInquiryResponse? {
        return dockdoor.value
    }

    fun setDDLocation(dockdoor: LocationInquiryResponse) {
        this.dockdoor.value = dockdoor
    }

    fun getItemBarcode(): Item? {
        return itemBarcode.value
    }

    fun setItemBarcode(itemBarcode: Item) {
        this.itemBarcode.value = itemBarcode
    }

    fun getSLPDetails(): InquirySLPResponse? {
        return slpDetails.value
    }

    fun setSLPDetails(inquirySLPResponse: InquirySLPResponse) {
        this.slpDetails.value = inquirySLPResponse
    }

    fun getInventoryTransferSlpInquiryDetail(): InventoryTransferSlpInquiryResponse {
        return inventoryTransferSlpInquiryDetail.value!!
    }

    fun setInventoryTransferSlpInquiryDetail(inventoryTransferSlpInquiryResponse: InventoryTransferSlpInquiryResponse) {
        this.inventoryTransferSlpInquiryDetail.value = inventoryTransferSlpInquiryResponse
    }

    /*Inventory transfer*/
    fun inventoryTransferContainer(getContDetailRequest: GetContDetailRequest) = viewModelScope.launch {
        inventoryTransferContainerInquiryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.inventoryTransferContainerResponse(getContDetailRequest)
        inventoryTransferContainerInquiryResponse.postValue(handleInventoryTransferContainerResponse(response))
    }

    private fun handleInventoryTransferContainerResponse(response: Response<InventoryTransferContainerInquiryResponse>): Resource<InventoryTransferContainerInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferContainerInquiryResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getInventoryTransferContainerInquiryDetail(): InventoryTransferContainerInquiryResponse {
        return inventoryTransferContainerInquiryDetail.value!!
    }

    fun setInventoryTransferContainerInquiryDetail(inventoryTransferContainerInquiryResponse: InventoryTransferContainerInquiryResponse) {
        this.inventoryTransferContainerInquiryDetail.value = inventoryTransferContainerInquiryResponse
    }

    /**
     * method to get Inventory transfer Serial inquiry detail
     */
    fun getInventoryTransferSerialInquiryDetail(slp: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getSerialDetails Request: $slp")
        inventoryTransferSerialInquiryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getInventoryTransferSerialInquiryDetail(slp)
        inventoryTransferSerialInquiryResponse.postValue(handleInventoryTransferSerialInquiryDetail(response))
    }

    /**
     * method to handle Inventory transfer Serial inquiry detail.
     */
    private fun handleInventoryTransferSerialInquiryDetail(response: Response<InventoryTransferSlpInquiryResponse>): Resource<InventoryTransferSlpInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferSerialInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferSerialInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to post Print requestor label
     */
    fun printPalletLabel(printPalletRequest: ASNPrintPalletRequest) = viewModelScope.launch {
        asnPrintPalletResponse.postValue(Resource.Loading())
        val response = inquiryRepository.printPalletLabel(printPalletRequest)
        asnPrintPalletResponse.postValue(handlePrintPalletResponse(response))
    }

    /**
     * method to handle print pallet/case/both label response.
     */
    private fun handlePrintPalletResponse(response: Response<ASNPalletInquiryPrintLabelResponse>): Resource<ASNPalletInquiryPrintLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "asnPrintPalletResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "asnPrintPalletResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun isFromSlpDetail(): Boolean {
        return isFromSlpDetail.value!!
    }

    fun setIsFromSlpDetail(boolean: Boolean) {
        this.isFromSlpDetail.value = boolean
    }

    fun setAsnDetailsData(inboundShipment: InboundShipment) {
        this.asnDetailsData.value = inboundShipment
    }

    fun getPalletDetails(): PalletInquiry? {
        return palletDetailsData.value
    }

    fun setPalletDetails(palletInquiry: PalletInquiry) {
        this.palletDetailsData.value = palletInquiry
    }

    fun setSelectedPrinterData(printerConfig: PrinterConfig?) {
        this.selectedPrinterData.value = printerConfig
    }

    fun getSelectedPrinterData(): PrinterConfig? {
        return selectedPrinterData.value
    }

    fun setInquiryASNTransactionParamData(transactionParamResponse: MPRepackTransParamResponse?) {
        transactionParamResponse!!.transParams?.forEach {
            transactionParamHahMap[it.transCode] = it.required
        }
        this.mprTransactionParamData.value = transactionParamResponse
    }
    fun checkIfPrintNeeded(printerKey: String): Boolean {
        return if(transactionParamHahMap.containsKey(printerKey)) transactionParamHahMap[printerKey]!! else false
    }

    fun getLocationInventory(location: String, page: Int, pageLimit: Int) = viewModelScope.launch {
        locationInventoryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getLocationInventory(location, page, pageLimit)
        locationInventoryResponse.postValue(handleLocationInventoryResponse(response))
    }
    private fun handleLocationInventoryResponse(response: Response<LocationInventoryResponse>): Resource<LocationInventoryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "locationInventoryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "locationInventory Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getPalletInventory(palletNumber: String, page: Int, pageLimit: Int) = viewModelScope.launch {
        palletInventoryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getPalletInventory(palletNumber, page, pageLimit)
        palletInventoryResponse.postValue(handlePalletDetailResponse(response))
    }

    private fun handlePalletDetailResponse(response: Response<PalletAdjustmentDetailResponse>): Resource<PalletAdjustmentDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletInventoryResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletInventoryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getLocationInventoryCount(locationId: String) = viewModelScope.launch {
        locationInventoryCountResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getLocationInventoryCount(locationId)
        locationInventoryCountResponse.postValue(handleLocationInventoryCount(response))
    }

    private fun handleLocationInventoryCount(response: Response<LocationInventoryCount>): Resource<LocationInventoryCount>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "locationInventoryCountResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "locationInventoryCountResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getRlogLocationInquiry(locationBarcode: String) = viewModelScope.launch {
        rLogLocationInquiryResponse.postValue(Resource.Loading())
        val response = inquiryRepository.getRlogLocationInquiry(locationBarcode)
        rLogLocationInquiryResponse.postValue(handleRlogLocationInquiryResponse(response))
    }

    private fun handleRlogLocationInquiryResponse(response: Response<RlogLocationInquiryResp>): Resource<RlogLocationInquiryResp>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "rLogLocationInquiryResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "rLogLocationInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}