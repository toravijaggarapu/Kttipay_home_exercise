package com.fsc.flare.ui.fragment.inventory.combinebypallet

import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.inventory.PalletCombineInquiryEntity
import com.fsc.flare.source.data.dto.splitcontainerreverse.TaskDetails

/**
 * This shared viewmodel intended to share the data among the flow,
 * not for the business logic, Do not place any business logic functions in this class.
 *
 *  @Note: Please make sure clear the data at the end of the flow.
 */

const val KEY_COMBINE_PALLET_NEW_TASK_RESULT = "KEY_COMBINE_PALLET_NEW_TASK_RESULT"

class CombineByPalletSharedViewModel : ViewModel() {

    var taskDetails: TaskDetails? = null
    var taskMode: String? = null
    var palletInformation: PalletCombineInquiryEntity? = null

    /**
     * Clear or reset the data in the viewmodel.
     */
    fun clearData() {
        taskDetails = null
        taskMode = null
        palletInformation = null
    }
}