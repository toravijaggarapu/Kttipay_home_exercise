package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.taskgroup.GroupedTaskResponse
import com.fsc.flare.source.data.dto.taskgroup.PickGroupedTaskRequest
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.GroupTaskAPI
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

class GroupTaskRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun fetchGroupedTask(queryMap: Map<String, String>): Response<GroupedTaskResponse> {
        val finalMap = HashMap<String, String>(queryMap)
        finalMap[GroupTaskAPI.ALLOCATION_TYPE] = GroupTaskAPI.ALLOCATION_TYPE_VALUE
        finalMap[GroupTaskAPI.TASK_GROUP] = GroupTaskAPI.TASK_GROUP_VALUE
        finalMap[GroupTaskAPI.CASE_PICK_WITH_PALLET] = "true"
        return getGroupedTask(finalMap)
    }

    suspend fun skipTask(queryMap: Map<String, String>) : Response<GroupedTaskResponse> {
        val finalMap = HashMap<String, String>(queryMap)
        finalMap[GroupTaskAPI.ALLOCATION_TYPE] = GroupTaskAPI.ALLOCATION_TYPE_VALUE
        finalMap[GroupTaskAPI.TASK_GROUP] = GroupTaskAPI.TASK_GROUP_VALUE
        finalMap[GroupTaskAPI.CASE_PICK_WITH_PALLET] = "true"
        finalMap[GroupTaskAPI.SKIP_CURRENT_GROUP] = "true"
        return getGroupedTask(finalMap)
    }

    private suspend fun getGroupedTask(queryMap: Map<String, String>) =
        apiGatewayInterface.fetchGroupedTask(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            queryMap = queryMap
        )

    suspend fun endPallet(endPickCartReq: EndPickCartReq) =
        apiGatewayInterface.pickEndCart(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            endPickCartReq = endPickCartReq
        )

    suspend fun pickGroupedTask(groupedTaskRequest: PickGroupedTaskRequest) =
        apiGatewayInterface.pickGroupedTask(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            pickGroupedTaskRequest = groupedTaskRequest
        )
}