package com.fsc.flare.ui.fragment.packing

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackingSelectShippingMethodBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackingSelectShippingMethodFragment"
private const val SHIPMENT_METHOD = "FEDEX_SHIP_VIA"

@AndroidEntryPoint
class PackingSelectShippingMethodFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPackingSelectShippingMethodBinding
    private val viewModel: PackingViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPackingSelectShippingMethodBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        subscribeObservers()

        return binding.root
    }

    fun subscribeObservers() {
        // Get Shipping Method from API
        viewModel.shipmentMethodListResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shipmentMethodListResponse ->
                        FlareLog.i(
                            TAG,
                            "ShipmentMethodListResponse success: $shipmentMethodListResponse"
                        )

                        shipmentMethodListResponse.lookups.forEach { lookUp ->
                            if (lookUp.lookupName == SHIPMENT_METHOD && lookUp.lookupCodes.isNotEmpty()) {

                                viewModel.shipmentMethodsLookUpList = ArrayList(lookUp.lookupCodes)
                                viewModel.shipmentMethodList = ArrayList()

                                viewModel.shipmentMethodsLookUpList.forEach { lookupCode ->
                                    viewModel.shipmentMethodList.add(lookupCode.lookupCodeDescription)
                                }

                                binding.shippingSpinner.setOptions(viewModel.shipmentMethodList)

                                // Set Shipping Method Associated with the Carton
                                val shipmentMethodList = viewModel.shipmentMethodsLookUpList.filter { it.lookupCode == viewModel.getShipmentMethodOfCarton() }
                                if(shipmentMethodList.isNotEmpty()){
                                    binding.shippingSpinner.setSelectedValue(shipmentMethodList[0].lookupCodeDescription)
                                }
                            }
                        }

                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackStationListResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Call Shipment Method API
        viewModel.getShipmentMethods()

        // Set Pack method
        binding.tvPackMethodValue.text = viewModel.getPackMethodDescription()

        // Set Pack Station
        binding.tvPackStationValue.text = viewModel.getPackStationDescription()


        if(viewModel.cartonNumber.isEmpty()){
            // Set Tote Number

            binding.cartonNumberGroup.visibility = View.GONE

            binding.toteNumberGroup.visibility = View.VISIBLE
            binding.tvToteNumberValue.text = viewModel.toteNumber
        }
        else {
            // Set Carton Number
            binding.toteNumberGroup.visibility = View.GONE

            binding.cartonNumberGroup.visibility = View.VISIBLE
            binding.tvCartonNumberValue.text = viewModel.cartonNumber
        }

        viewModel.selectedShipmentMethod = null
        binding.shippingSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
                viewModel.selectedShipmentMethod = null
                viewModel.shipmentMethodsLookUpList.forEach { lookupCode ->
                    if (lookupCode.lookupCodeDescription.equals(isUpdated,true)) {
                        viewModel.selectedShipmentMethod = lookupCode
                    }
            }
        }

        binding.ldNextButton.setOnClickListener {
            if(viewModel.selectedShipmentMethod == null){
                showErrorSnackBar(resources.getString(R.string.select_shipment_method))
            }
            else {
                navigateToSelectCartonTypeFragment()
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    fun navigateToSelectCartonTypeFragment(){
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackingSelectShippingMethodFragmentDirections.actionPackingSelectShippingMethodFragmentToPackingSelectCartonMethodFragment()
        navController.navigate(action)
    }

}