package com.fsc.flare.ui.fragment.prtotetopackstation

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPrtpsStageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteStageReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PRTPSToteFragmentStagingLocation"

@AndroidEntryPoint
class PRTPSToteFragmentStagingLocation : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPrtpsStageBinding
    private val viewModel: PRTPSViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private val checkedTotes = ArrayList<String>()

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    var locationId = 0

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPrtpsStageBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObserver()
        return binding.root
    }
    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleToteCountView()
        binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString() + getString(R.string.lbl_view)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateStagingLocation()
                }
            }
            v.onTouchEvent(event)
        }

        if (viewModel.isKitStaging) {
            binding.tvStagedLocation.visibility = View.VISIBLE
            binding.tvStagedLocationValue.visibility = View.VISIBLE
            binding.tvStagedLocationValue.text = viewModel.toteDetails?.kitStageLocation
            binding.tvCartToPrTransfer.text = getString(R.string.pr_tote_to_kit_staging)
            binding.tvStagingLocation.text = getString(R.string.hint_kitting_staging_location)
            binding.prLocationInput.hint = getString(R.string.hint_kitting_staging_location)
        }
        binding.prLocationInput.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "StagingLocation field focused")
                validateStagingLocation()
            }
            false
        }
        binding.prLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.prLocationErrRes.text = null
            }
        })
        binding.tvTotalCountValue.setOnClickListener{
            if(viewModel.getToteNumbersList().size>0)
                showToteList()
        }
    }

    private fun validateStagingLocation() {
        if (!binding.prLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.prLocationInput)
            if (viewModel.isKitStaging && binding.prLocationInput.text.toString() != binding.tvStagedLocationValue.text.toString()){
                binding.prLocationErrRes.text = getString(R.string.error_wrong_kitting_stage_location)
                return
            }
            viewModel.validateStagingLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    binding.prLocationInput.text.toString(),
                    if(viewModel.isKitStaging) "KS" else "S"
                )
            )
        }
    }

    private fun handleToteCountView() {
        if(viewModel.getToteNumbersList().size>0)
        {
            binding.tvTotalCountValue.visibility = View.VISIBLE
            binding.tvTotalCount.visibility =View.VISIBLE
            binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString() +  " "+ getString(R.string.lbl_view)
        }else
        {
            binding.tvTotalCountValue.visibility = View.GONE
            binding.tvTotalCount.visibility =View.GONE
            getNavigationController().popBackStack()
        }
    }

    private fun showToteList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.saved_totes_cartons))
        checkedTotes.clear()
        val totesArray = viewModel.getToteNumbersList().toTypedArray()
        builder.setMultiChoiceItems(totesArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedTotes.add(viewModel.getToteNumbersList()[which])
            }
            else
            {
                checkedTotes.remove(viewModel.getToteNumbersList()[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
            //    Log.d("debug", "Position:" + which)
            //   Log.d("debug", "isChecked Item:$"+viewModel.getToteNumbersList()[which])

        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            viewModel.removeUncheckedTotes(checkedTotes)
            handleToteCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }
    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedTotes.size>0
        if(checkedTotes.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    /**
     * method to update PR to pack station
     */
    private fun updatePackStation() {
        viewModel.updateToPackStation(
            PRToteStageReq(
                prTotes = viewModel.getToteNumbersList(),
                locationId = locationId,
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeObserver() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationClassResponse ->
                        if (locationClassResponse.success != null && locationClassResponse.success) {
                            FlareLog.i(TAG, "locationClass success: $locationClassResponse")
                            if (locationClassResponse.locations != null && locationClassResponse.locations.isNotEmpty()) {
                                if (indexExists(locationClassResponse.locations, 0)) {
                                    val location = locationClassResponse.locations[0]
                                    val locationClass = location.classification
                                    if (locationClass == "S" || (locationClass == "KS" && viewModel.isKitStaging)) {
                                        locationId = location.locationId
                                        updatePackStation()
                                    }
                                } else {
                                    if (viewModel.isKitStaging)
                                        displayErrorMessage(getString(R.string.not_valid_kit_staging_location))
                                    else
                                        displayErrorMessage(getString(R.string.invalid_pack_station_staging_location))
                                }
                            } else {
                                if (viewModel.isKitStaging)
                                    displayErrorMessage(getString(R.string.not_valid_kit_staging_location))
                                else
                                    displayErrorMessage(getString(R.string.invalid_pack_station_staging_location))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        displayErrorMessage(getString(R.string.invalid_pack_station_staging_location))
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.toteStageResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { toteStageResponse ->
                        if (toteStageResponse.success != null && toteStageResponse.success) {
                            FlareLog.i(TAG, "toteStageResponse success: $toteStageResponse")
                            binding.prLocationInput.text = null
                            viewModel.resetToteNumbersList()
                            showSuccessSnackBarImp(toteStageResponse.message.toString()){
                                getNavigationController().popBackStack(R.id.prToteToPackStationTote, false)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "toteStageResponse error: $message")
                       displayErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.prLocationErrRes.text = message
        binding.prLocationInput.selectAll()
        showSoftKeyBoard(fragmentContext, binding.prLocationInput)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.prLocationInput.setText(scan?.barcode.toString())
            binding.prLocationInput.text?.length?.let {
                binding.prLocationInput.setSelection(it)
            }
            FlareLog.i(TAG, "Cart field focused")
            validateStagingLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}