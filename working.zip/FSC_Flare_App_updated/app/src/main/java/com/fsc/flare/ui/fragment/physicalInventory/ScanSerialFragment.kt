package com.fsc.flare.ui.fragment.physicalInventory

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanSerialBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "ScanSerialFragment"
@AndroidEntryPoint
class ScanSerialFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentScanSerialBinding
    private lateinit var taskData: BatchTaskDetailsResp
    lateinit var cb1: CustomVisibilityCallback
    private var count = 0

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentScanSerialBinding.inflate(inflater, container, false)
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType ?: ""
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType.plus( " - " ).plus(taskData.batchNumber)
        subscribeSerialValidationObserver()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleTouchEvent()
        handleEnterKeyEvent()
        handleViewButtonClick()
        if (viewModel.serialList.size == viewModel.currentScanQty) {
            enableSerialField(false)
        }
        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun handleViewButtonClick() {
        binding.tvView.setOnClickListener {
            showScannedMultiItemsListDialog(
                viewModel.serialList,
                title=binding.tvSerial.text.toString() + " (${viewModel.serialList.size}/${viewModel.currentScanQty})",
                finalList = {
                    viewModel.serialList.clear()
                    viewModel.serialList.addAll(it)
                    count = viewModel.serialList.size
                    binding.tvSerialValue.text = String.format("%d/%s",count, viewModel.currentScanQty)
                    binding.tvView.visibility = if (count > 0) View.VISIBLE else View.GONE
                },
                onDismissDialog ={
                    enableSerialField(count < (viewModel.currentScanQty ?: 0))
                }
            )
        }
    }

    private fun enableSerialField(isEnable: Boolean) {
        binding.etSerialNumber.isEnabled = isEnable
        binding.etSerialNumber.isFocusable = isEnable
        binding.etSerialNumber.isFocusableInTouchMode = isEnable
        binding.etSerialNumber.alpha = if (isEnable) 1f else 0.35f
        if(isEnable){
            binding.etSerialNumber.post { binding.etSerialNumber.requestFocus() }
        }
    }

    private fun updateDataOnScreen() {
        binding.countType.text = sharedPreferencesBase.getString(PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, "")
        binding.location.text = taskData.locationBarCode
        binding.tvItemBarcodeValue.text = viewModel.selectedItem
        binding.tvSerialValue.text = String.format("%d/%s",viewModel.serialList.size, viewModel.currentScanQty)
    }

    private fun handleEnterKeyEvent() {
        binding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                validateSerialNumber()
            }else{
                if (viewModel.serialList.size == viewModel.currentScanQty){
                    navigateBackToItemScan()
                }else{
                    hideSoftKeyBoard(fragmentContext,binding.rootLayout)
                    showErrorSnackBar(getString(R.string.please_scan_all_serials))
                }
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                            validateSerialNumber()
                        }else{
                            if (viewModel.serialList.size == viewModel.currentScanQty){
                                navigateBackToItemScan()
                            }else{
                                showErrorSnackBar(getString(R.string.please_scan_all_serials))
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateSerialNumber() {
        FlareLog.i(TAG, "SerialNo field focused")
        hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
        val serialNumber = binding.etSerialNumber.text.toString().trim()
        if (!viewModel.serialList.contains(serialNumber)) {
            val isOutBoundOnly = viewModel.selectedItemDetails?.tracking?.serialNumberRequired == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY
            viewModel.validateSerialNumberOrItemCode(viewModel.selectedItemDetails?.itemId?:0,serialNumber, isOutBoundOnly)
        }else if(viewModel.serialList.size == viewModel.currentScanQty){
            displayErrorMessage(getString(R.string.cannot_scan_more))
        }
        else {
            displayErrorMessage(resources.getString(R.string.duplicate_serial))
        }
    }

    private fun subscribeSerialValidationObserver() {
        viewModel.serialItemIdValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialValidationResponse ->
                        FlareLog.i(TAG, "serialValidation Response: $serialValidationResponse")
                        if (serialValidationResponse.success) {
                            FlareLog.i(TAG, "serialValidation Success: $serialValidationResponse")
                            if (!viewModel.serialList.contains(binding.etSerialNumber.text.toString().trim())) {
                                viewModel.serialList.add(binding.etSerialNumber.text.toString().trim())
                                binding.tvView.visibility = if (viewModel.serialList.size > 0) View.VISIBLE else View.GONE
                                binding.etSerialNumber.text = null
                                binding.errResponse.text = null
                                binding.tvSerialValue.text = String.format("%d/%s",viewModel.serialList.size,viewModel.currentScanQty)
                                if (viewModel.serialList.size == viewModel.currentScanQty) {
                                    enableSerialField(false)
                                    viewModel.itemDetails[viewModel.itemDetails.indexOfFirst { it.itemBarCode == viewModel.selectedItemDetails?.itemId }].apply {
                                        serialNumber.clear()
                                        serialNumber.addAll(viewModel.serialList)
                                    }
                                    navigateBackToItemScan()
                                }
                            } else {
                                displayErrorMessage(resources.getString(R.string.duplicate_serial))
                            }
                        } else {
                            displayErrorMessage(resources.getString(R.string.invalid_serial))
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        displayErrorMessage(message)
                    }
                }
            }
        }
    }

    private fun navigateBackToItemScan() {
        val action = ScanSerialFragmentDirections.actionScanSerialFragmentToScanItemFragment()
        getNavigationController().navigate(action)
    }
    private fun displayErrorMessage(errorMessage: String) {
        binding.errResponse.text = errorMessage
        binding.etSerialNumber.requestFocus()
        binding.etSerialNumber.selectAll()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etSerialNumber.setText(scan?.barcode.toString())
        binding.etSerialNumber.text?.length?.let {
            binding.etSerialNumber.setSelection(it)
        }
        FlareLog.i(TAG, "ScanLocation field focused")
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        validateSerialNumber()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}