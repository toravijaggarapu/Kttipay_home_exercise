package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.repository.ReplenishDeliveryRepository
import com.fsc.flare.utils.getErrorCodeAndMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReplenishmentDeliveryPalletViewModel @Inject constructor(
    private val repository: ReplenishDeliveryRepository
) : BaseViewModel() {

    private val _screenState = MutableStateFlow<ReplenishmentDeliveryPalletState?>(null)
    val screenState = _screenState.asStateFlow()

    fun getTaskForScannedContainer(
        scope: CoroutineScope = viewModelScope,
        containerNumber: String
    ) {
        scope.launch {
            _screenState.emit(ReplenishmentDeliveryPalletState.ShowLoading)
            val response = repository.getReplenishTaskForContainer(containerNumber)
            _screenState.emit(ReplenishmentDeliveryPalletState.HideLoading)
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { taskResponse ->
                taskResponse.taskDetails?.let { task ->
                    _screenState.emit(ReplenishmentDeliveryPalletState.TaskFetchSuccess(task))
                } ?: _screenState.emit(ReplenishmentDeliveryPalletState.Error())
            } ?: run {
                val errorPair = response.getErrorCodeAndMessage()
                _screenState.emit(ReplenishmentDeliveryPalletState.Error(errorPair.second))
            }
        }
    }

    fun clearScreenState() {
        _screenState.value = null
    }
}

sealed class ReplenishmentDeliveryPalletState {
    data object ShowLoading : ReplenishmentDeliveryPalletState()
    data object HideLoading : ReplenishmentDeliveryPalletState()
    data class TaskFetchSuccess(val task: ReplenishDeliveryTask) : ReplenishmentDeliveryPalletState()
    data class Error(val message: String? = null) : ReplenishmentDeliveryPalletState()
}