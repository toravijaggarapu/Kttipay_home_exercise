package com.fsc.flare.ui.fragment.pickingforward

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBuildCartToteBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipBuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "BuildCartToteFragment"
const val IN_VALID_TOTE_OR_CART = "IN_VALID_TOTE_OR_CART"
const val NO_TASKS_FOR_CARTNUM ="NO_TASKS_FOR_CARTNUM"

@AndroidEntryPoint
class BuildCartToteFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentBuildCartToteBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBuildCartToteBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPickingBuildCart.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpUI()
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Tote field focused")
                    validateToteNumber()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val data = viewModel.getPickTask()
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
        binding.endCart.setOnClickListener {
            binding.endCart.isEnabled = false
            FlareLog.i(TAG, "Endcart clicked")
            viewModel.pickEndCart(
                    EndPickCartReq(
                            allocationType = data?.taskDetails?.allocationType?.toIntOrNull() ?: -1,
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            pickCartNbr = binding.cart.text.toString(),
                            cartId = data?.cartId,
                            isLTLcubing = viewModel.isLTLCubingEnabled
                    )
            )
        }
        binding.skipCart.setOnClickListener {
            FlareLog.i(TAG, "Skipcart clicked")
            binding.tote.setText("")
            if (data != null) {
                val allocationType = when {
                    viewModel.isRTV -> {
                        sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "") ?: ""
                    }
                    else -> {
                        sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "") ?: ""
                    }
                }
                viewModel.buildSkipCart(
                        SkipBuildCartReq(
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                binding.cart.text.toString(),
                                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                                allocationType,
                                skipTaskId = binding.taskId.text.toString(),
                                skipTaskDetId = "",
                                isLTLcubing = viewModel.isLTLCubingEnabled,
                                orderType = viewModel.orderType
                        )
                )
            }
        }
        binding.tote.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Tote field focused")
                validateToteNumber()
            }
            false
        }
        binding.tote.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.toteResponse.text = null
            }
        })

    }

    private fun setUpUI() {
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                binding.taskPriority.text = taskData.priority
                binding.taskId.text = taskData.taskId.toString()
                binding.carton.text = if (taskData.cartonNumber != null) taskData.cartonNumber else taskData.containerNbr
                if (taskData.cartonSize != null) {
                    binding.cartonSizeVal.text = taskData.cartonSize
                }
                if (!taskData.toteNumber.isNullOrEmpty() && taskData.taskWaveType == "C") {
                    binding.tvToteNumberValue.text = taskData.toteNumber
                    binding.tvToteNumberValue.visibility = View.VISIBLE
                    binding.tvToteNumberLabel.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun validateToteNumber() {
        val toteNumber = binding.tote.text.toString().trim()
        if (toteNumber.isNotEmpty()) {
            val data = viewModel.getPickTaskDetails()
            hideSoftKeyBoard(fragmentContext, binding.tote)
            val containerType = viewModel.validateContainerType(sharedPreferences, "Tote")
            if (containerType != null && (!toteNumber.startsWith(containerType.ctyId!!) || toteNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.toteResponse.text =
                    getString(R.string.tote_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else if (data!!.taskWaveType == "C" && !data.toteNumber.isNullOrEmpty()) {
                when {
                    data.toteNumber.isNullOrEmpty() -> {
                        binding.toteResponse.text = getString(R.string.invalid_wave_type)
                    }
                    toteNumber == data.toteNumber -> {
                        navigateToSlot()
                    }
                    else -> {
                        binding.toteResponse.text = getString(R.string.tote_is_invalid)
                    }
                }
            } else {
                viewModel.validateTote(
                    ValidateToteReq(
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        cartNumber = binding.cart.text.toString(),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        toteNumber = toteNumber
                    )
                )
            }
        } else {
            binding.toteResponse.text = getString(R.string.tote_required)
        }
    }

    private fun navigateToSlot() {
        sharedPreferences.edit().putString(PreferenceKeys.PICKING_TOTE_NBR, binding.tote.text.toString().trim()).apply()
        binding.tote.text = null
        val action = BuildCartToteFragmentDirections.actionBuildCartToteFragmentToBuildCartSlotFragment()
        getNavigationController().navigate(action)
    }

    private fun subscribeObservers() {
        viewModel.validateToteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateToteRes ->
                        if (validateToteRes.success != null && validateToteRes.success) {
                            FlareLog.i(TAG, "validateTote success: $validateToteRes")
                            if (validateToteRes.messageCode != null && validateToteRes.messageCode == IN_VALID_TOTE_OR_CART) {
                                binding.toteResponse.text = validateToteRes.message
                            } else {
                                navigateToSlot()
                            }
                        } else {
                            FlareLog.e(TAG, "validateTote error: ${validateToteRes.message}")
                            binding.toteResponse.text = validateToteRes.message
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "validateTote error: $message")
                        binding.toteResponse.text = message
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.endPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endCartResponse ->
                        FlareLog.i(TAG, "endCart Response: $endCartResponse")
                        if (endCartResponse.success != null && endCartResponse.success) {
                            FlareLog.i(TAG, "endCart success: $endCartResponse")
                            if (endCartResponse.taskDetails != null) {
                                viewModel.updateOrderType(endCartResponse.orderType)
                                viewModel.setPickTaskDetails(endCartResponse.taskDetails)
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartToteFragmentDirections.actionBuildCartToteFragmentToPickCartLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else if (endCartResponse.promptStage != null && endCartResponse.promptStage) {
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartToteFragmentDirections.actionBuildCartToteFragmentToPickingStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickingStagingLocationFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else {
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartToteFragmentDirections.actionBuildCartToteFragmentToBuildCartTaskGroup()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                navController.navigate(action, navOptions)
                            }
                        }else{
                            binding.endCart.isEnabled = true
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.endCart.isEnabled = true
                        FlareLog.e(TAG, "endCart error: $message")
                        showErrorSnackBar(message)
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == NO_TASKS_FOR_CARTNUM) {
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action = BuildCartToteFragmentDirections.actionBuildCartToteFragmentToBuildCartTaskGroup()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                    navController.navigate(action, navOptions)
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                setUpUI()
                            } else {
                                skipCartResponse.message?.let { showErrorSnackBar(it) }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.tote.setText(scan?.barcode.toString())
            binding.tote.text?.length?.let {
                binding.tote.setSelection(it)
            }
            FlareLog.i(TAG, "Tote field focused")
            validateToteNumber()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}