package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutLockCodesBinding
import dagger.hilt.android.AndroidEntryPoint


private const val TAG = "PackoutLockCodeFragment"

@AndroidEntryPoint
class PackoutLockCodeFragment : BaseFragment() {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutLockCodesBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutLockCodesBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        setUpData()
        return binding.root
    }

    fun setUpData() {
        binding.tvDockDoorValue.text = viewModel.getLocationBarcode()
        if (viewModel.getPalletReqNumber() == "") {
            binding.tvPallet.visibility = View.GONE
        } else {
            binding.tvPalletValue.text = viewModel.getPalletReqNumber()
        }
        binding.tvCartonValue.text = viewModel.getcartonReqNumber()
        binding.itemCode.text = viewModel.getitemData()
        binding.tvDescValue.text = viewModel.getItemDesc()
        binding.tvInvTypeValue.text =
            viewModel.getInventoryType()?.let { getInventoryDescription(it) }

        if (viewModel.lotNumberSelectedFromDeKitting) {
            binding.tvLotNumber.visibility = View.VISIBLE
            binding.tvLotValue.visibility = View.VISIBLE
            binding.tvLotValue.text = viewModel.getlotNumber()
        } else {
            showLotNumberValue()
        }

        binding.btnEndPackout.isEnabled = false
    }

    private fun showLotNumberValue() {
        if (!viewModel.getLocationData().locations.isNullOrEmpty()) {

            val taskDetails =
                viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
            val tracking = taskDetails.tracking

            if (tracking.lotRequired == 1 && !taskDetails.lotNumber.isNullOrEmpty()) {
                binding.tvLotNumber.visibility = View.VISIBLE
                binding.tvLotValue.visibility = View.VISIBLE
                binding.tvLotValue.text = taskDetails.lotNumber
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    fun setupListeners() {
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
            Log.d("debug", "BackButton Clicked")
            navigateToBack()
        }

        val damagedLockCodesList = ArrayList<String>(getLockCodesHashMap().values.filter { value:String -> (value.contains("Damaged")) })
        val lockCodesList = ArrayList<String>(damagedLockCodesList)
        lockCodesList.add(NO_LOCK)
        binding.lockCodeSpinner.setOptions(lockCodesList)
        binding.lockCodeSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            validateField()
        }
    }

    val NO_LOCK = "NO LOCK"

    fun navigateToBack() {
        findNavController().popBackStack()
    }

    private fun validateField() {
        binding.lockCodeSelectionError.text = ""
        if (binding.lockCodeSpinner.text == getString(R.string.select_lock_code)) {
            binding.lockCodeSelectionError.text = getString(R.string.select_lock_code)
        } else {

            var lockCodeDes = binding.lockCodeSpinner.text
            if(lockCodeDes == NO_LOCK){
                viewModel.lockCodeSelected = ""
                navigateToQtyFrag()
            }
            else {
                val selectedHashMap =
                    getLockCodesHashMap().filter { (key, value) -> value == lockCodeDes }
                viewModel.lockCodeSelected = (selectedHashMap.keys.first())

                if (!viewModel.containerLockCode.isNullOrEmpty() && viewModel.containerLockCode != viewModel.lockCodeSelected) {
                    showAlertDialog("", getString(R.string.mixed_inv_not_allowed)) {}
                } else {
                    navigateToQtyFrag()
                }
            }
        }
    }

    fun navigateToQtyFrag(){
        val action =
            PackoutLockCodeFragmentDirections.actionPackoutLockCodeFragmentToPackoutQuantityFragement()
        moveToFragment(action)
    }
}