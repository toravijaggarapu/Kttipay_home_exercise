package com.fsc.flare.source.data.dto

data class ForwardErrorResponse(
    val errors: Errors,
    val requestIdentifier: String,
    val success: Boolean,
    val transactionDate: String,
    val message: String? = null
)