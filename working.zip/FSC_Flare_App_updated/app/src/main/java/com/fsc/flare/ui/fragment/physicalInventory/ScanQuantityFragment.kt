package com.fsc.flare.ui.fragment.physicalInventory

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.OnBackPressedCallback
import androidx.annotation.RequiresApi
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanQuantityBinding
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.source.data.dto.physicalInventory.ItemDetail
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ScanQuantityFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentScanQuantityBinding
    private lateinit var taskData: BatchTaskDetailsResp
    private var itemsList: List<Int> = listOf()
    private var currentScannedItemId: Int? = null
    private lateinit var callback: OnBackPressedCallback

    override fun onAttach(context: Context) {
        super.onAttach(context)
        callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewModel.scannedItemListIds.contains(viewModel.selectedItemDetails?.itemId)) {
                    viewModel.scannedItemListIds.remove(viewModel.selectedItemDetails?.itemId)
                }
                requireActivity().supportFragmentManager.popBackStack()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentScanQuantityBinding.inflate(inflater, container, false)
        taskData = viewModel.batchTaskDetailsResp!!
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType.plus( " - " ).plus(taskData.batchNumber)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDataOnScreen()
        handleTouchEvent()
        handleEnterKeyEvent()
    }

    private fun updateDataOnScreen() {
        binding.countType.text =
            sharedPreferencesBase.getString(PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, "")
        binding.location.text = taskData.locationBarCode
        binding.itemBarcode.text = viewModel.selectedItem
    }

    private fun handleEnterKeyEvent() {
        binding.qty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateCount()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.qty.isFocused && !binding.qty.text.isNullOrEmpty()) {
                            validateCount()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateCount() {
        currentScannedItemId = viewModel.scannedItemListIds.last()
        itemsList = taskData.itemDetails?.map { it.itemBarCode} ?: emptyList()
        if (itemsList.contains(currentScannedItemId)) {
            val taskItemDetails = taskData.itemDetails?.filter { it.itemBarCode == currentScannedItemId }
            if(binding.qty.text.toString() != taskItemDetails?.get(0)?.qty.toString() && !viewModel.isGivingCountSecondTime ){
                showQuantityMismatchConfirmDialog()
            }else{
                navigateToNextScreen()
            }
        } else {
            navigateToNextScreen()
        }
    }

    private fun navigateToNextScreen() {
        val itemDetail = ItemDetail(
            containerId = viewModel.isActiveLocationEmpty.takeIf { !it }?.let { taskData.itemDetails?.getOrNull(0)?.containerId },
            itemBarCode = currentScannedItemId ?: 0,
            lotNumber = viewModel.scannedLotNumber,
            qty = binding.qty.text.toString().toLong(),
            uom = "EA"
        )
        viewModel.itemDetails.removeIf { it.itemBarCode == currentScannedItemId }
        viewModel.itemDetails.add(itemDetail)
        viewModel.currentScanQty = binding.qty.text.toString().toInt()
        if(viewModel.selectedItemDetails?.tracking?.serialNumberRequired == Constants.ApplicationConstants.SERIAL_TRACK_FULL_TRACKING){
            val action = ScanQuantityFragmentDirections.actionScanQuantityFragmentToScanSerialFragment()
            getNavigationController().navigate(action)
        }else{
            val action = ScanQuantityFragmentDirections.actionScanQuantityFragmentToScanItemFragment()
            getNavigationController().navigate(action)
        }
    }

    private fun showQuantityMismatchConfirmDialog() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(getString(R.string.counted_qty_not_match_with_system_qty))
        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialog, _ ->
            viewModel.isGivingCountSecondTime = true
            binding.qty.text = null
            dialog.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onDetach() {
        super.onDetach()
        callback.remove()
    }

}