package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.data.dto.replenishment.getReplenishDeliveryTask
import com.fsc.flare.source.repository.ReplenishDeliveryRepository
import com.fsc.flare.utils.getErrorCodeAndMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReplenishmentDeliveryLocationViewModel @Inject constructor(
    private val repository: ReplenishDeliveryRepository
) : BaseViewModel() {

    private val _screenState = MutableStateFlow<ReplenishmentDeliveryLocationState?>(null)
    val screenState = _screenState.asStateFlow()

    fun completeTask(
        scope: CoroutineScope = viewModelScope,
        taskId: Int,
        containerNumber: String,
        destinationLocation: String,
    ) {
        scope.launch {
            _screenState.emit(ReplenishmentDeliveryLocationState.ShowProgress)
            val response = repository.completeReplenishTask(
                taskId = taskId,
                containerNumber = containerNumber,
                destinationLoc = destinationLocation
            )
            _screenState.emit(ReplenishmentDeliveryLocationState.HideProgress)
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { taskResponse ->
                if (taskResponse.success) {
                    _screenState.emit(
                        ReplenishmentDeliveryLocationState.SuccessWithNextTask(taskResponse.taskDetails?.getReplenishDeliveryTask())

                    )
                } else {
                    _screenState.emit(ReplenishmentDeliveryLocationState.Error(taskResponse.message))
                }
            } ?: run {
                val errorPair = response.getErrorCodeAndMessage()
                _screenState.emit(ReplenishmentDeliveryLocationState.Error(errorPair.second))
            }
        }
    }

    fun clearScreenState() {
        _screenState.value = null
    }
}

sealed class ReplenishmentDeliveryLocationState {
    data object ShowProgress : ReplenishmentDeliveryLocationState()
    data object HideProgress : ReplenishmentDeliveryLocationState()
    data class Error(val message: String? = null) : ReplenishmentDeliveryLocationState()
    data class SuccessWithNextTask(val task: ReplenishDeliveryTask?) : ReplenishmentDeliveryLocationState()
}