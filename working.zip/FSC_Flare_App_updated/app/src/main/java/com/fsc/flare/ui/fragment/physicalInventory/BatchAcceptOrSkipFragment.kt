package com.fsc.flare.ui.fragment.physicalInventory


import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBatchAcceptOrSkipBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.physicalInventory.BatchSummaryResp
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "BatchAcceptOrSkipFragment"

@AndroidEntryPoint
class BatchAcceptOrSkipFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentBatchAcceptOrSkipBinding
    private lateinit var batchSummaryData: BatchSummaryResp

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBatchAcceptOrSkipBinding.inflate(inflater, container, false)
        binding.tvPhysicalInventory.text = viewModel.batchSummaryResp?.countType ?: ""
        viewModel.isActiveLocationEmpty = false
        subscribeBatchTaskDetailsObserver()
        subscribeBatchSummaryObserver()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        batchSummaryData = viewModel.batchSummaryResp!!
        updateBatchSummaryDataOnScreen()
        handleAcceptButtonClick()
        handleSkipButtonClick()
        handleBatchSearchIcon()  // Will work as separate NFR, currently the code is implemented in RF
        handleTouchEvent()
        handleEnterKeyEvent()
    }

    private fun handleEnterKeyEvent() {
        binding.batchSearch.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                if(binding.batchSearch.text.isNullOrEmpty()){
                    binding.searchIcon.visibility = View.VISIBLE
                    binding.batchNumber.visibility = View.VISIBLE
                    binding.batchSearch.visibility = View.INVISIBLE
                    handleFieldsVisibility(true)
                }else{
                    viewModel.getBatchSummary(binding.batchSearch.text.toString().trim(),null, sharedPreferencesBase.getString(
                        PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
                    ))
                }
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.batchSearch.isFocused) {
                            if (binding.batchSearch.text.isNullOrEmpty()) {
                                binding.searchIcon.visibility = View.VISIBLE
                                binding.batchNumber.visibility = View.VISIBLE
                                binding.batchSearch.visibility = View.INVISIBLE
                                handleFieldsVisibility(true)
                            } else {
                                viewModel.getBatchSummary(
                                    binding.batchSearch.text.toString().trim(),null,
                                    sharedPreferencesBase.getString(
                                        PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
                                    )
                                )
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun handleBatchSearchIcon() {
        binding.searchIcon.setOnClickListener(){
            binding.searchIcon.visibility = View.INVISIBLE
            binding.batchNumber.visibility = View.INVISIBLE
            binding.batchSearch.visibility = View.VISIBLE
            binding.batchSearch.requestFocus()
            handleFieldsVisibility(false)
        }
    }

    private fun handleFieldsVisibility(isVisible: Boolean){
        if(isVisible){
            binding.noOfLocationsTv.visibility = View.VISIBLE
            binding.noOfLocations.visibility = View.VISIBLE
            binding.locationClassTv.visibility = View.VISIBLE
            binding.locationClass.visibility = View.VISIBLE
            binding.ZoneDescTv.visibility = View.VISIBLE
            binding.ZoneDesc.visibility = View.VISIBLE
            binding.skipTask.visibility = View.VISIBLE
            binding.acceptTask.visibility = View.VISIBLE
        }else{
            binding.noOfLocationsTv.visibility = View.INVISIBLE
            binding.noOfLocations.visibility = View.INVISIBLE
            binding.locationClassTv.visibility = View.INVISIBLE
            binding.locationClass.visibility = View.INVISIBLE
            binding.ZoneDescTv.visibility = View.INVISIBLE
            binding.ZoneDesc.visibility = View.INVISIBLE
            binding.skipTask.visibility = View.INVISIBLE
            binding.acceptTask.visibility = View.INVISIBLE
        }

    }

    private fun handleSkipButtonClick() {
        binding.skipTask.setOnClickListener {
            viewModel.getBatchSummary(null, batchSummaryData.batchNumber, batchSummaryData.countType)
        }
    }

    private fun handleAcceptButtonClick() {
        binding.acceptTask.setOnClickListener {
            viewModel.getBatchTaskDetails()
        }
    }

    private fun subscribeBatchTaskDetailsObserver() {
        viewModel.batchTaskDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchTaskDetailsResp ->
                        FlareLog.i(TAG, "batchTaskDetails success: $batchTaskDetailsResp")
                        if(batchTaskDetailsResp.success){
                            if(batchTaskDetailsResp.itemDetails.isNullOrEmpty()){
                                viewModel.isActiveLocationEmpty = true
                            }
                            val action = BatchAcceptOrSkipFragmentDirections.actionBatchAcceptOrSkipFragmentToScanLocationFragment()
                            getNavigationController().navigate(action)
                        }else{
                            showErrorSnackBar(batchTaskDetailsResp.message)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchTaskDetails Error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                showErrorSnackBar(msgArray[1])
                            }
                        } else {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchSummaryObserver() {
        viewModel.batchSummaryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchSummaryResp ->
                        FlareLog.i(TAG, "batchSummary success: $batchSummaryResp")
                        if(batchSummaryResp.success){
                            viewModel.batchSummaryResp = batchSummaryResp
                            batchSummaryData = viewModel.batchSummaryResp!!
                            binding.searchIcon.visibility = View.VISIBLE
                            binding.batchNumber.visibility = View.VISIBLE
                            binding.batchSearch.visibility = View.INVISIBLE
                            binding.batchSearch.text = null
                            handleFieldsVisibility(true)
                            updateBatchSummaryDataOnScreen()
                        }else{
                            hideSoftKeyBoard(fragmentContext,binding.rootLayout)
                            binding.batchSearch.selectAll()
                            showErrorSnackBar(batchSummaryResp.message)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchSummary Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun updateBatchSummaryDataOnScreen() {
        binding.countType.text = batchSummaryData.countType
        binding.batchNumber.text = batchSummaryData.batchNumber
        binding.noOfLocations.text = batchSummaryData.noOfLocations.toString()
        binding.locationClass.text = getLocationClass(batchSummaryData.locationClass)
        binding.ZoneDesc.text = batchSummaryData.zoneDescription
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

}