package com.fsc.flare.ui.fragment.pickingforward.pickfromcasepick

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.content.ContextCompat
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogBlindCartonBinding
import com.fsc.flare.databinding.FragmentPickCartContainerBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable

import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.CartonInfo
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.ui.fragment.kitting.ListDialogFragment
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_FULL_TRACKING
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_OUTBOUND_ONLY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder

import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "PickCartContainerFragment"
private const val TRANS_KEY_SHORT_PICK = "SHORTPICK"
private const val PICK_FROM_CASE_PICK = "20"
private const val PICK_FROM_CASE_PICK_KITTING = "21"

@AndroidEntryPoint
class PickCartContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()

    lateinit var binding: FragmentPickCartContainerBinding
    private lateinit var blindCartonBinding: DialogBlindCartonBinding
    private lateinit var blindCartonDialog: Dialog
    lateinit var cb1: CustomVisibilityCallback
    private var totalSerialNumberCount = 0
    var allocationType = ""
    private var overrideCartonResponse: CartonInfo? = null


    override fun onResume() {
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentPickCartContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeUI()
        setUpEventListeners()
    }

    private fun initializeUI() {
        allocationType = sharedPreferences.getString(
            PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, ""
        ).toString()
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                totalSerialNumberCount = taskData.ibContainerQty
                binding.taskId.text = taskData.taskId.toString()
                binding.item.text = taskData.itemCode
                binding.description.text = taskData.itemDescription
                binding.pickLocation.text = taskData.locationBarcode
                binding.pickQty.text = String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
            }
        }
        binding.skipCart.visibility = View.GONE
        binding.shortPickCart.visibility = View.GONE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setUpEventListeners() {
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Container field focused")
                validateContainer()
            }
            false
        }

        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (overrideCartonResponse != null && overrideCartonResponse!!.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {

                    canEnableBlindCartonButton(viewModel.scannedSerialNumbers.size == totalSerialNumberCount)
                } else {
                    canEnableBlindCartonButton(s.isEmpty())
                }
                binding.etContainerRes.text = null
            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Container field focused")
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.shortPickCart.setOnClickListener {
            if (data != null) {
                if (taskData != null) {
                    showShortPickActionAlert()
                }
            }
        }

        binding.btnPickBlindCarton.setOnClickListener {
            if (taskData != null && (taskData.itemSerialTracked == "0" || viewModel.scannedSerialNumbers.isNotEmpty())) {
                showBlindCartonDialog()
            } else {
                binding.etContainerRes.text =
                    getString(R.string.item_is_serially_tracked_please_scan_serial_number)
            }
        }

        binding.tvSerialCount.setOnClickListener {
            displaySerialNumberView(viewModel.scannedSerialNumbers)
        }
    }

    private fun canEnableBlindCartonButton(canEnable: Boolean) {
        with(binding.btnPickBlindCarton) {
            isEnabled = canEnable
        }
    }

    private fun showBlindCartonDialog() {
        blindCartonBinding = DialogBlindCartonBinding.inflate(LayoutInflater.from(context))
        blindCartonDialog = Dialog(fragmentContext)
        with(blindCartonDialog) {
            setContentView(blindCartonBinding.root)
            setCancelable(false)
            show()
            val lp = WindowManager.LayoutParams()
            lp.copyFrom(window!!.attributes)
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            window!!.attributes = lp
        }

        with(blindCartonBinding) {
            etBlindContainer.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(charSeq: Editable) {

                }

                override fun beforeTextChanged(
                    charSeq: CharSequence, start: Int, count: Int, after: Int
                ) {

                }

                override fun onTextChanged(
                    charSeq: CharSequence, start: Int, before: Int, count: Int
                ) {
                    btnOk.isEnabled = charSeq.isNotEmpty()
                    etBlindContainerRes.text = null
                }
            })

            etBlindContainer.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    btnOk.performClick()
                }
                false
            }

            btnOk.setOnClickListener {
                if (!etBlindContainer.text.isNullOrEmpty()) {
                    val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
                    val containerNumber = etBlindContainer.text.toString()
                    if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                        etBlindContainerRes.text = getString(
                            R.string.container_prefix_length_validation,
                            containerType.ctyId,
                            containerType.ctyContainerLength
                        )
                    } else {
                        btnOk.isEnabled = false
                        viewModel.getContainer(
                            etBlindContainer.text.toString().trim(), "Y"
                        )
                    }
                }
            }
            btnCancel.setOnClickListener {
                blindCartonDialog.dismiss()
            }
            btnCancel.setOnClickListener {
                blindCartonDialog.dismiss()
            }
        }
    }

    /**
     * method to get transaction param info from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = TRANS_KEY_SHORT_PICK
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.transactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(
                                TAG, "TransactionParamResponse success: $transactionParamResponse"
                            )
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transVal == viewModel.rpcTransEnabledKey) {
                                    binding.shortPickCart.visibility = View.VISIBLE
                                } else {
                                    binding.shortPickCart.visibility = View.GONE
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun callShortPickAPI(
        data: TaskPickResponse, taskData: TaskDetails, reasonCode: String
    ) {
        val taskCasePicReq = TaskCasePickCompleteReq(
            allocationType = allocationType,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            cartNumber = data.cartNbr,
            cartId = data.cartId,
            containerId = taskData.containerId,
            containerNumber = taskData.containerNbr,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            itemCode = taskData.itemCode,
            itemDescription = taskData.itemDescription,
            itemId = taskData.itemId,
            pickQty = taskData.taskQty,
            pickQtyUom = taskData.taskQtyUom,
            taskDetId = taskData.taskDetId,
            taskId = taskData.taskId,
            lotNumber = taskData.lotNumber,
            expDate = taskData.expDate,
            orderType = viewModel.orderType
        )
        if (reasonCode.isNotEmpty()) {
            taskCasePicReq.pickQty = 0
            taskCasePicReq.reasonCode = reasonCode
        }
        viewModel.taskcasepickcomplete(taskCasePicReq)
    }

    private fun validateContainer() {
        val containerNbr = binding.etContainer.text.toString().trim()
        if (containerNbr.isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etContainer)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (containerNbr == taskData.containerNbr) {
                    binding.etContainer.text?.clear()
                    moveCartFragment()
                } else {
                    if ((allocationType == PICK_FROM_CASE_PICK || allocationType == PICK_FROM_CASE_PICK_KITTING) &&
                        overrideCartonResponse?.containerNbr == taskData.containerNbr &&
                        overrideCartonResponse?.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {
                        if (!viewModel.scannedSerialNumbers.contains(containerNbr)) {
                            val allSerialScanned =
                                viewModel.scannedSerialNumbers.size == totalSerialNumberCount
                            if (allSerialScanned) {
                                displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
                                binding.etContainer.isEnabled = false
                            } else {
                                viewModel.validateSerialNumberOrItemCodeContainer(
                                    containerNbr,
                                    true,
                                    taskData.pullLocationId,
                                    taskData.itemId,
                                    overrideCartonResponse!!.containerId
                                )
                            }
                        } else {
                            displayErrorMessage(getString(R.string.duplicate_serial))
                        }
                    } else {
                        callContainerOverrideAPI()
                    }
                }
            }
        }
    }

    private fun callContainerOverrideAPI() {
        viewModel.validateContainerOverride(
            ValidateCaseOverrideRequest(
                givenContainerNbr = binding.etContainer.text.toString().trim(),
                taskDetId = viewModel.getPickTaskDetails()?.taskDetId,
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            )
        )
    }

    private fun subscribeObservers() {
        subscribeTransactionParamObserver()
        callTransactionParamAPI()
        subscribeTaskCasePickCompleteObserver()
        subscribeContainerObserver()
        subscribeContainerOverrideObserver()
        subscribeSerialValidationObserver()
    }

    private fun subscribeTaskCasePickCompleteObserver() {
        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskCasePickCompleteRes ->
                        handleTaskCasePickCompleteResponse(taskCasePickCompleteRes)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        handleTaskCasePickCompleteErrorResponse(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleTaskCasePickCompleteResponse(taskCasePickCompleteRes: TaskCasePickCompleteRes) {
        if (taskCasePickCompleteRes.success != null && taskCasePickCompleteRes.success) {
            FlareLog.i(TAG, "taskCasePickComplete success: $taskCasePickCompleteRes")
            binding.etContainer.text?.clear()
            if (taskCasePickCompleteRes.taskDetails != null) {
                viewModel.updateOrderType(taskCasePickCompleteRes.orderType)
                viewModel.setPickTaskDetails(taskCasePickCompleteRes.taskDetails)
                showSuccessSnackBarStd(getString(R.string.short_picked_continue_picking)) {
                    val action =
                        PickCartContainerFragmentDirections.actionPickCartContainerFragmentToPickCartPickLocationFragment()
                    val navOptions =
                        NavOptions.Builder().setPopUpTo(R.id.pickCartPickLocationFragment, true)
                            .build()
                    getNavigationController().navigate(action, navOptions)
                }
            } else {
                // implement when task details is null
                if (taskCasePickCompleteRes.eligibleToStage == null || taskCasePickCompleteRes.eligibleToStage) {
                    taskCasePickCompleteRes.message?.let {
                        showSuccessSnackBarStd(it) {
                            val action =
                                PickCartContainerFragmentDirections.actionPickCartContainerFragmentToPickCartStagingLocFragment()
                            val navOptions = NavOptions.Builder()
                                .setPopUpTo(R.id.pickCartStagingLocFragment, true).build()
                            getNavigationController().navigate(action, navOptions)
                        }
                    }
                } else {
                    showAlertDialog(
                        "", getString(R.string.pick_cart_cancelled_case_pick_stage_alert_message)
                    ) {
                        val action =
                            PickCartContainerFragmentDirections.actionPickCartContainerFragmentToBuildCartTaskGroup()
                        val navOptions =
                            NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                        getNavigationController().navigate(action, navOptions)
                    }
                }
            }
        }
    }

    private fun handleTaskCasePickCompleteErrorResponse(message: String) {
        FlareLog.e(TAG, "taskCasePickComplete error: $message")
        if (message.contains("_")) {
            val msgArray = message.split("_")
            if (msgArray.isNotEmpty()) {
                when {
                    msgArray[0] == LOCATION_IS_EMPTY -> {
                        showAlertDialog("", msgArray[1]) {}
                    }

                    msgArray[0] == TASK_CYCLE_COUNT_PENDING -> {
                        showCycleCountPendingAlert()
                    }

                    else -> {
                        showErrorSnackBar(message)
                    }
                }
            }
        } else {
            showErrorSnackBar(message)
        }
    }

    private fun subscribeContainerObserver() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            with(blindCartonBinding) {
                when (containerInquiryResponse) {
                    is Resource.Success -> {
                        FlareLog.i(TAG, "container success: $containerInquiryResponse")
                        progressBar.visibility = View.GONE
                        containerInquiryResponse.data?.let { containerResponse ->
                            viewModel.givenCartonNbr = null
                            if (containerResponse.success && containerResponse.container.isNotEmpty()) {
                                displayPopUpErrorMessage(getString(R.string.master_pallet_repack_container_exists))
                            } else {
                                btnOk.isEnabled = true
                                blindCartonDialog.dismiss()
                                viewModel.givenCartonNbr = etBlindContainer.text.toString()
                                moveCartFragment()
                            }
                        }
                    }

                    is Resource.Error -> {
                        progressBar.visibility = View.GONE
                        containerInquiryResponse.message?.let { message ->
                            displayPopUpErrorMessage(message)
                            btnOk.isEnabled = false
                        }
                    }

                    is Resource.Loading -> {
                        progressBar.visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    private fun subscribeContainerOverrideObserver() {
        viewModel.validateContainerOverrideResponse.observe(viewLifecycleOwner) { containerOverrideResponse ->
            when (containerOverrideResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerOverrideResponse")
                    hideProgressBar()
                    containerOverrideResponse.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            handleContainerSuccessResponse(containerResponse)
                        } else {
                            displayErrorMessage(getString(R.string.container_not_found))
                        }

                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    containerOverrideResponse.message?.let { message ->
                        displayErrorMessage(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun handleContainerSuccessResponse(overrideResponse: ValidatePalletOverrideResponse) {
        overrideCartonResponse = overrideResponse.cartonInfo
        val containerNumber = binding.etContainer.text.toString().trim()
        if (allocationType == PICK_FROM_CASE_PICK || allocationType == PICK_FROM_CASE_PICK_KITTING) { //Serial number tracking only applicable for casepick from active only
            if (overrideCartonResponse?.scannedSerialType == SERIAL_TRACK_FULL_TRACKING) {
                if (overrideCartonResponse?.serialNumbers?.contains(containerNumber) == true) {
                    viewModel.scannedSerialNumbers = overrideCartonResponse!!.serialNumbers
                    binding.etContainer.text = null
                    displaySuccessMessage(
                        getString(
                            R.string.successfully_scanned_serial_number_and_the_associated_case_id,
                            containerNumber,
                            overrideCartonResponse!!.containerNbr
                        )
                    )
                } else {
                    displayErrorMessage(resources.getString(R.string.serial_doesnot_exist))
                }
            } else if (overrideCartonResponse!!.scannedSerialType == SERIAL_TRACK_OUTBOUND_ONLY) {
                if (!viewModel.scannedSerialNumbers.contains(containerNumber)) {
                    val allSerialScanned = viewModel.scannedSerialNumbers.size == totalSerialNumberCount
                    if (allSerialScanned) {
                        displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
                        binding.etContainer.isEnabled = false
                    } else {
                        val taskData = viewModel.getPickTaskDetails()
                        if (taskData != null) {
                            viewModel.validateSerialNumberOrItemCodeContainer(
                                containerNumber,
                                true,
                                taskData.pullLocationId,
                                taskData.itemId,
                                overrideCartonResponse!!.containerId
                            )
                        }
                    }
                } else {
                    displayErrorMessage(resources.getString(R.string.duplicate_serial))
                }
            } else {
                updateCartonId(overrideCartonResponse!!)
            }
        } else {
            updateCartonId(overrideCartonResponse!!)
        }
    }

    private fun updateCartonId(cartonResponse: CartonInfo) {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            taskData.containerNbr = cartonResponse.containerNbr
            taskData.containerId = cartonResponse.containerId
            // Update the container number and container Id from taskData to user entered one
            viewModel.pickTaskDetails.value = taskData
            moveCartFragment()
        }
        binding.etContainer.text = null
    }

    private fun subscribeSerialValidationObserver() {
        viewModel.serialItemIdValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialOrItemIdValidationResponse ->
                        FlareLog.i(
                            TAG, "serialValidation Response: $serialOrItemIdValidationResponse"
                        )
                        if (serialOrItemIdValidationResponse.success) {
                            if (serialOrItemIdValidationResponse.isSerialNumberValid) {
                                serialNumberUpdate()
                            } else {
                                if (serialOrItemIdValidationResponse.message != null) {
                                    displayErrorMessage(serialOrItemIdValidationResponse.message)
                                } else {
                                    displayErrorMessage(getString(R.string.something_went_wrong_services))
                                }
                            }

                        } else {
                            if (serialOrItemIdValidationResponse.message != null) {
                                displayErrorMessage(serialOrItemIdValidationResponse.message)
                            } else {
                                displayErrorMessage(getString(R.string.something_went_wrong_services))
                            }
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        displayErrorMessage(message)
                    }
                }
            }
        }
    }

    private fun serialNumberUpdate() {
        binding.tvSerialCount.visibility = View.VISIBLE
        viewModel.scannedSerialNumbers.add(binding.etContainer.text.toString().trim())
        binding.tvSerialCount.text = String.format(
            getString(R.string.serial_number_count),
            viewModel.scannedSerialNumbers.size.toString(),
            totalSerialNumberCount.toString()
        )
        binding.etContainer.text = null
        val allSerialScanned = viewModel.scannedSerialNumbers.size == totalSerialNumberCount
        canEnableBlindCartonButton(allSerialScanned)
        if (allSerialScanned) {
            displaySuccessMessage(getString(R.string.all_the_serial_numbers_scanned_successfully))
            binding.etContainer.isEnabled = false
        }
    }

    private fun moveCartFragment() {
        val action =
            PickCartContainerFragmentDirections.actionPickCartContainerFragmentToPickCartCartFragment()
        getNavigationController().navigate(action)
    }

    private fun displayErrorMessage(message: String) {
        FlareLog.e(TAG, "ContainerResponse error: $message")
        binding.etContainerRes.text = message
        binding.etContainerRes.setTextColor(ContextCompat.getColor(requireContext(), R.color.red))
        binding.etContainer.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etContainer)
    }

    private fun displaySuccessMessage(message: String) {
        binding.etContainerRes.text = message
        binding.etContainerRes.setTextColor(ContextCompat.getColor(requireContext(), R.color.green))
    }

    private fun displayPopUpErrorMessage(message: String) {
        with(blindCartonBinding) {
            etBlindContainerRes.text = message
            etBlindContainer.selectAll()
            showSoftKeyBoard(fragmentContext, etBlindContainer)
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showShortPickActionAlert() {
        val taskData = viewModel.getPickTaskDetails()
        val data = viewModel.getPickTask()
        val msg = if (data?.orderType != null && data.orderType.equals(
                Constants.FILL_KILL, ignoreCase = true
            )
        ) {
            getString(R.string.lbl_this_pick_task_belongs_to_a_fill_kill_order_do_you_want_to_continue)
        } else {
            getString(
                R.string.short_pick_for_casepick_alert,
                taskData?.taskQty.toString() + " " + taskData?.taskQtyUom,
                "0 " + taskData?.taskQtyUom
            )
        }
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_yes)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            viewModel.getInventoryReasonCodes()
            showReasonCode()
        }

        builder.setNegativeButton(resources.getString(R.string.alert_button_no)) { dialogInterface, _ ->
            dialogInterface.dismiss()

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showReasonCode() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            callShortPickAPI(viewModel.getPickTask()!!, viewModel.getPickTaskDetails()!!, lockCode)
            dialog.dismiss()
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        if (binding.etContainer.isFocused) {
            binding.etContainer.setText(scan?.barcode.toString())
            binding.etContainer.text?.length?.let {
                binding.etContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Container field focused")
            validateContainer()
        } else if (::blindCartonDialog.isInitialized && blindCartonDialog.isShowing) {
            with(blindCartonBinding) {
                etBlindContainer.setText(scan?.barcode.toString())
                etBlindContainer.text?.length?.let {
                    etBlindContainer.setSelection(it)
                }
            }
            FlareLog.i(TAG, "Blind Container field focused")
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showCycleCountPendingAlert() {
        showAlertDialog("",
            getString(R.string.cycle_count_pending_for_location),
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.getInventoryReasonCodes()
                    showReasonCode()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun displaySerialNumberView(scannedSerialList: List<String>) {
        val dialog = ListDialogFragment(getString(R.string.serial_numbers), scannedSerialList)
        dialog.show(childFragmentManager, "listDialog")
    }
}