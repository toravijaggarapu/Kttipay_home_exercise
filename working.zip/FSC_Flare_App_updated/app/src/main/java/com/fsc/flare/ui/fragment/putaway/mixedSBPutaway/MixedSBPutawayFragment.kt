package com.fsc.flare.ui.fragment.putaway.mixedSBPutaway

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentMixedSBPutawayBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayRequest
import com.fsc.flare.source.data.dto.mixedSBPutaway.PutawayReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "MixedSBPutawayFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [MixedSBPutawayFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class MixedSBPutawayFragment : BaseFragment(), FlareScannable {

    private val viewModel: MixedSBPutAwayViewModel by activityViewModels()
    private lateinit var binding: FragmentMixedSBPutawayBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMixedSBPutawayBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etToCont.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvToContRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etToLoc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvToLocRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etSerialNum.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSerialNumRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etSlp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSlpRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        //Initially only toContainer field needs to be enabled
        enableDisableFields(toContainer = true, toLocation = false, serialNumber = false, slp = false)
        binding.etToCont.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etToCont)
                FlareLog.i(TAG, "ToContainer field focused")
                validateToContainer()
            }
            false
        }

        binding.etToLoc.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etToLoc)
                FlareLog.i(TAG, "ToLocation field focused")
                validateToLocation()
            }
            false
        }

        binding.etSerialNum.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                if (binding.etSerialNum.isFocused && binding.etSerialNum.text.isNullOrEmpty()) {
                    enableDisableFields(toContainer = true, toLocation = true, serialNumber = true, slp = true)
                    binding.etSlp.requestFocus()
                } else {
                    hideSoftKeyBoard(fragmentContext, binding.etSerialNum)
                    FlareLog.i(TAG, "SerialNumber field focused")
                    validateSerialNumber()
                }

            }
            false
        }

        binding.etSlp.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSlp)
                FlareLog.i(TAG, "SLP field focused")
                submitPutaway()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etToCont.isFocused && !binding.etToCont.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "ToContainer field focused")
                        validateToContainer()
                    }
                    if (binding.etToLoc.isFocused && !binding.etToLoc.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "ToLocation field focused")
                        validateToLocation()
                    }
                    if (binding.etSerialNum.isFocused && !binding.etSerialNum.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "SerialNumber field focused")
                        validateSerialNumber()
                    }
                    if (binding.etSerialNum.isFocused && binding.etSerialNum.text.isNullOrEmpty()) {
                        enableDisableFields(toContainer = true, toLocation = true, serialNumber = true, slp = true)
                        binding.etSlp.requestFocus()
                    }
                    if (binding.etSlp.isFocused && !binding.etSlp.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "SLP field focused")
                        submitPutaway()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeToContainerObserver()
        subscribeToLocationObserver()
        subscribeSerialNumberObserver()
        subscribeSubmitPutawayObserver()
    }


    /**
     * method to validate toContainer from API
     */
    private fun validateToContainer() {
        if (binding.etToLoc.length() > 0) {
            binding.etToLoc.text = null
        }

        if (binding.etSerialNum.length() > 0) {
            binding.etSerialNum.text = null
        }

        if (binding.etSlp.length() > 0) {
            binding.etSlp.text = null
        }

        viewModel.validateToContainer(
            MSBPutawayRequest(
                dataSource = "RF",
                mixedSbPutaway = true,
                putaway = PutawayReq(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    destination = binding.etToCont.text.toString(),
                    locId = null,
                    retType = null,
                    serialNum = null,
                    source = null,
                    usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    /**
     * method to subscribe validate toContainer observer
     */
    private fun subscribeToContainerObserver() {
        viewModel.toContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.statusHandler?.statusCode != null) {
                            when (containerResponse.statusHandler.statusCode) {
                                "500" -> {
                                    binding.tvToContRes.text = containerResponse.statusHandler.message
                                    binding.etToCont.requestFocus()
                                    binding.etToCont.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etToCont)
                                }
                                "200" -> {
                                    if (containerResponse.putaway != null) {
                                        if (containerResponse.putaway.locId != null) {
                                            binding.etToLoc.setText(containerResponse.putaway.locId)
                                            binding.etQuantity.setText(containerResponse.putaway.cntQty.toString())
                                            viewModel.setContainerData(containerResponse.putaway)
                                            validateToLocation()
                                        } else {
                                            enableDisableFields(toContainer = true, toLocation = true, serialNumber = false, slp = false)
                                            binding.etToLoc.requestFocus()
                                        }
                                    } else {
                                        enableDisableFields(toContainer = true, toLocation = true, serialNumber = false, slp = false)
                                        binding.etToLoc.requestFocus()
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvToContRes.text = message
                        binding.etToCont.requestFocus()
                        binding.etToCont.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etToCont)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to validate toLocation from API
     */
    private fun validateToLocation() {
        viewModel.validateToLocation(
            MSBPutawayRequest(
                dataSource = "RF",
                mixedSbPutaway = true,
                putaway = PutawayReq(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    destination = null,
                    locId = binding.etToLoc.text.toString(),
                    retType = null,
                    serialNum = null,
                    source = null,
                    usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    /**
     * method to subscribe validate toLocation observer
     */
    private fun subscribeToLocationObserver() {
        viewModel.toLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationResponse ->
                        if (locationResponse.statusHandler?.statusCode != null) {
                            when (locationResponse.statusHandler.statusCode) {
                                "500" -> {
                                    binding.tvToLocRes.text = locationResponse.statusHandler.message
                                    binding.etToLoc.requestFocus()
                                    binding.etToLoc.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etToLoc)
                                }
                                "200" -> {
                                    locationResponse.putaway?.let { viewModel.setLocationData(it) }
                                    enableDisableFields(toContainer = true, toLocation = true, serialNumber = true, slp = true)
                                    binding.etSerialNum.requestFocus()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvToLocRes.text = message
                        binding.etToLoc.requestFocus()
                        binding.etToLoc.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etToLoc)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to validate serialNumber from API
     */
    private fun validateSerialNumber() {
        viewModel.validateSerialNumber(
            MSBPutawayRequest(
                dataSource = "RF",
                mixedSbPutaway = true,
                putaway = PutawayReq(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    destination = binding.etToCont.text.toString(),
                    locId = binding.etToLoc.text.toString(),
                    retType = 0,
                    serialNum = binding.etSerialNum.text.toString(),
                    source = null,
                    usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    /**
     * method to subscribe validate serialNumber observer
     */
    private fun subscribeSerialNumberObserver() {
        viewModel.serialNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialNumberResponse ->
                        if (serialNumberResponse.statusHandler != null) {
                            when (serialNumberResponse.statusHandler.statusCode) {
                                "500" -> {
                                    binding.tvSerialNumRes.text = serialNumberResponse.statusHandler.message
                                    binding.etSerialNum.requestFocus()
                                    binding.etSerialNum.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etSerialNum)
                                }
                                "200" -> {
                                    binding.etQuantity.setText(serialNumberResponse.putaway?.cntQty.toString())
                                    serialNumberResponse.statusHandler.message?.let { showSuccessSnackBar(it) }
                                    clearRequiredFields()
                                }
                                else -> {
                                    binding.etSerialNum.text?.clear()
                                    enableDisableFields(toContainer = true, toLocation = true, serialNumber = true, slp = true)
                                    binding.etSlp.requestFocus()
                                }
                            }

                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvSerialNumRes.text = message
                        binding.etSerialNum.requestFocus()
                        binding.etSerialNum.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etSerialNum)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to submit putaway
     */
    private fun submitPutaway() {
        viewModel.submitPutaway(
            MSBPutawayRequest(
                dataSource = "RF",
                mixedSbPutaway = true,
                putaway = PutawayReq(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    destination = binding.etToCont.text.toString(),
                    locId = binding.etToLoc.text.toString(),
                    retType = 0,
                    serialNum = null,
                    source = binding.etSlp.text.toString(),
                    usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    /**
     * method to subscribe validate serialNumber observer
     */
    private fun subscribeSubmitPutawayObserver() {
        viewModel.submitPutawayResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { submitPutawayResponse ->
                        if (submitPutawayResponse.statusHandler?.statusCode != null) {
                            when (submitPutawayResponse.statusHandler.statusCode) {
                                "500" -> {
                                    binding.tvSlpRes.text = submitPutawayResponse.statusHandler.message
                                    binding.etSlp.requestFocus()
                                    binding.etSlp.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etSlp)
                                }
                                "200" -> {
                                    binding.etQuantity.setText(submitPutawayResponse.putaway?.cntQty.toString())
                                    submitPutawayResponse.statusHandler.message?.let { showSuccessSnackBar(it) }
                                    clearRequiredFields()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvSerialNumRes.text = message
                        binding.etSerialNum.requestFocus()
                        binding.etSerialNum.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etSerialNum)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to clear required fields
     */
    private fun clearRequiredFields() {
        binding.etSerialNum.text = null
        binding.etSlp.text = null
        binding.etSerialNum.requestFocus()
        enableDisableFields(toContainer = true, toLocation = true, serialNumber = true, slp = false)
    }

    /**
     * method to enable/disable fields
     */
    private fun enableDisableFields(toContainer: Boolean, toLocation: Boolean, serialNumber: Boolean, slp: Boolean) {
        binding.etToCont.isEnabled = toContainer
        binding.etToLoc.isEnabled = toLocation
        binding.etSerialNum.isEnabled = serialNumber
        binding.etSlp.isEnabled = slp
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            binding.etToCont.isFocused -> {
                binding.etToCont.setText(scan?.barcode.toString())
                binding.etToCont.text?.length?.let {
                    binding.etToCont.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ToContainer field focused")
                    validateToContainer()
                }
            }
            binding.etToLoc.isFocused -> {
                binding.etToLoc.setText(scan?.barcode.toString())
                binding.etToLoc.text?.length?.let {
                    binding.etToLoc.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ToLocation field focused")
                    validateToLocation()
                }
            }
            binding.etSerialNum.isFocused -> {
                binding.etSerialNum.setText(scan?.barcode.toString())
                binding.etSerialNum.text?.length?.let {
                    binding.etSerialNum.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "SerialNumber field focused")
                    validateSerialNumber()
                }
            }
            binding.etSlp.isFocused -> {
                binding.etSlp.setText(scan?.barcode.toString())
                binding.etSlp.text?.length?.let {
                    binding.etSlp.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "SLP field focused")
                    submitPutaway()
                }
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}