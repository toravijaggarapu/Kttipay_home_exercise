package com.fsc.flare.ui.fragment.inventory.casetransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasetransferPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.Constants.Companion.TRANSFER_TYPE_PALLET
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CaseTransferPalletFragment"
private const val INVALID_PALLET = "ERR-INV-0104"

/**
 * A simple [CaseTransferPalletFragment] class.
 */
@AndroidEntryPoint
class CaseTransferPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentCasetransferPalletBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCasetransferPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.caseTransferHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.edtPallet.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletError.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtPallet)
                    if (binding.edtPallet.isFocused) {
                        FlareLog.i(TAG, "Pallet field focused")
                        getPalletDetail()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.edtPallet.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtPallet)
                FlareLog.i(TAG, "Pallet field focused")
                getPalletDetail()
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            getNewPalletDetail()
        }

        subscribeObservers()
    }

    private fun getPalletDetail() {
        if(binding.edtPallet.text.toString().trim().isNotEmpty()){
            //Get pallet detail.
            val containerType = viewModel.validateContainerType(sharedPreferences, TRANSFER_TYPE_PALLET)
            val palletNumber = binding.edtPallet.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.palletError.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                viewModel.caseTransferValidateContainer(binding.edtPallet.text.toString(), TRANSFER_TYPE_PALLET)
            }
        }
    }

    private fun getNewPalletDetail() {
        //Call new pallet API.sss
        viewModel.generatePalletCaseNumber()
    }

    private fun ContainerInquiryCall(){
        if(binding.edtPallet.text?.trim().toString().isNotEmpty()){
            viewModel.getContainerDetails(binding.edtPallet.text.toString().trim(),false)
        }
    }

    private fun subscribeObservers() {

        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { containerResponse ->
                        val containers = viewModel.getCaseTransferContainerList()
                        val palletResponse = viewModel.getCaseTransferPalletResponse()
                        if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)){
                            if(containerResponse.containers?.get(0)?.lockCode == "CC"){
                                binding.palletError.text = getString(R.string.cycle_count_in_progress_for_given_location)
                            }else{
                                when {
                                    containers?.get(0)?.itemId != palletResponse.palletInquiry.itemId -> {
                                        showErrorAlert(true)
                                    }
                                    containers?.get(0)?.inventoryType != palletResponse.palletInquiry.inventoryType -> {
                                        showErrorAlert(false)
                                    }
                                    else -> {
                                        //Save the pallet detail.
                                        viewModel.setCaseTransferPalletDetail(palletResponse.palletInquiry)
                                        viewModel.setNewPalletNumber(null)
                                        navigateDestinationLocationPage()
                                    }
                                }

                            }
                        }else{
                            if(containerResponse.containers?.get(0)?.cycleCountPending == "Y"){
                                binding.palletError.text = getString(R.string.cycle_count_is_pending_for_given_location)
                            }else{
                                when {
                                    containers?.get(0)?.itemId != palletResponse.palletInquiry.itemId -> {
                                        showErrorAlert(true)
                                    }
                                    containers?.get(0)?.inventoryType != palletResponse.palletInquiry.inventoryType -> {
                                        showErrorAlert(false)
                                    }
                                    else -> {
                                        //Save the pallet detail.
                                        viewModel.setCaseTransferPalletDetail(palletResponse.palletInquiry)
                                        viewModel.setNewPalletNumber(null)
                                        navigateDestinationLocationPage()
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        binding.palletError.text = message
                        FlareLog.e(TAG, "container error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.caseTransferContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletResponse ->
                        if(palletResponse.success){
                            val containers = viewModel.getCaseTransferContainerList()
                            if(containers!=null && containers.isNotEmpty()){
                                if(sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) && viewModel.isPalletUomDefined()){
                                        if(palletResponse.palletInquiry.noOfCase.toInt() == viewModel.getDefinedCaseQtyPerPallet()!!){
                                            binding.palletError.text = getString(R.string.scanned_pallet_is_already_full_as_per_uom_configuration_please_scan_another_pallet)
                                        }else if(palletResponse.palletInquiry.noOfCase.toInt() > viewModel.getDefinedCaseQtyPerPallet()!!){
                                            binding.palletError.text = getString(R.string.scanned_pallet_is_having_more_cases_than_the_pallet_uom_configured)
                                        }else if(viewModel.getCaseScannedCount() + palletResponse.palletInquiry.noOfCase > viewModel.getDefinedCaseQtyPerPallet()!!){
                                            val excessCases = ((viewModel.getCaseScannedCount()+palletResponse.palletInquiry.noOfCase) - viewModel.getDefinedCaseQtyPerPallet()!!).toInt()
                                            binding.palletError.text = resources.getString(R.string.lbl_max_pallet_capacity_is_reached_remove_excess, resources.getQuantityString(R.plurals.case_transfer_scanned_cases, excessCases, excessCases))
                                        }else{
                                            ContainerInquiryCall()
                                            viewModel.setCaseTransferPalletResponse(palletResponse)
                                        }
                                }else{
                                    ContainerInquiryCall()
                                    viewModel.setCaseTransferPalletResponse(palletResponse)
                                }
                            }
                        }else{
                            if(palletResponse.message!=null && palletResponse.message.isNotEmpty())
                            {
                                binding.palletError.text = palletResponse.message
                            }else
                            {
                                binding.palletError.text =getString(R.string.pallet_cannot_be_transferred)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                if ((msgArray[0] == INVALID_PALLET)) {
                                    //In error save the new pallet number as the user entered and proceed further.
                                    savePalletNumber(binding.edtPallet.text.toString().trim())
                                } else {
                                    binding.palletError.text = msgArray[1]
                                }
                            }
                        } else
                        {
                            binding.palletError.text =getString(R.string.pallet_cannot_be_transferred)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if(generatePalletCaseNumberResponse.success){
                            //Save the Pallet number.
                            if(generatePalletCaseNumberResponse.numbers[0].type.equals(TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                savePalletNumber(generatePalletCaseNumberResponse.numbers[0].value)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.edtPallet.requestFocus()
                        binding.palletError.text = message
                        binding.edtPallet.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.edtPallet)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun showErrorAlert(isMixedItem: Boolean) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(if (isMixedItem) resources.getString(R.string.lbl_mixed_items_not_allowed) else getString(R.string.receiving_mixed_inventory_not_allowed))
        builder.setMessage(if (isMixedItem) resources.getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check) else getString(
            R.string.containers_have_different_inventory_type_can_not_palletize_together))

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
            dialogInterface.dismiss()
            binding.edtPallet.text = null
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtPallet.setText(scan?.barcode.toString())
            binding.edtPallet.text?.length?.let {
                binding.edtPallet.setSelection(it)
            }
            FlareLog.i(TAG, "Pallet field focused")
            getPalletDetail()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun navigateDestinationLocationPage(){
        //Navigate to the Detail page.
        getNavigationController()
            .navigate(CaseTransferPalletFragmentDirections.actionCaseTransferPalletFragmentToCaseTransferDestinationLocationFragment())
    }

    private fun savePalletNumber(palletNumber:String){
        viewModel.setNewPalletNumber(palletNumber)
        viewModel.setCaseTransferPalletDetail(null)
        navigateDestinationLocationPage()
    }
}

