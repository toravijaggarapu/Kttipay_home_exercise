package com.fsc.flare.ui.fragment.partsreplacement

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.CompleteMoveTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.PrintTaskLabelRequest
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.source.data.dto.partsreplacement.response.GetMoveTaskRfResponse
import com.fsc.flare.source.data.dto.partsreplacement.response.LabelPrintingResponse
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.repository.PartsReplacementRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import java.lang.reflect.Type
import javax.inject.Inject

private val TAG = PartsReplacementViewModel::class.java.simpleName.toString()
@HiltViewModel
class PartsReplacementViewModel @Inject constructor(
    private val partsReplacementRepository: PartsReplacementRepository,
    private var sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)

    var taskGroupsList: MutableLiveData<ArrayList<TaskGroup>> =
        MutableLiveData<ArrayList<TaskGroup>>()

    val getRepairTaskRfResponse: MutableLiveData<Resource<GetMoveTaskRfResponse>> =
        SingleLiveEvent()

    val updateMoveTaskDetailsRfResponse: MutableLiveData<Resource<GetMoveTaskRfResponse>> =
        SingleLiveEvent()
    var moveTaskRfResponse: MutableLiveData<GetMoveTaskRfResponse> =
        MutableLiveData<GetMoveTaskRfResponse>()
    val compeleteMoveTaskDetailsRfResponse: MutableLiveData<Resource<GetMoveTaskRfResponse>> =
        SingleLiveEvent()
    val printPartsReplacementRfResponse: MutableLiveData<Resource<LabelPrintingResponse>> =
        SingleLiveEvent()


    var moveTaskDetails: MutableLiveData<List<TaskDetail>> = MutableLiveData()
    var taskTypeOptions: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    private var serialNumberList: MutableLiveData<List<String>?> = MutableLiveData()
    var indexCount: Int = 0
    private var containerList: MutableLiveData<List<String>> = MutableLiveData()
    private var putawayContainerList: MutableLiveData<List<String>> = MutableLiveData()
    var deviceContainerCount: Int = 0


    fun getRepairTaskRf(getRepairTaskRf: GetRepairTaskRf) =
        viewModelScope.launch {
            FlareLog.i(TAG, "getMovetTaskRF Request: $getRepairTaskRf")
            getRepairTaskRfResponse.postValue(Resource.Loading())
            val getMoveTaskRFRes =
                partsReplacementRepository.getRepairTaskRf(getRepairTaskRf)
            getRepairTaskRfResponse.postValue(
                handleGetMoveTaskRFResponse(
                    getMoveTaskRFRes
                )
            )
        }

    fun updateMoveTaskDetailsRf(getMoveTaskRf: UpdateMoveTaskDetailsRequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "updateMoveTaskDetailsRf Request: $getMoveTaskRf")
            updateMoveTaskDetailsRfResponse.postValue(Resource.Loading())
            val updateMoveTaskDetailsResponse =
                partsReplacementRepository.updateMoveTaskDetailsRf(getMoveTaskRf)
            updateMoveTaskDetailsRfResponse.postValue(
                handleGetMoveTaskRFResponse(
                    updateMoveTaskDetailsResponse
                )
            )
        }

    fun completeMoveTaskRf(completeMoveTaskRf: CompleteMoveTaskRf) =
        viewModelScope.launch {
            FlareLog.i(TAG, "completeMoveTaskRf Request: $completeMoveTaskRf")
            compeleteMoveTaskDetailsRfResponse.postValue(Resource.Loading())
            val completeMoveTaskDetailsRfResponse =
                partsReplacementRepository.completeMoveTaskRf(completeMoveTaskRf)
            compeleteMoveTaskDetailsRfResponse.postValue(
                handleGetMoveTaskRFResponse(
                    completeMoveTaskDetailsRfResponse
                )
            )
        }


    fun printPartsReplacementRf(printTaskLabelRequest: PrintTaskLabelRequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "printPartsReplacementRf Request: $printTaskLabelRequest")
            printPartsReplacementRfResponse.postValue(Resource.Loading())
            val printPartsReplacementResponse =
                partsReplacementRepository.printPartsReplacementRf(printTaskLabelRequest)
            printPartsReplacementRfResponse.postValue(
                handlePrintLabelRFResponse(
                    printPartsReplacementResponse
                )
            )
        }





    private fun handleGetMoveTaskRFResponse(getMoveTaskRfResponse: Response<GetMoveTaskRfResponse>): Resource<GetMoveTaskRfResponse>? {
        if (getMoveTaskRfResponse.isSuccessful) {
            getMoveTaskRfResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "GetMoveTaskRfResponse : $resultResponse")

                resultResponse.task.firstOrNull()?.let { task ->
                    setSourceContianerList(task.taskDetails.filter {!it.ibContainerNumber.isNullOrEmpty() }.map{it.ibContainerNumber}.distinct().toMutableList())
                    setPutawayContianerList(task.taskDetails.filter {!it.obContainerNumber.isNullOrEmpty() }.map{it.obContainerNumber}.distinct().toMutableList())
                }
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                getMoveTaskRfResponse.code(),
                getMoveTaskRfResponse.errorBody(),
                getMoveTaskRfResponse.message()
            )
            FlareLog.e(TAG, "GetMoveTaskRfResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handlePrintLabelRFResponse(labelPrintingResponse: Response<LabelPrintingResponse>): Resource<LabelPrintingResponse>? {
        if (labelPrintingResponse.isSuccessful) {
            labelPrintingResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LabelPrintingResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                labelPrintingResponse.code(),
                labelPrintingResponse.errorBody(),
                labelPrintingResponse.message()
            )
            FlareLog.e(TAG, "LabelPrintingResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }



    fun getMoveTaskRfResponse(): GetMoveTaskRfResponse {
        return moveTaskRfResponse.value!!
    }

    fun setMoveTaskRfResponse(getMoveTaskRfResponse: GetMoveTaskRfResponse) {
        this.moveTaskRfResponse.value = getMoveTaskRfResponse
    }

    fun getMoveTaskList(): List<Task> {
        return getMoveTaskRfResponse().let {
            it.task.filter {
                it.taskDetails.isNotEmpty()
            }
        }
    }

    fun getMoveTaskDetails(): List<TaskDetail> {
        return getMoveTaskRfResponse().task.flatMap { it.taskDetails }
    }

    fun getTaskTypeOptions(): ArrayList<String>? {
        return taskTypeOptions.value
    }

    fun setTaskTypeOptions() {
        val taskTaskList = ArrayList<String>()
        taskTaskList.add(Constants.PartsReplacement.MOVE_PARTS_TO_REPAIR)
        taskTaskList.add(Constants.PartsReplacement.MOVE_PARTS_TO_PUTAWAY)
        this.taskTypeOptions.value = taskTaskList
    }


    fun getSerialNumberList(): List<String>? {
        if (!getMoveTaskDetails().get(getIndexCountValue()).serialnumbers.isNullOrEmpty()) {
            this.serialNumberList.value = getMoveTaskDetails().get(getIndexCountValue()).serialnumbers
            return serialNumberList.value
        }
        return emptyList()
    }

    fun getSerialNumberCount(): Int {
        if (!serialNumberList.value.isNullOrEmpty()) {
            return serialNumberList.value!!.size
        }
        return 0
    }

    fun setSourceContianerList(containerList: List<String>?) {
        FlareLog.i(TAG, "containerList : ${containerList?.size}")
        this.containerList.value = containerList
    }

    fun getSourceContianerList(): List<String>? {
        if (!containerList.value.isNullOrEmpty()) {
            return containerList.value
        }
        return emptyList()
    }

    fun getSourceContianerCount(): Int {
        if (!containerList.value.isNullOrEmpty()) {
            return containerList.value!!.size
        }
        return 0
    }

    fun setPutawayContianerList(putawayContainerList: List<String>?) {
        FlareLog.i(TAG, "putawayContainerList : ${putawayContainerList?.size}")
        this.putawayContainerList.value = putawayContainerList
    }

    fun getPutawayContianerList(): List<String>? {
        if (!putawayContainerList.value.isNullOrEmpty()) {
            return putawayContainerList.value
        }
        return emptyList()
    }

    fun getPutawayContianerCount(): Int {
        if (!putawayContainerList.value.isNullOrEmpty()) {
            return putawayContainerList.value!!.size
        }
        return 0
    }

    fun getSerialList(): ArrayList<String> {
        val serialNumberList: ArrayList<String>
        val serialListJson =
            sharedPreferences.getString(PreferenceKeys.PartsReplacement.PUTAWAY_SERIAL_NUMBER_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return ArrayList()
    }

    fun resetSerialNumber() {
        val json = Gson().toJson(ArrayList<String>())
        sharedPreferences.edit().putString(PreferenceKeys.PartsReplacement.PUTAWAY_SERIAL_NUMBER_LIST, json).apply()
    }

    fun getSrcContainerList(): ArrayList<String> {
        val serialNumberList: ArrayList<String>
        val serialListJson =
            sharedPreferences.getString(PreferenceKeys.PartsReplacement.REPAIR_CONTAINER_NUMBER_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return ArrayList()
    }

    fun resetSrcContainerNumber() {
        val json = Gson().toJson(ArrayList<String>())
        sharedPreferences.edit().putString(PreferenceKeys.PartsReplacement.REPAIR_CONTAINER_NUMBER_LIST, json).apply()
    }

    fun getPutawayList(): ArrayList<String> {
        val serialNumberList: ArrayList<String>
        val serialListJson =
            sharedPreferences.getString(PreferenceKeys.PartsReplacement.PUTAWAY_CONTAINER_NUMBER_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return ArrayList()
    }

    fun resetPutawayNumber() {
        val json = Gson().toJson(ArrayList<String>())
        sharedPreferences.edit().putString(PreferenceKeys.PartsReplacement.PUTAWAY_CONTAINER_NUMBER_LIST, json).apply()
    }

    fun getTaskListSize(): Int {
        return getMoveTaskList().size
    }

    fun getTaskDetailsSize(): Int {
        return getMoveTaskDetails().size
    }

    fun getIndexCountValue(): Int {
        return indexCount
    }

    fun setIndexCountValue(currentIndex : Int) {
         indexCount = currentIndex
    }

    fun getDeviceContainerCountValue(): Int {
        return deviceContainerCount
    }

    fun setDeviceContainerCountValue(currentIndex : Int) {
        deviceContainerCount = currentIndex
    }


    fun getTaskGroupsList(): ArrayList<TaskGroup>? {
        return taskGroupsList.value
    }

    fun setTaskGroupsList(taskGroups: ArrayList<TaskGroup>) {
        this.taskGroupsList.value = taskGroups
    }

}
