package com.fsc.flare.ui.fragment.shippingtrailer.closetrailer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentShippingDockDoorBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.ui.fragment.shippingtrailer.ShippingTrailerViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.RecallCodes
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ShippingDockDoorFragment"

/**
 * [ShippingDockDoorFragment] class.
 */
@AndroidEntryPoint
class ShippingDockDoorFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: ShippingTrailerViewModel by activityViewModels()
    private lateinit var binding: FragmentShippingDockDoorBinding

    lateinit var cb1: CustomVisibilityCallback

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (binding.dockDoor.isFocused && !binding.dockDoor.text.isNullOrEmpty()) {
                        hideSoftKeyBoard(fragmentContext, binding.dockDoor)
                        viewModel.getDockDoorInfo(binding.dockDoor.text.toString())
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.dockDoor.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.dockDoor)
                FlareLog.i(TAG, "DockDoor field focused")
                viewModel.getDockDoorInfo(binding.dockDoor.text.toString())
            }
            false
        }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentShippingDockDoorBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.dockDoor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.dockDoorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.dockDoorResponse.observe(viewLifecycleOwner) { ddInquiryResponse ->
            when (ddInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "dockDoor success: $ddInquiryResponse")
                    hideProgressBar()
                    ddInquiryResponse.data?.let { locationResponse ->
                        if (locationResponse.location != null) {
                            getShipmentDockDoor(locationResponse.location.locationId)
                        } else {
                            binding.dockDoorResponse.text = resources.getString(R.string.invalid_location)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    ddInquiryResponse.message?.let { message ->
                        binding.dockDoorResponse.text = message
                        FlareLog.e(TAG, "dockDoor error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.shipmentDDResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shipmentDDResponse ->
                        sharedPreferences.edit().putString(PreferenceKeys.Shipping.DD_NUMBER, binding.dockDoor.text.toString()).apply()
                        if(shipmentDDResponse.success){
                            viewModel.setDockDoorShipment(shipmentDDResponse)
                            binding.dockDoor.text = null
                            val action = ShippingDockDoorFragmentDirections.actionShippingDockDoorFragmentToShippingTrailerFragment()
                            getNavigationController().navigate(action)
                        } else {
                            binding.dockDoorResponse.text = shipmentDDResponse.message
                            binding.dockDoor.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.dockDoor)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        handleShippingDockDoorErrorResponse(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        observeRecallContainersResponse()
    }

    /**
     * Function to handle OB Container error response
     */
    private fun handleShippingDockDoorErrorResponse(message: String?) {
        message?.let { msg ->
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg

            when {
                errorMessage[0].equals(RecallCodes.RECALL_CLOSE_TRAILER_ERROR, ignoreCase = true) -> {
                    displayRecallContainers(errorMessage[1])
                }
                else -> {
                    binding.dockDoorResponse.text = responseMessage
                    binding.dockDoor.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.dockDoor)
                }
            }
        }
    }

    /**
     * Function to display Recall containers alert dialog
     */
    private fun displayRecallContainers(errorMessage: String) {
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setMessage(errorMessage)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.lbl_view_recall_pallets)) { dialog, _ ->
                dialog.dismiss()
                // call view recall containers api
                val dockDoorId = viewModel.dockDoorResponse.value?.data?.location?.locationId?:0
                if(dockDoorId != 0)  {
                 viewModel.viewRecallContainersAPIRequest(dockDoorId)
                }
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to observe Recall Containers Api response
     */
    private fun observeRecallContainersResponse() {
        viewModel.obCartonRCLockResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObCartonRCLockSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObCartonRCLockErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Recall Containers success response
     */
    private fun handleObCartonRCLockSuccessResponse(data: OBCartonRCLockResponse?) {
        binding.dockDoor.setText("")
        data?.containers?.let { containers ->
            displayRecallContainersDialog(containers)
        }
    }

    /**
     * Function to display Recall Containers dialog
     */
    private fun displayRecallContainersDialog(containers: List<Container>) {

        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(getString(R.string.lbl_recalled_pallets))
            .setItems(containers.map { it.containerNumber }.toTypedArray(), null)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    /**
     * Function to handle Recall Containers error response
     */
    private fun handleObCartonRCLockErrorResponse(message: String?) {
        message?.let { errorMessage ->
            showErrorSnackBar(errorMessage)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun getShipmentDockDoor(dockDoorId: Int) {
        viewModel.getShipmentDockDoor(
            ShipmentDockDoorRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                dockDoorId = dockDoorId,
                closeTrailer = true
            )
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            sharedPreferences.edit().apply {
                sharedPreferences.edit().putString(PreferenceKeys.Item.DD_NUMBER, scan?.barcode.toString()).apply()
            }
            binding.dockDoor.setText(scan?.barcode.toString())
            binding.dockDoor.text?.length?.let {
                binding.dockDoor.setSelection(
                    it
                )
                viewModel.getDockDoorInfo(binding.dockDoor.text.toString())
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}