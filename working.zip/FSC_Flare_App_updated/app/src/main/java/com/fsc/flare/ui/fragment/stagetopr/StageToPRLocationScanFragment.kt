package com.fsc.flare.ui.fragment.stagetopr

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackstationToPrLocationBinding
import com.fsc.flare.databinding.FragmentStageToPrLocationScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteToPRLocationRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrRequest
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrResponse
import com.fsc.flare.ui.fragment.totefrompackstationtopr.PackstationToPRViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
private const val TAG = "StageToPRLocationScanFragment"
@AndroidEntryPoint
class StageToPRLocationScanFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentStageToPrLocationScanBinding
    private val viewModel: StageToPRViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    var locationId = 0

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentStageToPrLocationScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePRLocation()
                }
            }
            v.onTouchEvent(event)
        }
        binding.prLocationInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG,
                    "StagingLocation field focused"
                )
                validatePRLocation()
            }
            false
        }
        binding.prLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.prLocationErrRes.text = null
            }
        })
    }

    private fun subscribeObservers() {
        observeInventoryStagePrResponse()
    }

    /**
     * Function to observe OB Container Response
     */
    private fun observeInventoryStagePrResponse() {
        viewModel.inventoryStagePrResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleInventoryStagePrResponse(response.data?.message)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleInventoryStagePrErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleInventoryStagePrErrorResponse(message: String?) {
        hideProgressBar()

        message?.let { msg ->
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            FlareLog.e(TAG, "InventoryStagePrErrorResponse error: $responseMessage")
            displayErrorMessage(responseMessage)
        }
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleInventoryStagePrResponse(message: String?) {
        message?.let { message ->
            showSuccessSnackBarStd(message) {
                navigateToStagePRPalletScanFragment()
            }
        }
    }

    /**
     * Nav Handler to location scan fragment
     */
    private fun navigateToStagePRPalletScanFragment() {
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.stageToPRLocationScanFragment, true).build()
        getNavigationController().navigate(
            R.id.action_stageToPRLocationScanFragment_to_stageToPRPalletScanFragment,
            null,
            navOptions
        )
    }

    private fun validatePRLocation() {
        if (!binding.prLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.prLocationInput)
            val prLocation = binding.prLocationInput.text.toString().trim()
            val request = InventoryStageToPrRequest(destLocNbr = prLocation, viewModel.containerId)
            viewModel.inventoryStagePrReCallRequest(inventoryStagePrReCallRequest = request)
        }else
        {
            binding.prLocationErrRes.text = "Enter PR Location"
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.prLocationErrRes.text = message
        binding.prLocationInput.selectAll()
        showSoftKeyBoard(fragmentContext, binding.prLocationInput)
    }

    private fun showSuccess(message:String) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
            dialogInterface.dismiss()
                val navOptions = NavOptions.Builder()
                    .setPopUpTo(R.id.packStationToteToPRToteFragment, true).build()
                getNavigationController().navigate(
                    R.id.action_packstationToPRLocationFragment_to_packStationToPRToteFragment,
                    null,
                    navOptions
                )
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.prLocationInput.setText(scan?.barcode.toString())
            binding.prLocationInput.text?.length?.let {
                binding.prLocationInput.setSelection(it)
            }
        FlareLog.i(TAG, "Location field focused")
            validatePRLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}