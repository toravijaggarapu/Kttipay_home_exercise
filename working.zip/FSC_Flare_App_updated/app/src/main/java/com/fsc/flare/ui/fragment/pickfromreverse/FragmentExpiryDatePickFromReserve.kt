package com.fsc.flare.ui.fragment.pickfromreverse


import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentExpiryDatePickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject


private const val TAG = "FragmentExpiryDatePickFromReserve"

@AndroidEntryPoint
class FragmentExpiryDatePickFromReserve : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentExpiryDatePickFromReserveBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExpiryDatePickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.taskIdTVRes.text = data.taskId.toString()
            binding.itemCodeTvRes.text = data.itemCode
            binding.desTvRes.text = data.itemDescription
            binding.quantityTvRes.text = String.format("%d %s",data.ibContainerQty,data.ibContainerUom)
            binding.locaitonTvRes.text = data.locationName
            binding.containerTvRes.text = data.containerNbr
        }

        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            binding.expiryEdt.text = sdf.format(cal.time)
            if(!isExpiryDateSame(binding.expiryEdt.text.toString())){
                binding.expiryDateEdt.text = getString(R.string.alert_invalid_expiry_date)
            }else{
                if (!binding.expiryEdt.text.isNullOrEmpty()) {
                    validateContainer()
                }
            }
        }
        binding.expiryEdt.setOnClickListener {
            binding.expiryDateEdt.text = ""
                FlareLog.i(TAG, "Date field clicked")
            DatePickerDialog(
                fragmentContext, dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
        binding.stage.setOnClickListener {
            viewModel.reservepickstage()
        }
    }

    private fun validateContainer() {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            if (taskData.promptBlind) {
                viewModel.taskReservePickComplete(
                    ReservePickCompleteRequest(
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        taskData.containerId,
                        taskData.containerNbr,
                        sharedPreferences.getString(PreferenceKeys.ReservePick.BLIND_CONTAINER, null),
                        taskData.locationBarcode,
                        taskData.locationName,
                        taskData.taskQty,
                        taskData.taskQtyUom,
                        taskData.taskDetId,
                        "PFR",
                        taskData.taskId,
                        sharedPreferences.getString(PreferenceKeys.ReservePick.LOT_NUMBER, null),
                        binding.expiryDateEdt.text.toString()
                    )
                )
            } else {
                viewModel.taskReservePickComplete(
                    ReservePickCompleteRequest(
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        taskData.containerId,
                        taskData.containerNbr,
                        taskData.locationBarcode,
                        taskData.locationName,
                        taskData.taskQty,
                        taskData.taskQtyUom,
                        taskData.taskDetId,
                        "PFR",
                        taskData.taskId,
                        sharedPreferences.getString(PreferenceKeys.ReservePick.LOT_NUMBER, null),
                        binding.expiryDateEdt.text.toString()
                    )
                )
            }
        }

    }

    private fun subscribeObservers() {
        viewModel.reservePickCompleteResponse.observe(viewLifecycleOwner) { reservePickCompleteResponse ->
            when (reservePickCompleteResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickCompleteResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBar(response.message)
                            viewModel.reservepickstage()
                        } else {
                            viewModel.setPickTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentExpiryDatePickFromReserveDirections.actionPickFromReserveExpiryDateFragmentToPickFromReserveContainerFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveContainerFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickCompleteResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickCompleteResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) {reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showErrorSnackBar(response.message)
                            Handler(Looper.getMainLooper()).postDelayed({
                                val navController =
                                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    FragmentExpiryDatePickFromReserveDirections.actionPickFromReserveExpiryDateFragmentToPickFromReserveFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveFragment, true).build()
                                navController.navigate(action, navOptions)
                            }, 1000)
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentExpiryDatePickFromReserveDirections.actionPickFromReserveExpiryDateFragmentToPickFromReserveStageFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveStageFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun isExpiryDateSame(selectedDate:String):Boolean {
        val myFormat1 = "yyyy-MM-dd" // mention the format you need
        val myFormat = "yyyy-MM-dd hh:mm:ss" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        val sdf1 = SimpleDateFormat(myFormat1, Locale.US)
        if(viewModel.getPickTaskDetails()?.expDate!=null && viewModel.getPickTaskDetails()?.expDate !=""){
            val getApiExpiryDate = sdf.parse(viewModel.getPickTaskDetails()?.expDate)
            val taskDetailExpDate = sdf1.format(getApiExpiryDate)
            if(taskDetailExpDate.isNotEmpty() && taskDetailExpDate.equals(selectedDate, true)){
                return true
            }
        }else{
            return true
        }
        return false
    }
}