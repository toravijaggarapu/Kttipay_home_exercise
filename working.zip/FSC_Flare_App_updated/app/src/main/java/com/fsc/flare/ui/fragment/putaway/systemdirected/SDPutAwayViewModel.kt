package com.fsc.flare.ui.fragment.putaway.systemdirected

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.putawayforward.get.req.SDPutawayReq
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayForwardGetResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.ItemSlotting
import com.fsc.flare.source.data.dto.userdirectedputaway.PutawayRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitResponse
import com.fsc.flare.source.repository.SDPutAwayRepository
import com.fsc.flare.utils.Constants.LocationClasses.INBOUND_QA
import com.fsc.flare.utils.Constants.LocationClasses.RESERVE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class SDPutAwayViewModel @Inject constructor(
    private val sdPutAwayRepository: SDPutAwayRepository,
    private var sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {

    private val _containerResponse = SingleLiveEvent<Resource<UserDirectedPutawayContainerResponse>>()
    val containerResponse: LiveData<Resource<UserDirectedPutawayContainerResponse>>
        get() = _containerResponse

    private val _submitUDPutawayResponse = SingleLiveEvent<Resource<UserDirectedPutawaySubmitResponse>>()
    val submitUDPutawayResponse: LiveData<Resource<UserDirectedPutawaySubmitResponse>>
        get() = _submitUDPutawayResponse

    private val _transactionParamResponse = SingleLiveEvent<Resource<TransactionParamResponse>>()
    val transactionParamResponse: LiveData<Resource<TransactionParamResponse>>
        get() = _transactionParamResponse

    private val _putawayForwardGetRes = SingleLiveEvent<Resource<PutawayForwardGetResponse>>()
    val putawayForwardGetRes: LiveData<Resource<PutawayForwardGetResponse>>
        get() = _putawayForwardGetRes

    private val _containerInfoResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val containerInfoResponse: LiveData<Resource<InventoryContainerResponse>>
        get() = _containerInfoResponse

    private val isolatedLocationClass = "IL"
    val locationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    var isPutawayByPallet = false
    var isRCLockCalled = false


    /**
     * Function to prepare Api request for Container Data
     */
    fun prepareContainerRequest(containerText: String, putawayType: String) {
        viewModelScope.launch(dispatcher) {
            val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            val containerType = if (isPutawayByPallet) "Pallet" else "Case"
            val includeCCLocation = if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)
            ) "Y" else "N"

            getContainer(
                UserDirectedPutawayContainerRequest(
                    custId = custId,
                    buId = buId,
                    fcyId = fcyId,
                    containerNumber = containerInfoResponse.value?.data?.container?.get(0)
                        ?.getContainerNumber(isPutawayByPallet, containerText) ?: "",
                    putAwayType = putawayType,
                    containerType = containerType,
                    includeCCLocation = includeCCLocation,
                    recallLockExists = isRCLockCalled
                )
            )
        }
    }

    /**
     * Function to get container details
     */
    private suspend fun getContainer(userDirectedPutawayContainerRequest: UserDirectedPutawayContainerRequest) {
        _containerResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.validateContainer(userDirectedPutawayContainerRequest)
        _containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * Function to handle container response
     */
    private fun handleContainerResponse(response: Response<UserDirectedPutawayContainerResponse>): Resource<UserDirectedPutawayContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare UD Putaway request
     */
    fun prepareSystemDirectedPutawayRequest(
        containerData: UserDirectedPutawayContainerResponse,
        palletId: String?,
        locationClass: String
    ) {
        viewModelScope.launch {
            submitUserDirectedPutaway(
                UserDirectedPutawaySubmitRequest(
                    putaway = PutawayRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        containerIds = containerData.containerIds,
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        itemId = containerData.itemId,
                        itemSlotting = null,
                        location = com.fsc.flare.source.data.dto.userdirectedputaway.Location(
                            locationClass = if (isRCLockCalled) isolatedLocationClass else locationClass,
                            locationId = if(locationClass == RESERVE || locationClass == INBOUND_QA) containerData.locationId else Integer.parseInt(getLocationId())
                        ),
                        palletId = palletId,
                        userDirected = true,
                        includeCCLocation = if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) "Y" else "N",
                        isRCLockCalled = isRCLockCalled,
                        lotNumber = getItemLotNumber()
                    )
                )
            )
        }
    }

    /**
     * Function to prepare UD Putaway request with Slotting
     */
    fun prepareSystemDirectedPutawayRequestWithSlotting(
        containerData: UserDirectedPutawayContainerResponse,
        palletId: String?,
        locationClass: String,
        maxQty: Int,
        minQty: Int,
        uom: String
    ) {
        viewModelScope.launch {
            submitUserDirectedPutaway(
                UserDirectedPutawaySubmitRequest(
                    putaway = PutawayRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        containerIds = containerData.containerIds,
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        itemId = containerData.itemId,
                        itemSlotting = ItemSlotting(
                            locationClass = if (isRCLockCalled) isolatedLocationClass else locationClass,
                            locationId = if(locationClass == RESERVE || locationClass == INBOUND_QA) containerData.locationId else Integer.parseInt(getLocationId()),
                            maxQty = maxQty,
                            minQty = minQty,
                            uom = uom
                        ),
                        location = com.fsc.flare.source.data.dto.userdirectedputaway.Location(
                            locationClass = if (isRCLockCalled) isolatedLocationClass else locationClass,
                            locationId = Integer.parseInt(getLocationId())
                        ),
                        palletId = palletId,
                        userDirected = true,
                        includeCCLocation = if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) "Y" else "N",
                        isRCLockCalled = isRCLockCalled,
                        lotNumber = getItemLotNumber()
                    )
                )
            )
        }
    }

    /**
     * Function to submit user directed putaway details
     */
    private suspend fun submitUserDirectedPutaway(userDirectedPutawaySubmitRequest: UserDirectedPutawaySubmitRequest) {
        _submitUDPutawayResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.submitUserdirectedPutaway(userDirectedPutawaySubmitRequest)
        _submitUDPutawayResponse.postValue(handleSubmitUserDirectedPutawayResponse(response))
    }

    /**
     * Function to handle submit user directed putaway response
     */
    private fun handleSubmitUserDirectedPutawayResponse(response: Response<UserDirectedPutawaySubmitResponse>): Resource<UserDirectedPutawaySubmitResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare transaction param request
     */
    fun prepareTransactionParamRequest() {
        viewModelScope.launch(dispatcher) {
            getTransactionParam(
                TransactionParamRequest(
                    cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    trans_code = "IS"
                )
            )
        }
    }

    /**
     * Function to get transaction param details
     */
    private suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) {
        _transactionParamResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getTransactionParam(transactionParamRequest)
        _transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * Function to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse> {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            transactionParamResponse.code(),
            transactionParamResponse.errorBody(),
            transactionParamResponse.message()
        )
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare transaction param request
     */
    fun preparePutawayForwardRequest(locationClass: String) {
        viewModelScope.launch(dispatcher) {
            getPutawayForward(
                SDPutawayReq(
                    fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    cnt_id = getContainerData().containerNbr,
                    cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    locClass = locationClass,
                    containerType = if(isPutawayByPallet) "Pallet" else "Case"
                )
            )
        }
    }

    private suspend fun getPutawayForward(putawayForwardGetReq: SDPutawayReq) {
        _putawayForwardGetRes.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getPutawayContainer(putawayForwardGetReq)
        _putawayForwardGetRes.postValue(handlePutawayForwardGetRes(response))
    }

    private fun handlePutawayForwardGetRes(response: Response<PutawayForwardGetResponse>): Resource<PutawayForwardGetResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(),
            response.errorBody(),
            response.message()
        )
        return Resource.Error(errorResponse)
    }

    /**
     * Function to get container details
     */
    fun getContainerDetails(containerNum: String) = viewModelScope.launch {
        _containerInfoResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getContainerDetails(containerNum)
        _containerInfoResponse.postValue(handleContainerInquiryResponse(response))
    }

    /**
     * Function to handle container inquiry response
     */
    private fun handleContainerInquiryResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
            response.code(),
            response.errorBody(),
            response.message()
        )
        return Resource.Error(errorResponse)
    }

    //data to be saved in view model
    var containerData: MutableLiveData<UserDirectedPutawayContainerResponse> = MutableLiveData()
    var locationData: MutableLiveData<String> = MutableLiveData()
    val containerId: MutableLiveData<String> = MutableLiveData()
    private val flagSlotRequired: MutableLiveData<Boolean> = MutableLiveData()

    fun setContainerData(container: UserDirectedPutawayContainerResponse) {
        this.containerData.value = container
    }

    fun getContainerData(): UserDirectedPutawayContainerResponse {
        return containerData.value!!
    }

    fun setLocationData(location: String) {
        this.locationData.value = location
    }

    fun getLocationData(): String? {
        return locationData.value
    }

    fun getLocationId(): String {
        return containerId.value!!
    }

    fun setLocationId(locationId: String) {
        this.containerId.value = locationId
    }

    fun setFlagSlotRequired(tmp: Boolean) {
        this.flagSlotRequired.value = tmp
    }

    fun getFlagSlotRequired(): Boolean {
        return flagSlotRequired.value!!
    }

    fun removeSpecialChars(locationName: String): String {
        var value = locationName
        value = value.replace("-", "", true)
        return value
    }

    fun getSuggestedLocation(): String = containerData.value?.locationBarcode ?: ""

    fun isContainerHasIncubationLock() =
        containerInfoResponse.value?.data?.container?.firstOrNull()?.hasIncubationLock == true

    private fun getItemLotNumber() =
        containerInfoResponse.value?.data?.container?.firstOrNull()?.item?.lotNumber

    fun hasQualityAuditVendorComplianceLock() =
        containerInfoResponse.value?.data?.container?.firstOrNull()?.hasQualityAuditVendorComplianceLock == true
}