package com.fsc.flare.ui.fragment.inventory

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryAdjustmentContainerReasonBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryAdjustmentRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryAdjReason"

/**
 * A simple [InventoryAdjustmentReasonFragment] class.
 */
@AndroidEntryPoint
class InventoryAdjustmentReasonFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryAdjustmentContainerReasonBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getInventoryReasonCodes()
    }


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryAdjustmentContainerReasonBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventoryIcCtrAdj.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getContainerInfo()
        if (data != null) {
            if (data.isNotEmpty()) {
                val containerData = data[0]
                binding.txtContainerNumberValue.text = containerData.containerNumber
                if (containerData.item != null) {
                    binding.txtQtyValue.text = containerData.updatedQty.toString()
                    if (containerData.item.tracking != null) {
                        if (/*containerData.item.tracking.serialNumberRequired != "1" || */containerData.item.tracking.serialNumberRequired != "4") {
                            viewModel.setSerialNumberList(emptyList())
                        }
                    }
                }


            }
        }
        subscribeObserver()
    }

    private fun subscribeObserver() {
        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksOptions(inventoryLockList)
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        binding.reasonCodeDropDown.setOptions(inventoryLockList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        Log.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        val containerListData = viewModel.getContainerInfo()
                        if (containerListData != null) {
                            if (containerListData.isNotEmpty()) {
                                val containerData = containerListData[0]
                                viewModel.inventoryLockAdjustment(
                                    InventoryAdjustmentRequest(
                                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                        containerId = containerData.containerId,
                                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                        ibObCode = containerData.ibObCode,
                                        invMasterId = containerData.invMasterId,
                                        qty = containerData.updatedQty.toString(),
                                        qtyUom = binding.txtUomValue.text.toString(),
                                        reasonCode = lookup.lookupCode,
                                        serialNumbers = viewModel.getSerialNumberList(),//Serial number list not always come, so i converted into null type in viewModel and data class.
                                        lockCode = lookup.lookupCode,
                                        lockcodeId = lookup.lookupCodeId
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        viewModel.inventoryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { inventorylock ->
                        if (inventorylock.message != null) {
                            showSuccessSnackBarStd(inventorylock.message) {
                                val action =
                                    InventoryAdjustmentReasonFragmentDirections.actionInventoryAdjustmentReasonFragmentToInventoryAdjustmentContainerFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inventoryAdjustmentContainerFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "InventoryLockResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

}