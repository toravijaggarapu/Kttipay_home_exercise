package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLItemSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "TivoALTYP11ItemSerialFragment"
private const val ARG_PAGE_TYPE = "pageType"
/**
 * A simple [Fragment] subclass.
 * Use the [TivoALTYP11ItemSerialFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11ItemSerialFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLItemSerialBinding
    private var taskDetails: TaskDetails? = null
    private var tempSerialList = ArrayList<String>()
    private var pageType = ""
    lateinit var serialListAdapter: TivoSerialAdapter

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)

    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLItemSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etItemCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvItemCodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSerialNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        if (arguments != null)
            arguments?.let {
                pageType = it.getString(ARG_PAGE_TYPE)!!
            }
        taskDetails = viewModel.getPickTaskDetails()
        binding.tvTaskIdValue.text = taskDetails?.taskId.toString()
        binding.tvItemCodeValue.text = taskDetails?.itemCode
        binding.tvDescriptionValue.text = taskDetails?.itemDescription
        binding.tvPickQtyValue.text = String.format("%d Units",taskDetails?.taskQty)
//        binding.tvPickedQtyValue.text = "0 Units"
        binding.tvPickedQtyValue.text = resources.getQuantityString(R.plurals.pallet_transfer_units, viewModel.getQtyEntered(), viewModel.getQtyEntered())
        binding.tvLocationValue.text = taskDetails?.locationBarcode

        if (pageType == "serial") {
            tempSerialList = viewModel.getSerialNumberList() as ArrayList<String>
            setupRecyclerView()
            binding.wgSerailNumber.visibility = View.VISIBLE
            binding.wgItemCode.visibility = View.GONE
//            binding.tvSerialValue.text = "(${viewModel.getSerialNumberList().size}/${taskDetails?.taskQty})"
            binding.tvSerialValue.text = String.format("%d/%d Units",viewModel.getSerialNumberList().size,viewModel.getQtyEntered())
        } else {
            binding.wgSerailNumber.visibility = View.GONE
            binding.wgItemCode.visibility = View.VISIBLE
        }

        if (sharedPreferences.getBoolean(PreferenceKeys.PickFromReserve.IS_FIRST_TASK_UNITPICKED, false)) {
            binding.btnStage.isEnabled = true
        }

        binding.etItemCode.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etItemCode)
                FlareLog.i(TAG, "Item code field focused")
                validateItemCode()
            }
            false
        }

        binding.etSerialNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                FlareLog.i(TAG, "Serial Number field focused")
                validateSerialNumber()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etItemCode.isFocused && !binding.etItemCode.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Item code field focused")
                        validateItemCode()
                    } else if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Serial Number field focused")
                        validateSerialNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnStage.setOnClickListener {
            viewModel.reservepickstage()
        }

        if (viewModel.isOverrideItemAttributes == -1 && (taskDetails!!.itemLotTracked == "1" || taskDetails!!.itemExpDateTracked == "1")) {
            getTransactionParam()
        }
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = TivoSerialAdapter(tempSerialList)
        binding.rvSerial.adapter = serialListAdapter
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSerialValidationObserver()
        subscribeLookUpsObserver()
        subscribeReservePickStageReleaseObserver()
        subscribeTransactionParamObserver()
        subscribeUPCObserver()
    }


    /**
     * method to validate Item Code from API
     */
    private fun validateItemCode() {
        viewModel.setSerialNumberList(arrayListOf())
        if (binding.etItemCode.text.toString() == binding.tvItemCodeValue.text.toString()) {
            navigateQtyPage()
        } else {
            validateUPCorSLP()
        }
    }

    /**
     * method to validate Serial Number from API
     */
    private fun validateSerialNumber() {
        if (taskDetails != null) {
//            if(taskDetails!!.taskQty > viewModel.getSerialNumberList().size){
            if(viewModel.getQtyEntered() > viewModel.getSerialNumberList().size){
                if (!tempSerialList.contains(binding.etSerialNumber.text.toString())) {
                    val srlNbrValidation = taskDetails?.srlNbrValidation
                    val srlNbrLength = taskDetails?.srlNbrLength
                    if(srlNbrValidation!=null && srlNbrLength!=null &&
                        srlNbrValidation == "Y" && isValidDigit(srlNbrLength) &&
                        taskDetails?.itemSerialTracked == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY){
                        if(srlNbrLength.toInt() == binding.etSerialNumber.text.toString().trim().length){
                            callSerialNumberValidate()
                        }else{
                            binding.tvSerialNumberResponse.text = resources.getString(R.string.lbl_serial_number_length_must_be_digits,srlNbrLength)
                        }
                    }else{
                        callSerialNumberValidate()
                    }
                }else {
                    binding.tvSerialNumberResponse.text = resources.getString(R.string.duplicate_serial)
                    binding.etSerialNumber.requestFocus()
                    binding.etSerialNumber.selectAll()
                }
            }else{
                binding.etSerialNumber.text = null
                //TODO to show the reached task qty and serial list
                navigateNext()
            }
        }
    }

    private fun callSerialNumberValidate(){
        var outboundFlag = false
        if (taskDetails?.itemSerialTracked == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY) {
            outboundFlag = true
        }
        viewModel.validateTaskSerialNumber(
            InventoryTaskSerialNumberRequest(
                containerNumber = getContainerNumber(),
                palletNumber = "",
                containerSerialNumber = binding.etSerialNumber.text.toString(),
                taskUom = "E",
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                userDirected = false,
                outBoundOnly = outboundFlag
            )
        )
    }

    /**
     * method to get container number
     */
    private fun getContainerNumber(): String {
        if (taskDetails!!.containerNbr == null) {
            return taskDetails!!.locationBarcode
        }
        return taskDetails!!.containerNbr
    }

    /**
     * method to get Transaction param details from API
     */
    private fun getTransactionParam() {
        viewModel.getItemAttributesTransactionParam(
            MPRTransParamRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                transCode = "OIA"
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.itemAttrTransParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            if (transactionParamResponse.transParams != null && transactionParamResponse.transParams.isNotEmpty()) {
                                if (transactionParamResponse.transParams[0].required) {
                                    viewModel.isOverrideItemAttributes = 1
                                } else {
                                    viewModel.isOverrideItemAttributes = 0
                                }
                            } else {
                                viewModel.isOverrideItemAttributes = 0
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to observe serial validation response
     */
    private fun subscribeSerialValidationObserver() {
        viewModel.serialValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialValidationResponse ->
                        if (serialValidationResponse.success == "true") {
                            if (serialValidationResponse.validLpn != null) {
                                if (serialValidationResponse.validLpn == "true") {
                                    addSerialNumberToTempList()
                                } else {
                                    callLookUpAPI()
                                }
                            } else {
                                FlareLog.i(TAG, "serialValidation error: $serialValidationResponse")
                                binding.tvSerialNumberResponse.text = resources.getString(R.string.validLpn_not_available)
                                binding.etSerialNumber.requestFocus()
                                binding.etSerialNumber.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                            }

                        } else {
                            FlareLog.i(TAG, "serialValidation error: $serialValidationResponse")
                            binding.tvSerialNumberResponse.text = resources.getString(R.string.invalid_serial)
                            binding.etSerialNumber.requestFocus()
                            binding.etSerialNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    /**
     * method to add valid serial numbers to main serial list
     */
    private fun addSerialNumberToTempList() {
        if (!tempSerialList.contains(binding.etSerialNumber.text.toString())) {
            tempSerialList.add(binding.etSerialNumber.text.toString())
            serialListAdapter.notifyDataSetChanged()
            binding.etSerialNumber.text = null
//            count++
//            binding.tvSerialValue.text = "($count/${taskDetails?.taskQty})"
            binding.tvSerialValue.text = String.format("%d/%d Units",viewModel.getSerialNumberList().size,viewModel.getQtyEntered())
//            if (count == taskDetails?.taskQty) {
            if (viewModel.getSerialNumberList().size == viewModel.getQtyEntered()) {
                binding.etSerialNumber.isEnabled = false
                saveFinalSerialList()
                navigateNext()
            }
        } else {
            binding.tvSerialNumberResponse.text = resources.getString(R.string.duplicate_serial)
            binding.etSerialNumber.requestFocus()
            binding.etSerialNumber.selectAll()
        }
    }

    private fun navigateNext() {
        Handler(Looper.getMainLooper()).postDelayed({
            if(taskDetails!=null) {
                if (taskDetails?.itemLotTracked != null && taskDetails?.itemLotTracked!!.isNotEmpty() &&
                    (taskDetails?.itemLotTracked == "Y" || taskDetails?.itemLotTracked == "1")
                ) {
                    val action = TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToLotTrackFragment()
                    getNavigationController().navigate(action)
                } else if (taskDetails?.itemExpDateTracked != null && taskDetails?.itemExpDateTracked!!.isNotEmpty() &&
                    (taskDetails?.itemExpDateTracked == "Y" || taskDetails?.itemExpDateTracked == "1")
                ) {
                    val action = TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToExpiryDateTrackFragment()
                    getNavigationController().navigate(action)
                } else {
                    val action = TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToContainerFragment()
                    getNavigationController().navigate(action)
                }
            }
        }, 500)
    }

    /**
     * method to save final serial list to view model
     */
    private fun saveFinalSerialList() {
        viewModel.setSerialNumberList(tempSerialList)
    }

    /**
     * method to call lookup API
     */
    private fun callLookUpAPI() {
        viewModel.getInventoryLookups(
            InventoryLookupsRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                lookupNames = "ALLOW_NEW_SERIAL_NUMBER"
            )
        )
    }

    /**
     * method to subscribe lookups observer
     */
    private fun subscribeLookUpsObserver() {
        viewModel.lookupsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                if (it.lookupCode.equals("Y", true)) {
                                    addSerialNumberToTempList()
                                } else {
                                    FlareLog.i(TAG, "lookUp error: $lookUpResponse")
                                    binding.tvSerialNumberResponse.text = resources.getString(R.string.invalid_serial)
                                    binding.etSerialNumber.requestFocus()
                                    binding.etSerialNumber.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe reserve pick stage release observer
     */
    private fun subscribeReservePickStageReleaseObserver() {
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBarStd(response.message) {
                                val action =
                                    TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToTaskgroupFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val action =
                                TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToStagingLocationFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                            getNavigationController().navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeUPCObserver() {
        viewModel.upcOrSlpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { upcOrSlpResponse ->
                        if (upcOrSlpResponse.success) {
                            navigateQtyPage()
                        } else {
                            upcOrSlpResponse.message?.let { message ->
                                showErrorMessage(message)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showErrorMessage(message: String) {
        binding.tvItemCodeResponse.text = message
        binding.etItemCode.requestFocus()
        binding.etItemCode.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etItemCode)
    }

    private fun navigateQtyPage(){
        val action = TivoALTYP11ItemSerialFragmentDirections.actionItemSerialFragmentToQtyFragment()
        getNavigationController().navigate(action)
    }

    private fun validateUPCorSLP() {
        //API call to validate the UPC or SLP code.
        viewModel.validateUPCorSLP(itemCode = binding.tvItemCodeValue.text.toString().trim(),
            upcOrSlp = binding.etItemCode.text.toString().trim())
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            binding.etItemCode.isFocused -> {
                binding.etItemCode.setText(scan?.barcode.toString())
                binding.etItemCode.text?.length?.let {
                    binding.etItemCode.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Item Code field focused")
                    validateItemCode()
                }
            }

            binding.etSerialNumber.isFocused -> {
                binding.etSerialNumber.setText(scan?.barcode.toString())
                binding.etSerialNumber.text?.length?.let {
                    binding.etSerialNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Serial Number field focused")
                    validateSerialNumber()
                }
            }

        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}