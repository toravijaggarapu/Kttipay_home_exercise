package com.fsc.flare.ui.fragment.inventory.palletizeib

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeIbPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.AUTO_GENERATE_PALLET_NUMBER
import com.fsc.flare.utils.Constants.ContainerStatus.PUTAWAY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeIbPalletNumberFragment"
/**
 * A simple PalletRepackPalletNumber
 */
@AndroidEntryPoint
class PalletizeIbPalletNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletizeIbViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeIbPalletNumberBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        viewModel.setDataToDefault()
        super.onResume()
        cb1.onVisibilityChange(true)

    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletizeIbPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.palletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.palletNumber)
                FlareLog.i(TAG, "Container field focused")
                validatePallet()
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            generatePalletNumber()
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        // Show / Hide the New Pallet button based on the transaction param configuration.
        if (viewModel.getMPRTransactionParamData() != null) {
            if (viewModel.getTransactionParamByTransCode(AUTO_GENERATE_PALLET_NUMBER))
                binding.btnNewPallet.visibility = View.VISIBLE
            else
                binding.btnNewPallet.visibility = View.GONE
        }
        // reset pallet item info
        viewModel.saveItemInfo(null, null)
        binding.palletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to generate pallet from API
     */
    private fun generatePalletNumber() {
        //Call new pallet API.
        viewModel.generatePalletCaseNumber(viewModel.palletDetailKey)
    }

    /**
     * method to validate pallet from API
     */
    private fun validatePallet() {
        if (binding.palletNumber.text.toString().trim().isNotEmpty()) {
            //Check if pallet is in temp table.
            viewModel.validateTempTablePallet(binding.palletNumber.text.toString().trim(), "")
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {

        //Get temp table data for pallet only
        viewModel.getTempTablePalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            if(containerResponse.tempLpn!=null && containerResponse.tempLpn!!.palletNumber!=null){
                                val containersList = containerResponse.tempLpn!!.containerDetails
                                if (!containersList.isNullOrEmpty()) {
                                    // save item info
                                    viewModel.saveItemInfo(containerResponse.tempLpn?.itemId,containersList[0].inventoryType)
                                    //Save the transaction identifier.
                                    viewModel.setTempTableTransactionIdentifier(containerResponse.tempLpn!!.transactionIdentifier)
                                    //Save the temp table pallet detail.
                                    viewModel.setTempTableResponse(containerResponse.tempLpn!!)
                                    viewModel.setPalletNumber(containerResponse.tempLpn!!.palletNumber)
                                    viewModel.getPalletInquiryDetail(binding.palletNumber.text.toString().trim())
                                }
                            }else{
                                viewModel.getPalletInquiryDetail(binding.palletNumber.text.toString().trim())
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    //If Pallet number not exist in temp table then fetch Pallet detail in normal table.
                    viewModel.getPalletInquiryDetail(binding.palletNumber.text.toString().trim())
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.generatePalletNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            if (generatePalletCaseNumberResponse.numbers[0].type.equals(Constants.TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                viewModel.saveItemInfo(null,null)
                                viewModel.setPalletNumber(generatePalletCaseNumberResponse.numbers[0].value)
                                navigatePalletDetail()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.palletNumber.requestFocus()
                        binding.palletNumberResponse.text = message
                        binding.palletNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.palletNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.palletDetailsResp.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletResponse ->
                        if (palletResponse.success) {
                            if (palletResponse.container.isNotEmpty()) {
                                val restrictedLockCodes: List<String> = getRestrictedLockCodes()
                                val isAllowedOnCCPendingLocation = sharedPreferencesBase.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)
                                val lockCodes: List<String>? = palletResponse.container[0].lockCodes?.mapNotNull { it.code }
                                val lockCode = palletResponse.container[0].lockCode
                                val itemCodes = palletResponse.container[0].cases?.mapNotNull { it.item?.itemCode }?.distinct()
                                val itemDesc = palletResponse.container[0].cases?.mapNotNull { it.item?.itemDesc }?.distinct()
                                val invTypes = palletResponse.container[0].cases?.mapNotNull { it.inventoryType }?.distinct()
                                val itemIds = palletResponse.container[0].cases?.mapNotNull { it.item?.itemId }?.distinct()
                                val totalQty =  palletResponse.container[0].cases?.sumOf { it.item?.itemQty ?: 0}
                                val cases: MutableList<CaseTransferContainerModel> = mutableListOf()
                                palletResponse.container[0].cases?.forEach {
                                    val case = CaseTransferContainerModel(
                                        containerNumber = it.containerNumber ?: "",
                                        itemId = it.item?.itemId.toString(),
                                        itemCode = it.item?.itemCode,
                                        currentLoc = palletResponse.container[0].currentStageLoc,
                                        itemDesc = it.item?.itemDesc,
                                        qty = it.item?.itemQty?.toLong() ?: 0L,
                                        inventoryType = it.inventoryType
                                    )
                                    cases.add(case)
                                }
                                if (palletResponse.container[0].status != PUTAWAY) {
                                    displayErrorMessage( getString(R.string.pallet_not_in_putaway))
                                } else if (lockCode == "CC" && isAllowedOnCCPendingLocation) {
                                    displayErrorMessage(getString(R.string.cycle_count_in_progress_for_given_location))
                                } else if (palletResponse.container[0].cyclePending == "Y" && !isAllowedOnCCPendingLocation) {
                                    displayErrorMessage(getString(R.string.cycle_count_is_pending_for_given_location))
                                } else if (!itemCodes.isNullOrEmpty() && itemCodes.size > 1) {
                                    displayErrorMessage(getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check))
                                } else if (!invTypes.isNullOrEmpty() && invTypes.size > 1){
                                    displayErrorMessage(getString(R.string.containers_have_different_inventory_type_can_not_palletize_together))
                                }else if (lockCodes != null && lockCodes.any { restrictedLockCodes.contains(it)}) {
                                    displayErrorMessage(getString(R.string.Pallet_which_has_damage_lock_cannot_be_allowed))
                                } else {
                                        showAlertDialog("",
                                            resources.getString(R.string.lbl_pallet_number_already_exists_do_you_want_to_use),
                                            onPositiveClick = {
                                                viewModel.saveItemInfo(itemIds?.get(0).toString(), invTypes?.get(0))
                                                viewModel.setPalletNumber(palletResponse.container[0].containerNumber)
                                                viewModel.setPalletQty(totalQty?.toLong())
                                                viewModel.setPalletNbrOfCase(palletResponse.container[0].cases?.size?.toLong())
                                                viewModel.setPalletItemCode(itemCodes?.get(0))
                                                viewModel.setPalletItemDesc(itemDesc?.get(0))
                                                viewModel.setPalletCurrentLocation(palletResponse.container[0].currentStageLoc)
                                                viewModel.setChildContainerList(cases)
                                                navigatePalletDetail()
                                            },
                                            onNegativeClick = {}
                                        )
                                }
                            }else{
                                if (viewModel.getTempTableResponse() != null) {
                                    navigatePalletDetail()
                                } else {
                                    val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
                                    val palletNumber = binding.palletNumber.text.toString().trim()
                                    if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                                        displayErrorMessage(getString( R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength))
                                    } else {
                                        showPalletCreateAlert(binding.palletNumber.text.toString().trim())
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            binding.palletNumberResponse.text = msgArray[1]
                        }else{
                            binding.palletNumberResponse.text = message
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.palletNumber.requestFocus()
        binding.palletNumberResponse.text = message
        binding.palletNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.palletNumber)
    }

    private fun getRestrictedLockCodes():List<String> {
        val restrictLocksHashMap: HashMap<String, String> = Gson().fromJson(sharedPreferencesBase.getString(PreferenceKeys.RESTRICT_LOCKS_HASH_MAP,""), object : TypeToken<HashMap<String?, String?>?>() {}.type)
        return restrictLocksHashMap.keys.toList()
    }

    private fun navigatePalletDetail() {
        binding.palletNumber.text = null
        val action = PalletizeIbPalletNumberFragmentDirections.actionPalletizeIbPalletNumberFragmentToPalletizeIbPalletDetailFragment()
        getNavigationController().navigate(action)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.palletNumber.setText(scan?.barcode.toString())
                binding.palletNumber.text?.length?.let {
                    binding.palletNumber.setSelection(it)
                    FlareLog.i(TAG, "Container field focused")
                    validatePallet()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun showPalletCreateAlert(palletNumber:String) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setMessage("There is no pallet exist with $palletNumber. Do you want to create a new pallet?")

        builder.setPositiveButton(resources.getString(R.string.alert_button_yes)) { dialogInterface, which ->
            dialogInterface.dismiss()
            viewModel.setDataToDefault()
            viewModel.saveItemInfo(null,null)
            viewModel.setPalletNumber(binding.palletNumber.text.toString().trim())
            navigatePalletDetail()
        }
        builder.setNegativeButton(resources.getString(R.string.alert_button_cancel)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            binding.palletNumber.requestFocus()
            binding.palletNumber.selectAll()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}