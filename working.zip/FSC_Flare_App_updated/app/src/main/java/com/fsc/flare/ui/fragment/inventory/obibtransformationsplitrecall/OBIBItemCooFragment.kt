package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentObIbItemCooBinding
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.ui.fragment.receiving.StartsWithFilterAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = OBIBItemCooFragment::class.java.simpleName.toString()
/**
 *  [OBIBItemCooFragment] class.
 */
@AndroidEntryPoint
class OBIBItemCooFragment : BaseFragment() {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentObIbItemCooBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getCountriesLookup()
    }

    override fun onPause() {
        super.onPause()
        binding.etScanItemCoo.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etScanItemCoo)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentObIbItemCooBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etScanItemCoo.requestFocus()
        setUpViews()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to set up views with data
     */
    private fun setUpViews() {
        val obCartonDetails = sharedViewModel.obCartonDetails
        val itemDetails = sharedViewModel.itemDetails

        obCartonDetails?.let {
            binding.tvObContainerIdValue.text = it.containerNbr
        }
        itemDetails?.let { item ->
            binding.tvItemCodeValue.text = item.itemBarcode
            binding.tvItemDescriptionValue.text = item.itemDesc
        }

        binding.tvIbCartonIdValue.text = sharedViewModel.blindIbContainerNumber.orEmpty()
        binding.tvItemLotValue.text = sharedViewModel.lotNumber.orEmpty()
        binding.tvItemExpiryValue.text = sharedViewModel.expiryDate.orEmpty()

        updateViewVisibility(sharedViewModel.lotNumber, sharedViewModel.expiryDate)
    }

    /**
     * Function to update view visibility
     */
    private fun updateViewVisibility(lotNumber: String?, expiryDate: String?) {
        // Check if lot is required and update visibility
        setViewVisibility(lotNumber, binding.tvItemLot, binding.tvItemLotValue)

        // Update visibility for Expiry Date
        setViewVisibility(expiryDate, binding.tvItemExpiry, binding.tvItemExpiryValue)
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.etScanItemCoo.setOnItemClickListener { parent, _, position, _ ->
            val regex = Regex("\\((.*?)\\)")
            val selectedItem = parent.getItemAtPosition(position) as String
            val countryCode = regex.find(selectedItem)?.groupValues?.get(1)
            val isValidCoo = validateCountryOfOrigin(countryCode)
            if(isValidCoo) {
                sharedViewModel.coo = countryCode
                navigateToNext()
            } else {
                binding.tvItemCooResponse.text = getString(R.string.lbl_invalid, countryCode)
            }
        }

        binding.etScanItemCoo.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvItemCooResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate country of origin
     */
    private fun validateCountryOfOrigin(countryCode: String?): Boolean {
        val itemDetails = sharedViewModel.itemDetails ?: return false

        // Validate the country of origin if a matching item is found
        return itemDetails.coo?.equals(countryCode, ignoreCase = true) == true
    }

    /**
     * Nav Handler to Next Screen based on tracking information of Item
     */
    private fun navigateToNext() {
        binding.etScanItemCoo.text = null
        val action = OBIBItemCooFragmentDirections.actionScanOBIBCooFragmentToScanOBIBItemQtyFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeCountriesLookupResponse()
    }

    /**
     * Function to observe countries lookup response
     */
    private fun observeCountriesLookupResponse() {
        viewModel.countriesLookUpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleCountriesLookupSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleCountriesLookupErrorResponse(response.message)
                }
                is Resource.Loading -> showProgressBar()
            }

        }
    }

    /**
     * Function to handle countries lookup success response
     */
    private fun handleCountriesLookupSuccessResponse(lookUps: LookUps?) {
        val descriptionToCodeMap = mutableMapOf<String, String>()
        lookUps?.let { lookUpResponse ->
            lookUpResponse.lookups.forEach { lookUp ->
                lookUp.lookupCodes.forEach { lookupCode ->
                    descriptionToCodeMap[lookupCode.lookupCodeDescription] = lookupCode.lookupCode
                }
            }
        }
        sharedViewModel.countriesLookup = descriptionToCodeMap
        // Create a new list with all countries lookup descriptions
        val countriesDropdownList = descriptionToCodeMap.map { (lookupCodeDescription, lookupCode) -> "$lookupCodeDescription ($lookupCode)" }.toCollection(arrayListOf())
        if (countriesDropdownList.isNotEmpty()) {
            val adapter = StartsWithFilterAdapter(requireContext(), countriesDropdownList)
            binding.etScanItemCoo.setAdapter(adapter)
        }
    }

    /**
     * Function to handle countries lookup error response
     */
    private fun handleCountriesLookupErrorResponse(message: String?) {
        message?.let {
            showErrorSnackBarStd(message = message) {}
        }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }
}