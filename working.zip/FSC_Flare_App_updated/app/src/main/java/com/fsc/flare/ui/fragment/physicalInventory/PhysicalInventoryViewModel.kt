package com.fsc.flare.ui.fragment.physicalInventory

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.cyclecount.ValidateLotOrMfgCodeResponse
import com.fsc.flare.source.data.dto.inquiry.itembarcode.Item
import com.fsc.flare.source.data.dto.inquiry.itembarcode.ItemBarcodeResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.physicalInventory.AssignBatchReq
import com.fsc.flare.source.data.dto.physicalInventory.BatchSummaryResp
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.source.data.dto.physicalInventory.ItemDetail
import com.fsc.flare.source.data.dto.physicalInventory.TaskDetail
import com.fsc.flare.source.data.dto.physicalInventory.UpdateBatchTaskReq
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.repository.PhysicalInventoryRepository
import com.fsc.flare.ui.fragment.physicalInventory.model.ContainerModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PhysicalInventoryViewModel"
private const val PHYSICAL_INVENTORY_COUNT_TYPES = "PHYSICAL_INVENTORY_COUNT_TYPES"
private const val PI_PREFERRED_CONTAINER_TYPE = "PI_PREFERRED_CONTAINER_TYPE"
private const val PI_PREFERRED_PALLET_TYPE = "PI_PREFERRED_PALLET_TYPE"
private const val PI_ACTION = "Assign"
private const val PI_STATUS_RELEASE ="Released"

@HiltViewModel
class PhysicalInventoryViewModel @Inject constructor(
    private val physicalInventoryRepository: PhysicalInventoryRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1)

    val lookUpResponse = SingleLiveEvent<Resource<LookUps>>()
    val batchSummaryResponse = SingleLiveEvent<Resource<BatchSummaryResp>>()
    val batchTaskDetailsResponse = SingleLiveEvent<Resource<BatchTaskDetailsResp>>()
    val itemBarcodeResponse = SingleLiveEvent<Resource<ItemBarcodeResponse>>()
    val containerInfoResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val validateLotOrMfgCodeResponse = SingleLiveEvent<Resource<ValidateLotOrMfgCodeResponse>>()
    val validateLotNumberResponse = SingleLiveEvent<Resource<ValidateLotNumberResponse>>()
    val serialItemIdValidationResponse = SingleLiveEvent<Resource<PickingSerialOrItemCodeResponse>>()
    val serialValidationResponse = SingleLiveEvent<Resource<InventoryTaskSerialNumberResponse>>()

    var batchSummaryResp: BatchSummaryResp? = null
    var batchTaskDetailsResp: BatchTaskDetailsResp? = null
    var selectedItem: String? = null
    var selectedItemDetails: Item? = null
    var scannedItemListIds: MutableList<Int> = mutableListOf()
    var itemDetails: MutableList<ItemDetail> = mutableListOf()
//    var previousScanQty: String? = null
    var isGivingCountSecondTime = false
    var isFirstTimeContainerScanned = true
    var isActiveLocationEmpty = false
    var casePickCountConfigType: String? = null
    var reserveCountConfigType: String? = null
    var scannedLotNumber: String? = null
    var serialList = ArrayList<String>()
    var currentScanQty: Int? = null
    val containersList = ArrayList<ContainerModel>()



    fun getPhysicalInventoryLookUps() = viewModelScope.launch {
        lookUpResponse.postValue(Resource.Loading())
        val response = physicalInventoryRepository.getLookUps(prepareLookUpsRequest())
        lookUpResponse.postValue(handleLookUpsResponse(response))

    }

    private fun handleLookUpsResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getLookUps Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "getLookUps Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getBatchSummary(batchNumber: String?, skipBatchId: String?, countType: String?) =
        viewModelScope.launch {
            batchSummaryResponse.postValue(Resource.Loading())
            val response =  physicalInventoryRepository.getBatchSummary(batchNumber, skipBatchId, countType)
            batchSummaryResponse.postValue(handleBatchSummaryResponse(response))
        }

    private fun handleBatchSummaryResponse(response: Response<BatchSummaryResp>): Resource<BatchSummaryResp>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "BatchSummary Success : $resultResponse")
//                batchSummaryResp = resultResponse
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "BatchSummary Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getBatchTaskDetails() =
        viewModelScope.launch {
            batchTaskDetailsResponse.postValue(Resource.Loading())
            val response =
                physicalInventoryRepository.getBatchTaskDetails(prepareTaskDetailsRequest())
            batchTaskDetailsResponse.postValue(handleBatchTaskDetailsResponse(response))
        }

    fun updateBatchTask(updateBatchTaskReq: UpdateBatchTaskReq?) =
        viewModelScope.launch {
            batchTaskDetailsResponse.postValue(Resource.Loading())
            val response =
                physicalInventoryRepository.updateBatchTask(updateBatchTaskReq)
            batchTaskDetailsResponse.postValue(handleBatchTaskDetailsResponse(response))
        }

    private fun handleBatchTaskDetailsResponse(response: Response<BatchTaskDetailsResp>): Resource<BatchTaskDetailsResp>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "BatchDetail Success : $resultResponse")
                batchTaskDetailsResp = resultResponse
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "BatchDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getInquiryItemInfo(itemBarcode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getInquiryItemInfo Request: $itemBarcode")
        itemBarcodeResponse.postValue(Resource.Loading())
        val response = physicalInventoryRepository.getInquiryItemInfo(itemBarcode)
        itemBarcodeResponse.postValue(handleItemInquiryResponse(response))
    }

    private fun handleItemInquiryResponse(response: Response<ItemBarcodeResponse>): Resource<ItemBarcodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ItemInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "ItemInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getContainerInfo(containerNumber: String, itemInfo: String) = viewModelScope.launch {
        containerInfoResponse.postValue(Resource.Loading())
        val response = physicalInventoryRepository.getContainerInfo(containerNumber, itemInfo)
        containerInfoResponse.postValue(handleContainerInfoResponse(response))
    }

    private fun handleContainerInfoResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "containerInfoResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "containerInfo Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun prepareUpdateTaskRequest(
        noOfContainers: Long?,
        containers: List<String>?,
        validateCount: Boolean
    ): UpdateBatchTaskReq? {
        return batchTaskDetailsResp?.let {
            UpdateBatchTaskReq(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                validateCount = validateCount,
                listOf(
                    TaskDetail(
                        countType = sharedPreferences.getString(
                            PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
                        ),
                        locationClass = batchTaskDetailsResp!!.locationClass,
                        locationBarCode = it.locationBarCode,
                        batchNumber = batchTaskDetailsResp!!.batchNumber,
                        taskId = batchTaskDetailsResp!!.taskId,
                        itemDetails = itemDetails,
                        status = PI_STATUS_RELEASE,
                        noOfContainers = noOfContainers,
                        containers = containers
                    )
                )
            )
        }
    }

    private fun prepareLookUpsRequest(): LookUpsRequest {
        return LookUpsRequest(
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            lookupNames = PHYSICAL_INVENTORY_COUNT_TYPES.plus(",")
                .plus(PI_PREFERRED_CONTAINER_TYPE).plus(",").plus(PI_PREFERRED_PALLET_TYPE)
        )
    }

    private fun prepareTaskDetailsRequest(): AssignBatchReq {
        return AssignBatchReq(
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            batchNumber = listOf(batchSummaryResp?.batchNumber!!),
            userId = userId,
            action = PI_ACTION,
            countType = sharedPreferences.getString(
                PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, ""
            )?:""
        )
    }

    fun validateLotOrMfgCodeRequest(itemId: Int,lotOrMfgCode: String) = viewModelScope.launch {
        validateLotOrMfgCodeResponse.postValue(Resource.Loading())
        val response = physicalInventoryRepository.validateLotOrMfgCodeRequest(itemId,lotOrMfgCode)
        validateLotOrMfgCodeResponse.postValue(handleValidateLotOrMfgCodeResponse(response))
    }

    private fun handleValidateLotOrMfgCodeResponse(response: Response<ValidateLotOrMfgCodeResponse>): Resource<ValidateLotOrMfgCodeResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleValidateLotOrMfgCodeResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleValidateLotOrMfgCode Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    fun validateItemLotNumber(request: ValidateLotNumberRequest) = viewModelScope.launch {
        validateLotNumberResponse.postValue(Resource.Loading())
        val response = physicalInventoryRepository.validateLotNumber(request)
        validateLotNumberResponse.postValue(handleValidateLotNumberResponse(response))
    }

    private fun handleValidateLotNumberResponse(response: Response<ValidateLotNumberResponse>): Resource<ValidateLotNumberResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateLotNumberResponseTivoPFRResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    fun validateSerialNumberOrItemCode(itemId: Int, serialNumberOrItemId: String, isOutBoundOnly: Boolean) = viewModelScope.launch {
        serialItemIdValidationResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = physicalInventoryRepository.validateSerialNumberWithItemCode(itemId,serialNumberOrItemId, isOutBoundOnly)
        serialItemIdValidationResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    private fun handleSerialNumberOrItemIdValidationResponse(response: Response<PickingSerialOrItemCodeResponse>): Resource<PickingSerialOrItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            return if (response.code() in 400..501) {
                val responseMessage = handleForwardErrorResponse(response.errorBody(), TAG)
                if (responseMessage.isEmpty()) {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: ${response.message()}")
                    Resource.Error(response.message())
                } else {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: $responseMessage")
                    Resource.Error(responseMessage)
                }
            } else {
                Resource.Error(response.message())
            }
        }
        return null
    }
}