package com.fsc.flare.ui.fragment.inquiry.inventorytransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryTransferContainerInquiryDetailBinding
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [Fragment] subclass.
 * Use the [InventoryTransferContainerInquiryDetailFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InventoryTransferContainerInquiryDetailFragment : BaseFragment() {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryTransferContainerInquiryDetailBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInventoryTransferContainerInquiryDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val containerInquiryDetail = viewModel.getInventoryTransferContainerInquiryDetail()
        binding.tvContainerValue.text = containerInquiryDetail.containerNbr
        if(containerInquiryDetail.inventoryType !=null)
        {
            binding.tvInventoryTypeValue.text = getInventoryDescription(containerInquiryDetail.inventoryType)
        }
        binding.tvItemValue.text = containerInquiryDetail.itemCode
        binding.tvDescriptionValue.text = containerInquiryDetail.description
        binding.tvQtyValue.text = containerInquiryDetail.scanQty.toString()
        binding.tvFromLocationValue.text = containerInquiryDetail.fromLocationBarcode
        binding.tvToLocationValue.text = containerInquiryDetail.toLocationBarcode
        binding.tvAreaValue.text = containerInquiryDetail.area
        binding.tvZoneValue.text = containerInquiryDetail.zone
        binding.tvAisleValue.text = containerInquiryDetail.aisle
        binding.tvBayValue.text = containerInquiryDetail.bay
        binding.tvLevelValue.text = containerInquiryDetail.level
        binding.tvPositionValue.text = containerInquiryDetail.position

        binding.btnOk.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                val action =
                    InventoryTransferContainerInquiryDetailFragmentDirections.actionInventoryTransferContainerInquiryDetailFragmentToInventoryTransferContainerInquiryFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inventoryTransferContainerInquiryFragment, true).build()
                getNavigationController().navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME_500)

        }
    }

}