package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.buildSpannedString
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.NavOptions
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentDestinationLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.KittingCompleteRequest
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.ui.fragment.kitting.ListDialogFragment
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = InvMoveKSDestinationLocationFragment::class.simpleName.toString()

/**
 * A simple [InvMoveKSDestinationLocationFragment] class.
 */
@AndroidEntryPoint
class InvMoveKSDestinationLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: InvMoveKSViewModel by activityViewModels()
    private lateinit var binding: FragmentDestinationLocationBinding

    lateinit var cb1: CustomVisibilityCallback
    private lateinit var pallet: PalletResponse

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etDestinationLocation.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentDestinationLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        pallet = viewModel.getPalletResponse()
        val item = viewModel.selectedItem
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        if (pallet.palletNumber != null) {
            binding.tvPalletNumberValue.text = pallet.palletNumber
        } else {
            binding.tvPalletNumber.visibility = View.GONE
            binding.tvPalletNumberValue.visibility = View.GONE
        }
        if (pallet.containerNumber != null && item?.lotRequired == "1") {
            binding.tvLotNumberValue.text = viewModel.lot
        } else {
            binding.tvLotNumber.visibility = View.GONE
            binding.tvLotNumberValue.visibility = View.GONE
        }

        if (pallet.containerNumber != null && item?.srlNbrReqd == "4") {
            binding.tvSerialNumberValue.text = buildSpannedString {
                append("${viewModel.fetchValidatedSerialNumberList().size} / ${viewModel.getMoveQty()}")
            }
        } else {
            binding.tvSerialNumber.visibility = View.GONE
            binding.tvSerialNumberValue.visibility = View.GONE
        }

        updateViewVisibility(binding.tvNoOfCases)
        updateViewVisibility(binding.tvNoOfCasesValue)
        binding.tvMoveQty.text = getString(R.string.transferring_qty)
        binding.tvMoveQtyValue.text = viewModel.getMoveQty()

        if (pallet.containerNumber != null && item != null) {
            if (item.qty == viewModel.getMoveQty().toInt()) {
                binding.tvLotNumber.visibility = View.GONE
                binding.tvLotNumberValue.visibility = View.GONE
                binding.tvSerialNumber.visibility = View.GONE
                binding.tvSerialNumberValue.visibility = View.GONE
            }
        }

        binding.tvKitStagingLocation.text = getString(R.string.lbl_kit_station)
        binding.tvKitStagingLocationValue.text = pallet.kitStationLocation
        if (pallet.containersList!![0].items!!.size > 1) {
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
                binding.tvTotalQtyValue.text = item.qty.toString()
            }
        } else {
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
            }
            binding.tvTotalQtyValue.text = pallet.totalQty.toString()
        }
        binding.tvNoOfCasesValue.text = pallet.noOfCase.toString()

        // Hide Kit Item Details
        binding.kittingItemLayout.visibility = View.GONE
    }

    private fun updateViewVisibility(view: View) {
        view.visibility = View.GONE
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etDestinationLocation.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
        viewSerialList()
    }

    private fun viewSerialList() {
        binding.tvSerialNumberValue.setOnClickListener {
            val items = viewModel.fetchValidatedSerialNumberList()
            val dialog = ListDialogFragment(getString(R.string.lbl_serial_numbers), items)
            dialog.show(childFragmentManager, "listDialog")
        }
    }

    private fun handleCompleteKitting() {
        pallet = viewModel.getPalletResponse()
        var itemId = 0
        var pickedQty = 0
        pickedQty = viewModel.getMoveQty().toInt()
        if (pallet.containersList!![0].items!!.size > 1) {
            val item = viewModel.selectedItem
            if (item != null) {
                itemId = item.itemId
            }
        } else {
            pallet.containersList?.get(0)?.items?.get(0)?.let { item ->
                itemId = item.itemId
            }
        }
        val containerId = pallet.containerId
        validateKittingComplete(containerId, itemId, pickedQty)
    }

    private fun validateKittingComplete(containerId: Int, itemId: Int, pickedQty: Int) {
        viewModel.inventoryMoveKSToKS(
            KittingCompleteRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                locationId = viewModel.getDestinationLocationId(),
                containerId = containerId,
                itemId = itemId,
                pickedQty = pickedQty,
                lotNumber = viewModel.lot,
                serialNumbers = viewModel.fetchValidatedSerialNumberList()
            )
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etDestinationLocation.isFocused && !binding.etDestinationLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Destination Location field focused")
                        validateDestinationLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etDestinationLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
                FlareLog.i(TAG, "Destination Location field focused")
                if (binding.etDestinationLocation.isFocused && !binding.etDestinationLocation.text.isNullOrEmpty()) {
                    validateDestinationLocation()
                }
            }
            false
        }

        binding.etDestinationLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
                binding.tvDestinationLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun validateDestinationLocation() {
        viewModel.validateDestinationLocation(binding.etDestinationLocation.text?.trim().toString())
    }

    private fun subscribeObservers() {
        observeDestinationLocation()
        observeKittingComplete()
    }

    private fun observeKittingComplete() {
        viewModel.getKittingCompleteResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { kittingCompleteResponse ->
                        if (kittingCompleteResponse.success) {
                            viewModel.serialNumberList = mutableListOf()
                            viewModel.validatedSerialNumberList = mutableListOf()
                            viewModel.setLot("", true)
                            Log.d(TAG, "observeKittingComplete: lot = ${viewModel.lot}")
                            showSuccessSnackBarStd(kittingCompleteResponse.message) {
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.invMoveKSKitStationFragment, true)
                                    .setEnterAnim(R.anim.slide_in_right)
                                    .setExitAnim(R.anim.slide_out_left)
                                    .setPopEnterAnim(R.anim.slide_in_left)
                                    .setPopExitAnim(R.anim.slide_out_right).build()
                                navController.navigate(
                                    R.id.action_invMoveKSDestinationLocationFragment_to_invMoveKSKitStationFragment,
                                    null,
                                    navOptions
                                )
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvDestinationLocationResponse.text = response.message
                    binding.etDestinationLocation.requestFocus()
                    binding.etDestinationLocation.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
                }

                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun observeDestinationLocation() {
        viewModel.getLocationResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    response.data?.let { locationResponse ->
                        if (locationResponse.success) {
                            if (locationResponse.locations.isNotEmpty()) {
                                val firstIndex = locationResponse.locations.indices.first
                                viewModel.setDestinationLocationId(locationResponse.locations[firstIndex].locationId)
                                handleCompleteKitting()
                            } else {
                                binding.tvDestinationLocationResponse.text =
                                    resources.getString(R.string.invalid_location)
                                binding.etDestinationLocation.requestFocus()
                                binding.etDestinationLocation.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvDestinationLocationResponse.text = response.message
                    binding.etDestinationLocation.requestFocus()
                    binding.etDestinationLocation.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
                }

                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        binding.etDestinationLocation.setText(scan?.barcode.toString())
        binding.etDestinationLocation.text?.length?.let {
            binding.etDestinationLocation.setSelection(it)
            validateDestinationLocation()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}