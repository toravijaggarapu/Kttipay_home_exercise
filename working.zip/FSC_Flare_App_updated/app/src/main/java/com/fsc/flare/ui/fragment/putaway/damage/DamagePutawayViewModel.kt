package com.fsc.flare.ui.fragment.putaway.damage

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.CasesBean
import com.fsc.flare.source.data.dto.PalletPrinterReq
import com.fsc.flare.source.data.dto.putawayforward.get.req.SDPutawayReq
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayForwardGetResponse
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.Location
import com.fsc.flare.source.data.dto.userdirectedputaway.PutawayRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitResponse
import com.fsc.flare.source.repository.SDPutAwayRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

const val ARG_PARAM = "displayName"
const val ARG_VALUE = "SYSTEM DIRECTED PUTAWAY"
const val PRINTER_LBL = "LBL"
const val PRINTER_PAGE = 0
const val PRINTER_PAGE_LIMIT = 100
const val TYPE_DMR = "DMR"
const val TYPE_DMC = "DMC"
const val TYPE_PALLET = "Pallet"
const val TYPE_CASE = "Case"
private const val TAG = "DamagePutawayViewModel"
const val palletDetailKey = "pallet"
const val SAVED_STATE_CALL_PRINTER = "callPrinter"

@HiltViewModel
class DamagePutawayViewModel @Inject constructor(
    private val sdPutAwayRepository: SDPutAwayRepository,
    private var sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {

    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    var isPutawayByPallet = false
    var isUserDirected = false
    var isRCLockCalled = false
    var isQHLockOnForUserDirectedPutaway = false
    val includeCCLocation = if (sharedPreferences.getBoolean(
            PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false
        )
    ) Constants.YES else Constants.NO

    fun getDamageLocationType(): String {
        return if (isPutawayByPallet) TYPE_DMR else TYPE_DMC
    }

    private fun getContainerType(): String {
        return if (isPutawayByPallet) TYPE_PALLET else TYPE_CASE
    }

    private val _containerInfoResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val containerInfoResponse: LiveData<Resource<InventoryContainerResponse>>
        get() = _containerInfoResponse

    private val _containerResponse =
        SingleLiveEvent<Resource<UserDirectedPutawayContainerResponse>>()
    val containerResponse: LiveData<Resource<UserDirectedPutawayContainerResponse>>
        get() = _containerResponse
    val newPalletDetailResponse = SingleLiveEvent<Resource<CaseTransferPalletGenerateResponse>>()
    val palletResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()

    private val _submitUDPutawayResponse =
        SingleLiveEvent<Resource<UserDirectedPutawaySubmitResponse>>()
    val submitUDPutawayResponse: LiveData<Resource<UserDirectedPutawaySubmitResponse>>
        get() = _submitUDPutawayResponse

    private val _putawayForwardGetRes = SingleLiveEvent<Resource<PutawayForwardGetResponse>>()
    val putawayForwardGetRes: LiveData<Resource<PutawayForwardGetResponse>>
        get() = _putawayForwardGetRes

    val printRequestorResponse = SingleLiveEvent<Resource<PrintRequesterResponse>>()

    private val _locationResponse = SingleLiveEvent<Resource<LocationClassRes>>()
    val locationResponse: LiveData<Resource<LocationClassRes>>
        get() = _locationResponse

    /**
     * Function to get container details
     */
    fun getContainerDetails(containerNum: String) = viewModelScope.launch {
        _containerInfoResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getContainerDetails(containerNum)
        _containerInfoResponse.postValue(handleContainerInquiryResponse(response))
    }

    /**
     * Function to handle container inquiry response
     */
    private fun handleContainerInquiryResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
            response.code(), response.errorBody(), response.message()
        )
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare Api request for Container Data
     */
    fun prepareContainerRequest(containerText: String) {
        viewModelScope.launch(dispatcher) {
            getContainer(
                UserDirectedPutawayContainerRequest(
                    custId = custId,
                    buId = buId,
                    fcyId = fcyId,
                    containerNumber = containerInfoResponse.value?.data?.container?.get(0)
                        ?.getContainerNumber(isPutawayByPallet, containerText) ?: "",
                    putAwayType = getDamageLocationType(),
                    containerType = getContainerType(),
                    includeCCLocation = includeCCLocation,
                    recallLockExists = isRCLockCalled
                )
            )
        }
    }

    /**
     * Function to get container details
     */
    private suspend fun getContainer(userDirectedPutawayContainerRequest: UserDirectedPutawayContainerRequest) {
        _containerResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.validateContainer(userDirectedPutawayContainerRequest)
        _containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * Function to handle container response
     */
    private fun handleContainerResponse(response: Response<UserDirectedPutawayContainerResponse>): Resource<UserDirectedPutawayContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun generatePalletCaseNumber() = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.generatePalletCaseNumber(palletDetailKey)
        newPalletDetailResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }


    /**
     * method to get pallet details
     */
    fun getPalletDetails(palletNumber: String) = viewModelScope.launch {
        FlareLog.i(TAG, "PalletDetails Request: containerBarcode=$palletNumber ")
        palletResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getContainerDetails(palletNumber)
        palletResponse.postValue(handlePalletResponse(response))
    }

    /**
     * method to handle pallet response
     */
    private fun handlePalletResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Pallet Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }


    /**
     * Function to prepare UD Putaway request
     */
    fun prepareSystemDirectedPutawayRequest(
        containerData: UserDirectedPutawayContainerResponse,
        palletId: String?,
    ) {
        viewModelScope.launch {
            submitUserDirectedPutaway(
                UserDirectedPutawaySubmitRequest(
                    putaway = PutawayRequest(
                        buId = buId,
                        containerIds = containerData.containerIds,
                        custId = custId,
                        fcyId = fcyId,
                        itemId = containerData.itemId,
                        itemSlotting = null,
                        location = Location(
                            locationClass = getDamageLocationType(),
                            locationId = Integer.parseInt(getLocationData().toString())
                        ),
                        palletId = palletId,
                        userDirected = isUserDirected,
                        includeCCLocation = includeCCLocation,
                        isRCLockCalled = isRCLockCalled,
                        palletNumber = getPalletNumberValue(),
                        isQHLockOnForUserDirectedPutaway = isQHLockOnForUserDirectedPutaway
                    )
                )
            )
        }
    }

    /**
     * Function to submit user directed putaway details
     */
    private suspend fun submitUserDirectedPutaway(userDirectedPutawaySubmitRequest: UserDirectedPutawaySubmitRequest) {
        _submitUDPutawayResponse.postValue(Resource.Loading())
        val response =
            sdPutAwayRepository.submitUserdirectedPutaway(userDirectedPutawaySubmitRequest)
        _submitUDPutawayResponse.postValue(handleSubmitUserDirectedPutawayResponse(response))
    }

    /**
     * Function to handle submit user directed putaway response
     */
    private fun handleSubmitUserDirectedPutawayResponse(response: Response<UserDirectedPutawaySubmitResponse>): Resource<UserDirectedPutawaySubmitResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun preparePutawayForwardRequest() {
        viewModelScope.launch(dispatcher) {
            getPutawayForward(
                SDPutawayReq(
                    fcy_id = fcyId.toString(),
                    bu_id = buId.toString(),
                    cnt_id = getPutawayContainerData().containerNbr,
                    cust_id = custId.toString(),
                    locClass = getDamageLocationType(),
                    containerType = getContainerType()
                )
            )
        }
    }

    private suspend fun getPutawayForward(putawayForwardGetReq: SDPutawayReq) {
        _putawayForwardGetRes.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getPutawayContainer(putawayForwardGetReq)
        _putawayForwardGetRes.postValue(handlePutawayForwardGetRes(response))
    }

    private fun handlePutawayForwardGetRes(response: Response<PutawayForwardGetResponse>): Resource<PutawayForwardGetResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            response.code(), response.errorBody(), response.message()
        )
        return Resource.Error(errorResponse)
    }

    /**
     * method to get printer requestor config list
     */
    fun getPrintRequesterList() = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.getPrintRequestorList(
            PrinterConfigRequest(
                fcyId = fcyId,
                page = PRINTER_PAGE,
                pageLimit = PRINTER_PAGE_LIMIT,
                printerType = PRINTER_LBL
            )
        )
        printRequestorResponse.postValue(handlePrintRequestorListResponse(response))
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handlePrintRequestorListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(), response.errorBody(), response.message()
            )
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to post Print requestor label
     */
    fun printPalletLabel(printPalletRequest: String) = viewModelScope.launch {
        if (getContainerDetail() != null) {
            val itemDetails = getContainerDetail()!!.item
            val casesArray = ArrayList<CasesBean>()
            if (itemDetails != null) {
                casesArray.add(
                    CasesBean(
                        getPutawayDetails().serialNumbers,
                        itemDetails.itemQty,
                        itemDetails.itemCode,
                        itemDetails.itemBarCode,
                        getContainerDetail()?.containerNumber
                    )
                )
            }
            sdPutAwayRepository.printPalletLabel(
                PalletPrinterReq(
                    casesArray,
                    getPalletNumberValue(),
                    1,
                    0,
                    buId = buId,
                    custId = custId,
                    fcyId = fcyId,
                    buCode = sharedPreferences.getString(PreferenceKeys.BUSINESS_UNIT_CODE, "")!!,
                    customerCode = sharedPreferences.getString(PreferenceKeys.CUST_CODE, "")!!,
                    facilityCode = sharedPreferences.getString(PreferenceKeys.FACILITY_NAME, "")!!,
                    printRequester = printPalletRequest
                )
            )
        }
    }

    /**
     * Function to prepare location api request
     */
    fun prepareLocationRequest(locationText: String) {
        viewModelScope.launch(dispatcher) {
            validateLocation(
                LocationClassReq(
                    custId,
                    fcyId,
                    locationText,
                    ""
                )
            )
        }
    }

    /**
     * Function to get location details
     */
    private suspend fun validateLocation(locationClassReq: LocationClassReq) {
        _locationResponse.postValue(Resource.Loading())
        val response = sdPutAwayRepository.validateLocation(locationClassReq)
        _locationResponse.postValue(handleLocationResponse(response))
    }

    /**
     * Function to handle location response
     */
    private fun handleLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    private var containerDetail = MutableLiveData<Container>()

    private var putAwayContainerResponse = MutableLiveData<UserDirectedPutawayContainerResponse>()
    var locationData = MutableLiveData<String>()
    private var palletNumberValue = MutableLiveData<String>()
    private var putAwayData = MutableLiveData<PutawayResponse>()
    private val defaultPrinter = MutableLiveData<String>()


    private fun getContainerDetail(): Container? {
        return containerDetail.value
    }

    fun setContainerDetail(containerInfo: Container) {
        containerDetail.value = containerInfo
    }

    fun setPutawayContainerData(container: UserDirectedPutawayContainerResponse) {
        this.putAwayContainerResponse.value = container
    }

    fun getPutawayContainerData(): UserDirectedPutawayContainerResponse {
        return putAwayContainerResponse.value!!
    }

    fun setLocationData(location: String) {
        this.locationData.value = location
    }

    fun getLocationData(): String? {
        return locationData.value
    }

    private fun getPutawayDetails(): PutawayResponse {
        return putAwayData.value!!
    }

    fun setPutawayDetails(locationId: PutawayResponse) {
        this.putAwayData.value = locationId
    }

    fun setPalletNumberValue(palletNumberValue: String?) {
        this.palletNumberValue.value = palletNumberValue
    }

    fun getPalletNumberValue(): String? {
        return palletNumberValue.value
    }

    fun getDefaultPrinter(): String?{
        return defaultPrinter.value
    }

    fun setDefaultPrinter(printerName: String?){
        this.defaultPrinter.value = printerName
    }

}