package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentContainerIdBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockRequest
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockResponse
import com.fsc.flare.source.data.dto.receiving.ItemRequest
import com.fsc.flare.source.data.dto.receiving.Locations
import com.fsc.flare.source.data.dto.receiving.LockcodeRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingResponse
import com.fsc.flare.source.data.dto.receiving.inboundshipment.InboundShipment
import com.fsc.flare.source.data.dto.receiving.item.Item
import com.fsc.flare.source.data.dto.receiving.location.Location
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumber
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.Utility
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import org.joda.time.DateTime
import java.lang.reflect.Type

private const val TAG = "ContainerIdFragment"
const val RECORD_EXISTS = "RECORD_EXISTS"

/**
 * A simple [ContainerIdFragment] class.
 */
@AndroidEntryPoint
class ContainerIdFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentContainerIdBinding
    lateinit var cb1: CustomVisibilityCallback
    private val lockCodesList = mutableListOf<LockcodeRequest>()
    private var invTypesHashMap: HashMap<String, String> = HashMap()
    private var inventoryTypeSelected : String? = null
    private var  invTypeCode : String? = null
    private lateinit var recallItemCode: String


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        invTypesHashMap = viewModel.getInventoryTypesHashMap()
        inventoryTypeSelected = viewModel.getInventoryTypeSelected()
        invTypeCode = invTypesHashMap.entries.find { it.value == inventoryTypeSelected }?.key
    }
    
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentContainerIdBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        handleTouchAndFocusEvents()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.containerId.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) =
                Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.submitReceiving.isEnabled = s?.isNotEmpty() == true
                binding.etContainerRes.text = null
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            if (event?.action == MotionEvent.ACTION_DOWN) {
                super.onTouch(v, event)
                validateContainerField()
            }
            return@setOnTouchListener true
        }

        binding.containerId.setOnEditorActionListener { v, actionId, event ->
            super.onEditorAction(v, actionId, event)
            if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "containerId action called")
                validateContainerField()
            }
            return@setOnEditorActionListener false
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeItemRecallLockResponse()
        observeSubmitReceivingResponse()
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to observe Submit receiving response
     */
    private fun observeSubmitReceivingResponse() {
        viewModel.submitReceivingResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleSuccessResponse(response.data)
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> handleErrorResponse(response.message)
            }
        }
    }

    /**
     * Function to handle submit receiving success response
     */
    private fun handleSuccessResponse(submitReceivingResponse: SubmitReceivingResponse?) {
        hideProgressBar()
        submitReceivingResponse?.let {
            FlareLog.i(TAG, "submitReceiving Response: $it")
            if (it.success) {
                handleSuccessfulSubmission(it)
            }
        }
    }

    /**
     * Function to handle submit receiving success response
     */
    private fun handleSuccessfulSubmission(submitReceivingResponse: SubmitReceivingResponse) {
        FlareLog.i(TAG, "submitReceiving Success: $submitReceivingResponse")
        clearSharedPrefValues()
        showSuccessSnackBarStd(submitReceivingResponse.message) {
            navigateToItemBarcodeFragment()
        }
    }

    /**
     * Function to handle submit receiving error response
     */
    private fun handleErrorResponse(message: String?) {
        hideProgressBar()
        binding.submitReceiving.isEnabled = true
        message?.let {
            FlareLog.e(TAG, "submitReceivingResponse Error: $it")
            if ("timeout" in it) {
                showTimeOutDialog(getString(R.string.request_in_process_msg))
            } else {
                binding.apply {
                    displayErrorMessage(it)
                }
            }
        }
    }

    /**
     * Function to setup data on to the views
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val asnData = viewModel.getAsn()
        val item = viewModel.getItem()

        item.tracking.run {
            binding.apply {
                val lotNumber = sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
                val expirationDate = sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
                lotTv.isVisible = lotRequired == "1" && !lotNumber.isNullOrEmpty()
                lot.isVisible = lotRequired == "1" && !lotNumber.isNullOrEmpty()
                lot.text = lotNumber

                dateTv.isVisible = expirationRequired == "1" && !expirationDate.isNullOrEmpty()
                date.isVisible = expirationRequired == "1" && !expirationDate.isNullOrEmpty()
                date.text = expirationDate

                cooTv.isVisible = countryOfOriginRequired == "1"
                coo.isVisible = countryOfOriginRequired == "1"
                coo.text = sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null)

                dockDoor.text = sharedPreferencesBase.getString(PreferenceKeys.Item.DD_NUMBER, null)
                asn.text = asnData.asnNumber
                packageBarcode.text = item.itemBarCode
                itemCode.text = item.itemName
                packageBarcodeDesc.text = item.description
                inventoryTypeDesc.text = viewModel.getInventoryTypeSelected()
                qty.text = sharedPreferencesBase.getString(PreferenceKeys.Item.QUANTITY_INPUT, null)
                uom.text = sharedPreferencesBase.getString(PreferenceKeys.Item.UOM_INPUT, null)
                status.text = sharedPreferencesBase.getString(PreferenceKeys.Item.STATUS_INPUT, null)
                locationId.text = sharedPreferencesBase.getString(PreferenceKeys.Item.LOCATION_ID_BARCODE, null)

                if(item.hazmatRequired == "Y"){
                    itemClassCodeTv.visibility = View.VISIBLE
                    itemClassCode.visibility = View.VISIBLE
                    itemClassCode.text = item.hazardous?.hazardClassIMDG
                    slash.visibility = View.VISIBLE
                    division.visibility = View.VISIBLE
                    division.text = item.hazardous?.hazmatDivisionText
                }
            }
        }
        binding.submitReceiving.setOnClickListener {
            super.onClick(it)
            validateContainerField()
            if(binding.submitReceiving.isEnabled) {
                getItemRecallLock(item = item)
            }
        }
        binding.containerId.onFocusChangeListener = this
    }

    /**
     * Function to retrieve Item recall lock response
     * @param item - contains Item information
     */
    private fun getItemRecallLock(item: Item) {
        val recallLockRequest = ItemRecallLockRequest(
            itemCode = item.itemName,
            asnNumber = viewModel.getAsn().asnNumber,
            lotNumber = sharedPreferencesBase.getString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO,
                null
            ),
            coo = sharedPreferencesBase.getString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN,
                null
            ),
            invType = inventoryTypeSelected,
            vendorName = viewModel.getAsn().vendorName,
            expiryDate = sharedPreferencesBase.getString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE,
                null
            ),
            status = arrayListOf("1")
        )
        val queryCombinations = generateCombinations(recallLockRequest)
        for(query in queryCombinations) {
            println(query)
        }
        viewModel._queryCombinations = queryCombinations
        viewModel.getItemRecallLock(
            ItemRecallLockRequest(
                sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
                sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
                sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toLong(),
                itemCode = item.itemName,
                status = arrayListOf("1")
            )
        )
    }

    /**
     * Function to generate the list of valid recall combinations
     */
    private fun generateCombinations(request: ItemRecallLockRequest): List<String> {
        recallItemCode = request.itemCode
        val lotNumber = request.lotNumber
        val expiryDate = request.expiryDate?.let { "expdate:$it" }
        val otherParams = listOfNotNull(
            request.invType,
            request.vendorName,
            request.asnNumber,
            request.coo
        )

        val combinations = mutableListOf<String>()

        // Function to add a combination if it's valid
        fun addValidCombination(combo: List<String>) {
            val hasLot = combo.contains(lotNumber)
            val hasExpiry = combo.contains(expiryDate)
            if ((hasLot && hasExpiry) || (!hasLot && !hasExpiry)) {
                combinations.add((listOf(recallItemCode) + combo).sorted().joinToString("+"))
                // Add recallItemCode as a standalone valid combination
                combinations.add(recallItemCode)
            }
        }

        // Generate all possible combinations
        val allParams = otherParams + listOfNotNull(lotNumber, expiryDate)
        (1..allParams.size).forEach { size ->
            allParams.combinations(size).forEach { combo ->
                addValidCombination(combo)
            }
        }

        return combinations
    }

    private fun <T> List<T>.combinations(length: Int): List<List<T>> =
        if (length == 0) listOf(emptyList())
        else this.dropLast(length - 1).flatMapIndexed { index, element ->
            this.drop(index + 1).combinations(length - 1).map { listOf(element) + it }
        }

    /**
     * Function to extract recallAttributes from recallLockDetails and form as a list
     */
    private fun extractRecallAttributes(response: ItemRecallLockResponse): List<String> {
        return response.recallLocksDetails.map { it.recallAttributes.split("+").sorted().joinToString("+") }
    }

    /**
     * Function to observe Item Recall Lock response
     */
    private fun observeItemRecallLockResponse() {
        viewModel.getItemRecallLockResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { itemRecallLockResponse ->
                        if (itemRecallLockResponse.success) {
                            FlareLog.i(TAG, "recall Lock Status ${itemRecallLockResponse.recallLocksDetails[0].status}")
                            handleItemRecallLockResponse(itemRecallLockResponse)
                        } else {
                            val asnData = viewModel.getAsn()
                            val item = viewModel.getItem()
                            val location = viewModel.getLocation()
                            submitReceivingClickListener(asnData, item, location)
                        }
                    }
                }
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let {
                        FlareLog.i(TAG, "recall Lock Error Status $it")
                        showErrorSnackBar(it)
                    }
                }
            }
        }
    }

    /**
     * Function to handle Item recall lock response
     */
    private fun handleItemRecallLockResponse(itemRecallLockResponse: ItemRecallLockResponse) {
        if(itemRecallLockResponse.recallLocksDetails.isNotEmpty()) {
            val recallLock = acquireRecallLockForCombination(itemRecallLockResponse)
            if (recallLock != null) {
                FlareLog.i("recallLock", recallLock)
            }
            when {
                 !recallLock.isNullOrBlank() && viewModel.queryCombinations.contains(recallLock) -> {
                     viewModel.isItemRecalled = true
                     showItemRecallAlertDialog(
                         getString(R.string.lbl_item_recall_lock_dialog_title),
                         getString(R.string.lbl_item_code_is_recalled_contact_the_supervisor)
                     )
                }
                else -> {
                    val asnData = viewModel.getAsn()
                    val item = viewModel.getItem()
                    val location = viewModel.getLocation()
                    submitReceivingClickListener(asnData, item, location)
                }
            }
        }
    }

    /**
     * Function to acquire recall lock for a combination applied
     */
    private fun acquireRecallLockForCombination(response: ItemRecallLockResponse): String? {
        val responseAttributes = extractRecallAttributes(response)

        for (combination in responseAttributes) {
            if (combination.contains(recallItemCode) && responseAttributes.any { it == combination }) {
                return combination
            }
        }
        return null
    }

    /**
     * Function to display Item Recall Alert dialog
     */
    private fun showItemRecallAlertDialog(title: String, message: String) {
        showWarningDialog(title, message) {
            val asnData = viewModel.getAsn()
            val item = viewModel.getItem()
            val location = viewModel.getLocation()
            submitReceivingClickListener(asnData, item, location)
        }
    }

    /**
     * Function to handle Submit Receiving Button
     * @param asnData - contains ASN information
     * @param item - contains Item information
     * @param location - contains location information
     */
    private fun submitReceivingClickListener(
        asnData: InboundShipment,
        item: Item,
        location: Location?
    ) {
            FlareLog.i(TAG, "Submit Receiving called")
            binding.submitReceiving.isEnabled = false
            viewModel.submitReceiving(
                SubmitReceivingRequest(
                    asnData.asnId,
                    asnData.asnNumber,
                    asnData.dockDoor,
                    "20",
                    sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                    invTypeCode,
                    ItemRequest(
                        binding.containerId.text.toString().trim(),
                        sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, ""),
                        sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, ""),
                        item.itemId,
                        sharedPreferencesBase.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, "")?.toIntOrNull() ?: 0,
                        item.itemBarCode,
                        "EA",
                        sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, "") ?: "",
                        "",
                        "1",
                        sharedPreferencesBase.getString(PreferenceKeys.Item.QUANTITY_INPUT, "")?.toIntOrNull() ?: 0,
                        sharedPreferencesBase.getString(PreferenceKeys.Item.UOM_INPUT, "") ?: ""
                    ),
                    Locations(
                        location?.classification ?: "",
                        sharedPreferencesBase.getString(PreferenceKeys.Item.LOCATION_ID_INPUT, "")?.toIntOrNull() ?: 0,
                        location?.status ?: "",
                        location?.locationBarcode ?: ""
                    ),
                    Utility.generateUUID(),
                    DateTime.now().toString(),
                    "ASN",
                    asnData.vendorId,
                    serialNumbers = getSerialList(),
                    lockCodes = getLockCodeList(),
                    captureNewLot = getLotCaptureFlag(),
                    firstReceipt = sharedPreferencesBase.getBoolean(PreferenceKeys.RECEIVING_FIRST_ARTICLE_INSPECTION, false),
                    item.tracking.serialNumberRequired == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY
                )
            )
    }

    /**
     * Function to validate container number
     */
    private fun validateContainerField() {
        val containerId = binding.containerId.text.toString().trim()
        // Return early if the container ID is empty
        if (containerId.isEmpty()) return
        val inboundShipment = viewModel.getAsn()
        val asnLpnsList = inboundShipment.itemLPN
        // Check if the LPN list is not empty and if the container ID is already in use
        if (asnLpnsList.isNotEmpty() && asnLpnsList.any { it.lpnId == containerId }) {
            binding.submitReceiving.isEnabled = false
            displayErrorMessage(getString(R.string.container_already_in_use_please_scan_a_blind_container))
        } else {
            // Validate the container type if it's not already in use or if the list is empty
            validateContainerType(containerId)
        }
    }


    private fun validateContainerType(containerId: String) {
        val containerType = viewModel.validateContainerType(sharedPreferencesBase, "Carton")
        binding.submitReceiving.isEnabled = false
        hideSoftKeyBoard(fragmentContext, binding.containerId)

        containerType?.let { type ->
            val isValidContainerId = containerId.startsWith(type.ctyId!!) && containerId.length == type.ctyContainerLength!!.toInt()
            if (isValidContainerId) {
                addContainerLocks(containerId)
            } else {
                binding.submitReceiving.isEnabled = false
                displayErrorMessage(getString(R.string.container_prefix_length_validation, type.ctyId, type.ctyContainerLength))
            }
        }.run {
            if (containerType == null) {
                addContainerLocks(containerId)
            }
        }
    }

    private fun addContainerLocks(containerId: String) {
        if (viewModel.addContainerLockCode(containerId, sharedPreferencesBase.getString(PreferenceKeys.RECEIVING_LOCK_CODES, "")!!)) {
            sharedPreferencesBase.edit()
                .putString(PreferenceKeys.Item.CONTAINER_ID_INPUT, containerId).apply()
            binding.submitReceiving.isEnabled = true
        } else {
            displayErrorMessage(getString(R.string.case_with_damage_lock_case_without_damage_lock_cannot_be_allowed_in_the_same_pallet))
            binding.submitReceiving.isEnabled = false
        }
    }

    /**
     * Function to clear Shared Pref values stored during receiving process
     */
    private fun clearSharedPrefValues() {
        val editor = sharedPreferencesBase.edit()
        editor.putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, "")
            .putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, "")
            .putString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, "")
            .putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, "")
            .putString(PreferenceKeys.Item.QUANTITY_INPUT, "")
            .putString(PreferenceKeys.Item.UOM_INPUT, "")
            .putString(PreferenceKeys.RECEIVING_LOT_MESSAGE, "")
            .putString(PreferenceKeys.Item.LOCATION_ID_INPUT, "")
            .putString(PreferenceKeys.SERIAL_NUM_LIST, null)
            .apply()

        viewModel.isFirstArticleInspectionLockNeeded = false
        viewModel.isItemRecalled = false
        viewModel.isItemExpired = false
        viewModel.lockCodesList.clear()
    }

    /**
     * method to get if lot number verified is new/old
     */
    private fun getLotCaptureFlag(): Boolean {
        return !sharedPreferencesBase.getString(PreferenceKeys.RECEIVING_LOT_MESSAGE, "").equals(RECORD_EXISTS)
    }

    /**
     * method to get list of selected lockcodes
     */
    private fun getLockCodeList(): List<LockcodeRequest> {
        lockCodesList.clear()
        if (viewModel.isItemRecalled) {
            addItemRecallLock()
        }
        if(viewModel.isItemExpired) {
            addItemExpiredLock()
        }
        if (viewModel.isFirstArticleInspectionLockNeeded) {
            addFirstArticleLock()
        }
        val lockCodeData = sharedPreferencesBase.getString(PreferenceKeys.RECEIVING_LOCK_CODES, null)
        if (!lockCodeData.isNullOrEmpty()) {
            val inventoryLockcode: InventoryLockcode? = Gson().fromJson(lockCodeData, InventoryLockcode::class.java)
            inventoryLockcode?.let { lockcode ->
                lockCodesList.add(LockcodeRequest(lockcode.code, lockcode.lockCodeId))
            }
        }
        return lockCodesList.distinct()
    }

    /**
     * Function to add recall lock
     */
    private fun addItemRecallLock() {
        viewModel.lockCodesList
            .firstOrNull { it.code == "RC" && it.channel == "F"}
            ?.let { inventoryLockCodeWithRC ->
                lockCodesList.add(
                    LockcodeRequest(
                        lockCode = inventoryLockCodeWithRC.code ?: "",
                        lockCodeId = inventoryLockCodeWithRC.lockCodeId ?: 0
                    )
                )
            }
    }

    private fun addItemExpiredLock() {
        viewModel.lockCodesList
            .firstOrNull { it.code == "EX" && it.channel == "F"}
            ?.let { inventoryLockCodeWithEX ->
                lockCodesList.add(
                    LockcodeRequest(
                        lockCode = inventoryLockCodeWithEX.code ?: "",
                        lockCodeId = inventoryLockCodeWithEX.lockCodeId ?: 0
                    )
                )
            }
    }

    /**
     * Function to add first article inspection lock
     */
    private fun addFirstArticleLock() {
        if (viewModel.isFirstArticleInspectionLockNeeded) {
            storeItemBarCodeToHandleNextFIADialog()
            viewModel.firstArticleLockCode?.let { lockCodeJson ->
                if (lockCodeJson != "null") {
                    val faiLockCode: InventoryLockcode? = Gson().fromJson(lockCodeJson, InventoryLockcode::class.java)
                    faiLockCode?.code?.let { code ->
                        faiLockCode.lockCodeId?.let { lockCodeId ->
                            lockCodesList.add(LockcodeRequest(code, lockCodeId))
                        }
                    }
                }
            }
        }
    }

    /**
     * Function to save item barcode to display in FAI lock dialog
     */
    private fun storeItemBarCodeToHandleNextFIADialog() {
        val item = viewModel.getItem()
        val firstArticleMsgShownList = viewModel.getFirstArticleMsgShown()

        if (item.itemBarCode !in firstArticleMsgShownList) {
            viewModel.setFirstArticleMsgShown(item.itemBarCode)
        }
    }
    /**
     * method to get valid serial numbers list from sharedPreferencesBase
     */
    private fun getSerialList(): List<SerialNumber> {
        val serialListJson = sharedPreferencesBase.getString(PreferenceKeys.SERIAL_NUM_LIST, null)
        return serialListJson?.let {
            val type: Type = object : TypeToken<List<SerialNumber?>?>() {}.type
            Gson().fromJson(it, type)
        } ?: emptyList()
    }

    private fun displayErrorMessage(message: String) {
        trackErrorMessage(message)
        binding.containerId.requestFocus()
        binding.etContainerRes.text = message
        binding.containerId.selectAll()
        showSoftKeyBoard(fragmentContext, binding.containerId)
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.containerId.setText(scan?.barcode.toString())
        showSoftKeyBoard(fragmentContext, binding.containerId)
        binding.containerId.text?.length?.let {
            binding.containerId.setSelection(
                it
            )
        }
        validateContainerField()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to display Timeout error dialog
     */
    private fun showTimeOutDialog(message: String?) {
        if (message != null) {
            showAlertDialog(message,"") {
                handleTimeoutDialogPositiveAction()
            }
        }
    }

    /**
     * Function to handle Timeout dialog positive button
     */
    private fun handleTimeoutDialogPositiveAction() {
        clearSharedPrefValues()
        navigateToItemBarcodeFragment()
    }

    /**
     * Nav handler to Item Barcode Fragment
     */
    private fun navigateToItemBarcodeFragment() {
        val bundle = bundleOf("exitflag" to "true")
        val navOptions = NavOptions.Builder()
            .setPopUpTo(R.id.itemBarcodeFragment, true)
            .build()
        getNavigationController().navigate(R.id.action_containerIdFragment_to_itemBarcodeFragment, bundle, navOptions)
    }
}
