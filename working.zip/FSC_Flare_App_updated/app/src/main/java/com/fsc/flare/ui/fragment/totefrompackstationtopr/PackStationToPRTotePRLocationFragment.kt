package com.fsc.flare.ui.fragment.totefrompackstationtopr


import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackstationToPrLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteToPRLocationRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.utils.Constants.Companion.ROOT_MENU_NAME
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackStationToPRTotePRLocationFragment"
@AndroidEntryPoint
class PackStationToPRTotePRLocationFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPackstationToPrLocationBinding
    private val viewModel: PackstationToPRViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    private val checkedTotes = ArrayList<String>()
    private val checkedShipmentCartonIds = ArrayList<Int>()
    private var screenTitle : String? = null

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    var locationId = 0

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        handleToteCountView()
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun handleToteCountView() {
        if(viewModel.getToteNumbersList().size>0)
        {
            binding.tvTotalCountValue.visibility = View.VISIBLE
            binding.tvTotalCount.visibility =View.VISIBLE
            binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString() +  " "+ getString(R.string.lbl_view)
        }else
        {
            binding.tvTotalCountValue.visibility = View.GONE
            binding.tvTotalCount.visibility =View.GONE
            getNavigationController().popBackStack()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPackstationToPrLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        requireArguments().getString(ROOT_MENU_NAME)?.let { menuName ->
            screenTitle = menuName
            binding.tvToteFromPackoutToPR.text = screenTitle
        }
        subscribeObserver()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvTotalCountValue.text = viewModel.getToteNumbersList().size.toString()  + " "+ getString(R.string.lbl_view)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePRLocation()
                }
            }
            v.onTouchEvent(event)
        }
        binding.tvTotalCountValue.setOnClickListener{
            if(viewModel.getToteNumbersList().size>0)
                showToteList()
        }
        binding.prLocationInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "StagingLocation field focused")
                validatePRLocation()
            }
            false
        }
        binding.prLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.prLocationErrRes.text = null
            }
        })
    }
    private fun showToteList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.saved_totes_cartons))
        checkedTotes.clear()
        checkedShipmentCartonIds.clear()
        val totesArray = viewModel.getToteNumbersList().toTypedArray()
        builder.setMultiChoiceItems(totesArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedTotes.add(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            }
            else
            {
                checkedTotes.remove(viewModel.getToteNumbersList()[which])
                checkedShipmentCartonIds.add(viewModel.getShipmentCartonsList()[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
            //    Log.d("debug", "Position:" + which)
            //   Log.d("debug", "isChecked Item:$"+viewModel.getToteNumbersList()[which])

        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            viewModel.removeUncheckedTotesAndCartonIds(checkedTotes,checkedShipmentCartonIds)
            handleToteCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }
    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedTotes.size>0
        if(checkedTotes.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    private fun validatePRLocation() {
        if (!binding.prLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.prLocationInput)
            viewModel.validateStagingLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    binding.prLocationInput.text.toString().trim(),
                    "PR"
                )
            )
        }else
        {
            binding.prLocationErrRes.text = "Enter PR Location"
        }
    }

    /**
     * method to update PR to pack station
     */
    private fun updatePackStation() {
        viewModel.updatePackStationToPRLocation(
            PackStationToteToPRLocationRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                destLocBarcode = binding.prLocationInput.text.toString().trim(),
                locationId = locationId,
                packStationTotes = viewModel.getToteNumbersList(),
                shipmentCartonIds = viewModel.getShipmentCartonsList()
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeObserver() {
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationClassResponse ->
                        if (locationClassResponse.success != null && locationClassResponse.success) {
                            FlareLog.i(TAG, "locationClass success: $locationClassResponse")
                            if (locationClassResponse.locations != null && locationClassResponse.locations.isNotEmpty()) {
                                if (indexExists(locationClassResponse.locations, 0)) {
                                    val location = locationClassResponse.locations[0]
                                    val locationClass = location.classification
                                    if (locationClass == "PR") {
                                        locationId = location.locationId
                                        updatePackStation()
                                    }
                                } else {
                                    displayErrorMessage("Not a valid PR location")
                                }
                            } else {
                                displayErrorMessage("Not a valid PR location")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        displayErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.toteTransferResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { toteTransferResponse ->
                        if (toteTransferResponse.success != null && toteTransferResponse.success) {
                            FlareLog.i(TAG, "toteTransferResponse success: $toteTransferResponse")
                            binding.prLocationInput.text = null
                            viewModel.resetData()
                            showSuccess(toteTransferResponse.message.toString())
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "toteTransferResponse error: $message")
                        displayErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.prLocationErrRes.text = message
        binding.prLocationInput.selectAll()
        showSoftKeyBoard(fragmentContext, binding.prLocationInput)
    }

    private fun showSuccess(message:String) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
            dialogInterface.dismiss()
            val navOptions =
                NavOptions.Builder().setPopUpTo(R.id.packStationToteToPRToteFragment, true).build()
            val bundle = bundleOf(
                ROOT_MENU_NAME to screenTitle
            )
            getNavigationController().navigate(
                R.id.action_packstationToPRLocationFragment_to_packStationToPRToteFragment,
                bundle,
                navOptions
            )
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.prLocationInput.setText(scan?.barcode.toString())
            binding.prLocationInput.text?.length?.let {
                binding.prLocationInput.setSelection(it)
            }
            FlareLog.i(TAG, "Location field focused")
            validatePRLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}