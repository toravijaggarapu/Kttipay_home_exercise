package com.fsc.flare.ui.common

import android.text.InputFilter
import android.text.Spanned

class FlareCommonInputFilter : InputFilter {
    private val allowedSpecialCharacters = charArrayOf('-', '_', '.', '\'', '@', '#', '$', '^', '+', '~', ' ')
    private val REGEX_INPUT_FILTER = "^[a-zA-Z0-9-._'@#$^+~]+(?: [a-zA-Z0-9-._'@#$^+~]+)*$"

    override fun filter(
        source: CharSequence?,
        start: Int,
        end: Int,
        dest: Spanned?,
        dstart: Int,
        dend: Int,
    ): CharSequence? {
        if (source == null) {
            return null
        }

        val filteredStringBuilder = StringBuilder()
        for (i in start until end) {
            val currentChar = source[i]
            if (currentChar.isLetterOrDigit() || allowedSpecialCharacters.contains(currentChar)) {
                filteredStringBuilder.append(currentChar.uppercaseChar())
            }
        }

        return if (filteredStringBuilder.isEmpty()) {
            "" // Return empty string if no valid characters are found
        } else {
            filteredStringBuilder.toString()
        }
    }
}
