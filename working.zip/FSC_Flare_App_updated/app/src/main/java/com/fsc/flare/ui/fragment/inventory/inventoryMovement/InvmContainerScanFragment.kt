package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmContainerScanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmContainerScanViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.NavigationFromInvmContainerScan
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "InvmContainerScanFragment"

@AndroidEntryPoint
class InvmContainerScanFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmContainerScanViewModel by viewModels()
    private lateinit var binding: FragmentInvmContainerScanBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentInvmContainerScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.tvSourceIDValue.text = sharedViewModel.sourceId
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        observeEvents()

    }

    private fun setTextChangedListener() {
        binding.scanContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun observeEvents() {

        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.incProgressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { message ->
            if(message.isNotEmpty()){
                binding.scanContainer.selectAll()
            }
            binding.errResponse.text = message ?: ""
        }

        viewModel.navigateToScreen.observe(viewLifecycleOwner) { inventoryNavigation ->
            inventoryNavigation?.let {
                when(inventoryNavigation){
                    is NavigationFromInvmContainerScan.NavigateReasonCodes -> {
                        sharedViewModel.sourceDetails = inventoryNavigation.sourceDetails
                        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                        getNavigationController().navigate(InvmContainerScanFragmentDirections.actionInvmContainerScanFragmentToInvmReasonCodeSelectFragment())
                    }
                }
            }
        }
    }

    private fun handleEnterKeyEvent() {
        binding.scanContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateContainer()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (binding.scanContainer.isFocused && !binding.scanContainer.text.isNullOrEmpty()) {
                            validateContainer()
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateContainer() {
        viewModel.validateSourceInput(binding.scanContainer.text.toString().trim())
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        binding.scanContainer.setText(scan?.barcode.toString())
        binding.scanContainer.text?.length?.let {binding.scanContainer.setSelection(it)}
        validateContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearStates()
    }
}