package com.fsc.flare.database.typeconvertors

import androidx.room.TypeConverter
import com.fsc.flare.database.utils.LogLevel

class LogLevelConvertor {

    @TypeConverter
    fun fromLogTypeValue(value: String?): LogLevel = LogLevel.valueOf(value ?: LogLevel.INFO.level)


    @TypeConverter
    fun logTypeToString(level: LogLevel?): String = level?.level ?: LogLevel.INFO.level

}