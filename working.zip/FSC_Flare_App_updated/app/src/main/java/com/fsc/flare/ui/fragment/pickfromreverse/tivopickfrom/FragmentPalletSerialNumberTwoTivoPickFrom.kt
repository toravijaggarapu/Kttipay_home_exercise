package com.fsc.flare.ui.fragment.pickfromreverse.tivopickfrom

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavDirections
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPallettSerialNoTwoTivoPickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteRequestTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoPickReverseRequest
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.TivoPFR
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject


private const val TAG = "FragmentTaskGroupPickFromReverse"

@AndroidEntryPoint
class FragmentPalletSerialNumberTwoTivoPickFrom : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentPallettSerialNoTwoTivoPickFromReserveBinding
    private var pkdQty = 0
    private var totalQty = 0

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var cb1: CustomVisibilityCallback? = null

    override fun onResume() {
        super.onResume()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1?.onVisibilityChange(true)
        binding.btnStage.isEnabled = viewModel.getTasksCompletedList()?.isNotEmpty() == true
        init()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPallettSerialNoTwoTivoPickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etPalletSerialNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvError.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    FlareLog.i(TAG, "PalletNumber field focused")

                    validatePalletSerialNumber()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etPalletSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletSerialNumber)
                FlareLog.i(TAG, "etPalletSerialNumber field focused")
                validatePalletSerialNumber()
            }
            false
        }

        setListener()
    }

    private fun updatePickedQuantity() {
        binding.tvPickedQuantityValue.text = if (pkdQty > 1) "$pkdQty pallets" else "$pkdQty pallet"

    }

    private fun init(isCalledFromApiResponse:Boolean=false) {
        pkdQty = 0
        viewModel.getPickTaskDetails()?.let {
            binding.tvTaskIdValue.text = it.taskId.toString()
            binding.itemCodeValue.text = it.itemCode
            binding.tvDescValue.text = it.itemDescription
            binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} pallets" else "${it.taskQty} pallet"
            updatePickedQuantity()
            totalQty = it.taskQty
            binding.tvPalletNumberValue.text = it.containerNbr
            binding.tvLocationValue.text = it.locationBarcode

            if (!viewModel.isSerialNumberField()) {
                binding.tvPalletSerialNumber.text = getString(R.string.pallet_number)
                binding.etPalletSerialNumber.hint = getString(R.string.pallet_number)
            } else {
                if (viewModel.isNumberField()) {
                    binding.tvPalletSerialNumber.text = getString(R.string.pallet_serial_number)
                    binding.etPalletSerialNumber.hint = getString(R.string.pallet_serial_number)
                }
            }

            // If function called mark task complete api response
            if(isCalledFromApiResponse)
                return
            // Check if next task is for case
            val action = checkNextTaskType(it)
            if (action != null) {
                moveToFragment(action)
            }
        }
    }

    private fun setListener() {
        binding.btnUserPick.setOnClickListener {
            val action =
                FragmentPalletSerialNumberTwoTivoPickFromDirections.actionPalletSerialNumberTwoTivoPickFromFragmentToPalletSerialNumberOneTivoPickFromFragment()
            moveToFragment(action)
        }

        binding.btnStage.setOnClickListener {
            val action =
                FragmentPalletSerialNumberTwoTivoPickFromDirections.actionPalletSerialNumberTwoTivoPickFromFragmentToStagingLocationTivoPickFromFragment()
            moveToFragment(action)
        }
    }

    private fun validatePalletSerialNumber() {
        val palletSerialNumber = binding.etPalletSerialNumber.text.toString().trim()
        if (palletSerialNumber.isEmpty()) {
            if(viewModel.isSerialNumberField())
            {
                binding.tvError.text = getString(R.string.alert_enter_pallet_serial_number)
            }else
            {
                binding.tvError.text = getString(R.string.alert_enter_pallet_number)
            }
        } else {
            binding.tvError.text = ""
            hitApi()
        }
    }
    private fun hitApi() {

        val palletSerialNumber = binding.etPalletSerialNumber.text.toString().trim()
        val viewTaskPalletNumber = viewModel.getPickTaskDetails()?.containerNbr
        binding.tvError.text =""
            if (viewModel.isSerialNumberField()) {
                if(palletSerialNumber == viewTaskPalletNumber)
                {
                    pkdQty = 1
                    markTaskComplete()
                }else{
                    val request = ValidatePalletContainerSerialNumberTivoPickReverseRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        userDirected = false,
                        taskUom = "P",
                        containerSerialNumber = palletSerialNumber,
                        palletNumber = viewTaskPalletNumber
                    )
                    viewModel.validatePalletContainerSerialNumberTivoPickFromReserve(request, TivoPFR.VALIDATE_PALLET_SERIAL_NUMBER)
                }

        } else {
                // If matched push move to staging screen
            if(palletSerialNumber == viewTaskPalletNumber) {
                    pkdQty = 1
                    markTaskComplete()
                    // moveToStagingScreen()
                }
                else {
                    // Show the error
                    binding.tvError.text = getString(R.string.invalid_pallet_number)
                    // validatePalletSerialNumber()
                }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun markTaskComplete() {

        binding.tvError.text = ""
        viewModel.getPickTaskDetails()?.let {
            val request = MarkTaskCompleteRequestTivoPFR(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskId = it.taskId,
                taskDetId = it.taskDetId,
                pickQty = pkdQty,
                pickQtyUom = it.taskQtyUom,
                taskGroup = "PFR",
                lotNumber = it.lotNumber,
                expDate = "",
                palletId = it.containerId.toString(),
                palletNumber = it.containerNbr,
                userDirected = false,
                serialTracked = it.itemSerialTracked
            )
            // If current task has lot track or expired track than move to that screen
            val action = checkCurrentTaskType()
            if (action != null) {
                viewModel.markTaskCompleteRequest=request
                moveToFragment(action)
            }
            else {
                viewModel.taskReservePickCompleteTivoPFR(request)
            }
        }
    }

    private fun subscribeObservers() {

        viewModel.palletContainerSerialNumberValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tivoResponse ->
                        if (tivoResponse.success) {
                            binding.etPalletSerialNumber.setText("")
                            FlareLog.i(TAG, "tivo Response success: $tivoResponse")
                            pkdQty++
                            updatePickedQuantity()
                            if (pkdQty == totalQty) {
                                markTaskComplete()
                            }
                        } else {
                            binding.tvError.text = getString(R.string.invalid_pallet_serial_number)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        // showErrorSnackBar(message)
                        binding.tvError.text = getString(R.string.invalid_pallet_serial_number)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.markTaskCompleteTivoPFRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success == true) {
                            binding.etPalletSerialNumber.setText("")
                            FlareLog.i(TAG, "markTaskCompleteTivoPFRResponse success: $taskpickResponse")
                            saveCompletedTask()
                            updatePickedQuantity()
                            binding.btnStage.isEnabled = true
                            if (taskpickResponse.taskDetails == null) {
                                //showErrorSnackBar(taskpickResponse.message ?: "")
                                showSuccessSnackBar(taskpickResponse.message ?: getString(R.string.alert_all_tasks_completed))
                                binding.btnStage.performClick()
                            }else
                            {
                                taskpickResponse.taskDetails.let {
                                    val action = checkNextTaskType(it)
                                    viewModel.setPickTaskDetails(it)
                                    if (action == null) {
                                        init(true)
                                    } else {
                                        moveToFragment(action)
                                    }
                                }
                            }
                        } else {
                            showSuccessSnackBar(taskpickResponse.message ?: "")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")

                        showErrorSnackBar(message)
                    }

                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.containerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tivoResponse ->
                        if (tivoResponse.container.isNotEmpty()) {
                            binding.etPalletSerialNumber.setText("")
                            FlareLog.i(TAG, "tivo Response success: $tivoResponse")
                            pkdQty++
                            updatePickedQuantity()
                            if (pkdQty == totalQty) {
                                binding.btnStage.isEnabled = true
                                markTaskComplete()
                            }
                        } else {
                            binding.tvError.text = getString(R.string.invalid_container_serial_number)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                        binding.tvError.text = message
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun saveCompletedTask() {
        var taskList = viewModel.getTasksCompletedList()
        if (taskList == null) {
            taskList = ArrayList()
        }

        taskList.add(viewModel.getPickTaskDetails())
        viewModel.setTasksCompletedList(taskList)

    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etPalletSerialNumber.setText(scan?.barcode.toString())
            binding.etPalletSerialNumber.text?.length?.let {
                binding.etPalletSerialNumber.setSelection(
                    it
                )
                FlareLog.i(TAG, "pallet serial number field focused")
                validatePalletSerialNumber()
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb
        cb?.onVisibilityChange(true)
    }

    private fun checkCurrentTaskType(): NavDirections? {
        return viewModel.getPickTaskDetails()?.let {
            val isLotTracked = it.itemLotTracked
            val isExpiredTracked = it.itemExpDateTracked
            val action =
                when {
                    isLotTracked != "0" -> {
                        FragmentPalletSerialNumberTwoTivoPickFromDirections.actionPalletSerialNumberTwoTivoPickFromFragmentToLotNumberTivoPickFromFragment()
                    }
                    isExpiredTracked != "0" -> {
                        FragmentPalletSerialNumberTwoTivoPickFromDirections.actionPalletSerialNumberTwoTivoPickFromFragmentToExpiryDateTivoPickFromFragment()
                    }
                    else -> {
                        null
                    }
                }

            action
        }
    }

    private fun checkNextTaskType(taskDetail: TaskDetails): NavDirections? {
        return taskDetail.let {
            val serialTracked = it.itemSerialTracked
            val uom = it.taskQtyUom.lowercase(Locale.ROOT)
            val action =
                if ((serialTracked == "1" && uom == "cases") || (serialTracked == "0" && uom == "cases") || (serialTracked == "4" && uom == "cases")) {
                    FragmentPalletSerialNumberTwoTivoPickFromDirections.actionPalletSerialNumberTwoTivoPickFromFragmentToContainerSerialNumberTivoPickFromFragment()
                } else
                {
                    null
                }


            action

        }
    }
}