package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementSubTaskGroupBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementSubGroupFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementSubGroupFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var partsReplacemenSubTaskBinding: FragmentPartsReplacementSubTaskGroupBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacemenSubTaskBinding =
            FragmentPartsReplacementSubTaskGroupBinding.inflate(inflater, container, false)
        partsReplacemenSubTaskBinding.lifecycleOwner = this
        viewModel.setTaskTypeOptions()
        return partsReplacemenSubTaskBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        subscribeObservers()
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        partsReplacemenSubTaskBinding.tasktypeDropDown.setOptions(viewModel.getTaskTypeOptions())

        partsReplacemenSubTaskBinding.tasktypeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->

            if (selection.trim() == Constants.PartsReplacement.MOVE_PARTS_TO_REPAIR.trim()) {
                navigateToPartsReplacementRepairFragment()
            } else if (selection.trim() == Constants.PartsReplacement.MOVE_PARTS_TO_PUTAWAY.trim()) {
                createCart()
            }
        }
    }

    private fun createCart() {
        viewModel.getRepairTaskRf(
            GetRepairTaskRf(
                partRunnerCart = "",
                taskType = Constants.PartsReplacement.TASK_TYPE_PUTAWAY,
                taskgroup = Constants.PartsReplacement.TASK_GROUP_TNR,
                actionType = Constants.PartsReplacement.ACTION_TYPE_GET
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.getRepairTaskRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { moveTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(moveTaskRfResponse)
                        FlareLog.e(TAG, "subgroup getMoveTaskRfResponse : ${moveTaskRfResponse.toString()}")
                        navigateToPartsReplacementPutawayFragment()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "getMoveTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                else -> {}
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun hideProgressBar() {
        partsReplacemenSubTaskBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacemenSubTaskBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun displayErrorMessage(errorMessage: String) {
        showErrorSnackBar(errorMessage)
    }

    private fun navigateToPartsReplacementRepairFragment() {
        val action =
            PartsReplacementSubGroupFragmentDirections.actionPartsReplacementTaskTypeFragmentToPartsReplacementCartFragment()
        findNavController().navigate(action)
    }

    private fun navigateToPartsReplacementPutawayFragment() {
        val action =
            PartsReplacementSubGroupFragmentDirections.actionPartsReplacementTaskTypeFragmentToPartsReplacementPartsContainerFragment()
        findNavController().navigate(action)
    }
}