package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSCReverseFromContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContDetailsRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContPutawayDetails
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SCReverseFromContainerFragment"

@AndroidEntryPoint
class SCReverseFromContainerFragment : BaseFragment(), FlareScannable {

    private val viewModel: SplitContainerReverseViewModel by activityViewModels()
    private lateinit var binding: FragmentSCReverseFromContainerBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    var channelType = ""
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSCReverseFromContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding.etFromContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtFromContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etFromContainer.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.etFromContainer.isFocused && !binding.etFromContainer.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "FromContainer field focused")
            validateFromContainerAPI()
        }
    }


    /**
     * method to validate from container field from API
     */
    private fun validateFromContainerAPI() {
        viewModel.validateFromContainer(
            SplitContDetailsRequest(
                dataSource = "RF",
                putaway = SplitContPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    channel = ""
                )
            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribefromContObserver()
    }


    /**
     * method for fromContainer response observer
     */
    private fun subscribefromContObserver() {
        viewModel.fromContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { fromConRes ->
                        FlareLog.i(TAG, "fromContainer response: ${response.data}")
                        when (fromConRes.statusHandler?.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "fromContainer Error response: ${fromConRes.statusHandler.error}")
                                binding.etFromContainer.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etFromContainer)
                                binding.txtFromContainerResponse.text = fromConRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "fromContainer Success response: $fromConRes")
                                sharedPreferences.edit().putString(PreferenceKeys.SC_FROM_CONT, binding.etFromContainer.text.toString()).apply()

                                if (fromConRes.container.channel != null) {
                                    channelType = fromConRes.container.channel
                                    sharedPreferences.edit().putString(PreferenceKeys.SC_CHANNEL_TYPE, channelType).apply()

                                    when (channelType) {
                                        "R" -> {
                                            val navController =
                                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                            val action = SCReverseFromContainerFragmentDirections.actionSCReverseFromContFragmentToSCReverseSKUFragment()
                                            navController.navigate(action)
                                        }
                                        "F" -> {
                                            val navController =
                                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                            val action = SCReverseFromContainerFragmentDirections.actionSCReverseFromContFragmentToSCReverseItemBarcodeFragment()
                                            navController.navigate(action)
                                        }
                                    }
                                } else {
                                    binding.etFromContainer.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etFromContainer)
                                    binding.txtFromContainerResponse.text = resources.getString(R.string.channel_type_not_available)
                                }
                            }
                            else ->
                                FlareLog.e(TAG, "fromContainer : ${response.data.statusHandler?.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "fromContainer: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }




    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etFromContainer.setText(scan?.barcode.toString())
                binding.etFromContainer.text?.length?.let {
                    binding.etFromContainer.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "FromContainer field focused")
                    validateFromContainerAPI()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}