package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutInventoryTypesBinding
import com.fsc.flare.log.FlareLog
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "PackoutInventoryTypesFragment"
@AndroidEntryPoint
class PackoutInventoryTypesFragment: BaseFragment() {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutInventoryTypesBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutInventoryTypesBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        setupData()
        return binding.root
    }

    fun setupData(){
        binding.tvDockDoorValue.text=viewModel.getLocationBarcode()
        if(viewModel.getPalletReqNumber()=="") {
            binding.tvPallet.visibility = View.GONE
        }
        else{
            binding.tvPalletValue.text=viewModel.getPalletReqNumber()
        }
        binding.tvCartonValue.text=viewModel.getcartonReqNumber()
        binding.itemCode.text=viewModel.getitemData()
        binding.tvDescValue.text=viewModel.getItemDesc()

        if(viewModel.lotNumberSelectedFromDeKitting) {
            binding.tvLotNumber.visibility = View.VISIBLE
            binding.tvLotValue.visibility = View.VISIBLE
            binding.tvLotValue.text = viewModel.getlotNumber()
        }
        else {
            handleLotNumber()
        }

        binding.btnEndPackout.isEnabled=false
    }

    private fun handleLotNumber() {
        if (!viewModel.getLocationData().locations.isNullOrEmpty()) {

            val taskDetails = viewModel.getLocationData().locations[0].items.filter { it.itemId == viewModel.getItemId() }[0]
            val tracking = taskDetails.tracking

            if (tracking.lotRequired == 1 && !taskDetails.lotNumber.isNullOrEmpty()) {
                binding.tvLotNumber.visibility = View.VISIBLE
                binding.tvLotValue.visibility = View.VISIBLE
                binding.tvLotValue.text = taskDetails.lotNumber
            }
        }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    fun setupClickListeners(){
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
            Log.d("debug", "BackButton Clicked")
            navigateToBackSreen()
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val invTypesList = ArrayList<String>()
        for(invType in viewModel.getInvTypes(viewModel.currentItemBarCode)) {
            var invTypeData = getInventoryDescription(invType)
            invTypesList.add(invTypeData)
        }

        binding.invTypeSpinner.setOptions(invTypesList)

        binding.invTypeSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            validateField()
        }
    }

    fun navigateToBackSreen() {
        findNavController().popBackStack()
    }

    private fun validateField() {
        binding.invTypeSelectionError.text=""
        if(binding.invTypeSpinner.text == getString(R.string.lbl_select_inventory_type)) {
            binding.invTypeSelectionError.text = getString(R.string.lbl_select_inventory_type)
        }
        else {

            val selectedInvType = binding.invTypeSpinner.text.toString();
            val selectedHashMap = getInventoryHashMap().filter { (key, value) -> value == selectedInvType}
            viewModel.setInventoryType(selectedHashMap.keys.first())

            // Show LockCodesFragment
            val action = PackoutInventoryTypesFragmentDirections.actionPackoutInventoryTypesFragmentToPackoutLockCodeFragment()
            moveToFragment(action)
        }
    }

}