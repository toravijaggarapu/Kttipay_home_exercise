package com.fsc.flare.ui.fragment.pickfromreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStageDetailsPickFromReverseBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "FragmentStageDetailsPickFromReverse"

@AndroidEntryPoint
class FragmentStageDetailsPickFromReverse : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentStageDetailsPickFromReverseBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStageDetailsPickFromReverseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getStageTaskDetails()
        if(data != null){
            binding.containerIdTvRes.text = data.obContainerNumber
            binding.itemCodeTvRes.text = data.itemCode
            binding.desTvRes.text = data.itemDesc
            binding.quantityTvRes.text = String.format("%d %s",data.pickQty,data.pickQtyUom)
            binding.stagingLocationTvRes.text = data.stageLocationName
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    updateStaging()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.stagingLocationedt.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.stagingLocationedt)
                FlareLog.i(TAG, "stagingLocation field focused")
                updateStaging()
            }
            false
        }
    }

    private fun updateStaging() {
        if (!binding.stagingLocationedt.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.stagingLocationedt)
            val data = viewModel.getStageTaskDetails()
            if (data != null) {
                viewModel.reservepickstageupdate(
                    ReservePickStageRequest(
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        data.itemCode,
                        data.itemDesc,
                        data.obContainerId,
                        data.obContainerNumber,
                        data.pickQty,
                        data.pickQtyUom,
                        data.stageLocationBarcode,
                        data.stageLocationId,
                        data.stageLocationName,
                        data.taskId
                    )
                )
            }
        }
    }

    private fun subscribeObservers() {
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) {reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBarStd(response.message) {
                                val action =
                                    FragmentStageDetailsPickFromReverseDirections.actionPickFromReserveStageFragmentToPickFromReserveFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action =
                                FragmentStageDetailsPickFromReverseDirections.actionPickFromReserveStageFragmentToPickFromReserveStageFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickFromReserveStageFragment, true).build()
                            navController.navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.stagingLocationedt.setText(scan?.barcode.toString())
            binding.stagingLocationedt.text?.length?.let {
                binding.stagingLocationedt.setSelection(it)
            }
            FlareLog.i(TAG, "Staging Loc field focused")
            updateStaging()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}