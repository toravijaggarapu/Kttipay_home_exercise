package com.fsc.flare.ui.fragment.inventory.invmovekitstationtokitstation

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentMoveQtyBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.PalletResponse
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "MoveQtyFragment"

/**
 * A simple [InvMoveKSQtyFragment] class.
 */
@AndroidEntryPoint
class InvMoveKSQtyFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: InvMoveKSViewModel by activityViewModels()
    private lateinit var binding: FragmentMoveQtyBinding
    private lateinit var pallet: PalletResponse

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.etMoveQty.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etMoveQty)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentMoveQtyBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvKitting.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        pallet = viewModel.getPalletResponse()
        if (pallet.containerNumber != null) {
            binding.tvCaseNumberValue.text = pallet.containerNumber
        } else {
            binding.tvCaseNumber.visibility = View.GONE
            binding.tvCaseNumberValue.visibility = View.GONE
        }
        if (pallet.palletNumber != null) {
            binding.tvPalletNumberValue.text = pallet.palletNumber
        } else {
            binding.tvPalletNumber.visibility = View.GONE
            binding.tvPalletNumberValue.visibility = View.GONE
        }

        if (pallet.containersList!![0].items!!.size > 1) {
            val item = viewModel.selectedItem
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
                binding.tvTotalQtyValue.text = item.qty.toString()
            }
        } else {
            val item = viewModel.selectedItem
            if (item != null) {
                binding.tvItemNameValue.text = item.itemName
                binding.tvItemDescValue.text = item.itemDesc
            }
            binding.tvTotalQtyValue.text = pallet.totalQty.toString()
        }
        binding.tvKitStagingLocation.text = getString(R.string.lbl_kit_station)
        binding.tvKitStagingLocationValue.text = pallet.kitStationLocation

        // Hide Kit Item Details
        binding.kittingItemLayout.visibility = View.GONE
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etMoveQty.requestFocus()
        handleTouchAndFocusEvents()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etMoveQty)
                    if (binding.etMoveQty.isFocused && !binding.etMoveQty.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Qty field focused")
                        validateMoveQty()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etMoveQty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etMoveQty)
                if (binding.etMoveQty.isFocused && !binding.etMoveQty.text.isNullOrEmpty()) {
                    FlareLog.i(TAG, "Qty field focused")
                    validateMoveQty()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etMoveQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etMoveQty)
                binding.tvQtyErrorResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun validateMoveQty() {
        if (pallet.containersList!![0].items!!.size > 1) {
            val item = viewModel.selectedItem
            if (item != null) {
                when {
                    binding.etMoveQty.text.toString().trim().isEmpty() -> {
                        binding.tvQtyErrorResponse.text = getString(R.string.error_empty_qty)
                    }

                    binding.etMoveQty.text.toString().trim().toInt() == 0 -> {
                        binding.tvQtyErrorResponse.text = getString(R.string.qty_cannot_ero)
                    }

                    binding.etMoveQty.text.toString().trim().toInt() <= item.qty -> {
                        viewModel.setMoveQty(binding.etMoveQty.text.toString())
                        navigateToNext()
                    }

                    else -> {
                        binding.tvQtyErrorResponse.text =
                            getString(R.string.container_qty_exceed_error)
                    }
                }
            }
        } else {
            when {
                binding.etMoveQty.text.toString().trim().isEmpty() -> {
                    binding.tvQtyErrorResponse.text = getString(R.string.error_empty_qty)
                }

                binding.etMoveQty.text.toString().trim().toInt() == 0 -> {
                    binding.tvQtyErrorResponse.text = getString(R.string.qty_cannot_ero)
                }

                binding.etMoveQty.text.toString().toInt() <= pallet.totalQty -> {
                    viewModel.setMoveQty(binding.etMoveQty.text.toString())
                    navigateToNext()
                }

                else -> {
                    binding.tvQtyErrorResponse.text = getString(R.string.container_qty_exceed_error)
                }
            }
        }
    }

    private fun navigateToNext() {
        val item = viewModel.selectedItem
        if (item != null) {
            when {
                item.lotRequired == "1" -> {
                    navController.navigate(R.id.action_invMoveKSQtyFragment_to_invMoveKSLotFragment)
                }

                item.srlNbrReqd == "4" -> {
                    navController.navigate(R.id.action_invMoveKSQtyFragment_to_invMoveKSSerialFragment)
                }

                else -> {
                    navController.navigate(R.id.action_invMoveKSQtyFragment_to_invMoveKSDestinationLocationFragment)
                }
            }
        }
    }
}