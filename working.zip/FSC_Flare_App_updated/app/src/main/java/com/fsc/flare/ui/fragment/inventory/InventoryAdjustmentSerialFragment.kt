package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberRequest
import com.fsc.flare.ui.fragment.receiving.SerialAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryAdjustmentSerialFragment"

@AndroidEntryPoint
class InventoryAdjustmentSerialFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: SerialAdapter

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentPickCartSerialBinding
    private var tempSerialList = ArrayList<String>()
    private var count = 0
    val serialNumberList = mutableListOf<String>()
    private var containerData: Container? = null

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPickCartSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeSerialValidationObserver()
        subscribeLookUpsObserver()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val containerList = viewModel.getContainerInfo()
        if (containerList != null) {
            if (containerList.isNotEmpty()) {
                containerData = containerList[0]
                if (containerData?.item != null) {
                    binding.tvSerialValue.text = String.format("%d/%d",count,containerData?.updatedQty)
                }
            }
        }

        setupRecyclerView()

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                    FlareLog.i(TAG, "SerialNo field focused")
                    if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                        validateSerialNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerialNumber.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                FlareLog.i(TAG, "SerialNo field focused")
                if (binding.etSerialNumber.isFocused && !binding.etSerialNumber.text.isNullOrEmpty()) {
                    validateSerialNumber()
                }
            }
            false
        }
    }


    /**
     * method to verify serial number from API
     */
    private fun validateSerialNumber() {
        if (containerData != null) {
            viewModel.validateTaskSerialNumber(
                InventoryTaskSerialNumberRequest(
                    containerNumber = containerData?.containerNumber!!,
                    palletNumber = "",
                    containerSerialNumber = binding.etSerialNumber.text.toString(),
                    taskUom = "E",
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    userDirected = false,
                    outBoundOnly = false
                )
            )
        }
    }

    /**
     * method to subscribe serial number validation
     */
    private fun subscribeSerialValidationObserver() {
        viewModel.serialValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialValidationResponse ->
                        if (serialValidationResponse.success == "true") {
                            if (serialValidationResponse.validLpn == "true") {
                                addSerialNumberToTempList()
                            } else {
                                callLookUpAPI()
                            }
                        } else {
                            FlareLog.i(TAG, "serialValidation error: $serialValidationResponse")
                            binding.tvSerialNumberResponse.text = resources.getString(R.string.invalid_serial)
                            binding.etSerialNumber.requestFocus()
                            binding.etSerialNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    /**
     * method to call lookup API
     */
    private fun callLookUpAPI() {
        viewModel.getInventoryLookups(
            InventoryLookupsRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                lookupNames = "ALLOW_NEW_SERIAL_NUMBER"
            )
        )
    }

    /**
     * method to subscribe lookups observer
     */
    private fun subscribeLookUpsObserver() {
        viewModel.lookupsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                if (it.lookupCode.equals("Y", true)) {
                                    addSerialNumberToTempList()
                                } else {
                                    FlareLog.i(TAG, "lookUp error: $lookUpResponse")
                                    binding.tvSerialNumberResponse.text = resources.getString(R.string.invalid_serial)
                                    binding.etSerialNumber.requestFocus()
                                    binding.etSerialNumber.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etSerialNumber)
                                }
                            }
                        }

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to save final serial list to view model
     */
    private fun saveFinalSerialList() {
        viewModel.setSerialNumberList(tempSerialList)
    }

    /**
     * method to add valid serial numbers to main serial list
     */
    private fun addSerialNumberToTempList() {
        if (!tempSerialList.contains(binding.etSerialNumber.text.toString())) {
            tempSerialList.add(binding.etSerialNumber.text.toString())
            serialListAdapter.notifyDataSetChanged()
            binding.etSerialNumber.text = null
            count++
            binding.tvSerialValue.text = String.format("%d/%d",count,containerData?.updatedQty)
            if (count == containerData?.updatedQty) {
                binding.etSerialNumber.isEnabled = false
                count = 0
                saveFinalSerialList()
                Handler(Looper.getMainLooper()).postDelayed({
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        InventoryAdjustmentSerialFragmentDirections.actionInventoryAdjustmentSerialFragmentToInventoryAdjustmentReasonFragment()
                    navController.navigate(action)
                }, 500)
            }
        } else {
            binding.tvSerialNumberResponse.text = resources.getString(R.string.duplicate_serial)
            binding.etSerialNumber.requestFocus()
            binding.etSerialNumber.selectAll()
        }
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        binding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = SerialAdapter(tempSerialList)
        binding.rvSerial.adapter = serialListAdapter
    }

    /**
     * method to hide progressbar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    /**
     * method to show progressbar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etSerialNumber.setText(scan?.barcode.toString())
                binding.etSerialNumber.text?.length?.let {
                    binding.etSerialNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "SerialNumber field focused")
                    validateSerialNumber()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}