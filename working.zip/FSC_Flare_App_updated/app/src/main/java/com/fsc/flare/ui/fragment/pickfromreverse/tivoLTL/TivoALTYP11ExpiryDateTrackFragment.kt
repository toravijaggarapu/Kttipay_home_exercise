package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLExpiryDateTrackBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

private const val TAG = "TivoALTYP11ExpiryDateTrackFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [TivoALTYP11ExpiryDateTrackFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11ExpiryDateTrackFragment : BaseFragment(){

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLExpiryDateTrackBinding
    private var taskDetails: TaskDetails? = null

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLExpiryDateTrackBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        taskDetails = viewModel.getPickTaskDetails()
        binding.tvTaskIdValue.text = taskDetails?.taskId.toString()
        binding.tvItemCodeValue.text = taskDetails?.itemCode
        binding.tvDescriptionValue.text = taskDetails?.itemDescription
        binding.tvPickQtyValue.text = String.format("%d Units", taskDetails?.taskQty)
//        binding.tvPickedQtyValue.text = "0 Units"
        binding.tvPickedQtyValue.text = resources.getQuantityString(R.plurals.pallet_transfer_units, viewModel.getQtyEntered(), viewModel.getQtyEntered())
        binding.tvLocationValue.text = taskDetails?.locationBarcode


        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            binding.date.text = sdf.format(cal.time)
            if (!binding.date.text.isNullOrEmpty()) {
                val taskData = viewModel.getPickTaskDetails()
                if (taskData != null) {
                    when {
                        viewModel.isOverrideItemAttributes == 1 -> {
                            saveExpiryDate(binding.date.text.toString())
                        }
                        isExpiryDateSame(binding.date.text.toString()) -> {
                            saveExpiryDate(binding.date.text.toString())
                        }
                        else -> {
                            binding.tvExpiryDateResponse.text = getString(R.string.alert_invalid_expiry_date)
                        }
                    }
                }

//                sharedPreferences.edit().putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, binding.date.text.toString()).apply()
//                if (taskDetails.tracking.countryOfOriginRequired == "1") {
//                    binding.date.requestFocus()
//                    val navController =
//                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//                    val action = ExpiryDateFragmentDirections.actionExpiryDateFragmentToCooFragment()
//                    navController.navigate(action)
//                } else {
//                    binding.date.requestFocus()
//                    val navController =
//                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//                    val action = ExpiryDateFragmentDirections.actionExpiryDateFragmentToQtyUomFragment()
//                    navController.navigate(action)
//                }
            }
        }


        binding.date.setOnClickListener {
            val calendar = Calendar.getInstance()
            FlareLog.i(TAG, "Date field clicked")

            binding.tvExpiryDateResponse.text = ""
            val datePickerDialog = DatePickerDialog(
                fragmentContext, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePickerDialog.datePicker.minDate = calendar.timeInMillis
            datePickerDialog.show()

        }

        binding.btnStage.setOnClickListener {
            /*val navController =
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = RCContainerFragmentDirections.actionRcContainerToRcStagingLocation()
            navController.navigate(action)*/
        }
    }

    private fun saveExpiryDate(expDate: String) {
        enableStageButton()
        sharedPreferences.edit().putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE_PFA, expDate).apply()
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = TivoALTYP11ExpiryDateTrackFragmentDirections.actionQtyFragmentToContainerFragment()
        navController.navigate(action)
    }

    /**
     * method to enable stage button
     */
    private fun enableStageButton() {
        binding.btnStage.isEnabled = true
    }

    private fun isExpiryDateSame(selectedDate:String):Boolean {
        val myFormat1 = "yyyy-MM-dd" // mention the format you need
        val myFormat = "yyyy-MM-dd hh:mm:ss" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        val sdf1 = SimpleDateFormat(myFormat1, Locale.US)

        if(viewModel.getPickTaskDetails()?.expDate!=null && viewModel.getPickTaskDetails()?.expDate !="") {
            val getApiExpiryDate = sdf.parse(viewModel.getPickTaskDetails()?.expDate!!)
            val taskDetailExpDate = sdf1.format(getApiExpiryDate!!)
            if (taskDetailExpDate.isNotEmpty() && taskDetailExpDate.equals(selectedDate, true)) {
                return true
            }
        }else
        {
            return true
        }
        return false
    }

}