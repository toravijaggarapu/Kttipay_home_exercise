package com.fsc.flare.ui.fragment.inquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryContainerDescBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.LockCodeValuesUtil
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryConDescFragment"

/**
 * A simple [InquiryContainerDescriptionFragment] class.
 */
@AndroidEntryPoint
class InquiryContainerDescriptionFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryContainerDescBinding
    
    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryContainerDescBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getItem()
        FlareLog.i(TAG, "InquiryConDescFragment: $data")
        if (data?.containers != null) {
            if (data.containers.isNotEmpty()) {
                binding.prevNextLayout.visibility = View.GONE
                val container = data.containers[0]

                if(container.containerType!=null && container.containerType.equals("C",false))
                binding.containerNumberTv.text = resources.getString(R.string.container_number)
                else binding.containerNumberTv.text = resources.getString(R.string.lbl_pallet_number)
                binding.containerNumber.text=container.container
                binding.ibObIndicator.text = container.ibObIdentifier
                binding.channel.text = container.channel
                binding.containerStatus.text = LockCodeValuesUtil.getLockCodeValue(
                    if (container.containerStatus == null) 0
                    else container.containerStatus.toString().toInt()
                )
                binding.item.text = container.item
                binding.inventoryType.text = container.inventoryType?.let { getInventoryDescription(it) }
                binding.quantity.text = container.qty.toString()
                binding.uom.text = container.qtyUom
                binding.lot.text = container.lotNumber
                binding.expiryDate.text = container.expiryDate
                binding.coo.text = container.coo
                binding.tvCurrentLocationValue.text = container.currentLocNumber
            }
        }

        binding.btnOk.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                val navController =
                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                val action =
                    InquiryContainerDescriptionFragmentDirections.actionInquiryContainerDescToInquiryContainerFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.inquiryContainer, true).build()
                navController.navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
        }
    }

}