package com.fsc.flare.utils

import java.util.Date

object LockCodeValuesUtil {
    var codeValues: MutableMap<Int, String> = mutableMapOf(
        Pair(0, "Created"),
        Pair(10, "Received"),
        Pair(20, "Putaway"),
        Pair(25, "Closed"),
        Pair(30, "On Task"),
        Pair(35, "Partially Allocated"),
        Pair(40, "Allocated"),
        Pair(50, "Consumed"),
        Pair(55, "RA Forward"),
        Pair(65, "RA Received"),
        Pair(85, "Picked"),
        Pair(90, "Complete"),
        Pair(99, "Cancelled"),
        Pair(100, "Shipped"),
        Pair(110, "Printed"),
        Pair(120, "Released"),
        Pair(130, "Marked"),
        Pair(140, "In Picking"),
        Pair(150, "Picking Complete"),
        Pair(160, "In Packing"),
        Pair(170, "Pack Complete"),
        Pair(180, "Weighed"),
        Pair(190, "Manifested"),
        Pair(200, "Outbound Staging"),
        Pair(205, "Loading"),
        Pair(210, "Loaded On Truck"),
        Pair(220, "Ready for Close"),
        Pair(300, "Shipped"),
    )

    fun getLockCodeValue(key: Int): String? {
        return codeValues[key]
    }

    var lastFetchDateTimeLookup = 0L
    var isPILockEnabled = false
        set(value) {
            lastFetchDateTimeLookup = Date().time
            field = value
        }

}