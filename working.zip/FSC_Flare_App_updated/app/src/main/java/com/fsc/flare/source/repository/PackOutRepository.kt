package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.packout.req.*
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class PackOutRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getLocationId(packOutGetReq: PackOutGetReq) =
        apiGatewayInterface.getPackOutLocationId(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            facility = packOutGetReq.facility,
            barcode = packOutGetReq.barcode,
            itemInfo = packOutGetReq.itemInfo,
            custId = packOutGetReq.custId,
            buId = packOutGetReq.buId
        )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun submitPackout(packOutSaveTmp: PackOutSaveTmp) =
        apiGatewayInterface.submitPackout(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            packOutSaveTmp = packOutSaveTmp
        )

    suspend fun endPackOut(endPackOutEndReq: PackOutEndReq) =
        apiGatewayInterface.endPackout(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            packOutEndReq = endPackOutEndReq
        )

    suspend fun validatePackOutSerialNumber(packOutSerialNumberGetReq: PackOutSerialNumberGetReq) =
        apiGatewayInterface.validatePackOutSerialNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNumber = packOutSerialNumberGetReq.containerNumber,
            palletNumber = packOutSerialNumberGetReq.containerNumber,
            containerSerialNumber = packOutSerialNumberGetReq.containerSerialNumber,
            custId = packOutSerialNumberGetReq.custId,
            fcyId = packOutSerialNumberGetReq.fcyId,
            buId = packOutSerialNumberGetReq.buId,
            userDirected = packOutSerialNumberGetReq.userDirected,
            taskUom = packOutSerialNumberGetReq.taskUom
        )

    suspend fun getPalletId(packOutPalletGetReq: PackOutPalletGetReq) =
        apiGatewayInterface.getPackOutPalletId(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = packOutPalletGetReq.fcyId,
            custId = packOutPalletGetReq.custId,
            buId = packOutPalletGetReq.buId,
            palletNumber = packOutPalletGetReq.palletNumber,
            ibCartonNumber = packOutPalletGetReq.ibCartonNumber
        )

    suspend fun getLotNumber(packOutLotGetReq: PackOutLotGetReq) =
        apiGatewayInterface.getPackOutLotNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = packOutLotGetReq.fcy_Id,
            custId = packOutLotGetReq.custId,
            buId = packOutLotGetReq.buId,
            lotNumber = packOutLotGetReq.batchNumber,
            itemName = packOutLotGetReq.itemName,
            itemId = packOutLotGetReq.itemId
        )

    suspend fun getQty(packOutQtyGetReq: PackOutQtyGetReq) =
        apiGatewayInterface.getQtyId(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            fcyId = packOutQtyGetReq.fcyId,
            custId = packOutQtyGetReq.custId,
            buId = packOutQtyGetReq.buId,
            qty = packOutQtyGetReq.qty,
            palletQty = packOutQtyGetReq.palletQty,
            caseQty = packOutQtyGetReq.caseQty,
            locationBarCode = packOutQtyGetReq.locationBarCode,
            transactionIdentifier = packOutQtyGetReq.transactionIdentifier,
            isKitting = packOutQtyGetReq.isKitting,
            itemId = packOutQtyGetReq.itemId
        )

    suspend fun getTransactionParamDetail(transactionParamRequest: TransactionParamRequest) =
        apiGatewayInterface.getTransactionParam(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = transactionParamRequest.cust_id,
            buId = transactionParamRequest.bu_id,
            fcyId = transactionParamRequest.fcy_id,
            transCode = transactionParamRequest.trans_code
        )

    suspend fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = apiGatewayInterface.validateUPCorSLP(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        itemCode = itemCode,
        upcOrSlp = upcOrSlp
    )

    suspend fun getLocationInventoryCount(locationId: String) = apiGatewayInterface.getLocationInventoryCount(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
    )

    suspend fun getInquiryContainer(containerNum: String) = apiGatewayInterface.getInquiryContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum
    )

    suspend fun getLpnsInTempTable(locationId: Long) = apiGatewayInterface.getLpnsInTempTable(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        locationId = locationId
    )

    suspend fun generatePalletCaseNumber(type: String) =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = type
        )

    suspend fun getPrintRequestorListForPackout(printerConfigRequest: PrinterConfigRequest) = apiGatewayInterface.getPrintRequestorListForPackout(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigRequest.fcyId,
        page = printerConfigRequest.page,
        pageLimit = printerConfigRequest.pageLimit,
        printerType = printerConfigRequest.printerType
    )

    suspend fun getPrinterForTheKitStation(locationId:Int ) = apiGatewayInterface.getPrinterForTheKitStation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        locationId = locationId
    )


    suspend fun printCaseLabelsFromPackout(printCaseLabelPackoutReq: PrintCaseLabelPackoutReq ) = apiGatewayInterface.printCaseLabelsFromPackout(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fscUser = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        printCaseLabelPackoutReq = printCaseLabelPackoutReq
    )
    suspend fun getWorkOrderStatus(kitLocationId: Int) = apiGatewayInterface.getWorkOrderStatus(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        kitLocationId = kitLocationId
    )

    suspend fun deKitPackout(kitLocationId: Int) = apiGatewayInterface.deKitPackout(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        kitLocationId = kitLocationId
    )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )
}

