package com.fsc.flare.di

import android.app.Application
import com.fsc.flare.database.FlareDataBase
import com.fsc.flare.database.dao.FlareDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@InstallIn(SingletonComponent::class)
@Module
class FlareRFLogsModule {

    @Provides
    fun getFlareDao(application: Application): FlareDao {
        val db = FlareDataBase.getDataBase(application)
        return db.flareDao()
    }
}