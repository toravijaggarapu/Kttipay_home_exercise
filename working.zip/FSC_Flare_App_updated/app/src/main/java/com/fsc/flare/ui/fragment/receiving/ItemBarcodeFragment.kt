package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.text.HtmlCompat
import androidx.core.text.bold
import androidx.core.text.color
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogBatchSelectionBinding
import com.fsc.flare.databinding.FragmentItemBarcodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.res.BatchDetail
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.receiving.ExitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.CriteriaFirstInspectionRequest
import com.fsc.flare.source.data.dto.receiving.item.Item
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import org.joda.time.DateTime
import java.math.BigDecimal
import javax.inject.Inject


private const val TAG = "ItemBarcodeFragment"

/**
 * A simple [ItemBarcodeFragment] class..
 */
@AndroidEntryPoint
class ItemBarcodeFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentItemBarcodeBinding
    private var exitFlag: String? = null
    private lateinit var cb1: CustomVisibilityCallback
    private lateinit var inventoryTypeCode: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            exitFlag = arguments?.getString("exitflag")

        if (exitFlag.equals("true")){
            sendTrackerDataToServer()
        }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentItemBarcodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        binding.itemBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.itemBarcodeResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        subscribeObservers()
        sharedPreferences.edit().putBoolean(PreferenceKeys.RECEIVING_FIRST_ARTICLE_INSPECTION, false).apply()
        viewModel.isFirstArticleInspectionLockNeeded = false
        return binding.root
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observePackageItemResponse()
        observeExitReceivingResponse()
        observeFirstInspectionResponse()
        observeLotNumberResponse()
    }

    /**
     * Function to observe lot number response
     */
    private fun observeLotNumberResponse() {
        viewModel.validateLotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lotResponse ->
                        if (lotResponse.success) {
                            lotValidationResponseHandle(lotResponse)
                        } else {
                            FlareLog.i(TAG, "lotValidation error: $response")
                            showErrorSnackBar(if (response.message.isNullOrEmpty()) getString(R.string.alert_invalid_lot_number) else response.message)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lotValidation Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle lot validation response
     */
    private fun lotValidationResponseHandle(lotResponse: ValidateLotNumberResponse) {
        //showSuccessSnackBar(msg)
        val batchDetailList = lotResponse.batchDetail
        batchDetailList?.let { batchDetailObject ->
            if(batchDetailObject.isNotEmpty()) {
                when(batchDetailObject.size) {
                     1 -> {
                        val batchDetail = batchDetailObject[0]
                        //check for the expiry flag from api response
                        if(batchDetail.expired) {
                            displayExpiryFlagAlert(batchDetail)
                        } else {
                            updateBatchDetailsAndNavigate(batchDetail)
                        }
                    }
                    in 2..Int.MAX_VALUE -> {
                        processMultipleBatchDetailsFromLotMaster(batchDetailObject)
                    }
                }
            }
        }
    }

    /**
     * Function to process multiple Batch Details from Lot Master
     */
    private fun processMultipleBatchDetailsFromLotMaster(batchDetailObject: List<BatchDetail>) {
        val item = viewModel.getItem()
        val itemDetails = viewModel.getAsn().itemdetails
        val itemList = itemDetails.filter { it.itemId == item.itemId && it.shippedQty != BigDecimal.ZERO }
        val distinctInventoryTypesListForLot = itemList.filter { it.invnType == inventoryTypeCode }.distinctBy { it.batchNumber }
        val batchNumbersFromAsn = distinctInventoryTypesListForLot.map { it.batchNumber }.toSet()
        val disabledLotNumbers = batchDetailObject.filter { it.batchNbr in batchNumbersFromAsn } + batchNumbersFromAsn.minus(batchDetailObject.map { it.batchNbr }.toSet())
        // filteredListFromLotMaster will check for the batch numbers from Lot Master which matches with batchNumbersFromASN and remove the ones which are not part of Lot Master and
        // will add them as a custom object with Just batchNbr and isInvalid set to true.
        val filteredListFromLotMaster = batchDetailObject.filter { it.batchNbr in batchNumbersFromAsn } +
                batchNumbersFromAsn.minus(batchDetailObject.map { it.batchNbr }.toSet())
                    .filterNotNull()
                    .map { BatchDetail(batchNbr = getString(R.string.invalid_lot_information, it), isInvalid = true) }
        disabledLotNumbers.forEach {
            println(it)
        }
        filteredListFromLotMaster.forEach {
            println(it)
        }
        if(filteredListFromLotMaster.isNotEmpty()) {
            showLotSelectionDialog(filteredListFromLotMaster)
        } else {
            itemNavigation(item)
        }
    }

    private fun updateBatchDetailsAndNavigate(batchDetail: BatchDetail) {
        viewModel.isItemExpired = batchDetail.expired
        sharedPreferences.edit().apply {
            putString(PreferenceKeys.RECEIVING_LOT_MESSAGE, RECORD_EXISTS)
            putString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO,
                batchDetail.batchNbr ?: ""
            )
            putString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE,
                batchDetail.expirationDateFormat ?: ""
            )
            putString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_MANUFACTURING_DATE,
                batchDetail.manufacturingDate ?: ""
            )
            putString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_MANUFACTURING_CODE,
                batchDetail.manufacturingCode ?: ""
            )
            putString(
                PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN,
                batchDetail.coo ?: ""
            )

        }.apply()
        itemNavigation(viewModel.getItem())
    }

    private fun displayExpiryFlagAlert(batchDetail: BatchDetail) {
        showAlertDialog(getString(R.string.item_lot_expired_alert),
            resources.getString(R.string.alert_button_proceed),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    updateBatchDetailsAndNavigate(batchDetail = batchDetail)
                }

                override fun onNegativeButtonClick() {
                }
            })
    }


    /**
     * Function to observe First Article Inspection Response
     */
    private fun observeFirstInspectionResponse() {
        viewModel.criteriaFirstInspectionResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { firstInspectionResponse ->
                        if (firstInspectionResponse.success) {
                            showSuccessSnackBar(firstInspectionResponse.message)
                            FlareLog.e(TAG, "criteriaFirstInspectionResponse Success: ${firstInspectionResponse.message}")
                            sharedPreferences.edit().putBoolean(PreferenceKeys.RECEIVING_FIRST_ARTICLE_INSPECTION, true).apply()
                            filterInvTypes()
                        }
                    }
                }
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        sharedPreferences.edit().putBoolean(PreferenceKeys.RECEIVING_FIRST_ARTICLE_INSPECTION, false).apply()
                        viewModel.isFirstArticleInspectionLockNeeded = true
                        val itemBarcode = binding.itemBarcode.text.toString()
                        if (itemBarcode !in viewModel.getFirstArticleMsgShown()) {
                            showFirstArticleWarningMsg()
                        } else {
                            filterInvTypes()
                        }
                    }
                }
            }
        }
    }

    /**
     * Function to observe Exi Receiving response
     */
    private fun observeExitReceivingResponse() {
        viewModel.exitReceivingResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { exitResponse ->
                        if (exitResponse.success) {
                            FlareLog.i(TAG, "exitReceiving success: $exitResponse")
                            viewModel.setAsn(null)
                            showSuccessSnackBarStd(exitResponse.message) {
                                navigateToDocDoorFragment(true)
                            }
                        } else {
                            binding.exitReceiving.isEnabled = true
                            showErrorSnackBar(exitResponse.message)
                            FlareLog.e(TAG, "packageItem error: ${exitResponse.message}")
                        }
                    }
                }
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    binding.exitReceiving.isEnabled = true
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "exitReceiving Error: $message")
                    }
                }
            }
        }
    }

    /**
     * Nav Handler to Dock Door Fragment
     */
    private fun navigateToDocDoorFragment(exitFlag: Boolean) {
        val bundle = bundleOf("exitflag" to exitFlag)
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.dockDoorFragment, true).build()
        getNavigationController().navigate(
            R.id.action_itemBarcodeFragment_to_dockDoor,
            bundle,
            navOptions
        )
    }

    /**
     * Function to observe Package Item Response
     */
    private fun observePackageItemResponse() {
        viewModel.packageItemResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let(::handleItemBarcodeResponse)
                }
                is Resource.Loading -> showProgressBar()
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.apply {
                            displayErrorMessage(message)
                        }
                        FlareLog.e(TAG, "packageItem Error: $message")
                    }
                }
            }
        }
    }

    /**
     * Function to filter inventory types
     */
    private fun filterInvTypes() {
        val item = viewModel.getItem()
        val itemDetails = viewModel.getAsn().itemdetails
        val itemList = itemDetails.filter { it.itemId == item.itemId && it.shippedQty != BigDecimal.ZERO }

        if (itemList.isEmpty()) {
            displayErrorMessage(getString(R.string.lbl_invalid_barcode))
            return
        }

        val distinctInventoryTypesList = itemList.distinctBy { it.invnType }
        val emptyInvTypeFound = itemList.any { it.invnType == null }
        val invTypeCodes = distinctInventoryTypesList.mapNotNull { it.invnType }
        val invTypes = getInvTypesFromCodes(invTypeCodes, emptyInvTypeFound)

        if (invTypes.size > 1) {
            showInventorySelectionDialog(invTypes, item)
            return
        }

        if (invTypes.isNotEmpty()) {
            val selectedInvType = invTypes[0].replace(resources.getString(R.string.lbl_default), "").trim()
            viewModel.setInventoryTypeSelected(selectedInvType)

            if (item.hazmatRequired == "Y" && (item.hazardous?.hazardClassIMDG.isNullOrEmpty() || item.tracking.temperatureZone.isNullOrEmpty())) {
                displayErrorMessage(getString(R.string.please_provide_the_hazardous_details))
                return
            }

            val matchingCode = viewModel.getInventoryTypesHashMap().entries.find { (_, value) ->
                value == viewModel.getInventoryTypeSelected()
            }?.key

            if (matchingCode != null) {
                inventoryTypeCode = matchingCode
            }

            val distinctInventoryTypesListForLot = itemList.filter { it.invnType == inventoryTypeCode }.distinctBy { it.batchNumber }
            when {
                item.tracking.lotRequired == "1" -> {
                    when (distinctInventoryTypesListForLot.size) {
                        1 -> callLotValidationApi(distinctInventoryTypesListForLot[0].batchNumber ?: "")
                        in 2..Int.MAX_VALUE -> {
                            // check from batch details from Lot Master
                            callLotValidationApiFromLotMaster()
                        }
                    }
                }
                else -> {
                    // Navigate to item if lot validation is not required
                    itemNavigation(item)
                }
            }
        }
    }

    /**
     * Function to display FAI warning message
     */
    private fun showFirstArticleWarningMsg() {
        val text1 = getString(R.string.first_article_inspection_msg_part_one)
        val boldText1 = "" + binding.itemBarcode.text
        val text2 = getString(R.string.first_article_inspection_msg_part_two)

        val colorPrimary = ContextCompat.getColor(fragmentContext, R.color.colorPrimary)

        val message = SpannableStringBuilder()
            .append(text1)
            .color(colorPrimary) { bold { append(boldText1) } }
            .append(text2)
        showAlertDialog("", message.toString()) {
            filterInvTypes()
        }
    }

    /**
     * Function to setup data onto views
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val asnData = viewModel.getAsn()
        val asnNumber = asnData.asnNumber
        val facilityId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
        val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)

        with(binding) {
            dockDoor.text = sharedPreferences.getString(PreferenceKeys.Item.DD_NUMBER, null)
            asn.text = asnNumber
            trackCustomValue("ASN_NUMBER", asnNumber)
            rootLayout.setOnTouchListener { v, event ->
                if (event?.action == MotionEvent.ACTION_DOWN) {
                    super.onTouch(v, event)
                    validateField()
                }
                true
            }

            itemBarcode.setOnEditorActionListener { v, actionId, event ->
                super.onEditorAction(v, actionId, event)
                if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    validateField()
                }
                false
            }

            exitReceiving.visibility = View.VISIBLE
            exitReceiving.setOnClickListener {
                super.onClick(it)
                FlareLog.i(TAG, "ExitReceiving clicked")
                exitReceiving.isEnabled = false
                viewModel.exitReceiving(
                    ExitReceivingRequest(
                        asnNumber,
                        "30",
                        "RF",
                        facilityId,
                        emptyList(),
                        DateTime.now().toString(),
                        custId = custId,
                        buId = buId
                    )
                )
            }
        }
        binding.itemBarcode.onFocusChangeListener = this
        sharedPreferences.edit().putInt(PreferenceKeys.RECEVEING_ASN_ID, asnData.asnId).apply()
    }

    /**
     * Function to handle Item Barcode Response
     *
     * It checks If Item UOM's are not defined then it will show message to user. (virtual case scenario.)
     *
     */
    private fun handleItemBarcodeResponse(itemBarcodeResponse: PackageItemResponse) {
        if (itemBarcodeResponse.success) {
            itemBarcodeResponse.items?.let { items ->

                if (!viewModel.selectedContainerType.isNullOrEmpty() &&
                    !viewModel.isUMOAllowForReceiving(items[0])) {
                    showReceivingNotPossibleMessage(items[0])
                    return@handleItemBarcodeResponse
                }

                when {
                    items.size == 1 -> {
                        viewModel.setItem(items[0])
                        checkFirstArticleInspectionAndInventoryTypes(viewModel.getItem())
                    }

                    items.size > 1 -> showItemSelectionDialog(items)
                    else -> displayErrorMessage(getString(R.string.lbl_invalid_barcode))
                }
            } ?: run {
                displayErrorMessage(getString(R.string.lbl_invalid_barcode))
            }
        } else {
            displayErrorMessage(getString(R.string.lbl_invalid_barcode))
        }
    }

    /**
     * Function to display Item Selection dialog
     */
    private fun showItemSelectionDialog(items: List<Item>) {
        val str = "<font color='#340e5f'>Select Item</font>"
        val asnItems = viewModel.getAsn().itemdetails.map { it.itemId }
        val displayItemsList = items.filter { asnItems.contains(it.itemId) }.map { it.itemName }

        if (displayItemsList.isNotEmpty()) {
            showAlertDialogItems(
                title = HtmlCompat.fromHtml(str, HtmlCompat.FROM_HTML_MODE_LEGACY).toString(),
                positiveButton = getString(R.string.alert_dialog_close_btn),
                displayItemsList = displayItemsList
            ) { position ->
                val selectedItem = items.first { it.itemName == displayItemsList[position] }
                binding.itemBarcode.setText(selectedItem.itemBarCode)
                binding.itemBarcode.setSelection(binding.itemBarcode.text?.length ?: 0)
                viewModel.setItem(selectedItem)
                checkFirstArticleInspectionAndInventoryTypes(viewModel.getItem())
            }
        } else {
            displayErrorMessage(getString(R.string.lbl_invalid_barcode))
        }
    }

    /**
     * Function to display Receiving Not Possible Message based on container type.
     */
    private fun showReceivingNotPossibleMessage(itemDetails: Item) {
        val errorMessage = when {
            viewModel.selectedContainerType == CASE -> {
                getString(R.string.case_uom_is_not_defined_message)
            }

            !itemDetails.uomConversions.any { it.toUOM == "CS" } && !itemDetails.uomConversions.any { it.toUOM == "PL" } -> {
                getString(R.string.case_n_pallet_uom_is_not_defined_message)
            }

            !itemDetails.uomConversions.any { it.toUOM == "CS" } -> {
                getString(R.string.case_uom_is_not_defined_message)
            }

            else -> {
                getString(R.string.pallet_uom_is_not_defined_message)
            }
        }
        binding.itemBarcodeResponse.text = errorMessage
    }

    /**
     * Function to check FAI lock should be called or not
     */
    private fun checkFirstArticleInspectionAndInventoryTypes(item: Item) {
        when {
            item.firstReceipt == "Y" -> {
                viewModel.criteriaFirstInspection(
                    CriteriaFirstInspectionRequest(
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        "FAI",
                        item.itemId
                    )
                )
            }
            else -> filterInvTypes()
        }
    }

    /**
     * Function to retrieve Inventory Types from Codes
     * @param invTypeCodes - contains list of Inventory Type Codes
     * @param emptyInvTypeFound - Boolean which provides emptyInvType found
     */
    private fun getInvTypesFromCodes(invTypeCodes: List<String>, emptyInvTypeFound: Boolean): Array<String> {
        val invTypesHashMap = viewModel.getInventoryTypesHashMap()
        val invTypeTempList = invTypeCodes.mapNotNull { invTypesHashMap[it] }.toMutableList()

        if (emptyInvTypeFound) {
            val defaultInvTypeDesc = viewModel.getDefaultInvTypeDesc()
            val defaultInvTypeDescWithLabel = "$defaultInvTypeDesc ${resources.getString(R.string.lbl_default)}"

            if (invTypeTempList.contains(defaultInvTypeDesc)) {
                invTypeTempList.remove(defaultInvTypeDesc)
            }
            invTypeTempList.add(defaultInvTypeDescWithLabel)
        }

        return invTypeTempList.toTypedArray()
    }

    /**
     * Nav Handler to navigate to COO Screen or Inventory Type selection screen
     */
    private fun itemNavigation(item: Item) {
        val coo = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, "")
        val action = when {
            item.tracking.countryOfOriginRequired == "1" && item.tracking.lotRequired == "1" -> {
                binding.itemBarcode.text = null
                ItemBarcodeFragmentDirections.actionItemBarcodeFragmentToCooFragment()
            }
            else -> {
                binding.itemBarcode.text = null
                ItemBarcodeFragmentDirections.actionItemBarcodeFragmentToInventoryTypeFragment()
            }
        }
        getNavigationController().navigate(action)
    }

    /**
     * Function to display Inventory Selection Dialog
     */
    private fun showInventorySelectionDialog(invTypes: Array<String>, item: Item) {
        val title = getString(R.string.select_inventory_type)
        showSingleItemChoiceDialog(HtmlCompat.fromHtml(title, HtmlCompat.FROM_HTML_MODE_LEGACY).toString(), invTypes){
            handleInventorySelection(it, item)
        }
    }

    /**
     * Function to handle inventory selection
     */
    private fun handleInventorySelection(selectedType: String, item: Item) {
        val selectedInvType = selectedType.replace("(Default)", "").trim()
        viewModel.setInventoryTypeSelected(selectedInvType)

        if (item.hazmatRequired == "Y" && (item.hazardous?.hazardClassIMDG.isNullOrEmpty() || item.tracking.temperatureZone.isNullOrEmpty())) {
            displayErrorMessage(getString(R.string.please_provide_the_hazardous_details))
        } else {
            processInventorySelection(item, selectedInvType)
        }
    }

    /**
     * Function to process Inventory selection
     */
    private fun processInventorySelection(item: Item, selectedInvType: String) {
        val itemDetails = viewModel.getAsn().itemdetails
        val itemList = itemDetails.filter { it.itemId == item.itemId && it.shippedQty != BigDecimal.ZERO }
        val matchingCode = viewModel.getInventoryTypesHashMap().entries.find { (_, value) ->
            value == selectedInvType
        }?.key

        if (matchingCode != null) {
            inventoryTypeCode = matchingCode
        }

        val distinctInventoryTypesListForLot = itemList.filter { it.invnType == inventoryTypeCode }.distinctBy { it.batchNumber }
        when {
            item.tracking.lotRequired == "1" -> {
                when (distinctInventoryTypesListForLot.size) {
                    1 -> callLotValidationApi(distinctInventoryTypesListForLot[0].batchNumber ?: "")
                    in 2..Int.MAX_VALUE -> {
                        //Check for BatchDetails from Lot Master
                        callLotValidationApiFromLotMaster()
                    }
                }
            }
            else -> {
                // Navigate to item if lot validation is not required
                itemNavigation(item)
            }
        }
    }

    private fun callLotValidationApi(batchNumber: String) {
        viewModel.validateLotRequest(batchNumber = batchNumber)
    }

    private fun callLotValidationApiFromLotMaster() {
        viewModel.validateLotRequestFromLotMaster()
    }

    /**
     * Function to display lot selection dialog
     */
    private fun showLotSelectionDialog(itemList: List<BatchDetail>) {

        val dialogView = LayoutInflater.from(fragmentContext).inflate(R.layout.dialog_batch_selection, null)
        val binding = DataBindingUtil.bind<DialogBatchSelectionBinding>(dialogView)

        val dialog = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(getString(R.string.select_lot_number))
            .setView(dialogView)
            .setCancelable(false)
            .create()

        // Adjust the dialog width to match the screen width
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)

        val adapter = BatchItemAdapter(itemList) { selectedItem ->
            if(selectedItem.expired) {
                displayExpiryFlagAlert(selectedItem)
            } else {
                updateBatchDetailsAndNavigate(selectedItem)
            }
            // Dismiss the dialog after selecting an item
            dialog.dismiss()
        }

        binding?.recyclerView?.layoutManager = LinearLayoutManager(fragmentContext)
        binding?.recyclerView?.adapter = adapter

        dialog.show()
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to validate Item Barcode scanned
     */
    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.itemBarcode.isFocused && !binding.itemBarcode.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Get Package Items called")
            getItems()
        }
    }

    /**
     * Function to retrieve Item Information
     */
    private fun getItems() {
        viewModel.getItems(
            PackageItemRequest(
                "Detail",
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                "0",
                binding.itemBarcode.text.toString(),
                ""
            )
        )
    }

    private fun displayErrorMessage(message: String) {
        trackErrorMessage(message)
        binding.itemBarcodeResponse.text = message
        binding.itemBarcode.selectAll()
        showSoftKeyBoard(fragmentContext, binding.itemBarcode)
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.itemBarcode.setText(scan?.barcode.toString())
        binding.itemBarcode.text?.length?.let {
            binding.itemBarcode.setSelection(it)
        }
        FlareLog.i(TAG, "Get Package Items called")
        getItems()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

}