package com.fsc.flare.ui.fragment.packing

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CartonDetailsRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.LookupCode
import com.fsc.flare.source.data.dto.packing.req.DeManifestRequest
import com.fsc.flare.source.data.dto.packing.req.ManifestRequest
import com.fsc.flare.source.data.dto.packing.req.PackingConfirmQtyRequest
import com.fsc.flare.source.data.dto.packing.req.PrintLabelRequest
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.req.UnPackRequest
import com.fsc.flare.source.data.dto.packing.res.CartonDetail
import com.fsc.flare.source.data.dto.packing.res.CartonInfo
import com.fsc.flare.source.data.dto.packing.res.CartonType
import com.fsc.flare.source.data.dto.packing.res.CartonTypesResponse
import com.fsc.flare.source.data.dto.packing.res.ManifestAPIResponse
import com.fsc.flare.source.data.dto.packing.res.PackingConfirmQtyResponse
import com.fsc.flare.source.data.dto.packing.res.PackingPackResponse
import com.fsc.flare.source.data.dto.packing.res.PrintLabelResponse
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.packing.res.UnPackResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.CycleCountRepository
import com.fsc.flare.source.repository.PackingRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PackingViewModel"

@HiltViewModel
class PackingViewModel @Inject constructor(private val packingRepository: PackingRepository) : BaseViewModel() {

    // Order Status
    private val PICKING_COMPLETE_STATUS = 150
    private val PACK_COMPLETE_STATUS = 170
    private val MANIFESTED = 190
    private val WEIGHED = 180
    private val PACKING_ON_HOLD = 155

    private val ORDER_PACKED_COMPLETE_STATUS = 65

    // Order Type
    private val ORDER_TYPE_PARCEL = "B2C"
    private val ORDER_TYPE_LTL = "B2B"

    // Pack Station
    val packStationListResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    var printRequestorDescList = ArrayList<String>()
    var printRequestorHashmap = HashMap<String, PrinterConfig>()
    var selectedPackStation:PrinterConfig? = null

    // Pack Method
    val packMethodListResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    var packMethodsLookUpList = ArrayList<LookupCode>()
    var packMethodList = ArrayList<String>()
    var selectedPackMethod:LookupCode? = null

    // Pack API
    val packAPIResponse: MutableLiveData<Resource<PackingPackResponse>> = SingleLiveEvent()
    var cartonInfo:CartonInfo? = null
    var cartonNumber:String = ""
    var toteNumber:String = ""

    // Shipment Method
    val shipmentMethodListResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    var shipmentMethodsLookUpList = ArrayList<LookupCode>()
    var shipmentMethodList = ArrayList<String>()
    var selectedShipmentMethod:LookupCode? = null

    // Carton Type
    val cartonTypesResponse: MutableLiveData<Resource<CartonTypesResponse>> = SingleLiveEvent()
    var cartonTypesList = ArrayList<CartonType>()
    var selectedCartonType: CartonType? = null

    // Confirm PackQty API
    val confirmPackQtyResponse: MutableLiveData<Resource<PackingConfirmQtyResponse>> = SingleLiveEvent()

    // Delivery Type
    var saturdayDelivery:Boolean = false

    // Manifest API
    val manifestAPIResponse: MutableLiveData<Resource<ManifestAPIResponse>> = SingleLiveEvent()

    // Print API
    val printAPIResponse: MutableLiveData<Resource<PrintLabelResponse>> = SingleLiveEvent()

    // Send PR API
    val sendToPRResponse: MutableLiveData<Resource<SendToPRResponse>> = SingleLiveEvent()

    // UnPack API
    val unPackAPIResponse: MutableLiveData<Resource<UnPackResponse>> = SingleLiveEvent()

    fun getShipmentMethodDescription():String {
        return selectedShipmentMethod?.lookupCodeDescription?:""
    }

    fun getShipmentMethodOfCarton():String {
        return cartonInfo?.shipVia?:""
    }

    fun getShipmentMethodCode():String {
        return selectedShipmentMethod?.lookupCode?:""
    }

    fun getCartonTypeValue():String {
        return selectedCartonType?.getCartonType()?:""
    }

    fun getContainerId():Int {
        return cartonInfo?.obContainerId?:0
    }

    fun getCartonId():Int {
        return cartonInfo?.cartonId?:0
    }

    fun getCartonType():String {
        return cartonInfo?.obCartonType?:""
    }

    fun getCartonSize():String {
        return cartonInfo?.cartonSize?:""
    }

    fun getPackMethodDescription():String {
        return selectedPackMethod?.lookupCodeDescription?:""
    }

    fun getPackMethodCode():String {
        return selectedPackMethod?.lookupCode?:""
    }

    fun getPackStationDescription():String {
        return selectedPackStation?.requestor?:""
    }

    fun getTotalPickedQty():Int {
        var pickedItemQty = 0;
        try {
            cartonInfo?.cartonDetails?.forEach {
                 pickedItemQty += it.pickedQty
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
        return pickedItemQty
    }

    fun getTotalNumberOfItems() : Int{
        return cartonInfo?.cartonDetails?.size?:0
    }

    fun getCartonStatus() : String{
        return cartonInfo?.status?:""
    }

    fun isParcelOrder() : Boolean {
        return cartonInfo?.orderType == ORDER_TYPE_PARCEL
    }

    fun isLTLOrder() : Boolean {
        return cartonInfo?.orderType == ORDER_TYPE_LTL
    }

    fun getCustomerOrderNumber(): String{
        return cartonInfo?.customerOrderNumber?:""
    }

    fun getOrderStatus():String{
        return cartonInfo?.orderStatus?:""
    }

    fun isContainerPickingCompleted(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.status == PICKING_COMPLETE_STATUS.toString()
    }

    fun isOrderedPacked(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.orderStatus == ORDER_PACKED_COMPLETE_STATUS.toString()
    }

    fun isContainerPackingOnHold(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.status == PACKING_ON_HOLD.toString()
    }

    fun isContainerPackCompleted(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.status == (PACK_COMPLETE_STATUS.toString())
    }

    fun isContainerWeighed(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.status == (WEIGHED.toString())
    }

    fun isContainerManifested(cartonInfo:CartonInfo) : Boolean {
        return cartonInfo.status == MANIFESTED.toString()
    }

    // Pack Stations
    fun getPackStationList() = viewModelScope.launch {
        FlareLog.i(TAG, "getPackStations Request:")
        packStationListResponse.postValue(Resource.Loading())
        val response = packingRepository.getPackStationList()
        packStationListResponse.postValue(handlePackStationListResponse(response))
    }

    private fun handlePackStationListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackStationListResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PackStationListResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    // Pack Methods
    fun getPackMethods() = viewModelScope.launch {
        FlareLog.i(TAG, "getPackMethods Request:")
        packMethodListResponse.postValue(Resource.Loading())
        val response = packingRepository.getPackMethodList()
        packMethodListResponse.postValue(handlePackMethodListResponse(response))
    }

    private fun handlePackMethodListResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackMethodListResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PackMethodListResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // Pack API
    fun callPackAPI(toteNumber:String,cartonNumber:String) = viewModelScope.launch {
        FlareLog.i(TAG, "packAPI Request:")
        packAPIResponse.postValue(Resource.Loading())
        val response = packingRepository.pack(toteNumber,cartonNumber)
        packAPIResponse.postValue(handlePackAPIResponse(response))
    }

    private fun handlePackAPIResponse(response: Response<PackingPackResponse>): Resource<PackingPackResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackAPIResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PackAPIResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // Shipment Methods
    fun getShipmentMethods() = viewModelScope.launch {
        FlareLog.i(TAG, "getShipmentMethods Request:")
        shipmentMethodListResponse.postValue(Resource.Loading())
        val response = packingRepository.getShipmentMethods()
        shipmentMethodListResponse.postValue(handleShipmentMethodListResponse(response))
    }

    private fun handleShipmentMethodListResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ShipmentMethodListResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ShipmentMethodListResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    // Get Carton Types
    fun getCartonTypes() = viewModelScope.launch {
        FlareLog.i(TAG, "getCartonTypes Request:")
        cartonTypesResponse.postValue(Resource.Loading())
        val response = packingRepository.getCartonTypes()
        cartonTypesResponse.postValue(handleCartonTypesResponse(response))
    }

    private fun handleCartonTypesResponse(response: Response<CartonTypesResponse>): Resource<CartonTypesResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CartonTypesResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CartonTypesResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // Pack API
    fun confirmPackQty(custId:Int,fcyId:Int,buId:Int,packingMethod:String,toteNumber:String,cartonId:Int,selectAll:Boolean) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm PackQty Request:")
        confirmPackQtyResponse.postValue(Resource.Loading())
        val packingConfirmQtyRequest = PackingConfirmQtyRequest(packingMethod,toteNumber,cartonId,selectAll,fcyId,buId,custId)
        val response = packingRepository.confirmPackQty(packingConfirmQtyRequest)
        confirmPackQtyResponse.postValue(handleConfirmPackQtyAPIResponse(response))
    }

    private fun handleConfirmPackQtyAPIResponse(response: Response<PackingConfirmQtyResponse>): Resource<PackingConfirmQtyResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackAPIResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PackAPIResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun sendToPR(request:SendToPRRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm SendToPR Request:")
        sendToPRResponse.postValue(Resource.Loading())
        val response = packingRepository.sendToPR(request)
        sendToPRResponse.postValue(handleSendToPRResponse(response))
    }

    fun print(printRequest:PrintLabelRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm PrintLabelRequest Request:")
        printAPIResponse.postValue(Resource.Loading())
        val response = packingRepository.printLabel(printRequest)
        printAPIResponse.postValue(handlePrintLabelResponse(response))
    }

    // Pack API
    fun manifest(manifestRequest:ManifestRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm ManifestRequest Request:")
        manifestAPIResponse.postValue(Resource.Loading())
        val response = packingRepository.manifest(manifestRequest)
        manifestAPIResponse.postValue(handleManifestAPIResponse(response))
    }

    fun demanifest(manifestRequest:DeManifestRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm De ManifestRequest Request:")
        manifestAPIResponse.postValue(Resource.Loading())
        val response = packingRepository.demanifest(manifestRequest)
        manifestAPIResponse.postValue(handleDeManifestAPIResponse(response))
    }

    // UnPack API
    fun callUnPackAPI(unPackRequest: UnPackRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "unpackAPI Request:")
        unPackAPIResponse.postValue(Resource.Loading())
        val response = packingRepository.unpack(unPackRequest)
        unPackAPIResponse.postValue(handleUnPackResponse(response))
    }

    private fun handleUnPackResponse(response: Response<UnPackResponse>): Resource<UnPackResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "UnPackResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "UnPackResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleManifestAPIResponse(response: Response<ManifestAPIResponse>): Resource<ManifestAPIResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ManifestAPIResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ManifestAPIResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleDeManifestAPIResponse(response: Response<ManifestAPIResponse>): Resource<ManifestAPIResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ManifestAPIResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ManifestAPIResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleSendToPRResponse(response: Response<SendToPRResponse>): Resource<SendToPRResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SendToPRResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintLabelResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handlePrintLabelResponse(response: Response<PrintLabelResponse>): Resource<PrintLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintLabelResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintLabelResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun clearData(){
        // Pack Station
        printRequestorDescList.clear()
        printRequestorHashmap.clear()
        selectedPackStation = null

        // Pack Method
        packMethodsLookUpList.clear()
        packMethodList.clear()
        selectedPackMethod = null

        // Pack API
        cartonInfo = null
        cartonNumber = ""
        toteNumber = ""

        // Shipment Method
        shipmentMethodsLookUpList.clear()
        shipmentMethodList.clear()
        selectedShipmentMethod = null

        // Carton Type
        cartonTypesList.clear()
        selectedCartonType = null

        // Delivery Type
        saturdayDelivery = false
    }
}