package com.fsc.flare.utils

import com.fsc.flare.source.data.dto.receiving.item.UomConversion

class ItemUOMConversionRateUtil() {
    var qtyUOM = ""
    var totalQuantity = 0
    private val hashMap = HashMap<String, UomConversion>()
    var isCaseUomDefined = false
    var isPalletUomDefined = false

    constructor(uomConversions: List<UomConversion>) : this() {
        for (uomConversion in uomConversions) {
            hashMap[uomConversion.toUOM] = uomConversion
        }
        if(hashMap.containsKey("CS")){
            isCaseUomDefined = true
        }
        if(hashMap.containsKey("PL")){
            isPalletUomDefined = true
        }
    }

    // This method can be useful for update the instance class values
    fun updateHashmap(uomConversions: List<UomConversion>){
        hashMap.clear()
        for (uomConversion in uomConversions) {
            hashMap[uomConversion.toUOM] = uomConversion
        }
    }

    fun calculateQuantity(selectedUOM: String, quantity: Int) {
        if (hashMap.containsKey(selectedUOM)) {
            totalQuantity = quantity * hashMap[selectedUOM]?.conversionRate!!
            qtyUOM = hashMap[selectedUOM]!!.qtyUOM
            if (qtyUOM == null){
                totalQuantity = -1
            }
            if (qtyUOM != null && qtyUOM != selectedUOM) {
                calculateQuantity(qtyUOM, totalQuantity)
            }
        }
    }
    fun getEachesQtyInACase(): Int? =   hashMap["CS"]?.conversionRate

    fun getCasesQtyInAPallet():Int? {
        return if(!hashMap["PL"]?.qtyUOM.isNullOrEmpty() && hashMap["PL"]?.qtyUOM == "CS") {
            hashMap["PL"]?.conversionRate
        }else{
            0
        }
    }

    fun getEachesQtyInAPallet():Int? {
        return if(!hashMap["PL"]?.qtyUOM.isNullOrEmpty() && hashMap["PL"]?.qtyUOM == "EA"){
            hashMap["PL"]?.conversionRate
        }else if(!hashMap["PL"]?.qtyUOM.isNullOrEmpty() && hashMap["PL"]?.qtyUOM == "CS"){
            getEachesQtyInACase()?.let { hashMap["PL"]?.conversionRate?.times(it) }
        }else{
            0
        }
    }

    // Collect the conversion rate from UOM lis for inner pack
    fun getInnerPackRate() : Int {
        return if(hashMap.containsKey("IP")){
            return hashMap["IP"]?.conversionRate!!
        } else {
            0
        }
    }
}