package com.fsc.flare.transactiontracker.dto

data class FSCTrackerContainerDetailModel(
    var seqNo: Int=0,
    val httpMethod: String?,
    val url: String?,
    val request: String?,
    val response: String?,
)