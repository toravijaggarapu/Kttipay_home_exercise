package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartLotBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartLotFragment"

@AndroidEntryPoint
class PickCartLotFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartLotBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartLotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
       // binding.tvPickingBuildCart.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "lot field focused")
                    validatelot()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.lotInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "lot field focused")
                validatelot()
            }
            false
        }
        binding.lotInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.lotResponse.text = null
            }
        })

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            binding.cart.text = data?.cartNbr
            binding.taskId.text = taskData.taskId.toString()
            binding.item.text = taskData.itemCode
            binding.description.text = taskData.itemDescription
            binding.pickLocation.text = taskData.locationBarcode
            binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
            if (taskData.lotNumber.isNotEmpty()) {
                binding.lotTv.visibility = View.VISIBLE
                binding.lot.visibility = View.VISIBLE
                binding.lot.text = taskData.lotNumber
            }
            if(!taskData.mfgDate.isNullOrEmpty()){
                binding.mfgTv.visibility = View.VISIBLE
                binding.mfg.visibility = View.VISIBLE
                binding.mfg.text = formatDate(taskData.mfgDate!!)
            }
            if(!taskData.expDate.isNullOrEmpty()){
                binding.expiryTv.visibility = View.VISIBLE
                binding.expiry.visibility = View.VISIBLE
                binding.expiry.text = formatDate(taskData.expDate!!)
            }
            binding.container.text = taskData.containerNbr

            if (taskData.allocationType == "20"|| taskData.allocationType =="21")
            {
                showToteLayout(false)
                // showConatainerNumber
                handleContainerLayout(true)

            }else
            {
                // hideConatainerNumber
                handleContainerLayout(false)

                if(!taskData.toteNumber.isNullOrEmpty())
                {
                    showToteLayout(true)
                    binding.toteNumber.text = taskData.toteNumber
                }else
                    showToteLayout(false)
            }
        }
    }

    private fun validatelot() {
        if (!binding.lotInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.lotInput)
            val taskData = viewModel.getPickTaskDetails()

            if (taskData != null) {
                if (viewModel.isOverrideItemAttributes == 1) {
                    if (taskData.lotNumber == binding.lotInput.text.toString()) {
                        navigationFlow(taskData)
                    } else {
                         callLotValidationAPI(taskData)
                    }
                } else {
                    if (taskData.lotNumber.isNotEmpty()) {
                        if (taskData.lotNumber == binding.lotInput.text.toString()) {
                            navigationFlow(taskData)
                        } else {
                            binding.lotResponse.text = getString(R.string.alert_invalid_lot_number)
                            binding.lotInput.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.lotInput)
                        }
                    } else {
                        callLotValidationAPI(taskData)
                    }
                }
            }
        } else {
            binding.lotResponse.text = getString(R.string.lot_required)
            binding.lotInput.selectAll()
            showSoftKeyBoard(fragmentContext, binding.lotInput)
        }
    }

    private fun callLotValidationAPI(taskData: TaskDetails) {
        viewModel.validateLotNumber(
            LotNumReqBody(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                lotNumber = binding.lotInput.text.toString(),
                asnId = taskData.asnId,
                itemId = taskData.itemId,
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.lotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lotNumberResponse ->
                        FlareLog.i(TAG, "lotValidation Response: $lotNumberResponse")
                        if (lotNumberResponse.success != null && lotNumberResponse.success) {
                            FlareLog.i(TAG, "lotValidation Success: $lotNumberResponse")
                            if (lotNumberResponse.message != null) {
                                showSuccessSnackBar(lotNumberResponse.message)
                            }
                            val taskData = viewModel.getPickTaskDetails()
                            if (taskData != null) {
                                taskData.lotNumber = binding.lotInput.text.toString().trim()
                                taskData.expDate = lotNumberResponse.expiryDate
                                navigationFlow(taskData)
                            }
                        } else {
                            FlareLog.i(TAG, "lotValidation error: $lotNumberResponse")
                            binding.lotResponse.text = lotNumberResponse.message
                            binding.lotInput.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.lotInput)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lotValidation Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    private fun navigationFlow(taskData: TaskDetails) {
        when (AllocationType.entries.find { it.code == taskData.allocationType }) {
            AllocationType.ALLOCATED_FROM_ACTIVE,
            AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL -> {
                moveToNextScreen(taskData.itemExpDateTracked == "1",
                    taskData.itemSerialTracked == "4" || taskData.itemSerialTracked == "1")
            }
            AllocationType.PICK_FROM_ACTIVE,
            AllocationType.PICK_FROM_ACTIVE_RTV,
            AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV -> {
                moveToNextScreen(taskData.itemExpDateTracked == "1",
                    taskData.itemSerialTracked == "4")
            }
            AllocationType.PICK_FROM_CASE_PICK,
            AllocationType.ALLOCATED_FROM_CASE_PICK,
            AllocationType.PICK_FROM_CASE_PICK_RTV,
            AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV,
            AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV,
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV -> {
                val action = PickCartLotFragmentDirections.actionPickCartLotFragmentToPickCartCartFragment()
                getNavigationController().navigate(action)
            }
            else -> {
                // Handle other cases or do nothing
            }
        }
    }


    private fun moveToNextScreen(isExpiry: Boolean, isSerialTracked: Boolean) {
        when {
            isSerialTracked -> {
                val action = PickCartLotFragmentDirections.actionPickCartLotFragmentToPickCartSerialFragment()
                getNavigationController().navigate(action)
            }
            else -> {
                val action = PickCartLotFragmentDirections.actionPickCartLotFragmentToPickCartSlotFragment()
                getNavigationController().navigate(action)
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.lotInput.setText(scan?.barcode.toString())
            binding.lotInput.text?.length?.let {
                binding.lotInput.setSelection(it)
            }
            FlareLog.i(TAG, "Slot field focused")
            validatelot()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

    private fun handleContainerLayout(visible: Boolean) {
        if(visible)
        {
            binding.containerTv.visibility = View.VISIBLE
            binding.container.visibility = View.VISIBLE
        }else
        {
            binding.containerTv.visibility = View.GONE
            binding.container.visibility = View.GONE
        }
    }
}