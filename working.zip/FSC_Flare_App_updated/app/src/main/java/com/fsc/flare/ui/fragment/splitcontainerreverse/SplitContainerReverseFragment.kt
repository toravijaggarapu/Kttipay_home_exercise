package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReverseSplitContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.Putaway
import com.fsc.flare.source.data.dto.splitcontainerreverse.QtyBaseReq
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContDetailsRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContPutawayDetails
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitPutawayDetails
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuPutawayDetails
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "SplitContainerReverse"
@AndroidEntryPoint
class SplitContainerReverseFragment : BaseFragment(), FlareScannable {

    private val viewModel: SplitContainerReverseViewModel by activityViewModels()
    private lateinit var binding: FragmentReverseSplitContainerBinding
    var channelType = ""

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReverseSplitContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //Enable only fromContainer field initially
        enableDisableText(fromCont = true, false, false, false, false)

        binding.etFromContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtFromContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etSku.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtSkuResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        binding.etItmBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtItmBarcodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        binding.etQuantity.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtQuantityResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etToContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtToContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateFields()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.etFromContainer.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFields()
            }
            false
        }
        binding.etSku.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFields()
            }
            false
        }
        binding.etItmBarcode.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFields()
            }
            false
        }
        binding.etQuantity.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFields()
            }
            false
        }
        binding.etToContainer.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFields()
            }
            false
        }
    }

    private fun validateFields() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.etFromContainer.isFocused && !binding.etFromContainer.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "fromContainer field focused")
            validateFromContainerAPI()
        } else if (binding.etSku.isFocused && !binding.etSku.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "SKU field focused")
            validateSkuAPI()
        } else if (binding.etItmBarcode.isFocused && !binding.etItmBarcode.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Item barcode field focused")
            validateItemBarcodeAPI()
        } else if (binding.etQuantity.isFocused && !binding.etQuantity.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "QTY field focused")
            validateQtyAPI()
        } else if (binding.etToContainer.isFocused && !binding.etToContainer.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "toContainer field focused")
            validateSubmitSplitContainerAPI()
        }
    }


    /**
     * method to validate from container field from API
     */
    private fun validateFromContainerAPI() {
        viewModel.validateFromContainer(
            SplitContDetailsRequest(
                dataSource = "RF",
                putaway = SplitContPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    channel = "R"
                )
            )
        )
    }

    /**
     * method to validate sku field from API
     */
    private fun validateSkuAPI() {
        viewModel.validateSku(
            SplitSkuRequest(
                dataSource = "RF",
                putaway = SplitSkuPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    channel = channelType,
                    sku = binding.etSku.text.toString()
                )
            )
        )
    }

    /**
     * method to validate item barcode field from API
     */
    private fun validateItemBarcodeAPI() {
        viewModel.validateItemBarcode(
            SplitSkuRequest(
                dataSource = "RF",
                putaway = SplitSkuPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    channel = channelType,
                    sku = binding.etItmBarcode.text.toString()
                )
            )
        )
    }

    /**
     * method to validate QTY field from API
     */
    private fun validateQtyAPI() {
        viewModel.validateQty(
            QtyBaseReq(
                dataSource = "RF",
                putaway = Putaway(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    qty = binding.etQuantity.text.toString().toInt(),
                    channel = channelType
                )
            )
        )
    }

    /**
     * method to call submit split container API
     */
    private fun validateSubmitSplitContainerAPI() {
        viewModel.validateSubmitSplitContainer(
            SplitContSubmitRequest(
                dataSource = "RF",
                putaway = SplitContSubmitPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = binding.etFromContainer.text.toString(),
                    qty = binding.etQuantity.text.toString().toInt(),
                    channel = channelType,
                    sku = binding.etSku.text.toString(),
                    destination = binding.etToContainer.text.toString()
                )

            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribefromContObserver()
        subscribeSkuObserver()
        subscribeItemBarcodeObserver()
        subscribeQtyValidateObserver()
        subscribeSubmitContainerObserver()
    }


    /**
     * method for fromContainer response observer
     */
    private fun subscribefromContObserver() {
        viewModel.fromContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { fromConRes ->
                        FlareLog.i(TAG, "fromContainer response : ${response.data}")
                        when (fromConRes.statusHandler?.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "fromContainer Error response :" + fromConRes.statusHandler.error)
                                binding.etFromContainer.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etFromContainer)
                                binding.txtFromContainerResponse.text = fromConRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "fromContainer Success response")
                                if (fromConRes.container.channel != null) {
                                    channelType = fromConRes.container.channel
                                    when (channelType) {
                                        "R" -> {
                                            binding.wgItmBarcode.visibility = View.GONE
                                            binding.wgSku.visibility = View.VISIBLE
                                            viewModel.setInventoryType(fromConRes.container.inventoryType)
                                            enableDisableText(false, true, false, false, false)
                                            binding.etSku.requestFocus()
                                        }
                                        "F" -> {
                                            binding.wgItmBarcode.visibility = View.VISIBLE
                                            binding.wgSku.visibility = View.GONE
                                            viewModel.setInventoryType(fromConRes.container.inventoryType)
                                            enableDisableText(false, false, true, false, false)
                                            binding.etItmBarcode.requestFocus()
                                        }
                                        else -> Log.d(TAG, "subscribefromContObserver: ")
                                    }
                                } else {
                                    binding.etFromContainer.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etFromContainer)
                                    binding.txtFromContainerResponse.text = resources.getString(R.string.lbl_channel_type_not_available)
                                }
                            }
                            else ->
                                FlareLog.i(TAG, "fromContainer : ${response.data}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "fromContainer: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method for fromContainer response observer
     */
    private fun subscribeSkuObserver() {
        viewModel.skuResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skuRes ->
                        FlareLog.i(TAG, "sku response : ${response.data}")
                        when (skuRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "sku response Error :" + skuRes.statusHandler.error)
                                binding.etSku.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etSku)
                                binding.txtSkuResponse.text = skuRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "sku response Success")
                                enableDisableText(false, false, false, true, false)
                                binding.etQuantity.requestFocus()
                                binding.tvInvType.visibility = View.VISIBLE
                                binding.tvInvTypeValue.visibility = View.VISIBLE
                                binding.tvInvTypeValue.text = viewModel.getInventoryType()?.let { getInventoryDescription(it) }
                            }
                            else ->
                                FlareLog.i(TAG, "sku : ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "sku: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method for fromContainer response observer
     */
    private fun subscribeItemBarcodeObserver() {
        viewModel.itemBarcodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { itemBarcodeRes ->
                        FlareLog.i(TAG, "itemBarcode response : ${response.data}")
                        when (itemBarcodeRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "itemBarcode response Error :" + itemBarcodeRes.statusHandler.error)
                                binding.etItmBarcode.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etItmBarcode)
                                binding.txtItmBarcodeResponse.text = itemBarcodeRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "itemBarcode response Success")
                                enableDisableText(false, false, false, true, false)
                                binding.etQuantity.requestFocus()
                            }
                            else ->
                                FlareLog.i(TAG, "itemBarcode : ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "itemBarcode: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method for qty response observer
     */
    private fun subscribeQtyValidateObserver() {
        viewModel.qtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { qtyRes ->
                        FlareLog.i(TAG, "Qty response : ${response.data}")
                        when (qtyRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "Qty response Error :" + qtyRes.statusHandler.error)
                                showSoftKeyBoard(fragmentContext, binding.etQuantity)
                                binding.etQuantity.selectAll()
                                binding.txtQuantityResponse.text = qtyRes.statusHandler.message
                            }
                            "200" -> {
                                FlareLog.i(TAG, "Qty response Success")
                                enableDisableText(false, false, false, false, true)
                                binding.etToContainer.requestFocus()
                            }
                            else ->
                                FlareLog.i(TAG, "Qty : ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Qty: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method for submit split container observer
     */
    private fun subscribeSubmitContainerObserver() {
        viewModel.submitConResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { submitSplitConRes ->
                        FlareLog.i(TAG, "SubmitSplitCont response : ${response.data}")
                        when (submitSplitConRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "SubmitSplitCont Error :" + submitSplitConRes.statusHandler.error)
                                showErrorSnackBar(submitSplitConRes.statusHandler.message)
                            }
                            "200" -> {
                                FlareLog.i(TAG, "SubmitSplitCont Success")
                                showSuccessSnackBar(submitSplitConRes.statusHandler.message)
                                clearAllFields()
                                enableDisableText(true, false, false, false, false)
                                binding.etFromContainer.requestFocus()
                            }
                            else ->
                                FlareLog.i(TAG, "SubmitSplitCont : ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "SubmitSplitCont: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }




    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            binding.etFromContainer.isFocused -> {
                binding.etFromContainer.setText(scan?.barcode.toString())
                binding.etFromContainer.text?.length?.let {
                    binding.etFromContainer.setSelection(
                        it
                    )
                    validateFromContainerAPI()
                }

            }
            binding.etSku.isFocused -> {
                binding.etSku.setText(scan?.barcode.toString())
                binding.etSku.text?.length?.let {
                    binding.etSku.setSelection(
                        it
                    )
                    validateSkuAPI()
                }
            }
            binding.etItmBarcode.isFocused -> {
                binding.etItmBarcode.setText(scan?.barcode.toString())
                binding.etItmBarcode.text?.length?.let {
                    binding.etItmBarcode.setSelection(
                        it
                    )
                    validateItemBarcodeAPI()
                }
            }

            binding.etQuantity.isFocused -> {
                binding.etQuantity.setText(scan?.barcode.toString())
                binding.etQuantity.text?.length?.let {
                    binding.etQuantity.setSelection(
                        it
                    )
                    validateQtyAPI()
                }
            }
            binding.etToContainer.isFocused -> {
                binding.etToContainer.setText(scan?.barcode.toString())
                binding.etToContainer.text?.length?.let {
                    binding.etToContainer.setSelection(
                        it
                    )
                    validateSubmitSplitContainerAPI()
                }
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError:$scanRaw")
    }

    /**
     * method to enable/disable fields
     */
    private fun enableDisableText(fromCont: Boolean, sku: Boolean, itemBarcode: Boolean, qty: Boolean, toCont: Boolean) {
        binding.etFromContainer.isEnabled = fromCont
        binding.etSku.isEnabled = sku
        binding.etItmBarcode.isEnabled = itemBarcode
        binding.etQuantity.isEnabled = qty
        binding.etToContainer.isEnabled = toCont
    }

    /**
     * method to clear all fields
     */
    private fun clearAllFields() {
        binding.etFromContainer.text = null
        binding.etSku.text = null
        binding.etItmBarcode.text = null
        binding.etQuantity.text = null
        binding.etToContainer.text = null
    }
}