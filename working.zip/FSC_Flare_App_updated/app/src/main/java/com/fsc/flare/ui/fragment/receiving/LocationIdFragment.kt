package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentLocationIdBinding
import com.fsc.flare.databinding.ItemContainerNQuantityBinding
import com.fsc.flare.databinding.VirtualLabelsPrintRequestDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.location.DockDoorLocationRequest
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

private const val TAG = "LocationIdFragment"

/**
 * A simple [LocationIdFragment] class.
 */
@AndroidEntryPoint
class LocationIdFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var alertHandler: AlertHandler

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentLocationIdBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val asnData = viewModel.getAsn()
        if (asnData.stagingLocnId != 0 && viewModel.selectedContainerType == null) {
            validateStagingLocationId()
        }
    }

    private fun validateStagingLocationId() {
        FlareLog.i(TAG, "Validate location id called")
        val asnData = viewModel.getAsn()
        val stagingLocId = asnData.stagingLocnId
        if(stagingLocId != 0){
            viewModel.validateLocationId(
                DockDoorLocationRequest(
                    facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    locationId = stagingLocId.toString(),
                    locationClass = Constants.LocationClasses.STAGE
                )
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentLocationIdBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
      //  binding.tvReceiving.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        observeFlowOnUI { observeReceiveSubmitEvent() }
        observeFlowOnUI { observeReceiveError() }
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.validateLocIdResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    response.data?.let { locationResponse ->
                        FlareLog.i(TAG, "validateLocId Response: $locationResponse")
                        hideProgressBar()
                        val locationIdList = locationResponse.locations
                        if (locationIdList.isNotEmpty()) {
                            binding.stagingLocationId.setText(locationIdList[0].locationBarcode)
                            binding.stagingLocationId.setSelection(binding.stagingLocationId.text?.length ?: 0)
                            binding.stagingLocationId.requestFocus()
                            sharedPreferences.edit().putString(PreferenceKeys.Item.LOCATION_ID_INPUT, locationIdList[0].locationId.toString()).apply()
                            sharedPreferences.edit().putString(PreferenceKeys.Item.LOCATION_ID_BARCODE, locationIdList[0].locationBarcode).apply()
                            viewModel.setLocation(locationIdList[0])
                            /**
                             *  In virtual cases scenario, receiving submitted will be done in same screen.
                             */
                            viewModel.selectedContainerType.takeIf { it == PALLET || it == CASE }?.let {
                                binding.btnSubmitReceiving.isEnabled = true
                            } ?: run {
                                Handler(Looper.getMainLooper()).postDelayed({
                                    val action = LocationIdFragmentDirections.actionLocationIdFragmentToContainerIdFragment()
                                    getNavigationController().navigate(action)
                                }, 500)
                            }
                        } else {
                            showErrorSnackBar(resources.getString(R.string.lbl_no_staging_location_found))
                            binding.stagingLocationId.text = null
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(resources.getString(R.string.lbl_invalid_location))
                        FlareLog.e(TAG, "validateLocId Error: $message")
                    }
                }
            }
        }
    }

    /**
     * Function to observe Receive Submit Event
     */
    private suspend fun observeReceiveSubmitEvent() {
        viewModel.submitReceivingViewState.filterNotNull().collect { event ->
            when (event) {
                is SubmitReceiveEvent.ProgressBar -> {
                    binding.incProgressBar.progressLoading.visibility = if (event.isShowProgress) View.VISIBLE else View.GONE
                }

                SubmitReceiveEvent.CallReceivingSubmitAPI -> {
                    viewModel.virtualCasesReceivingSubmit()
                }

                /**
                 * After receiving success, show print labels dialog will be shown
                 */
                is SubmitReceiveEvent.ReceivingSuccessWithPrintLabels -> {
                    showSuccessSnackBar(event.successMessage)
                    delay(2000)
                    showPrintLabelsDialog()
                }

                /**
                 * Display Item Recall Alert dialog
                 */
                SubmitReceiveEvent.ItemRecallAlert -> {
                    alertHandler.showSimpleAlert(
                        title = getString(R.string.lbl_item_recall_lock_dialog_title),
                        message = getString(R.string.lbl_item_code_is_recalled_contact_the_supervisor),
                        icon = R.drawable.alert_accent
                    ) {
                        viewModel.virtualCasesReceivingSubmit()
                    }
                }

                is SubmitReceiveEvent.ReceivingSuccess -> {
                    // Do Nothing here. This action not intended for this screen.
                }

                /**
                 * Print labels snack alert will be shown
                 */
                is SubmitReceiveEvent.PrintLabelsSuccess -> {
                    showSuccessSnackBarStd(getString(R.string.case_lbls_printed_successfully)) { moveBackToDockDoorScan() }
                }

                /**
                 * After receiving success, show print requesters dialog will be shown
                 */
                is SubmitReceiveEvent.PrintRequesters -> {
                    alertHandler.showPrintRequesterDialog(
                        requesters = event.printRequesters
                    ) { printRequester ->
                        viewModel.printLabels(printRequester = printRequester)
                    }
                }
            }
        }
    }

    private fun showPrintLabelsDialog() {
        val printLabelsBinding = VirtualLabelsPrintRequestDialogBinding.inflate(
            LayoutInflater.from(requireContext()), null, false
        )
        printLabelsBinding.rvContainerLabels.layoutManager = LinearLayoutManager(requireContext())

        val printDialog = Dialog(requireContext()).apply {
            setContentView(printLabelsBinding.root)
            setCancelable(false)
        }

        printLabelsBinding.btnPrint.setOnClickListener {
            printDialog.dismiss()
            viewModel.getPrintRequesters()
        }

        printLabelsBinding.btnCancel.setOnClickListener {
            printDialog.dismiss()
            moveBackToDockDoorScan()
        }

        /**
         * This function will make sure the dialog layout is updated properly.
         */

        printDialog.show()
        printLabelsBinding.root.post {
            printLabelsBinding.root.requestLayout()
            printLabelsBinding.rvContainerLabels.adapter = VirtualLabelsAdapter(
                mContext = requireContext(),
                containersList = viewModel.virtualContainersList(),
                quantityPerContainer = viewModel.eachQuantityInCase
            )
        }
        printDialog.apply {
            window?.setBackgroundDrawableResource(android.R.color.transparent)
        }
    }

    /**
     * Observe screen error states.
     */
    private suspend fun observeReceiveError() {
        viewModel.submitReceivingErrorState.filterNotNull().collect { error ->

            val errorMessage = when (error) {

                SubmitReceiveErrorMessage.ClearError -> { "" }

                is SubmitReceiveErrorMessage.ResponseError -> {
                    binding.btnSubmitReceiving.isEnabled = true
                    error.errorMessage
                }

                SubmitReceiveErrorMessage.SomethingWentWrong -> {
                    binding.btnSubmitReceiving.isEnabled = true
                    getString(R.string.lbl_something_went_wrong)
                }

                is SubmitReceiveErrorMessage.NoPrintRequesters -> {
                    if (error.errorMessage.isNullOrEmpty()) {
                        alertHandler.showSimpleAlert(
                            message = getString(R.string.no_print_requester_found)
                        ) {
                            moveBackToDockDoorScan()
                        }
                    } else {
                        alertHandler.showConfirmationAlert(
                            message = getString(
                                R.string.want_to_retry_label_printing,
                                error.errorMessage
                            ),
                            positiveButtonTitle = getString(R.string.retry),
                            negativeButtonTitle = getString(R.string.alert_button_cancel),
                            positiveCallBack = {
                                viewModel.getPrintRequesters()
                            },
                            negativeCallBack = {
                                moveBackToDockDoorScan()
                            }
                        )
                    }
                    ""
                }

                is SubmitReceiveErrorMessage.UnableToPrintLabels -> {
                    val errorMessage = error.errorMessage.takeIf { it.isNotEmpty() } ?: Constants.ApplicationConstants.SOMETHING_WENT_WRONG
                    alertHandler.showConfirmationAlert(
                        message = getString(R.string.want_to_retry_label_printing, errorMessage),
                        positiveButtonTitle = getString(R.string.retry),
                        negativeButtonTitle = getString(R.string.alert_button_cancel),
                        positiveCallBack = {
                            viewModel.printRequester?.takeIf { it.isNotEmpty() }?.let {
                                viewModel.printLabels(printRequester = it)
                            } ?: viewModel.getPrintRequesters()
                        },
                        negativeCallBack = {
                            moveBackToDockDoorScan()
                        }
                    )
                    ""
                }
            }

            binding.etLocationRes.text = errorMessage
        }
    }

    private fun moveBackToDockDoorScan() {
        viewModel.clearVirtualCaseFlowData()
        getNavigationController().popBackStack(R.id.dockDoorFragment, inclusive = false)
    }

    private fun hideProgressBar() {
        binding.incProgressBar.progressLoading.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.incProgressBar.progressLoading.visibility = View.VISIBLE
    }

    private fun validateLocationId() {
        FlareLog.i(TAG, "Validate location id called")
        if (binding.stagingLocationId.text.toString().isNotEmpty()) {
            viewModel.validateLocationId(
                DockDoorLocationRequest(
                    facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                barcode = binding.stagingLocationId.text.toString(),
                locationClass = Constants.LocationClasses.STAGE
                )
            )
        } else {
            trackErrorMessage(resources.getString(R.string.lbl_input_staging_location))
            binding.etLocationRes.text = resources.getString(R.string.lbl_input_staging_location)
            showSoftKeyBoard(fragmentContext, binding.stagingLocationId)
        }
    }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    super.onTouch(v, event)
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.stagingLocationId.isFocused && !binding.stagingLocationId.text.isNullOrEmpty()) {
                        validateLocationId()
                    } else {
                        binding.etLocationRes.text = resources.getString(R.string.lbl_input_staging_location)
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        val asnData = viewModel.getAsn()
        val item = viewModel.getItem()
        binding.dockDoor.text = sharedPreferences.getString(PreferenceKeys.Item.DD_NUMBER, null)
        binding.asn.text = asnData.asnNumber
        binding.packageBarcode.text = item.itemBarCode
        binding.itemCode.text = item.itemName
        binding.packageBarcodeDesc.text = item.description
        binding.inventoryTypeDesc.text = viewModel.getInventoryTypeSelected()
        val lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
        val expirationDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
        if (item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()) {
            binding.lotTv.visibility = View.VISIBLE
            binding.lot.visibility = View.VISIBLE
            binding.lot.text = lotNumber
        }
        if (item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()) {
            binding.dateTv.visibility = View.VISIBLE
            binding.date.visibility = View.VISIBLE
            binding.date.text = expirationDate
        }
        if (item.tracking.countryOfOriginRequired == "1") {
            binding.cooTv.visibility = View.VISIBLE
            binding.coo.visibility = View.VISIBLE
            binding.coo.text = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null)
        }

        if(item.hazmatRequired == "Y"){
            binding.itemClassCodeTv.visibility = View.VISIBLE
            binding.itemClassCode.visibility = View.VISIBLE
            binding.itemClassCode.text = item.hazardous?.hazardClassIMDG
            binding.slash.visibility = View.VISIBLE
            binding.division.visibility = View.VISIBLE
            binding.division.text = item.hazardous?.hazmatDivisionText
        }
        binding.qty.text = sharedPreferences.getString(PreferenceKeys.Item.QUANTITY_INPUT, null)
        binding.uom.text = sharedPreferences.getString(PreferenceKeys.Item.UOM_INPUT, null)
        binding.status.text = sharedPreferences.getString(PreferenceKeys.Item.STATUS_INPUT, null)
        binding.stagingLocationId.requestFocus()
        binding.stagingLocationId.setOnEditorActionListener { v, actionId, event ->
            super.onEditorAction(v, actionId, event)
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "locationId Action Done")
                // Validation required
                validateLocationId()
            }
            false
        }
        binding.stagingLocationId.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etLocationRes.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.stagingLocationId.onFocusChangeListener = this

        /**
         *  In virtual cases scenario, newly added UI will be shown.
         */
        viewModel.selectedContainerType.takeIf { it == PALLET || it == CASE }?.let {
            if (it == PALLET) {
                binding.grpPalletNumber.visibility = View.VISIBLE
                binding.tvPalletNumber.text = viewModel.newPalletNumber
                binding.uom.text = getString(R.string.pl)
                binding.qty.text = "1"
            } else {
                binding.uom.text = getString(R.string.cs)
                binding.qty.text = viewModel.casesQuantity.toString()
            }
            binding.grpTotalQuantity.visibility = View.VISIBLE
            binding.tvQuantity.text = sharedPreferencesBase.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, "")
            binding.btnSubmitReceiving.visibility = View.VISIBLE
        }

        /**
         * Submit receiving.
         */
        binding.btnSubmitReceiving.setOnClickListener {
            binding.btnSubmitReceiving.isEnabled = false
            viewModel.checkRecallLocksAndProceed()
        }

        binding.scrollViewLayout.post {
            binding.scrollViewLayout.fullScroll(View.FOCUS_DOWN)
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.stagingLocationId.setText(scan?.barcode.toString().trim())
        binding.stagingLocationId.text?.length?.let {
            binding.stagingLocationId.setSelection(it)
        }
        FlareLog.i(TAG, "Location field focused")
        validateLocationId()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.onClearData()
    }
}

private class VirtualLabelsAdapter(
    private val mContext: Context,
    private val containersList: List<String>,
    private val quantityPerContainer: Int
) : RecyclerView.Adapter<VirtualLabelsAdapter.VirtualLabelsViewHolder>() {

    class VirtualLabelsViewHolder(
        private val binding: ItemContainerNQuantityBinding,
        private val quantity: Int,
        private val mContext: Context
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(containerName: String, isLastItem: Boolean = false) {
            binding.tvContainerNumber.text = containerName
            binding.tvQuantity.text = mContext.getString(R.string.qty_ea, quantity)
            binding.vSeparator.visibility = if (isLastItem) View.INVISIBLE else View.VISIBLE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VirtualLabelsViewHolder(
            ItemContainerNQuantityBinding.inflate(LayoutInflater.from(mContext), parent, false),
            quantityPerContainer,
            mContext
        )

    override fun getItemCount() = containersList.size

    override fun onBindViewHolder(holder: VirtualLabelsViewHolder, position: Int) {
        holder.bind(containersList[position], isLastItem = position == containersList.size - 1)
    }
}