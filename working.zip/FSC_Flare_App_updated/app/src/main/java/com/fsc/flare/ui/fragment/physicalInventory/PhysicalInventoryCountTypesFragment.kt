package com.fsc.flare.ui.fragment.physicalInventory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPhysicalInventoryCountTypesBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.physicalInventory.PhysicalInventoryBatchStatus.BATCH_AUDIT_COUNT_IN_PROGRESS
import com.fsc.flare.ui.fragment.physicalInventory.PhysicalInventoryBatchStatus.BATCH_PRIMARY_COUNT_IN_PROGRESS
import com.fsc.flare.ui.fragment.physicalInventory.PhysicalInventoryBatchStatus.BATCH_RECOUNT_IN_PROGRESS
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "PhysicalInventoryCountTypesFragment"
private const val PHYSICAL_INVENTORY_COUNT_TYPES = "PHYSICAL_INVENTORY_COUNT_TYPES"
private const val PI_PREFERRED_CONTAINER_TYPE = "PI_PREFERRED_CONTAINER_TYPE"
private const val PI_PREFERRED_PALLET_TYPE = "PI_PREFERRED_PALLET_TYPE"

object PhysicalInventoryBatchStatus{
     const val BATCH_PRIMARY_COUNT_IN_PROGRESS = "Primary Count InProgress"
     const val BATCH_RECOUNT_IN_PROGRESS = "Recount InProgress"
     const val BATCH_AUDIT_COUNT_IN_PROGRESS = "Audit Count InProgress"
}

@AndroidEntryPoint
class PhysicalInventoryCountTypesFragment : BaseFragment() {

    private val viewModel: PhysicalInventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentPhysicalInventoryCountTypesBinding

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPhysicalInventoryCountTypesBinding.inflate(inflater, container, false)
        binding.tvPhysicalInventory.text =
            sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        viewModel.getPhysicalInventoryLookUps()
        subscribeLookUpObserver()
        subscribeBatchSummaryObserver()
        subscribeBatchTaskDetailsObserver()
        return binding.root
    }

    private fun subscribeLookUpObserver() {
        viewModel.lookUpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { it ->
                            when (it.lookupName) {
                                PHYSICAL_INVENTORY_COUNT_TYPES -> {
                                    val countTypesList =
                                        ArrayList(lookUpResponse.lookups[0].lookupCodes.map { it.lookupCodeDescription })
                                    binding.countTypesDropDown.setOptions(countTypesList)
                                }

                                PI_PREFERRED_CONTAINER_TYPE -> {
                                    viewModel.casePickCountConfigType =
                                        it.lookupCodes[0].lookupCodeDescription
                                }

                                PI_PREFERRED_PALLET_TYPE -> {
                                    viewModel.reserveCountConfigType =
                                        it.lookupCodes[0].lookupCodeDescription
                                }

                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchSummaryObserver() {
        viewModel.batchSummaryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchSummaryResp ->
                        if(!batchSummaryResp.batchNumber.isNullOrEmpty()){
                            FlareLog.i(TAG, "batchSummary success: $batchSummaryResp")
                            viewModel.batchSummaryResp = batchSummaryResp
                            if(batchSummaryResp.batchStatus == BATCH_PRIMARY_COUNT_IN_PROGRESS ||
                                batchSummaryResp.batchStatus ==  BATCH_RECOUNT_IN_PROGRESS||
                                batchSummaryResp.batchStatus == BATCH_AUDIT_COUNT_IN_PROGRESS){
                                viewModel.getBatchTaskDetails()
                            }else{
                                val action =
                                    PhysicalInventoryCountTypesFragmentDirections.actionPhysicalInventoryCountTypesFragmentToBatchAcceptOrSkipFragment()
                                getNavigationController().navigate(action)
                            }
                        }else{
                            showSuccessSnackBar(getString(R.string.no_tasks_exist))
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchSummary Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun subscribeBatchTaskDetailsObserver() {
        viewModel.batchTaskDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { batchTaskDetailsResp ->
                        FlareLog.i(TAG, "batchTaskDetails success: $batchTaskDetailsResp")
                        if(batchTaskDetailsResp.success){
                            viewModel.isActiveLocationEmpty = batchTaskDetailsResp.itemDetails.isNullOrEmpty()
                            val action = PhysicalInventoryCountTypesFragmentDirections.actionPhysicalInventoryCountTypesFragmentToScanLocationFragment()
                            getNavigationController().navigate(action)
                        }else{
                            showErrorSnackBar(batchTaskDetailsResp.message)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "batchTaskDetails Error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                showErrorSnackBar(msgArray[1])
                            }
                        } else {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.countTypesDropDown.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            sharedPreferencesBase.edit()
                .putString(PreferenceKeys.PhysicalInventory.SELECTED_COUNT_TYPE, isUpdated).apply()
            viewModel.getBatchSummary(null,"", isUpdated)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

}