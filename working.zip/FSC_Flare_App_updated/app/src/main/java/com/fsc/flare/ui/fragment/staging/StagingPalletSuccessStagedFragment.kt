package com.fsc.flare.ui.fragment.staging

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStagingPalletSuccessStagedBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "StagingPalletSuccessStagedFragment"
@AndroidEntryPoint
class StagingPalletSuccessStagedFragment : BaseFragment(), FlareScannable {

    private val viewModel: StagingViewModel by activityViewModels()
    private lateinit var binding: FragmentStagingPalletSuccessStagedBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStagingPalletSuccessStagedBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showSuccessSnackBar(resources.getString(R.string.pallet_is_staged))
        //display previously captured carton/pallet and stagingLocation number
        binding.tvPalletNumberValue.text = sharedPreferences.getString(PreferenceKeys.STAGING_PALLET_NUMBER, "")
        binding.tvStagedLocationValue.text = sharedPreferences.getString(PreferenceKeys.STAGING_LOCATION, "")
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }


}