package com.fsc.flare.ui.fragment.inventory.palletizeib

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeIbPalletDetailBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerModel
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostData
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.PRINT_CASE_LABEL
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.Constants.ContainerType.CASE
import com.fsc.flare.utils.Constants.LocationClasses.CASE_PICK
import com.fsc.flare.utils.Constants.LocationClasses.RESERVE
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeIbPalletDetailFragment"

/**
 * A simple [PalletizeIbPalletDetailFragment] class.
 */
@AndroidEntryPoint
class PalletizeIbPalletDetailFragment : BaseFragment(), FlareScannable, PalletizeIbContainerAdapter.RemoveContainerInterface {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PalletizeIbViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeIbPalletDetailBinding
    lateinit var cb1: CustomVisibilityCallback
    lateinit var adapter: PalletizeIbContainerAdapter
    private var containerList = ArrayList<CaseTransferContainerModel>()
    private var childContainerList = ArrayList<CaseTransferContainerModel>()
    private var palletItemId: String? = null
    private var palletInventoryType: String? =null
    private val checkedContainers = ArrayList<String>()
    private var containerNbrList = ArrayList<String>()
    private var itemUomConversionRateUtil: ItemUOMConversionRateUtil? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        updateUI()
        super.onResume()
        handleContainerCountView()
        cb1.onVisibilityChange(true)
    }

    private fun handleContainerCountView() {
        if(containerList.size>0)
        {
            binding.labelLayout.visibility = View.VISIBLE
            binding.tvQty.text = containerList.size.toString().plus(" ").plus(getString(R.string.lbl_view))
            binding.btnEndPallet.isEnabled = true
        }else
        {
            binding.labelLayout.visibility = View.GONE
            binding.btnEndPallet.isEnabled = false
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizeIbPalletDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        setupRecyclerView()

        palletItemId = viewModel.getItmID()
        palletInventoryType = viewModel.getInventoryType()
      //  updateUI()
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtContainer)
                    validateContainerApi()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.edtContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtContainer)
                FlareLog.i(TAG, "Container field focused")
                validateContainerApi()
            }
            false
        }

        binding.btnEndPallet.setOnClickListener {
            updateTempTableData()
        }
        subscribeObservers()

        binding.tvQty.setOnClickListener{
                showScannedContainersList()
        }

        binding.edtContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerError.text = null
                enableSubmitButton()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun showScannedContainersList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.containers_scanned))
        checkedContainers.clear()
        containerNbrList  = ArrayList(containerList.map { it.containerNumber})

        val ContainersArray = containerList.map { "${it.containerNumber}    ${it.qty} Units" }.toTypedArray()
        builder.setMultiChoiceItems(ContainersArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedContainers.add(containerNbrList[which])
            }
            else
            {
                checkedContainers.remove(containerNbrList[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            removeCheckedContainers(checkedContainers)
            handleContainerCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }

    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedContainers.size>0
        if(checkedContainers.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    fun removeCheckedContainers(checkedContainers: ArrayList<String>) {
        val filteredContianers = containerList.filter { it -> it.containerNumber !in checkedContainers }
        removeSelectedContainers( containerList.filter { it -> it.containerNumber in checkedContainers })
        containerList.clear()
        containerList.addAll(filteredContianers)
        if(containerList.size == 0){
           if(viewModel.getPalletItemCode()== null ){
               palletItemId = null
               palletInventoryType = null
               binding.palletQtyLayout.visibility = View.GONE
               binding.nbrOfContainerLayout.visibility = View.GONE
               binding.palletItmCodeLayout.visibility = View.GONE
               binding.palletItmDescLayout.visibility = View.GONE
               binding.palletInventoryType.visibility = View.GONE
           }
        }
    }

    private fun updateUI() {
        containerList.clear()
        childContainerList.clear()
        viewModel.getChildContainerList()?.let { childContainerList.addAll(it.toList()) }

        //Once the End Palletize is done and moved to destination location page, click back fom destination location, will update UI from temp. response.
        val tempFinalTableResponse = viewModel.getTempTableResponseFinal()
        if (tempFinalTableResponse != null) {
            binding.tvPalletNumberValue.text = tempFinalTableResponse.palletNumber
            var palletQty = 0
            if (!tempFinalTableResponse.containerDetails.isNullOrEmpty()) {
                for (container in tempFinalTableResponse.containerDetails!!) {
                    palletQty += container.containerQty
                    val tempContainerList: List<CaseTransferContainerModel> = childContainerList.filter { it.containerNumber == container.containerNumber}
                    if(tempContainerList.isEmpty())
                    {
                        val caseTransferContainerModel = CaseTransferContainerModel(
                            containerNumber = container.containerNumber!!,
                            qty = container.containerQty.toLong(),
                            itemId =  tempFinalTableResponse.itemId,
                            itemCode = tempFinalTableResponse.itemCode,
                            itemDesc = tempFinalTableResponse.itemDescription,
                            currentLoc = container.locationId.toString(),
                            inventoryType = viewModel.getInventoryType()
                        )
                        containerList.add(caseTransferContainerModel)
                    }
                }
            }
            val getCurrentLocation = viewModel.getPalletCurrentLocation()
            updateData(
                palletNumber = tempFinalTableResponse.palletNumber,
                palletQty = palletQty.toLong(),
                nbrOfContainer = tempFinalTableResponse.containerDetails!!.size.toLong(),
                itemCode = tempFinalTableResponse.itemCode,
                itemDescription = tempFinalTableResponse.itemDescription,
                currentLoc = getCurrentLocation
            )
            enableButtonCheck()
            updateContainerCountAndQtyCount()
        } else {
            //If the temp table response is not null, set the container list and item detail.
            val tempTableResponse = viewModel.getTempTableResponse()
            if (tempTableResponse?.containerDetails != null) {
                var itemCode = ""
                var itemDesc = ""
                if (!tempTableResponse.itemCode.isNullOrEmpty()) {
                    itemCode = tempTableResponse.itemCode!!
                    itemDesc = tempTableResponse.itemDescription!!
                }
                var palletQty: Long = 0
                for (containerRes in tempTableResponse.containerDetails!!) {
                    palletQty += containerRes.containerQty
                    val tempContainerList: List<CaseTransferContainerModel> = childContainerList.filter { it.containerNumber == containerRes.containerNumber}
                    if(tempContainerList.isEmpty()) {
                        val caseTransferContainerModel = CaseTransferContainerModel(
                            containerNumber = containerRes.containerNumber!!,
                            qty = containerRes.containerQty.toLong(),
                            itemId = tempTableResponse.itemId,
                            itemCode = tempTableResponse.itemCode,
                            itemDesc = tempTableResponse.itemDescription,
                            inventoryType = viewModel.getInventoryType(),
                            currentLoc = containerRes.locationId.toString()
                        )
                        containerList.add(caseTransferContainerModel)
                    }
                }
                updateData(
                    palletNumber = tempTableResponse.palletNumber,
                    palletQty = palletQty,
                    nbrOfContainer = tempTableResponse.containerDetails!!.size.toLong(),
                    itemCode = itemCode,
                    itemDescription = itemDesc,
                    currentLoc = ""
                )
                enableButtonCheck()
                updateContainerCountAndQtyCount()
            } else {
                //Update the UI from the Flare system data.
                val palletNumber = viewModel.getPalletNumber()
                val palletQty = viewModel.getPalletQty()
                val palletNbrOfCase = viewModel.getPalletNbrOfCase()
                val palletItemCode = viewModel.getPalletItemCode()
                val palletItemDesc = viewModel.getPalletItemDesc()
                val palletCurrentLocation = viewModel.getPalletCurrentLocation()
                updateData(
                    palletNumber = palletNumber,
                    palletQty = palletQty,
                    nbrOfContainer = palletNbrOfCase,
                    itemCode = palletItemCode,
                    itemDescription = palletItemDesc,
                    currentLoc = palletCurrentLocation
                )
               /* val getChildContainerList = viewModel.getChildContainerList()
                if (!getChildContainerList.isNullOrEmpty()) {
                    childContainerList.addAll(getChildContainerList)
                }*/
            }
        }
    }

    private fun updateData(
        palletNumber: String?,
        palletQty: Long?,
        nbrOfContainer: Long?,
        itemCode: String?,
        itemDescription: String?,
        currentLoc: String?
    ) {
        binding.tvPalletNumberValue.text = palletNumber

        if (palletQty != null && palletQty > 0) {
            binding.tvPalletQtyValue.text = "$palletQty"
            binding.palletQtyLayout.visibility = View.VISIBLE
        } else {
            binding.palletQtyLayout.visibility = View.GONE
        }
        if (nbrOfContainer != null && nbrOfContainer > 0) {
            binding.tvNbrOfContainerValue.text = "$nbrOfContainer"
            binding.nbrOfContainerLayout.visibility = View.VISIBLE
        } else {
            binding.nbrOfContainerLayout.visibility = View.GONE
        }
        if (itemCode.isNullOrEmpty()) {
            binding.palletItmCodeLayout.visibility = View.GONE
        } else {
            binding.tvItemCodeValue.text = itemCode
            binding.palletItmCodeLayout.visibility = View.VISIBLE
        }
        if (itemDescription.isNullOrEmpty()) {
            binding.palletItmDescLayout.visibility = View.GONE
        } else {
            binding.tvItemDescValue.text = itemDescription
            binding.palletItmDescLayout.visibility = View.VISIBLE
        }
        if (!currentLoc.isNullOrEmpty()) {
            binding.tvCurrentLocationValue.text = currentLoc
            binding.currentLocLayout.visibility = View.VISIBLE
        } else {
            binding.currentLocLayout.visibility = View.GONE
        }
        if(!palletInventoryType.isNullOrEmpty())
        {
            binding.palletInventoryType.visibility = View.VISIBLE
            binding.tvInventoryType.text= palletInventoryType?.let { getInventoryDescription(it) }
        }else{
            binding.palletInventoryType.visibility = View.GONE
        }
    }

    private fun subscribeObservers() {
        viewModel.printContainerLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.deleteContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { deleteResponse ->
                        Log.d("debug", "delete Container:$deleteResponse")
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                 //       showSnackBar(message)
                        Log.d("debug", "delete Container Error:$message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.updateTempTableResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tempTableSubmitResponse ->
                        if (tempTableSubmitResponse.success && tempTableSubmitResponse.tempLpn != null) {
                            viewModel.setTempTableResponseFinal(tempTableSubmitResponse.tempLpn)
                            viewModel.setTempTableTransactionIdentifier(tempTableSubmitResponse.tempLpn!!.transactionIdentifier)
                            navigateToDestinationLocation()
                        } else {
                            showErrorSnackBar(resources.getString(R.string.lbl_unable_update_the_temp_data))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.caseDetailResp.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { caseResponse ->
                        if (caseResponse.success && caseResponse.container.isNotEmpty()) {
                            val restrictedLockCodes = getRestrictedLockCodes()
                            val lockCodes = caseResponse.container[0].lockCodes?.mapNotNull { it.code } ?: emptyList()
                            val isAllowedOnCCPendingLocation = sharedPreferencesBase.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)
                            if (!caseResponse.container[0].item?.uomConversions.isNullOrEmpty() && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS, false))) {
                                itemUomConversionRateUtil = caseResponse.container[0].item?.uomConversions?.let { ItemUOMConversionRateUtil(it) }
                                viewModel.palletUomDefined(itemUomConversionRateUtil?.isPalletUomDefined == true)
                                itemUomConversionRateUtil?.getCasesQtyInAPallet()?.let { viewModel.setDefinedCaseQtyPerPallet(it) }
                            }
                            val container = caseResponse.container[0]
                            if (!(container.currentLocationClass == RESERVE || container.currentLocationClass == CASE_PICK)) {
                                displayErrorMessage(getString(R.string.case_must_belong_to_reserve_or_casepick))
                            } else if (!container.containerType.equals(CASE, ignoreCase = true)) {
                                displayErrorMessage(getString(R.string.invalid_container))
                            } else if (container.status!="20") {
                                displayErrorMessage(getString(R.string.container_not_in_putway_status))
                            } else if (caseResponse.container[0].lockCode == "CC") {
                                displayErrorMessage(getString(R.string.cycle_count_in_progress_for_given_location))
                            } else if (caseResponse.container[0].cyclePending == YES && !isAllowedOnCCPendingLocation) {
                                displayErrorMessage(getString(R.string.cycle_count_is_pending_for_given_location))
                            } else if (!palletItemId.isNullOrEmpty() && palletItemId != container.item?.itemId.toString()) {
                                displayErrorMessage(getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check))
                            } else if (!palletInventoryType.isNullOrEmpty() && palletInventoryType != container.inventoryType) {
                                displayErrorMessage(getString(R.string.containers_have_different_inventory_type_can_not_palletize_together))
                            } else if (itemUomConversionRateUtil != null && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) &&
                                        (itemUomConversionRateUtil?.isPalletUomDefined == true && (childContainerList.size + containerList.size) >= viewModel.getDefinedCaseQtyPerPallet()!!))) {
                                displayErrorMessage(resources.getString(R.string.lbl_max_pallet_capacity_is_reached))
                            } else if (lockCodes.any { restrictedLockCodes.contains(it)}) {
                                displayErrorMessage(getString(R.string.case_which_has_damage_lock_cannot_be_allowed))
                            } else {
                                val case = CaseTransferContainerModel(
                                    containerNumber = container.containerNumber,
                                    itemId = container.item?.itemId.toString(),
                                    itemCode = container.item?.itemCode,
                                    currentLoc = container.currentStageLoc,
                                    itemDesc = container.item?.itemDesc,
                                    qty = container.item?.itemQty?.toLong() ?: 0,
                                    inventoryType = container.inventoryType
                                )
                                if (!container.parentContainerNumber.isNullOrEmpty()) {
                                    showAlertDialog("",resources.getString(R.string.lbl_do_you_want_to_deassociate_ib_container_from_pallet, container.parentContainerNumber),
                                        onPositiveClick = {
                                            addToList(case)
                                            updateContainerCountAndQtyCount()
                                        },
                                        onNegativeClick = { })
                                } else {
                                    addToList(case)
                                    updateContainerCountAndQtyCount()
                                }
                            }
                        } else {
                            displayErrorMessage(getString(R.string.invalid_container_number))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { it ->
                        displayErrorMessage(it)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun getRestrictedLockCodes():List<String> {
        val restrictLocksHashMap: HashMap<String, String> = Gson().fromJson(sharedPreferencesBase.getString(PreferenceKeys.RESTRICT_LOCKS_HASH_MAP,""), object : TypeToken<HashMap<String?, String?>?>() {}.type)
        return restrictLocksHashMap.keys.toList()
    }

    private fun displayErrorMessage(message: String) {
        binding.edtContainer.requestFocus()
        binding.containerError.text = message
        binding.edtContainer.selectAll()
    }

    private fun enableSubmitButton() {
        binding.btnEndPallet.isEnabled = containerList.isNotEmpty()
    }

    private fun navigateToDestinationLocation() {
        //Navigate to the Destination location page.
        val action = PalletizeIbPalletDetailFragmentDirections.actionPalletizeIbPalletDetailFragmentToPalletizeIbDestinationLocationFragment()
        getNavigationController().navigate(action)
    }

    override fun removeClick(position: Int) {
        if (containerList.isNotEmpty()) {
            val container = containerList[position]
            val containerQty = container.qty

            if(viewModel.getTempTableTransactionIdentifier()!=0)
            {
                viewModel.deleteTempTableContainer(container.containerNumber,viewModel.getTempTableTransactionIdentifier().toString())
            }

            //Update the number of Container and pallet qty values.
            val nbrOfContainer = if (binding.tvNbrOfContainerValue.text.toString().isEmpty()) 0 else binding.tvNbrOfContainerValue.text.toString().toLong()
            val palletQty = if (binding.tvPalletQtyValue.text.toString().isEmpty()) 0 else binding.tvPalletQtyValue.text.toString().toLong()
            binding.tvPalletQtyValue.text = (palletQty - containerQty).toString()
            binding.tvNbrOfContainerValue.text = (nbrOfContainer.toInt() - 1).toString()
            containerList.removeAt(position)
//            adapter.notifyDataSetChanged()
            enableButtonCheck()
            updateContainerCountAndQtyCount()

            if (containerList.isEmpty() && childContainerList.isEmpty()) {
                binding.palletQtyLayout.visibility = View.GONE
                binding.nbrOfContainerLayout.visibility = View.GONE
                binding.palletItmCodeLayout.visibility = View.GONE
                binding.palletItmDescLayout.visibility = View.GONE
                binding.currentLocLayout.visibility = View.GONE
                binding.palletInventoryType.visibility = View.GONE
                palletItemId = null
                palletInventoryType = null
                viewModel.saveItemInfo(null, null)
            }
        }
    }

    fun removeSelectedContainers(selectedList: List<CaseTransferContainerModel>){
        if (selectedList.isNotEmpty()) {
            for(container in selectedList){
                val containerQty = container.qty
                if(viewModel.getTempTableTransactionIdentifier()!=0)
                {
                    viewModel.deleteTempTableContainer(container.containerNumber,viewModel.getTempTableTransactionIdentifier().toString())
                }

                //Update the number of Container and pallet qty values.
                val nbrOfContainer = if (binding.tvNbrOfContainerValue.text.toString().isEmpty()) 0 else binding.tvNbrOfContainerValue.text.toString().toLong()
                val palletQty = if (binding.tvPalletQtyValue.text.toString().isEmpty()) 0 else binding.tvPalletQtyValue.text.toString().toLong()
                binding.tvPalletQtyValue.text = (palletQty - containerQty).toString()
                binding.tvNbrOfContainerValue.text = (nbrOfContainer.toInt() - 1).toString()
//                containerList.removeAt(position)
//            adapter.notifyDataSetChanged()
                enableButtonCheck()
                updateContainerCountAndQtyCount()

                if (containerList.isEmpty() && childContainerList.isEmpty()) {
                    binding.palletQtyLayout.visibility = View.GONE
                    binding.nbrOfContainerLayout.visibility = View.GONE
                    binding.palletItmCodeLayout.visibility = View.GONE
                    binding.palletItmDescLayout.visibility = View.GONE
                    binding.currentLocLayout.visibility = View.GONE
                    binding.palletInventoryType.visibility = View.GONE
                    palletItemId = null
                    palletInventoryType = null
                    viewModel.saveItemInfo(null, null)
                }
            }
        }
    }

    private fun updateContainerCountAndQtyCount() {
        enableSubmitButton()
        var caseScannedCount = 0
        if (containerList.isNotEmpty()) {
            caseScannedCount = containerList.size
        }

        binding.tvQty.text = caseScannedCount.toString().plus(" ").plus(getString(R.string.lbl_view))
        if (caseScannedCount > 0) {
            binding.labelLayout.visibility = View.VISIBLE
        } else {
            binding.labelLayout.visibility = View.GONE
        }
    }

    private fun enableButtonCheck() {
        binding.btnEndPallet.isEnabled = containerList.isNotEmpty()
    }

    private fun validateContainerApi() {
        if (binding.edtContainer.text.toString().trim().isNotEmpty()) {
            //Check if container is already scanned.
            if (isContainerScanned(binding.edtContainer.text.toString().trim())) {
                binding.containerError.text = getString(R.string.case_transfer_container_already_scanned)
            } else {
                //validate container API.
                binding.containerError.text = null
                viewModel.getCaseDetails(binding.edtContainer.text.toString().trim())
            }
        }
    }

    private fun addToList(case: CaseTransferContainerModel) {

        if (palletItemId == null) {
            palletItemId = case.itemId.toString()
        }
        if(palletInventoryType == null)
        {
            palletInventoryType = case.inventoryType
        }
        // save the item info
        viewModel.saveItemInfo(palletItemId, palletInventoryType)

        // Show / Hide the New Pallet button based on the transaction param configuration.
        if (viewModel.getMPRTransactionParamData() != null) {
            if (viewModel.getTransactionParamByTransCode(PRINT_CASE_LABEL)) {
                //Call the print case label API.
                printContainerLabels(case)
            }
        }
        containerList.add(case)
        viewModel.setItemId(case.itemId?.toLong())
        binding.containerError.text = null
        binding.edtContainer.text = null

        //Update the number of Container and pallet qty values.
        val nbrOfContainer = if (binding.tvNbrOfContainerValue.text.toString().isEmpty()) 0 else binding.tvNbrOfContainerValue.text.toString().toLong()
        val palletQty = if (binding.tvPalletQtyValue.text.toString().isEmpty()) 0 else binding.tvPalletQtyValue.text.toString().toLong()

        binding.tvPalletQtyValue.text = (palletQty + case.qty).toString()
        binding.tvNbrOfContainerValue.text = (nbrOfContainer.toInt() + 1).toString()
        binding.tvItemCodeValue.text = case.itemCode
        binding.tvItemDescValue.text = case.itemDesc

        binding.palletQtyLayout.visibility = View.VISIBLE
        binding.nbrOfContainerLayout.visibility = View.VISIBLE
        binding.palletItmCodeLayout.visibility = View.VISIBLE
        binding.palletItmDescLayout.visibility = View.VISIBLE

        if(!palletInventoryType.isNullOrEmpty())
        {
            binding.palletInventoryType.visibility = View.VISIBLE
            binding.tvInventoryType.text= palletInventoryType?.let { getInventoryDescription(it) }
        }else{
            binding.palletInventoryType.visibility = View.GONE
        }
    }

    private fun isContainerScanned(containerNbr: String): Boolean {
        var isScannedAlready = false
        if (containerList.isNotEmpty()) {
            for (containerObj in containerList) {
                if (containerObj.containerNumber.equals(containerNbr, true)) {
                    isScannedAlready = true
                    break
                }
            }
        }
        if (!isScannedAlready) {
            //Need to check for Flare system data, if the Pallet has any child containers or not. (this list will not be updated in RecyclerView)
            if (childContainerList.isNotEmpty()) {
                for (containerObj in childContainerList) {
                    if (containerObj.containerNumber.equals(containerNbr, true)) {
                        isScannedAlready = true
                        break
                    }
                }
            }
        }

        return isScannedAlready
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtContainer.setText(scan?.barcode.toString())
            binding.edtContainer.text?.length?.let {
                binding.edtContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Container field focused")
            validateContainerApi()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun printContainerLabels(case: CaseTransferContainerModel) {
        if (viewModel.getPrinterNameData().isNotEmpty()) {
            val printContainerLabelRequest = PrintContainerLabelRequest(
                containerNumber = case.containerNumber,
                itemId = case.itemId.toString(),
                containerQty = case.qty.toString(),
                printRequester = viewModel.getPrinterNameData(),
                serialNumbers = arrayListOf()
            )
            viewModel.printContainerLabels(printContainerLabelRequest)
        } else {
            FlareLog.i(TAG, "Print Requester is not selected")
        }
    }
    private fun updateTempTableData() {
        val itemId = viewModel.getItemId().toString()
        val containerNewList = ArrayList<PalletRepackPostData>()
        if (containerList.isNotEmpty()) {
            for (containerObj in containerList) {
                val palletRepackPostData = PalletRepackPostData(
                    containerNumber = containerObj.containerNumber,
                    serialNumbers = arrayListOf(),
                    qtyUom = "EA",
                    itemId = itemId,
                    containerQty = containerObj.qty.toString(),
                    inventoryType = containerObj.inventoryType!!
                )
                containerNewList.add(palletRepackPostData)
            }
        }
        if (childContainerList.isNotEmpty()) {
            for (containerObj in childContainerList) {
                val palletRepackPostData = PalletRepackPostData(
                    containerNumber = containerObj.containerNumber,
                    serialNumbers = arrayListOf(),
                    qtyUom = "EA",
                    itemId = itemId,
                    containerQty = containerObj.qty.toString(),
                    inventoryType = containerObj.inventoryType!!
                )
                containerNewList.add(palletRepackPostData)
            }
        }
        val palletRepackPostRequest = PalletRepackPostRequest(
            palletNumber = binding.tvPalletNumberValue.text.toString(),
            containerDetails = containerNewList
        )
        viewModel.postTempTable(palletRepackPostRequest)
    }

    private fun showErrorAlert(isMixedItem: Boolean) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(if (isMixedItem) resources.getString(R.string.lbl_mixed_items_not_allowed) else getString(R.string.receiving_mixed_inventory_not_allowed))
        builder.setMessage(if (isMixedItem) resources.getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check) else getString(
            R.string.containers_have_different_inventory_type_can_not_palletize_together))

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
            dialogInterface.dismiss()
            binding.edtContainer.text = null
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}
