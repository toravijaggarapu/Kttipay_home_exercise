package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartItemBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartItemFragment"

@AndroidEntryPoint
class PickCartItemFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartItemBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartItemBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        subscribeTransactionParamObserver()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskCasePickCompleteRes ->
                        if (taskCasePickCompleteRes.success != null && taskCasePickCompleteRes.success) {
                            FlareLog.i(TAG, "taskCasePickComplete success: $taskCasePickCompleteRes")
                            binding.itemInput.text?.clear()
                            if (taskCasePickCompleteRes.taskDetails != null) {
                                viewModel.setPickTaskDetails(taskCasePickCompleteRes.taskDetails)
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = PickCartItemFragmentDirections.actionPickCartItemFragmentToPickCartLocationFragment()
                                navController.navigate(action)
                            } else {
                                // implement when task details is null
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = PickCartItemFragmentDirections.actionPickCartItemFragmentToPickCartLocationFragment()
                                navController.navigate(action)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskCasePickComplete error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun validateItem() {
        if (!binding.itemInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.itemInput)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (binding.itemInput.text.toString() == taskData.itemCode) {
                    navigateQtyPage()
                    binding.itemInput.text?.clear()
                } else {
                    //Call the new API to check the UPC or SLP number is associated with Item code when user scan/enter the other than the item code.
                    validateUPCorSLP()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "ItemInput field focused")
                    validateItem()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            binding.cart.text = data?.cartNbr
            binding.taskId.text = taskData.taskId.toString()
            binding.item.text = taskData.itemCode
            binding.description.text = taskData.itemDescription
            binding.pickLocation.text = taskData.locationBarcode
            binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
            if(!taskData.toteNumber.isNullOrEmpty()) {
                showToteLayout(true)
                binding.toteNumber.text = taskData.toteNumber
            }else
                showToteLayout(false)
        }
        binding.itemInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "ItemInput field focused")
                validateItem()
            }
            false
        }
        binding.itemInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.itemInputResponse.text = null
            }
        })
        binding.shortPickCart.setOnClickListener {
            FlareLog.i(TAG, "Short pick cart clicked")
            if (data != null) {
                if (taskData != null) {
                    viewModel.taskcasepickcomplete(
                            TaskCasePickCompleteReq(
                                    allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")!!,
                                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                    cartNumber = data.cartNbr,
                                    cartId = data.cartId,
                                    containerId = taskData.containerId,
                                    containerNumber = taskData.containerNbr,
                                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                    itemCode = taskData.itemCode,
                                    itemDescription = taskData.itemDescription,
                                    itemId = taskData.itemId,
                                    pickQty = taskData.taskQty,
                                    pickQtyUom = taskData.taskQtyUom,
                                    taskDetId = taskData.taskDetId,
                                    taskId = taskData.taskId,
                                    lotNumber = taskData.lotNumber,
                                    expDate = taskData.expDate,
                                    orderType = viewModel.orderType
                            )
                    )
                }
            }
        }
        if (viewModel.isOverrideItemAttributes == -1 && (taskData!!.itemLotTracked == "1" || taskData.itemExpDateTracked == "1")) {
            getTransactionParam()
        }
    }
    /**
     * method to get Transaction param details from API
     */
    private fun getTransactionParam() {
        viewModel.getItemAttributesTransactionParam(
            MPRTransParamRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                transCode = "OIA"
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.itemAttrTransParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            if (!transactionParamResponse.transParams.isNullOrEmpty()) {
                                if (transactionParamResponse.transParams[0].required) {
                                    viewModel.isOverrideItemAttributes = 1
                                } else {
                                    viewModel.isOverrideItemAttributes = 0
                                }
                            } else {
                                viewModel.isOverrideItemAttributes = 0
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.upcOrSlpResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { upcOrSlpResponse ->
                        if(upcOrSlpResponse.success){
                            navigateQtyPage()
                        }else{
                            binding.itemInputResponse.text = upcOrSlpResponse.message
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.itemInput.setText(scan?.barcode.toString())
            binding.itemInput.text?.length?.let {
                binding.itemInput.setSelection(it)
            }
            FlareLog.i(TAG, "ItemInput field focused")
            validateItem()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun validateUPCorSLP() {
        //API call to validate the UPC or SLP code.
        viewModel.validateUPCorSLP(itemCode = binding.item.text.toString().trim(),
            upcOrSlp = binding.itemInput.text.toString().trim())
    }

    private fun navigateQtyPage(){
        val action = PickCartItemFragmentDirections.actionPickCartItemFragmentToPickCartQtyFragment()
        if (viewModel.isInnerPack()){
            showAlertDialog("","Item has Inner Pack. Please verify scan unit to ensure correct pick qty") {
                getNavigationController().navigate(action)
            }
        } else {
            getNavigationController().navigate(action)
        }
    }

    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

}