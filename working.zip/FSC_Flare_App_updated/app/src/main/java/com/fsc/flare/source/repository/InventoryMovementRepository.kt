package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.PalletPrinterReq
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.InvmTaskCompleteRequest
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.SubmitDestinationLocationRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class InventoryMovementRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getSourceDetails(source: String) =
        apiGatewayInterface.getSourceDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)?: "",
            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
            containerNumber = source,
        )

    suspend fun getReasonCodes(sourceLocationClass: String, containerType: String, itemCategory: String, destLocationCls: List<String>) =  apiGatewayInterface.getReasonCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)?: "",
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        sourceLocationClass = sourceLocationClass,
        containerType = containerType,
        itemCategory = itemCategory,
        fetchBySrc = true,
        destLocationCls = destLocationCls.joinToString(",")
    )

    suspend fun getDestinationLocation(containerNbr: String, reasonCode: String) =
        apiGatewayInterface.getDestinationLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)?: "",
            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNbr = containerNbr,
            reasonCode = reasonCode
        )

    suspend fun submitDestinationLocation(request: SubmitDestinationLocationRequest) =
        apiGatewayInterface.submitDestinationLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)?: "",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            validateUpcRequest = request
        )

    suspend fun validateSerialNumberApiCall(itemId: Long, serialNbr: String, isOutBoundOnly: Boolean) =
        apiGatewayInterface.validatePISerialNumberWithItemCode(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            itemId = itemId.toInt(),
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            serialNumberOrItemId = serialNbr,
            isOutBoundOnly = isOutBoundOnly
        )

    suspend fun getTaskGroups(allocationTypes: String) = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = allocationTypes
    )

    suspend fun getTask(taskReq: TaskPickReq) = apiGatewayInterface.getTaskPick(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickReq = taskReq
    )

    suspend fun generatePalletNumber(type: String) =  apiGatewayInterface.generatePalletCaseNumber(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        type = type
    )

    suspend fun getPalletDetails(pallet: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = pallet,
            itemInfo = itemInfo
        )

    suspend fun invmTaskComplete(taskType: String?, request: InvmTaskCompleteRequest) =
        apiGatewayInterface.invmTaskComplete(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            taskType = taskType,
            invmTaskCompleteRequest = request
        )


    suspend fun skipTask(request: SkipPickCartReq) = apiGatewayInterface.buildSkipCart(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = request.fcyId,
        custId = request.custId,
        buId = request.buId,
        pickCartNbr = request.pickCartNbr,
        assignedTo = request.assignedTo,
        allocationType = request.allocationType,
        skipTaskId = request.skipTaskId,
        skipTaskDetId = request.skipTaskDetId,
        isLTLcubing = request.isLTLcubing,
        false
    )

    suspend fun getPrintRequesterList(printerConfigRequest: PrinterConfigRequest) = apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigRequest.fcyId,
        page = printerConfigRequest.page,
        pageLimit = printerConfigRequest.pageLimit,
        printerType = printerConfigRequest.printerType
    )

    suspend fun printPalletLabel(palletPrinterReq: PalletPrinterReq) =
        apiGatewayInterface.printPalletLabel(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            palletPrinterReq
        )
}

