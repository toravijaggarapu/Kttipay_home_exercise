package com.fsc.flare.ui.fragment.receiving

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryTypeBinding
import com.fsc.flare.ui.fragment.commontasks.BLIND_PALLET_RESULT
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.getNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [StatusFragment] class
 */
@AndroidEntryPoint
class InventoryTypesFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryTypeBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - "+
                sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryTypeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        binding.inventoryTypesSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            super.spinnerSelected(binding.inventoryTypesTv.text.toString(), binding.inventoryTypesSpinner.text.toString())
            viewModel.setInventoryTypeSelected(isUpdated)
            navigateToNextScreen()
        }

        getNavigationResult<String>(BLIND_PALLET_RESULT) { palletNumber ->
            viewModel.newPalletNumber = palletNumber
            navigateToNextScreen()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val asnData = viewModel.getAsn()
        val item = viewModel.getItem()
        binding.dockDoor.text = sharedPreferences.getString(PreferenceKeys.Item.DD_NUMBER, null)
        binding.asn.text = asnData.asnNumber
        binding.packageBarcode.text = item.itemBarCode
        binding.itemCode.text = item.itemName
        binding.packageBarcodeDesc.text = item.description
        binding.inventoryTypesSpinner.setOptions(viewModel.getInventoryTypesHashMap().values.toList() as ArrayList<String>?)
        binding.inventoryTypesSpinner.text = viewModel.getInventoryTypeSelected()
        super.spinnerSelected(binding.inventoryTypesTv.text.toString(), binding.inventoryTypesSpinner.text.toString())
        val lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
        val expirationDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
        if (item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()) {
            binding.lotTv.visibility = View.VISIBLE
            binding.lot.visibility = View.VISIBLE
            binding.lot.text = lotNumber
        }
        if (item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()) {
            binding.dateTv.visibility = View.VISIBLE
            binding.date.visibility = View.VISIBLE
            binding.date.text = expirationDate
        }
        if (item.tracking.countryOfOriginRequired == "1") {
            binding.cooTv.visibility = View.VISIBLE
            binding.coo.visibility = View.VISIBLE
            binding.coo.text = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null)
        }

        if (viewModel.getManufacturingDate(viewModel.validateLotNumberResponse).isNotEmpty()) {
            binding.mfdateTv.visibility = View.VISIBLE
            binding.mfdate.visibility = View.VISIBLE
            binding.mfdate.text = parseExpiryDate(viewModel.getManufacturingDate(viewModel.validateLotNumberResponse))
        }

        if (item.hazmatRequired == "Y") {
            binding.itemClassCodeTv.visibility = View.VISIBLE
            binding.itemClassCode.visibility = View.VISIBLE
            binding.itemClassCode.text = item.hazardous?.hazardClassIMDG
            binding.slash.visibility = View.VISIBLE
            binding.division.visibility = View.VISIBLE
            binding.division.text = item.hazardous?.hazmatDivisionText
        }

        binding.btnNext.setOnClickListener {
            super.onClick(it)
            navigateToNextScreen()
        }
    }

    /**
     * In Virtual Case scenarios if user needs to create a new pallet, then it navigates to Pallet creation
     * other cases it moves to Qty UOM fragment (previous flow).
     */
    private fun navigateToNextScreen() {
        val action = if (viewModel.selectedContainerType == PALLET && viewModel.newPalletNumber == null)
            InventoryTypesFragmentDirections.actionInventoryTypeToCreateBlindPallet()
        else
            InventoryTypesFragmentDirections.actionInventoryTypeFragmentToQtyUomFragment()

        findNavController().navigate(action)
    }
}