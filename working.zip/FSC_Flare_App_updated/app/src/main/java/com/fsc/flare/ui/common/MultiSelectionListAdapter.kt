package com.fsc.flare.ui.common

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemCheckboxTextBinding

class MultiSelectionListAdapter<T : MultiSelection>(
    private val displayList: List<T>,
    private val onItemSelectionChanged: () -> Unit = {}
) : RecyclerView.Adapter<MultiSelectionListAdapter<T>.ListViewHolder>() {

    inner class ListViewHolder(private val binding: ItemCheckboxTextBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.cbContent.setOnClickListener {
                val clickedObject = displayList[adapterPosition]
                clickedObject.isSelected = !clickedObject.isSelected
                onItemSelectionChanged.invoke()
            }
        }

        fun bind(item: T, isLastItem: Boolean) {
            binding.cbContent.text = item.getDisplayName()
            binding.cbContent.isChecked = item.isSelected
            binding.vSeparator.visibility = if (isLastItem) View.INVISIBLE else View.VISIBLE
        }
    }

    fun getSelectedItemsList(): List<T> {
        return displayList.filter { it.isSelected }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ListViewHolder {
        val binding = ItemCheckboxTextBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(item = displayList[position], isLastItem = position == displayList.size - 1)
    }

    override fun getItemCount() = displayList.size
}