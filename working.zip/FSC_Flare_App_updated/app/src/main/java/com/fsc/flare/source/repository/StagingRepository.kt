package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentDocumentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationRequest
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton



@Singleton
class StagingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun validatePalletNumber(container: String, itemInfo: String) = apiGatewayInterface.validateStagingPallet(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = container,
        itemInfo = itemInfo
    )

    suspend fun validateStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun validateStagingPalletLocation(stagingPalletLocationRequest: StagingPalletLocationRequest) =
        apiGatewayInterface.validatePalletStagingLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            stagingPalletLocationRequest = stagingPalletLocationRequest
        )

    suspend fun fetchRecallLockOBContainerDetails(obCartonRCLockRequest: OBCartonRCLockRequest): Response<OBCartonRCLockResponse> =
        apiGatewayInterface.fetchRecallLockOBContainerDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            lock = obCartonRCLockRequest.lock,
            palletNbr = obCartonRCLockRequest.palletNbr
        )

    suspend fun fetchObCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest): Response<ValidateCartonHandlerTypeResponse> =
        apiGatewayInterface.fetchObCartonDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            cartonNbr = validateCartonHandlerTypeRequest.cartonNbr,
            type = validateCartonHandlerTypeRequest.type,
            responseLevel = validateCartonHandlerTypeRequest.responseLevel
        )

    suspend fun validateInputForPrinting(validateInputRequest: ValidateInputRequest) =
        apiGatewayInterface.validateInputForPrinting(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            searchEntity = validateInputRequest.searchEntity,
            inputVal = validateInputRequest.inputVal,
            custId = validateInputRequest.custId,
            buId = validateInputRequest.buId,
            fcyId = validateInputRequest.fcyId
        )

    suspend fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) =
        apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = printerConfigRequest.fcyId,
            page = printerConfigRequest.page,
            pageLimit = printerConfigRequest.pageLimit,
            printerType = printerConfigRequest.printerType
        )

    suspend fun printInternationalShipmentDocuments(printRequest: PrintShipmentDocumentRequest) =
        apiGatewayInterface.printInternationalShipmentDocuments(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            printOrderRequest = printRequest
        )

    suspend fun getLocationInventoryCount(locationId: String?, palletId: Int?) = apiGatewayInterface.getLocationInventoryCount(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "") ?: "",
        custId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId=sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId=sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
        palletId = palletId
    )
}