package com.fsc.flare.ui.fragment.pickingforward.pickfromcasepick

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartPickLocationBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipBuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.ui.fragment.pickingforward.PickCartPalletFragmentDirections
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.DropDown
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartPickLocationFragment"
const val NO_TASKS_FOR_CARTNUM_PICKCART = "NO_TASKS_FOR_CARTNUM"

@AndroidEntryPoint
class PickCartPickLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartPickLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(
            PreferenceKeys.CUST_CODE,
            null
        ) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPickCartPickLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        binding.pickLocationInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "PickLocation field focused")
                validatePickLocation()
            }
            false
        }
        binding.pickLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.pickLocationTvRes.text = null
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "PickLocation focused")
                    validatePickLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
        val allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)
        val rtvAllocationType = sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, null)

        if (allocationType in listOf(
                AllocationType.ALLOCATED_FROM_CASE_PICK.code,
                AllocationType.CYCLE_COUNT_CASE_PICK.code
            ) ||
            rtvAllocationType in listOf(
                AllocationType.PICK_FROM_CASE_PICK_RTV.code,
                AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
                AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code
            )
        ) {
            binding.endCart.visibility = View.VISIBLE
            binding.skipLineItem.visibility = View.VISIBLE
        } else {
            binding.endCart.visibility = View.GONE
        }
        binding.endCart.setOnClickListener {
            FlareLog.i(TAG, "EndCart clicked")
            binding.endCart.isEnabled = false
            val tskData = viewModel.getPickTask()
            val allocationType = when {
                viewModel.isRTV -> {
                    sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
                }
                else -> {
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")
                }
            }
            viewModel.pickEndCart(
                EndPickCartReq(
                    allocationType = allocationType?.toIntOrNull() ?: -1,
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    pickCartNbr = binding.cart.text.toString(),
                    cartId = tskData?.cartId,
                    isLTLcubing = viewModel.isLTLCubingEnabled
                )
            )
        }
        binding.skipCart.setOnClickListener {
            FlareLog.i(TAG, "SkipCart clicked")
            val taskDetails = viewModel.getPickTaskDetails()
            val allocationType = when {
                viewModel.isRTV -> {
                    sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
                }
                else -> {
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")
                }
            }
            when (allocationType) {
                AllocationType.ALLOCATED_FROM_CASE_PICK.code,
                AllocationType.PICK_FROM_CASE_PICK.code,
                AllocationType.PICK_FROM_CASE_PICK_RTV.code,
                AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
                AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code,
                AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV.code -> {
                    if (taskDetails != null) {
                        viewModel.buildSkipCart(
                            SkipBuildCartReq(
                                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                binding.cart.text.toString(),
                                sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                                allocationType,
                                skipTaskId = taskDetails.taskId.toString(),
                                skipTaskDetId = "",
                                isLTLcubing = viewModel.isLTLCubingEnabled,
                                orderType = viewModel.orderType
                            )
                        )
                    }
                }

                else -> {
                    if (taskDetails != null) {
                        viewModel.pickSkipCart(
                            SkipPickCartReq(
                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                pickCartNbr = binding.cart.text.toString(),
                                assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                                allocationType = taskDetails.allocationType,
                                skipTaskId = taskDetails.taskId.toString(),
                                skipTaskDetId = taskDetails.taskDetId.toString(),
                                replenType = if (viewModel.isRTV) "" else getString(R.string.picking_fill),
                                isLTLcubing = viewModel.isLTLCubingEnabled,
                                orderType = viewModel.orderType
                            )
                        )
                    }
                }
            }
        }

        binding.skipLineItem.setOnClickListener {
            val taskDetails = viewModel.getPickTaskDetails()
            if (taskDetails != null) {
                viewModel.buildSkipCart(
                    SkipBuildCartReq(
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        binding.cart.text.toString(),
                        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                        sharedPreferences.getString(
                            PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE,
                            ""
                        )!!,
                        skipTaskId = taskDetails.taskDetId.toString(),
                        skipTaskDetId = taskDetails.taskDetId.toString(),
                        isLTLcubing = viewModel.isLTLCubingEnabled,
                        orderType = viewModel.orderType
                    )
                )
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun validatePickLocation() {
        if (!binding.pickLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.pickLocationInput)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (binding.pickLocationInput.text.toString() == taskData.locationBarcode) {
                    binding.pickLocationInput.text?.clear()
                    viewModel.validateStagingLocation(
                        LocationClassReq(
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskData.locationBarcode,
                            ""
                        )
                    )
                } else {
                    binding.pickLocationTvRes.text = getString(R.string.wrong_pick_location)
                    binding.pickLocationInput.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.pickLocationInput)
                }
            }
        }
    }

    private fun navigateToContainer() {
        viewModel.scannedSerialNumbers.clear()
        val action =
            PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToPickCartContainerFragment()
        getNavigationController().navigate(action)
    }

    private fun subscribeObservers() {
        viewModel.endPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endPickCartResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (endPickCartResponse.success != null && endPickCartResponse.success) {
                            FlareLog.i(TAG, "endPickCart success: $endPickCartResponse")
                            if (endPickCartResponse.taskDetails != null) {
                                val navController = Navigation.findNavController(
                                    requireActivity(),
                                    R.id.nav_host_fragment
                                )
                                val action =
                                    PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToPickCartStagingLocFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.pickCartStagingLocFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else if (endPickCartResponse.promptStage != null && endPickCartResponse.promptStage) {
                                val navController = Navigation.findNavController(
                                    requireActivity(),
                                    R.id.nav_host_fragment
                                )
                                /*val action = PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToPickingStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickingStagingLocationFragment, true).build()
                                navController.navigate(action, navOptions)*/
                                val action =
                                    PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToPickCartStagingLocFragment()
                                val navOptions = NavOptions.Builder()
                                    .setPopUpTo(R.id.pickCartStagingLocFragment, true).build()
                                navController.navigate(action, navOptions)
                            } else {
                                val navController = Navigation.findNavController(
                                    requireActivity(),
                                    R.id.nav_host_fragment
                                )
                                val action =
                                    PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToBuildCartTaskGroup()
                                val navOptions =
                                    NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true)
                                        .build()
                                navController.navigate(action.actionId, getBundleData(), navOptions)
                            }
                        } else {
                            binding.endCart.isEnabled = true
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.endCart.isEnabled = true
                        FlareLog.e(TAG, "endCart error: $message")
                        showErrorSnackBar(message)
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == NO_TASKS_FOR_CARTNUM_PICKCART) {
                                    val navController = Navigation.findNavController(
                                        requireActivity(),
                                        R.id.nav_host_fragment
                                    )
                                    val action =
                                        PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToBuildCartTaskGroup()
                                    val navOptions = NavOptions.Builder()
                                        .setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                    navController.navigate(
                                        action.actionId,
                                        getBundleData(),
                                        navOptions
                                    )
                                }
                            }
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {

                                if (skipCartResponse.taskDetails.taskStatus == 35) {
                                    val data = viewModel.getPickTask()
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    showStagePendingAlert(
                                        data?.cartNbr!!,
                                        skipCartResponse.taskDetails.taskId
                                    )
                                } else {
                                    viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                    binding.taskId.text =
                                        skipCartResponse.taskDetails.taskId.toString()
                                    binding.item.text = skipCartResponse.taskDetails.itemCode
                                    binding.description.text =
                                        skipCartResponse.taskDetails.itemDescription
                                    binding.pickLocation.text =
                                        skipCartResponse.taskDetails.locationBarcode
                                    binding.pickQty.text =
                                        viewModel.getTaskQtyUOMValue(skipCartResponse.taskDetails)
                                }
                            } else {
                                skipCartResponse.message?.let { showErrorSnackBar(it) }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        showErrorSnackBar(message)
                    }

                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationDetailsResponse ->
                        if (locationDetailsResponse.success) {
                            FlareLog.i(
                                TAG,
                                "locationDetailsResponse success: $locationDetailsResponse"
                            )
                            if (locationDetailsResponse.locations.isNotEmpty()) {
                                val reserveLocation = locationDetailsResponse.locations[0]
                                if (sharedPreferences.getBoolean(
                                        PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                                        false
                                    )
                                ) {
                                    if (reserveLocation.lockCode == "CC") {
                                        val msg =
                                            getString(R.string.cycle_count_progress_for_location)
                                        showCycleCountPendingAlert(msg)
                                    } else {
                                        navigateToContainer()
                                    }
                                } else {
                                    if (reserveLocation.cycleCountPending == "Y") {
                                        val msg =
                                            getString(R.string.cycle_count_pending_for_location)
                                        showCycleCountPendingAlert(msg)
                                    } else {
                                        navigateToContainer()
                                    }
                                }

                            } else {
                                showErrorSnackBar("Invalid Location")
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskCasePickResponse ->
                        if (taskCasePickResponse.success != null && taskCasePickResponse.success) {
                            FlareLog.i(TAG, "taskCasePickComplete success: $taskCasePickResponse")
                            binding.pickLocationInput.text?.clear()
                            if (taskCasePickResponse.taskDetails != null) {
                                viewModel.updateOrderType(taskCasePickResponse.orderType)
                                viewModel.setPickTaskDetails(taskCasePickResponse.taskDetails)
                                setupUI()
                            } else {
                                // implement when task details is null
                                if (taskCasePickResponse.eligibleToStage == null || taskCasePickResponse.eligibleToStage) {
                                    val action =
                                        PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToPickCartStagingLocFragment()
                                    val navOptions = NavOptions.Builder()
                                        .setPopUpTo(R.id.pickCartStagingLocFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                } else {
                                    showAlertDialog(
                                        "",
                                        getString(R.string.pick_cart_cancelled_case_pick_stage_alert_message)
                                    ) {
                                        val action =
                                            PickCartPickLocationFragmentDirections.actionPickCartPickLocationFragmentToBuildCartTaskGroup()
                                        val navOptions = NavOptions.Builder()
                                            .setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                        getNavigationController().navigate(action.actionId, getBundleData(), navOptions)
                                    }
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskCasePickComplete error: $message")
                        if (message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                when {
                                    msgArray[0] == LOCATION_IS_EMPTY -> {
                                        showErrorAlert(msgArray[1])
                                    }

                                    msgArray[0] == TASK_CYCLE_COUNT_PENDING -> {
                                        val msg =
                                            getString(R.string.cycle_count_pending_for_location)
                                        showCycleCountPendingAlert(msg)
                                    }

                                    else -> {
                                        showErrorSnackBar(message)
                                    }
                                }
                            }
                        } else {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun getBundleData(): Bundle? {
        val bundle = if (viewModel.isRTV) {
            bundleOf(Constants.IS_RTV to true)
        } else {
            null
        }
        return bundle
    }

    private fun setupUI() {
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                binding.taskId.text = taskData.taskId.toString()
                binding.item.text = taskData.itemCode
                binding.description.text = taskData.itemDescription
                binding.pickLocation.text = taskData.locationBarcode
                binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
            }
        }
    }

    private fun showCycleCountPendingAlert(msg: String) {
        showAlertDialog(
            "",
            msg,
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.getInventoryReasonCodes()
                    showReasonCode()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    var reasonCode: View? = null
    private fun showReasonCode() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(layoutInflater)
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        reasonCode = dialogView.reasonCodeDropDown
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        (reasonCode as DropDown?)!!.setOptions(inventoryLockList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        (reasonCode as DropDown?)!!.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            callShortPickAPI(viewModel.getPickTask()!!, viewModel.getPickTaskDetails()!!, lockCode)
            dialog.dismiss()
        }
    }

    private fun callShortPickAPI(
        data: TaskPickResponse,
        taskData: TaskDetails,
        reasonCode: String
    ) {
        val taskCasePicReq = TaskCasePickCompleteReq(
            allocationType = sharedPreferences.getString(
                PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE,
                ""
            )!!,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            cartNumber = data.cartNbr,
            cartId = data.cartId,
            containerId = taskData.containerId,
            containerNumber = taskData.containerNbr,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            itemCode = taskData.itemCode,
            itemDescription = taskData.itemDescription,
            itemId = taskData.itemId,
            pickQty = 0,
            pickQtyUom = taskData.taskQtyUom,
            taskDetId = taskData.taskDetId,
            taskId = taskData.taskId,
            lotNumber = taskData.lotNumber,
            expDate = taskData.expDate,
            reasonCode = reasonCode,
            orderType = viewModel.orderType
        )
        viewModel.taskcasepickcomplete(taskCasePicReq)
    }

    private fun showErrorAlert(message: String) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)
        builder.setPositiveButton(getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.pickLocationInput.setText(scan?.barcode.toString())
        binding.pickLocationInput.text?.length?.let {
            binding.pickLocationInput.setSelection(it)
        }
        FlareLog.i(TAG, "PickLocation field focused")
        validatePickLocation()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showStagePendingAlert(cartNumber: String, taskId: Int) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(R.string.stage_pending_alert, cartNumber, taskId.toString())
        builder.setTitle("")
        builder.setMessage(msg)
        builder.setPositiveButton(getString(R.string.lbl_stage_cart)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            val navController =
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action =
                PickCartPalletFragmentDirections.actionPickCartPalletFragmentToPickCartStagingLocFragment()
            navController.navigate(action)
        }

        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}