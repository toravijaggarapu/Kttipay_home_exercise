package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentScanBlindIbContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = ScanBlindIBContainerFragment::class.java.simpleName.toString()
/**
 *  [ScanBlindIBContainerFragment] class.
 */
@AndroidEntryPoint
class ScanBlindIBContainerFragment : BaseFragment(), FlareScannable {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentScanBlindIbContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etIbContainer.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etIbContainer)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentScanBlindIbContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etIbContainer.requestFocus()
        setUpViews()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to update views with data
     */
    private fun setUpViews() {
        sharedViewModel.obCartonDetails?.let { obCarton ->
            binding.tvObContainerIdValue.text = obCarton.containerNbr
        }

        binding.btnBlindIbContainer.setOnClickListener {
            viewModel.generateBlindIBCartonRequest()
        }
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etIbContainer.isFocused && !binding.etIbContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateIBContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etIbContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etIbContainer)
                FlareLog.i(TAG, "Container field focused")
                if (binding.etIbContainer.isFocused && !binding.etIbContainer.text.isNullOrEmpty()) {
                    validateIBContainer()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etIbContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvIbContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate IB container
     */
    private fun validateIBContainer() {
        val blindIbContainerNumber = binding.etIbContainer.text.toString().trim()
        viewModel.ibCartonDetailsRequest(blindIbContainerNumber = blindIbContainerNumber)
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeIBContainerResponse()
        observeBlindIbCartonResponse()
    }

    /**
     * Function to observe Blind IB carton response
     */
    private fun observeBlindIbCartonResponse() {
        viewModel.blindIbCartonResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleBlindIbCartonSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleBlindIbCartonErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Blind IB Carton Error response
     */
    private fun handleBlindIbCartonErrorResponse(message: String?) {
        message?.let {
            showErrorSnackBar(message = message)
        }
    }

    /**
     * Function to handle Blind IB Carton success response
     */
    private fun handleBlindIbCartonSuccessResponse(response: CaseTransferPalletGenerateResponse?) {
        response?.takeIf { it.success }?.let { blindCartonResponse ->
            // Find the first carton that is not of type "pallet"
            val cartonValue = blindCartonResponse.numbers
                .firstOrNull { it.type != "pallet" }
                ?.value

            // Update the shared view model and navigate if a valid carton number is found
            cartonValue?.let { blindCartonNbr ->
                sharedViewModel.blindIbContainerNumber = blindCartonNbr
                navigateToOBIBItemBarcodeFragment()
            }
        }
    }

    /**
     * Function to observe IB container response
     */
    private fun observeIBContainerResponse() {
        viewModel.ibContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleIbContainerSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleIbContainerErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle IB container error response
     */
    private fun handleIbContainerErrorResponse(message: String?) {
        message?.let {
            val blindIbContainerNumber = binding.etIbContainer.text.toString().trim()
            sharedViewModel.blindIbContainerNumber = blindIbContainerNumber
            navigateToOBIBItemBarcodeFragment()
        }
    }

    /**
     * Function to navigate OB/IB Item Scan Fragment
     */
    private fun navigateToOBIBItemBarcodeFragment() {
        binding.etIbContainer.text = null
        val action = ScanBlindIBContainerFragmentDirections.actionScanBlindIbContainerFragmentToScanOBIBItemBarcodeFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to handle IB container success response
     */
    private fun handleIbContainerSuccessResponse(response: InventoryContainerResponse?) {
        response?.container?.firstOrNull()?.let { containerEntity ->
            binding.tvIbContainerResponse.text = getString(R.string.lbl_blind_container_already_exists_error, containerEntity.containerNumber)
            with(binding.etIbContainer) {
                requestFocus()
                selectAll()
            }
            showSoftKeyBoard(requireContext(), binding.etIbContainer)
        }.run {
            if(response?.container.isNullOrEmpty()) {
                sharedViewModel.blindIbContainerNumber = binding.etIbContainer.text.toString().trim()
                navigateToOBIBItemBarcodeFragment()
            }
        }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etIbContainer.setText(scan?.barcode.toString())
        binding.etIbContainer.text?.length?.let {
            binding.etIbContainer.setSelection(it)
            validateIBContainer()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}