package com.fsc.flare.ui.fragment.inventory

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryLockUnlockContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryLockContainerFragment"
private const val ARG_PARAM1 = "screenTagName"

/**
 * A simple [InventoryLockUnlockContainerFragment] class.
 */
@AndroidEntryPoint
class InventoryLockUnlockContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var screenTagName: String? = null

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryLockUnlockContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            arguments?.let {
                screenTagName = it.getString(ARG_PARAM1)
            }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.container.isFocused && !binding.container.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Container field focused")
            viewModel.getContainer(binding.container.text.toString(), "Y")
        }
    }

    private fun subscribeObservers() {
        viewModel.adjustmentResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.container.isEmpty()) {
                            binding.containerResponse.text = resources.getString(R.string.cont_info_not_avlb)
                        } else {
                            val containerData = containerResponse.container[0]
                            if (containerData.ibObCode == "IB" && binding.tvInventory.text.toString().contains("IB")) {
                                viewModel.setContainerInfo(containerResponse.container)
                                binding.container.text = null
                                navigateToDetailsPage()

                            } else if (containerData.ibObCode == "OB" && binding.tvInventory.text.toString().contains("OB")) {
                                viewModel.setContainerInfo(containerResponse.container)
                                binding.container.text = null
                                navigateToDetailsPage()
                            } else {
                                showErrorSnackBar(resources.getString(R.string.lbl_invalid, binding.tvInventory.text))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.containerResponse.text = message
                        binding.container.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.container)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToDetailsPage() {
        val bundle = bundleOf(
            "screenTagName" to screenTagName
        )
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        navController.navigate(R.id.action_containerLockUnlockFragment_to_containerLockUnlockReasonFragment, bundle)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInventoryLockUnlockContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvInventory.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }
    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.container.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.containerResponse.text = null
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.container.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        subscribeObservers()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.container.setText(scan?.barcode.toString())
            binding.container.text?.length?.let {
                binding.container.setSelection(
                    it
                )
            }
            FlareLog.i(TAG, "Container field focused")
            viewModel.getContainer(binding.container.text.toString(), "Y")
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}