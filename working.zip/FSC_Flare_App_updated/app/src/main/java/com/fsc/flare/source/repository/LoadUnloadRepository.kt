package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerPatchRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.SendPalletToPRRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LoadUnloadRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun getDockDoorId(locBarCode: String) = apiGatewayInterface.getDockDoorInfo(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locBarCode = locBarCode,
        locClass = "DD"
    )

    suspend fun validateShipmentDockDoor(shipmentDockDoorRequest: ShipmentDockDoorRequest) =
        apiGatewayInterface.getShipmentDockDoor(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = shipmentDockDoorRequest.custId,
            fcyId = shipmentDockDoorRequest.fcyId,
            buId = shipmentDockDoorRequest.buId,
            dockDoorId = shipmentDockDoorRequest.dockDoorId,
            closeTrailer = false
        )


    suspend fun loadTrailer(loadTrailerRequest: LoadTrailerRequest) =
        apiGatewayInterface.loadTrailer(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = loadTrailerRequest.custId,
            buId = loadTrailerRequest.buId,
            fcyId = loadTrailerRequest.fcyId,
            shipmentId = loadTrailerRequest.shipmentId,
            containerId = ""
        )

    suspend fun unloadTrailer(loadTrailerRequest: LoadTrailerRequest) =
        apiGatewayInterface.unloadTrailer(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = loadTrailerRequest.custId,
            buId = loadTrailerRequest.buId,
            fcyId = loadTrailerRequest.fcyId,
            shipmentId = loadTrailerRequest.shipmentId,
            containerId = ""
        )

    suspend fun loadTrailerPatch(loadTrailerPatchRequest: LoadTrailerPatchRequest) =
        apiGatewayInterface.loadTrailerPatch(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            loadTrailerPatchRequest = loadTrailerPatchRequest
        )

    suspend fun unLoadTrailerPatch(unloadTrailerRequest: UnloadTrailerRequest) = apiGatewayInterface.unLoadTrailerPatch(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
        unloadTrailerRequest = unloadTrailerRequest
    )

    suspend fun getStagingLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateStagingLocation(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun fetchObCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest): Response<ValidateCartonHandlerTypeResponse> =
        apiGatewayInterface.fetchObCartonDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            cartonNbr = validateCartonHandlerTypeRequest.cartonNbr,
            type = validateCartonHandlerTypeRequest.type,
            responseLevel = validateCartonHandlerTypeRequest.responseLevel
        )

    suspend fun sendToPR(sendToPRRequest: SendPalletToPRRequest) =
        apiGatewayInterface.sendPalletToPR(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            request = sendToPRRequest
        )

    suspend fun fetchRecallLockOBContainerDetails(obCartonRCLockRequest: OBCartonRCLockRequest): Response<OBCartonRCLockResponse> =
        apiGatewayInterface.fetchRecallLockOBContainerDetails(
            gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            lock = obCartonRCLockRequest.lock,
            palletNbr = obCartonRCLockRequest.palletNbr
        )
}