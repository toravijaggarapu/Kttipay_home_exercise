package com.fsc.flare.ui.fragment.pickingforward

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBuildCartTaskGroupBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.lookups.toLookUpCodes
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.utils.Constants.AllocationType.ACTIVE_LTL
import com.fsc.flare.utils.Constants.AllocationType.ACTIVE_PARCEL
import com.fsc.flare.utils.Constants.AllocationType.FROM_CASE_PICK
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.LTL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.PreferenceKeys.Companion.PCL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.getNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "BuildCartTaskGroupFragment"
const val ORDER_TYPE_RESULT = "OrderTypeResult"
const val ORDER_TYPE = "RTV"
@AndroidEntryPoint
class BuildCartTaskGroupFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentBuildCartTaskGroupBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        if (viewModel.gettaskGroupCodeOptions() != null) {
            binding.pickCartTaskGroupDropDown.setOptions(viewModel.gettaskGroupCodeOptions())
        }
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retrieve the arguments
        val isRTV = arguments?.getBoolean(IS_RTV) ?: false

        // Check if isRTV is false before making API calls
        if (!isRTV) {
            callCartToPRLocationTransactionParamAPI()
        }
        callLTLTransactionParamAPI()
        viewModel.resetSerialNumber()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBuildCartTaskGroupBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPickingPickCart.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        val bundle = arguments
        if (bundle != null) {
            viewModel.isRTV = bundle.getBoolean(IS_RTV)
        }
        subscribeLTLTransactionParamObserver()
        subscribeCartToPRTransactionParamObserver()
        subscribeTransactionParamObserver()
        subscribeRtvTaskPickObserver()
        subscribeObservers()
        return binding.root
    }

    /**
     * Function to fetch task groups based on provided allocation type codes.
     */
    private fun fetchTaskGroups(allocationTypes: List<AllocationType>) {
        // Create a list of the desired AllocationType codes
        val allocationTypeCodes = allocationTypes.map { it.code }

        // Join the codes into a single string separated by commas
        val allocationTypeCodesString = allocationTypeCodes.joinToString(",")

        // Call the viewModel method with the concatenated string
        viewModel.getTaskGroups(allocType = allocationTypeCodesString)
    }


    /**
     * Function to fetch LTL Cubing enabled task groups
     */
    private fun fetchLTLCubingEnabledTaskGroups() {
        fetchTaskGroups(listOf(
            AllocationType.ALLOCATED_FROM_ACTIVE,           // Code "10"
            AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL,// Code "11"
            AllocationType.ALLOCATED_FROM_CASE_PICK,        // Code "20"
            AllocationType.PICK_FROM_ACTIVE,                // Code "12"
            AllocationType.PICK_FROM_CASE_PICK              // Code "21"
        ))
    }

    /**
     * Function to fetch LTL Cubing disabled task groups
     */
    private fun fetchLTLCubingDisabledTaskGroups() {
        fetchTaskGroups(listOf(
            AllocationType.ALLOCATED_FROM_ACTIVE,           // Code "10"
            AllocationType.ALLOCATED_FROM_CASE_PICK,        // Code "20"
            AllocationType.PICK_FROM_ACTIVE,                // Code "12"
            AllocationType.PICK_FROM_CASE_PICK              // Code "21"
        ))
    }

    /**
     * method to get transaction param info from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "PIA"
            )
        )
    }

    /**
     * method to get transaction param info from API
     */
    private fun callLTLTransactionParamAPI() {
        viewModel.getLTLTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "LTLCUBE"
            )
        )
    }

    private fun callCartToPRLocationTransactionParamAPI() {
        viewModel.getCartToPRransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "TOTETOPR"
            )
        )
    }

    /**
     * Function to subscribe RTV task pick observer
     */
    private fun subscribeRtvTaskPickObserver() {
        viewModel.rtvTaskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleRtvTaskPickSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleRtvTaskPickErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle RTV task pick success response
     */
    private fun handleRtvTaskPickSuccessResponse(taskPickResponse: TaskPickResponse?) {
        taskPickResponse?.let { rtvTaskPickResponse ->
            if (rtvTaskPickResponse.success == true) {
                FlareLog.i(TAG, "RTV TaskPick success: $rtvTaskPickResponse")
                processTaskDetails(rtvTaskPickResponse)

                // Handle case when cart number is null
                if (rtvTaskPickResponse.cartNbr == null) {
                    navigateToFullPalletFragment(rtvTaskPickResponse)
                    navigateToBuildCartPalletFragment()
                } else {
                    navigateBasedOnAllocationType()
                }
            } else {
                handleEndCartReadyFlow(rtvTaskPickResponse)
            }
        }
    }

    private fun navigateToBuildCartPalletFragment() {
        val allocationTypes = listOf(
            AllocationType.PICK_FROM_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV.code,
            AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code,
            AllocationType.PICK_FROM_ACTIVE_RTV.code
        )

        if (sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "") in allocationTypes) {
            val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToBuildCartPalletFragment()
            binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
            val bundle = bundleOf(IS_RTV to true)
            getNavigationController().navigate(action.actionId, bundle)
        }
    }

    private fun navigateToFullPalletFragment(rtvTaskPickResponse: TaskPickResponse) {
        val allocationType = sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
        val validTypes = listOf(
            AllocationType.PICK_FROM_RESERVE_RTV.code,
            AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code,
            AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code,
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code
        )

        if (allocationType in validTypes) {
            if (rtvTaskPickResponse.taskDetails != null) {
                binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
                val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToFullPalletPickFromReservePalletPage()
                val bundle = bundleOf(IS_RTV to true)
                getNavigationController().navigate(action.actionId, bundle)
            } else {
                rtvTaskPickResponse.message?.let { showErrorSnackBar(it) }
            }
        }
    }

    private fun processTaskDetails(rtvTaskPickResponse: TaskPickResponse) {
        viewModel.setPickTask(rtvTaskPickResponse)
        rtvTaskPickResponse.taskDetails?.let { taskDetails ->
            viewModel.setPickTaskDetails(taskDetails)
        }
    }

    private fun navigateBasedOnAllocationType() {
        val allocationType = sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")

        val action = when (allocationType) {
            AllocationType.PICK_FROM_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV.code,
            AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV.code -> {
                BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToPickCartPickLocationFragment()
            }
            AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code,
            AllocationType.PICK_FROM_ACTIVE_RTV.code -> {
                BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToBuildCartToteFragment()
            }
            AllocationType.PICK_FROM_RESERVE_RTV.code,
            AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code,
            AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code,
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code -> {
                BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToFullPalletPickFromReservePalletPage()
            }
            else -> null
        }

        action?.let {
            binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
            val bundle = bundleOf(IS_RTV to true)
            getNavigationController().navigate(action.actionId, bundle)
        }
    }

    private fun handleEndCartReadyFlow(rtvTaskPickResponse: TaskPickResponse) {
        if (rtvTaskPickResponse.cartIsReadyToEnd) {
            viewModel.setPickTask(rtvTaskPickResponse)
            showEndCartDialog(rtvTaskPickResponse.cartId, rtvTaskPickResponse.cartNbr)
        }
    }


    /**
     * Function to handle RTV task pick error response
     */
    private fun handleRtvTaskPickErrorResponse(message: String?) {
        message?.let { error ->
            showErrorSnackBar(error)
        }
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeLTLTransactionParamObserver() {
        viewModel.ltlTransactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                val isLtlCubingEnabled = noOfCases.transVal == viewModel.ltlFLowEnabledKey
                                Log.d("debug", if (isLtlCubingEnabled) "LTL Cubing Enabled" else "LTL Cubing Disabled")

                                viewModel.isLTLCubingEnabled = isLtlCubingEnabled

                                if (viewModel.isRTV) {
                                    viewModel.fetchRTVTaskGroups()
                                } else {
                                    if (isLtlCubingEnabled) {
                                        fetchLTLCubingEnabledTaskGroups()
                                    } else {
                                        fetchLTLCubingDisabledTaskGroups()
                                    }
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                viewModel.isLTLCubingEnabled = false
                                if (!viewModel.isRTV) {
                                    fetchLTLCubingDisabledTaskGroups()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        viewModel.isLTLCubingEnabled = false
                        fetchLTLCubingDisabledTaskGroups()
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.transactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transValDesc.equals("Prompt Item Attributes", true)) {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, true).apply()
                                } else {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        showErrorSnackBar(message)
                        sharedPreferences.edit().putBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeCartToPRTransactionParamObserver() {
        viewModel.cartToPrLocationTransParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                viewModel.setToteToPrTransParamValue(noOfCases.transVal)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun subscribeObservers() {

        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrp success: $taskGroupResponse")
                        val taskGroupDescList = ArrayList<String>()
                        val taskGroups = ArrayList<TaskGroup>()
                        taskGroupResponse.taskGroups?.forEach { lookup ->
                            when (lookup.allocationType) {
                                ACTIVE_PARCEL -> {
                                    lookup.description += " (PARCEL)"
                                }

                                ACTIVE_LTL -> {
                                    lookup.description += " (LTL)"
                                }
                            }
                            taskGroupDescList.add(lookup.description)
                            taskGroups.add(lookup)
                        }
                        viewModel.settaskGroupCodeOptions(taskGroupDescList)
                        viewModel.setTaskGroupsList(taskGroups)
                        binding.pickCartTaskGroupDropDown.setOptions(taskGroupDescList)
                        if(!viewModel.isRTV) {
                            callTransactionParamAPI()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskGrp Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success != null && taskReplenResponse.success) {
                            viewModel.isComingFromPickCartFlow = false
                            FlareLog.i(TAG, "taskPick success: $taskReplenResponse")
                            if (taskReplenResponse.cartNbr == null) {
                                binding.pickCartTaskGroupDropDown.text = null
                                binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToBuildCartPalletFragment()
                                navController.navigate(action)
                            } else {
                                viewModel.setPickTask(taskReplenResponse)
                                if (taskReplenResponse.taskDetails != null) {
                                    viewModel.setPickTaskDetails(taskReplenResponse.taskDetails)
                                }
                                if (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "") == "20" || sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "") == "21") {
                                    binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToPickCartPickLocationFragment()
                                    navController.navigate(action)
                                } else {
                                    binding.pickCartTaskGroupDropDown.text = getString(R.string.select_task_group)
                                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                    val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToBuildCartToteFragment()
                                    navController.navigate(action)
                                }
                            }
                        }else{
                            if (taskReplenResponse.cartIsReadyToEnd){
                                viewModel.setPickTask(taskReplenResponse)
                                showEndCartDialog(taskReplenResponse.cartId,taskReplenResponse.cartNbr)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.pickCartTaskGroupDropDown.boolFoo.observe(viewLifecycleOwner) { selectedTaskGroup ->

            if(viewModel.isRTV) {
                viewModel.getTaskGroupsList()?.firstOrNull { it.description == selectedTaskGroup }?.let { rtvTaskGroup ->
                    viewModel.orderType = ORDER_TYPE
                    sharedPreferences.edit().apply {
                        putString(PreferenceKeys.RtvPicking.TASK_GROUP, rtvTaskGroup.description)
                        putString(PreferenceKeys.RtvPicking.TASK_GROUP_CODE, rtvTaskGroup.code)
                        putString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, rtvTaskGroup.allocationType)
                    }.apply()
                    viewModel.fetchRtvTasks()
                }
            } else {
                viewModel.getTaskGroupsList()?.firstOrNull { it.description == selectedTaskGroup }?.let { taskGroup ->
                    viewModel.orderType = null
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP, taskGroup.description).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, taskGroup.code).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, taskGroup.allocationType).apply()

                    viewModel.getConfiguredOrderTypes()?.takeIf { viewModel.isPickOrderTypeEnabled() && it.isNotEmpty() && it.contains(taskGroup.allocationType) }?.let {
                        when (taskGroup.allocationType) {
                            ACTIVE_PARCEL -> handleOrderTypeSelection(PCL_ORD_TYPES_PREFERENCE, ACTIVE_PARCEL)
                            ACTIVE_LTL -> handleOrderTypeSelection(LTL_ORD_TYPES_PREFERENCE, ACTIVE_LTL)
                            FROM_CASE_PICK -> handleOrderTypeSelection(allocationType = FROM_CASE_PICK)
                            else -> fetchTasks()
                        }
                    } ?: fetchTasks()
                }
            }
        }

        viewModel.endPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endPickCartResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (endPickCartResponse.success != null && endPickCartResponse.success) {
                            FlareLog.i(TAG, "endPickCart success: $endPickCartResponse")
                            if (endPickCartResponse.taskDetails != null) {
                                viewModel.updateOrderType(endPickCartResponse.orderType)
                                viewModel.setPickTaskDetails(endPickCartResponse.taskDetails)
                                val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToPickCartLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            } else if (endPickCartResponse.promptStage != null && endPickCartResponse.promptStage) {
                                val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToPickingStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickingStagingLocationFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            } else {
                                val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToBuildCartToteFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartToteFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                FlareLog.e(TAG, "endPickCart error: ${msgArray[1]}")
                                showErrorSnackBar(msgArray[1])
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        getNavigationResult<String>(ORDER_TYPE_RESULT) { orderType ->
            viewModel.orderType = orderType
            fetchTasks()
        }
    }

    private fun handleOrderTypeSelection(orderTypePreferenceKey: String? = null, allocationType: String) {
        val orderTypes = orderTypePreferenceKey?.let {
            sharedPreferences.getString(it, null).orEmpty().toLookUpCodes()
        } ?: run {
            (sharedPreferences.getString(PCL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes() +
            sharedPreferences.getString(LTL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes()).distinctBy { it.lookupCode }
        }
        if (orderTypes.size > 1) {
            val action = BuildCartTaskGroupFragmentDirections.actionBuildCartTaskGroupToOrderTypeSelection(allocationType)
            getNavigationController().navigate(action)
        } else {
            viewModel.orderType = orderTypes.getOrNull(0)?.lookupCode
            fetchTasks()
        }
    }

    private fun fetchTasks() {
        viewModel.getTaskPick(
            TaskPickReq(
                allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) ?: "",
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                custId =  sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskGroup = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null) ?: "",
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun showEndCartDialog(cartId: Int?,cartNbr: String?) {
        showAlertDialog(
            getString(R.string.tasks_completed_in_cart_perform_end_cart_here_with_cart_number, cartNbr),
            getString(R.string.end_cart),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    val allocationType = when {
                        viewModel.isRTV -> {
                            sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
                        }
                        else -> {
                            sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")
                        }
                    }
                    viewModel.pickEndCart(
                        EndPickCartReq(
                            allocationType = allocationType?.toIntOrNull() ?: -1,
                            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            pickCartNbr = cartNbr,
                            cartId = cartId,
                            isLTLcubing = viewModel.isLTLCubingEnabled
                        )
                    )
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}