package com.fsc.flare.ui.fragment.labelsanddocuments

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentLabelsAndDocumentsBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfigReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "LabelsAndDocumentsFragment"

/**
 * A simple [LabelsAndDocumentsFragment] class.
 */
@AndroidEntryPoint
class LabelsAndDocumentsFragment : BaseFragment() {

    private lateinit var binding: FragmentLabelsAndDocumentsBinding
    private val viewModel: LabelsAndDocumentsViewModel by activityViewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentLabelsAndDocumentsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.printRequester.isFocused && !binding.printRequester.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "printRequester field focused")
                        callPrinterconfig()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.printRequester.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.printRequester)
                FlareLog.i(TAG, "printRequester field focused")
                callPrinterconfig()
            }
            false
        }

        binding.printRequester.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.printRequesterResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

    }


    private fun callPrinterconfig() {
        viewModel.calGetPrinterConfig(
            PrinterConfigReq(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                requestor = binding.printRequester.text.toString()
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.printerConfigsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printRes ->
                        if (printRes.printerConfigs.isNotEmpty()) {
                            viewModel.setPrinterConfigs(printRes.printerConfigs)
                            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action = LabelsAndDocumentsFragmentDirections.actionLabelsAndDocumentsToLdPrintEntitySelect()
                            navController.navigate(action)
                        } else {
                            binding.printRequesterResponse.text = resources.getString(R.string.lbl_printer_config_not_available)
                            binding.printRequester.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.printRequester)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "printRes error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}