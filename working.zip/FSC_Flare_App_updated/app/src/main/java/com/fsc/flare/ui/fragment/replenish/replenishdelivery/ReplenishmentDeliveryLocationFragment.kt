package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenDeliveryLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.repository.REPLENISH_DELIVERY_TASK_TYPE
import com.fsc.flare.ui.fragment.receiving.CASE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

@AndroidEntryPoint
class ReplenishmentDeliveryLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var binding: FragmentReplenDeliveryLocationBinding
    private val viewModel: ReplenishmentDeliveryLocationViewModel by viewModels()
    private val sharedViewModel: ReplenishmentDeliverySharedViewModel by activityViewModels()
    private val currentTask: ReplenishDeliveryTask? by lazy { sharedViewModel.task }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenDeliveryLocationBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initScreenUI()
        binding.tvHeaderTitle.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.etDeliveryLocation.doAfterTextChanged {
            binding.tvErrorMessage.text = null
            val input = binding.etDeliveryLocation.text.toString().trim()
            binding.btSubmit.isEnabled = input.isNotEmpty()
        }

        binding.btSubmit.setOnClickListener {
            if (binding.progressBar.visibility == View.VISIBLE) return@setOnClickListener
            hideSoftKeyBoard(requireContext(), binding.etDeliveryLocation)
            val inputString = binding.etDeliveryLocation.text.toString().trim()
            currentTask?.let {
                binding.tvErrorMessage.text = null
                if (inputString == it.destLocationBarcode) {
                    viewModel.completeTask(
                        taskId = it.taskId ?: 0,
                        containerNumber = it.containerNbr.orEmpty(),
                        destinationLocation = binding.etDeliveryLocation.text.toString().trim()
                    )
                } else {
                    binding.tvErrorMessage.text = getString(R.string.lbl_invalid_location)
                }
            }
        }

        observeFlowOnUI { observeScreenState() }
    }

    @SuppressLint("SetTextI18n")
    private fun initScreenUI() {
        currentTask?.let {
            binding.tvPalletOrContainerTitle.text =
                if (it.taskContainer == CASE)
                    getString(R.string.container_label)
                else
                    getString(R.string.lbl_pallet_colon)
            binding.tvPalletOrContainer.text = it.containerNbr
            binding.tvTaskNumber.text = "${it.taskId}"
            binding.tvTaskType.text =
                if (it.taskType == REPLENISH_DELIVERY_TASK_TYPE)
                    getString(R.string.replenishment_delivery)
                else
                    it.taskType
            binding.tvReplenishQty.text = "${it.taskQty} ${it.taskQtyUom}"
            binding.tvFromLocation.text = it.locationBarcode
            binding.tvDeliveryLocation.text = it.destLocationBarcode
        }
    }

    private suspend fun observeScreenState() {
        viewModel.screenState.filterNotNull().collect { state ->
            when (state) {

                ReplenishmentDeliveryLocationState.ShowProgress -> {
                    binding.progressBar.visibility = View.VISIBLE
                    disableTouch()
                }

                ReplenishmentDeliveryLocationState.HideProgress -> {
                    binding.progressBar.visibility = View.GONE
                    enableTouch()
                }

                is ReplenishmentDeliveryLocationState.Error -> {
                    binding.tvErrorMessage.text = state.message ?: getString(R.string.lbl_something_went_wrong)
                }

                is ReplenishmentDeliveryLocationState.SuccessWithNextTask -> {
                    showSuccessSnackBarStd(message = getString(R.string.replen_success_msg)) {
                        navigateBackToFlow(state.task)
                    }
                }
            }
        }
    }

    /**
     * Navigates back to the appropriate flow based on the selected task mode.
     *
     * @param task The `ReplenishDeliveryTask` to be passed to the next screen. If null, the task will be cleared.
     *
     * This function checks the `selectedTaskMode` in the `sharedViewModel` to determine the navigation flow.
     *
     * >> If the mode is `SYSTEM_DIRECTED`, it sets the `task` in the `sharedViewModel` and navigates back to the
     * `replenishDeliveryTaskScreen` or `replenishTaskModeScreen` based on the next task availability.
     * >> If the mode is `USER_DIRECTED`, it navigates back to the `replenDeliveryPalletFragment`.
     * The `inclusive` parameter in `popBackStack` is set based on whether the `task` is null.
     */
    private fun navigateBackToFlow(task: ReplenishDeliveryTask? = null) {
        sharedViewModel.task = null
        if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED) {
            sharedViewModel.task = task ?: sharedViewModel.clearData().let { null }
            findNavController().popBackStack(
                destinationId = R.id.replenDeliveryTaskScreen,
                inclusive = task == null
            )
        } else {
            findNavController().popBackStack(
                destinationId = R.id.replenDeliveryPalletFragment,
                inclusive = false
            )
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        FlareLog.i(screenName, "onScan: $scan")
        if (binding.progressBar.visibility == View.VISIBLE)
            return
        val barCode = scan?.barcode.toString().trim()
        binding.etDeliveryLocation.setText(barCode)
        binding.etDeliveryLocation.text?.length?.let {
            binding.etDeliveryLocation.setSelection(it)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(screenName, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearScreenState()
    }
}