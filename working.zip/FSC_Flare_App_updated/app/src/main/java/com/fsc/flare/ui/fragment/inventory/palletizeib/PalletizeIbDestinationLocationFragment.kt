package com.fsc.flare.ui.fragment.inventory.palletizeib

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeIbDestinationLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeIbDestinationLocationFragment"
private const val CASES_REACHED_MAX_QTY = "ERR-INV-0037"
private const val ITEMS_REACHED_MAX_QTY = "ERR-INV-0038"

/**
 * A simple [PalletizeIbDestinationLocationFragment] class.
 */
@AndroidEntryPoint
class PalletizeIbDestinationLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: PalletizeIbViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeIbDestinationLocationBinding
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var palletizeIbSubmitRequest : PalletizeIbSubmitRequest
    private var itemId: String? = null
    var inventoryType:String? =null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        updateUI()
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizeIbDestinationLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.edtDestinationLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.destinationLocationError.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        itemId = viewModel.getItmID()
        inventoryType = viewModel.getInventoryType()

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtDestinationLocation)
                    checkLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.edtDestinationLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtDestinationLocation)
                FlareLog.i(TAG, "Container field focused")
                checkLocation()
            }
            false
        }

        updateUI()
        /*binding.btnSubmit.setOnClickListener {
            if(binding.edtDestinationLocation.text.toString().trim().isNotEmpty()) {
                submitDestinationLocation()
            }
        }*/
        subscribeObservers()
    }

    private fun checkLocation(){
        if (binding.edtDestinationLocation.text.toString().trim().isNotEmpty()) {
            viewModel.validateStagingLocation(binding.edtDestinationLocation.text.toString())
        }
    }

    private fun submitDestinationLocation() {
        palletizeIbSubmitRequest = PalletizeIbSubmitRequest(
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = binding.tvPalletNumberValue.text.toString(),
            destinationLocation = binding.edtDestinationLocation.text.toString().trim(),
            transactionIdentifier = viewModel.getTempTableTransactionIdentifier(),
            skipQtyValidation = false
        )
        viewModel.palletizeIBSubmitAPI(palletizeIbSubmitRequest)
    }

    private fun updateUI(){
        val tempTableResponse = viewModel.getTempTableResponseFinal()
        if(tempTableResponse!=null){
            binding.tvPalletNumberValue.text = tempTableResponse.palletNumber
            if(!tempTableResponse.containerDetails.isNullOrEmpty()){
                var palletQty = 0
                for(container in tempTableResponse.containerDetails!!){
                    palletQty += container.containerQty
                }
                binding.tvPalletQtyValue.text = "$palletQty"
                binding.tvNbrOfContainerValue.text = "${tempTableResponse.containerDetails!!.size}"
            }
            binding.tvItemCodeValue.text = tempTableResponse.itemCode
            binding.tvItemDescValue.text = tempTableResponse.itemDescription

            val getCurrentLocation = viewModel.getPalletCurrentLocation()
            if(getCurrentLocation.isNullOrEmpty()){
                binding.currentLocLayout.visibility = View.GONE
            }else{
                binding.tvCurrentLocationValue.text = getCurrentLocation
                binding.currentLocLayout.visibility = View.VISIBLE
            }

            if(!inventoryType.isNullOrEmpty())
            {
                binding.palletInventoryType.visibility = View.VISIBLE
                binding.tvInventoryType.text= inventoryType?.let { getInventoryDescription(it) }
            }else{
                binding.palletInventoryType.visibility = View.GONE
            }

        }
    }

    private fun subscribeObservers() {
        viewModel.locationResponse.observe(viewLifecycleOwner) { locationInquiryResponse ->
            when (locationInquiryResponse) {
                is Resource.Success -> {
                    locationInquiryResponse.data?.let { locationResponse ->
                        if (locationResponse.success && locationResponse.locations.isNotEmpty()) {
                            submitDestinationLocation()
                        } else {
                            binding.destinationLocationError.text = getString(R.string.invalid_location)
                        }
                    }
                    FlareLog.i(TAG, "locationInquiry success: $locationInquiryResponse")
                    hideProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    locationInquiryResponse.message?.let { message ->
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                        binding.edtDestinationLocation.requestFocus()
                        binding.destinationLocationError.text = message
                        binding.edtDestinationLocation.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.edtDestinationLocation)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.palletizeIbSubmitResponse.observe(viewLifecycleOwner) { palletizeIbSubmitResponse ->
            when (palletizeIbSubmitResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG,"palletizeIbSubmitResponse success: $palletizeIbSubmitResponse")
                    hideProgressBar()
                    palletizeIbSubmitResponse.data?.let { palletizeIbPostResponse ->
                        showCustomDialog(palletizeIbPostResponse.message) {navigatePalletScanPage()}
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    palletizeIbSubmitResponse.message?.let { message ->
                        FlareLog.e(TAG, "palletizeIbSubmitResponse Error: $message")

                        if (message.contains("##")) {
                            val msg = message.split("##")
                            if (msg[0].equals(CASES_REACHED_MAX_QTY, ignoreCase = true) ||
                                msg[0].equals(ITEMS_REACHED_MAX_QTY, ignoreCase = true)) {
                                showAlertDialog(
                                    title = "",
                                    message = msg[1],
                                    onPositiveClick = {
                                        palletizeIbSubmitRequest.skipQtyValidation = true
                                        viewModel.palletizeIBSubmitAPI(palletizeIbSubmitRequest)
                                    },
                                    onNegativeClick = { getNavigationController().popBackStack() })
                            } else {
                                binding.destinationLocationError.text = msg[1]
                            }
                        } else {
                            showCustomDialog(message) {}
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

   /* private fun enableSubmitButton(){
        binding.btnSubmit.isEnabled = binding.edtDestinationLocation.text.toString().isNotEmpty()
    }*/

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtDestinationLocation.setText(scan?.barcode.toString())
            binding.edtDestinationLocation.text?.length?.let {
                binding.edtDestinationLocation.setSelection(it)
            }
            FlareLog.i(TAG, "Destination Location field focused")
            checkLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun navigatePalletScanPage(){
        //Navigate to the Detail page.
        val action = PalletizeIbDestinationLocationFragmentDirections.actionPalletizeIbDestinationLocationFragmentToPalletizeIbPalletNumberFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.palletizeIbPalletNumberFragment, true).build()
        getNavigationController().navigate(action, navOptions)
    }

}

