package com.fsc.flare

import android.app.Application
import android.content.Context
import android.util.Log
import com.appdynamics.eumagent.runtime.AgentConfiguration
import com.appdynamics.eumagent.runtime.Instrumentation
import com.fedex.services.blazar.ScanException
import com.fedex.services.blazar.Scanner
import com.fedex.services.blazar.callbacks.ScanListener
import com.fsc.flare.base.logs.LogFileManager
import com.fsc.flare.log.FlareLog
import dagger.hilt.android.HiltAndroidApp
import com.fsc.flare.transactiontracker.logs.FSCTrackerLogFileManager
private const val TAG = "FlareApplication"

@HiltAndroidApp
class FlareApplication : Application() {

    companion object {
        private var sScanner: Scanner? = null
        fun getScanner(): Scanner? {
            return sScanner
        }
        lateinit var instance: FlareApplication

        fun getContext(): Context {
            return instance
        }
    }

    init {
        instance = this
    }

    override fun onCreate() {
        super.onCreate()
        startAppDynamics()
        //FlareLog.initializeCaptainsLog(applicationContext.getExternalFilesDir(null).toString() + LOG_DIRECTORY + LOG_FILENAME)
        FlareLog.initializeFlareLog(
            applicationContext.filesDir!!.toString() + LogFileManager.LOG_DIRECTORY,
            LogFileManager.LOG_FILE_NAME
        )
        initializeScanning()
        FSCTrackerLogFileManager.initializeFileManager(getContext().filesDir!!.toString())
    }

    private fun initializeScanning() {
        sScanner = Scanner.Builder(this)
            .limitToScannables()
            .scanListener(FlareScanListener())
            .build()
        sScanner?.bootstrap()
    }

    private fun startAppDynamics() {
        try {
            Log.i("startAppDynamics", "Starting AppDynamics...")
            Instrumentation.start(
                AgentConfiguration.builder()
                    .withAppKey(BuildConfig.APDYNAMICS_KEY)
                    .withContext(applicationContext)
                    //.withCollectorURL("https://pdx-col.eum-appdynamics.com")
                    .withScreenshotsEnabled(false)
                    //.withLoggingLevel(Instrumentation.LOGGING_LEVEL_INFO)
                    .build()
            )
        } catch (e: java.lang.Exception) {
            Log.e("startAppDynamics", "Unable to start AppDynamics. ", e)
        }
    }

    private class FlareScanListener : ScanListener() {
        override fun onScanError(e: ScanException) {
            Log.e(TAG, "onScanError: Blazer threw a ScanException.")
        }
    }
}