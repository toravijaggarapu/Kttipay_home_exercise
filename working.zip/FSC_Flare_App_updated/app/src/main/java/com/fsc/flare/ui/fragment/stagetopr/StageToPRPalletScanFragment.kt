package com.fsc.flare.ui.fragment.stagetopr

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStageToPrPalletScanPageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
private const val TAG = "StageToPRPalletScanFragment"
@AndroidEntryPoint
class StageToPRPalletScanFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentStageToPrPalletScanPageBinding
    private val viewModel: StageToPRViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentStageToPrPalletScanPageBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    FlareLog.i(TAG,
                        "Cart field focused"
                    )
                    validateTote()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.toteInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.toteInput)
                FlareLog.i(TAG,
                    "Tote field focused"
                )
                validateTote()
            }
            false
        }
        binding.toteInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.toteInputErrRes.text = null
            }
        })
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeOBContainerResponse()
    }


    /**
     * method to get tote/carton is valid info from API
     */
    private fun validateTote() {
        if (binding.toteInput.text.toString().trim().isNotEmpty()) {
            val palletNumber = binding.toteInput.text.toString().trim()
            viewModel.obCartonDetailsRequest(palletNumber = palletNumber)
        }
        else
        {
            binding.toteInputErrRes.text = getString(R.string.enter_tote_carton)
        }
    }

    /**
     * Function to observe OB Container Response
     */
    private fun observeOBContainerResponse() {
        viewModel.obContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObContainerSuccessResponse(response.data,response.message)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObContainerErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.toteInput.setText(scan?.barcode.toString())
            binding.toteInput.text?.length?.let {
                binding.toteInput.setSelection(it)
            }
        FlareLog.i(TAG, "Tote field focused")
        validateTote()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleObContainerSuccessResponse(response: ValidateCartonHandlerTypeResponse?,message:String?) {
        if(response!=null && !message.isNullOrEmpty() && response.containerDetails.isNullOrEmpty()){
            displayErrorMessage(message)
            return
        }

        response?.containerDetails?.let {
            containerDetails ->
            if(containerDetails.isNotEmpty()) {
                containerDetails[0].containerId?.let {
                    viewModel.containerId = it
                    navigateToStagePRLocationScanFragment()
                }
            }
        }
    }

    /**
     * Function to handle OB container success response
     */
    private fun handleObContainerErrorResponse(message: String?) {
        hideProgressBar()

        message?.let { msg ->
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg
            FlareLog.e(TAG, "ObContainerErrorResponse error: $responseMessage")
            displayErrorMessage(responseMessage)
        }
    }

    /**
     * Nav Handler to location scan fragment
     */
    private fun navigateToStagePRLocationScanFragment() {
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.stageToPRLocationScanFragment, true).build()
        getNavigationController().navigate(
            R.id.action_stageToPRPalletScanFragment_to_stageToPRLocationScanFragment,
            null,
            navOptions
        )
    }

    private fun displayErrorMessage(message: String) {
        binding.toteInputErrRes.text = message
        binding.toteInput.selectAll()
        showSoftKeyBoard(fragmentContext, binding.toteInput)
    }
}