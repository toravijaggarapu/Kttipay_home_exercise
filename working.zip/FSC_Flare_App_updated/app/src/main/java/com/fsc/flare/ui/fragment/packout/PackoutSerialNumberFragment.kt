package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutSaveTmp
import com.fsc.flare.source.data.dto.packout.req.PackOutSerialNumberGetReq
import com.fsc.flare.source.data.dto.packout.req.PrintCaseLabelPackoutReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutSerialNumberFragment"

@AndroidEntryPoint
class PackoutSerialNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutSerialBinding
    private var tempSerialList = ArrayList<String>()
    private var count = 0

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutSerialBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvCounter.text = String.format("%d/%d",count,viewModel.getcasePalletQty())
        binding.btnEndPackout.isEnabled = false
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etSerial.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvSerialRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etSerial.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        binding.btnEndPackout.setOnClickListener {
            val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutstagingFragement()
            getNavigationController().navigate(action)
        }
        binding.tvViewButton.setOnClickListener {
            showScannedMultiItemsListDialog(
                tempSerialList,
                title=binding.tvSeriallabel.text.toString() + " ($count/${viewModel.getcasePalletQty()})",
                finalList = {
                    tempSerialList.addAll(it)
                    count = tempSerialList.size
                    binding.tvCounter.text = "($count/${viewModel.getcasePalletQty()})"
                    binding.tvViewButton.visibility = if (tempSerialList.size > 0) View.VISIBLE else View.GONE
                    enableSerialField(tempSerialList.size < viewModel.getcasePalletQty())
                }
            )
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etSerial)
        if (binding.etSerial.isFocused && !binding.etSerial.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Serial Number field focused")
            validateSerialNumber()
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSerialValidationObserver()
        subscribeSubmitPackoutObserver()
    }

    /**
     * method to validate Serial Number from API
     */
    private fun validateSerialNumber() {
        viewModel.validatePackOutSerialNumber(
            PackOutSerialNumberGetReq(
                containerNumber = viewModel.getLocationBarcode(),
                palletNumber = viewModel.getPalletReqNumber(),
                containerSerialNumber = binding.etSerial.text.toString(),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                userDirected = false,
                taskUom = "E"
            )
        )

    }


    /**
     * method to observe serial validation response
     */
    private fun subscribeSerialValidationObserver() {
        viewModel.serialValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { serialValidationResponse ->
                        if (serialValidationResponse.success == "true") {
                            if (serialValidationResponse.validLpn != null && serialValidationResponse.validLpn == "true") {
                                addSerialNumberToTempList()
                                binding.tvViewButton.visibility = if (tempSerialList.size > 0) View.VISIBLE else View.GONE
                                binding.etSerial.text = null
                            } else {
                                binding.tvSerialRes.text = resources.getString(R.string.validLpn_not_available)
                            }
                        } else {
                            binding.tvSerialRes.text = resources.getString(R.string.invalid_serial)
                            binding.etSerial.requestFocus()
                            binding.etSerial.selectAll()
                            showSoftKeyBoard(
                                fragmentContext, binding.etSerial
                            )
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "serialValidation Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }

    /**
     * method to add valid serial numbers to main serial list
     */
    private fun addSerialNumberToTempList() {
        if (!tempSerialList.contains(binding.etSerial.text.toString())) {
            tempSerialList.add(binding.etSerial.text.toString())
            binding.tvSerialRes.text = null
            count++
            binding.tvCounter.text = String.format("%d/%d",count,viewModel.getcasePalletQty())
            if (count == viewModel.getcasePalletQty()) {
                enableSerialField(false)
                count = 0
                callSubmitPackoutAPI()
            }
        } else {
            binding.tvSerialRes.text = resources.getString(R.string.duplicate_serial)
            binding.etSerial.requestFocus()
            binding.etSerial.selectAll()
        }
    }

    private fun enableSerialField(isEnable: Boolean) {
        binding.etSerial.isEnabled = isEnable
        binding.etSerial.isFocusable = isEnable
        binding.etSerial.isFocusableInTouchMode = isEnable
    }

    /**
     * method to call submit packout API
     */
    private fun callSubmitPackoutAPI() {
        viewModel.setSerialNumberList(tempSerialList)
        viewModel.submitPackout(
            PackOutSaveTmp(
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                viewModel.getLocationBarcode(),
                viewModel.getLocId(),
                viewModel.getcasePalletQty(),
                viewModel.getpckPallet(),
                viewModel.getPalletReqNumber(),
                viewModel.getcartonReqNumber(),
                viewModel.getItemId(),
                viewModel.getQuantity(),
                "EA",
                viewModel.getlotNumber(),
                viewModel.getExpiryDate(),
                viewModel.gettransIdentifier(),
                viewModel.getSerialNumberList(),
                viewModel.getInventoryType(),
                viewModel.lockCodeSelected,
                viewModel.isKitting
            )
        )
    }

    /**
     * submit packout observer
     */
    private fun subscribeSubmitPackoutObserver() {
        viewModel.submitPackoutResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutLocation response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "PackOutLocation Success:${response}")
                            binding.tvSerialRes.text = null
                            viewModel.settransIdentifier(response.transactionIdentifier)
                            binding.btnEndPackout.isEnabled = true
                            if (response.message.isNotEmpty()) {
                                showSuccessSnackBar(response.message)
                            }
                            if(viewModel.isKitting && !viewModel.isDekitting)
                            {
                                callToPrintCaseLabel()
                            }
                            else
                            {
                                val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutCartonFragement()
                                moveToFragment(action)
                               // palitizeCartonLogic(viewModel.getFlag())
                            }

                        } else {
                            binding.tvSerialRes.text = resources.getString(R.string.lbl_save_tmp_record_unsuccessful)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwaySerialNumber Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printCaseLabelResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "printCaseLabelResponse response:$response")
                        if (response.success) {
                            FlareLog.i(TAG, "printCaseLabelResponse Success:${response}")
                            showSuccessSnackBarStd(resources.getString(R.string.case_lbl_printed_successfully)) {
                                val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutCartonFragement()
                                moveToFragment(action)
                              //  palitizeCartonLogic(viewModel.getFlag())
                            }
                        } else {
                            if(response.message!=null)
                            {
                                FlareLog.e(TAG, "PackOutLocation Error:${response.message}")
                                showErrorSnackBar(response.message)
                            }
                            val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutCartonFragement()
                            moveToFragment(action)
                           // palitizeCartonLogic(viewModel.getFlag())
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showErrorSnackBar(message)
                        val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutCartonFragement()
                        moveToFragment(action)
                       // palitizeCartonLogic(viewModel.getFlag())
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun callToPrintCaseLabel() {
        if (viewModel.isKitting) {
            viewModel.printCaseLabel(
                PrintCaseLabelPackoutReq(
                    itemBarcode = viewModel.getItemBarcode(),
                    itemDescription = viewModel.getItemDesc(),
                    itemName = viewModel.getitemData(),
                    caseNumber = viewModel.getcartonReqNumber(),
                    qty = viewModel.getcasePalletQty().toString(),
                    printerName = viewModel.getDefaultPrinter(),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
        }
    }

    private fun palitizeCartonLogic(coun: Int) {
        if (viewModel.getTpData() == viewModel.palletizeCartonsTransValue) {
            val fg = viewModel.getFlag()
            val data = viewModel.getpckPallet()
            if (coun < data) {
                viewModel.setFlag(fg + 1)
                val action = PackoutSerialNumberFragmentDirections.actionPackoutserialnumberFragmentToPackoutCartonFragement()
                moveToFragment(action)
            } else {
                binding.btnEndPackout.isEnabled = true
            }
        } else {
            binding.btnEndPackout.isEnabled = true
        }

    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etSerial.setText(scan?.barcode.toString())
                binding.etSerial.text?.length?.let {
                    binding.etSerial.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Serial Number field focused")
                    validateSerialNumber()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }


}