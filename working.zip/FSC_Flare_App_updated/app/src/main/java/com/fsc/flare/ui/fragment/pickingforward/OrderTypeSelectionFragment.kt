package com.fsc.flare.ui.fragment.pickingforward

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBuildCartTaskGroupBinding
import com.fsc.flare.source.data.dto.lookups.toLookUpCodes
import com.fsc.flare.utils.Constants.AllocationType.ACTIVE_LTL
import com.fsc.flare.utils.Constants.AllocationType.ACTIVE_PARCEL
import com.fsc.flare.utils.Constants.AllocationType.FROM_CASE_PICK
import com.fsc.flare.utils.Constants.AllocationType.FROM_RESERVE_PICK
import com.fsc.flare.utils.PreferenceKeys.Companion.LTL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.PreferenceKeys.Companion.PCL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.PreferenceKeys.Companion.SUB_MENU_SELECTED
import com.fsc.flare.utils.setNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class OrderTypeSelectionFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var binding: FragmentBuildCartTaskGroupBinding
    private val allocationType by lazy { OrderTypeSelectionFragmentArgs.fromBundle(requireArguments()).allocationType }
    private val pclOrderLookups by lazy { sharedPreferences.getString(PCL_ORD_TYPES_PREFERENCE, null).toLookUpCodes() }
    private val ltlOrderLookups by lazy { sharedPreferences.getString(LTL_ORD_TYPES_PREFERENCE, null).toLookUpCodes() }
    private val combinedLookups by lazy {
        (sharedPreferences.getString(PCL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes() +
                sharedPreferences.getString(LTL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes()).distinctBy { it.lookupCode }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBuildCartTaskGroupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observables()
        setData()
    }

    private fun observables() {
        binding.pickCartTaskGroupDropDown.boolFoo.observe(viewLifecycleOwner) { selectedOrderType ->
            val orderType = (when (allocationType) {
                ACTIVE_PARCEL -> pclOrderLookups
                ACTIVE_LTL -> ltlOrderLookups
                else -> combinedLookups
            }).firstOrNull { it.lookupCodeDescription == selectedOrderType }?.lookupCode
            orderType?.let {
                setNavigationResult(key = ORDER_TYPE_RESULT,result = it)
                findNavController().popBackStack()
            }
        }
    }

    private fun setData() {
        binding.tvPickingPickCart.text = sharedPreferences.getString(SUB_MENU_SELECTED, null)
        binding.pickCartTaskGroupTv.text = getString(R.string.order_type)
        binding.pickCartTaskGroupDropDown.text = getString(R.string.select_order_type)

        when (allocationType) {
            ACTIVE_PARCEL, ACTIVE_LTL, FROM_CASE_PICK, FROM_RESERVE_PICK -> {
                val orderLookups = when (allocationType) {
                    ACTIVE_PARCEL -> pclOrderLookups
                    ACTIVE_LTL -> ltlOrderLookups
                    else -> combinedLookups
                }
                binding.pickCartTaskGroupDropDown.setOptions(ArrayList(orderLookups.map { it.lookupCodeDescription }))
            }

            else -> {
                findNavController().popBackStack()
            }
        }
    }
}