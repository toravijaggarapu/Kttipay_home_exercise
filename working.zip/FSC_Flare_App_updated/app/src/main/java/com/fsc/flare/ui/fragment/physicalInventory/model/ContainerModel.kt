package com.fsc.flare.ui.fragment.physicalInventory.model

data class ContainerModel(
    val containerNumber: String? = null,
    val containerId: String? =null
)
