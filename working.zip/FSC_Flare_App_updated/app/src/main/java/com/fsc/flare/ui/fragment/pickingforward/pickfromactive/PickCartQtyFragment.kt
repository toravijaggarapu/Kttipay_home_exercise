package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartQtyBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickingforward.IP_VALUE
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import java.lang.reflect.Type
import java.text.SimpleDateFormat
import java.util.Locale
import javax.inject.Inject

private const val TAG = "PickCartQtyFragment"
const val TASK_CYCLE_COUNT_PENDING = "ERR-TASK-049"
const val TASK_ALREADY_PICKED = "ERR-TASK-051"
const val TASK_ASSIGNED_TO_OTHER_USER = "ERR-TASK-052"
const val LOCATION_IS_EMPTY = "ERR-TASK-055"

@AndroidEntryPoint
class PickCartQtyFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartQtyBinding
    lateinit var cb1: CustomVisibilityCallback

    var lockCode:String = ""
    val inventoryLockList = ArrayList<String>()
    val inventoryLockCodeList = ArrayList<String>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartQtyBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.isShortPick = false
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "QTY field focused")
                    viewModel.isShortPick = false
                    validateQty()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.qtyInput.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "QTY field focused")
                viewModel.isShortPick = false
                validateQty()
            }
            false
        }
        binding.qtyInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.qtyResponse.text = null
            }
        })
        binding.shortPickCart.setOnClickListener {
            FlareLog.i(TAG, "ShortPickCart clicked")
            binding.qtyResponse.text = null
            val taskData = viewModel.getPickTaskDetails()
            var enteredQty = 0
            if (binding.qtyInput.text.toString().isNotEmpty()){
                enteredQty = binding.qtyInput.text.toString().toInt()
            }
            if (taskData != null) {
                val taskQty = viewModel.getTaskQty(taskData)
                when {
                    enteredQty + taskData.pickedQty > taskQty -> {
                        binding.qtyResponse.text = getString(R.string.lbl_qty_not_more_than_pick_qty)
                        binding.qtyInput.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.qtyInput)
                    }

                    enteredQty + taskData.pickedQty == taskQty-> {
                        showShortPickActionQtyIsSameAlert()
                    }


                    else -> {
                        showShortPickActionAlert(taskData, enteredQty)
                    }
                }
            }
        }
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            binding.cart.text = data?.cartNbr
            binding.taskId.text = "${taskData.taskId}"
            binding.item.text = taskData.itemCode
            binding.description.text = taskData.itemDescription
            binding.pickLocation.text = taskData.locationBarcode
            binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
            binding.pickedQty.text = viewModel.getPickQtyUOMValue(taskData)
            binding.qtyInputUom.text = if (viewModel.isInnerPack()) IP_VALUE else taskData.taskQtyUom
            if (!taskData.toteNumber.isNullOrEmpty()) {
                showToteLayout(true)
                binding.toteNumber.text = taskData.toteNumber
            } else
                showToteLayout(false)
        }

    }

    private fun getFormattedExpiryDate(expiryDate:String?):String
    {
        var formattedExpiryDate = ""
        if(expiryDate!=null && expiryDate!="")
        {
            val myFormat1 = "yyyy-MM-dd" // mention the format you need
            val sdf1 = SimpleDateFormat(myFormat1, Locale.US)
            val getApiExpiryDate = sdf1.parse(expiryDate)
            formattedExpiryDate = sdf1.format(getApiExpiryDate!!)
            return formattedExpiryDate
        }
        return formattedExpiryDate
    }

    /**
     * method to get valid serial numbers list from shared preferences
     */
    private fun getSerialList(): List<String> {
        val serialNumberList: MutableList<String>
        val serialListJson = sharedPreferences.getString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return emptyList()
    }

    private fun validateQty() {
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            var enteredQty = 0
            if (binding.qtyInput.text.toString().isNotEmpty()){
                enteredQty = binding.qtyInput.text.toString().toInt()
            }
            val taskQty =  viewModel.getTaskQty(taskData)
            when {

                !viewModel.isShortPick && binding.qtyInput.text.isNullOrEmpty() -> {
                    binding.qtyResponse.text = getString(R.string.lbl_qty_required)
                    binding.qtyInput.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.qtyInput)
                }
                !viewModel.isShortPick && enteredQty + taskData.pickedQty > taskQty -> {
                    binding.qtyResponse.text = getString(R.string.lbl_qty_not_more_than_pick_qty)
                    binding.qtyInput.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.qtyInput)
                }
                else -> {
                    hideSoftKeyBoard(fragmentContext, binding.qtyInput)
                    if (!viewModel.isShortPick)
                        taskData.pickedQty += enteredQty
//                    viewModel.resetSerialNumber()
                    // If Prompt ITEM Attributes is YES, SHOW THE LOT & EXPIRY IF IT TRACKED

                    if(sharedPreferences.getBoolean(PreferenceKeys.PickCart.IS_PROMPT_ITEM_ATTRIBUTES, false))
                    {
                        when {
                            taskData.itemLotTracked == "1" -> {
                                val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartLotFragment()
                                getNavigationController().navigate(action)
                            }
                            taskData.itemSerialTracked == "4" || taskData.itemSerialTracked == "1" -> {
                                if (taskData.pickedQty == getSerialList().size) {
                                    navigateToSlotFragment()
                                } else {
                                    if (taskData.itemSerialTracked == "1" &&
                                        (taskData.allocationType == AllocationType.PICK_FROM_ACTIVE.code ||
                                         taskData.allocationType == AllocationType.PICK_FROM_ACTIVE_RTV.code ||
                                         taskData.allocationType == AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code)) {
                                        navigateToSlotFragment()
                                    } else {
                                        navigateToSerialNumber()
                                    }
                                }
                            }
                            else -> {
                                navigateToSlotFragment()
                            }
                        }
                    }else
                    {
                        if(taskData.itemSerialTracked == "4" || taskData.itemSerialTracked == "1")
                        {
                            if (taskData.pickedQty == getSerialList().size) {
                                navigateToSlotFragment()
                            } else {
                                if (taskData.itemSerialTracked == "1" &&
                                    (taskData.allocationType == AllocationType.PICK_FROM_ACTIVE.code ||
                                     taskData.allocationType == AllocationType.PICK_FROM_ACTIVE_RTV.code ||
                                     taskData.allocationType == AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code))
                                {
                                    navigateToSlotFragment()
                                } else {
                                    navigateToSerialNumber()
                                }
                            }
                        } else {
                            navigateToSlotFragment()
                        }
                    }
                }
            }
        }
    }

    private fun navigateToSerialNumber() {
        val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartSerialFragment()
        getNavigationController().navigate(action)
    }

    private fun navigateToSlotFragment() {
        val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartSlotFragment()
        getNavigationController().navigate(action)
    }

    private fun subscribeObservers() {
        viewModel.shortPickTotesResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shortPickToteResponse ->
                        if (!shortPickToteResponse.toteDetails.isNullOrEmpty()) {
                            viewModel.setShortPickTotesList(shortPickToteResponse)
                            if (!shortPickToteResponse.prLocExist) {
                                navigateToStageCart()
                            } else {
                                val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPrLocationFragment()
                                getNavigationController().navigate(action)
                            }
                        } else {
                            if (shortPickToteResponse.promptStage)
                                navigateToStageCart()
                            else {
                                showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                                    navigateToTaskGroup()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Get short pick error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.taskPickQtyUpdateResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { qtyUpdateResponse ->
                        if (qtyUpdateResponse.success != null && qtyUpdateResponse.success) {
                            FlareLog.i(TAG, "taskPickQtyUpdate success: $qtyUpdateResponse")
                            val isChaseWave = (viewModel.getPickTaskDetails()!!.taskWaveType.isNotEmpty()) && viewModel.getPickTaskDetails()!!.taskWaveType == "C"
                            if (qtyUpdateResponse.promptStage != null && qtyUpdateResponse.promptStage) {
                                if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                    if (!isChaseWave && qtyUpdateResponse.taskShortQty > 0) {
                                        showSuccessSnackBarImp(resources.getString(R.string.proceed_to_problem_resolution_area_with_short_pick)) {
                                            getShortPickedTotesList()
                                        }
                                    } else {
                                        getShortPickedTotesList()
                                    }
                                } else {
                                    navigateToStageCart()
                                }
                            } else {
                                if (qtyUpdateResponse.taskDetails != null) {
                                    viewModel.updateOrderType(qtyUpdateResponse.orderType)
                                    viewModel.setPickTaskDetails(qtyUpdateResponse.taskDetails)
                                    if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue() && !qtyUpdateResponse.alterNativeLocationFound && !isChaseWave) {
                                        showSuccessSnackBarStd(resources.getString(R.string.short_picked_continue_picking)) {
                                            navigateToPickCart()
                                        }
                                    } else {
                                        navigateToPickCart()
                                    }
                                } else {
                                    showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                                        navigateToTaskGroup()
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPickQtyUpdate error: $message")
                        if(message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == TASK_CYCLE_COUNT_PENDING) {
                                    showCycleCountPendingAlert(getString(R.string.cycle_count_pending_for_location), isZeroPick = true)
                                }else if(msgArray[0] == TASK_ALREADY_PICKED || msgArray[0] == TASK_ASSIGNED_TO_OTHER_USER)
                                {
                                    showErrorAlert(msgArray[1], navigate = true, locationEmpty = false)
                                }else if (msgArray[0] == LOCATION_IS_EMPTY )
                                {
                                    showErrorAlert(msgArray[1], navigate = false, locationEmpty = true)
                                }
                                else {
                                    binding.qtyInput.requestFocus()
                                    binding.qtyInput.selectAll()
                                    binding.qtyResponse.text = msgArray[1]
                                    showSoftKeyBoard(fragmentContext, binding.qtyResponse)
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToPickCart() {
        val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartLocationFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
        getNavigationController().navigate(action, navOptions)
    }

    private fun getShortPickedTotesList() {
        viewModel.getShortPickedTotes(
            binding.cart.text.toString(),
            viewModel.getPickTask()?.cartId ?: 0
        )
    }

    private fun navigateToStageCart() {
        val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartStagingLocFragment()
        getNavigationController().navigate(action)
    }

    private fun navigateToTaskGroup(){
        if (viewModel.isComingFromPickCartFlow) {
            val action = PickCartQtyFragmentDirections.actionPickCartQtyFragmentToPickCartPalletFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartPalletFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        } else {
            val bundle = if (viewModel.isRTV) {
                bundleOf(IS_RTV to true)
            } else {
                null
            }
            val action =
                PickCartQtyFragmentDirections.actionPickCartQtyFragmentToBuildCartTaskGroup()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
            getNavigationController().navigate(action.actionId, bundle, navOptions)
        }
    }
    
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        //Scan Program is needed for the SLOT page. removed to reduce the multiple API calls
            binding.qtyInput.setText(scan?.barcode.toString())
            binding.qtyInput.text?.length?.let {
                binding.qtyInput.setSelection(it)
            }
            FlareLog.i(TAG, "QTY field focused")
            validateQty()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

    private fun showShortPickActionAlert(tskData: TaskDetails, enteredQty: Int) {
        val taskQty = viewModel.getTaskQtyUOMValue(tskData)
        val pickQty = (enteredQty + tskData.pickedQty).toString()+
                " " +
                (if (viewModel.isInnerPack()) IP_VALUE else tskData.taskQtyUom)

        val data = viewModel.getPickTask()
        val msg = if (data?.orderType != null && data.orderType.equals(Constants.FILL_KILL, ignoreCase = true)) {
            getString(R.string.lbl_this_pick_task_belongs_to_a_fill_kill_order_do_you_want_to_continue)
        } else {
            getString(R.string.short_pick_alert, taskQty, pickQty)
        }
        showCycleCountPendingAlert(msg, false)
    }

    private fun pickQtyUpdateCall(taskData: TaskDetails) {
        viewModel.taskPickQtyUpdate(
            TaskPickQtyUpdateReq(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                allocationType =  taskData.allocationType.toInt(),
                pickQty = viewModel.getPickQty(taskData).toString(),
                pickQtyUom = taskData.taskQtyUom,
                taskDetailId = taskData.taskDetId,
                taskId = taskData.taskId,
                serialNumber = getSerialList(),
                lotNumber = taskData.lotNumber,
                reasonCode = viewModel.reasonCode,
                expDate = getFormattedExpiryDate(taskData.expDate)
            )
        )
        viewModel.reasonCode = ""
    }

    private fun showShortPickActionQtyIsSameAlert() {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(resources.getString(R.string.lbl_pick_qty_and_picked_qty_is_same_so_this_is_not_a_short_pick_and_you_can_continue_with_the_normal_picking_process))

        builder.setPositiveButton(resources.getString(R.string.button_continue)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            validateQty()
        }

        builder.setNegativeButton(resources.getString(R.string.alert_button_no)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showCycleCountPendingAlert(message: String, isZeroPick: Boolean) {
        showAlertDialog(
            "",
            message,
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    viewModel.isShortPick = true
                    val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
                    val dialog = Dialog(fragmentContext)
                    dialog.setContentView(dialogView.root)
                    dialog.setCancelable(false)
                    dialog.show()
                    val lp = WindowManager.LayoutParams()
                    lp.copyFrom(dialog.window!!.attributes)
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT
                    lp.height =  ViewGroup.LayoutParams.MATCH_PARENT
                    dialog.window!!.attributes = lp
                    dialogView.btnCancel.setOnClickListener {
                        dialog.dismiss()
                    }
                    dialogView.btnOk.setOnClickListener {
                        val taskData = viewModel.getPickTaskDetails()
                        if (taskData != null) {
                            if (isZeroPick) {
                                taskData.pickedQty = 0
                                pickQtyUpdateCall(taskData)
                            } else {
                                var enteredQty = 0
                                if (binding.qtyInput.text.toString().isNotEmpty()){
                                    enteredQty = binding.qtyInput.text.toString().toInt()
                                }
                                taskData.pickedQty += enteredQty
                                if (taskData.pickedQty == 0) {
                                    pickQtyUpdateCall(taskData)
                                } else if (taskData.itemSerialTracked == "4" || taskData.itemSerialTracked == "1") {
                                    if (taskData.pickedQty == getSerialList().size) {
                                        pickQtyUpdateCall(taskData)
                                    } else {
                                        validateQty()
                                    }
                                } else {
                                    validateQty()
                                }
                            }
                        }
                        dialog.dismiss()
                    }
                    if (inventoryLockList.isEmpty())
                        viewModel.getInventoryReasonCodes()
                    else
                        dialogView.reasonCodeDropDown.setOptions(inventoryLockList)

                    viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
                        when (response) {
                            is Resource.Success -> {
                                hideProgressBar()
                                response.data?.let { lookUpResponse ->
                                    FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                                    lookUpResponse.lookups.forEach { lookUp ->
                                        lookUp.lookupCodes.forEach {
                                            inventoryLockList.add(it.lookupCodeDescription)
                                            inventoryLockCodeList.add(it.lookupCode)
                                        }
                                    }
                                    viewModel.setInventoryLocksList(lookUpResponse.lookups)
                                    dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                                }
                            }
                            is Resource.Error -> {
                                hideProgressBar()
                                response.message?.let { message ->
                                    FlareLog.e(TAG, "lookUpResponse Error: $message")
                                }
                            }
                            is Resource.Loading -> {
                                showProgressBar()
                            }
                        }
                    }

                    dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
                        val lookups = viewModel.getInventoryLocksList()
                        lookups.forEach { lookupCode ->
                            lookupCode.lookupCodes.forEach { lookup ->
                                if (lookup.lookupCodeDescription == selection) {
                                    FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                                    viewModel.reasonCode = lookup.lookupCode
                                    dialogView.btnOk.isEnabled = true
                                }
                            }
                        }
                    }
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun showErrorAlert(message:String , navigate:Boolean , locationEmpty:Boolean) {
        if(locationEmpty) {
            showCycleCountPendingAlert(message, isZeroPick = true)
        } else {
            val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            builder.setTitle("")
            builder.setMessage(message)

            builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
                dialogInterface.dismiss()
                if (navigate) {
                    navigateToTaskGroup()
                }
            }
            val alertDialog: MaterialAlertDialogBuilder = builder
            alertDialog.setCancelable(false)
            alertDialog.show()
        }
    }
}