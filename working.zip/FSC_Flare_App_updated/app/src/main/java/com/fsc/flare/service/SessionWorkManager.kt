package com.fsc.flare.service

import android.content.Context
import android.content.Intent
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.fsc.flare.log.FlareLog


private var TAG = "SessionWorkManager"
var SESSION_REFRESH = "SESSION_REFRESH"

class SessionWorkManager(var context: Context, workParams: WorkerParameters) : Worker(context, workParams) {

    override fun doWork(): Result {
        sendMessage()
        return Result.success()
    }
    private fun sendMessage() {
        FlareLog.d(TAG, "Broadcasting work")
        val intent = Intent(SESSION_REFRESH)
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent)
    }
}