package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.inventory.CartonAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.CartonDetailsRequest
import com.fsc.flare.source.data.dto.inventory.CaseTransferSubmitRequest
import com.fsc.flare.source.data.dto.inventory.CombinePalletRequest
import com.fsc.flare.source.data.dto.inventory.InventoryAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletLockUnlockAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLockRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerLocationRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferGetContainerRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferLocationRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InventoryRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = container,
            itemInfo = itemInfo
        )

    suspend fun getInventoryReasonCodes() = apiGatewayInterface.getInventoryReasonCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
    )

    suspend fun inventoryLockAdjustment(inventoryAdjustmentRequest: InventoryAdjustmentRequest) =
        apiGatewayInterface.inventoryLockAdjustment(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryAdjustmentRequest
        )

    suspend fun inventoryLockRequest(inventoryLockRequest: InventoryLockRequest) =
        apiGatewayInterface.inventoryLockRequest(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryLockRequest
        )

    suspend fun shipmentCartons(shipmentCartons: CartonDetailsRequest) =
        apiGatewayInterface.shipmentCartons(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            obContainerId = shipmentCartons.obContainerId,
            itemBarcode = shipmentCartons.itemBarcode,
            buId = shipmentCartons.buId,
            custId = shipmentCartons.custId,
            fcyId = shipmentCartons.fcyId
        )

    suspend fun packqtyconfirm(cartonAdjustmentRequest: CartonAdjustmentRequest) =
        apiGatewayInterface.packqtyconfirm(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            cartonAdjustmentRequest = cartonAdjustmentRequest
        )


    suspend fun validateInventoryTaskSerialNumber(inventorySerialNumberRequest: InventoryTaskSerialNumberRequest) =
        apiGatewayInterface.validateInventoryTaskSerialNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNumber = inventorySerialNumberRequest.containerNumber,
            palletNumber = inventorySerialNumberRequest.containerNumber,
            containerSerialNumber = inventorySerialNumberRequest.containerSerialNumber,
            taskUom = inventorySerialNumberRequest.taskUom,
            custId = inventorySerialNumberRequest.custId,
            fcyId = inventorySerialNumberRequest.fcyId,
            buId = inventorySerialNumberRequest.buId,
            userDirected = inventorySerialNumberRequest.userDirected,
            outBoundOnly = inventorySerialNumberRequest.outBoundOnly
        )

    suspend fun getInventoryLookups(inventoryLookupsRequest: InventoryLookupsRequest) = apiGatewayInterface.getInventoryLookups(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = inventoryLookupsRequest.fcyId,
        cusId = inventoryLookupsRequest.cusId,
        buId = inventoryLookupsRequest.buId,
        lookupNames = inventoryLookupsRequest.lookupNames,
    )

    /*Inventory transfer*/
    suspend fun inventoryTransferSlpResponse(getContDetailRequest: GetContDetailRequest) =
        apiGatewayInterface.inventoryTransferSlpResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNum = getContDetailRequest.containerNbr,
            custId = getContDetailRequest.custId,
            buId = getContDetailRequest.buId,
            fcyId = getContDetailRequest.fcyId,
            includeCCLocation = getContDetailRequest.includeCCLocation
        )

    suspend fun inventoryTransferLocationResponse(inventoryTransferLocationRequest: InventoryTransferLocationRequest) =
        apiGatewayInterface.inventoryTransferLocationResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryTransferLocationRequest
        )
    /*Inventory transfer*/

    suspend fun getInventoryLockCodes(inventoryLockcodeRequest: InventoryLockcodeRequest) = apiGatewayInterface.getInventoryLockCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = inventoryLockcodeRequest.custId,
        fcyId = inventoryLockcodeRequest.fcyId,
        buId = inventoryLockcodeRequest.buId
    )

    /*Inventory transfer container*/
    suspend fun inventoryTransferContainerResponse(getContDetailRequest: GetContDetailRequest) =
        apiGatewayInterface.inventoryTransferContainerResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNbr = getContDetailRequest.containerNbr,
            custId = getContDetailRequest.custId,
            buId = getContDetailRequest.buId,
            fcyId = getContDetailRequest.fcyId,
            includeCCLocation = getContDetailRequest.includeCCLocation,
            locClass = getContDetailRequest.locClass
        )

    suspend fun inventoryTransferContainerReverseToForwardResponse(inventoryTransferGetContainerRequest: InventoryTransferGetContainerRequest) =
        apiGatewayInterface.inventoryTransferContainerReverseToForwardResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNbr = inventoryTransferGetContainerRequest.containerNbr,
            custId = inventoryTransferGetContainerRequest.custId,
            buId = inventoryTransferGetContainerRequest.buId,
            fcyId = inventoryTransferGetContainerRequest.fcyId
        )

    suspend fun inventoryTransferContainerLocationResponse(inventoryTransferContainerLocationRequest: InventoryTransferContainerLocationRequest) =
        apiGatewayInterface.inventoryTransferContainerLocationResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryTransferContainerLocationRequest
        )

    /*Inventory transfer Serial API*/
    suspend fun inventoryTransferSerialResponse(getContDetailRequest: GetContDetailRequest) =
        apiGatewayInterface.getInventoryTransferSerialInquiry(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            serial = getContDetailRequest.containerNbr,
            custId = getContDetailRequest.custId,
            buId = getContDetailRequest.buId,
            fcyId = getContDetailRequest.fcyId,
            includeCCLocation = getContDetailRequest.includeCCLocation,
        )

    suspend fun getPalletDetail(palletNumber: String) =
        apiGatewayInterface.getPalletDetail(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = palletNumber
        )

    suspend fun getPalletCombineDetails(palletNumber: String,transferType:String) =
        apiGatewayInterface.getPalletDetailsForCombine(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = palletNumber,
            transferType = transferType,
            combineBy = transferType
        )

    suspend fun combinePallet(requestBody:CombinePalletRequest) =
        apiGatewayInterface.combinePallet(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            requestBody = requestBody
        )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun inventoryIbPalletAdjustment(inventoryAdjustmentRequest: InventoryIbPalletAdjustmentRequest) =
        apiGatewayInterface.inventoryIbPalletAdjustment(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryAdjustmentRequest
        )

    suspend fun getLockList(containerId: Long) =
        apiGatewayInterface.getLockList(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerId = containerId,
            containerType = "P",
        )

    suspend fun inventoryIbPalletLockUnlockAdjustment(inventoryIbPalletLockUnlockAdjustmentRequest: InventoryIbPalletLockUnlockAdjustmentRequest) =
        apiGatewayInterface.inventoryIbPalletLockUnlockAdjustment(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inventoryIbPalletLockUnlockAdjustmentRequest
        )

    suspend fun caseTransferValidateContainer(containerNumber:String, transferType: String) =
        apiGatewayInterface.caseTransferValidateContainer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            container = containerNumber,
            transferType = transferType
        )

    suspend fun generatePalletCaseNumber() =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = "pallet" //pallet_casenum
        )

    suspend fun caseTransferSubmitDestinationLocation(caseTransferSubmitRequest: CaseTransferSubmitRequest) =
        apiGatewayInterface.caseTransferSubmitDestinationLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            caseTransferSubmitRequest = caseTransferSubmitRequest
        )

    suspend fun getLocationInfo(locBarCode: String) = apiGatewayInterface.getLocationInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locBarCode = locBarCode
    )

    suspend fun getContainerDetails(containerNum: String,itemUOMRequired: Boolean) = apiGatewayInterface.getContainerInquiryWithItemUom(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum,
        itemUOMRequired = itemUOMRequired
    )

    suspend fun getCaseDetailsByPallet(parentContainerId: String) =
        apiGatewayInterface.getCaseDetailsByPallet(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            parentContainerId = parentContainerId,
            excludeLocationInfo = true,
            itemInfo = "Y"
        )
}
