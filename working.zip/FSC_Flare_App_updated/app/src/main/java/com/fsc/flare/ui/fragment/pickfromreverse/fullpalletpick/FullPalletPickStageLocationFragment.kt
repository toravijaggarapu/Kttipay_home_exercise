package com.fsc.flare.ui.fragment.pickfromreverse.fullpalletpick

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentFullpalletPickStageLocationFragmentBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveRequest
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveResponse
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountHeader
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = FullPalletPickPalletFragment::class.simpleName.toString()

@AndroidEntryPoint
class FullPalletPickStageLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private val pickingForwardViewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentFullpalletPickStageLocationFragmentBinding
    lateinit var cb1: CustomVisibilityCallback


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFullpalletPickStageLocationFragmentBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
         if (!viewModel.isRTV && sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "31") {
            getKittingStageLocation()
        }
        updateUI()
        subscribeObservers()
        return binding.root
    }

    private fun getKittingStageLocation() {
        val taskData = viewModel.getPickTaskDetails()
        if(taskData!=null)
        {
            val psuedoOrderId = taskData.orderId
            val orderType = "WO"
            viewModel.getKittingStagingLocation(psuedoOrderId!!, orderType)
        }
    }

    private fun updateUI() {
        if (!viewModel.isRTV && sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "31") {
            binding.scanStageLocVal.hint = getString(R.string.scan_kitting_staging_location)
            binding.txtScanStageLoc.text = getString(R.string.lbl_scan_kitting_stage_location)
            binding.stageLocationTv.text = getString(R.string.lbl_kitting_staging_location)
        }
    }

    private fun subscribeObservers() {
        viewModel.kittingStagingLocationResponse.observe(viewLifecycleOwner){response ->
            when(response){
                is Resource.Success ->{
                    hideProgressBar()
                    response.data?.let { kittingStageLocResponse ->
                        if (kittingStageLocResponse.success != null && kittingStageLocResponse.success) {
                            FlareLog.i(TAG, "kitting stage location success: $kittingStageLocResponse")
                            binding.stageLocationVal.text= kittingStageLocResponse.orderProcessingLocation.locationBarcode
                            val taskData = getPickTaskDetails()
                            if(taskData!=null)
                            {
                                taskData.stageLocationBarcode = kittingStageLocResponse.orderProcessingLocation.locationBarcode
                                taskData.stageLocationId = kittingStageLocResponse.orderProcessingLocation.locationId
                            }
                        }else{
                            binding.scanStageResponse.text = getString(R.string.error_wrong_kitting_stage_location)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.palletPickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { palletPickCompleteResponse ->
                        FlareLog.i(TAG, "palletPickCompleteResponse Response: $palletPickCompleteResponse")

                        if(palletPickCompleteResponse!=null)
                        {
                            if (palletPickCompleteResponse.success) {
                                if (viewModel.generateCycleCount)
                                    generateCycleCountToVerifyZeroLocation()
                                navigateToNextScreen(palletPickCompleteResponse)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPalletPickComplete Error: $message")
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty() && msgArray.size > 1) {
                                showErrorSnackBar(msgArray[1])
                            } else {
                                showErrorSnackBar(message)
                            }
                        } else {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.cycleCountTriggerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cycleCountTriggerResponse ->
                        if (cycleCountTriggerResponse.success) {
                            FlareLog.i(TAG, "cycleCountTriggerResponse Success: $cycleCountTriggerResponse.message")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "cycleCountTriggerResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToNextScreen(palletPickCompleteResponse: PalletPickFromReserveResponse) {
        if (palletPickCompleteResponse.message != null){
            showSuccessSnackBarStd(palletPickCompleteResponse.message) {
                val bundle : Bundle = if (viewModel.isRTV) {
                    bundleOf(IS_RTV to true)
                }else{
                    bundleOf(IS_RTV to false)
                }
                if (palletPickCompleteResponse.taskDetails != null) {
                    if (palletPickCompleteResponse.taskDetails.allocationType != "31" && palletPickCompleteResponse.taskDetails.stageLocationName.isNullOrEmpty()) {
                        noStageLocationDetailsError(palletPickCompleteResponse.taskDetails)
                    } else {
                        val taskDetails = palletPickCompleteResponse.taskDetails
                        if (viewModel.isRTV) {
                            pickingForwardViewModel.setPickTaskDetails(taskDetails)
                        } else {
                            viewModel.setPickTaskDetails(taskDetails)
                        }
                        pickingForwardViewModel.setPickTaskDetails(palletPickCompleteResponse.taskDetails)
                        val action =
                            FullPalletPickStageLocationFragmentDirections.actionFullPalletPickFromReserveStageLocationPageToFullPalletPickFromReservePalletPage()
                        val navOptions = NavOptions.Builder()
                            .setPopUpTo(R.id.fullPalletPickFromReservePalletPage, true).build()
                        getNavigationController().navigate(action.actionId, bundle,navOptions)
                    }
                } else {
                    if (viewModel.isRTV) {
                        val action =
                            FullPalletPickStageLocationFragmentDirections.actionFullPalletPickFromReserveStageLocationPageToBuildCartTaskGroup()
                        val navOptions =
                            NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true)
                                .build()
                        getNavigationController().navigate(action.actionId, bundle, navOptions)
                    } else {
                        val action =
                            FullPalletPickStageLocationFragmentDirections.actionFullPalletPickFromReserveStageLocationPageToTivoTaskGroupFragment()
                        val navOptions =
                            NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true)
                                .build()
                        getNavigationController().navigate(action, navOptions)
                    }
                }
            }
        }
    }

    private fun generateCycleCountToVerifyZeroLocation() {
        getPickTaskDetails()?.let {
            viewModel.generateCycleCountToVerifyZeroLocation(
                CycleCountTriggerRequest(
                    CycleCountHeader(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    ),skipErrIfCCPending = true
                ), locationId = it.pullLocationId
            )
        }
    }

    private fun noStageLocationDetailsError(taskDetails: TaskDetails) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(R.string.stage_location_not_added, taskDetails.taskId.toString(), taskDetails.customerOrderNumber.toString())
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            val action = FullPalletPickStageLocationFragmentDirections.actionFullPalletPickFromReserveStageLocationPageToTivoTaskGroupFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Location field focused")
                    validateStageLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        initData()
        binding.scanStageLocVal.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Location field focused")
                validateStageLocation()
            }
            false
        }
        binding.scanStageLocVal.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.scanStageResponse.text = null
            }
        })
    }

    private fun validateStageLocation() {
        if (binding.scanStageLocVal.text.toString().trim().isNotEmpty()) {
            val taskData = getPickTaskDetails()
            hideSoftKeyBoard(fragmentContext, binding.scanStageLocVal)
            if (binding.scanStageLocVal.text.toString().trim() == taskData?.stageLocationBarcode) {
                val taskGroup : String = if (viewModel.isRTV){
                    sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_CODE, null) ?: "0"
                }else {
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null) ?:"0"
                }
                viewModel.palletPickComplete(
                    PalletPickFromReserveRequest(
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        allocationType =  taskData.allocationType.toInt(),
                        taskGroup = taskGroup,
                        pickQty = taskData.taskQty.toString(),
                        pickQtyUom = taskData.taskQtyUom,
                        reasonCode = "",
                        palletNumber = viewModel.getScannedPallet(),
                        taskId = taskData.taskId,
                        taskDetId = taskData.taskDetId,
                        itemLotTracked = taskData.itemLotTracked,
                        itemExpDateTracked = taskData.itemExpDateTracked,
                        itemSerialTracked = taskData.itemSerialTracked,
                        stageLocId = taskData.stageLocationId,
                        orderType = viewModel.orderType
                    )
                )
            } else {
                if (!viewModel.isRTV && sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "31") {
                    binding.scanStageResponse.text = getString(R.string.error_wrong_kitting_stage_location)
                } else {
                    binding.scanStageResponse.text = getString(R.string.error_wrong_stage_location)
                }
                binding.scanStageLocVal.selectAll()
            }

        } else {
            if (!viewModel.isRTV && sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "31") {
                binding.scanStageResponse.text = getString(R.string.error_wrong_kitting_stage_location)
            } else {
                binding.scanStageResponse.text = getString(R.string.error_wrong_stage_location)
            }
            binding.scanStageLocVal.selectAll()
        }
    }

    private fun initData() {
        getPickTaskDetails()?.let { taskData ->
            with(binding) {
                taskId.text = taskData.taskId.toString()
                itemVal.text = taskData.itemCode
                itemDescVal.text = taskData.itemDescription
                palletVal.text = viewModel?.getScannedPallet()
                pickQtyVal.text = String.format("%d %s - %d %s", taskData.ibContainerQty, taskData.ibContainerUom, taskData.taskQty, taskData.taskQtyUom)
                stageLocationVal.text = taskData.stageLocationName
            }
        } ?: showErrorSnackBar(getString(R.string.task_details_are_not_found))
    }

    /**
     * get taskDetails data based on RTV/nonRTV flow
     */
    private fun getPickTaskDetails(): TaskDetails? {
        val taskData: TaskDetails? = if (viewModel.isRTV) {
            pickingForwardViewModel.getPickTaskDetails()
        } else {
            viewModel.getPickTaskDetails()
        }
        return taskData
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.scanStageLocVal.setText(scan?.barcode.toString())
            binding.scanStageLocVal.text?.length?.let {
                binding.scanStageLocVal.setSelection(it)
            }
            FlareLog.i(TAG, "Scan Stage Location field focused")
            validateStageLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}