package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "TivoALTYP11StagingLocationFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [TivoALTYP11StagingLocationFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11StagingLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLStagingLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etStagingLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvStagingLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val stageTaskDetails = viewModel.getStageTaskDetails()
        if (stageTaskDetails != null) {
            binding.tvContainerNumberValue.text = stageTaskDetails.obContainerNumber
            binding.tvItemCodeValue.text = stageTaskDetails.itemCode
            binding.tvDescriptionValue.text = stageTaskDetails.itemDesc
            binding.tvQtyValue.text = String.format("%d Units",stageTaskDetails.pickQty)
            binding.tvStagingLocationValue.text = stageTaskDetails.stageLocationName
            val taskDetails = viewModel.getPickTaskDetails()
            if (taskDetails != null) {
                if (taskDetails.itemLotTracked == "1" && taskDetails.lotNumber.isNotEmpty()) {
                    binding.tvLotNumber.visibility = View.VISIBLE
                    binding.tvLotValue.visibility = View.VISIBLE
                    binding.tvLotValue.text = taskDetails.lotNumber
                }
                if (taskDetails.itemExpDateTracked == "1" && !taskDetails.expDate.isNullOrEmpty()) {
                    binding.tvExpiryDate.visibility = View.VISIBLE
                    binding.tvExpiryDateValue.visibility = View.VISIBLE
                    binding.tvExpiryDate.text = formatExpiryDate(taskDetails.expDate)
                }
            }
        }

        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                FlareLog.i(TAG, "Staging Location field focused")
                validateStagingLocation()
            }
            false
        }


        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Staging Location field focused")
                        validateStagingLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeReservePickStageObserver()
    }

    /**
     * method to validate Staging Location from API
     */
    private fun validateStagingLocation() {
        val stageTaskDetails = viewModel.getStageTaskDetails()
        if (binding.etStagingLocation.text.toString() == stageTaskDetails?.stageLocationBarcode) {
            callReservePickStageAPI()
        } else {
            binding.tvStagingLocationResponse.text = resources.getString(R.string.invalid_staging_location)
        }
    }

    /**
     * method to call reserve pick stage endpoint/submit call
     */
    private fun callReservePickStageAPI() {
        val data = viewModel.getStageTaskDetails()
        if (data != null) {
            viewModel.reservepickstageupdate(
                ReservePickStageRequest(
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    itemCode = data.itemCode,
                    itemDesc = data.itemDesc,
                    obContainerId = data.obContainerId,
                    obContainerNumber = data.obContainerNumber,
                    pickQty = data.pickQty,
                    pickQtyUom = data.pickQtyUom,
                    stageLocationBarcode = data.stageLocationBarcode,
                    stageLocationId = data.stageLocationId,
                    stageLocationName = data.stageLocationName,
                    taskId = data.taskId
                )
            )
        }
    }

    /**
     * method to subscribe reserve pick stage observer
     */
    private fun subscribeReservePickStageObserver() {
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.taskDetails == null) {
                            showSuccessSnackBarStd(response.message) {
                                val action =
                                    TivoALTYP11StagingLocationFragmentDirections.actionStagingLocationFragmentToTaskgroupsFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            viewModel.setStageTaskDetails(response.taskDetails)
                            val action =
                                TivoALTYP11StagingLocationFragmentDirections.actionStagingLocationFragmentToStagingLocationFragment()
                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                            getNavigationController().navigate(action, navOptions)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etStagingLocation.setText(scan?.barcode.toString())
                binding.etStagingLocation.text?.length?.let {
                    binding.etStagingLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Staging Location field focused")
                    validateStagingLocation()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}