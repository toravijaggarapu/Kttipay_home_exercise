package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBUomBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.createIBContainer.Item
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBUomFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBUomFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBUomFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBUomBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var uomList = ArrayList<String>()
    private var conversionRateCSToEA: Int = 0


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        if (uomList.isEmpty()) {
            populateUOMDropDown()
        }
        cb1.onVisibilityChange(true)
    }


    /**
     * method to populate UOM dropdown based on Item respose
     */
    private fun populateUOMDropDown(): ArrayList<String> {
        uomList.add("EA")
//        uomList.add("CS")
        return uomList
    }



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBUomBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvQtyResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val itemData = viewModel.getItemBarcodeData()
        if(itemData!=null){
            binding.tvItemCodeValue.text = itemData.itemBarCode
            binding.tvItemDescValue.text = itemData.description
            setupBottomInfoLayout(itemData)
        }
        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.ddUom.setOptions(uomList)

        binding.etQty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etQty)
                FlareLog.i(TAG, "Qty field focused")
                validateQtyCheck()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etQty.isFocused) {
                        FlareLog.i(TAG, "Qty field focused")
                        validateQtyCheck()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.ddUom.boolFoo.observe(viewLifecycleOwner) {
            binding.tvUomResponse.text = null
            when {
                binding.etQty.text.isNullOrEmpty() -> {
                    binding.tvQtyResponse.text = resources.getString(R.string.error_empty_qty)
                }
                binding.etQty.text.toString().toInt() == 0 -> {
                    binding.etQty.selectAll()
                    binding.tvQtyResponse.text = resources.getString(R.string.error_zero_qty)
                }
                else -> {
                    calculateQty()
                }
            }

        }

    }

    /**
     * method to setup bottom case/pallet info layout
     */
    private fun setupBottomInfoLayout(itemData: Item) {
        binding.infoLayout.placeholder.visibility = View.GONE
        if (itemData.uomConversions != null && itemData.uomConversions.isNotEmpty()) {
            itemData.uomConversions.forEach {
                if (it.qtyUOM == "EA" && it.toUOM == "CS") {
                    binding.infoLayout.tvManual.text = String.format("1CS = %d Eaches",it.conversionRate)
                    conversionRateCSToEA = it.conversionRate
                }
                if (it.qtyUOM == "CS" && it.toUOM == "PL") {
                    binding.infoLayout.tvSystem.text = String.format("1PL = %d Cases",it.conversionRate)
                }
            }
        }
    }

    /**
     * method to calculate Qty in Eaches/Units
     */
    private fun calculateQty() {
        val inputQty = binding.etQty.text.toString().toInt()
        val selectedUom = binding.ddUom.text.toString()

        viewModel.setInputQty(inputQty)
        viewModel.setInputQtyUom(selectedUom)
        when (selectedUom) {
            "EA" -> {
                viewModel.setInputQtyInUnits(inputQty)
                if((sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) && conversionRateCSToEA != 0)
                    && (inputQty > conversionRateCSToEA)){
                    binding.tvQtyResponse.text = resources.getString(R.string.lbl_entered_qty_cannot_be_greater_than_defined_qty)
                }else{
                    if (inputQty > conversionRateCSToEA) {
                        showQtyGreaterWarningPopup()
                    } else {
                        navigate()
                    }
                }
            }
            "CS" -> {
                val finalQtyInEaches = inputQty * conversionRateCSToEA
                viewModel.setInputQtyInUnits(finalQtyInEaches)
                if((sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) && conversionRateCSToEA != 0)
                    && (inputQty > conversionRateCSToEA)){
                    binding.tvQtyResponse.text = resources.getString(R.string.lbl_entered_qty_cannot_be_greater_than_defined_qty)
                }else{
                    if (finalQtyInEaches > conversionRateCSToEA) {
                        showQtyGreaterWarningPopup()
                    } else {
                        navigate()
                    }
                }
            }
            "PL" -> {
            }

        }

    }

    /**
     * method to show warning popup when input Qty is greater than the Max Qty allowed
     */
    private fun showQtyGreaterWarningPopup() {
        MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setTitle(getString(R.string.container_qty_greater_case_uom))
            .setCancelable(true)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ ->
                dialog.dismiss()
                navigate()
            }
            .setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    /**
     * method to handle navigation to next screen
     */
    private fun navigate() {
        val itemData = viewModel.getItemBarcodeData()
        if (itemData!=null) {
            when {
                itemData.tracking.lotRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBUomFragmentDirections.actionUomFragmentToLotFragment()
                    navController.navigate(action)
                }
                itemData.tracking.expirationRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBUomFragmentDirections.actionUomFragmentToExpiryDateFragment()
                    navController.navigate(action)
                }
                itemData.tracking.countryOfOriginRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBUomFragmentDirections.actionUomFragmentToCooFragment()
                    navController.navigate(action)
                }
                /*itemData.tracking.serialNumberRequired == "1" ||*/ itemData.tracking.serialNumberRequired == "4" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBUomFragmentDirections.actionUomFragmentToSerialFragment()
                    navController.navigate(action)
                }
                else -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBUomFragmentDirections.actionUomFragmentToLockReasonCodeFragment()
                    navController.navigate(action)
                }
            }
        }
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeUOMObserver()
    }


    /**
     * method to subscribe UOM list observer
     */
    private fun subscribeUOMObserver() {

    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etQty.setText(scan?.barcode.toString())
                binding.etQty.text?.length?.let {
                    binding.etQty.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Qty field focused")
                    validateQtyCheck()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun validateQtyCheck(){
        when {
            binding.etQty.text.isNullOrEmpty() -> {
                //binding.etQty.requestFocus()
                binding.tvQtyResponse.text = resources.getString(R.string.error_empty_qty)
            }
            binding.etQty.text.toString().toInt() == 0 -> {
                //binding.etQty.requestFocus()
                binding.etQty.selectAll()
                binding.tvQtyResponse.text = resources.getString(R.string.error_zero_qty)
            }
            binding.ddUom.text == resources.getString(R.string.lbl_select_uom) -> {
                binding.etQty.clearFocus()
                binding.tvUomResponse.text = resources.getString(R.string.error_select_uom)
            }
            else -> {
                calculateQty()
            }
        }
    }
}