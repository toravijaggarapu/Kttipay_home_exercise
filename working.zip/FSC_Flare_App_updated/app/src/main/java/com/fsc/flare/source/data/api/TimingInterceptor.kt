package com.fsc.flare.source.data.api

import com.fsc.flare.log.FlareLog
import okhttp3.Interceptor
import okhttp3.Response

private const val TAG = "APIResponseTiming"
class TimingInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val startTime = System.nanoTime()  // Start time

        // Proceed with the request
        val response = chain.proceed(request)

        val endTime = System.nanoTime()  // End time
        val durationInSeconds = (endTime - startTime) / 1_000_000_000.0 // Convert to seconds

        FlareLog.i(TAG, "Request to ${request.url} took $durationInSeconds seconds") // Log the duration in seconds

        return response
    }
}