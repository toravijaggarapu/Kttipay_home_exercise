package com.fsc.flare.source.data.dto;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

import org.joda.time.LocalDateTime;

import java.io.IOException;

public class UnixTimestampAdapter extends TypeAdapter<LocalDateTime> {

    public UnixTimestampAdapter() {

    }

    @Override
    public void write(JsonWriter out, LocalDateTime value) throws IOException {
        out.value(value.toString());
    }

    @Override
    public LocalDateTime read(JsonReader in) throws IOException {
        long unixTimestampMillis = 0L;
        if (JsonToken.NUMBER.equals(in.peek())) {
            unixTimestampMillis = in.nextLong();
        } else if (JsonToken.STRING.equals(in.peek())) {
            unixTimestampMillis = Long.valueOf(in.nextString());
        }
        return new LocalDateTime(unixTimestampMillis * 1000L);
    }
}
