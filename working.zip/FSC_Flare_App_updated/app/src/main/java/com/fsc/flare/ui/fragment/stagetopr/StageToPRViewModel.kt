package com.fsc.flare.ui.fragment.stagetopr

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrRequest
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrResponse
import com.fsc.flare.source.repository.StageToPRRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "StageToPRViewModel"
@HiltViewModel
class StageToPRViewModel @Inject constructor(private val repository: StageToPRRepository) : BaseViewModel() {

    var containerId = 0
    private val _obContainerResponse = SingleLiveEvent<Resource<ValidateCartonHandlerTypeResponse>>()
    internal val obContainerResponse: LiveData<Resource<ValidateCartonHandlerTypeResponse>>
        get() = _obContainerResponse

    private val _inventoryStagePrResponse = SingleLiveEvent<Resource<InventoryStageToPrResponse>>()
    internal val inventoryStagePrResponse: LiveData<Resource<InventoryStageToPrResponse>>
        get() = _inventoryStagePrResponse

    private suspend fun fetchOBCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest) {
        _obContainerResponse.postValue(Resource.Loading())
        val response = repository.fetchObCartonDetails(validateCartonHandlerTypeRequest)
        _obContainerResponse.postValue(handleObCartonDetailsResponse(response))
    }

    private fun handleObCartonDetailsResponse(response: Response<ValidateCartonHandlerTypeResponse>): Resource<ValidateCartonHandlerTypeResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun obCartonDetailsRequest(palletNumber: String) {
        viewModelScope.launch {
            fetchOBCartonDetails(
                ValidateCartonHandlerTypeRequest(
                    cartonNbr = palletNumber,
                    type = OBIBTransformations.STG_PR.type,
                    responseLevel = "SUMMARY"
                )
            )
        }
    }

    private suspend fun inventoryStagePrReCall(inventoryStagePrReCallRequest: InventoryStageToPrRequest) {
        _inventoryStagePrResponse.postValue(Resource.Loading())
        val response = repository.inventoryStagePrReCall(inventoryStagePrReCallRequest)
        _inventoryStagePrResponse.postValue(handleInventoryStagePrReCallResponse(response))
    }

    private fun handleInventoryStagePrReCallResponse(response: Response<InventoryStageToPrResponse>): Resource<InventoryStageToPrResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun inventoryStagePrReCallRequest(inventoryStagePrReCallRequest: InventoryStageToPrRequest) {
        viewModelScope.launch {
            inventoryStagePrReCall(inventoryStagePrReCallRequest)
        }
    }


}