package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.Item
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails

class OBIBTransSplitRecallSharedViewModel: ViewModel() {

    private var _obCartonDetails: OBCartonDetails? = null
    var obCartonDetails: OBCartonDetails? by ::_obCartonDetails

    private var _blindIbContainerNumber: String? = null
    var blindIbContainerNumber: String? by ::_blindIbContainerNumber

    private var _itemDetails: Item? = null
    var itemDetails: Item? by ::_itemDetails

    private var _lotNumber: String? = null
    var lotNumber: String? by ::_lotNumber

    private var _expiryDate: String? = null
    var expiryDate: String? by ::_expiryDate

    private var _coo: String? = null
    var coo: String? by ::_coo

    private var _itemQty: String? = null
    var itemQty: String? by ::_itemQty

    private var _countriesLookup = mapOf<String, String>()
    var countriesLookup: Map<String, String> by ::_countriesLookup
}