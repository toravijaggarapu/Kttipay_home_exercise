package com.fsc.flare.ui.fragment.pickfromreverse.tivopickfrom

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStagingLocationTivoPickFromReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageResponse
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "FragmentStagingLocationTivoPickFrom"

@AndroidEntryPoint
class FragmentStagingLocationTivoPickFrom : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentStagingLocationTivoPickFromReserveBinding
    private var mResponse: ReservePickStageResponse? = null

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        super.onResume()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStagingLocationTivoPickFromReserveBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                        updateStaging()
                    } else {
                        binding.tvError.text = getString(R.string.alert_enter_staging_location)
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                FlareLog.i(TAG, "etStagingLocation field focused")
                if (!binding.etStagingLocation.text.isNullOrEmpty()) {
                    updateStaging()
                } else {
                    binding.tvError.text = getString(R.string.alert_enter_staging_location)
                }
            }
            false
        }

        //checkData()
        hitApi()
        addListener()
    }

    private fun addListener()
    {
        binding.etStagingLocation.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.tvError.text = ""
            }
        })
    }

    private fun init() {

        mResponse?.taskDetails?.let { taskDetail ->
            binding.tvStagingLocationValue.text = taskDetail.stageLocationName
            binding.tvPalletNumber.text =
                if (viewModel.isPallet(taskDetail.pickQtyUom)) getString(R.string.lbl_pallet_number) else getString(R.string.container_number)
            binding.tvPalletNumberValue.text = taskDetail.obContainerNumber
            binding.itemCodeValue.text = taskDetail.itemCode
            binding.tvDescValue.text = taskDetail.itemDesc

            var pickQuantityUOM = ""

            if(taskDetail.pickQtyUom == "Pallets")
            {
                pickQuantityUOM = if(taskDetail.pickQty >1) taskDetail.pickQtyUom else "Pallet"
            }
            else if(taskDetail.pickQtyUom == "Cases")
            {
                pickQuantityUOM = if(taskDetail.pickQty >1) taskDetail.pickQtyUom else "Case"
            }

            binding.pickQuantityValue.text = String.format("%d %s",taskDetail.pickQty,pickQuantityUOM)
        }
    }

    private fun hitApi() {
        viewModel.tivoPickFromReserveLocationInfo()
    }

    private fun moveToScreen() {

        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)

        navController.navigate(
            R.id.TivoTaskGroupFragment,
            null,
            NavOptions.Builder()
                .setPopUpTo(R.id.TivoTaskGroupFragment, true)
                .build()
        )

    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }


    private fun subscribeObservers() {

        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { reservePickStageResponse ->
                        if (reservePickStageResponse.success) {
                            // binding.tvStagingLocationValue.text = response.taskDetails?.stageLocationName
                            //mResponse = response
                            binding.etStagingLocation.setText("")
                            mResponse = reservePickStageResponse
                            if (reservePickStageResponse.taskDetails == null) {
                                if (reservePickStageResponse.message != null) {
                                    showSuccessSnackBar(reservePickStageResponse.message)
                                }
                                moveToScreen()
                            } else {
                                // Update task detail for next task
                                init()
                            }
                        } else {
                            binding.tvError.text = getString(R.string.invalid_staging_location)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                        binding.tvError.text = getString(R.string.invalid_staging_location)

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.tivoPickFromReserveReleaseResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { reservePickStageResponse ->
                        if (reservePickStageResponse.success && (reservePickStageResponse.taskDetails != null)) {
                            mResponse = reservePickStageResponse
                            init()
                        } else {
                            showErrorSnackBar(reservePickStageResponse.message)
                        }

                    }

                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "tivo staging location Error: $message")
                        showErrorSnackBar(message)

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun updateStaging() {
        if (mResponse?.taskDetails?.stageLocationBarcode == binding.etStagingLocation.text.toString()) {
            if (mResponse != null) {
                binding.tvError.text = ""
                mResponse?.taskDetails?.let { data ->
                    viewModel.reservepickstageupdate(
                        ReservePickStageRequest(
                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            data.itemCode,
                            data.itemDesc,
                            data.obContainerId,
                            data.obContainerNumber,
                            data.pickQty,
                            data.pickQtyUom,
                            data.stageLocationBarcode,
                            data.stageLocationId,
                            data.stageLocationName,
                            data.taskId
                        )
                    )
                }
            } else {
                binding.tvError.text = getString(R.string.no_release_location_found)
            }
        } else {
            binding.tvError.text = getString(R.string.invalid_staging_location)
        }
    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")

    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}