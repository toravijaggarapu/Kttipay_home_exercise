package com.fsc.flare.ui.fragment.packing

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackingSelectDeliveryBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackingSelectDeliveryFragment"

@AndroidEntryPoint
class PackingSelectDeliveryFragment : BaseFragment(), FlareScannable {

    lateinit var binding: FragmentPackingSelectDeliveryBinding
    private val viewModel: PackingViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPackingSelectDeliveryBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set Pack method
        binding.tvPackMethodValue.text = viewModel.getPackMethodDescription()

        // Set Pack Station
        binding.tvPackStationValue.text = viewModel.getPackStationDescription()


        if(viewModel.cartonNumber.isEmpty()){
            // Set Tote Number

            binding.cartonNumberGroup.visibility = View.GONE

            binding.toteNumberGroup.visibility = View.VISIBLE
            binding.tvToteNumberValue.text = viewModel.toteNumber
        }
        else {
            // Set Carton Number
            binding.toteNumberGroup.visibility = View.GONE

            binding.cartonNumberGroup.visibility = View.VISIBLE
            binding.tvCartonNumberValue.text = viewModel.cartonNumber
        }

        // Set Shipping Method
        binding.tvShippingMethodValue.text = viewModel.getShipmentMethodDescription()

        // Set Carton Type
        binding.tvCartonTypeValue.text = viewModel.getCartonTypeValue()

        binding.ldConfirmButton.setOnClickListener {
            viewModel.saturdayDelivery = binding.cbDelivery.isChecked
            navigateToPackingDetailsFragment()
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    fun navigateToPackingDetailsFragment(){
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        val action = PackingSelectDeliveryFragmentDirections.actionPackingSelectDeliveryFragmentToPackingSuccessFragment()
        navController.navigate(action)
    }

}