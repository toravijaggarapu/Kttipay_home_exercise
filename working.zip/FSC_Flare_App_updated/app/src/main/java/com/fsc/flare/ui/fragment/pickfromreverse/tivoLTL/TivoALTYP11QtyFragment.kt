package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTivoLTLQtyBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_FULL_TRACKING
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SERIAL_TRACK_OUTBOUND_ONLY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "TivoALTYP11QtyFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [TivoALTYP11QtyFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class TivoALTYP11QtyFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTivoLTLQtyBinding
    private var taskDetails: TaskDetails? = null
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTivoLTLQtyBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvQtyResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        taskDetails = viewModel.getPickTaskDetails()
        binding.tvTaskIdValue.text = taskDetails?.taskId.toString()
        binding.tvItemCodeValue.text = taskDetails?.itemCode
        binding.tvDescriptionValue.text = taskDetails?.itemDescription
        binding.tvPickQtyValue.text = String.format("%d Units",taskDetails?.taskQty)
//        binding.tvPickedQtyValue.text = "0 Units"
        binding.tvPickedQtyValue.text = resources.getQuantityString(R.plurals.pallet_transfer_units, viewModel.getQtyEntered(), viewModel.getQtyEntered())
        binding.tvLocationValue.text = taskDetails?.locationBarcode


        binding.etQty.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etQty)
                FlareLog.i(TAG, "Qty field focused")
                if(binding.etQty.text.toString().trim().isEmpty()){
                    binding.tvQtyResponse.text = getString(R.string.error_empty_qty)
                }else{
                    validateQty()
                }
            }
            false
        }


        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etQty.isFocused) {
                        FlareLog.i(TAG, "Qty field focused")
                        if(binding.etQty.text.toString().trim().isEmpty()){
                            binding.tvQtyResponse.text = getString(R.string.error_empty_qty)
                        }else{
                            validateQty()
                        }
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnStage.setOnClickListener(View.OnClickListener {
            /*val navController =
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action = RCContainerFragmentDirections.actionRcContainerToRcStagingLocation()
            navController.navigate(action)*/
        })

        binding.btnShortPcik.setOnClickListener {
            if(binding.etQty.text.toString().trim().isEmpty()){
                binding.tvQtyResponse.text = getString(R.string.error_empty_qty)
            }else if (getPickedQty() == taskDetails?.taskQty) {
                showShortPickActionQtyIsSameAlert()
            }else{
                validateQty()
            }
        }
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeQtyObserver()
    }


    /**
     * method to validate Qty from API
     */
    private fun validateQty() {
//        if (binding.etQty.text.toString().toInt() == taskDetails?.taskQty) {
//            val navController =
//                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//            val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToContainerFragment()
//            navController.navigate(action)

        val pickedQty = getPickedQty()
        val serialListSize = viewModel.getSerialNumberList().size

        if (getPickedQty() == taskDetails?.taskQty) {//If the pick Qty is equal to task detail, proceed without alert.
            afterQtyValidate()
        } else if (viewModel.getSerialNumberList().size == taskDetails?.taskQty && getPickedQty()> taskDetails?.taskQty!!) {//Picked qty is greater than the
//            binding.tvQtyResponse.text = "Task Qty already picked."
//            Handler().postDelayed({navigateAfterQtyValidate()}, 500)
            binding.tvQtyResponse.text = resources.getString(R.string.lbl_picked_qty_cannot_be_grater_than_task_qty)
        }else if (viewModel.getSerialNumberList().size < taskDetails?.taskQty!! && getPickedQty()> taskDetails?.taskQty!!) {//Picked qty is greater than the
            binding.tvQtyResponse.text = resources.getString(R.string.lbl_picked_qty_cannot_be_grater_than_task_qty)
        } else {
            showShortPickActionAlert()
        }

//        } else {
//            binding.tvQtyResponse.text = resources.getString(R.string.qty_mismatch)
//            binding.etQty.requestFocus()
//            binding.etQty.selectAll()
//            showSoftKeyBoard(fragmentContext, binding.etQty)
//        }
        /*  //TODO:Need to ask value info to be passed.
          viewModel.validateQty(
              TivoValidateQtyRequest(
                  custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                  buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                  fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                  qty = binding.etQty.text.toString().toInt(),//
                  palletQty = taskDetails?.taskQty!!,//
                  caseQty = taskDetails?.taskQty!!,//
                  locationBarCode = taskDetails?.locationBarcode!!,//
                  transactionIdentifier = taskDetails?.taskQty!!,//
              )
          )*/
    }


    /**
     * method to subscribe Qty observer
     */
    private fun subscribeQtyObserver() {
        viewModel.validateQtyResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateQtyResponse ->
                        if (validateQtyResponse.success) {
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToContainerFragment()
                            navController.navigate(action)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvQtyResponse.text = message
                        binding.etQty.requestFocus()
                        binding.etQty.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etQty)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun saveEnteredQty(pickedQty: Int){
        viewModel.setQtyEntered(pickedQty)
    }

    private fun showShortPickActionAlert() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(R.string.short_pick_alert, taskDetails?.taskQty.toString() + " " + taskDetails?.taskQtyUom,
            getPickedQty().toString() +" " + taskDetails?.taskQtyUom)
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_yes)) { dialogInterface, which ->
            dialogInterface.dismiss()
            afterQtyValidate()
        }

        builder.setNegativeButton(resources.getString(R.string.alert_button_no)) { dialogInterface, which ->
            dialogInterface.dismiss()

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showShortPickActionQtyIsSameAlert() {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(resources.getString(R.string.lbl_pick_qty_and_picked_qty_is_same_so_this_is_not_a_short_pick_and_you_can_continue_with_the_normal_picking_process))

        builder.setPositiveButton(resources.getString(R.string.button_continue)) { dialogInterface, which ->
            dialogInterface.dismiss()
            afterQtyValidate()
        }

        builder.setNegativeButton(resources.getString(R.string.alert_button_no)) { dialogInterface, which ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun afterQtyValidate(){
        if (taskDetails != null) {
            saveEnteredQty(getPickedQty())
            navigateAfterQtyValidate()
        }
    }

    private fun navigateAfterQtyValidate(){
        if (taskDetails != null) {
            taskDetails = viewModel.getPickTaskDetails()
            if(viewModel.getQtyEntered() == 0){
                //If the picked Qty is 0, no need to go for Serial, Lot, Exp date pages. Move to Ops container only.
                val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToContainerFragment()
                getNavigationController().navigate(action)
            } else if(viewModel.getQtyEntered() == taskDetails?.taskQty &&
                viewModel.getSerialNumberList().size == taskDetails?.taskQty){
                navigationNextPage(false)
            } else if(viewModel.getQtyEntered() == viewModel.getSerialNumberList().size) {
                navigationNextPage(false)
            }else{
                navigationNextPage(true)
            }
        }
    }

    private fun navigationNextPage(isCheckSerial:Boolean){
        if (sharedPreferences.getBoolean(PreferenceKeys.PickFromReserve.IS_PROMPT_ITEM_ATTRIBUTES, false)) {
            if (isCheckSerial && taskDetails?.itemSerialTracked == SERIAL_TRACK_OUTBOUND_ONLY || taskDetails?.itemSerialTracked == SERIAL_TRACK_FULL_TRACKING) {
                val bundle = bundleOf(
                    "pageType" to "serial"
                )
                getNavigationController().navigate(R.id.action_qtyFragment_to_itemSerialFragment, bundle)
            } else if (taskDetails?.itemLotTracked != null && taskDetails?.itemLotTracked!!.isNotEmpty() &&
                (taskDetails?.itemLotTracked == "Y" || taskDetails?.itemLotTracked == "1")
            ) {
                val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToLotTrackFragment()
                getNavigationController().navigate(action)
            } else if (taskDetails?.itemExpDateTracked != null && taskDetails?.itemExpDateTracked!!.isNotEmpty() &&
                (taskDetails?.itemExpDateTracked == "Y" || taskDetails?.itemExpDateTracked == "1")
            ) {
                val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToExpiryDateTrackFragment()
                getNavigationController().navigate(action)
            } else {
                val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToContainerFragment()
                getNavigationController().navigate(action)
            }
        } else {
            if (isCheckSerial && taskDetails?.itemSerialTracked == SERIAL_TRACK_OUTBOUND_ONLY || taskDetails?.itemSerialTracked == SERIAL_TRACK_FULL_TRACKING) {
                val bundle = bundleOf(
                    "pageType" to "serial"
                )
                getNavigationController().navigate(R.id.action_qtyFragment_to_itemSerialFragment, bundle)
            } else {
                val action = TivoALTYP11QtyFragmentDirections.actionQtyFragmentToContainerFragment()
                getNavigationController().navigate(action)
            }
        }
    }

    private fun getPickedQty():Int{
        return if(binding.etQty.text.toString().trim().isEmpty()){
            viewModel.getQtyEntered()
        }else{
            binding.etQty.text.toString().toInt()+ viewModel.getQtyEntered()
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etQty.setText(scan?.barcode.toString())
                binding.etQty.text?.length?.let {
                    binding.etQty.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Qty field focused")
                    validateQty()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}