package com.fsc.flare.ui.fragment.loadunloadtrailer

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerPatchRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.SendPalletToPRRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.ValidationResult
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.res.CartonDetail
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorResponse
import com.fsc.flare.source.repository.LoadUnloadRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = LoadUnloadViewModel::class.java.simpleName.toString()

@HiltViewModel
class LoadUnloadViewModel @Inject constructor(
    private val loadUnloadRepository: LoadUnloadRepository,
    private var sharedPreferences: SharedPreferences
) : BaseViewModel() {

    private val _dockDoorIdResponse = SingleLiveEvent<Resource<LocationInquiryResponse>>()
    internal val dockDoorIdResponse: LiveData<Resource<LocationInquiryResponse>>
        get() = _dockDoorIdResponse

    private val _shipmentDDResponse = SingleLiveEvent<Resource<ShipmentDockDoorResponse>>()
    internal val shipmentDDResponse: LiveData<Resource<ShipmentDockDoorResponse>>
        get() = _shipmentDDResponse

    private val _loadTrailerResponse = SingleLiveEvent<Resource<LoadTrailerResponse>>()
    internal val loadTrailerResponse: LiveData<Resource<LoadTrailerResponse>>
        get() = _loadTrailerResponse

    private val _unloadTrailerResponse = SingleLiveEvent<Resource<UnloadTrailerResponse>>()
    internal val unloadTrailerResponse: LiveData<Resource<UnloadTrailerResponse>>
        get() = _unloadTrailerResponse

    private val _loadTrailerPatchResponse = SingleLiveEvent<Resource<LoadTrailerResponse>>()
    internal val loadTrailerPatchResponse: LiveData<Resource<LoadTrailerResponse>>
        get() = _loadTrailerPatchResponse

    private val _unLoadTrailerResponse = SingleLiveEvent<Resource<UnloadTrailerResponse>>()
    internal val unLoadTrailerResponse: LiveData<Resource<UnloadTrailerResponse>>
        get() = _unLoadTrailerResponse

    private val _stagingLocationResponse = SingleLiveEvent<Resource<LocationClassRes>>()
    internal val stagingLocationResponse: LiveData<Resource<LocationClassRes>>
        get() = _stagingLocationResponse

    private val _obContainerResponse = SingleLiveEvent<Resource<ValidateCartonHandlerTypeResponse>>()
    internal val obContainerResponse: LiveData<Resource<ValidateCartonHandlerTypeResponse>>
        get() = _obContainerResponse

    private val _sendToPRResponse = SingleLiveEvent<Resource<SendToPRResponse>>()

    internal val sendToPRResponse: LiveData<Resource<SendToPRResponse>>
        get() = _sendToPRResponse

    private val _obCartonRCLockResponse = SingleLiveEvent<Resource<OBCartonRCLockResponse>>()

    internal val obCartonRCLockResponse: LiveData<Resource<OBCartonRCLockResponse>>
        get() = _obCartonRCLockResponse

    private var _dockDoorShipment: ShipmentDockDoorResponse? = null
    internal var dockDoorShipment: ShipmentDockDoorResponse?
        get() = _dockDoorShipment
        set(value) {
            _dockDoorShipment = value
        }

    private var _loadTrailer: LoadTrailerResponse? = null
    internal var loadTrailer: LoadTrailerResponse?
        get() = _loadTrailer
        set(value) {
            _loadTrailer = value
        }

    private var _unloadTrailer: UnloadTrailerResponse? = null
    internal var unloadTrailer: UnloadTrailerResponse?
        get() = _unloadTrailer
        set(value) {
            _unloadTrailer = value
        }

    private var _validationResult: ValidationResult? = null
    internal var validationResult: ValidationResult?
        get() = _validationResult
        set(value) {
            _validationResult = value
        }

    private var _obCartonDetails: OBCartonDetails? = null
    var obCartonDetails: OBCartonDetails?
        get() = _obCartonDetails
        set(value) {
            _obCartonDetails = value
        }

    fun getDockDoorId(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getDockDoorIdRequest: $locBarCode")
        _dockDoorIdResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.getDockDoorId(locBarCode)
        _dockDoorIdResponse.postValue(handleDockDoorIdResponse(response))
    }

    private fun handleDockDoorIdResponse(response: Response<LocationInquiryResponse>): Resource<LocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DockDoorIdResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "DockDoorIdResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validateShipmentDockDoor(shipmentDockDoorRequest: ShipmentDockDoorRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validatedDockDoorRequest: $shipmentDockDoorRequest")
        _shipmentDDResponse.postValue(Resource.Loading())
        val shipmentResponse = loadUnloadRepository.validateShipmentDockDoor(shipmentDockDoorRequest)
        _shipmentDDResponse.postValue(handleShipmentDockDoorResponse(shipmentResponse))
    }

    private fun handleShipmentDockDoorResponse(response: Response<ShipmentDockDoorResponse>): Resource<ShipmentDockDoorResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "shipmentDDResponse success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "shipmentDDResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }


    fun loadTrailer(loadTrailerRequest: LoadTrailerRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "loadTrailerRequest: $loadTrailerRequest")
        _loadTrailerResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.loadTrailer(loadTrailerRequest)
        _loadTrailerResponse.postValue(handleLoadTrailerResponse(response))
    }

    fun unloadTrailer(loadTrailerRequest: LoadTrailerRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "loadTrailerRequest: $loadTrailerRequest")
        _unloadTrailerResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.unloadTrailer(loadTrailerRequest)
        _unloadTrailerResponse.postValue(handleUnloadTrailerResponse(response))
    }

    private fun handleLoadTrailerResponse(response: Response<LoadTrailerResponse>): Resource<LoadTrailerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LoadTrailerResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LoadTrailerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleUnloadTrailerResponse(response: Response<UnloadTrailerResponse>): Resource<UnloadTrailerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "UnloadTrailerResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "UnloadTrailerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun loadTrailerPatch(loadTrailerPatchRequest: LoadTrailerPatchRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "loadTrailerPatchRequest: $loadTrailerPatchRequest")
        _loadTrailerPatchResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.loadTrailerPatch(loadTrailerPatchRequest)
        _loadTrailerPatchResponse.postValue(handleLoadTrailerPatchResponse(response))
    }

    private fun handleLoadTrailerPatchResponse(response: Response<LoadTrailerResponse>): Resource<LoadTrailerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LoadTrailerPatchResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LoadTrailerPatchResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getStagingLocation Request: $locationClassReq")
        _stagingLocationResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.getStagingLocation(locationClassReq)
        _stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "StagingLocation Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun unLoadTrailerPatch(unloadTrailerRequest: UnloadTrailerRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "unLoadTrailerPatchRequest: $unloadTrailerRequest")
        _unLoadTrailerResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.unLoadTrailerPatch(unloadTrailerRequest)
        _unLoadTrailerResponse.postValue(handleUnLoadTrailerPatchResponse(response))
    }

    private fun handleUnLoadTrailerPatchResponse(response: Response<UnloadTrailerResponse>): Resource<UnloadTrailerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "UnLoadTrailerPatchResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "UnLoadTrailerPatchResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun obCartonDetailsRequest(obContainerNumber: String) {
        viewModelScope.launch {
            fetchOBCartonDetails(
                ValidateCartonHandlerTypeRequest(
                    cartonNbr = obContainerNumber,
                    type = OBIBTransformations.LD_TRAIL.type,
                    responseLevel = "SUMMARY"
                )
            )
        }
    }

    private suspend fun fetchOBCartonDetails(validateCartonHandlerTypeRequest: ValidateCartonHandlerTypeRequest) {
        _obContainerResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.fetchObCartonDetails(validateCartonHandlerTypeRequest)
        _obContainerResponse.postValue(handleObCartonDetailsResponse(response))
    }

    private fun handleObCartonDetailsResponse(response: Response<ValidateCartonHandlerTypeResponse>): Resource<ValidateCartonHandlerTypeResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun sendToPRAPIRequest(lockCode: String, cartonNumber: String) {
        viewModelScope.launch {
            val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)

            val sendToPRRequest = SendPalletToPRRequest(
                fcyId = fcyId,
                custId = custId,
                buId = buId,
                emptyList<Int>(),
                palletNumber = cartonNumber,
                reasonCode = lockCode)

            sendToPR(sendToPRRequest)
        }
    }

    private suspend fun sendToPR(sendToPRRequest: SendPalletToPRRequest) {
        _sendToPRResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.sendToPR(sendToPRRequest)
        _sendToPRResponse.postValue(handleSendToPRResponse(response))
    }

    private fun handleSendToPRResponse(response: Response<SendToPRResponse>): Resource<SendToPRResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun viewRecallContainersAPIRequest(cartonNumber: String) {
        viewModelScope.launch {
            fetchRCLockOBCartonDetails(
                OBCartonRCLockRequest(
                    palletNbr = cartonNumber,
                    lock = "RC"
                )
            )
        }
    }

    private suspend fun fetchRCLockOBCartonDetails(obCartonRCLockRequest: OBCartonRCLockRequest) {
        _obCartonRCLockResponse.postValue(Resource.Loading())
        val response = loadUnloadRepository.fetchRecallLockOBContainerDetails(obCartonRCLockRequest)
        _obCartonRCLockResponse.postValue(handleRCLockObCartonDetailsResponse(response))
    }

    private fun handleRCLockObCartonDetailsResponse(response: Response<OBCartonRCLockResponse>): Resource<OBCartonRCLockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            return Resource.Error(errorResponse)
        }
        return null
    }

    override fun onCleared() {
        super.onCleared()
    }
}