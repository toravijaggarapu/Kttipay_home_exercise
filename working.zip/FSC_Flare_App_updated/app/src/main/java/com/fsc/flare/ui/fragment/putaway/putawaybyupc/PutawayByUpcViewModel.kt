package com.fsc.flare.ui.fragment.putaway.putawaybyupc

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.putawayreverse.ContainerRequest
import com.fsc.flare.source.data.dto.putawayreverse.ContainerResponse
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayRequest
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayResponse
import com.fsc.flare.source.data.dto.putawayreverse.Putaway
import com.fsc.flare.source.data.dto.putawayreverse.PutawayContainerReq
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.PutawayRequest
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.UpcItemSlpData
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcRequest
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcResponse
import com.fsc.flare.source.repository.PutAwayRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = PutawayByUpcViewModel::class.java.simpleName.toString()
@HiltViewModel
class PutawayByUpcViewModel @Inject constructor(
    private val putAwayRepository: PutAwayRepository,
    private var sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {

    private val dataSource: String = "RF"

    private val _validateupcresponse = SingleLiveEvent<Resource<ValidateUpcResponse>>()

    val validateupcresponse: LiveData<Resource<ValidateUpcResponse>>
        get() = _validateupcresponse

    private val _validatecontainerresponse = SingleLiveEvent<Resource<ContainerResponse>>()

    val validatecontainerresponse: LiveData<Resource<ContainerResponse>>
        get() = _validatecontainerresponse

    private val _validateputawayresponse = SingleLiveEvent<Resource<DoPutawayResponse>>()

    val validateputawayresponse: LiveData<Resource<DoPutawayResponse>>
        get() = _validateputawayresponse

    lateinit var selectedItem: UpcItemSlpData

    fun validateUpcRequest(upcText: String) {
        viewModelScope.launch(dispatcher) {
            validateUpc(
                ValidateUpcRequest(
                    dataSource = dataSource,
                    mixedSbPutaway = false,
                    upcPutaway = true,
                    putaway = PutawayRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                        destination = "",
                        locId = "",
                        retType = 0,
                        upc = upcText,
                        usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                        whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString()
                    )
                )
            )
        }
    }

    private suspend fun validateUpc(validateUpcRequest: ValidateUpcRequest) {
        _validateupcresponse.postValue(Resource.Loading())
        val response = putAwayRepository.validateUpc(validateUpcRequest = validateUpcRequest)
        _validateupcresponse.postValue(handleValidateUpcResponse(response))
    }

    private fun handleValidateUpcResponse(response: Response<ValidateUpcResponse>): Resource<ValidateUpcResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateUpcResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ValidateUpcResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validateContainerRequest(containerText: String) {
        viewModelScope.launch(dispatcher) {
            validateContainer(
                ContainerRequest(
                    dataSource = dataSource,
                    putaway = PutawayContainerReq(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                            .toString(),
                        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        destination = containerText,
                        usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                        whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                    )
                )
            )
        }
    }

    private suspend fun validateContainer(containerRequest: ContainerRequest) {
        _validatecontainerresponse.postValue(Resource.Loading())
        val response = putAwayRepository.validateContainer(containerRequest = containerRequest)
        _validatecontainerresponse.postValue(handleValidateContainerResponse(response))
    }

    fun handleValidateContainerResponse(response: Response<ContainerResponse>): Resource<ContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun validatePutawayRequest(upcText: String, containerText: String, locationText: String) {
        viewModelScope.launch(dispatcher) {
            validatePutaway(
                DoPutawayRequest(
                    dataSource = dataSource,
                    putaway = Putaway(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                            .toString(),
                        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        destination = containerText,
                        locId = locationText,
                        source = selectedItem.slp,
                        usrId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                        whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        retType = 0,
                        upc = upcText
                    ),
                    mixedSbPutaway = false,
                    upcPutaway = true
                )
            )
        }
    }

    private suspend fun validatePutaway(doPutawayRequest: DoPutawayRequest) {
        _validateputawayresponse.postValue(Resource.Loading())
        val response = putAwayRepository.doPutaway(doPutawayRequest)
        _validateputawayresponse.postValue(handleValidatePutawayResponse(response))
    }

    private fun handleValidatePutawayResponse(response: Response<DoPutawayResponse>): Resource<DoPutawayResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Putaway Response Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Putaway Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

}