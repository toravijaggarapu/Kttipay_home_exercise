package com.fsc.flare.database.typeconvertors


import androidx.room.TypeConverter
import java.util.Calendar
import java.util.Date

class DateTimeConverter {

    @TypeConverter
    fun fromTimeStamp(value: Long?): Date = Date(value ?: Calendar.getInstance().time.time)

    @TypeConverter
    fun dateToTimeStamp(date: Date?): Long = date?.time ?: Calendar.getInstance().time.time

}