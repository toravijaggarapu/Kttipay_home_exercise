package com.fsc.flare.ui.fragment.palletrepack

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRepackPalletNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackData
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletRepackPalletNumber"

/**
 * A simple PalletRepackPalletNumber
 */
@AndroidEntryPoint
class PalletRepackPalletNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletRepackViewModel by activityViewModels()
    private lateinit var binding: FragmentRepackPalletNumberBinding
    lateinit var cb1: CustomVisibilityCallback


    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        viewModel.setDataToDefault()
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRepackPalletNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (viewModel.getMPRTransactionParamData() != null) {
            if (viewModel.getTransactionParamByTransCode("AGPN"))
                binding.btnNewPallet.visibility = View.VISIBLE
            else
                binding.btnNewPallet.visibility = View.GONE
        }
        binding.palletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.palletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.palletNumber)
                FlareLog.i(TAG, "Container field focused")
                validatePallet()
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            getNewPalletDetail()
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    /**
     * method to generate pallet from API
     */
    private fun getNewPalletDetail() {
        //Call new pallet API.
        viewModel.generatePalletCaseNumber(viewModel.palletDetailKey)
    }

    /**
     * method to validate pallet from API
     */
    private fun validatePallet() {
        if(binding.palletNumber.text.toString().trim().isNotEmpty()) {
            val containerType = viewModel.validateContainerType(sharedPreferences, Constants.TRANSFER_TYPE_PALLET)
            val palletNumber = binding.palletNumber.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.palletNumberResponse.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                val palletData =
                    PalletRepackData(binding.palletNumber.text.toString(), "", 0)
                viewModel.setPalletData(palletData)
                //Get pallet detail.
                viewModel.getPalletDetail(binding.palletNumber.text.toString(), "Y")
            }
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            if (generatePalletCaseNumberResponse.numbers[0].type.equals(Constants.TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                val palletData = PalletRepackData(
                                    generatePalletCaseNumberResponse.numbers[0].value,
                                    "",
                                    0
                                )
                                viewModel.setPalletData(palletData)
                                navigateContainerView()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.palletNumber.requestFocus()
                        binding.palletNumberResponse.text = message
                        binding.palletNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.palletNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.palletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { palletResponse ->
                        if (palletResponse!!.container.isNotEmpty()) {
                            binding.palletNumberResponse.text = getString(R.string.pallet_already_exist)
                        } else {
                            if(binding.palletNumber.text.toString().trim().isNotEmpty()) {
                                val palletData = PalletRepackData(
                                    binding.palletNumber.text.toString().trim(), "", 0
                                )
                                viewModel.setPalletData(palletData)
                                navigateContainerView()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        binding.palletNumber.requestFocus()
                        binding.palletNumberResponse.text = message
                        binding.palletNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.palletNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateContainerView() {
        binding.palletNumber.text = null
        val action = PalletRepackPalletNumberFragmentDirections.actionPalletRepackPalletNumberFragmentToPalletRepackContainerFragment()
        getNavigationController().navigate(action)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.palletNumber.setText(scan?.barcode.toString())
                binding.palletNumber.text?.length?.let {
                    binding.palletNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container field focused")
                    validatePallet()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}