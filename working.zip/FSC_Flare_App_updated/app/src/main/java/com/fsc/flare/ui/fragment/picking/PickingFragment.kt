package com.fsc.flare.ui.fragment.picking

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickingBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.picking.PickLocationTo
import com.fsc.flare.source.data.dto.picking.PickingContainerId
import com.fsc.flare.source.data.dto.picking.PickingLocation
import com.fsc.flare.source.data.dto.picking.PickingLocationToRequest
import com.fsc.flare.source.data.dto.picking.PickingSubmitData
import com.fsc.flare.source.data.dto.picking.PickingSubmitRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateBl
import com.fsc.flare.source.data.dto.picking.PickingValidateBlRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateContainerIdRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateLocationRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickingFragment"

/**
 * A simple [PickingFragment] class
 */
@AndroidEntryPoint
class PickingFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickingViewModel by viewModels()
    private lateinit var binding: FragmentPickingBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPickingBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        //WeightReq
        viewModel.getWeightReq()

        binding.etBL.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtBLResponse.text = ""
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtLocationResponse.text = ""

            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtContainerRes.text = ""

            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
        binding.etToLoc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtToLocRes.text = ""
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        /* binding.submitPick.setOnClickListener {
             validatePickSubmit()
         }*/
        //validateBl
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etBL.isFocused && !binding.etBL.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "BL field focused")
                        validateBL()
                    } else if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                        //validateLocation
                        FlareLog.i(TAG, "Location field focused")
                        validateLocation()
                    } else if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                        //validateContainerId
                        FlareLog.i(TAG, "Container field focused")
                        validateContainer()
                    } else if (binding.etToLoc.isFocused && !binding.etToLoc.text.isNullOrEmpty()) {
                        //validateContainerId
                        FlareLog.i(TAG, "ToLocation field focused")
                        validateToLocation()
                    } else if (binding.etWeight.isFocused) {
                        FlareLog.i(TAG, "PickSubmit/Weight field focused")
                        validatePickSubmit()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etBL.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etBL)
                FlareLog.i(TAG, "BL field focused")
                validateBL()
            }
            false
        }

        binding.etLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLocation)
                FlareLog.i(TAG, "etLocation field focused")
                validateLocation()
            }
            false
        }

        binding.etContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etContainer)
                FlareLog.i(TAG, "etContainer field focused")
                validateContainer()
            }
            false
        }

        binding.etToLoc.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etToLoc)
                FlareLog.i(TAG, "etToLoc field focused")
                validateToLocation()
            }
            false
        }
    }

    private fun validatePickSubmit() {
        if (binding.etBL.text.isNullOrEmpty()) {
            showErrorSnackBar(getString(R.string.lbl_enter_bl))
            binding.etBL.requestFocus()
        } else if (binding.etLocation.text.isNullOrEmpty()) {
            showErrorSnackBar(getString(R.string.lbl_enter_loc))
            binding.etLocation.requestFocus()
        } else if (binding.etContainer.text.isNullOrEmpty()) {
            showErrorSnackBar(getString(R.string.lbl_enter_cont))
            binding.etContainer.requestFocus()
        } else {
            viewModel.isValidPickSubmit(
                PickingSubmitRequest(
                    "RF",
                    PickingSubmitData(
                        binding.etBL.text.toString(),
                        binding.etContainer.text.toString(),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        binding.etLocation.text.toString(),
                        true,
                        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
                        sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        if (binding.etWeight.text.isNullOrEmpty()) 0 else Integer.parseInt(binding.etWeight.text.toString()),
                        binding.etToLoc.text.toString(),
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                        grpPutawayReqd = true
                    )
                )
            )
        }
    }

    private fun validateContainer() {
        viewModel.isValidContainerId(
            PickingValidateContainerIdRequest(
                "RF",
                PickingContainerId(
                    binding.etBL.text.toString(),
                    binding.etContainer.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.etLocation.text.toString(),
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_SUBMIT, false),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                )
            )
        )
    }

    private fun validateLocation() {
        viewModel.isValidLocation(
            PickingValidateLocationRequest(
                "RF",
                PickingLocation(
                    binding.etBL.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.etLocation.text.toString(),
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_SUBMIT, false),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                )
            )
        )
    }

    private fun validateToLocation() {
        viewModel.isValidLocationTo(
            PickingLocationToRequest(
                "RF",
                PickLocationTo(
                    binding.etBL.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    binding.etContainer.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.etLocation.text.toString(),
                    binding.etToLoc.text.toString(),
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_SUBMIT, false),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    private fun validateBL() {
        viewModel.isValidBl(
            PickingValidateBlRequest(
                "RF",
                PickingValidateBl(
                    binding.etBL.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_SUBMIT, false),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
                    sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                )
            )
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun subscribeObservers() {
        viewModel.pickingWeightResponse.observe(viewLifecycleOwner) { response ->

            when (response) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "pickingWeight Success: ${response.data}")
                    hideProgressBar()
                    if (response.data != null) {
                        sharedPreferences.edit().apply {
                            putBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, response.data.pick.weightReq)
                            putBoolean(PreferenceKeys.PICKING_SUBMIT, response.data.pick.pickSubmit)
                            putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                            putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                        }.apply()
                    }
                    if (sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false)) {
                        binding.grpWeight.visibility = View.VISIBLE
                    }
                    binding.etBL.requestFocus()
                    enableDisableText(bl = true, loc = false, cont = false, toLoc = false, wt = false)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingWeight Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
        viewModel.pickingValidateBlResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "pickingValidate response: $response")
                    hideProgressBar()
                    if (response.data != null) {
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "pickingValidate error: ${response.data.statusHandler.message}")
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                binding.txtBLResponse.text = response.data.statusHandler.message
                                binding.etBL.selectAll()
                                enableDisableText(bl = true, loc = false, cont = false, toLoc = false, wt = false)
                                showSoftKeyBoard(fragmentContext, binding.etBL)
                            }
                            "200" -> {
                                FlareLog.i(TAG, "pickingValidate success: ${response.data}")
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                binding.txtBLResponse.text = null
                                enableDisableText(bl = true, loc = true, cont = false, toLoc = false, wt = false)
                                binding.etLocation.requestFocus()
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingValidate Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
        viewModel.pickingValidateLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    FlareLog.i(TAG, "pickingValidateLocation Response: $response")
                    if (response.data != null) {
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "pickingValidateLocation error: ${response.data.statusHandler.message}")
                                showSoftKeyBoard(fragmentContext, binding.etLocation)
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = false, toLoc = false, wt = false)
                                binding.txtLocationResponse.text = response.data.statusHandler.message
                                binding.etLocation.selectAll()
                                binding.txtBLResponse.text = null
                            }
                            "200" -> {
                                FlareLog.i(TAG, "pickingValidateLocation success: ${response.data}")
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = true, toLoc = false, wt = false)
                                binding.txtBLResponse.text = null
                                binding.txtLocationResponse.text = null
                                binding.etContainer.requestFocus()
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingValidateLocation Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
        viewModel.pickingValidateContainerIdResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    FlareLog.i(TAG, "pickingValidateContainerId Response: $response")
                    if (response.data != null) {
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "pickingValidateContainerId error: ${response.data.statusHandler.message}")
                                showSoftKeyBoard(fragmentContext, binding.etContainer)
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = true, toLoc = false, wt = false)
                                binding.txtContainerRes.text = response.data.statusHandler.message
                                binding.etContainer.selectAll()
                                binding.txtBLResponse.text = null
                                binding.txtLocationResponse.text = null
                            }
                            "200" -> {
                                FlareLog.i(TAG, "pickingValidateContainerId success: ${response.data}")
                                sharedPreferences.edit().apply {
                                    putString(PreferenceKeys.PICKING_WEIGHT, response.data.pick.weight)
                                    putBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, response.data.pick.weightReq)
                                    putBoolean(PreferenceKeys.PICKING_SUBMIT, response.data.pick.pickSubmit)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = true, toLoc = true, wt = false)
                                binding.etToLoc.requestFocus()
                                binding.txtBLResponse.text = null
                                binding.txtLocationResponse.text = null
                                binding.txtContainerRes.text = null
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingValidateContainerId Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
        // Picking Submit
        viewModel.pickingValidateSubmitResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    FlareLog.i(TAG, "pickingValidateSubmit Response: $response")
                    if (response.data != null) {
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "pickingValidateSubmit error: ${response.data.statusHandler.error}")
                                if (response.data.statusHandler.error != null) {
                                    showErrorSnackBar(response.data.statusHandler.error)
                                }
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                            }
                            "200" -> {
                                FlareLog.i(TAG, "pickingValidateSubmit success: ${response.data}")
                                showSuccessSnackBar(response.data.statusHandler.message)
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()

                                if (sharedPreferences.getBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, false)) {
                                    binding.etContainer.text = null
                                    binding.etToLoc.text = null
                                    binding.etWeight.text = null
                                    binding.etContainer.requestFocus()
                                } else if (sharedPreferences.getBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, false)) {
                                    binding.etLocation.text = null
                                    binding.etContainer.text = null
                                    binding.etToLoc.text = null
                                    binding.etWeight.text = null
                                    binding.etLocation.requestFocus()
                                } else {
                                    binding.etBL.text = null
                                    binding.etLocation.text = null
                                    binding.etContainer.text = null
                                    binding.etToLoc.text = null
                                    binding.etWeight.text = null
                                    binding.etBL.requestFocus()
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingValidateSubmit Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }
        viewModel.pickingValidateLocationToResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    FlareLog.i(TAG, "pickingValidateLocationTo Response: $response")
                    if (response.data != null) {
                        when (response.data.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "pickingValidateLocationTo error: ${response.data.statusHandler.message}")
                                showSoftKeyBoard(fragmentContext, binding.etLocation)
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = true, toLoc = true, wt = false)
                                binding.txtToLocRes.text = response.data.statusHandler.message
                                binding.etToLoc.selectAll()
                            }
                            "200" -> {
                                FlareLog.i(TAG, "pickingValidateLocationTo success: ${response.data}")
                                sharedPreferences.edit().apply {
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_SAME_LOCATION, response.data.cntsInSameLocation)
                                    putBoolean(PreferenceKeys.PICKING_CNTIN_OTHER_LOCATION, response.data.cntInOtherLocations)
                                }.apply()
                                enableDisableText(bl = true, loc = true, cont = true, toLoc = true, wt = true)
                                binding.txtBLResponse.text = null
                                binding.txtLocationResponse.text = null
                                binding.txtContainerRes.text = null
                                binding.txtToLocRes.text = null
                                binding.etWeight.requestFocus()
                                if (!sharedPreferences.getBoolean(PreferenceKeys.PICKING_WEIGHT_REQ, false)) {
                                    validatePickSubmit()
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "pickingValidateLocationTo Error: $message")
                        showErrorSnackBar(message)
                    }
                }
            }
        }

        viewModel.noNetworkUpdate.observe(viewLifecycleOwner) { response ->
            if (response != null) {
                hideProgressBar()
                showErrorSnackBar(resources.getString(R.string.network_connect_failure))
            }
        }
    }

    private fun enableDisableText(bl: Boolean, loc: Boolean, cont: Boolean, toLoc: Boolean, wt: Boolean) {
        binding.etBL.isEnabled = bl
        binding.etWeight.isEnabled = wt
        binding.etContainer.isEnabled = cont
        binding.etLocation.isEnabled = loc
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            binding.etBL.isFocused -> {
                binding.etBL.setText(scan?.barcode.toString())
                binding.etBL.text?.length?.let {
                    binding.etBL.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "BL field focused")
                    validateBL()
                }
            }

            binding.etLocation.isFocused -> {
                binding.etLocation.setText(scan?.barcode.toString())
                binding.etLocation.text?.length?.let {
                    binding.etLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Location field focused")
                    validateLocation()
                }
            }
            binding.etContainer.isFocused -> {
                binding.etContainer.setText(scan?.barcode.toString())
                binding.etContainer.text?.length?.let {
                    binding.etContainer.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "com.fsc.flare.source.data.dto.inventoryadjustment.res.Container field focused")
                    validateContainer()
                }
            }
            binding.etToLoc.isFocused -> {
                binding.etContainer.setText(scan?.barcode.toString())
                binding.etContainer.text?.length?.let {
                    binding.etContainer.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ToLocation field focused")
                    validateToLocation()
                }
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}