package com.fsc.flare.di

import android.accounts.AccountManager
import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import androidx.work.WorkManager
import com.fedex.services.blazar.Scanner
import com.fsc.flare.FlareApplication
import com.fsc.flare.transactiontracker.FSCTransactionTracker
import com.fsc.flare.utils.DateTimeTypeConverter
import com.fsc.flare.utils.EmptyStringToDoubleTypeAdapter
import com.fsc.flare.utils.FlareSecurityManager
import com.fsc.flare.utils.LocalTimeTypeConverter
import com.fsc.flare.utils.PreferenceKeys
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import org.joda.time.DateTime
import org.joda.time.LocalTime
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class AppModule {

    @Singleton
    @Provides
    fun provideSharedPreferences(application: Application): SharedPreferences {
        return application.getSharedPreferences(PreferenceKeys.APP_PREFERENCES, Context.MODE_PRIVATE)
    }

    @Singleton
    @Provides
    fun provideResources(application: Application): Resources? {
        return application.resources
    }


    @Singleton
    @Provides
    fun provideScanner(): Scanner? {
        return FlareApplication.getScanner()
    }

    @Singleton
    @Provides
    fun provideFlareSecurityManager(): FlareSecurityManager {
        return FlareSecurityManager()
    }

    @Provides
    @Singleton
    fun provideAccountManager(application: Application): AccountManager {
        return AccountManager.get(application)
    }

    @Singleton
    @Provides
    fun provideGson(): Gson {
        return GsonBuilder()
            .registerTypeAdapter(DateTime::class.java, DateTimeTypeConverter())
            .registerTypeAdapter(LocalTime::class.java, LocalTimeTypeConverter())
            .registerTypeAdapter(Double::class.javaPrimitiveType, EmptyStringToDoubleTypeAdapter())
            .excludeFieldsWithoutExposeAnnotation()
            .create()
    }

    @Provides
    @Singleton
    @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

    @Provides
    @Singleton
    fun provideWorkManager(context: Application): WorkManager {
        return WorkManager.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideTransactionTracker(): FSCTransactionTracker {
        return FSCTransactionTracker()
    }

}