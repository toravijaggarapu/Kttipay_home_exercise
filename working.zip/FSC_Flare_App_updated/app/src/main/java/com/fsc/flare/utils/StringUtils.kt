package com.fsc.flare.utils

import android.content.Context
import com.fsc.flare.R
import okhttp3.RequestBody
import okio.Buffer
import java.io.IOException

object StringUtils {

    fun langConvertedName(
        menuID: String?,
        originalMenuName: String?,
        context: Context?
    ): String? {
        val labelIdentifier = "menu_$menuID"
        return try {
            val resourceField = R.string::class.java.getDeclaredField(labelIdentifier)
            val resourceId = resourceField.getInt(resourceField)
            context?.getString(resourceId)
        } catch (e: Exception) {
            originalMenuName
        }
    }

    fun bodyToString(request: RequestBody?): String {
        return try {
            val buffer = Buffer()
            request?.let {
                it.writeTo(buffer)
                buffer.readUtf8()
            } ?: ""
        } catch (e: IOException) {
            "did not work"
        }
    }
}
