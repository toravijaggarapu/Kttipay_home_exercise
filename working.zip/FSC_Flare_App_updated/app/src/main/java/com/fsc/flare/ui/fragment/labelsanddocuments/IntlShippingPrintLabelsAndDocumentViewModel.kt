package com.fsc.flare.ui.fragment.labelsanddocuments

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.labelsanddocuments.Document
import com.fsc.flare.source.data.dto.labelsanddocuments.DocumentOption
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentDocumentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputResponse
import com.fsc.flare.source.repository.LabelsAndDocumentsRepository
import com.fsc.flare.source.repository.StagingRepository
import com.fsc.flare.utils.IntShipDocumentsAPI.COUNTRY_CODE
import com.fsc.flare.utils.IntShipDocumentsAPI.ENTITY_ID
import com.fsc.flare.utils.IntShipDocumentsAPI.ENTITY_NUMBER
import com.fsc.flare.utils.IntShipDocumentsAPI.ENTITY_TYPE
import com.fsc.flare.utils.IntShipDocumentsAPI.ENTITY_TYPE_VALUE
import com.fsc.flare.utils.IntShipDocumentsAPI.IS_REPRINT
import com.fsc.flare.utils.IntShipDocumentsAPI.ROUTE_TO
import com.fsc.flare.utils.PreferenceKeys
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val DOC_TYPE = "DOC"
private const val ORDER= "Order"

@HiltViewModel
class IntlShippingPrintLabelsAndDocumentViewModel @Inject constructor(
    private val labelsAndDocumentsRepository: LabelsAndDocumentsRepository,
    private val stagingRepository: StagingRepository,
    private val sharedPreference: SharedPreferences
) : BaseViewModel() {

    private val _screenState = MutableStateFlow<ShippingDocumentsScreenState?>(null)
    val screenState = _screenState.asStateFlow()

    private val documentLookups by lazy {
        val lookupString = sharedPreference.getString(PreferenceKeys.DOCUMENTS_LOOKUP_MAP, "")
        takeIf { lookupString?.isNotEmpty() == true }?.let {
            val typeToken = object : TypeToken<HashMap<String, String>>() {}.type
            Gson().fromJson(lookupString, typeToken) as HashMap<String, String>
        } ?: mapOf()
    }

    fun getInternationalShippingDocuments(
        scope: CoroutineScope = viewModelScope,
        inputResponse: ValidateInputResponse
    ) {
        scope.launch {
            _screenState.emit(ShippingDocumentsScreenState.ShowLoading)

            val requestParams = HashMap<String, String>()
            requestParams[ENTITY_TYPE] = ENTITY_TYPE_VALUE
            requestParams[ENTITY_NUMBER] = inputResponse.orderNumber
            requestParams[ENTITY_ID] = "${inputResponse.orderId}"
            requestParams[COUNTRY_CODE] = inputResponse.countryCode.orEmpty()
            requestParams[ROUTE_TO] = inputResponse.routeTo.orEmpty()
            requestParams[IS_REPRINT] = "true"

            val response = labelsAndDocumentsRepository.getInternationalShipmentDocuments(requestParams)
            _screenState.emit(ShippingDocumentsScreenState.HideLoading)

            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { responseData ->
                responseData.documentsData?.documents?.takeIf { it.isNotEmpty() }?.let {
                    _screenState.emit(ShippingDocumentsScreenState.ShowDocuments(
                        it.map { document ->
                            DocumentOption(
                                name = documentLookups.getOrDefault(document.docType.orEmpty(), document.docType.orEmpty()),
                                docId = document.docType.orEmpty(),
                                isChecked = (document.numOfTimesPrinted ?: 0) > 0
                            )
                        }
                    ))
                } ?: run {
                    _screenState.emit(ShippingDocumentsScreenState.NoDocumentsFound)
                }
            } ?: run {
                val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
                _screenState.emit(ShippingDocumentsScreenState.ShowDocAPIError(errorResponse))
            }
        }
    }

    fun printSelectedDocuments(
        scope: CoroutineScope = viewModelScope,
        printInput: ValidateInputResponse?,
        printerConfigs: List<PrinterConfig>?,
        selectedDocuments: List<Document>
    ) {
        scope.launch {
            _screenState.emit(ShippingDocumentsScreenState.ShowLoading)
            val lookupResponse = labelsAndDocumentsRepository.getPrinterName()
            lookupResponse.takeIf {
                it.isSuccessful && it.body() != null && printInput != null &&
                        printerConfigs?.isNotEmpty() == true }?.body()?.let { responseData ->

                var isPrintInitiated = false

                responseData.lookups.firstOrNull()?.lookupCodes?.forEach { lookUpCode ->
                    printerConfigs?.forEach { printerConfig ->
                        if (lookUpCode.lookupCode == printerConfig.printerName &&
                            printerConfig.printerType == DOC_TYPE &&
                            sharedPreference.getString(PreferenceKeys.LD_PRINT_ENTITY, null) == ORDER
                        ) {
                            isPrintInitiated = true

                            val request = PrintShipmentDocumentRequest(
                                buId = sharedPreference.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                custId = sharedPreference.getInt(PreferenceKeys.CUST_ID, -1),
                                fcyId = sharedPreference.getInt(PreferenceKeys.FACILITY_ID, -1),
                                emailGroup = sharedPreference.getString(PreferenceKeys.FEDEX_EMAIL, ""),
                                orderId = printInput?.orderId ?: 0,
                                documentPrinterName = lookUpCode.lookupCodeDescription,
                                packingSlipType = printInput?.packingSlipType.orEmpty(),
                                printRequestor = printerConfig.requestor,
                                documentsList = selectedDocuments.map { it.docType.orEmpty() }
                            )

                            val printResponse = stagingRepository.printInternationalShipmentDocuments(request)
                            _screenState.emit(ShippingDocumentsScreenState.HideLoading)

                            printResponse.takeIf { it.isSuccessful && it.body() != null }?.body()
                                ?.let { responseResults ->
                                    if (responseResults.status == true) {
                                        _screenState.emit(ShippingDocumentsScreenState.PrintSuccess)
                                    } else {
                                        _screenState.emit(ShippingDocumentsScreenState.ShowPrintAPIError(responseResults.errorDescription))
                                    }
                                } ?: run {
                                val errorResponse = handleForwardErrorResponse(
                                    printResponse.code(),
                                    printResponse.errorBody(),
                                    printResponse.message()
                                )
                                _screenState.emit(ShippingDocumentsScreenState.ShowPrintAPIError(errorResponse))
                            }
                        }
                    }
                }
                if (!isPrintInitiated) {
                    _screenState.emit(ShippingDocumentsScreenState.HideLoading)
                    _screenState.emit(ShippingDocumentsScreenState.ShowPrintAPIError("Printer not found"))
                }
            } ?: run {
                _screenState.emit(ShippingDocumentsScreenState.HideLoading)
                val errorResponse = handleForwardErrorResponse(lookupResponse.code(), lookupResponse.errorBody(), lookupResponse.message())
                _screenState.emit(ShippingDocumentsScreenState.ShowPrintAPIError(errorResponse))
            }
        }
    }

    fun clearData() {
        viewModelScope.launch {
            _screenState.emit(null)
        }
    }
}

sealed class ShippingDocumentsScreenState {
    data object ShowLoading : ShippingDocumentsScreenState()
    data object HideLoading : ShippingDocumentsScreenState()
    data object NoDocumentsFound : ShippingDocumentsScreenState()
    data object PrintSuccess : ShippingDocumentsScreenState()
    data class ShowDocAPIError(val message: String) : ShippingDocumentsScreenState()
    data class ShowPrintAPIError(val message: String? = null) : ShippingDocumentsScreenState()
    data class ShowDocuments(val documents: List<DocumentOption>) : ShippingDocumentsScreenState()
}