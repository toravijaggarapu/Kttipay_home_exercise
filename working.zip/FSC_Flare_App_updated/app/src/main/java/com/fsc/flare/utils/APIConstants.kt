package com.fsc.flare.utils

object GroupTaskAPI {
    const val CARTON_NUMBER = "cartNbr"
    const val CARTON_ID = "cartId"
    const val ALLOCATION_TYPE = "allocationType"
    const val CASE_PICK_WITH_PALLET = "casePickWithPallet"
    const val SKIP_CURRENT_GROUP = "skipCurrentGrp"
    const val SKIP_TASK_GRP_SEQ_NBR = "skipTaskGrpSeqNbr"
    const val SHIPMENT_NUMBER = "shipmentNbr"
    const val SHIP_STOP_SEQUENCE = "shipStopSeq"
    const val LOCATION_ID = "locationId"
    const val TASK_GROUP = "taskGroup"

    const val ALLOCATION_TYPE_VALUE = "20"
    const val TASK_GROUP_VALUE = "PCL"
}

object IntShipDocumentsAPI {
    const val ENTITY_TYPE = "entityType"
    const val ENTITY_NUMBER = "entityNumber"
    const val ENTITY_ID = "entityId"
    const val COUNTRY_CODE = "countryCode"
    const val ROUTE_TO = "routeTo"
    const val IS_REPRINT = "isReprint"

    const val ENTITY_TYPE_VALUE = "order"
}