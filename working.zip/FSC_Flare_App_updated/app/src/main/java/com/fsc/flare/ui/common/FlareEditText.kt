package com.fsc.flare.ui.common

import android.content.Context
import android.text.InputFilter
import android.util.AttributeSet
import com.google.android.material.textfield.TextInputEditText
import kotlin.collections.filterNotNull
import kotlin.collections.toTypedArray

open class FlareEditText: TextInputEditText {

    constructor(context: Context) : super(context) {
        init(context, null)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context, attrs)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) :
            super(context, attrs, defStyleAttr) {
        init(context, attrs)
    }

    private fun init(context: Context, attrs: AttributeSet?) {

        val allCapsFilter = FlareCommonInputFilter()

        // Get the existing filters
        val existingFilters = filters

        // Create a new array with the Flare filter added
        val newFilters = arrayOfNulls<InputFilter>(existingFilters.size + 1)
        System.arraycopy(existingFilters, 0, newFilters, 0, existingFilters.size)
        newFilters[existingFilters.size] = allCapsFilter

        // Apply the new filters`
        filters = newFilters.filterNotNull().toTypedArray()
    }
}