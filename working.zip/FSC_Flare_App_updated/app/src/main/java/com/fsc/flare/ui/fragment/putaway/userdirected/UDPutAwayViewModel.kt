package com.fsc.flare.ui.fragment.putaway.userdirected

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.Location
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.ItemSlotting
import com.fsc.flare.source.data.dto.userdirectedputaway.PutawayRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitResponse
import com.fsc.flare.source.repository.UDPutAwayRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class UDPutAwayViewModel @Inject constructor(
    private val udPutawayRepository: UDPutAwayRepository,
    private var sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
    ) : BaseViewModel() {

    private val _containerResponse = SingleLiveEvent<Resource<UserDirectedPutawayContainerResponse>>()
    val containerResponse: LiveData<Resource<UserDirectedPutawayContainerResponse>>
        get() = _containerResponse

    private val _locationResponse = SingleLiveEvent<Resource<LocationClassRes>>()
    val locationResponse: LiveData<Resource<LocationClassRes>>
        get() = _locationResponse

    private val _submitUDPutawayResponse = SingleLiveEvent<Resource<UserDirectedPutawaySubmitResponse>>()
    val submitUDPutawayResponse: LiveData<Resource<UserDirectedPutawaySubmitResponse>>
        get() = _submitUDPutawayResponse

    private val _transactionParamResponse = SingleLiveEvent<Resource<TransactionParamResponse>>()
    val transactionParamResponse: LiveData<Resource<TransactionParamResponse>>
        get() = _transactionParamResponse

    private val _containerInfoResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val containerInfoResponse: LiveData<Resource<InventoryContainerResponse>>
        get() = _containerInfoResponse

    private lateinit var _containerData: UserDirectedPutawayContainerResponse

    private lateinit var _locationData: Location

    private val isolatedLocationClass = "IL"

    fun setContainerData(container: UserDirectedPutawayContainerResponse) {
        _containerData = container
    }

    fun getContainerData(): UserDirectedPutawayContainerResponse = _containerData

    fun setLocationData(location: Location) {
        _locationData = location
    }

    fun getLocationData(): Location = _locationData

    var isPutawayByPallet = false
    var isRCLockCalled = false
    var isQHLockOnForUserDirectedPutaway = false


    /**
     * Function to prepare Api request for Container Data
     */
    fun prepareContainerRequest(containerText: String, putawayType: String) {
        viewModelScope.launch(dispatcher) {
            val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
            val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
            val containerType = if (isPutawayByPallet) "Pallet" else "Case"
            val includeCCLocation = if (sharedPreferences.getBoolean(
                    PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                    false
                )
            ) "Y" else "N"

            getContainer(
                UserDirectedPutawayContainerRequest(
                    custId = custId,
                    buId = buId,
                    fcyId = fcyId,
                    containerNumber =  containerInfoResponse.value?.data?.container?.get(0)
                        ?.getContainerNumber(isPutawayByPallet, containerText) ?: "",
                    putAwayType = putawayType,
                    containerType = containerType,
                    includeCCLocation = includeCCLocation,
                    recallLockExists = isRCLockCalled
                )
            )
        }
    }

    /**
     * Function to get container details
     */
    private suspend fun getContainer(userDirectedPutawayContainerRequest: UserDirectedPutawayContainerRequest) {
        _containerResponse.postValue(Resource.Loading())
        val response = udPutawayRepository.validateContainer(userDirectedPutawayContainerRequest)
        _containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * Function to handle container response
     */
    private fun handleContainerResponse(response: Response<UserDirectedPutawayContainerResponse>): Resource<UserDirectedPutawayContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare location api request
     */
    fun prepareLocationRequest(locationText: String) {
        viewModelScope.launch(dispatcher) {
            validateLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    locationText,
                    if (isRCLockCalled) isolatedLocationClass else ""
                )
            )
        }
    }

    /**
     * Function to get location details
     */
    private suspend fun validateLocation(locationClassReq: LocationClassReq) {
        _locationResponse.postValue(Resource.Loading())
        val response = udPutawayRepository.validateLocation(locationClassReq)
        _locationResponse.postValue(handleLocationResponse(response))
    }

    /**
     * Function to handle location response
     */
    private fun handleLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare UD Putaway request
     */
    fun prepareUserDirectedPutawayRequest(
        containerData: UserDirectedPutawayContainerResponse,
        location: Location,
        palletId: String?,
        locationClass: String
    ) {
        viewModelScope.launch {
            submitUserDirectedPutaway(
                UserDirectedPutawaySubmitRequest(
                    putaway = PutawayRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        containerIds = containerData.containerIds,
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        itemId = containerData.itemId,
                        itemSlotting = null,
                        location = com.fsc.flare.source.data.dto.userdirectedputaway.Location(
                            locationClass = if (isRCLockCalled) isolatedLocationClass else locationClass,
                            locationId = location.locationId
                        ),
                        palletId = palletId,
                        userDirected = true,
                        includeCCLocation = if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) "Y" else "N",
                        isRCLockCalled = isRCLockCalled,
                        lotNumber = getItemLotNumber(),
                        isQHLockOnForUserDirectedPutaway = isQHLockOnForUserDirectedPutaway
                    )
                )
            )
            isQHLockOnForUserDirectedPutaway = false
        }
    }

    /**
     * Function to prepare UD Putaway request with Slotting
     */
    fun prepareUserDirectedPutawayRequestWithSlotting(
        containerData: UserDirectedPutawayContainerResponse,
        location: Location,
        palletId: String?,
        locationClass: String,
        maxQty: Int,
        minQty: Int,
        uom: String
    ) {
        viewModelScope.launch {
            submitUserDirectedPutaway(
                UserDirectedPutawaySubmitRequest(
                    putaway = PutawayRequest(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        containerIds = containerData.containerIds,
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        itemId = containerData.itemId,
                        itemSlotting = ItemSlotting(
                            locationClass = locationClass,
                            locationId = location.locationId,
                            maxQty = maxQty,
                            minQty = minQty,
                            uom = uom
                        ),
                        location = com.fsc.flare.source.data.dto.userdirectedputaway.Location(
                            locationClass = if (isRCLockCalled) isolatedLocationClass else locationClass,
                            locationId = location.locationId
                        ),
                        palletId = palletId,
                        userDirected = true,
                        includeCCLocation = if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) "Y" else "N",
                        isRCLockCalled = isRCLockCalled,
                        lotNumber = getItemLotNumber()
                    )
                )
            )
        }
    }


    /**
     * Function to submit user directed putaway details
     */
    private suspend fun submitUserDirectedPutaway(userDirectedPutawaySubmitRequest: UserDirectedPutawaySubmitRequest) {
        _submitUDPutawayResponse.postValue(Resource.Loading())
        val response = udPutawayRepository.submitUserdirectedPutaway(userDirectedPutawaySubmitRequest)
        _submitUDPutawayResponse.postValue(handleSubmitUserDirectedPutawayResponse(response))
    }

    /**
     * Function to handle submit user directed putaway response
     */
    private fun handleSubmitUserDirectedPutawayResponse(response: Response<UserDirectedPutawaySubmitResponse>): Resource<UserDirectedPutawaySubmitResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    /**
     * Function to prepare transaction param request
     */
    fun prepareTransactionParamRequest() {
        viewModelScope.launch(dispatcher) {
            getTransactionParam(
                TransactionParamRequest(
                    cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    trans_code = "IS"
                )
            )
        }
    }

    /**
     * Function to get transaction param details
     */
    private suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) {
        _transactionParamResponse.postValue(Resource.Loading())
        val response = udPutawayRepository.getTransactionParam(transactionParamRequest)
        _transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * Function to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(
            transactionParamResponse.code(),
            transactionParamResponse.errorBody(),
            transactionParamResponse.message()
        )
        return Resource.Error(errorResponse)
    }

    /**
     * Function to get container details
     */
    fun getContainerDetails(containerNum: String) = viewModelScope.launch {
        _containerInfoResponse.postValue(Resource.Loading())
        val response = udPutawayRepository.getContainerDetails(containerNum)
        _containerInfoResponse.postValue(handleContainerInquiryResponse(response))
    }

    /**
     * Function to handle container inquiry response
     */
    private fun handleContainerInquiryResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(
            response.code(),
            response.errorBody(),
            response.message()
        )
        return Resource.Error(errorResponse)
    }

    fun isContainerHasIncubationLock() =
        containerInfoResponse.value?.data?.container?.firstOrNull()?.hasIncubationLock == true

    private fun getItemLotNumber() =
        containerInfoResponse.value?.data?.container?.firstOrNull()?.item?.lotNumber
}
