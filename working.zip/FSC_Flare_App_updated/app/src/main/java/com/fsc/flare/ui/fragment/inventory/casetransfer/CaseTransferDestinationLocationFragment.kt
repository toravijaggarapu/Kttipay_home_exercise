package com.fsc.flare.ui.fragment.inventory.casetransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasetransferDestinationLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerFromRequest
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerToRequest
import com.fsc.flare.source.data.dto.inventory.CaseTransferSubmitRequest
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CaseTransferDestinationLocationFragment"
private const val CASE_TRANSFER_TYPE = "CASE"
private const val CASES_REACHED_MAX_QTY = "ERR-INV-0037"
private const val ITEMS_REACHED_MAX_QTY = "ERR-INV-0038"

/**
 * A simple [CaseTransferDestinationLocationFragment] class.
 */
@AndroidEntryPoint
class CaseTransferDestinationLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentCasetransferDestinationLocationBinding
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var caseTransferSubmitRequest : CaseTransferSubmitRequest
    var inventoryType:String? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCasetransferDestinationLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.caseTransferHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtDestinationLocation)
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.edtDestinationLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtDestinationLocation)
            }
            false
        }

        val containerList = viewModel.getCaseTransferContainerList()
        val palletDetail = viewModel.getCaseTransferPalletDetail()
        val scannedCaseQtyUnits = viewModel.getCaseQtyUnits()
        val nbrOfCasesScanned = viewModel.getCaseScannedCount()

        if(palletDetail!=null){
            //For existing pallet detail populate.
            updateUI(
                palletNbr = palletDetail.palletNumber,
                palletQtyUnits = (palletDetail.palletQuantity + scannedCaseQtyUnits).toInt(),
                nbrOfCases = (palletDetail.noOfCase + nbrOfCasesScanned).toInt(),
                itemCode = if(!palletDetail.itemName.isNullOrEmpty()) palletDetail.itemName else "",
                itemDesc = if(!palletDetail.itemDescription.isNullOrEmpty()) palletDetail.itemDescription else "",
                currentLoc = if(!palletDetail.currentLocation.isNullOrEmpty()) palletDetail.currentLocation else ""
            )
        }else if(viewModel.getNewPalletNumber() != null){
            //For New pallet,
            //Here showing the container scanned item code, item desc,
            //container qty as no. of container/serial nbr scanned.
            //Pallet qty as sum of scanned containers qty.
            if(!containerList.isNullOrEmpty()) {
                updateUI(
                    palletNbr = viewModel.getNewPalletNumber()!!,
                    palletQtyUnits = scannedCaseQtyUnits,
                    nbrOfCases = nbrOfCasesScanned,
                    itemCode = if(containerList[0].itemCode !=null && containerList[0].itemCode?.isNotEmpty()!!) containerList[0].itemCode!! else "",
                    itemDesc = if(containerList[0].itemDesc !=null && containerList[0].itemDesc?.isNotEmpty()!!) containerList[0].itemDesc!! else "",
                    currentLoc = null
                )
            }
        }

        binding.btnSubmit.setOnClickListener {
            if(binding.edtDestinationLocation.text.toString().trim().isNotEmpty()) {
                //Case transfer submit API call need to add.
                submitDestinationLocation()
            }
        }
        subscribeObservers()
        binding.edtDestinationLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.destinationLocationError.text = null
                enableSubmitButton()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun updateUI(palletNbr:String, palletQtyUnits: Int, nbrOfCases: Int, itemCode:String, itemDesc:String, currentLoc:String?){
        binding.tvPalletNumberValue.text = palletNbr
        binding.tvPalletQtyValue.text = resources.getQuantityString(R.plurals.case_transfer_scanned_case_units, palletQtyUnits, palletQtyUnits)
        binding.tvNbrOfContainer.text = resources.getQuantityString(R.plurals.case_transfer_nbr_case, nbrOfCases)
        binding.tvNbrOfContainerValue.text = nbrOfCases.toString()
        binding.tvItemCodeValue.text = itemCode
        binding.tvItemDescValue.text = itemDesc
        if(!currentLoc.isNullOrEmpty()) {
            binding.tvCurrentLocationValue.text = currentLoc
            binding.tvCurrentLocation.visibility = View.VISIBLE
            binding.tvCurrentLocationValue.visibility = View.VISIBLE
        }else{
            binding.tvCurrentLocation.visibility = View.GONE
            binding.tvCurrentLocationValue.visibility = View.GONE
        }
        val containers = viewModel.getCaseTransferContainerList()
        if(!containers.isNullOrEmpty()){
           inventoryType = containers[0].inventoryType
        }
        if(inventoryType!=null)
        {
            binding.palletItemInvTypeLayout.visibility = View.VISIBLE
            binding.tvItemInvTypeValue.text= inventoryType?.let { getInventoryDescription(it) }
        }
    }

    private fun submitDestinationLocation() {
        // fetch pallet details from API
        if (!binding.edtDestinationLocation.text.isNullOrEmpty()) {

            var caseTransferToRequest:CaseTransferContainerToRequest? = null
            var caseTransferFromRequest:CaseTransferContainerFromRequest? = null

            val newPalletNbr = viewModel.getNewPalletNumber()
            val existingPalletDetail = viewModel.getCaseTransferPalletDetail()
            if(newPalletNbr!=null){
                //New pallet scenario,
                caseTransferToRequest = CaseTransferContainerToRequest(
                    palletNumber = newPalletNbr
                )
                caseTransferFromRequest = CaseTransferContainerFromRequest(
                    palletNumber = "",
                    caseNumber = getContainerList()
                )
            }else if(existingPalletDetail!=null){
                //Existing pallet scenario,
                caseTransferFromRequest = CaseTransferContainerFromRequest(
                    palletNumber = existingPalletDetail.palletNumber,
                    caseNumber = getContainerList())
            }

            caseTransferSubmitRequest = CaseTransferSubmitRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toLong(),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
                destinationLocation = binding.edtDestinationLocation.text.toString().trim(),
                skipQtyValidation = true,
                transferType = CASE_TRANSFER_TYPE,
                inventoryType= inventoryType,
                transferFrom = caseTransferFromRequest,
                transferTo = caseTransferToRequest
            )
            viewModel.caseTransferSubmitDestinationLocation(caseTransferSubmitRequest)
        }
    }

    private fun getContainerList():List<String>{
        val caseNumbers = arrayListOf<String>()
        val containers = viewModel.getCaseTransferContainerList()
        if(!containers.isNullOrEmpty()){
            for(containerObj in containers) {
                caseNumbers.add(containerObj.containerNumber)
            }
        }
        return caseNumbers
    }
    private fun subscribeObservers() {
        viewModel.caseTransferSubmitLocResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { caseTransferSubmitResponse ->
                        if(caseTransferSubmitResponse.success) {
                            viewModel.setCaseTransferContainerList(null)
                            viewModel.setCaseScannedCount(0)
                            viewModel.setCaseQtyUnits(0)
                            showCustomDialog(caseTransferSubmitResponse.message) { navigateContainerScanPage() }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")){
                            val msg = message.split("##")
                            if(msg[0].equals(CASES_REACHED_MAX_QTY, ignoreCase = true)||
                                msg[0].equals(ITEMS_REACHED_MAX_QTY, ignoreCase = true)) {
                                showAlertDialog("", msg[1], {
                                    if(caseTransferSubmitRequest!=null) {
                                        caseTransferSubmitRequest.skipQtyValidation = true
                                        viewModel.caseTransferSubmitDestinationLocation(caseTransferSubmitRequest)
                                    }
                                }, {getNavigationController().popBackStack()})
                            }else{
                                binding.destinationLocationError.text = msg[1]
                            }
                        }else{
                            binding.destinationLocationError.text = message
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun enableSubmitButton(){
        binding.btnSubmit.isEnabled = binding.edtDestinationLocation.text.toString().isNotEmpty()
    }
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtDestinationLocation.setText(scan?.barcode.toString())
            binding.edtDestinationLocation.text?.length?.let {
                binding.edtDestinationLocation.setSelection(it)
            }
            FlareLog.i(TAG, "Destination Location field focused")
            enableSubmitButton()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun navigateContainerScanPage(){
        //Navigate to the Detail page.
        val action = CaseTransferDestinationLocationFragmentDirections.actionCaseTransferDestinationLocationFragmentToCaseTransferContainerFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.caseTransferContainerFragment, true).build()
        getNavigationController().navigate(action, navOptions)
    }

}

