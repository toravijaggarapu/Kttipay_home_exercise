package com.fsc.flare.ui.fragment.pickingforward.pickfromactive

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartLocationBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.DropDown
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Locale
import javax.inject.Inject

private const val TAG = "PickCartLocationFragment"

@AndroidEntryPoint
class PickCartLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    var reasonCode: View? = null
    var lockCode = ""
    val inventoryLockList = ArrayList<String>()
    val inventoryLockCodeList = ArrayList<String>()

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        viewModel.resetSerialNumber()
        super.onResume()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Pick location field focused")
                    validateLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        setUpUI()
        binding.skipCart.setOnClickListener {
            FlareLog.i(TAG, "Skipcart clicked")
            val taskDetails = viewModel.getPickTaskDetails()
            if (taskDetails != null) {
                viewModel.pickSkipCart(
                    SkipPickCartReq(
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        pickCartNbr = binding.cart.text.toString(),
                        assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                        allocationType = taskDetails.allocationType,
                        skipTaskId = taskDetails.taskId.toString(),
                        skipTaskDetId = taskDetails.taskDetId.toString(),
                        replenType = getString(R.string.picking_fill),
                        isLTLcubing = viewModel.isLTLCubingEnabled,
                        orderType = viewModel.orderType
                    )
                )
            }
        }
        binding.pickLocationInput.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Pick location field focused")
                validateLocation()
            }
            false
        }
        binding.pickLocationInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.pickLocationTvRes.text = null
            }
        })
    }

    private fun setUpUI() {
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (taskData != null) {
            binding.cart.text = data?.cartNbr
            binding.taskId.text = taskData.taskId.toString()
            binding.item.text = taskData.itemCode
            binding.description.text = taskData.itemDescription
            binding.pickLocation.text = taskData.locationBarcode
            if(!taskData.toteNumber.isNullOrEmpty())
            {
                showToteLayout(true)
                binding.toteNumber.text = taskData.toteNumber
            }else
                showToteLayout(false)
            binding.pickQty.text = viewModel.getTaskQtyUOMValue(taskData)
        }
    }

    private fun showToteLayout(visible: Boolean) {
        if(visible)
        {
            binding.toteTV.visibility = View.VISIBLE
            binding.toteNumber.visibility = View.VISIBLE
        }else
        {
            binding.toteTV.visibility = View.GONE
            binding.toteNumber.visibility = View.GONE
        }
    }

    private fun subscribeObservers() {
        viewModel.skipPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { skipCartResponse ->
                        if (skipCartResponse.success != null && skipCartResponse.success) {
                            FlareLog.i(TAG, "skipPickCart success: $skipCartResponse")
                            if (skipCartResponse.taskDetails != null) {
                                viewModel.updateOrderType(skipCartResponse.orderType)
                                viewModel.setPickTaskDetails(skipCartResponse.taskDetails)
                                binding.taskId.text = skipCartResponse.taskDetails.taskId.toString()
                                binding.item.text = skipCartResponse.taskDetails.itemCode
                                binding.description.text = skipCartResponse.taskDetails.itemDescription
                                binding.toteNumber.text = skipCartResponse.taskDetails.toteNumber
                                binding.pickLocation.text = skipCartResponse.taskDetails.locationName
                                binding.pickQty.text = String.format("%d %s",skipCartResponse.taskDetails.taskQty,skipCartResponse.taskDetails.taskQtyUom)
                            } else {
                                skipCartResponse.message?.let { showErrorSnackBar(it) }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "skipPickCart error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.taskPickQtyUpdateResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { qtyUpdateResponse ->
                        if (qtyUpdateResponse.success != null && qtyUpdateResponse.success) {
                            FlareLog.i(TAG, "taskPickQtyUpdate success: $qtyUpdateResponse")
                            val isChaseWave = (viewModel.getPickTaskDetails()!!.taskWaveType!=null && viewModel.getPickTaskDetails()!!.taskWaveType.isNotEmpty()) && viewModel.getPickTaskDetails()!!.taskWaveType == "C"
                            if (qtyUpdateResponse.promptStage != null && qtyUpdateResponse.promptStage) {

                                if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue()) {
                                    if(!isChaseWave && qtyUpdateResponse.taskShortQty > 0) {
                                        showSuccessSnackBarImp(resources.getString(R.string.proceed_to_problem_resolution_area_with_short_pick)) {
                                            getShortPickedTotesList()
                                        }
                                    }
                                    else{
                                        getShortPickedTotesList()
                                    }
                                } else {
                                    navigateToStageCart()
                                }
                            } else {
                                if (qtyUpdateResponse.taskDetails != null) {
                                    viewModel.updateOrderType(qtyUpdateResponse.orderType)
                                    viewModel.setPickTaskDetails(qtyUpdateResponse.taskDetails)
                                    if(viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue() && !qtyUpdateResponse.alterNativeLocationFound && !isChaseWave ) {
                                        showSuccessSnackBarStd(resources.getString(R.string.short_picked_continue_picking)) {}
                                    }
                                    setUpUI()
                                } else {
                                    showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                                        navigateToTaskGroup()
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPickQtyUpdate error: $message")
                        if(message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == TASK_CYCLE_COUNT_PENDING) {
                                    showReasonCode(false)
                                } else if(msgArray[0] == TASK_ALREADY_PICKED || msgArray[0] == TASK_ASSIGNED_TO_OTHER_USER) {
                                    showErrorAlert(msgArray[1], false)
                                } else if (msgArray[0] == LOCATION_IS_EMPTY ) {
                                    showErrorAlert(msgArray[1], true)
                                }
                                else {
                                    binding.pickLocationInput.requestFocus()
                                    binding.pickLocationInput.selectAll()
                                    binding.pickLocationTvRes.text = msgArray[1]
                                    showSoftKeyBoard(fragmentContext, binding.pickLocationInput)
                                }
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationDetailsResponse ->
                        if (locationDetailsResponse.success != null && locationDetailsResponse.success) {
                            FlareLog.i(TAG, "locationDetailsResponse success: $locationDetailsResponse")
                            if (locationDetailsResponse.locations.isNotEmpty()) {
                                val reserveLocation = locationDetailsResponse.locations[0]
                                if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) {
                                    if (reserveLocation.lockCode == "CC") {
                                        val msg = getString(R.string.cycle_count_progress_for_location)
                                        showCyclePendingAlert(msg,false)
                                    } else {
                                        navigateToItem()
                                    }
                                } else {
                                    if (reserveLocation.cycleCountPending == "Y") {
                                        val msg = getString(R.string.cycle_count_pending_for_location)
                                        showCyclePendingAlert(msg, false)
                                    } else {
                                        navigateToItem()
                                    }
                                }

                            } else {
                                showErrorSnackBar("Invalid Location")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.shortPickTotesResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { shortPickToteResponse ->
                        if (shortPickToteResponse.toteDetails != null && shortPickToteResponse.toteDetails.isNotEmpty()) {
                            viewModel.setShortPickTotesList(shortPickToteResponse)
                            if (!shortPickToteResponse.prLocExist) {
                                navigateToStageCart()
                            } else {
                                val action = PickCartLocationFragmentDirections.actionPickCartLocationFragmentToPrLocationFragment()
                                getNavigationController().navigate(action)
                            }
                        } else {
                            if (shortPickToteResponse.promptStage)
                                navigateToStageCart()
                            else {
                                showSuccessSnackBarStd(resources.getString(R.string.lbl_no_task_details_found_for_staging_moving_to_task_group)) {
                                    navigateToTaskGroup()
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Get short pick error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToItem() {
        val action = PickCartLocationFragmentDirections.actionPickCartLocationFragmentToPickCartItemFragment()
        getNavigationController().navigate(action)
    }

    private fun showCyclePendingAlert(msg: String, isZeroPick: Boolean) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_zero_pick)) { dialogInterface, which ->
            dialogInterface.dismiss()
            showReasonCode(isZeroPick)
        }
        builder.setNegativeButton(resources.getString(R.string.alert_button_cancel)) { dialogInterface, which ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showReasonCode(isZeroPick: Boolean) {
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(layoutInflater)
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        reasonCode = dialogView.reasonCodeDropDown
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        (reasonCode as DropDown?)!!.setOptions(inventoryLockList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        (reasonCode as DropDown?)!!.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                var pickedQty = viewModel.getPickQty(taskData)

                if (isZeroPick)
                    pickedQty = 0

                viewModel.taskPickQtyUpdate(
                    TaskPickQtyUpdateReq(
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")!!.toInt(),
                        pickQty = pickedQty.toString(),
                        pickQtyUom = taskData.taskQtyUom,
                        taskDetailId = taskData.taskDetId,
                        taskId = taskData.taskId,
                        serialNumber = emptyList(),
                        lotNumber = taskData.lotNumber,
                        reasonCode = lockCode,
                        expDate = getFormattedExpiryDate(taskData.expDate)
                    )
                )
            }
            dialog.dismiss()
        }
        if (inventoryLockList.isEmpty())
            viewModel.getInventoryReasonCodes()
        else
            dialogView.reasonCodeDropDown.setOptions(inventoryLockList)

    }

    private fun navigateToStageCart() {
        val action = PickCartLocationFragmentDirections.actionPickCartLocationFragmentToPickCartStagingLocFragment()
        getNavigationController().navigate(action)
    }

    private fun getShortPickedTotesList() {
        viewModel.getShortPickedTotes(
            binding.cart.text.toString(),
            viewModel.getPickTask()?.cartId ?: 0
        )
    }

    private fun navigateToTaskGroup(){
        if (viewModel.isComingFromPickCartFlow) {
            val action = PickCartLocationFragmentDirections.actionPickCartLocationFragmentToPickCartPalletFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartPalletFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        } else {
            val action = PickCartLocationFragmentDirections.actionPickCartLocationFragmentToBuildCartTaskGroup()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
            getNavigationController().navigate(action, navOptions)
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun validateLocation() {
        if (!binding.pickLocationInput.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.pickLocationInput)
            val taskData = viewModel.getPickTaskDetails()
            if (taskData != null) {
                if (binding.pickLocationInput.text.toString() == taskData.locationBarcode) {
                    binding.pickLocationInput.text?.clear()
                    viewModel.validateStagingLocation(
                        LocationClassReq(
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            taskData.locationBarcode,
                            ""
                        )
                    )
                } else {
                    binding.pickLocationTvRes.text = getString(R.string.wrong_pick_location)
                    binding.pickLocationInput.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.pickLocationInput)
                }
            }
        }
    }

    fun getFormattedExpiryDate(expiryDate: String?): String {
        var formattedExpiryDate = ""
        if (expiryDate != null && expiryDate != "") {
            val myFormat1 = "yyyy-MM-dd" // mention the format you need
            val sdf1 = SimpleDateFormat(myFormat1, Locale.US)
            val getApiExpiryDate = sdf1.parse(expiryDate)
            formattedExpiryDate = sdf1.format(getApiExpiryDate)
            return formattedExpiryDate
        }
        return formattedExpiryDate
    }

    private fun showErrorAlert(message:String, locationEmpty:Boolean) {
        if(locationEmpty) {
            showCyclePendingAlert(message, true)
        } else {
            val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            builder.setTitle("")
            builder.setMessage(message)
            builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
                dialogInterface.dismiss()
                navigateToTaskGroup()
            }
            val alertDialog: MaterialAlertDialogBuilder = builder
            alertDialog.setCancelable(false)
            alertDialog.show()
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.pickLocationInput.setText(scan?.barcode.toString())
            binding.pickLocationInput.text?.length?.let {
                binding.pickLocationInput.setSelection(it)
            }
            FlareLog.i(TAG, "Pick location field focused")
            validateLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}