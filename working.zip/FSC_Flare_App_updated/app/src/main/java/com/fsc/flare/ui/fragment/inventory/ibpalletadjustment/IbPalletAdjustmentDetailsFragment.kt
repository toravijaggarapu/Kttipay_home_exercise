package com.fsc.flare.ui.fragment.inventory.ibpalletadjustment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentIbPalletAdjustmentDetailBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletAdjustmentRequest
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "IbPalletAdjustmentDetailsFragment"
private const val MIXED = "Mixed"

/**
 * A simple [IbPalletAdjustmentDetailsFragment] class.
 */
@AndroidEntryPoint
class IbPalletAdjustmentDetailsFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentIbPalletAdjustmentDetailBinding
    private var reasonCode = ""
    private var reasonCodeHashMap = HashMap<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getInventoryReasonCodes()
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentIbPalletAdjustmentDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvIbPalletAdjHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //Get the saved Pallet detail from viewModel object and populate it to the UI.
        val palletData = viewModel.getPalletResponse()
        binding.tvPalletNumberValue.text = palletData.container
        binding.tvCurrentLocationValue.text = palletData.currentLocNumber
        binding.tvNumberOfCaseValue.text = palletData.noOfCases.toString()
        binding.tvTotalPalletQtyValue.text = palletData.qty.toString()
        binding.tvInvTypeValue.text = getInventoryDescription(palletData.inventoryType)

        if (viewModel.isItemMixed()) {
            binding.tvItemCodeValue.text = MIXED
        }else{
            binding.tvItemCodeValue.text = palletData.item
        }
        if(viewModel.isItemDescMixed()){
            binding.tvItemDescValue.text = MIXED
        }else{
            binding.tvItemDescValue.text = palletData.itemDesc
        }


        if (viewModel.isShowItemAttributes()) {
            binding.displayItemLayout.visibility = View.VISIBLE
            if(!palletData.lotNumber.isNullOrEmpty()){
                binding.tvLot.visibility = View.VISIBLE
                binding.tvLotValue.visibility = View.VISIBLE
                binding.tvLotValue.text = palletData.lotNumber
            }
            if(!palletData.expiryDate.isNullOrEmpty()){
                binding.tvExpDate.visibility = View.VISIBLE
                binding.tvExpDateValue.visibility = View.VISIBLE
                binding.tvExpDateValue.text = palletData.expiryDate
            }
            if(!palletData.manufacturedDate.isNullOrEmpty()){
                binding.tvMfgDate.visibility = View.VISIBLE
                binding.tvMfgDateValue.visibility = View.VISIBLE
                binding.tvMfgDateValue.text = palletData.manufacturedDate
            }
            if(!palletData.coo.isNullOrEmpty()){
                binding.tvCoo.visibility = View.VISIBLE
                binding.tvCooValue.visibility = View.VISIBLE
                binding.tvCooValue.text = palletData.coo
            }
            if(viewModel.isLotMixed()){
                binding.tvLotValue.text = MIXED
            }else{
                binding.tvLotValue.text = palletData.lotNumber
            }
            if(viewModel.isExpDateMixed()){
                binding.tvExpDateValue.text = MIXED
            }else{
                binding.tvExpDateValue.text = palletData.expiryDate
            }
            if(viewModel.isMfgDateMixed()){
                binding.tvMfgDateValue.text = MIXED
            }else{
                binding.tvMfgDateValue.text = palletData.manufacturedDate
            }
        } else {
            binding.displayItemLayout.visibility = View.GONE
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtAdjustQty)
                    if (binding.edtAdjustQty.isFocused) {
                        FlareLog.i(TAG, "IB Pallet Adjustment field focused")
                        binding.edtAdjustQty.clearFocus()
                        validateAdjustQty()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.edtAdjustQty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtAdjustQty)
                FlareLog.i(TAG, "AdjustQty field focused")
                validateAdjustQty()
            }
            false
        }
        binding.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            reasonCode = reasonCodeHashMap[selection].toString()
            validateAdjustQty()
        }

        binding.btnConfirm.setOnClickListener {
            confirmApiCall()
        }
        binding.edtAdjustQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvAdjustQtyResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
        enableConfirmButton(false)
        subscribeObservers()
    }

    private fun validateAdjustQty() {
        if (binding.edtAdjustQty.text.toString().isNotEmpty()) {
            if (binding.edtAdjustQty.text.toString().toInt() > 0) {
                enableConfirmButton(false)
                binding.tvAdjustQtyResponse.text = resources.getString(R.string.qty_can_not_greater_than_zero_for_pallet_adjustment)
            } else {
                enableConfirmButton(reasonCode.isNotEmpty())
            }
        } else {
            enableConfirmButton(false)
        }
    }

    private fun enableConfirmButton(isEnable: Boolean) {
        binding.btnConfirm.isEnabled = isEnable
    }

    private fun subscribeObservers() {

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        if (lookUpResponse.lookups.isNotEmpty()) {
                            lookUpResponse.lookups[0].lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                reasonCodeHashMap[it.lookupCodeDescription] = it.lookupCode
                            }
                            binding.reasonCodeDropDown.setOptions(inventoryLockList)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.inventoryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let {
                        showAlertDialog("", it.message, onDialogYesClicked)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    enableConfirmButton(true)
                    showErrorSnackBar(response.message!!)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun confirmApiCall() {
        val palletData = viewModel.getPalletResponse()
        enableConfirmButton(false)

        viewModel.inventoryIbPalletAdjustment(
            InventoryIbPalletAdjustmentRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                containerId = palletData.containerId,
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                containerType = palletData.containerType,
                invMasterId = 0, // For pallets we need to give this as 0
                qty = binding.edtAdjustQty.text.toString(),
                qtyUom = "EA",// For pallets qtyUom could be EA
                reasonCode = reasonCode,
            )
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    // Callback from dialog positive button
    private val onDialogYesClicked = {
        val action =
            IbPalletAdjustmentDetailsFragmentDirections.actionIbPalletAdjustmentDetailFragmentToIbPalletAdjustmentFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.ibPalletAdjustmentFragment, true).build()
        getNavigationController().navigate(action, navOptions)
    }

}

