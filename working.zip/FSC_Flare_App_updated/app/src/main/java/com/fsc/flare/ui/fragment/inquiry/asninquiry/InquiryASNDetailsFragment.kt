package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryAsnDetailsBinding
import com.fsc.flare.source.data.dto.inquiry.asn.ASNMoreOptionsData
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPrintPalletRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


/**
 * A simple [Fragment] subclass.
 * Use the [InquiryASNDetailsFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InquiryASNDetailsFragment : BaseFragment() {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryAsnDetailsBinding
    private val mixed = "Mixed"

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquiryAsnDetailsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    /**
     * method to subscribe Print labels
     */
    private fun subscribeObservers() {
        viewModel.asnPrintPalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { asnPrintResponse ->
                        showCustomDialog(asnPrintResponse.message) {}
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val palletData = viewModel.getPalletDetails()
        /* val asnData = viewModel.getAsnDetailsData()
         if (asnData != null) {
             binding.tvAsnNumberValue.text = asnData.asnNumber
             r
         }*/
        if (palletData != null) {
            //Set the values of pallet detail
            binding.tvAsnNumberValue.text = palletData.asnNumber
            binding.tvCustAsnNumberValue.text = palletData.customerASNNumber
            binding.tvPalletNumberValue.text = palletData.palletNumber
            binding.tvNoOfCasesValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_cases, palletData.noOfCase, palletData.noOfCase)
            binding.tvPalletQuantityValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_units, palletData.palletQuantity, palletData.palletQuantity)
            binding.tvItemCodeValue.text = palletData.itemCode
            binding.tvItemDescValue.text = palletData.itemDescription
            binding.tvInventoryTypeValue.text = palletData.inventoryType?.let { getInventoryDescription(it) }

            if (palletData.containerNumber != null) {
                binding.tvContainerNumberValue.text = palletData.containerNumber
                binding.lnrContainerNumber.visibility = View.VISIBLE
            }

            if (palletData.itemCode != mixed) {
                binding.btnMore.visibility = View.VISIBLE
            }
        }

        binding.btnOk.setOnClickListener {
            val action =
                InquiryASNDetailsFragmentDirections.actionInquiryAsnDetailsFragmentToInquiryAsnPalletNumberFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.InquiryASNPalletNumberFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        }

        binding.btnMore.setOnClickListener {
            val optionList = ArrayList<ASNMoreOptionsData>()
            optionList.add(ASNMoreOptionsData("BP", getString(R.string.asn_inquiry_blind_pallet)))
            if (viewModel.checkIfPrintNeeded("PPL"))
                optionList.add(ASNMoreOptionsData("PPL", getString(R.string.asn_inquiry_print_pallet_label)))

            if (viewModel.checkIfPrintNeeded("PCL"))
                optionList.add(ASNMoreOptionsData("PCL", getString(R.string.asn_inquiry_print_case_label)))

            if (viewModel.checkIfPrintNeeded("PPL") && viewModel.checkIfPrintNeeded("PCL"))
                optionList.add(ASNMoreOptionsData("PBL", getString(R.string.asn_inquiry_print_both_label)))

            showMoreOptions(optionList)
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    private fun showMoreOptions(optionList: ArrayList<ASNMoreOptionsData>) {
        val dialogView = layoutInflater.inflate(R.layout.custom_list_dialog, null)
        val dialog = AlertDialog.Builder(fragmentContext).setView(dialogView).create()
        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }
        val homeAdapter = MoreOptionsAdapter(optionList, object : MoreOptionsAdapter.OnAdapterClickListener {
            override fun onItemSelected(itemId: String) {
                if (itemId == "BP") {
                    //For blind pallet option, it will navigate to blind pallet screen
                    dialog.dismiss()
                    val action = InquiryASNDetailsFragmentDirections.actionInquiryAsnDetailsFragmentToInquiryAsnBlindPalletNumberFragment()
                    getNavigationController().navigate(action)
                } else {
                    //Other options will initiate API call to print labels
                    viewModel.printPalletLabel(createPrintPalletRequest(itemId))
                    dialog.dismiss()
                }
            }
        }, fragmentContext)
        dialogView.findViewById<RecyclerView>(R.id.rvPrintLabels).apply {
            adapter = homeAdapter
        }
        dialog.setCancelable(false)
        dialog.show()
    }

    private fun createPrintPalletRequest(itemId: String): ASNPrintPalletRequest {
        val palletData = viewModel.getPalletDetails()
        val printPalletRequest: ASNPrintPalletRequest?
        printPalletRequest = ASNPrintPalletRequest(
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            pallet = palletData!!.palletNumber,
            asnId = palletData.asnId,
            buCode = sharedPreferences.getString(PreferenceKeys.BUSINESS_UNIT_CODE, "")!!,
            customerCode = sharedPreferences.getString(PreferenceKeys.CUST_CODE, "")!!,
            facilityCode = sharedPreferences.getString(PreferenceKeys.FACILITY_NAME, "")!!,
            printRequester = viewModel.getSelectedPrinterData()!!.requestor
        )
        when (itemId) {
            "PPL" -> {
                printPalletRequest.printPalletLabel = "1"
            }
            "PCL" -> {
                printPalletRequest.printCaseLabel = "1"
            }
            else -> {
                printPalletRequest.printBothLabel = "1"
            }
        }
        return printPalletRequest
    }

}
