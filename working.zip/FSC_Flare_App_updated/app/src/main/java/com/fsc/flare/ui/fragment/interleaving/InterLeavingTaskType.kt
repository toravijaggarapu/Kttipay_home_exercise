package com.fsc.flare.ui.fragment.interleaving

import com.fsc.flare.R

enum class InterLeavingTaskType(val code: String) {
    PALLET_PUTWAY_TO_RESERVE("PPWR"),
    PICK_FROM_RESERVE("PFR"),
    PALLET_REPLENISHMENT_TO_ACTIVE("PRA"),
    PALLET_REPLENISHMENT_TO_CASE_PICK("PRC");

    val description: Int
        get() = when (this) {
            PALLET_PUTWAY_TO_RESERVE -> R.string.pallet_putaway_to_reserve
            PICK_FROM_RESERVE -> R.string.pick_from_reserve
            PALLET_REPLENISHMENT_TO_ACTIVE -> R.string.pallet_repln_to_active
            PALLET_REPLENISHMENT_TO_CASE_PICK -> R.string.pallet_repln_to_case_pick
        }
}