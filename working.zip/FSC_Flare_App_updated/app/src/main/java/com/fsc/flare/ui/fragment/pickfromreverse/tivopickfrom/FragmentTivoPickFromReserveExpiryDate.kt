package com.fsc.flare.ui.fragment.pickfromreverse.tivopickfrom

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavDirections
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentExpiryDateTivoPfrBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject


private const val TAG = "FragmentTivoPickFromReserveExpiryDate"

@AndroidEntryPoint
class FragmentTivoPickFromReserveExpiryDate : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentExpiryDateTivoPfrBinding
    private var pkdQty=1

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        super.onResume()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        binding.btnStage.isEnabled = viewModel.getTasksCompletedList()?.isNotEmpty() == true

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExpiryDateTivoPfrBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateExpiry()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        init()
        setDatePicker()
        setListener()
    }


    private fun updatePickedQuantity() {
        // Check for pallet for case
        if (viewModel.isPallet(viewModel.getPickTaskDetails())) {
            binding.tvPickedQuantityValue.text = if (pkdQty > 1) "$pkdQty pallets" else "$pkdQty pallet"
            viewModel.markTaskCompleteRequest?.let {
                binding.tvPalletNumberValue.text = it.palletNumber
            }
            binding.tvContainerNumber.visibility = View.GONE
            binding.tvContainerNumberValue.visibility = View.GONE

        } else {
            binding.tvPickedQuantityValue.text = if (pkdQty > 1) "$pkdQty cases" else "$pkdQty case"
            binding.tvPalletNumberValue.text = viewModel.getPickTaskDetails()?.containerNbr
            viewModel.markTaskCompleteRequest?.let {
                binding.tvContainerNumberValue.text = it.containers?.let { it ->
                    if (it.isNotEmpty()) {
                        it.first()?.containerNumber
                    } else ""
                } ?: ""
            }
        }
    }

    private fun init() {
        binding.btnStage.isEnabled = true
        viewModel.getPickTaskDetails()?.let {
            binding.tvTaskIdValue.text = it.taskId.toString()
            binding.itemCodeValue.text = it.itemCode
            binding.tvDescValue.text = it.itemDescription
            updatePickedQuantity()
            binding.tvContainerNumberValue.text = "${it.containerId}"
            binding.tvLocationValue.text = it.locationBarcode

            if (viewModel.isPallet(it)) {
                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} pallets" else "${it.taskQty} pallet"
            } else {
                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} cases" else "${it.taskQty} case"
            }
        }
    }

    private fun setListener() {
        binding.btnStage.setOnClickListener {
            moveToStagingScreen()
        }
    }

    private fun setDatePicker() {
        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

           // val myFormat = "MM/dd/yyyy" // mention the format you need
            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            binding.etExpiryDate.text = sdf.format(cal.time)
            if(!isExpiryDateSame(binding.etExpiryDate.text.toString())){
                binding.tvError.text = getString(R.string.alert_invalid_expiry_date)
            }
//            if (!binding.date.text.isNullOrEmpty()) {
//                sharedPreferences.edit().putString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, binding.date.text.toString()).apply()
//                if (item.tracking.countryOfOriginRequired == "1") {
//                    binding.date.requestFocus()
//                    val navController =
//                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//                    val action = ExpiryDateFragmentDirections.actionExpiryDateFragmentToCooFragment()
//                    navController.navigate(action)
//                } else {
//                    binding.date.requestFocus()
//                    val navController =
//                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
//                    val action = ExpiryDateFragmentDirections.actionExpiryDateFragmentToQtyUomFragment()
//                    navController.navigate(action)
//                }
//            }
        }
        binding.etExpiryDate.setOnClickListener {
            binding.tvError.text = ""
            DatePickerDialog(
                fragmentContext, dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun validateExpiry() {
        if (!binding.etExpiryDate.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "expiry date field focused")
            val expiryDate = binding.etExpiryDate.text.toString().trim()
            // Check for valid or invalid expiry date
            if (expiryDate.isEmpty()) {
                binding.tvError.text = getString(R.string.alert_invalid_expiry_date)
            } else {
                if(!isExpiryDateSame(expiryDate)){
                    binding.tvError.text = getString(R.string.alert_invalid_expiry_date)
                }else{
                    // If current task has lot track or expired track than move to that screen
                    val action = checkCurrentTaskType()
                    if (action != null) {
                        moveToFragment(action)
                        return
                    }
                    binding.tvError.text = ""
                    // Add expiry date to mark request
                    viewModel.markTaskCompleteRequest?.expDate = expiryDate
                    viewModel.markTaskCompleteRequest?.let {
                        viewModel.taskReservePickCompleteTivoPFR(it)
                    }
                }
            }

        } else {
            binding.tvError.text = getString(R.string.alert_enter_expiry_date)
        }
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun saveCompletedTask() {
        var taskList = viewModel.getTasksCompletedList()
        if (taskList == null) {
            taskList = ArrayList()
        }

        taskList.add(viewModel.getPickTaskDetails())
        viewModel.setTasksCompletedList(taskList)

    }
    private fun moveToStagingScreen() {
       // val action = FragmentExpiryDatePickFromReserveDirections.actionPickFromReserveExpiryDateFragmentToPickFromReserveStageFragment()
       /* val action = FragmentExpiryDatePickFromReserveDirections.actionPickFromReserveExpiryDateFragmentToStagingLocationTivoPickFromFragment()
         moveToFragment(action)*/

        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        navController.navigate(
            R.id.stagingLocationTivoPickFromFragment,
            null,
            NavOptions.Builder()
                .setPopUpTo(R.id.stagingLocationTivoPickFromFragment, true)
                .build()
        )
    }

    private fun subscribeObservers() {
        viewModel.markTaskCompleteTivoPFRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success == true) {
                            saveCompletedTask()
                            binding.etExpiryDate.text = ""
                            FlareLog.i(TAG, "markTaskCompleteTivoPFRResponse success: $taskpickResponse")
                            binding.btnStage.isEnabled = true
                            viewModel.markTaskCompleteRequest = null // reset complete request
                            if (taskpickResponse.taskDetails == null) {
                                showSuccessSnackBar(taskpickResponse.message ?: getString(R.string.alert_all_tasks_completed))
                                binding.btnStage.performClick()
                            }else
                            {
                                taskpickResponse.taskDetails.let {
                                    viewModel.setPickTaskDetails(it)
                                }
                                checkNextTaskType(viewModel.getPickTaskDetails())
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
            binding.etExpiryDate.text = scan?.barcode.toString()



    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun checkCurrentTaskType(): NavDirections? {
        return viewModel.getPickTaskDetails()?.let {
            val itemLotTracked = it.itemLotTracked
            val action =
                when {
                    itemLotTracked != "0" -> {
                        null
                    }
                    else -> {
                        null
                    }
                }

            action
        }
    }

    private fun checkNextTaskType(taskDetail: TaskDetails?) {
         taskDetail.let {
            val serialTracked = it?.itemSerialTracked
            val uom = it?.taskQtyUom?.lowercase(Locale.ROOT)

             if ((serialTracked == "1" && uom == "pallets") || (serialTracked == "0" && uom == "pallets") || (serialTracked == "4" && uom == "pallets")) {
                moveToScreen(1)
            } else if ((serialTracked == "1" && uom == "cases") || (serialTracked == "0" && uom == "cases") || (serialTracked == "4" && uom == "cases")) {
                moveToScreen(2)
            }
        }
    }

    private fun moveToScreen(type: Int) {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)

        when (type) {
            1 -> // pallet screen
            {
                navController.navigate(
                    R.id.palletSerialNumberTwoTivoPickFromFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.id.palletSerialNumberTwoTivoPickFromFragment, true)
                        .build()
                )
            }

            2 -> // case screen
            {
                navController.navigate(
                    R.id.containerSerialNumberTivoPickFromFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.id.containerSerialNumberTivoPickFromFragment, true)
                        .build()
                )
            }
        }
    }

    private fun isExpiryDateSame(selectedDate:String):Boolean {
        val myFormat1 = "yyyy-MM-dd" // mention the format you need
        val myFormat = "yyyy-MM-dd hh:mm:ss" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        val sdf1 = SimpleDateFormat(myFormat1, Locale.US)

        if(viewModel.getPickTaskDetails()?.expDate!=null && viewModel.getPickTaskDetails()?.expDate !=""){
            val getApiExpiryDate = sdf.parse(viewModel.getPickTaskDetails()?.expDate)
            val taskDetailExpDate = sdf1.format(getApiExpiryDate)
            if(taskDetailExpDate.isNotEmpty() && taskDetailExpDate.equals(selectedDate, true)){
                return true
            }
        }else
        {
            return true
        }
        return false
    }
}