package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReverseLocationDescriptionBinding
import com.fsc.flare.source.data.dto.inquiry.location.ReverseContObj
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ReverseLocationDescriptionFragment :  BaseFragment() {


    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentReverseLocationDescriptionBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReverseLocationDescriptionBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getLocation()
        val rlogLocData = viewModel.rLogLocationInquiry
        val containersList = rlogLocData?.locationDetails?.distinctBy { it.cntNbr }
        val filteredContainerList = containersList?.filter {it.cntType == "Carton" }

        if (data != null) {
            val location = data.locations[0]
            binding.zoneGroup.text = location.groupDescription
            binding.locationId.text = location.locationBarcode
            binding.locationClass.text = getLocationClass(location.classification)
            binding.locationType.text = getLocationType(location.locType)
            binding.status.text = getLocationStatus(location.status)
            if (rlogLocData != null) {
                binding.returnType.text = rlogLocData.locationDetails[0].scnRetType
                binding.returnPoint.text = rlogLocData.locationDetails[0].scnRetPoint
                binding.group.text = rlogLocData.locationDetails[0].scnGrpId
                binding.sb.text = rlogLocData.locationDetails[0].scnSbnum
                binding.sbStatus.text = rlogLocData.locationDetails[0].sbStatus
            }
            if(rlogLocData != null ){
                if (!filteredContainerList.isNullOrEmpty() && location.classification != "S") {
                    if(filteredContainerList.size == 1){
                        binding.bl.text =rlogLocData.locationDetails[0].scnBl
                        binding.blStatus.text = rlogLocData.locationDetails[0].scnBlStatus
                        binding.vendorId.text = rlogLocData.locationDetails[0].scnVendId
                        binding.singleContainerId.visibility = View.VISIBLE
                        binding.singleContainerId.text = rlogLocData.locationDetails[0].cntNbr
                    }else{
                        binding.multipleContainerId.visibility = View.VISIBLE
                        viewModel.reverseContainerList = filteredContainerList.map{ReverseContObj(containerNbr = it.cntParentContainerNbr, vendorId = it.scnVendId, blNbr = it.scnBl, blStatus = it.scnBlStatus)}.toMutableList()
                        binding.multipleContainerId.setOnClickListener {
                            val action = ReverseLocationDescriptionFragmentDirections.actionReverseLocationFragmentToReverseContainerListFragment()
                            getNavigationController().navigate(action)
                        }
                    }
                }else{
                    binding.invDetailsLayout.visibility = View.GONE
                }
            }

            binding.btnOk.setOnClickListener {
                Handler(Looper.getMainLooper()).postDelayed({
                    val action = ReverseLocationDescriptionFragmentDirections.actionReverseLocationFragmentToInquiryLocationFragment()
                    getNavigationController().navigate(action)
                }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
            }
        }
    }
}