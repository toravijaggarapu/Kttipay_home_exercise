package com.fsc.flare.ui.fragment.replenish.loadcartpallet


import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishTaskGroupBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.TaskReplenRequest
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ReplenishLoadCartTaskGr"
@AndroidEntryPoint
class ReplenishLoadCartTaskGroupFragment : BaseFragment() {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishTaskGroupBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        if (viewModel.gettaskGroupCodeOptions() != null) {
            binding.dropdownTaskgrp.setOptions(viewModel.gettaskGroupCodeOptions())
        }
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FlareLog.i(TAG, "GetTaskGroups called")
        viewModel.getTaskGroups()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishTaskGroupBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        binding.tvReplenish.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun subscribeObservers() {
        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrp Response: $taskGroupResponse")
                        val taskGroupDescList = ArrayList<String>()
                        val taskGroups = ArrayList<TaskGroup>()
                        taskGroupResponse?.taskGroups?.forEach { lookup ->
                            taskGroupDescList.add(lookup.description)
                            taskGroups.add(lookup)
                        }
                        viewModel.settaskGroupCodeOptions(taskGroupDescList)
                        viewModel.setTaskGroupsList(taskGroups)
                        binding.dropdownTaskgrp.setOptions(taskGroupDescList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskGrp Error: $message")

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }

        viewModel.taskReplenResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplen Response: $taskReplenResponse")
                        if (taskReplenResponse != null) {
                            if (taskReplenResponse.success) {
                                if (taskReplenResponse.cartNbr == null) {
                                    binding.dropdownTaskgrp.text = null
                                    binding.dropdownTaskgrp.text = getString(R.string.select_task_group)
                                    val action = ReplenishLoadCartTaskGroupFragmentDirections.actionLoadCartTaskGroupToLoadCartPallet()
                                    getNavigationController().navigate(action)
                                } else {
                                    viewModel.setReplenTask(taskReplenResponse)
                                    if (taskReplenResponse.taskDetails != null) {
                                        viewModel.setReplenTaskDetails(taskReplenResponse.taskDetails)
                                    }
                                    binding.dropdownTaskgrp.text = getString(R.string.select_task_group)
                                    val action = ReplenishLoadCartTaskGroupFragmentDirections.actionLoadCartTaskGroupToLoadCartContainer()
                                    getNavigationController().navigate(action)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskReplen Error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.dropdownTaskgrp.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            val taskGroups = viewModel.getTaskGroupsList()
            taskGroups?.forEach { lookupCode ->
                if (lookupCode.description == isUpdated) {
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP, isUpdated).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, lookupCode.code).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, lookupCode.allocationType).apply()
                }
            }
            viewModel.getTaskReplen(
                TaskReplenRequest(
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null).orEmpty(),
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null).orEmpty()
                )
            )
        }
    }
}