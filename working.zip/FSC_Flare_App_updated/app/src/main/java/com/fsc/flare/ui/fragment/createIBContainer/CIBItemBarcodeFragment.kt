package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBItemBarcodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBItemBarcodeFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBItemBarcodeFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBItemBarcodeFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBItemBarcodeBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBItemBarcodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.etItemBarcode.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etItemBarcode)
                if (binding.etItemBarcode.isFocused && !binding.etItemBarcode.text.isNullOrEmpty()) {
                    FlareLog.i(TAG, "Item Barcode field focused")
                    validateItemBarcode()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etItemBarcode.isFocused && !binding.etItemBarcode.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Item Barcode field focused")
                        validateItemBarcode()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etItemBarcode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvItemBarcodeResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeItemBarcodeObserver()
    }


    /**
     * method to get Item details from API
     */
    private fun validateItemBarcode() {
        viewModel.getItemDetails(binding.etItemBarcode.text.toString())
    }

    /**
     * method to subscribe ItemBarcode response observer
     */
    private fun subscribeItemBarcodeObserver() {
        viewModel.itemBarCodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { itemBarcodeResponse ->
                        if (itemBarcodeResponse!=null && itemBarcodeResponse.success) {
                            if (itemBarcodeResponse.items != null && itemBarcodeResponse.items.isNotEmpty()) {
                                viewModel.setItemBarcodeData(itemBarcodeResponse.items[0])
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                val action =
                                    CIBItemBarcodeFragmentDirections.actionItemBarcodeFragmentToUomFragment()
                                navController.navigate(action)
                            } else {
                                showItemCodeError(getString(R.string.invalid_item_barcode))
                            }
                        } else {
                            showItemCodeError(getString(R.string.invalid_item_barcode))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showItemCodeError(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etItemBarcode.setText(scan?.barcode.toString())
                binding.etItemBarcode.text?.length?.let {
                    binding.etItemBarcode.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Item Barcode field focused")
                    validateItemBarcode()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun showItemCodeError(msg:String){
        binding.etItemBarcode.requestFocus()
        binding.tvItemBarcodeResponse.text = resources.getString(R.string.invalid_item_barcode)
        binding.etItemBarcode.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etItemBarcode)
    }
}