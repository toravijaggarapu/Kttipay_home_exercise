package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.login.LangUpdateRequest
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

class AccountRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun fetchAuthorizedMenu(token: String) = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
        apiGatewayInterface.fetchTempAuthorizedMenu(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!
        )
    } else {
        apiGatewayInterface.fetchAuthorizedMenu(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            token
        )
    }

    suspend fun updateAppLanguage(lang: LangUpdateRequest) =
        apiGatewayInterface.appLanguageUpdate(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            languageRequest = lang)

    suspend fun getContainerTypes() =
        apiGatewayInterface.fetchContainerTypes(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
        )

    suspend fun getFacilityDetails(fName:String) =
        apiGatewayInterface.getFacilityDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            facilityName = fName
        )

    suspend fun updateLastLoginTimeForCustomer(): Response<LangUpdateResponse> =
        apiGatewayInterface.updateLastLoginTimeForCustomer(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            usrId =sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        )

    suspend fun getLookUps(lookUpsRequest: LookUpsRequest) = apiGatewayInterface.getLookUps(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = lookUpsRequest.cusId,
        fcyId = lookUpsRequest.fcyId,
        buId = lookUpsRequest.buId,
        lookupNames = lookUpsRequest.lookupNames
    )

    suspend fun getTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun getInventoryLockCodes(inventoryLockcodeRequest: InventoryLockcodeRequest) = apiGatewayInterface.getInventoryLockCodes(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = inventoryLockcodeRequest.custId,
        fcyId = inventoryLockcodeRequest.fcyId,
        buId = inventoryLockcodeRequest.buId
    )

    suspend fun getCustomerDetails(customerId: Int) = apiGatewayInterface.getCustomerDetails(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
        customerId = customerId
    )

}