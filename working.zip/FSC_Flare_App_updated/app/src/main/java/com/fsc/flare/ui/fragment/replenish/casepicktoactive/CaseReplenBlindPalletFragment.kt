package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenBlindPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenBlindPalletFragment::class.java.simpleName.toString()

/**
 * [CaseReplenBlindPalletFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenBlindPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenBlindPalletBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(
                PreferenceKeys.FEDEX_ID, null
            )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etPalletCartId.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etPalletCartId)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenBlindPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplen.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etPalletCartId.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etPalletCartId)
                    if (!binding.etPalletCartId.text.isNullOrEmpty()) {
                        FlareLog.i(
                            TAG,
                            "Pallet field focused"
                        )
                        getPalletOrCartIdInfo()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etPalletCartId.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletCartId)
                FlareLog.i(TAG, "Pallet field focused")
                getPalletOrCartIdInfo()
            }
            false
        }

        binding.etPalletCartId.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                showSoftKeyBoard(fragmentContext, binding.etPalletCartId)
                binding.tvPalletCartidResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun getPalletOrCartIdInfo() {
        if (!binding.etPalletCartId.text.isNullOrEmpty()) {
            viewModel.getReplenCaseToActivePickTask(
                TaskReplenCartRequest(
                    sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_CODE, null)!!,
                    binding.etPalletCartId.text.toString()
                )
            )
        } else {
            binding.tvPalletCartidResponse.text = getString(R.string.cart_pallet_required)
        }
    }

    private fun subscribeObservers() {
        observeReplenCaseToActiveTaskPickResponse()
    }

    private fun observeReplenCaseToActiveTaskPickResponse() {
        viewModel.replenCaseTaskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        FlareLog.i(TAG, "taskReplen Response: $taskReplenResponse")
                        if (taskReplenResponse.success) {
                            if (taskReplenResponse.taskDetails != null) {
                                viewModel._pickCartNbr = taskReplenResponse.cartNbr
                                viewModel._replenTaskDetails.value = taskReplenResponse.taskDetails
                                val action = CaseReplenBlindPalletFragmentDirections.actionCaseReplenBlindPalletToCaseReplenTaskDetails()
                                getNavigationController().navigate(action)
                            } else {
                                showErrorSnackBar(getString(R.string.no_task_details_found))
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(
                            TAG,
                            "taskReplen error: $message"
                        )
                        binding.tvPalletCartidResponse.text = message
                        binding.etPalletCartId.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etPalletCartId)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etPalletCartId.setText(scan?.barcode.toString())
        binding.etPalletCartId.text?.length?.let {
            binding.etPalletCartId.setSelection(it)
            getPalletOrCartIdInfo()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }
}