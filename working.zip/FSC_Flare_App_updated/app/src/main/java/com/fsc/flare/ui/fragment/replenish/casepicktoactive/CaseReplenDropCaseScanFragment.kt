package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenDropCaseScanBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CaseReplenDropCaseScanFragment::class.java.simpleName.toString()

/**
 * A simple [CaseReplenDropCaseScanFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenDropCaseScanFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenDropCaseScanBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenDropCaseScanBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplenishHeader.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        observeData()
        return binding.root
    }

    private fun observeData() {
        observeContainerInquiryData()
    }

    private fun setUpViews() {
        with(binding) {
            updateUIElements()

            grpScanCase.visibility = View.GONE
            grpDecisionButtons.visibility = View.VISIBLE

            btAccept.setOnClickListener {
                grpScanCase.visibility = View.VISIBLE
                grpDecisionButtons.visibility = View.GONE
            }

            btSkip.setOnClickListener {
                viewModel.replenCaseSkipTask(
                    SkipTaskDetailsRequest(
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        pickCartNbr = viewModel.pickCartNbr,
                        assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                        allocationType = sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, "60") ?: "60",
                        skipTaskId = binding.tvTaskNumberValue.text.toString()
                    )
                )
            }
        }
        handleTouchAndFocusEvents()
        observeReplenCaseSkipTaskData()
    }

    private fun updateUIElements() {
        binding.tvPalletCartIdValue.text = viewModel.pickCartNbr
        viewModel.replenTaskDetails.value?.let { taskDetails ->
            binding.tvTaskNumberValue.text = "${taskDetails.taskId}"
            binding.tvItemValue.text = taskDetails.itemCode
            binding.tvPickContainerValue.text =
                if (taskDetails.toteNumber.isNullOrEmpty()) taskDetails.containerNbr else taskDetails.toteNumber
            binding.tvDeliveryQtyValue.text = getString(
                R.string.lbl_delivery_qty_value,
                taskDetails.taskQty,
                taskDetails.taskQtyUom,
                taskDetails.ibContainerQty,
                taskDetails.ibContainerUom ?: taskDetails.taskQtyUom
            )
            binding.tvDeliveryLocationValue.text = taskDetails.destLocationBarcode
        }
    }

    private fun observeReplenCaseSkipTaskData() {
        viewModel.replenCaseSkipTaskResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success) {
                            val taskDetails = taskReplenResponse.taskDetails
                            if (taskDetails != null) {
                                viewModel.apply {
                                    _replenTaskDetails.value = taskDetails
                                    _pickCartNbr = taskReplenResponse.cartNbr
                                }
                                updateUIElements()
                            } else {
                                showErrorSnackBar("No Task Details Found")
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    showErrorSnackBar(
                        message = response.message ?: getString(R.string.lbl_something_went_wrong)
                    )
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.etScanCase)
                    if (binding.etScanCase.isFocused && !binding.etScanCase.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etScanCase.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanCase)
                FlareLog.i(TAG, "Container field focused")
                validateContainer()
            }
            false
        }

        binding.etScanCase.doAfterTextChanged { binding.tvContainerErrorResponse.text = null }
    }

    private fun validateContainer() {
        if (!binding.etScanCase.text.isNullOrEmpty()) {
            val interimTaskDetails = viewModel.replenTaskDetails.value
            interimTaskDetails?.let {
                val caseNumber = if(it.toteNumber.isNullOrEmpty()) it.containerNbr else it.toteNumber
                if (binding.etScanCase.text.toString() == caseNumber) {
                    viewModel.validateContainer(binding.etScanCase.text.toString(), "Y")
                } else {
                    binding.tvContainerErrorResponse.text = getString(R.string.invalid_container)
                }
            }
        } else {
            binding.tvContainerErrorResponse.text = getString(R.string.case_field_is_empty)
        }
    }

    private fun observeContainerInquiryData() {
        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { inventoryContainerResponse ->
                        if (inventoryContainerResponse.success) {
                            val containers = inventoryContainerResponse.container
                            val firstContainer = containers.firstOrNull()

                            val isNotEmpty = containers.isNotEmpty()
                            val isFirstContainerMatch = firstContainer?.containerNumber == binding.etScanCase.text.toString()
                            val isNotMixedInventoryType = firstContainer?.mixedInventoryType != true

                            if (isNotEmpty && isFirstContainerMatch) {
                                if(isNotMixedInventoryType) {
                                    val action = CaseReplenDropCaseScanFragmentDirections.actionCaseReplenDropCaseScanToCaseReplenDropLocationScan()
                                    getNavigationController().navigate(action)
                                } else {
                                    binding.tvContainerErrorResponse.text = getString(R.string.inventory_type_is_mixed)
                                }
                            } else {
                                binding.tvContainerErrorResponse.text = getString(R.string.invalid_container)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { errorMessage ->
                        binding.etScanCase.text?.length?.let {
                            binding.etScanCase.setSelection(it)
                        }
                        binding.tvContainerErrorResponse.text = errorMessage
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible() || binding.grpDecisionButtons.visibility == View.VISIBLE) {
            return
        }
        binding.etScanCase.setText(scan?.barcode.toString())
        binding.etScanCase.text?.length?.let {
            binding.etScanCase.setSelection(it)
            validateContainer()
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        disableTouch()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        enableTouch()
    }
}