package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.inquiry.location.CaseObj


class CaseAdapter(private val cases: MutableList<CaseObj>):
    RecyclerView.Adapter<CaseAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_case, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val case = cases[position]
        holder.bind(case)
    }

    override fun getItemCount(): Int {
        return cases.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val palletNumberTextView: TextView = itemView.findViewById(R.id.palletNumberTextView)
        private val qtyTextView: TextView = itemView.findViewById(R.id.noOfCasesTextView)
        private val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)

        fun bind(case: CaseObj) {
            palletNumberTextView.text = case.caseNbr
            qtyTextView.text = case.qty.toString()
            statusTextView.text = case.status
        }
    }
}