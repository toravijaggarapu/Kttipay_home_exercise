package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingPalletPickFromReserveDetailedBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.PickInfo
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull

private val TAG = PickFromReserveDetailFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PickFromReserveDetailFragment : BaseFragment(), FlareScannable {

    private lateinit var binding: FragmentInterleavingPalletPickFromReserveDetailedBinding
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private val viewModel: InterLeavingExecuteTaskViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingPalletPickFromReserveDetailedBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initiateView(sharedViewModel.validateContainerResponse?.interLeavingData?.pickInfo)
        observeFlowOnUI { observeApiResults() }
        disableDeviceBack()
        handleTouchAndFocusEvents()
    }

    private fun initiateView(pickInfo: PickInfo?) {
        binding.tvTaskId.text = pickInfo?.taskId.toString()
        binding.tvItem.text = pickInfo?.itemBarcode.toString()
        binding.tvLocation.text = pickInfo?.pickLocBarcode.toString()
        binding.tvDescription.text = pickInfo?.itemDesc.toString()
        binding.tvPalletQty.text = pickInfo?.allocatedQty.toString()
      //  binding.tvStagingLocation.text = "Location"
    }


    /**
     * Monitor the API response data and trigger corresponding actions based on the outcome.
     */
    private suspend fun observeApiResults() {
        viewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is PutwayToReserveTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is PutwayToReserveTaskState.PickNextTask -> {
                    initiateView(state.pickInfo)
                }

                is PutwayToReserveTaskState.ShowError -> showErrorSnackBar(state.errorMessage)
                is PutwayToReserveTaskState.EnableScanCurrentLocation -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PickFromReserveDetailFragmentDirections.actionPickFromReserveDetailFragmentToScanCurrentLocation()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code
                    val action =
                        PickFromReserveDetailFragmentDirections.actionPickFromReserveDetailFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PICK_FROM_RESERVE.code
                    val action =
                        PickFromReserveDetailFragmentDirections.actionPickFromReserveDetailFragmentToPickFromReserve()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }

                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToActive -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    val action =
                        PickFromReserveDetailFragmentDirections.actionPickFromReserveDetailFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) 
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                            validateStagingLocation()

                        } else {
                            binding.tvShowError.visibility = View.VISIBLE
                            binding.tvShowError.text =
                                getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                    binding.tvShowError.visibility = View.GONE
                    validateStagingLocation()

                }
                return@setOnEditorActionListener false
            }

            binding.etStagingLocation.doAfterTextChanged { binding.tvShowError.visibility = View.GONE  }
        }
    }

    private fun validateStagingLocation() {
        if (binding.etStagingLocation.text.toString() == "") {
            viewModel.callExecuteTaskService(
                endTaskRequest = ExecuteTaskRequest(
                    binding.etStagingLocation.text.toString(),
                    sharedViewModel.taskInterLeavingResponse?.sessionId ?: "0",
                    sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                        ?: 0
                )
            )
        } else {
            binding.tvShowError.visibility = View.VISIBLE
            binding.tvShowError.text =
                getString(R.string.lbl_invalid_location)
        }
    }

    private fun disableDeviceBack() {
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.etStagingLocation.text.isNullOrEmpty()) {
            binding.etStagingLocation.setText(scan?.barcode.toString())
            validateStagingLocation()
        }
    }
}