package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingSelectEquipmentBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.utils.Constants.Companion.DISPLAY_NAME
import com.fsc.flare.utils.enableOrDisableField
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull

private val TAG = ScanEquipmentsFragment::class.java.simpleName.toString()

/**
 *  [ScanEquipmentsFragment] class.
 */
@AndroidEntryPoint
class ScanEquipmentsFragment : BaseFragment(), FlareScannable {

    private val viewModel: ScanEquipmentViewModel by viewModels()
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private lateinit var binding: FragmentInterleavingSelectEquipmentBinding
    private lateinit var equipmentType: String
    private var equipmentTypeId: Int = 0
    private var equipmentId: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingSelectEquipmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setFragmentHeader()
        viewModel.getEquipmentType()
        observeFlowOnUI { observeApiResults() }
        handleTouchAndFocusEvents()
    }

    private fun setFragmentHeader() {
        if (arguments != null)
            arguments?.let {
                binding.tvInterleaving.text = it.getString(DISPLAY_NAME)
            }
    }

    /**
     * Monitor the API response data and trigger corresponding actions based on the outcome.
     */
    private suspend fun observeApiResults() {
        viewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is InterLeavingTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is InterLeavingTaskState.ListOfEquipmentType -> {
                    binding.selectEquipmentSpinner.setOptions(state.equipmentType)
                    binding.selectEquipmentSpinner.boolFoo.observe(viewLifecycleOwner) { selection ->
                        equipmentType = selection
                        onClear()
                        binding.etEquipment.enableOrDisableField(true)
                    }
                }

                is InterLeavingTaskState.ShowError -> {
                    showErrorSnackBar(getString(R.string.something_went_wrong_services))
                }

                is InterLeavingTaskState.EnableScanCurrentLocation -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    sharedViewModel.equipmentId = state.equipmentId
                    sharedViewModel.equipmentTypeId = state.equipmentTypeId
                    onClear()
                    val action =
                        ScanEquipmentsFragmentDirections.actionScanEquipmentToScanCurrentLocation()
                    getNavigationController().navigate(action.actionId)
                }

                is InterLeavingTaskState.ShowNoEquipmentError -> {
                    showErrorSnackBar(getString(state.errorMessage))
                }

                is InterLeavingTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code
                    sharedViewModel.equipmentId = state.equipmentId
                    sharedViewModel.equipmentTypeId = state.equipmentTypeId
                    onClear()
                    val action =
                        ScanEquipmentsFragmentDirections.actionScanEquipmentToPalletReplenishmentToCasePick(
                            getString(state.screenTitle)
                        )
                    getNavigationController().navigate(action)
                }

                is InterLeavingTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PICK_FROM_RESERVE.code
                    sharedViewModel.equipmentId = state.equipmentId
                    sharedViewModel.equipmentTypeId = state.equipmentTypeId
                    onClear()
                    val action =
                        ScanEquipmentsFragmentDirections.actionScanEquipmentToInterLeavingPickFromReserve()
                    getNavigationController().navigate(action)
                }

                is InterLeavingTaskState.NavigateToPalletReplenishmentToActive -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    sharedViewModel.equipmentId = state.equipmentId
                    sharedViewModel.equipmentTypeId = state.equipmentTypeId
                    onClear()
                    val action =
                        ScanEquipmentsFragmentDirections.actionScanEquipmentToPalletReplenishmentToCasePick(
                            getString(state.screenTitle)
                        )
                    getNavigationController().navigate(action)
                }

                is InterLeavingTaskState.NavigateToPalletPutawayToReserve -> {
                    binding.etCurrentLocation.enableOrDisableField(true)
                    equipmentTypeId = state.equipmentTypeId
                    equipmentId = state.equipmentId
                    currentLocationHandleTouchAndFocusEvents()
                }
            }
        }
    }

    /**
     * Function to handle touch and focus events for Equipment editText
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.etEquipment.enableOrDisableField(false)
        binding.etCurrentLocation.enableOrDisableField(false)
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        when {
                            binding.etEquipment.isFocused && !binding.etEquipment.text.isNullOrEmpty() -> {
                                viewModel.getCurrentPosition(selectedDescription = equipmentType, equipmentNbr = binding.etEquipment.text.toString() )
                            }
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            binding.etEquipment.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, binding.etEquipment)
                    activity?.applicationContext?.let {
                        viewModel.getCurrentPosition(
                            selectedDescription = equipmentType, equipmentNbr = binding.etEquipment.text.toString()
                        )
                    }
                }
                false
            }
        }
    }

    /**
     * Function to handle touch and focus events for Current Location editText
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun currentLocationHandleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        when {
                            binding.etCurrentLocation.isFocused && !binding.etCurrentLocation.text.isNullOrEmpty() -> {
                                callInterLeavingService(equipmentId, equipmentTypeId)

                            }
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            binding.etCurrentLocation.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, binding.etCurrentLocation)
                    callInterLeavingService(equipmentId, equipmentTypeId)

                }
                false
            }
        }
    }

    /**
     * Initiate interLeaving api call
     */
    private fun callInterLeavingService(equipmentId: Int, equipmentTypeId: Int) {
        val interLeavingPayload = GetInterLeavingRequest(
            equipmentId = equipmentId,
            equipmentTypeId = equipmentTypeId,
            currentLocBarcode = binding.etCurrentLocation.text.toString()
        )
        viewModel.callInterLeavingService(interLeavingPayload = interLeavingPayload)
    }

    /**
     * Method to clear the UI content
     */
    private fun onClear() {
        binding.etEquipment.setText("")
        binding.etCurrentLocation.setText("")
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.tvEquipmentType.text.isEmpty()) {
            showErrorSnackBar(getString(R.string.select_equipment_type_error_msg))
        } else if (binding.etEquipment.text.isNullOrEmpty()) {
            binding.etEquipment.setText(scan?.barcode.toString())
            viewModel.getCurrentPosition(selectedDescription = equipmentType, equipmentNbr = binding.etEquipment.text.toString())
        } else {
            binding.etCurrentLocation.setText(scan?.barcode.toString())
            callInterLeavingService(equipmentId, equipmentTypeId)
        }
    }
}