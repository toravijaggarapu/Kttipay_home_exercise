package com.fsc.flare.ui.fragment.packout

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberResponse
import com.fsc.flare.source.data.dto.inventory.TempLpnsResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.packout.req.*
import com.fsc.flare.source.data.dto.packout.res.*
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.DeKitItem
import com.fsc.flare.source.data.dto.pickingforward.res.DekitPackoutResponse
import com.fsc.flare.source.data.dto.pickingforward.res.KitStationLocationResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.UpcOrSlpResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.receiving.item.UomConversion
import com.fsc.flare.source.repository.PackOutRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PackoutVM"

@HiltViewModel
class PackoutVM @Inject constructor(
    private val packOutRepository: PackOutRepository
) : BaseViewModel() {
    val packOutEndResponse: MutableLiveData<Resource<PackOutEndRes>> = SingleLiveEvent()
    val submitPackoutResponse: MutableLiveData<Resource<PackOutSaveTmpResponse>> = SingleLiveEvent()
    val stagingLocationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val serialValidationResponse: MutableLiveData<Resource<InventoryTaskSerialNumberResponse>> = SingleLiveEvent()
    val validateLocIdResponse: MutableLiveData<Resource<PackoutBase>> = SingleLiveEvent()
    val validateQtyResponse: MutableLiveData<Resource<PackOutQuantityResponse>> = SingleLiveEvent()
    val validateTransactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val validatePalletIdResponse: MutableLiveData<Resource<PackOutPalletResponse>> = SingleLiveEvent()
    val validateCartonIdResponse: MutableLiveData<Resource<PackOutPalletResponse>> = SingleLiveEvent()
    val validateLotNumberResponse: MutableLiveData<Resource<PackOutLotResponse>> = SingleLiveEvent()
    val transactionPIAParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val upcOrSlpResponse: MutableLiveData<Resource<UpcOrSlpResponse>> = SingleLiveEvent()
    val containerInquiryResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()
    val LpnsInTempTableResponse: MutableLiveData<Resource<TempLpnsResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val newContainerResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val printRequestorResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    val printerForTheKitStationResponse: MutableLiveData<Resource<KitStationLocationResponse>> = SingleLiveEvent()
    val printCaseLabelResponse: MutableLiveData<Resource<PrintCaseLabelResponse>> = SingleLiveEvent()
    val workOrderStatusResponse: MutableLiveData<Resource<workOrderStatusResponse>> = SingleLiveEvent()
    val dekitPackoutResponse: MutableLiveData<Resource<DekitPackoutResponse>> = SingleLiveEvent()
    val inventoryContainerResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()


    fun validateLocationId(packOutGetReq: PackOutGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateLocation Request: $packOutGetReq")
        validateLocIdResponse.postValue(Resource.Loading())
        val locIdResponse = packOutRepository.getLocationId(packOutGetReq)
        validateLocIdResponse.postValue(handleLocationResponse(locIdResponse))
    }

    private fun handleLocationResponse(response: Response<PackoutBase>): Resource<PackoutBase>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateLocationResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validatePackOutSerialNumber(packOutSerialNumberGetReq: PackOutSerialNumberGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateSerialNumber Request: $packOutSerialNumberGetReq")
        serialValidationResponse.postValue(Resource.Loading())
        val serialNumberValidationRes = packOutRepository.validatePackOutSerialNumber(packOutSerialNumberGetReq)
        serialValidationResponse.postValue(handleSerialNumberValidationResponse(serialNumberValidationRes))
    }

    private fun handleSerialNumberValidationResponse(response: Response<InventoryTaskSerialNumberResponse>): Resource<InventoryTaskSerialNumberResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumber Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateSerialNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validatePalletId(packOutPalletGetReq: PackOutPalletGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validatePalletId Request: $packOutPalletGetReq")
        validatePalletIdResponse.postValue(Resource.Loading())
        val palletIdResponse = packOutRepository.getPalletId(packOutPalletGetReq)
        validatePalletIdResponse.postValue(handlePalletIdResponse(palletIdResponse))
    }

    private fun handlePalletIdResponse(response: Response<PackOutPalletResponse>): Resource<PackOutPalletResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validatePalletIdResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validatePalletIdResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validateCartonId(packOutPalletGetReq: PackOutPalletGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateCartonId Request: $packOutPalletGetReq")
        validateCartonIdResponse.postValue(Resource.Loading())
        val cartonIdResponse = packOutRepository.getPalletId(packOutPalletGetReq)
        validateCartonIdResponse.postValue(handleCartonIdResponse(cartonIdResponse))
    }

    private fun handleCartonIdResponse(response: Response<PackOutPalletResponse>): Resource<PackOutPalletResponse>? {
        if (response.isSuccessful) {
            //Let is a null safe operator being used
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateCartonIdResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateCartonIdResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validateQtyId(packOutQtyGetReq: PackOutQtyGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateQty Request: $packOutQtyGetReq")
        validateQtyResponse.postValue(Resource.Loading())
        val qtyResponse = packOutRepository.getQty(packOutQtyGetReq)
        validateQtyResponse.postValue(handleQtyIdResponse(qtyResponse))
    }

    private fun handleQtyIdResponse(response: Response<PackOutQuantityResponse>): Resource<PackOutQuantityResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateQtyResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateQtyResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getTransactionParam Request: $transactionParamRequest")
        validateTransactionParamResponse.postValue(Resource.Loading())
        val transactionParamRes = packOutRepository.getTransactionParamDetail(transactionParamRequest)
        validateTransactionParamResponse.postValue(handleTransactionParamResponse(transactionParamRes))
    }

    private fun handleTransactionParamResponse(response: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getTransactionParamResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateStagingLocation Request: $locationClassReq")
        stagingLocationResponse.postValue(Resource.Loading())
        val response = packOutRepository.validateStagingLocation(locationClassReq)
        stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateStagingLocationResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "validateStagingLocation Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun submitPackout(packOutSaveTmp: PackOutSaveTmp) = viewModelScope.launch {
        FlareLog.i(TAG, "submitPackout Request: $packOutSaveTmp")
        submitPackoutResponse.postValue(Resource.Loading())
        val response = packOutRepository.submitPackout(packOutSaveTmp)
        submitPackoutResponse.postValue(handleSubmitPackoutResponse(response))
    }

    private fun handleSubmitPackoutResponse(response: Response<PackOutSaveTmpResponse>): Resource<PackOutSaveTmpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "submitPackoutResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "submitPackout Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateLotNumber(packOutLotGetReq: PackOutLotGetReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateLotNumber Request: $packOutLotGetReq")
        validateLotNumberResponse.postValue(Resource.Loading())
        val response = packOutRepository.getLotNumber(packOutLotGetReq)
        validateLotNumberResponse.postValue(handleLotNumberResponse(response))
    }

    private fun handleLotNumberResponse(response: Response<PackOutLotResponse>): Resource<PackOutLotResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateLotNumberResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun endPackOut(packOutEndReq: PackOutEndReq) = viewModelScope.launch {
        FlareLog.i(TAG, "EndPackOut Request: $packOutEndReq")
        packOutEndResponse.postValue(Resource.Loading())
        val response = packOutRepository.endPackOut(packOutEndReq)
        packOutEndResponse.postValue(handleEndPackOutResponse(response))
    }

    private fun handleEndPackOutResponse(response: Response<PackOutEndRes>): Resource<PackOutEndRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "EndPackOutResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "EndPackOut Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get transaction param details
     */
    fun getPIATransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionPIAParamResponse.postValue(Resource.Loading())
        val response = packOutRepository.getTransactionParamDetail(transactionParamRequest)
        transactionPIAParamResponse.postValue(handleTransactionParamResponse(response))
    }


    fun generatePalletNumber(type: String) = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = packOutRepository.generatePalletCaseNumber(type)
        newPalletDetailResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    fun generateCaseNumber(type: String) = viewModelScope.launch {
        newContainerResponse.postValue(Resource.Loading())
        val response = packOutRepository.generatePalletCaseNumber(type)
        newContainerResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    //Save data into viewmodel variables
    val locationData: MutableLiveData<PackoutBase> = MutableLiveData<PackoutBase>()
    val packOutPalletResponse: MutableLiveData<PackOutPalletResponse> = MutableLiveData<PackOutPalletResponse>()
    val palletReqNumber: MutableLiveData<String> = MutableLiveData<String>()
    val cartonReqNumber: MutableLiveData<String> = MutableLiveData<String>()
    val expiryDate: MutableLiveData<String> = MutableLiveData<String>()
    val lotNumber: MutableLiveData<String> = MutableLiveData<String>()
    var pckPallet: Int = 0
    var casePallet: Int = 0
    val serialNumberList: MutableLiveData<List<String>> = MutableLiveData<List<String>>()
    val itemData: MutableLiveData<String> = MutableLiveData<String>()
    var qty: Int = 0
    val itemId: MutableLiveData<Int> = MutableLiveData<Int>()
    var flags: Int = 0
    val locationBarcodeId: MutableLiveData<Int> = MutableLiveData<Int>()
    val locBarcode: MutableLiveData<String> = MutableLiveData<String>()
    val inventoryType : MutableLiveData<String> = MutableLiveData<String>()
    val tpData: MutableLiveData<Int> = MutableLiveData<Int>()
    val transIdentifier: MutableLiveData<String> = MutableLiveData<String>()
    val itemDesc: MutableLiveData<String> = MutableLiveData<String>()
    val packOutCartonResponse: MutableLiveData<PackOutPalletResponse> = MutableLiveData<PackOutPalletResponse>()
    var promptItemAttribute: Boolean = false
    var tempLpnsList: ArrayList<ContainerDetails> = ArrayList()
    var ispalletUomConfigured :Boolean = false
    var caseQtyForPallet: Int = -1
    var existingPallet: String? = null
    var palletizeCartonsTransValue = 23
    var isKitting = false
    val palletDetailKey = "pallet"
    val newCaseNumberKey = "casenum"
    val palletTransferTypeKey = "PALLET"
    var printRequestorDescList = ArrayList<String>()
    var printRequestorHashmap = HashMap<String, PrinterConfig>()
    val defaultPrinter: MutableLiveData<String> = MutableLiveData<String>()
    val itemBarcode: MutableLiveData<String> = MutableLiveData<String>()
    val itemUomConversions:  MutableLiveData<List<UomConversion>> = MutableLiveData<List<UomConversion>>()

    fun getItemUomConversion(): List<UomConversion>? {
        return itemUomConversions.value
    }


    fun getKitLocationId():Int{
        if(getLocationData().locations.isEmpty())
            return 0
        else
        return getLocationData().locations[0].locationId
    }

    fun setItemUomConversion(itemUomConversions:List<UomConversion>? ){
        this.itemUomConversions.value = itemUomConversions
    }

    fun getItemBarcode(): String {
        return itemBarcode.value!!
    }

    fun setItemBarcode(itemBarcode: String?) {
        this.itemBarcode.value = itemBarcode
    }

    fun getDefaultPrinter(): String?{
        return defaultPrinter.value
    }

    fun setDefaultPrinter(printerName: String?){
        this.defaultPrinter.value = printerName
    }

    fun getTempTableLpnsList() : ArrayList<ContainerDetails>{
        return tempLpnsList
    }

    fun getLocationData(): PackoutBase {
        return locationData.value!!
    }

    fun setLocationData(packOutResponse: PackoutBase) {
        this.locationData.value = packOutResponse
    }

    fun getPalletReqNumber(): String? {
        return palletReqNumber.value
    }

    fun setPalletReqNumber(tmp: String) {
        this.palletReqNumber.value = tmp
    }

    fun getcartonReqNumber(): String {
        return cartonReqNumber.value!!
    }

    fun setCartonReqNumber(tmp: String) {
        this.cartonReqNumber.value = tmp
    }

    fun getSerialNumberList(): List<String>? {
        return serialNumberList.value
    }

    fun setSerialNumberList(serialList: List<String>) {
        this.serialNumberList.value = serialList
    }

    fun getPackOutPalletResponse(): PackOutPalletResponse {
        return packOutPalletResponse.value!!
    }

    fun setPackOutPalletResponse(packOutPalletResponse: PackOutPalletResponse) {
        this.packOutPalletResponse.value = packOutPalletResponse
    }

    fun getExpiryDate(): String? {
        return expiryDate.value
    }

    fun setExpiryDate(tmp: String) {
        this.expiryDate.value = tmp
    }

    fun getExpiryDateFromResponse():String {
        if(validateLotNumberResponse?.value == null || validateLotNumberResponse.value?.data == null || validateLotNumberResponse.value?.data?.batchDetail.isNullOrEmpty()) {
            return ""
        }
        return if(validateLotNumberResponse.value!!.data!!.batchDetail?.get(0)?.expirationDateFormat.isNullOrEmpty()) "" else validateLotNumberResponse.value!!.data!!.batchDetail?.get(0)?.expirationDateFormat.toString()
    }

    fun getManufacturingDate():String {
        if(validateLotNumberResponse?.value == null || validateLotNumberResponse.value?.data == null || validateLotNumberResponse.value?.data?.batchDetail.isNullOrEmpty()) {
            return ""
        }
        return if(validateLotNumberResponse.value!!.data!!.batchDetail?.get(0)?.manufacturingDate.isNullOrEmpty()) "" else validateLotNumberResponse.value!!.data!!.batchDetail?.get(0)?.manufacturingDate.toString()
    }

    fun getlotNumber(): String? {
        return lotNumber.value
    }

    fun setlotNumber(tmp: String) {
        this.lotNumber.value = tmp
    }

    fun getpckPallet(): Int {
        return pckPallet
    }

    fun setpckPallet(tmp: Int) {
        this.pckPallet = tmp
    }

    fun getcasePalletQty(): Int {
        return casePallet
    }

    fun setcasePalletQty(tmp: Int) {
        this.casePallet = tmp
    }

    fun getitemData(): String {
        return itemData.value!!
    }

    fun setitemData(tmp: String) {
        this.itemData.value = tmp
    }

    fun getQuantity(): Int {
        return qty
    }

    fun setQuantity(tmp: Int) {
        this.qty = tmp
    }

    fun getLocId(): Int {
        return locationBarcodeId.value!!
    }

    fun setLocId(tmp: Int) {
        this.locationBarcodeId.value = tmp
    }

    fun getItemId(): Int {
        return itemId.value!!
    }

    fun setItemId(tmp: Int) {
        this.itemId.value = tmp
    }

    fun getFlag(): Int {
        return flags
    }

    fun setFlag(tmp: Int) {
        this.flags = tmp
    }

    fun getLocationBarcode(): String {
        return locBarcode.value!!
    }

    fun setLocationBarcode(tmp: String?) {
        this.locBarcode.value = tmp
    }

    fun getInventoryType(): String?{
        return inventoryType.value
    }

    fun setInventoryType(inventoryType: String?){
        this.inventoryType.value = inventoryType
    }

//    fun setTempLpnsList(list: ArrayList<ContainerDetails>) {
//        this.tempLpnsList.value= list
//    }
//
//    fun getTempLpnsList(): ArrayList<ContainerDetails>? {
//        return tempLpnsList.value
//    }

    fun getTpData(): Int {
        return tpData.value!!
    }

    fun setTpData(tmp: Int) {
        this.tpData.value = tmp
    }

    fun gettransIdentifier(): String {
        return transIdentifier.value!!
    }

    fun settransIdentifier(tmp: String?) {
        this.transIdentifier.value = tmp
    }

    fun getItemDesc(): String {
        return itemDesc.value!!
    }

    fun setItemDesc(tmp: String?) {
        this.itemDesc.value = tmp
    }

    fun setPackOutCartonResponse(packOutCartonResponse: PackOutPalletResponse?) {
        this.packOutCartonResponse.value = packOutCartonResponse
    }

    fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = viewModelScope.launch {
        FlareLog.i(TAG, "validateUPCorSLP Request: itemCode: $itemCode , upcOrSlp: $upcOrSlp")
        upcOrSlpResponse.postValue(Resource.Loading())
        val response = packOutRepository.validateUPCorSLP(itemCode, upcOrSlp)
        upcOrSlpResponse.postValue(handleValidateUPCorSLP(response))
    }

    private fun handleValidateUPCorSLP(response: Response<UpcOrSlpResponse>): Resource<UpcOrSlpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateUPCorSLP Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateUPCorSLP Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getInquiryContainer(locationId: String) = viewModelScope.launch {
        containerInquiryResponse.postValue(Resource.Loading())
        val response = packOutRepository.getInquiryContainer(locationId)
        containerInquiryResponse.postValue(handleContainerInquiryResponse(response))
    }

    private fun handleContainerInquiryResponse(response: Response<ContainerInventoryInquiryResponse>): Resource<ContainerInventoryInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getLpnsInTempTable(locationId: Long) = viewModelScope.launch {
        LpnsInTempTableResponse.postValue(Resource.Loading())
        val response = packOutRepository.getLpnsInTempTable(locationId)
        LpnsInTempTableResponse.postValue(handleLpnsInTempTableResponse(response))
    }

    private fun handleLpnsInTempTableResponse(response: Response<TempLpnsResponse>): Resource<TempLpnsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LpnsInTempTableResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LpnsInTempTableResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get printer requestor config list
     */
    fun getPrintRequesterList(printerConfigRequest: PrinterConfigRequest) = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = packOutRepository.getPrintRequestorListForPackout(printerConfigRequest)
        printRequestorResponse.postValue(handlePrintRequestorListResponse(response))
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handlePrintRequestorListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getPrinterForTheKitStation(locationId:Int) = viewModelScope.launch {
        printerForTheKitStationResponse.postValue(Resource.Loading())
        val response = packOutRepository.getPrinterForTheKitStation(locationId)
        printerForTheKitStationResponse.postValue(handleKitStationLocationResponse(response))
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handleKitStationLocationResponse(response: Response<KitStationLocationResponse>): Resource<KitStationLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleKitStationLocationResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleKitStationLocationResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun printCaseLabel(printCaseLabelPackoutReq: PrintCaseLabelPackoutReq ) = viewModelScope.launch {
        printCaseLabelResponse.postValue(Resource.Loading())
        val response = packOutRepository.printCaseLabelsFromPackout(printCaseLabelPackoutReq)
        printCaseLabelResponse.postValue(handlePrintCaseLabelResponse(response))
    }


    /**
     * method to handle print case labels  response
     */
    private fun handlePrintCaseLabelResponse(response: Response<PrintCaseLabelResponse>): Resource<PrintCaseLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handlePrintCaseLabelResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handlePrintCaseLabelResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getWorkOrderStatus(kitLocationId: Int) = viewModelScope.launch {
        workOrderStatusResponse.postValue(Resource.Loading())
        val response = packOutRepository.getWorkOrderStatus(kitLocationId)
        workOrderStatusResponse.postValue(handleWorkOrderStatusResponse(response))
    }

    private fun handleWorkOrderStatusResponse(response: Response<workOrderStatusResponse>): Resource<workOrderStatusResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleWorkOrderStatusResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleWorkOrderStatusResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun deKitPackout(kitLocationId: Int) = viewModelScope.launch {
        dekitPackoutResponse.postValue(Resource.Loading())
        val response = packOutRepository.deKitPackout(kitLocationId)
        dekitPackoutResponse.postValue(handledeKitPackoutResponse(response))
    }

    private fun handledeKitPackoutResponse(response: Response<DekitPackoutResponse>): Resource<DekitPackoutResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleDekitPackoutResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleDekitPackoutResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        inventoryContainerResponse.postValue(Resource.Loading())
        val response = packOutRepository.getContainer(container, itemInfo)
        inventoryContainerResponse.postValue(handleContainerResponse(response))
    }

    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    var lotNumberSelectedFromDeKitting = false
    var lockCodeSelected = ""
    var currentItemBarCode = ""

    var dekitItems = mutableListOf<DeKitItem>()
    var containerLockCode = ""
    var isDekitting = false

    val ASN_LOCK_CODE = "ASN"

    fun clearKittingData(){
        isDekitting = false;
        containerLockCode = ""
        dekitItems.clear()
    }

    fun getLotNumbers(itemBarCode:String):List<String> {
        val lotNumbersList = emptyList<String>()
        try {
            var list =  dekitItems.filter { dekitItem:DeKitItem -> (!dekitItem.itemBarcode.isNullOrEmpty() && dekitItem.itemBarcode.equals(itemBarCode)) }
            return list.first().lotNumbers
        }
        catch (e:Exception){
            e.printStackTrace()
        }
        return lotNumbersList
    }

    fun getInvTypes(itemBarCode:String):List<String> {
        val invTypesList = emptyList<String>()
        try {
            var list =  dekitItems.filter { dekitItem:DeKitItem -> (!dekitItem.itemBarcode.isNullOrEmpty() && dekitItem.itemBarcode.equals(itemBarCode)) }
            if(!list.isEmpty()) {
                return list.first().inventoryTypes
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
        return invTypesList
    }

    fun isItemHasMultipleLotNumbers():Boolean{
       return getLotNumbers(currentItemBarCode).size > 1
    }

    fun isItemHasMultipleInventoryTypes():Boolean{
        return getInvTypes(currentItemBarCode).size > 1
    }
}