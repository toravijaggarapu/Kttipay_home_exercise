package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.login.GatewayToken
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.login.UserInfo
import com.fsc.flare.source.data.dto.login.externaluser.ExternalUserResponse
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Named

class AuthenticationRepository @Inject constructor(
    private val apiGatewayInterfaceUserId: ApiGatewayInterface,
    private val apiGateway: ApiGatewayInterface,
    @Named("basic") private val apiGatewayInterface: ApiGatewayInterface,
    @Named("gateway") private val apiGatewayTokenInterface: ApiGatewayInterface,
    @Named("auth") private val apiGatewayUserInfoInterface: ApiGatewayInterface,
    @Named("tempauth") private val apiGatewayTempUserInfoInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun fetchAppProperties() = apiGatewayInterface.fetchAppProperties()

    suspend fun fetchGatewayToken(apiGatewayClientId: String, apiGatewaySecret: String): Response<GatewayToken> =
        apiGatewayTokenInterface.fetchGatewayToken(apiGatewayClientId, apiGatewaySecret, "client_credentials", "PP_Portal_ReadWrite")

    suspend fun fetchUserInfo(token: String): Response<UserInfo> =
        apiGatewayUserInfoInterface.fetchUserInfo(
            "Bearer $token"
        )

    suspend fun fetchTempUserInfo(token: String): Response<UserInfo> =
        apiGatewayTempUserInfoInterface.fetchUserInfo(
            "Bearer $token"
        )

    suspend fun fetchExternalUserDetails(userType: String, usrId: String): Response<ExternalUserResponse> =
        apiGatewayInterfaceUserId.fetchExternalUserID(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "undefined")!!,
            usrId,
            userType
        )

    suspend fun updateLastLoginTimeDetails(usrId: Int): Response<LangUpdateResponse> =
        apiGatewayInterfaceUserId.updateLastLoginTime(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            usrId =usrId
        )

    suspend fun getLookUps(inventoryTypesRequest: LookUpsRequest) = apiGateway.getLookUps(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = inventoryTypesRequest.cusId,
        fcyId = inventoryTypesRequest.fcyId,
        buId = inventoryTypesRequest.buId,
        lookupNames = inventoryTypesRequest.lookupNames
    )
}