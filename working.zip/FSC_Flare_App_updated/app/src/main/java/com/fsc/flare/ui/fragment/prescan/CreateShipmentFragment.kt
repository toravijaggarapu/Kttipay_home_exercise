package com.fsc.flare.ui.fragment.prescan

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCreateShipmentBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.prescan.vendor.PrescanGetCustomerDetailsResponse
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.CUSTOMER_DETAILS
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.DEFAULT_VENDOR_CODE
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CreateShipmentFragment::class.java.simpleName.toString()

/**
 * A Fragment for select customer name ,customer number , customer Address .
 * this fragment is launched from Prescan fragment.
 */
@AndroidEntryPoint
class CreateShipmentFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var fragmentCreateShipmentBinding: FragmentCreateShipmentBinding
    private val viewModel: PreScanViewModel by activityViewModels()
    private lateinit var defaultVendorCode: String

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fragmentCreateShipmentBinding =
            FragmentCreateShipmentBinding.inflate(inflater, container, false)
        return fragmentCreateShipmentBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        callLookUpAPI()
        vendorCustomerDetails()
        setClickListeners()
        subscribeObserver()
        setRmaNumberToView()
        setReturnTypeDataToDropDown()
    }

    /**
     * method to attach the listener to createShipment button
     */
    private fun setClickListeners() {
        fragmentCreateShipmentBinding.btnCreateShipment.setOnClickListener {
            navigateToProcessPrescanFragment()
        }
    }

    /**
     * method to enable create shipment button
     */
    private fun enableCreateShipmentButton() {
        fragmentCreateShipmentBinding.btnCreateShipment.isEnabled =
            fragmentCreateShipmentBinding.customerDetailsSpinner.text.isNotEmpty()
    }


    /**
     *  A Override method for show home ,logout,account menu icon in action bar
     */
    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * method to call lookup  API call for Default vender
     */
    private fun callLookUpAPI() {
        viewModel.getPrescanDefaultVendor()
    }

    /**
     * method to get vendor Customer Details from API call
     */
    private fun vendorCustomerDetails() {
        viewModel.vendorCustomerDetails()
    }

    /**
     * method to subscribe Observer for get customer details from vender lookup api call
     * And get default vendor code from lookup default vendor api call
     */
    private fun subscribeObserver() {
        viewModel.vendorORCustomerDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { vendorsResponse ->
                        handleVendorResponse(vendorsResponse)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    FlareLog.e(TAG, "Failed to fetch vendor or CustomerDetails Response")
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.defaultVendorResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.lookups?.firstOrNull { it.lookupCodes[0].lookupCode.isNotEmpty() }
                        ?.let { lookUp ->
                            defaultVendorCode = lookUp.lookupCodes[0].lookupCode
                            FlareLog.i(TAG, "default vendor success: $defaultVendorCode")
                        }
                }

                is Resource.Error -> {
                    FlareLog.e(TAG, "default vendor Response error: ${response.message}")
                    handleErrorMessage(response)
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to handle vendor api response
     */
    private fun handleVendorResponse(vendorsResponse: PrescanGetCustomerDetailsResponse) {
        if (vendorsResponse.success) {
            viewModel.customerDetailsListItem.observe(viewLifecycleOwner) {
                fragmentCreateShipmentBinding.customerDetailsSpinner.text = it
                enableCreateShipmentButton()
            }
        }
    }

    /**
     * Method to handle error api response
     */
    private fun handleErrorMessage(response: Resource<LookUps>) {
        hideProgressBar()
        response.message?.let { message ->
            showErrorSnackBar(message)
        }
    }

    /**
     * method to navigate to process prescan fragment
     */
    private fun navigateToProcessPrescanFragment() {
        FlareLog.i(TAG, "navigateToProcessPrescanFragment called")
        val bundle = bundleOf(
            CUSTOMER_DETAILS to fragmentCreateShipmentBinding.customerDetailsSpinner.text,
            DEFAULT_VENDOR_CODE to defaultVendorCode,
        )
        getNavigationController().navigate(
            R.id.action_createShipmentFragment_to_processPreScanFragment,
            bundle
        )
    }

    /**
     * method to get RMA number
     */
    private fun setRmaNumberToView() {
        fragmentCreateShipmentBinding.tvRmaNumber.text =
            viewModel.validateRMAResponse.customerASNNumber
    }

    /**
     * method to set return type values to dropDown
     */
    private fun setReturnTypeDataToDropDown() {
        fragmentCreateShipmentBinding.returnTypeDropDown.setSelectedValue(
            viewModel.getSelectedReturnType()
        )
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        fragmentCreateShipmentBinding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        fragmentCreateShipmentBinding.progressBar.visibility = View.GONE
    }
}
