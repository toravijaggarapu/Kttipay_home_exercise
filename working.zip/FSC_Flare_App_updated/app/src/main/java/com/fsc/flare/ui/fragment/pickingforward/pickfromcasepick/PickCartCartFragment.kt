package com.fsc.flare.ui.fragment.pickingforward.pickfromcasepick

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartCartBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountHeader
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.ui.fragment.kitting.ListDialogFragment
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.LOCATION_IS_EMPTY
import com.fsc.flare.ui.fragment.pickingforward.pickfromactive.TASK_CYCLE_COUNT_PENDING
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartCartFragment"

private const val NEXT_TASK_AVAILABLE = "ERR-TASK-044"
private const val STAGE_CART = "ERR-TASK-045"
private const val NO_TASK_AVAILABLE = "ERR-TASK-046"

@AndroidEntryPoint
class PickCartCartFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartCartBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPickCartCartBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null) {
            binding.cart.text = data.cartNbr
            if (taskData != null) {
                binding.taskId.text = taskData.taskId.toString()
                binding.item.text = taskData.itemCode
                binding.description.text = taskData.itemDescription
                binding.container.text = if (viewModel.givenCartonNbr.isNullOrEmpty()) taskData.containerNbr else viewModel.givenCartonNbr
                binding.pickLocation.text = taskData.locationBarcode
                binding.pickQty.text = String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
                if (taskData.itemLotTracked == "1") {
                    binding.lotTv.visibility = View.VISIBLE
                    binding.lot.visibility = View.VISIBLE
                    binding.lot.text = taskData.lotNumber
                }
                if (taskData.itemExpDateTracked == "1" && !taskData.expDate.isNullOrEmpty()) {
                    binding.dateTv.visibility = View.VISIBLE
                    binding.date.visibility = View.VISIBLE
                    binding.date.text = formatDate(taskData.expDate!!)
                }
                if (viewModel.scannedSerialNumbers.isNotEmpty()) {
                    binding.serialNumberGroup.visibility = View.VISIBLE
                    binding.tvSerialNumberValue.text = String.format(
                        "%d %s",
                        viewModel.scannedSerialNumbers.size,
                        taskData.ibContainerUom
                    )
                }
            }
        }
        binding.etCart.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Cart field focused")
                validateCart()
            }
            false
        }
        binding.etCart.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.txtCartRes.text = null
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Cart field focused")
                    validateCart()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.tvSerialNumberView.setOnClickListener {
            displaySerialNumberView(viewModel.scannedSerialNumbers)
        }
    }

    private fun validateCart() {
        if (!binding.etCart.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etCart)
            val data = viewModel.getPickTask()
            val taskData = viewModel.getPickTaskDetails()
            if (data != null) {
                if (taskData != null) {
                    if (binding.etCart.text.toString() == data.cartNbr) {
                        callUnitPickCompleteAPI(taskData.taskQty)
                    } else {
                        binding.txtCartRes.text = getString(R.string.wrong_cart)
                        binding.etCart.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etCart)
                    }
                }
            }
        }
    }

    private fun callUnitPickCompleteAPI(taskQty: Int) {
        val data = viewModel.getPickTask()
        val taskData = viewModel.getPickTaskDetails()
        if (data != null && taskData != null) {
            viewModel.taskcasepickcomplete(
                TaskCasePickCompleteReq(
                    allocationType = taskData.allocationType,
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    cartNumber = data.cartNbr,
                    cartId = data.cartId,
                    containerId = taskData.containerId,
                    containerNumber = taskData.containerNbr,
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    itemCode = taskData.itemCode,
                    itemDescription = taskData.itemDescription,
                    itemId = taskData.itemId,
                    pickQty = taskQty,
                    pickQtyUom = taskData.taskQtyUom,
                    taskDetId = taskData.taskDetId,
                    taskId = taskData.taskId,
                    lotNumber = taskData.lotNumber,
                    expDate = formatDate(taskData.expDate ?: ""),
                    reasonCode = lockCode,
                    orderType = viewModel.orderType
                )
            )
        }
    }

    private fun subscribeObservers() {
        viewModel.taskCasePickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskCasePickCompleteRes ->
                        if (taskCasePickCompleteRes.success != null && taskCasePickCompleteRes.success) {
                            FlareLog.i(
                                TAG,
                                "taskCasePickComplete success: $taskCasePickCompleteRes"
                            )
                            if (!taskCasePickCompleteRes.zeroLocation.isNullOrEmpty() && taskCasePickCompleteRes.zeroLocation == "Y") {
                                showZeroLocationAlert(taskCasePickCompleteRes)
                            } else {
                                navigateToNextScreen(taskCasePickCompleteRes)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskCasePickComplete error: $message")
                        if (message.contains("_")) {
                            val msgArray = message.split("_")
                            if (msgArray.isNotEmpty()) {
                                if (msgArray[0] == TASK_CYCLE_COUNT_PENDING) {
                                    showCycleCountPendingAlert()
                                } else {
                                    showCustomDialog(msgArray[1]) {
                                        when {
                                            msgArray[0] == NEXT_TASK_AVAILABLE -> {
                                                callTaskPickAPI()
                                            }

                                            msgArray[0] == STAGE_CART -> {
                                                Handler(Looper.getMainLooper()).postDelayed(
                                                    {
                                                        val action =
                                                            PickCartCartFragmentDirections.actionPickCartCartFragmentToPickCartStagingLocFragment()
                                                        val navOptions = NavOptions.Builder()
                                                            .setPopUpTo(
                                                                R.id.pickCartStagingLocFragment,
                                                                true
                                                            ).build()
                                                        getNavigationController().navigate(
                                                            action,
                                                            navOptions
                                                        )
                                                    },
                                                    Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME
                                                )
                                            }

                                            msgArray[0] == NO_TASK_AVAILABLE -> {
                                                navigateToTaskGroup()
                                            }

                                            msgArray[0] == LOCATION_IS_EMPTY -> {
                                                // simply dismiss the dialog from base fragment
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            binding.txtCartRes.text = message
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToNextScreen(taskCasePickCompleteRes: TaskCasePickCompleteRes) {
        binding.etCart.text?.clear()
        if (taskCasePickCompleteRes.taskDetails != null) {
            viewModel.updateOrderType(taskCasePickCompleteRes.orderType)
            viewModel.setPickTaskDetails(taskCasePickCompleteRes.taskDetails)
            val action =
                PickCartCartFragmentDirections.actionPickCartCartFragmentToPickCartPickLocationFragment()
            val navOptions =
                NavOptions.Builder().setPopUpTo(R.id.pickCartPickLocationFragment, true).build()
            getNavigationController().navigate(action, navOptions)
        } else {
            taskCasePickCompleteRes.message?.let {
                showSuccessSnackBarStd(it) {
                    val action =
                        PickCartCartFragmentDirections.actionPickCartCartFragmentToPickCartStagingLocFragment()
                    val navOptions =
                        NavOptions.Builder().setPopUpTo(R.id.pickCartStagingLocFragment, true)
                            .build()
                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    private fun showZeroLocationAlert(taskCasePickCompleteRes: TaskCasePickCompleteRes) {
        val data = viewModel.getPickTaskDetails()
        if (data != null) {
            showAlertDialog("",
                getString(R.string.lbl_does_the_location_empty_after_picking, data.locationBarcode),
                getString(R.string.alert_button_yes),
                getString(R.string.alert_button_no),
                object : AlertDialogClickListener {
                    override fun onPositiveButtonClick() {
                        navigateToNextScreen(taskCasePickCompleteRes)
                    }

                    override fun onNegativeButtonClick() {
                        generateCycleCountToVerifyZeroLocation()
                        navigateToNextScreen(taskCasePickCompleteRes)
                    }
                }
            )
        }
    }

    private fun generateCycleCountToVerifyZeroLocation() {
        viewModel.getPickTaskDetails()?.let {
            viewModel.generateCycleCountToVerifyZeroLocation(
                CycleCountTriggerRequest(
                    CycleCountHeader(
                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    ), skipErrIfCCPending = true
                ), locationId = it.pullLocationId
            )
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etCart.setText(scan?.barcode.toString())
        binding.etCart.text?.length?.let {
            binding.etCart.setSelection(it)
        }
        FlareLog.i(TAG, "Cart field focused")
        validateCart()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

    private fun callTaskPickAPI() {
        subscribeTaskDetailsObserver()
        viewModel.getTaskPick(
            TaskPickReq(
                allocationType = sharedPreferences.getString(
                    PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE,
                    null
                )!!,
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskGroup = sharedPreferences.getString(
                    PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE,
                    null
                )!!,
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }

    private fun subscribeTaskDetailsObserver() {
        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success != null && taskReplenResponse.success) {
                            viewModel.isComingFromPickCartFlow = false
                            FlareLog.i(TAG, "taskPick success: $taskReplenResponse")
                            if (taskReplenResponse.cartNbr == null) {
                                val action =
                                    PickCartCartFragmentDirections.actionPickCartCartFragmentToBuildCartPalletFragment()
                                getNavigationController().navigate(action)
                            } else {
                                viewModel.setPickTask(taskReplenResponse)
                                if (taskReplenResponse.taskDetails != null) {
                                    viewModel.setPickTaskDetails(taskReplenResponse.taskDetails)
                                    val action =
                                        PickCartCartFragmentDirections.actionPickCartCartFragmentToPickCartPickLocationFragment()
                                    val navOptions = NavOptions.Builder()
                                        .setPopUpTo(R.id.pickCartPickLocationFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                } else {
                                    navigateToTaskGroup()
                                }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                        navigateToTaskGroup()
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.cycleCountTriggerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { cycleCountTriggerResponse ->
                        if (cycleCountTriggerResponse.success) {
                            FlareLog.i(
                                TAG,
                                "cycleCountTriggerResponse Success: $cycleCountTriggerResponse.message"
                            )
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "cycleCountTriggerResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToTaskGroup() {
        Handler(Looper.getMainLooper()).postDelayed({
            val action =
                PickCartCartFragmentDirections.actionPickCartCartFragmentToBuildCartTaskGroup()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
            getNavigationController().navigate(action, navOptions)
        }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
    }

    var lockCode: String = ""

    private fun showCycleCountPendingAlert() {
        viewModel.getInventoryReasonCodes()
        showAlertDialog(
            "",
            getString(R.string.cycle_count_pending_for_location),
            getString(R.string.alert_button_ok),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    val dialogView =
                        ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
                    val dialog = Dialog(fragmentContext)
                    dialog.setContentView(dialogView.root)
                    dialog.setCancelable(false)
                    dialog.show()
                    val lp = WindowManager.LayoutParams()
                    lp.copyFrom(dialog.window!!.attributes)
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT
                    lp.height = ViewGroup.LayoutParams.MATCH_PARENT
                    dialog.window!!.attributes = lp
                    dialogView.btnCancel.setOnClickListener {
                        dialog.dismiss()
                        lockCode = ""
                    }
                    dialogView.btnOk.setOnClickListener {
                        callUnitPickCompleteAPI(0)
                        dialog.dismiss()
                    }
                    viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
                        when (response) {
                            is Resource.Success -> {
                                hideProgressBar()
                                response.data?.let { lookUpResponse ->
                                    FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                                    val inventoryLockList = ArrayList<String>()
                                    val inventoryLockCodeList = ArrayList<String>()
                                    lookUpResponse.lookups.forEach { lookUp ->
                                        lookUp.lookupCodes.forEach {
                                            inventoryLockList.add(it.lookupCodeDescription)
                                            inventoryLockCodeList.add(it.lookupCode)
                                        }
                                    }
                                    viewModel.setInventoryLocksList(lookUpResponse.lookups)
                                    dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                                }
                            }

                            is Resource.Error -> {
                                hideProgressBar()
                                response.message?.let { message ->
                                    FlareLog.e(TAG, "lookUpResponse Error: $message")
                                }
                            }

                            is Resource.Loading -> {
                                showProgressBar()
                            }
                        }
                    }
                    dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
                        val lookups = viewModel.getInventoryLocksList()
                        lookups.forEach { lookupCode ->
                            lookupCode.lookupCodes.forEach { lookup ->
                                if (lookup.lookupCodeDescription == selection) {
                                    FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                                    lockCode = lookup.lookupCode
                                    dialogView.btnOk.isEnabled = true
                                }
                            }
                        }
                    }
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun displaySerialNumberView(scannedSerialList: List<String>) {
        val dialog = ListDialogFragment(getString(R.string.serial_numbers), scannedSerialList)
        dialog.show(childFragmentManager, "listDialog")
    }
}