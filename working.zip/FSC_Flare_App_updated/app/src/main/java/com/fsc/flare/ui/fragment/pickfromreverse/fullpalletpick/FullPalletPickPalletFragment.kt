package com.fsc.flare.ui.fragment.pickfromreverse.fullpalletpick

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentFullpalletPickPalletPageBinding
import com.fsc.flare.databinding.ReasonCodeDropdownDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = FullPalletPickPalletFragment::class.simpleName.toString()

@AndroidEntryPoint
class FullPalletPickPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private val pickingForwardViewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentFullpalletPickPalletPageBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFullpalletPickPalletPageBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        arguments?.getBoolean(IS_RTV)?.let { viewModel.isRTV = it }
        subscribeObservers()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun validateLocation() {
        val taskData = getPickTaskDetails()
        if (taskData != null) {
            viewModel.validateLocationDetails(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    taskData.locationBarcode,
                    viewModel.getLocationValue(taskData.allocationType)
                )
            )
        } else {
            showErrorSnackBar("Location Details Not found")
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Location field focused")
                    validateLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        initData()
        binding.scanPalletVal.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Pallet field focused")
                validateLocation()
            }
            false
        }
        binding.scanPalletVal.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.scanPalletResponse.text = null
            }
        })

        binding.shortPick.setOnClickListener {
            showShortPickActionAlert()
        }
    }

    private fun validatePallet() {
        if (binding.scanPalletVal.text.toString().trim().isNotEmpty()) {
            viewModel.validatePalletOverride(
                ValidatePalletOverrideRequest(
                    givenContainerNbr = binding.scanPalletVal.text.toString().trim(),
                    taskDetId = getPickTaskDetails()?.taskDetId,
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
            viewModel.setScannedPallet(binding.scanPalletVal.text.toString().trim())
        } else {
            binding.scanPalletResponse.text = getString(R.string.pallet_is_required)
            binding.scanPalletVal.selectAll()
        }
    }

    private fun initData() {
        val taskData: TaskDetails? = getPickTaskDetails()
        if (taskData != null) {
            binding.taskId.text = taskData.taskId.toString()
            binding.itemVal.text = taskData.itemCode
            binding.itemDescVal.text = taskData.itemDescription
            binding.pickQtyVal.text = String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
            binding.locationVal.text = taskData.locationBarcode
            binding.palletQtyVal.text = String.format("%d %s", taskData.ibContainerQty, taskData.ibContainerUom)
        } else {
            showErrorSnackBar("Task Details are not found")
        }
    }

    /**
     * get taskDetails data based on RTV/nonRTV flow
     */
    private fun getPickTaskDetails(): TaskDetails? {
        val taskData: TaskDetails? = if (viewModel.isRTV) {
            pickingForwardViewModel.getPickTaskDetails()
        } else {
            viewModel.getPickTaskDetails()
        }
        return taskData
    }

    private fun showShortPickActionAlert() {
        val taskData = getPickTaskDetails()
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(
            R.string.short_pick_for_pallet_alert,
            taskData?.taskQty.toString() + " " + taskData?.taskQtyUom,
            "0 " + taskData?.taskQtyUom
        )
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(getString(R.string.alert_button_yes)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            viewModel.getInventoryReasonCodes()
            showReasonCode()
        }

        builder.setNegativeButton(getString(R.string.alert_button_no)) { dialogInterface, _ ->
            dialogInterface.dismiss()

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showReasonCode() {
        var lockCode = ""
        val dialogView = ReasonCodeDropdownDialogBinding.inflate(LayoutInflater.from(context))
        val dialog = Dialog(fragmentContext)
        dialog.setContentView(dialogView.root)
        dialog.setCancelable(false)
        dialog.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        dialog.window!!.attributes = lp

        viewModel.inventoryLocksResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val inventoryLockList = ArrayList<String>()
                        val inventoryLockCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                inventoryLockList.add(it.lookupCodeDescription)
                                inventoryLockCodeList.add(it.lookupCode)
                            }
                        }
                        viewModel.setInventoryLocksList(lookUpResponse.lookups)
                        dialogView.reasonCodeDropDown.setOptions(inventoryLockList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        dialogView.reasonCodeDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val lookups = viewModel.getInventoryLocksList()
            lookups.forEach { lookupCode ->
                lookupCode.lookupCodes.forEach { lookup ->
                    if (lookup.lookupCodeDescription == selection) {
                        FlareLog.d(TAG, "lockCodeDropDownCode: ${lookup.lookupCode}")
                        lockCode = lookup.lookupCode
                        dialogView.btnOk.isEnabled = true
                    }
                }
            }
        }
        dialogView.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogView.btnOk.setOnClickListener {
            callShortPickAPI(lockCode)
            dialog.dismiss()
        }
    }

    private fun callShortPickAPI(lockCode: String) {
        val taskData = getPickTaskDetails()

        val taskGroup: String = if (viewModel.isRTV) {
            sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_CODE, null) ?: ""
        } else {
            sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null) ?: ""
        }
        taskData?.let {
            PalletPickFromReserveRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                allocationType = taskData.allocationType.toInt(),
                taskGroup = taskGroup,
                pickQty = "0",
                pickQtyUom = taskData.pickQtyUom ?: "",
                reasonCode = lockCode,
                palletNumber = taskData.containerNbr,
                taskId = taskData.taskId,
                taskDetId = taskData.taskDetId,
                itemLotTracked = taskData.itemLotTracked,
                itemExpDateTracked = taskData.itemExpDateTracked,
                itemSerialTracked = taskData.itemSerialTracked,
                stageLocId = 0,
                orderType = viewModel.orderType
            )
        }?.let {
            viewModel.palletPickComplete(
                it
            )
        }
    }

     private fun subscribeObservers() {

         viewModel.locationDetailsResponse.observe(viewLifecycleOwner) { response ->
             when (response) {
                 is Resource.Success -> {
                     hideProgressBar()
                     response.data?.let { locationDetailsResponse ->
                         if (locationDetailsResponse.success) {
                             FlareLog.i(TAG, "locationDetailsResponse success: $locationDetailsResponse")
                             if (locationDetailsResponse.locations.isNotEmpty()) {
                                 val reserveLocation = locationDetailsResponse.locations[0]
                                 if (sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)) {
                                     if (reserveLocation.lockCode == "CC") {
                                         val msg = getString(R.string.cycle_count_progress_for_location)
                                         showCyclePendingAlert(msg)
                                     } else {
                                         validatePallet()
                                     }
                                 } else {
                                     if (reserveLocation.cycleCountPending == "Y") {
                                         val msg = getString(R.string.cycle_count_pending_for_location)
                                         showCyclePendingAlert(msg)
                                     } else {
                                         validatePallet()
                                     }
                                 }

                             } else {
                                 showErrorSnackBar("Invalid Reserve Location")
                             }
                         }
                     }
                 }
                 is Resource.Error -> {
                     hideProgressBar()
                     response.message?.let { message ->
                         FlareLog.e(TAG, "stagingLocationResponse error: $message")
                         showErrorSnackBar(message)
                     }
                 }
                 is Resource.Loading -> {
                     showProgressBar()
                 }
             }
         }

        viewModel.validatePalletOverrideResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validatePalletOverrideResponse ->
                        val taskData = getPickTaskDetails()
                        FlareLog.i(TAG, "validatePalletOverrideResponse success: $response")
                        hideProgressBar()
                        if (taskData != null) {
                            zeroLocationPromptCall(
                                taskData.pullLocationId,
                                validatePalletOverrideResponse.cartonInfo.containerId.toLong()
                            )
                        } else {
                            binding.scanPalletResponse.text =
                                getString(R.string.task_details_are_not_found)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "validatePalletOverrideResponse Error: $message")
                        if (message != null) {
                            binding.scanPalletResponse.text = message
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.zeroLocationPromptResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { zeroLocationPromptResponse ->
                        FlareLog.i(
                            TAG,
                            "zeroLocationPromptResponse Response: $zeroLocationPromptResponse"
                        )
                        if (zeroLocationPromptResponse != null) {
                            if (!zeroLocationPromptResponse.zeroQtyLocation.isNullOrEmpty() && zeroLocationPromptResponse.zeroQtyLocation == "Y") {
                                getPickTaskDetails()?.let { showZeroLocationAlert(it.locationBarcode) }
                            } else {
                                navigateToStage()
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "zeroLocationPromptResponse Error: $message")
                        if (message != null) {
                            binding.scanPalletResponse.text = message
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }


        viewModel.palletPickCompleteResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { palletPickCompleteResponse ->
                        FlareLog.i(TAG, "palletPickCompleteResponse Response: $palletPickCompleteResponse")
                        if (palletPickCompleteResponse != null) {
                            if (palletPickCompleteResponse.success) {
                                if (palletPickCompleteResponse.message != null)
                                    showSuccessSnackBarStd(palletPickCompleteResponse.message) {
                                        val bundle : Bundle = if (viewModel.isRTV) {
                                            bundleOf(IS_RTV to true)
                                        }else{
                                            bundleOf(IS_RTV to false)
                                        }
                                        if (palletPickCompleteResponse.taskDetails != null) {

                                            if (palletPickCompleteResponse.taskDetails.allocationType != "31" && palletPickCompleteResponse.taskDetails.stageLocationName.isNullOrEmpty()) {
                                                noStageLocationDetailsError(
                                                    palletPickCompleteResponse.taskDetails
                                                )
                                            } else {
                                                val taskDetails = palletPickCompleteResponse.taskDetails
                                                if (viewModel.isRTV) {
                                                    pickingForwardViewModel.setPickTaskDetails(taskDetails)
                                                } else {
                                                    viewModel.setPickTaskDetails(taskDetails)
                                                }
                                                val action =
                                                    FullPalletPickPalletFragmentDirections.actionFullPalletPickFromReservePalletPageToFullPalletPickFromReservePalletPage()
                                                val navOptions = NavOptions.Builder().setPopUpTo(
                                                    R.id.fullPalletPickFromReservePalletPage,
                                                    true
                                                ).build()
                                                getNavigationController().navigate(
                                                    action.actionId,
                                                    bundle,
                                                    navOptions
                                                )
                                            }
                                        } else if (viewModel.isRTV) {
                                            val action =
                                                FullPalletPickPalletFragmentDirections.actionFullPalletPickFromReservePalletPageToBuildCartTaskGroup()
                                            val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartTaskGroup, true).build()
                                            getNavigationController().navigate(
                                                action.actionId,
                                                bundle,
                                                navOptions
                                            )
                                        } else {
                                            val action =
                                                FullPalletPickPalletFragmentDirections.actionFullPalletPickFromReservePalletPageToTivoTaskGroupFragment()
                                            val navOptions = NavOptions.Builder()
                                                .setPopUpTo(R.id.TivoTaskGroupFragment, true)
                                                .build()
                                            getNavigationController().navigate(action, navOptions)
                                        }
                                    }
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "TaskPalletPickComplete Error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showZeroLocationAlert(locationBarcode: String) {
        showAlertDialog("",
            getString(R.string.lbl_does_the_location_empty_after_picking, locationBarcode),
            getString(R.string.alert_button_yes),
            getString(R.string.alert_button_no),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    navigateToStage()
                }
                override fun onNegativeButtonClick() {
                   viewModel.generateCycleCount = true
                    navigateToStage()
                }
            })
    }

    private fun zeroLocationPromptCall(locationId: Long, palletId: Long) {
        val skipPalletIdList: ArrayList<Long> = ArrayList()
        skipPalletIdList.add(palletId)
        viewModel.zeroLocationPromptCall(locationId,skipPalletIdList)
    }

    private fun navigateToStage() {
        if (binding.scanPalletVal.text.toString().trim().isNotEmpty()) {
            val action =
                FullPalletPickPalletFragmentDirections.actionFullPalletPickFromReservePalletPageToFullPalletPickFromReserveStageLocationPage()
            getNavigationController().navigate(action)
        }
    }

    private fun showCyclePendingAlert(msg: String) {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(getString(R.string.alert_button_zero_pick)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            viewModel.getInventoryReasonCodes()
            showReasonCode()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun noStageLocationDetailsError(taskDetails: TaskDetails) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(R.string.stage_location_not_added, taskDetails.taskId.toString(), taskDetails.customerOrderNumber.toString())
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            Handler(Looper.getMainLooper()).postDelayed({
                val action = FullPalletPickPalletFragmentDirections.actionFullPalletPickFromReservePalletPageToTivoTaskGroupFragment()
                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoTaskGroupFragment, true).build()
                getNavigationController().navigate(action, navOptions)
            }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.scanPalletVal.setText(scan?.barcode.toString())
            binding.scanPalletVal.text?.length?.let {
                binding.scanPalletVal.setSelection(it)
            }
            FlareLog.i(TAG, "Scan Pallet field focused")
            validateLocation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

}