package com.fsc.flare.ui.fragment.palletizecontainer

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.google.android.material.textview.MaterialTextView

class PalletizeIBContainerAdapter(
    private var containerList: MutableList<String>
) : RecyclerView.Adapter<PalletizeIBContainerAdapter.ViewHolder>() {
    lateinit var context: Context
    fun update(item: String) {
        containerList.add(item)
        notifyItemInserted(containerList.size)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvContainerNumberValue: MaterialTextView = itemView.findViewById(R.id.tvContainerNumberValue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PalletizeIBContainerAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_receiving_container, parent, false)
        context = parent.context
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: PalletizeIBContainerAdapter.ViewHolder, position: Int) {
        holder.tvContainerNumberValue.text = containerList[position]
    }

    override fun getItemCount(): Int {
        return containerList.size
    }

}