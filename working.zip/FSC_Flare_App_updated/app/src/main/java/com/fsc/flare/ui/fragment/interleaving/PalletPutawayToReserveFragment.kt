package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingScanPalletLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTask
import com.fsc.flare.source.data.dto.interleaving.RegisterLocationRequest
import com.fsc.flare.source.data.dto.interleaving.ValidateContainerRequest
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

private val TAG = PalletPutawayToReserveFragment::class.java.simpleName.toString()

/**
 *  [PalletPutawayToReserveFragment] class.
 */
@AndroidEntryPoint
class PalletPutawayToReserveFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var alertHandler: AlertHandler

    private lateinit var binding: FragmentInterleavingScanPalletLocationBinding
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private val taskTypeIdentifierViewModel: InterLeavingTaskTypeIdentifierViewModel by viewModels()

    override fun onCreateView(

        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingScanPalletLocationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvCurrentLocation.text =
            sharedViewModel.taskInterLeavingResponse?.pickInfo?.pickLocBarcode
        currentLocationHandleTouchAndFocusEvents()

        observeFlowOnUI { observeApiResults() }

        setClickListenerToEndTaskButtons()
        setClickListenerToSkipButtons()
        setClickListenerToSkipInlineButtons()
    }

    /**
     * Monitor the API response data and trigger corresponding actions based on the outcome.
     */
    private suspend fun observeApiResults() {
        taskTypeIdentifierViewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is InterLeavingLocationTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is InterLeavingLocationTaskState.LocationRegisterSuccess -> {
                    showSuccessSnackBar(getString(state.message))
                    validatePallet()
                    handleViewVisibility()
                }

                is InterLeavingLocationTaskState.ShowError -> showErrorSnackBar(state.errorMessage)
                is InterLeavingLocationTaskState.ContainerResponse -> {
                    sharedViewModel.validateContainerResponse = state.getInterLeavingResponse
                    val action =
                        PalletPutawayToReserveFragmentDirections.actionPalletPutwayToReserveFragmentToDetailFragment()
                    getNavigationController().navigate(action)
                }

                is InterLeavingLocationTaskState.EndTaskSuccess -> {
                    sharedViewModel.clearData()
                    val action =
                        PalletPutawayToReserveFragmentDirections.actionScanCurrentLocationToHomeFragment()
                    getNavigationController().navigate(action)
                }

                is InterLeavingLocationTaskState.NavigateToPalletPutwayToReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    binding.tvCurrentLocation.text =
                        state.response?.pickInfo?.pickLocBarcode
                }

                is InterLeavingLocationTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code
                    val action =
                        PalletPutawayToReserveFragmentDirections.actionPalletPutwayToReserveFragmentToPalletReplenishmentToCasePick(
                            getString(state.screenTitle)
                        )
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(
                            R.id.scanEquipmentFragment,
                            inclusive = true
                        )
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }

                is InterLeavingLocationTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PalletPutawayToReserveFragmentDirections.actionPalletPutwayToReserveFragmentToPickFromReserve()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(
                            R.id.scanEquipmentFragment,
                            inclusive = true
                        )
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }

                is InterLeavingLocationTaskState.NavigateToPalletReplenishmentToActive -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType =
                        InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    val action =
                        PalletPutawayToReserveFragmentDirections.actionPalletPutwayToReserveFragmentToPalletReplenishmentToCasePick(
                            getString(state.screenTitle)
                        )
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(
                            R.id.scanEquipmentFragment,
                            inclusive = true
                        )
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun currentLocationHandleTouchAndFocusEvents() {
        with(binding) {
            locationRootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, locationRootLayout)
                        if (binding.scanLocation.isFocused && !binding.scanLocation.text.isNullOrEmpty()) {
                            validateLocation()

                        } else {
                            binding.tvShowLocationError.visibility = View.VISIBLE
                            binding.tvShowLocationError.text =
                                getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.scanLocation.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.scanLocation)
                       validateLocation()
                   }
                   return@setOnEditorActionListener false
               }
            binding.scanLocation.doAfterTextChanged { binding.tvShowLocationError.visibility = View.GONE }
        }
    }

    private fun validateLocation() {
        if (binding.scanLocation.text.toString() == sharedViewModel.taskInterLeavingResponse?.pickInfo?.pickLocBarcode) {
            taskTypeIdentifierViewModel.registerLocation(
                taskType = sharedViewModel.taskType ?: "",
                registerLocationRequest = RegisterLocationRequest(
                    binding.scanPallet.text.toString(),
                    sharedViewModel.taskInterLeavingResponse?.sessionId
                        ?: "0"
                )
            )
        } else {
            binding.tvShowLocationError.visibility = View.VISIBLE
            binding.tvShowLocationError.text =
                getString(R.string.lbl_invalid_location)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun validatePallet() {
        with(binding) {
            locationRootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, locationRootLayout)
                        when {
                            binding.scanPallet.isFocused && !binding.scanPallet.text.isNullOrEmpty() -> {
                                callValidateContainerService()
                            }

                            else -> {
                                binding.tvShowPalletError.visibility = View.VISIBLE
                                binding.tvShowPalletError.text =
                                    getString(R.string.lbl_input_required)
                            }
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.scanLocation.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.scanLocation)
                       callValidateContainerService()
                   }
                   return@setOnEditorActionListener false
               }

            binding.scanPallet.doAfterTextChanged {  binding.tvShowPalletError.visibility = View.GONE }
        }
    }

    /**
     * Call validate container Service
     */
    private fun callValidateContainerService() {
        taskTypeIdentifierViewModel.sendValidateContainerRequest(
            taskType = sharedViewModel.taskType ?: "",
            containerRequest = ValidateContainerRequest(
                containerNbr = binding.scanPallet.text.toString(),
                scannedLocBarcode = binding.tvCurrentLocation.text.toString(),
                taskId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId
                    ?: 0,
                sessionId = sharedViewModel.taskInterLeavingResponse?.sessionId
                    ?: ""
            )
        )
    }

    private fun handleViewVisibility() {
        binding.lblCurrentLocation.visibility = View.GONE
        binding.scanLocation.visibility = View.GONE
        binding.lblPalletLocation.visibility = View.VISIBLE
        binding.scanPallet.visibility = View.VISIBLE
    }

    private fun setClickListenerToEndTaskButtons() {
        binding.btnEndTask.setOnClickListener {
            alertHandler.showFlareConfirmationAlert(
                message = getString(
                    R.string.interleaving_end_task_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                    taskTypeIdentifierViewModel.sendEndTaskRequest(
                        interLeavingEndTask = InterLeavingEndTask(
                            sessionId = sharedViewModel.taskInterLeavingResponse?.sessionId ?: ""
                        )
                    )
                }
            )
        }
    }

    private fun setClickListenerToSkipButtons() {
        binding.btnSkip.setOnClickListener {
            alertHandler.showFlareConfirmationAlert(
                message = getString(
                    R.string.interleaving_skip_task_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                     taskTypeIdentifierViewModel.callInterLeavingService(
                         interLeavingPayload = GetInterLeavingRequest(
                             equipmentId = sharedViewModel.equipmentId ?: 0,
                             equipmentTypeId = sharedViewModel.equipmentTypeId ?: 0,
                             skipTaskId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId ?: 0
                         )
                     )
                }
            )
        }
    }

    private fun setClickListenerToSkipInlineButtons() {
        binding.btnSkipSequence.setOnClickListener {
            alertHandler.showConfirmationAlert(
                message = getString(
                    R.string.interleaving_skip_task_sequence_message,
                ),
                positiveButtonTitle = getString(R.string.yes),
                negativeButtonTitle = getString(R.string.no),
                positiveCallBack = {
                    taskTypeIdentifierViewModel.callInterLeavingService(
                        interLeavingPayload = GetInterLeavingRequest(
                            equipmentId = sharedViewModel.equipmentId ?: 0,
                            equipmentTypeId = sharedViewModel.equipmentTypeId ?: 0,
                            skipTaskGrpId = sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId ?: 0
                        )
                    )
                }
            )
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.scanLocation.isFocused && binding.scanLocation.text.isNullOrEmpty()) {
            binding.scanLocation.setText(  scan?.barcode.toString())
            validateLocation()
        }else{
            binding.scanPallet.setText(scan?.barcode.toString())
            callValidateContainerService()
        }
    }
}