package com.fsc.flare.ui.fragment.prescan

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPreScanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.prescan.fetch.PreScanValidateRMARequest
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.LAUNCHED_FROM_PRE_PROCESS_SCREEN
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.PRE_SCAN_RMA_PAGE_LIMIT
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.PRE_SCAN_RMA_PAGE_NUMBER
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PreScanFragment::class.java.simpleName.toString()

/**
 * A Fragment for PreScan feature , this fragment is launched from submenu item navigation graph.
 */
@AndroidEntryPoint
class PreScanFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var fragmentPreScanBinding: FragmentPreScanBinding
    private var launchedFromPreProcess: Boolean = false
    private val viewModel: PreScanViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fragmentPreScanBinding = FragmentPreScanBinding.inflate(inflater, container, false)
        fragmentPreScanBinding.lifecycleOwner = this
        callReturnTypeApi()
        subscribeValidateRMAObserver()
        return fragmentPreScanBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        launchedFromPreProcess =
            requireArguments().getString(LAUNCHED_FROM_PRE_PROCESS_SCREEN).isNullOrEmpty().not()
        setUpListeners()
    }

    override fun onResume() {
        super.onResume()
        if (launchedFromPreProcess) {
            launchedFromPreProcess = false
            showSuccessSnackBar(getString(R.string.prescan_success))

        }
    }

    /**
     * Method to set listener to observer the rma value and search button click
     */
    private fun setUpListeners() {
        fragmentPreScanBinding.etRmaNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                fragmentPreScanBinding.btnSearch.visibility =
                    if (fragmentPreScanBinding.etRmaNumber.text.isNullOrBlank()) View.GONE else View.VISIBLE
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        fragmentPreScanBinding.btnSearch.setOnClickListener {
            validateRMANumber()
        }
    }

    /**
     *  A Override method for show home ,logout,account menu icon in action bar.
     *  And also handle show snackbar for success of Process prescan message
     */
    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * method to validate RMA Number from API call
     */
    private fun validateRMANumber() {
        val rmaNumber = fragmentPreScanBinding.etRmaNumber.text.toString().trim()
        viewModel.getValidateRMADetails(
            PreScanValidateRMARequest(
                cust_Id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                rmaNumber = rmaNumber,
                page = PRE_SCAN_RMA_PAGE_NUMBER,
                pageLimit = PRE_SCAN_RMA_PAGE_LIMIT
            )
        )
    }

    /**
     *  method to initiate return type API call
     */
    private fun callReturnTypeApi() {
        viewModel.getReturnType()
    }

    /**
     * method to get vendor Customer Details from API call
     */
    private fun vendorCustomerDetails() {
        viewModel.vendorCustomerDetails()
    }

    /**
     * Function to observe validate RMA Response
     */
    private fun subscribeValidateRMAObserver() {
        viewModel.preScanValidateRMAResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { validateRMAResponse ->
                        if (validateRMAResponse.success) {
                            viewModel.validateRMAResponse = validateRMAResponse
                            vendorCustomerDetails()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    FlareLog.e(TAG, "Error response while validate RMA number ")
                    showAlertDialog("", resources.getString(R.string.pre_scan_alert_dialog_message)) {}
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        subscribeVendorOrCustomerDetailsObserver()
        subscribeForVendorCustomerDetails()
    }

    /**
     * Method to observe customer details response
     */
    private fun subscribeVendorOrCustomerDetailsObserver() {
        viewModel.vendorORCustomerDetailsResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { vendorsResponse ->
                        if (vendorsResponse.success) {
                            navigateToCreateShipFragment()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    FlareLog.e(TAG, "Error Response while getting vendor OR Customer Details  ")
                    showAlertDialog("", resources.getString(R.string.pre_scan_no_customer_alert_dialog_message)) {}
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to show alterDialog if vendor api is failed
     */
    private fun subscribeForVendorCustomerDetails() {
        viewModel.showNoVendorAssociatedMsg.observe(viewLifecycleOwner){
            if (it) {
                showAlertDialog(
                    "",
                    resources.getString(R.string.pre_scan_no_customer_alert_dialog_message)
                ) {
                    viewModel.showNoVendorAssociatedMsg.postValue(false)
                }
            }
        }
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        fragmentPreScanBinding.progressBar.visibility = View.GONE
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        fragmentPreScanBinding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to navigate CreateShipment Fragments
     */
    private fun navigateToCreateShipFragment() {
        FlareLog.i(TAG, "navigateToCreateShipFragment called")
        val action = PreScanFragmentDirections.actionPreScanFragmentToCreateShipmentFragment()
        getNavigationController().navigate(action)
    }
}