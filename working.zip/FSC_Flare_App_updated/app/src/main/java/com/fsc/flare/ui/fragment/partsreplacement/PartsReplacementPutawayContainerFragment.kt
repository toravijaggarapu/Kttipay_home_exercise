package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementPutawayConatainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.CompleteMoveTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_TYPE_PUTAWAY
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementPutawayContainerFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementPutawayContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: PartsRepalcementSerialAdapter
    private lateinit var partsReplacementPutawayConatainerBinding: FragmentPartsReplacementPutawayConatainerBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>
    var containerNumberList = mutableListOf<String>()
    private var containerList = ArrayList<String>()
    private var scannedSerial = ""

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementPutawayConatainerBinding =
            FragmentPartsReplacementPutawayConatainerBinding.inflate(inflater, container, false)
        partsReplacementPutawayConatainerBinding.lifecycleOwner = this
        return partsReplacementPutawayConatainerBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        subscribeObservers()
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        taskDetails.firstOrNull()?.let {
            with(partsReplacementPutawayConatainerBinding) {
                tvItemValue.text = it.itemId
                tvDescriptionValue.text = it.itemDescription
                tvInventoryValue.text = it.invType
                tvPutawayContainerValue.text = it.obContainerNumber
            }
        }
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        val moveTaskDetails = viewModel.getMoveTaskDetails()
        if (moveTaskDetails != null) {
            containerNumberList.addAll(viewModel.getPutawayList())
            if (!viewModel.getPutawayContianerList().isNullOrEmpty()) {
                containerList = viewModel.getPutawayContianerList() as ArrayList<String>
                partsReplacementPutawayConatainerBinding.tvContainerValue.text =
                    "(${containerNumberList.size}/${viewModel.getPutawayContianerCount()})"
            }
            setupRecyclerView()
        }

        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.doAfterTextChanged {
            partsReplacementPutawayConatainerBinding.errResponse.text = null
        }

        partsReplacementPutawayConatainerBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(
                        fragmentContext,
                        partsReplacementPutawayConatainerBinding.etPutawayContainerItem
                    )
                    if (partsReplacementPutawayConatainerBinding.etPutawayContainerItem.isFocused) {
                        validatePutawayContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(
                    fragmentContext,
                    partsReplacementPutawayConatainerBinding.etPutawayContainerItem
                )
                validatePutawayContainer()
            }
            false
        }
    }

    private fun getRepairTaskRf(taskList: List<Task>) {
        taskList.firstOrNull()?.let {
            viewModel.getRepairTaskRf(
                GetRepairTaskRf(
                    partRunnerCart = "",
                    taskType = TASK_TYPE_PUTAWAY,
                    taskgroup = Constants.PartsReplacement.TASK_GROUP_TNR,
                    actionType = Constants.PartsReplacement.ACTION_TYPE_GET
                )
            )
        }
    }

    private fun completeMoveTaskRf() {
        viewModel.completeMoveTaskRf(
            CompleteMoveTaskRf(
                taskType = TASK_TYPE_PUTAWAY,
                taskId =  taskDetails.get(0).taskId
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.getRepairTaskRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { moveTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(moveTaskRfResponse)
                        FlareLog.e(TAG, "getMoveTaskRfResponse : ${moveTaskRfResponse.toString()}")
                        navigateToPartsPutawayContainerFragment()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "compeleteMoveTaskRfResponse error: $msg")
                        showErrorSnackBar(msg)
                        navigateToPartsTaskTypeFragment()
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                else -> {}
            }
        }
        viewModel.compeleteMoveTaskDetailsRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { compeleteMoveTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(compeleteMoveTaskRfResponse)
                        FlareLog.e(
                            TAG,
                            "compeleteMoveTaskRfResponse : ${compeleteMoveTaskRfResponse.toString()}"
                        )
                        showSuccessSnackBar(getString(R.string.parts_replacement_task_completed))
                        getRepairTaskRf(viewModel.getMoveTaskList())
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "compeleteMoveTaskRfResponse error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                else -> {}
            }
        }
    }


    private fun validatePutawayContainer() {
        if (partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text.toString().trim()
                .isNotEmpty() && partsReplacementPutawayConatainerBinding.tvPutawayContainerValue.text.toString()
                .trim() == partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text.toString()
                .trim()
        ) {
            partsReplacementPutawayConatainerBinding.errResponse.text = null
            putawayContainerValidate()
        } else {
            displayErrorMessage(getString(R.string.parts_replacement_invalid_putaway_container))
        }

    }

    private fun putawayContainerValidate() {
        val taskDetails = viewModel.getMoveTaskDetails()
        if (taskDetails != null) {
            val serialNumber =
                partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text.toString()
                    .trim()
            if (containerNumberList.size < viewModel.getPutawayContianerCount()) {
                if (!containerNumberList.contains(serialNumber)) {
                    if (containerList.contains(serialNumber)) {
                        FlareLog.i(TAG, "serialList contains")
                        scannedSerial =
                            partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text.toString()
                                .trim()
                        showSuccessSnackBar(resources.getString(R.string.parts_replacement_container_completed))
                        serialNumberUpdate()
                    }


                } else {
                    displayErrorMessage(resources.getString(R.string.parts_replacement_container_duplicate))
                }
            } else {
                partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text = null
                navigateToPartsTaskTypeFragment()
            }
        }
    }

    private fun hideProgressBar() {
        partsReplacementPutawayConatainerBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementPutawayConatainerBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.setText(scan?.barcode.toString())
        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text?.length?.let {
            partsReplacementPutawayConatainerBinding.etPutawayContainerItem.setSelection(it)
        }
        validatePutawayContainer()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToPartsTaskTypeFragment() {
        viewModel.resetPutawayNumber()
        Handler(Looper.getMainLooper()).postDelayed({
            val action =
                PartsReplacementPutawayContainerFragmentDirections.actionPartsReplacementPutawayContainerFragmentToPartsReplacementTaskTypeFragment()
            findNavController().navigate(action)
        }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
    }

    private fun navigateToPartsPutawayContainerFragment() {
        viewModel.resetPutawayNumber()
        Handler(Looper.getMainLooper()).postDelayed({
            val action =
                PartsReplacementPutawayContainerFragmentDirections.actionPartsReplacementPutawayContainerFragmentToPartsReplacementPartsContainerFragment()
            findNavController().navigate(action)
        }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementPutawayConatainerBinding.errResponse.text = errorMessage
        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.requestFocus()
        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.selectAll()
        showSoftKeyBoard(
            fragmentContext,
            partsReplacementPutawayConatainerBinding.etPutawayContainerItem
        )
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        partsReplacementPutawayConatainerBinding.rvContainer.layoutManager =
            LinearLayoutManager(fragmentContext)
        serialListAdapter = PartsRepalcementSerialAdapter(containerNumberList as ArrayList<String>,getString(R.string.parts_replacement_putaway_container))


        partsReplacementPutawayConatainerBinding.rvContainer.adapter = serialListAdapter
    }

    private fun serialNumberUpdate() {

        containerNumberList.add(
            partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text.toString().trim()
        )
        serialListAdapter.notifyDataSetChanged()
        partsReplacementPutawayConatainerBinding.etPutawayContainerItem.text = null
        val taskDetail = viewModel.getMoveTaskDetails()
        if (taskDetail != null) {
            partsReplacementPutawayConatainerBinding.tvContainerValue.text =
                String.format(getString(R.string.actual_by_required), containerNumberList.size, viewModel.getPutawayContianerCount())
            if (containerNumberList.size == viewModel.getPutawayContianerCount()) {
                partsReplacementPutawayConatainerBinding.etPutawayContainerItem.isEnabled = false
                saveSerialListToSharedPref()
                completeMoveTaskRf()
            } else {
                with(partsReplacementPutawayConatainerBinding) {
                    tvPutawayContainerValue.text =
                        containerList.get(containerNumberList.size)
                    FlareLog.e(TAG, " taskDetail.get(containerNumberList.size) ${ taskDetail.get(containerNumberList.size)}")

                    tvItemValue.text = taskDetail.get(containerNumberList.size).itemId
                    tvDescriptionValue.text =  taskDetail.get(containerNumberList.size).itemDescription
                    tvInventoryValue.text =  taskDetail.get(containerNumberList.size).invType
                    tvPutawayContainerValue.text =  taskDetail.get(containerNumberList.size).obContainerNumber
                }
            }
        }
        scannedSerial = ""

    }

    private fun saveSerialListToSharedPref() {
        val json = Gson().toJson(containerNumberList)
        sharedPreferences.edit().putString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, json)
            .apply()
    }

}