package com.fsc.flare.di

import com.fsc.flare.source.repository.MaterialMovementRepository
import com.fsc.flare.source.repository.MaterialMovementRepositoryImpl
import com.fsc.flare.source.repository.ReplenishDeliveryRepository
import com.fsc.flare.source.repository.ReplenishDeliveryRepositoryImpl
import com.fsc.flare.source.repository.SDCombinePalletRepository
import com.fsc.flare.source.repository.SDCombinePalletRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent


@Module
@InstallIn(ViewModelComponent::class)
abstract class RepositoryModule {

    @Binds
    abstract fun getCombinePalletRepository(repository: SDCombinePalletRepositoryImpl): SDCombinePalletRepository

    @Binds
    abstract fun getReplenishDeliveryRepository(repository: ReplenishDeliveryRepositoryImpl): ReplenishDeliveryRepository

    @Binds
    abstract fun getMaterialMovementRepository(repository: MaterialMovementRepositoryImpl): MaterialMovementRepository
}