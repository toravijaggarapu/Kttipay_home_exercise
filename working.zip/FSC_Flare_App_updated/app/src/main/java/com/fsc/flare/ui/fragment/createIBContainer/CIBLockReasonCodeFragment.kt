package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBLockReasonCodeBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.lookups.LookupCode
import com.fsc.flare.utils.Constants.LockCodes.FIRST_ARTICLE_INSPECTION
import com.fsc.flare.utils.Constants.LockCodes.INCUBATION_HOLD
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBLockReasonCodeFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBLockReasonCodeFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBLockReasonCodeFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    private lateinit var binding: FragmentCIBLockReasonCodeBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val lockCodeHashMap: HashMap<String, InventoryLockcode> = HashMap()
    private val reasonCodeHashMap: HashMap<String, LookupCode> = HashMap()
    lateinit var cb1: CustomVisibilityCallback


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        if (viewModel.getLockCodeList() != null) {
            binding.ddLockcode.setOptions(viewModel.getLockCodeList())
        }

        if (viewModel.getReasonCodeList() != null) {
            binding.ddReasonCode.setOptions(viewModel.getReasonCodeList())
        }
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getLockCodes()
    }



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBLockReasonCodeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val itemData = viewModel.getItemBarcodeData()

        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.tvItemCodeValue.text = itemData?.itemBarCode
        binding.tvItemDescValue.text = itemData?.description
        binding.tvQtyUomValue.text = String.format("%d units",viewModel.getInputQtyInUnits())

        binding.ddLockcode.boolFoo.observe(viewLifecycleOwner) {
            val selectedLockCode = lockCodeHashMap[it]
            if (selectedLockCode != null) {
                viewModel.setInputLockCode(selectedLockCode)
            }
        }

        binding.ddReasonCode.boolFoo.observe(viewLifecycleOwner) {
            val selectedReasonCode = reasonCodeHashMap[it]
            if (selectedReasonCode != null) {
                viewModel.setInputReasonCode(selectedReasonCode)
            }
        }

        binding.btnStage.setOnClickListener {
            val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action =
                CIBLockReasonCodeFragmentDirections.actionLockReasoncodeFragmentToStagingLocationFragment()
            navController.navigate(action)
        }

    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeLockCodeObserver()
        subscribeReasonCodeObserver()
    }


    /**
     * method to Lock Codes from API
     */
    private fun getLockCodes() {
        viewModel.getLockCodes(
            InventoryLockcodeRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
            )
        )
    }

    /**
     * method to subscribe lock code observer
     */
    private fun subscribeLockCodeObserver() {
        viewModel.lockCodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        val lockCodeList = ArrayList<String>()
                        lookUpResponse.lockCodes.forEach { lockcode ->
                            if (lockcode.code != INCUBATION_HOLD && lockcode.code != FIRST_ARTICLE_INSPECTION) {
                                lockCodeList.add(lockcode.description)
                            }
                            lockCodeHashMap[lockcode.description] = lockcode
                            when (lockcode.code) {
                                "PW" -> {
                                    viewModel.setDefaultLockCode(lockcode)
                                }
                            }
                        }
                        viewModel.setLockCodeList(lockCodeList)
                        binding.ddLockcode.setOptions(lockCodeList)
                        getReasonCodes()
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to get reason codes from API
     */
    private fun getReasonCodes() {
        viewModel.getReasonCodes()
    }

    /**
     * method to subscribe Reason code observer
     */
    private fun subscribeReasonCodeObserver() {
        viewModel.reasonCodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        val reasonCodeList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach { reasonCode ->
                                reasonCodeList.add(reasonCode.lookupCodeDescription)
                                reasonCodeHashMap[reasonCode.lookupCodeDescription] = reasonCode
                            }
                        }
                        viewModel.setReasonCodeList(reasonCodeList)
                        binding.ddReasonCode.setOptions(reasonCodeList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}