package com.fsc.flare.ui.fragment.submenuchildren

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSubMenuBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.Children
import com.fsc.flare.source.data.dto.login.Module
import com.fsc.flare.source.data.dto.login.UserModulesByCustomer
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.fsc.flare.ui.activity.main.MainActivity
import com.fsc.flare.ui.fragment.home.HomeAdapter
import com.fsc.flare.ui.fragment.home.HomeViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.StringUtils
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject

private const val ARG_PARAM1 = "displayName"
private const val ARG_PARAM2= "rootMenuName"
private const val TAG = "SubMenuChildrenFragment"

@AndroidEntryPoint
class SubMenuChildrenFragment : BaseFragment(), SubMenuChildrenAdapter.OnAdapterClickListener {

    private var displayName: String? = null
    private var rootMenuName:String?=null

    lateinit var subMenuChildrenAdapter: SubMenuChildrenAdapter
    private lateinit var binding: FragmentSubMenuBinding
    lateinit var navController: NavController
    private val viewModel: HomeViewModel by activityViewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onResume() {
        sendTrackerDataToServer()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            arguments?.let {
                displayName = it.getString(ARG_PARAM1)
                rootMenuName = it.getString(ARG_PARAM2)
            }
        }
    }

    override fun onCreateMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.main_menu, menu)
        val item = menu.findItem(R.id.action_search)
        val searchView = item.actionView as SearchView
        searchView.maxWidth = Int.MAX_VALUE
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setIconifiedByDefault(true)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                subMenuChildrenAdapter.filter.filter(newText)
                return false
            }
        })
        item?.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }

            override fun onMenuItemActionCollapse(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }
        })
        super.onCreateMenu(menu, inflater)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.account)?.isVisible = true
        menu.findItem(R.id.action_search)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.language)?.isVisible = false
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentSubMenuBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        binding.tvDisplayName.text = displayName
        if(viewModel.fetchUserModulesByCustomerList().isNotEmpty()) {
            generateSubMenuList(viewModel.fetchUserModulesByCustomerList())
        }
    }

    private fun generateSubMenuList(userModulesByCustomer: List<UserModulesByCustomer>) {
        val navItemsList = arrayListOf<Children>()
        val currentCustomerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)

        // Flag to check if we found a matching cusId
        var foundMatchingCusId = false

        // First, check for matching cusId
        userModulesByCustomer.forEach { userModule ->
            if (userModule.cusId.toInt() == currentCustomerId) {
                foundMatchingCusId = true
                userModule.modules.forEach { module ->
                    addNavItemsToList(module, navItemsList)
                }
            }
        }

        // If no matching cusId was found, check for cusId == -1
        if (!foundMatchingCusId) {
            userModulesByCustomer.forEach { userModule ->
                if (userModule.cusId.toInt() == -1) {
                    userModule.modules.forEach { module ->
                        addNavItemsToList(module, navItemsList)
                    }
                }
            }
        }

        setupRecyclerView(navItemsList)
    }

    private fun addNavItemsToList(module: Module, navItemsList: MutableList<Children>) {
        module.navItems.forEach { navItem ->
            // Check if navItem's children are not null
            navItem.children?.let { children ->
                // Iterate through each child
                children.forEach { child ->
                    // Check if displayName is not null and matches rootMenuName
                    if (child.displayName?.uppercase(Locale.ROOT) == rootMenuName) {
                        // Check if child.children is not null before adding
                        child.children?.let { grandChildren ->
                            navItemsList.addAll(grandChildren) // Add all children to the list
                        }
                    }
                }
            }
        }
    }

    private fun setupRecyclerView(navItemsList: ArrayList<Children>) {
        subMenuChildrenAdapter = SubMenuChildrenAdapter(navItemsList, this, fragmentContext)
        binding.submenuRecycler.apply {
            adapter = subMenuChildrenAdapter
            layoutManager = GridLayoutManager(activity, 2)
        }
    }

    override fun onItemSelected(item: String?, menuID:String?) {
        if (viewModel.isPILockEnabledForFeature(item)) {
            FlareLog.e(TAG, "Pi inprogress, dialog visible.")
            showCustomDialog(getString(R.string.pi_count_inprogress_operation_not_allowed)) {
                FlareLog.e(TAG, "Pi inprogress, dialog dismissed.")
            }
            return
        }
        val menuName = StringUtils.langConvertedName(menuID,item, context)
        sharedPreferences.apply {
            sharedPreferences.edit().putString(PreferenceKeys.SUB_MENU_SELECTED, menuName).apply()
        }
        trackerInstance.setModuleName(item!!)
        when (item) {
            "ITEM INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquiryItemBarcode()
                getNavigationController().navigate(action)
            }
            "DOCK DOOR INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquiryDockDoor()
                getNavigationController().navigate(action)
            }
            "LOCATION INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquiryLocation()
                getNavigationController().navigate(action)
            }
            "CONTAINER INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquiryContainer()
                getNavigationController().navigate(action)
            }
            "SLP INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquirySLPFragment()
                getNavigationController().navigate(action)
            }

            "ASN PALLET INQUIRY" -> {
                  val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInquiryAsnPrintRequestorFragment()
                  getNavigationController().navigate(action)
            }

            "SPLIT CONTAINER" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToSplitContainerReversefragment()
                getNavigationController().navigate(action)
            }
            "LOCK IB CONTAINER" -> {
                val bundle = bundleOf(
                    "screenTagName" to "LOCK"
                )
                getNavigationController().navigate(R.id.action_subMenuChildrenFragment_to_containerLockUnlockFragment, bundle)
            }
            "UNLOCK IB CONTAINER" -> {
                val bundle = bundleOf(
                    "screenTagName" to "UNLOCK"
                )
                getNavigationController().navigate(R.id.action_subMenuChildrenFragment_to_containerLockUnlockFragment, bundle)
            }
            "LOCK OB CONTAINER" -> {
                val bundle = bundleOf(
                    "screenTagName" to "LOCK"
                )
                getNavigationController().navigate(R.id.action_subMenuChildrenFragment_to_containerLockUnlockFragment, bundle)
            }
            "UNLOCK OB CONTAINER" -> {
                val bundle = bundleOf(
                    "screenTagName" to "UNLOCK"
                )
                getNavigationController().navigate(R.id.action_subMenuChildrenFragment_to_containerLockUnlockFragment, bundle)
            }
            "CONTAINER ADJUSTMENT" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInventoryAdjustmentContainerFragment()
                getNavigationController().navigate(action)
            }
            "PUTAWAY TO ACTIVE" -> {
                if (rootMenuName == "SYSTEM DIRECTED PUTAWAY") {
                    getNavigationController().navigate(
                        R.id.action_subMenuChildrenFragment_to_sdPutawayActiveContainerFragment,
                        bundleOf("displayName" to "SYSTEM DIRECTED PUTAWAY")
                    )
                } else {
                    //USER DIRECTED PUTAWAY
                    getNavigationController().navigate(
                        R.id.action_subMenuChildrenFragment_to_udPutawayActiveContainerFragment,
                        bundleOf("displayName" to "USER DIRECTED PUTAWAY")
                    )
                }
            }
            "PUTAWAY TO CASE PICK" -> {
                if (rootMenuName == "SYSTEM DIRECTED PUTAWAY") {
                    getNavigationController().navigate(
                        R.id.action_subMenuChildrenFragment_to_sdPutawayCasepickContainerFragment,
                        bundleOf("displayName" to "SYSTEM DIRECTED PUTAWAY")
                    )

                } else {
                    //USER DIRECTED PUTAWAY
                    getNavigationController().navigate(
                        R.id.action_subMenuChildrenFragment_to_udPutawayCasepickContainerFragment,
                        bundleOf("displayName" to "USER DIRECTED PUTAWAY")
                    )
                }
            }
            "PUTAWAY TO RESERVE" -> {
                if (rootMenuName == "SYSTEM DIRECTED PUTAWAY") {
                    getNavigationController().navigate(
                        R.id.action_subMenuChildFragment_to_putawayForwardFragment,
                        bundleOf("displayName" to "SYSTEM DIRECTED PUTAWAY")
                    )
                } else {
                    //USER DIRECTED PUTAWAY
                    //For System directed and User directed flow, using the same fragment. Only the header changed.
                    getNavigationController().navigate(
                        R.id.action_subMenuChildrenFragment_to_udPutawayReserveContainerFragment,
                        bundleOf("displayName" to "$displayName-RESERVE")
                    )
                }
            }
            "SLP" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInventoryTransferSlpFragment()
                getNavigationController().navigate(action)
            }
            "CONTAINER" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToInventoryTransferContainerFragment()
                getNavigationController().navigate(action)
            }
            "SLP SERIAL INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToInventoryTransferSlpInquiryFragment()
                getNavigationController().navigate(action)
            }
            "CONTAINER# INQUIRY" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToInventoryTransferContainerInquiryFragment()
                getNavigationController().navigate(action)
            }
            "CONTAINER TO ACTIVE" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToCTAContainerFragment()
                getNavigationController().navigate(action)
            }

            "CONTAINER TO STAGE" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToRCTSContainerFragment()
                getNavigationController().navigate(action)
            }

            "COMBINE BY PALLET" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToCombineByPalletTaskMode()
                getNavigationController().navigate(action)
            }

            "SPLIT & COMBINE BY CASE" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildrenFragmentToSplitAndCombineByCaseFragment()
                getNavigationController().navigate(action)
            }

            "PALLET ADJUSTMENT" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToIbPalletAdjustmentFragment()
                getNavigationController().navigate(action)
            }

            "LOCK IB PALLET" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToPalletLockAdjustmentFragment()
                getNavigationController().navigate(action)
            }

            "UNLOCK IB PALLET" -> {
                val action = SubMenuChildrenFragmentDirections.actionSubMenuChildFragmentToPalletUnlockAdjustmentFragment()
                getNavigationController().navigate(action)
            }

            "PUTAWAY TO DAMAGE" -> {
                if(sharedPreferences.getBoolean(PreferenceKeys.ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS, false)){
                    getNavigationController().navigate(R.id.action_subMenuChildFragment_to_putawayDamageFragment, bundleOf("displayName" to rootMenuName))
                }else{
                    showErrorSnackBar(getString(R.string.this_feature_is_not_allowed_as_configuration_is_off))
                }
            }

            else -> {
                Toast.makeText(requireActivity(), "Clicked on $item", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}