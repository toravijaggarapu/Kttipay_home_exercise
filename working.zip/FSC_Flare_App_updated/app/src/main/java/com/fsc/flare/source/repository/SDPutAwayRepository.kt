package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.PalletPrinterReq
import com.fsc.flare.source.data.dto.putawayforward.get.req.SDPutawayReq
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayForwardGetResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SDPutAwayRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    val fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: ""

    suspend fun validateContainer(userDirectedPutawayContainerRequest: UserDirectedPutawayContainerRequest) =
        apiGatewayInterface.validateContainerPutawayUserDirected(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = fedexId,
            custId = userDirectedPutawayContainerRequest.custId,
            buId = userDirectedPutawayContainerRequest.buId,
            fcyId = userDirectedPutawayContainerRequest.fcyId,
            containerNumber = userDirectedPutawayContainerRequest.containerNumber,
            putAwayType = userDirectedPutawayContainerRequest.putAwayType,
            userDirected = false,
            containerType = userDirectedPutawayContainerRequest.containerType,
            includeCCLocation = userDirectedPutawayContainerRequest.includeCCLocation,
            recallLockExists = userDirectedPutawayContainerRequest.recallLockExists
        )

    suspend fun submitUserdirectedPutaway(userDirectedPutawaySubmitRequest: UserDirectedPutawaySubmitRequest) =
        apiGatewayInterface.submitUserDirectedPutaway(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = fedexId,
            requestBody = userDirectedPutawaySubmitRequest
        )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) =
        apiGatewayInterface.validateTransactionParam(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = fedexId,
            custId = transactionParamRequest.cust_id,
            buId = transactionParamRequest.bu_id,
            fcyId = transactionParamRequest.fcy_id,
            transCode = transactionParamRequest.trans_code
        )

    suspend fun getPutawayContainer(putawayForwardGetReq: SDPutawayReq): Response<PutawayForwardGetResponse> {
        return apiGatewayInterface.getPutawaySystemDirected(
            gatewayToken = "Bearer ${
                sharedPreferences.getString(
                    PreferenceKeys.API_GATEWAY_ACCESS_TOKEN,
                    null
                )
            }",
            fedexId = fedexId,
            fcy_id = putawayForwardGetReq.fcy_id,
            bu_id = putawayForwardGetReq.bu_id,
            cust_id = putawayForwardGetReq.cust_id,
            cntNumber = putawayForwardGetReq.cnt_id,
            locClass = putawayForwardGetReq.locClass,
            containerType = putawayForwardGetReq.containerType
        )
    }

    suspend fun getContainerDetails(containerNum: String) = apiGatewayInterface.getContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = fedexId,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = containerNum,
        itemInfo = "Y"
    )

    suspend fun generatePalletCaseNumber(type: String) =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = fedexId,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = type
        )


    suspend fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) =
        apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
            gatewayToken = "Bearer ${
                sharedPreferences.getString(
                    PreferenceKeys.API_GATEWAY_ACCESS_TOKEN,
                    null
                )
            }",
            fedexId = fedexId,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = printerConfigRequest.fcyId,
            page = printerConfigRequest.page,
            pageLimit = printerConfigRequest.pageLimit,
            printerType = printerConfigRequest.printerType
        )

    suspend fun printPalletLabel(printPalletRequest: PalletPrinterReq) =
        apiGatewayInterface.printPalletLabel(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = fedexId,
            printPalletRequest
        )

    suspend fun validateLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )


}