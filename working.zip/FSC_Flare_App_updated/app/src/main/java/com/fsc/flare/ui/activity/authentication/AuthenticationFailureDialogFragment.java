package com.fsc.flare.ui.activity.authentication;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.fsc.flare.R;
import com.fsc.flare.utils.AuthFailure;

import dagger.hilt.android.AndroidEntryPoint;


@AndroidEntryPoint
public class AuthenticationFailureDialogFragment extends DialogFragment {

    private static final String TAG = "AuthenticationFailure";

    private AuthenticationFailureListener mListener;
    private static final String EXTRA_AUTH_FAILURE = "auth_failure";
    private static final String LOG_TAG = "AuthenticationFailureDialog";

    public static AuthenticationFailureDialogFragment newInstance(@AuthFailure String authFailure) {
        AuthenticationFailureDialogFragment dialog = new AuthenticationFailureDialogFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_AUTH_FAILURE, authFailure);
        dialog.setArguments(args);
        return dialog;
    }

    public interface AuthenticationFailureListener {
        void onAuthFailureAcknowledged();

        void finishWithFailure();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (AuthenticationFailureListener) context;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        setCancelable(false);
        String authFailureMessage = getMessageFromAuthFailure();
        Log.i(TAG, "Auth Failure Dialog Message: "+ authFailureMessage);
        return new AlertDialog.Builder(getContext())
                .setIcon(R.drawable.alert_accent)
                .setTitle(R.string.authentication_failure_title)
                .setMessage(authFailureMessage)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    Log.i(TAG, "Auth Failure Dialog acknowledged.");
                    mListener.onAuthFailureAcknowledged();
                })
                .create();
    }

    private String getMessageFromAuthFailure() {
        @AuthFailure String authFailure = getArguments() == null ? null : getArguments().getString(EXTRA_AUTH_FAILURE);
        if (AuthFailure.LOGIN_PAGE_CONTENT_ERROR.equals(authFailure)) {
            return getString(R.string.authentication_failure_message_login_page_content);
        } else if (AuthFailure.LOGIN_PAGE_NETWORK_ERROR.equals(authFailure)) {
            return getString(R.string.authentication_failure_message_login_page_network);
        } else {
            return getString(R.string.authentication_failure_message_generic);
        }
    }
}
