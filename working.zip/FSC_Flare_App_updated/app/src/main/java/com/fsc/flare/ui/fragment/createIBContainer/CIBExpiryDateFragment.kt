package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBExpiryDateBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

private const val TAG = "CIBExpiryDateFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBExpiryDateFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBExpiryDateFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBExpiryDateBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBExpiryDateBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val itemData = viewModel.getItemBarcodeData()

        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.tvItemCodeValue.text = itemData?.itemBarCode
        binding.tvItemDescValue.text = itemData?.description

        val cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val myFormat = "yyyy-MM-dd" // mention the format you need
            val sdf = SimpleDateFormat(myFormat, Locale.US)
            binding.etExpiryDate.text = sdf.format(cal.time)
            if (!binding.etExpiryDate.text.isNullOrEmpty()) {
                viewModel.setInputExpiryDate(binding.etExpiryDate.text.toString())
                navigate()
            }
        }

        binding.etExpiryDate.setOnClickListener {
            FlareLog.i(TAG, "Date field clicked")
            DatePickerDialog(
                fragmentContext, dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

    }

    /**
     * method to handle navigation to next screen
     */
    private fun navigate() {
        val itemData = viewModel.getItemBarcodeData()
        if (itemData?.tracking != null) {
            when {
                itemData.tracking.countryOfOriginRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBExpiryDateFragmentDirections.actionUomFragmentToCooFragment()
                    navController.navigate(action)
                }
                /*itemData.tracking.serialNumberRequired == "1" ||*/ itemData.tracking.serialNumberRequired == "4" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBExpiryDateFragmentDirections.actionUomFragmentToSerialFragment()
                    navController.navigate(action)
                }
                else -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBExpiryDateFragmentDirections.actionExpiryDateFragmentToLockReasonCodeFragment()
                    navController.navigate(action)
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}