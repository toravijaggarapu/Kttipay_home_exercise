package com.fsc.flare.ui.fragment.inventory.renamepallet

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRenamePalletDetailBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletRequest
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "RenamePalletDetailFragment"

@AndroidEntryPoint
class RenamePalletDetailFragment : BaseFragment() {

    private val viewModel: RenamePalletViewModel by activityViewModels()
    private lateinit var binding: FragmentRenamePalletDetailBinding
    var isNewPallet = false
    var renamePalletRequest: RenamePalletRequest ?= null

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRenamePalletDetailBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etBlindPalletNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvBlindPalletNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val palletRepackData = viewModel.getPalletDetailData()
        binding.tvPalletNumberValue.text = palletRepackData.palletNumber
        binding.tvNoOfContainerValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_cases, palletRepackData.noOfCases.toInt(), palletRepackData.noOfCases)
        binding.tvPalletQtyValue.text =
                resources.getQuantityString(R.plurals.pallet_transfer_units, palletRepackData.palletQty.toInt(), palletRepackData.palletQty)
        binding.tvItemCodeValue.text = palletRepackData.itemCode
        binding.tvItemDescValue.text = palletRepackData.itemDesc
        binding.tvCurrentLocationValue.text = palletRepackData.currentLocation

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etBlindPalletNumber.isFocused && binding.etBlindPalletNumber.text.toString().trim().isNotEmpty()) {
                        FlareLog.i(TAG, "Destination Location field focused")
                        isNewPallet = false
                        validateBlindPalletNumber(binding.etBlindPalletNumber.text.toString().trim())
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etBlindPalletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etBlindPalletNumber)
                FlareLog.i(TAG, "Destination Location field focused")
                isNewPallet = false
                validateBlindPalletNumber(binding.etBlindPalletNumber.text.toString().trim())
            }
            false
        }

        binding.btnNewPallet.setOnClickListener {
            binding.etBlindPalletNumber.text = null
            callNewPalletAPI()
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        //Blind Pallet number submit and navigation
        viewModel.renamePalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { renamePalletResponse ->
                        if (renamePalletResponse.success) {
                            navigatePalletNumber(resources.getString(R.string.lbl_pallet_renamed_to_successfully,renamePalletRequest!!.existingPalletNumber,renamePalletRequest!!.newPalletNumber))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if (isNewPallet){
                            showCustomDialog(message) {}
                        } else {
                            binding.etBlindPalletNumber.requestFocus()
                            binding.tvBlindPalletNumberResponse.text = message
                            binding.etBlindPalletNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etBlindPalletNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        // New pallet button click update and navigation
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { newPalletResponse ->
                        if (newPalletResponse.success) {
                            if (newPalletResponse.numbers[0].type.equals(Constants.TRANSFER_TYPE_PALLET, ignoreCase = true)) {
                                isNewPallet = true
                                validateBlindPalletNumber(newPalletResponse.numbers[0].value)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigatePalletNumber(message: String) {
        showCustomDialog(message) {
            val navController =
                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
            val action =
                RenamePalletDetailFragmentDirections.actionRenamePalletDetailFragmentToRenamePalletNumberFragment()
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.renamePalletNumberFragment, true).build()
            navController.navigate(action, navOptions)
        }
    }

    /**
     * method to validate blind pallet number
     */
    private fun validateBlindPalletNumber(newPalletNumber: String) {
        if (newPalletNumber.isNotEmpty()) {
            val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
            if (containerType != null && (!newPalletNumber.startsWith(containerType.ctyId!!) || newPalletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.tvBlindPalletNumberResponse.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                renamePalletRequest = RenamePalletRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    existingPalletNumber = binding.tvPalletNumberValue.text.toString(),
                    newPalletNumber = newPalletNumber
                )
                viewModel.renamePalletNumberCall(renamePalletRequest!!)
            }
        }
    }

    /**
     * method to call generate new pallet API
     */
    private fun callNewPalletAPI() {
        viewModel.newPalletNumberGenerate()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

}