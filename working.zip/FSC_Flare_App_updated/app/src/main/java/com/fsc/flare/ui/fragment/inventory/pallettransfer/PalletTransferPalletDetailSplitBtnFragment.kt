package com.fsc.flare.ui.fragment.inventory.pallettransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletTransferPalletDetailSplitBtnBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pallettransfer.PalletTransferRequest
import com.fsc.flare.source.data.dto.pallettransfer.TransferFromEntity
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletTransferPalletDetailSplitBtnFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [PalletTransferPalletDetailSplitBtnFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class PalletTransferPalletDetailSplitBtnFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletTransferViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletTransferPalletDetailSplitBtnBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletTransferPalletDetailSplitBtnBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val palletDetails = viewModel.getPalletDetails()!!.palletInquiry
        binding.tvPalletNumberValue.text = palletDetails.palletNumber
        binding.tvPalletQtyValue.text = resources.getQuantityString(R.plurals.pallet_transfer_units, palletDetails.palletQuantity, palletDetails.palletQuantity)
        binding.tvNbrOfCaseValue.text = resources.getQuantityString(R.plurals.pallet_transfer_cases, palletDetails.noOfCase, palletDetails.noOfCase)
        binding.tvItemCodeValue.text = palletDetails.itemBarCode
        binding.tvItemDescValue.text = palletDetails.itemDescription
        binding.tvCurrentLocationValue.text = palletDetails.currentLocation

        if(!palletDetails.inventoryType.isNullOrEmpty()) {
            binding.tvInventoryType.text= palletDetails.inventoryType?.let { getInventoryDescription(it) }
        }

        if (palletDetails.splitAllowed) {
            binding.btnSplit.visibility = View.VISIBLE
        } else {
            binding.btnSplit.visibility = View.GONE
        }
        binding.etDestinationLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvDestinationLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etDestinationLocation.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                FlareLog.i(TAG, "Pallet Number field focused")
                enableConfirmButton()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    enableConfirmButton()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnConfirm.setOnClickListener {
            binding.tvDestinationLocationResponse.text = null
            submitDestinationLocationApi()
        }

        binding.btnSplit.setOnClickListener {
            val action =
                    PalletTransferPalletDetailSplitBtnFragmentDirections.palletTransferPalletDetailSplitBtnToFragmentPalletTransferPalletDetailNoSplitBtn()
            getNavigationController().navigate(action)
        }
        enableConfirmButton()
    }

    private fun enableConfirmButton() {
        binding.btnConfirm.isEnabled = binding.etDestinationLocation.text.toString().trim().isNotEmpty()
    }

    private fun submitDestinationLocationApi() {
        val palletDetails = viewModel.getPalletDetails()!!.palletInquiry
        val palletTransferRequest = PalletTransferRequest(
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            binding.etDestinationLocation.text.toString().trim(),
            viewModel.palletTransferTypeKey,
            palletDetails.inventoryType,
            TransferFromEntity(binding.tvPalletNumberValue.text.toString())
        )
        viewModel.confirmDestinationLocation(palletTransferRequest)
    }

    private fun subscribeObservers() {
        viewModel.palletSuccessResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletDetailResponse ->
                        if (palletDetailResponse.success) {
                            FlareLog.i(TAG, "palletSuccessResponse success: $palletDetailResponse")
                            showCustomDialog(palletDetailResponse.message, onPositiveClick = onDialogYesClicked)
                        } else {
                            showErrorMessage(palletDetailResponse.message)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationResponse error: $message")
                        showErrorMessage(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showErrorMessage(message: String) {
        binding.tvDestinationLocationResponse.text = message
        binding.etDestinationLocation.requestFocus()
        binding.etDestinationLocation.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etDestinationLocation)
    }

    // Callback from dialog positive button
    private val onDialogYesClicked = {
        val action =
            PalletTransferPalletDetailSplitBtnFragmentDirections.palletTransferPalletDetailSplitBtnFragmentPalletTransferPalletNumberFragment()
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.palletTransferPalletNumberFragment, true).build()
        getNavigationController().navigate(action, navOptions)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etDestinationLocation.setText(scan?.barcode.toString())
                binding.etDestinationLocation.text?.length?.let {
                    binding.etDestinationLocation.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Destination location field focused")
                    submitDestinationLocationApi()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}