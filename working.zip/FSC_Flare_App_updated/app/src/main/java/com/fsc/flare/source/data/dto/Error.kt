package com.fsc.flare.source.data.dto

data class Error(
    val detail: String,
    val errorcode: String,
    val title: String
)