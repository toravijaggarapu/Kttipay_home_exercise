package com.fsc.flare.ui.fragment.pickfromreverse.tivopickfrom

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletContainerSerialUserDirectedTivoPfrBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ContainersItem
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteRequestTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoPickReverseRequest
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.TivoPFR
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "FragmentTaskGroupPickFromReverse"

@AndroidEntryPoint
class FragmentPalletContainerSerialUserDirectedTivoPickFrom : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletContainerSerialUserDirectedTivoPfrBinding
    private var pkdQty = 0
    private var totalQty = 0
    private lateinit var containersScanned: ArrayList<ContainersItem>

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var cb1: CustomVisibilityCallback? = null

    override fun onResume() {
        super.onResume()
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1?.onVisibilityChange(true)
        binding.btnStage.isEnabled = viewModel.getTasksCompletedList()?.isNotEmpty() == true
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletContainerSerialUserDirectedTivoPfrBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validatePN()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etPalletSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletSerialNumber)
                FlareLog.i(TAG, "etPalletSerialNumber field focused")
                validatePN()
            }
            false
        }

        init()
        setListener()
    }

    private fun updatePickedQuantity() {
        if (viewModel.isPallet(viewModel.getPickTaskDetails()))
            binding.pickedQuantityValue.text = if (pkdQty > 1) "$pkdQty pallets" else "$pkdQty pallet"
        else
            binding.pickedQuantityValue.text = if (pkdQty > 1) "$pkdQty cases" else "$pkdQty case"
    }

    private fun init() {
        pkdQty=0
        containersScanned = ArrayList()
        viewModel.getPickTaskDetails()?.let {
            binding.tvTaskIdValue.text = it.taskId.toString()
            binding.itemCodeValue.text = it.itemCode
            binding.tvDescValue.text = it.itemDescription
            totalQty = it.taskQty
            // binding.pickedQuantityValue.text = if (pkdQty > 1) "$pkdQty pallets" else "$pkdQty pallet"
            updatePickedQuantity()
            if (viewModel.isPallet(it)) {

                if(viewModel.isSerialNumberField())
                {
                    binding.tvPalletSerialNumber.text = getString(R.string.pallet_serial_number)
                    binding.etPalletSerialNumber.hint = getString(R.string.pallet_serial_number)
                }else{
                    binding.tvPalletSerialNumber.text = getString(R.string.pallet_number)
                    binding.etPalletSerialNumber.hint = getString(R.string.pallet_number)
                }

                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} pallets" else "${it.taskQty} pallet"

            } else {

                if(viewModel.isSerialNumberField())
                {
                    binding.tvPalletSerialNumber.text = getString(R.string.container_serial_number)
                    binding.etPalletSerialNumber.hint = getString(R.string.container_serial_number)
                }else
                {
                    binding.tvPalletSerialNumber.text = getString(R.string.container_number)
                    binding.etPalletSerialNumber.hint = getString(R.string.container_number)
                }

                binding.pickQuantityValue.text = if (it.taskQty > 1) "${it.taskQty} cases" else "${it.taskQty} case"

            }
        }
    }

    private fun setListener() {
        binding.btnStage.setOnClickListener {
            viewModel.onStageFromUserDirectedScreen = true
            val action =
                FragmentPalletContainerSerialUserDirectedTivoPickFromDirections.actionPalletSerialNumberOneTivoPickFromFragmentToStagingLocationTivoPickFromFragment()
            moveToFragment(action)
        }
    }

    private fun validatePN() {
        if (!binding.etPalletSerialNumber.text.isNullOrEmpty()) {
            binding.tvError.text = ""
            //FlareLog.i(TAG, "PalletNumber field focused")
            val taskDetailId = viewModel.getPickTaskDetails()?.taskDetId
            val viewTaskPalletNumber = viewModel.getPickTaskDetails()?.containerNbr

            if (viewModel.isPallet(viewModel.getPickTaskDetails())) {
                val request = ValidatePalletContainerSerialNumberTivoPickReverseRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    userDirected = true,
                    taskUom = "P",
                    containerSerialNumber = binding.etPalletSerialNumber.text.toString().trim(),
                    taskDetailId = taskDetailId,
                    palletNumber = viewTaskPalletNumber
                )
                viewModel.validatePalletContainerSerialNumberTivoPickFromReserve(request, TivoPFR.VALIDATE_PALLET_NUMBER_USER_DIRECTED)

            } else {
                val request = ValidatePalletContainerSerialNumberTivoPickReverseRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    userDirected = true,
                    taskUom = "C",
                    containerNumber = binding.etPalletSerialNumber.text.toString().trim(),
                    taskDetailId = taskDetailId
                )
                viewModel.validatePalletContainerSerialNumberTivoPickFromReserve(request, TivoPFR.VALIDATE_CONTAINER_NUMBER_USER_DIRECTED)
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun markTaskComplete() {

        binding.tvError.text = ""
        viewModel.getPickTaskDetails()?.let {
            val scannedContainers = if (!viewModel.isPallet(it)) containersScanned else ArrayList()
            val palletId = if (viewModel.isPallet(it)) it.containerId.toString() else ""
            val palletNumber = if (viewModel.isPallet(it)) it.containerNbr else ""

            val request = MarkTaskCompleteRequestTivoPFR(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskId = it.taskId,
                taskDetId = it.taskDetId,
                pickQty = pkdQty,
                pickQtyUom = it.taskQtyUom,
                taskGroup = "PFR",
                lotNumber = it.lotNumber,
                expDate = "",
                palletId = palletId,
                palletNumber = palletNumber,
                userDirected = true,
                serialTracked = it.itemSerialTracked,
                containers = scannedContainers
            )

            // If current task has lot track or expired track than move to that screen
            val action = checkCurrentTaskType()
            if (action != null) {
                viewModel.markTaskCompleteRequest = request
                moveToFragment(action)

            } else {
                viewModel.taskReservePickCompleteTivoPFR(request)
            }
        }
    }

    private fun saveCompletedTask() {
        var taskList = viewModel.getTasksCompletedList()
        if (taskList == null) {
            taskList = ArrayList()
        }

        taskList.add(viewModel.getPickTaskDetails())
        viewModel.setTasksCompletedList(taskList)

    }

    private fun subscribeObservers() {

        viewModel.palletContainerSerialNumberValidationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tivoResponse ->
                        if (tivoResponse.success) {
                            //    binding.btnStage.isEnabled = true
                            binding.etPalletSerialNumber.setText("")
                            FlareLog.i(TAG, "tivo Response success: $tivoResponse")
                            val containerItem = ContainersItem(containerNumber = tivoResponse.caseNumber, containerId = tivoResponse.containerId)
                            containersScanned.add(containerItem)
                            pkdQty++
                            updatePickedQuantity()
                            if (pkdQty == totalQty) {
                                // update with new pallet number and pallet id
                                val data = viewModel.getPickTaskDetails()
                                //data?.containerId=tivoResponse.containerId.toInt()
                                if (viewModel.isPallet(data)) {
                                    data?.containerNbr = tivoResponse.palletNumber
                                    data?.containerId = tivoResponse.palletId.toInt()
                                } else {
                                    data?.containerNbr = tivoResponse.caseNumber
                                    data?.containerId = tivoResponse.containerId.toInt()
                                }
                                data?.let { viewModel.setPickTaskDetails(it) }
                                markTaskComplete()
                            }
                        } else {
                            if (viewModel.isPallet(viewModel.getPickTaskDetails())) {
                                if (viewModel.isSerialNumberField()) {
                                    binding.tvError.text = getString(R.string.invalid_pallet_serial_number)
                                } else {
                                    binding.tvError.text = getString(R.string.invalid_pallet_number)
                                }
                            } else {
                                if (viewModel.isSerialNumberField()) {
                                    binding.tvError.text = getString(R.string.invalid_container_serial_number)
                                } else {
                                    binding.tvError.text = getString(R.string.invalid_container_number)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                   /*     if (viewModel.isPallet(viewModel.getPickTaskDetails()))
                            binding.tvError.text = getString(R.string.invalid_pallet_serial_number)
                        else
                            binding.tvError.text = getString(R.string.invalid_container_serial_number)*/

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.markTaskCompleteTivoPFRResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success == true) {
                            FlareLog.i(TAG, "markTaskCompleteTivoPFRResponse success: $taskpickResponse")
                            binding.btnStage.isEnabled = true
                            saveCompletedTask()
                            if (taskpickResponse.taskDetails == null) {
                                //showErrorSnackBar(taskpickResponse.message ?: "")
                                showSuccessSnackBar(taskpickResponse.message?:getString(R.string.alert_all_tasks_completed))
                                binding.btnStage.performClick()
                            }
                            else{
                                taskpickResponse.taskDetails.let {
                                    viewModel.setPickTaskDetails(it)
                                }
                                goToBackScreen()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.containerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tivoResponse ->
                        if (tivoResponse.container.isNotEmpty()) {
                            binding.etPalletSerialNumber.setText("")
                           // binding.btnStage.isEnabled = true
                            FlareLog.i(TAG, "tivo Response success: $tivoResponse")
                            if(tivoResponse.container.isNotEmpty()) {
                                val container = tivoResponse.container.first()
                                val containerItem =
                                    ContainersItem(containerNumber = container.containerNumber, containerId = container.containerId.toString())
                                containersScanned.add(containerItem)
                            }
                            pkdQty++
                            updatePickedQuantity()
                            if (pkdQty == totalQty) {
                                markTaskComplete()
                            }
                        } else {
                            binding.tvError.text = getString(R.string.invalid_container_serial_number)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskPick Error: $message")
                       // showErrorSnackBar(message)
                        binding.tvError.text = message
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun goToBackScreen() {
        val navController =
            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        navController.popBackStack()
    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }



    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etPalletSerialNumber.setText(scan?.barcode.toString())
            binding.etPalletSerialNumber.text?.length?.let {
                binding.etPalletSerialNumber.setSelection(
                    it
                )
                FlareLog.i(TAG, "container number field focused")
                validatePN()
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb
        cb?.onVisibilityChange(true)
        FragmentPalletContainerSerialUserDirectedTivoPickFromDirections
    }
    private fun checkCurrentTaskType(): NavDirections? {
        return viewModel.getPickTaskDetails()?.let {
            val isLotTracked = it.itemLotTracked
            val isExpiredTracked = it.itemExpDateTracked
            val action =
                when {
                    isLotTracked != "0" -> {
                        FragmentPalletContainerSerialUserDirectedTivoPickFromDirections.actionPalletContainerSerialNumberUserDirectedPickFromFragmentToLotNumberTivoPickFromFragment()
                    }
                    isExpiredTracked != "0" -> {
                        FragmentPalletContainerSerialUserDirectedTivoPickFromDirections.actionPalletContainerSerialNumberUserDirectedPickFromFragmentToExpiryDateTivoPickFromFragment()
                    }
                    else -> {
                        null
                    }
                }

            action
        }
    }
}