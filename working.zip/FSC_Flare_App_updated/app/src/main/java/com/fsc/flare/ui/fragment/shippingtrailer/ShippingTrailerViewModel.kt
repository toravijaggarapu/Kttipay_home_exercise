package com.fsc.flare.ui.fragment.shippingtrailer

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBDockDoorRCLockRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorResponse
import com.fsc.flare.source.repository.ShippingTrailerRepository
import com.fsc.flare.utils.RecallCodes
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "ShippingTrailerViewModel"
@HiltViewModel
class ShippingTrailerViewModel @Inject constructor(
    private val shippingTrailerRepository: ShippingTrailerRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {
    val shipmentDDResponse: MutableLiveData<Resource<ShipmentDockDoorResponse>> = SingleLiveEvent()
    val dockDoorResponse: MutableLiveData<Resource<LocationInquiryResponse>> = SingleLiveEvent()
    val closeTrailerResponse: MutableLiveData<Resource<CloseTrailerResponse>> = SingleLiveEvent()

    private val _obCartonRCLockResponse = SingleLiveEvent<Resource<OBCartonRCLockResponse>>()

    internal val obCartonRCLockResponse: LiveData<Resource<OBCartonRCLockResponse>>
        get() = _obCartonRCLockResponse

    fun getDockDoorInfo(locBarCode: String) = viewModelScope.launch {
        dockDoorResponse.postValue(Resource.Loading())
        val response = shippingTrailerRepository.getDockDoorInfo(locBarCode)
        dockDoorResponse.postValue(handleDockDoorInquiryResponse(response))
    }

    private fun handleDockDoorInquiryResponse(response: Response<LocationInquiryResponse>): Resource<LocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG,"DockDoorInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "DockDoorInquiry Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getShipmentDockDoor(shipmentDockDoorRequest: ShipmentDockDoorRequest) = viewModelScope.launch {
        shipmentDDResponse.postValue(Resource.Loading())
        val shipmentResponse = shippingTrailerRepository.getShipmentDockDoor(shipmentDockDoorRequest)
        shipmentDDResponse.postValue(handleShipmentDDResponse(shipmentResponse))
    }

    private fun handleShipmentDDResponse(response: Response<ShipmentDockDoorResponse>): Resource<ShipmentDockDoorResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "shipmentDDResponse success response:$resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "shipmentDDR Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    var dockDoorShipment: MutableLiveData<ShipmentDockDoorResponse> = MutableLiveData<ShipmentDockDoorResponse>()
    fun getDockDoorShipment(): ShipmentDockDoorResponse? {
        return dockDoorShipment.value
    }

    fun setDockDoorShipment(dockDoorShipment: ShipmentDockDoorResponse) {
        this.dockDoorShipment.value = dockDoorShipment
    }

    fun closeTrailer(closeTrailerRequest: CloseTrailerRequest) = viewModelScope.launch {
        closeTrailerResponse.postValue(Resource.Loading())
        val shipmentResponse = shippingTrailerRepository.closeTrailer(closeTrailerRequest)
        closeTrailerResponse.postValue(handleCloseTrailerResponse(shipmentResponse))
    }

    private fun handleCloseTrailerResponse(response: Response<CloseTrailerResponse>): Resource<CloseTrailerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG,"CloseTrailerResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CloseTrailer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun viewRecallContainersAPIRequest(dockDoorId: Int) {
        viewModelScope.launch {
            fetchRCLockOBCartonDetails(
                OBDockDoorRCLockRequest(
                    dockDoorId = dockDoorId,
                    lock = RecallCodes.RECALL_LOCK
                )
            )
        }
    }

    private suspend fun fetchRCLockOBCartonDetails(obCartonRCLockRequest: OBDockDoorRCLockRequest) {
        _obCartonRCLockResponse.postValue(Resource.Loading())
        val response = shippingTrailerRepository.fetchRecallLockOBContainerDetails(obCartonRCLockRequest)
        _obCartonRCLockResponse.postValue(handleRCLockObCartonDetailsResponse(response))
    }

    private fun handleRCLockObCartonDetailsResponse(response: Response<OBCartonRCLockResponse>): Resource<OBCartonRCLockResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            return Resource.Error(errorResponse)
        }
        return null
    }
}