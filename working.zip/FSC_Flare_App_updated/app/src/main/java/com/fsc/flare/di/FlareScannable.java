package com.fsc.flare.di;

import com.fedex.services.blazar.Scannable;
import com.fedex.services.blazar.models.Scan;
import com.fedex.services.blazar.views.CustomScannableFragment;

public interface FlareScannable extends Scannable<Scan>, CustomScannableFragment<Scan> {
    void onScanError(String scanRaw, Exception ex);
}
