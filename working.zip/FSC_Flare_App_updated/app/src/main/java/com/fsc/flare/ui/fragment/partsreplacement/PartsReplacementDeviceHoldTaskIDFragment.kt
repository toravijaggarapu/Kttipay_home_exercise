package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementTaskdetailsTaskidBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementDeviceHoldTaskIDFragment::class.java.simpleName.toString()
@AndroidEntryPoint
class PartsReplacementDeviceHoldTaskIDFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var partsReplacementTaskIdBinding: FragmentPartsReplacementTaskdetailsTaskidBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails : List<TaskDetail>
    lateinit var task : List<Task>

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementTaskIdBinding =
            FragmentPartsReplacementTaskdetailsTaskidBinding.inflate(inflater, container, false)
        partsReplacementTaskIdBinding.lifecycleOwner = this
        return partsReplacementTaskIdBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()

        taskDetails?.let {
            with(partsReplacementTaskIdBinding) {
                tvTaskIdValue.text = it.get(viewModel.getDeviceContainerCountValue()).taskId
                tvDeviceContainerValue.text = it.get(viewModel.getDeviceContainerCountValue()).obContainerNumber
                tvToteValue.text =it.get(viewModel.getDeviceContainerCountValue()).toteNumber
            }
        }

        partsReplacementTaskIdBinding.etTaskIdValue.doAfterTextChanged {
            partsReplacementTaskIdBinding.errResponses.text = null
        }

        partsReplacementTaskIdBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementTaskIdBinding.etTaskIdValue)
                    if (partsReplacementTaskIdBinding.etTaskIdValue.isFocused) {
                        validateTaskID()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementTaskIdBinding.etTaskIdValue.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementTaskIdBinding.etTaskIdValue)
                validateTaskID()
            }
            false
        }
    }

    private fun validateTaskID() {
        val etTaskIDValue = partsReplacementTaskIdBinding.etTaskIdValue.text.toString().trim()
        if (etTaskIDValue.isNotEmpty()) {
            partsReplacementTaskIdBinding.errResponses.text = null
            if (partsReplacementTaskIdBinding.tvTaskIdValue.text.toString().trim()==etTaskIDValue){
                navigateToPartsReplacementDeviceContainerFragment()
            } else {
                displayErrorMessage(resources.getString(R.string.parts_replacement_taskID_error_message))
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementTaskIdBinding.etTaskIdValue.setText(scan?.barcode.toString())
        partsReplacementTaskIdBinding.etTaskIdValue.text?.length?.let {
            partsReplacementTaskIdBinding.etTaskIdValue.setSelection(it)
        }
        validateTaskID()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementTaskIdBinding.errResponses.text = errorMessage
        partsReplacementTaskIdBinding.etTaskIdValue.requestFocus()
        partsReplacementTaskIdBinding.etTaskIdValue.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementTaskIdBinding.etTaskIdValue)
    }

    private fun navigateToPartsReplacementDeviceContainerFragment() {
        val action =
            PartsReplacementDeviceHoldTaskIDFragmentDirections.actionPartsReplacementToteFragmentToPartsReplacementDeviceHoldContainerFragment()
        findNavController().navigate(action)
    }
}