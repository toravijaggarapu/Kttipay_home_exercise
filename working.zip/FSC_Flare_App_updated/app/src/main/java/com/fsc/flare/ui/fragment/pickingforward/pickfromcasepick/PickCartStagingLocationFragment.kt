package com.fsc.flare.ui.fragment.pickingforward.pickfromcasepick

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPickCartStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.RepairTaskRequest
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.ui.fragment.pickingforward.PickingForwardViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PickCartStagingLocationFragment"

@AndroidEntryPoint
class PickCartStagingLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentPickCartStagingLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    private var kittingStagingLocation:String? = null
    private var kittingStagingNeeded:Boolean = false

    private var kittingLocationId = 0

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentPickCartStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }

        val data = viewModel.getPickTask()
        if (data != null) {
            binding.cart.text = data.cartNbr
        }
        if (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "12" || sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "21") {
            kittingStagingNeeded = true
        }
        if(kittingStagingNeeded)
        {
            binding.stagingLocTv.text = getString(R.string.lbl_kitting_staging_location)
            binding.stagingLoc.hint = getString(R.string.lbl_kitting_staging_location)
            binding.kittingStagingLocationTv.visibility = View.VISIBLE
            binding.kittingStagingLocationValue.visibility = View.VISIBLE
            getKittingStageLocation()
        }else
        {
            binding.stagingLocTv.text = getString(R.string.staging_location)
            binding.stagingLoc.hint = getString(R.string.staging_location)
            binding.kittingStagingLocationTv.visibility = View.GONE
            binding.kittingStagingLocationValue.visibility = View.GONE
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "StagingLocation field focused")
                    if(kittingStagingNeeded)
                    {
                        validateKittingStationLocation()
                    }else
                    {
                        validateStagingLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.stagingLoc.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "StagingLocation field focused")
                if(kittingStagingNeeded)
                {
                    validateKittingStationLocation()
                }else
                {
                    validateStagingLocation()
                }
            }
            false
        }
        binding.stagingLoc.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.stagingLocResponse.text = null
            }
        })
        if (viewModel.cartToPRLocationTransferValue == viewModel.getToteToPrTransParamValue() && !viewModel.shortPickTotes.prLocExist && viewModel.shortPickTotes.toteDetails != null && viewModel.shortPickTotes.toteDetails!!.isNotEmpty()) {
            showAlertDialog("", resources.getString(R.string.lbl_short_picked_totes_slash_cartons_available_in_the_cart_but_no_pr_location)) {}
        }
    }

    private fun getKittingStageLocation() {
        val taskData = viewModel.getPickTaskDetails()
        if(taskData!=null)
        {
            if(taskData.orderId!=null)
            {
                val orderId = taskData.orderId
                val orderType = "WO"
                viewModel.getKittingStagingLocation(orderId!!, orderType)
            }else
            {
             showErrorSnackBar("Order ID is not present.")
            }
        }
    }
    private fun validateKittingStationLocation() {
        if (!binding.stagingLoc.text.isNullOrEmpty()) {
            if(kittingStagingLocation != null && kittingStagingLocation == binding.stagingLoc.text.toString().trim())
            {
                hideSoftKeyBoard(fragmentContext, binding.stagingLoc)
                val data = viewModel.getPickTask()
                val taskData = viewModel.getPickTaskDetails()
                if (data != null) {
                    if (taskData != null) {
                        viewModel.taskactivepickstaging(
                            TaskPickActiveStagingReq(
                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                cartId = data.cartId,
                                cartNumber = data.cartNbr,
                                locationId = kittingLocationId,
                                taskId = taskData.taskId,
                                allocationType = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null),
                                isLTLcubing = viewModel.isLTLCubingEnabled
                            ))
                    }
                }
                else{
                    binding.stagingLocResponse.text = "Invalid Data"
                }
            }else
            {
                binding.stagingLocResponse.text = "Invalid kit staging location"
            }

        }else
        {
            binding.stagingLocResponse.text = "Enter kit staging location"
            binding.stagingLoc.selectAll()
            showSoftKeyBoard(fragmentContext, binding.stagingLoc)
        }
    }

    private fun subscribeObservers() {

        viewModel.kittingStagingLocationResponse.observe(viewLifecycleOwner){response ->
            when(response){
                is Resource.Success ->{
                    hideProgressBar()
                    response.data?.let { kittingStageLocResponse ->
                        if (kittingStageLocResponse.success != null && kittingStageLocResponse.success) {
                            FlareLog.i(TAG, "kitting stage location success: $kittingStageLocResponse")
                            binding.kittingStagingLocationValue.text =
                                if (kittingStageLocResponse.orderProcessingLocation.locationBarcode != null) kittingStageLocResponse.orderProcessingLocation.locationBarcode else viewModel.getKitStageLocation()
                            kittingStagingLocation = kittingStageLocResponse.orderProcessingLocation.locationBarcode
                            kittingLocationId = kittingStageLocResponse.orderProcessingLocation.locationId
                        }else{
                            binding.stagingLocResponse.text = getString(R.string.invalid_staging_location)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.locationClassResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationClassResponse ->
                        if (locationClassResponse.success != null && locationClassResponse.success) {
                            FlareLog.i(TAG, "locationClass success: $locationClassResponse")
                            if (locationClassResponse.locations != null && locationClassResponse.locations.isNotEmpty()) {
                                val data = viewModel.getPickTask()
                                val taskData = viewModel.getPickTaskDetails()
                                if (indexExists(locationClassResponse.locations, 0)) {
                                    val location = locationClassResponse.locations[0]
                                    val locationClass = location.classification
                                    if (locationClass == "S") {
                                        val stagingLocationId = location.locationId
                                        if (data != null) {
                                            if (taskData != null) {
                                                viewModel.taskactivepickstaging(
                                                    TaskPickActiveStagingReq(
                                                        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                        cartId = data.cartId,
                                                        cartNumber = data.cartNbr,
                                                        locationId = stagingLocationId,
                                                        taskId = taskData.taskId,
                                                        allocationType = taskData.allocationType,
                                                        isLTLcubing = viewModel.isLTLCubingEnabled
                                                    )
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    binding.stagingLocResponse.text = getString(R.string.invalid_staging_location)
                                }
                            } else {
                                binding.stagingLocResponse.text = getString(R.string.invalid_staging_location)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationClass error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.taskactivepickstagingresponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { pickStagingResponse ->
                        if (pickStagingResponse.success != null && pickStagingResponse.success) {
                            if(pickStagingResponse.triggerRepair){
                                viewModel.initiateRepairFlow(RepairTaskRequest(
                                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                    customerOrderNumber = pickStagingResponse.customerOrderNumber,
                                    deviceHoldContNumber =pickStagingResponse.deviceHoldContNumber,
                                    orderId = pickStagingResponse.orderId,
                                    fromLocationId = pickStagingResponse.locationId,
                                    workOrderId = pickStagingResponse.workOrderId,
                                    obContainerId = pickStagingResponse.containerId
                                ))
                            }

                            if(pickStagingResponse.message!=null)
                            {
                                showSuccessSnackBar(pickStagingResponse.message)
                            }
                            FlareLog.i(TAG, "taskactivepickstaging success: $pickStagingResponse")
                            if(viewModel.isComingFromPickCartFlow ) {
                                Handler(Looper.getMainLooper()).postDelayed({
                                    val navController = Navigation.findNavController(
                                        requireActivity(),
                                        R.id.nav_host_fragment
                                    )
                                    val action =
                                        PickCartStagingLocationFragmentDirections.actionPickCartStagingLocFragmentToPickCartPalletFragment()
                                    val navOptions = NavOptions.Builder()
                                        .setPopUpTo(R.id.pickCartPalletFragment, true).build()
                                    navController.navigate(action, navOptions)
                                }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)

                            } else {
                                Handler(Looper.getMainLooper()).postDelayed({
                                    val action =
                                        PickCartStagingLocationFragmentDirections.actionPickCartStagingLocFragmentToBuildCartTaskGroup()
                                    val navOptions = NavOptions.Builder()
                                        .setPopUpTo(R.id.buildCartTaskGroup, true)
                                        .build()

                                    val bundle = if (viewModel.isRTV) {
                                        bundleOf(IS_RTV to true)
                                    } else {
                                        null
                                    }

                                    getNavigationController().navigate(action.actionId, bundle, navOptions)
                                }, Constants.ApplicationConstants.NAVIGATION_POST_DELAY_TIME)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskactivepickstaging error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.stagingLoc.setText(scan?.barcode.toString())
            binding.stagingLoc.text?.length?.let {
                binding.stagingLoc.setSelection(it)
            }
            FlareLog.i(TAG, "StagingLocation field focused")
            if(kittingStagingNeeded)
            {
                validateKittingStationLocation()
            }else
            {
                validateStagingLocation()
            }
    }
    private fun  validateStagingLocation() {
        if (!binding.stagingLoc.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.stagingLoc)
            viewModel.validateStagingLocation(
                LocationClassReq(
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    binding.stagingLoc.text.toString(),
                    "S"
                )
            )
        }
    }
    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")

    }

}