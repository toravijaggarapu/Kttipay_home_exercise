package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.repository.ReplenishDeliveryRepository
import com.fsc.flare.utils.getErrorCodeAndMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReplenishmentDeliveryTasksViewModel @Inject constructor(
    private val repository: ReplenishDeliveryRepository
) : BaseViewModel() {

    private val _taskScreenState = MutableStateFlow<ReplenishmentDeliveryTasksState?>(null)
    val taskScreenState = _taskScreenState.asStateFlow()

    fun getTask(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _taskScreenState.emit(ReplenishmentDeliveryTasksState.ShowLoading)
            val response = repository.getReplenishDeliveryTasks()
            _taskScreenState.emit(ReplenishmentDeliveryTasksState.HideLoading)
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { taskResponse ->
                taskResponse.taskDetails?.let { task ->
                    _taskScreenState.emit(ReplenishmentDeliveryTasksState.SuccessTask(task))
                } ?: _taskScreenState.emit(ReplenishmentDeliveryTasksState.GetTaskError())
            } ?: run {
                val errorPair = response.getErrorCodeAndMessage()
                _taskScreenState.emit(ReplenishmentDeliveryTasksState.GetTaskError(errorPair.second))
            }
        }
    }

    fun skipTask(
        scope: CoroutineScope = viewModelScope,
        taskId: Int,
        taskDetailId: Int
    ) {
        scope.launch {
            _taskScreenState.emit(ReplenishmentDeliveryTasksState.ShowLoading)
            val response = repository.skipReplenishDeliveryTask(
                taskId = taskId,
                taskDetailId = taskDetailId
            )
            _taskScreenState.emit(ReplenishmentDeliveryTasksState.HideLoading)
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { taskResponse ->
                taskResponse.taskDetails?.let { task ->
                    _taskScreenState.emit(ReplenishmentDeliveryTasksState.SuccessTask(task))
                } ?: _taskScreenState.emit(ReplenishmentDeliveryTasksState.SkipTaskError())
            } ?: run {
                val errorPair = response.getErrorCodeAndMessage()
                _taskScreenState.emit(ReplenishmentDeliveryTasksState.SkipTaskError(errorPair.second))
            }
        }
    }

    fun clearScreenState() {
        _taskScreenState.value = null
    }
}

sealed class ReplenishmentDeliveryTasksState {
    data object ShowLoading : ReplenishmentDeliveryTasksState()
    data object HideLoading : ReplenishmentDeliveryTasksState()
    data class SuccessTask(val task: ReplenishDeliveryTask) : ReplenishmentDeliveryTasksState()
    data class GetTaskError(val message: String? = null) : ReplenishmentDeliveryTasksState()
    data class SkipTaskError(val message: String? = null) : ReplenishmentDeliveryTasksState()
}