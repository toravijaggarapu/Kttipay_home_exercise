package com.fsc.flare.ui.fragment.replenish.loadcartpallet

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishBlindContainerDetailsBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.source.data.dto.replenishment.ValidateBlindContainerRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ReplenishLoadCartBlindC"

@AndroidEntryPoint
class ReplenishLoadCartBlindContainerDetailsFragment : BaseFragment(), FlareScannable {

    private val viewModel: ReplenishViewModel by activityViewModels()
    private lateinit var binding: FragmentReplenishBlindContainerDetailsBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenishBlindContainerDetailsBinding.inflate(inflater, container, false)
        binding.replenishViewModel = viewModel
        binding.lifecycleOwner = this
        binding.tvReplenish.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "validate BlindContainer called")
                    validateBlindContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val cartData = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()
        binding.txtCartPalletRes.text = cartData?.cartNbr
        if (taskData != null) {
            binding.txtTaskIDRes.text = taskData.taskId.toString()
            binding.txtItemRes.text = taskData.itemCode
            binding.txtDesRes.text = taskData.itemDescription
            binding.txtLocationRes.text = taskData.locationBarcode
            binding.txtContainerRes.text = taskData.containerNbr
            binding.txtPickQtyRes.text =
                String.format("%d %s",taskData.taskQty,taskData.taskQtyUom)
        }
        binding.etBlindContainerNo.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "validate BlindContainer called")
                validateBlindContainer()
            }
            false
        }
        binding.etBlindContainerNo.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.blindContainerResponse.text = null
            }
        })
    }

    private fun validateBlindContainer() {
        if (!binding.etBlindContainerNo.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etBlindContainerNo)
            val data = viewModel.getReplenTask()
            val taskdata = viewModel.getReplenTaskDetails()
            viewModel.validateBlindContainer(
                ValidateBlindContainerRequest(
                    sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                    binding.etBlindContainerNo.text.toString(),
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    data?.cartId.toString(),
                    data?.cartNbr.toString(),
                    taskdata?.taskDetId.toString(),
                    taskdata?.taskId.toString()
                )
            )
        }
    }

    private fun subscribeObservers() {
        viewModel.validateBlindContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { blindContainerResponse ->
                        FlareLog.i(TAG, "blindContainer response $response")
                        if (blindContainerResponse != null) {
                            if (blindContainerResponse.success) {
                                FlareLog.i(TAG, "blindContainer success: " + blindContainerResponse.message)
                                if (blindContainerResponse.taskDetails != null) {
                                    viewModel.setReplenTaskDetails(blindContainerResponse.taskDetails)
                                    val action =
                                        ReplenishLoadCartBlindContainerDetailsFragmentDirections.actionLoadCartBlindContainerToLoadCartContainer()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.loadCartContainer, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                } else {
                                    viewModel.updateReplenEndCart(
                                        TaskReplenEndCartRequest(
                                            sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!.toInt(),
                                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                                            binding.txtCartPalletRes.text.toString()
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "blindContainer error: $message")
                        binding.blindContainerResponse.text = message
                        binding.etBlindContainerNo.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etBlindContainerNo)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.endCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data.let { endCartResponse ->
                        FlareLog.i(TAG, "endCartResponse: $endCartResponse")
                        if (endCartResponse != null) {
                            if (endCartResponse.success) {
                                FlareLog.i(TAG, "endCartResponse success: $endCartResponse")
                                when {
                                    endCartResponse.taskDetails != null -> {
                                        viewModel.setReplenTaskDetails(endCartResponse.taskDetails)
                                        val action =
                                            ReplenishLoadCartBlindContainerDetailsFragmentDirections.actionLoadCartBlindContainerToFillCasePickContainer()
                                        val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenFillCasePickContainer, true).build()
                                        getNavigationController().navigate(action, navOptions)
                                    }
                                    endCartResponse.promptStage -> {
                                        val action =
                                            ReplenishLoadCartBlindContainerDetailsFragmentDirections.actionLoadCartBlindContainerToReplenStagingLocationFragment()
                                        val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenStagingLocationFragment, true).build()
                                        getNavigationController().navigate(action, navOptions)
                                    }
                                    else -> {
                                        val action =
                                            ReplenishLoadCartBlindContainerDetailsFragmentDirections.actionLoadCartBlindContainerToLoadCartTaskGroup()
                                        val navOptions = NavOptions.Builder().setPopUpTo(R.id.replenLoadCartOrPallet, true).build()
                                        getNavigationController().navigate(action, navOptions)
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "endCartResponse error: $message")
                        if (message != null) {
                            showErrorSnackBar(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etBlindContainerNo.setText(scan?.barcode.toString())
            binding.etBlindContainerNo.text?.length?.let {
                binding.etBlindContainerNo.setSelection(it)
            }
            validateBlindContainer()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}