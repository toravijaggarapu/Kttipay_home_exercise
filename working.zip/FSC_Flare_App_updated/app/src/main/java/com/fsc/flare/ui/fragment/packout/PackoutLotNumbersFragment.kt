package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutLotNumbersBinding
import com.fsc.flare.log.FlareLog
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "PackoutLotNumbersFragment"

@AndroidEntryPoint
class PackoutLotNumbersFragment : BaseFragment() {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutLotNumbersBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutLotNumbersBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        setUpData()
        return binding.root
    }

    fun setUpData(){
        binding.tvDockDoorValue.text = viewModel.getLocationBarcode()
        if (viewModel.getPalletReqNumber() == "") {
            binding.tvPallet.visibility = View.GONE
        } else {
            binding.tvPalletValue.text = viewModel.getPalletReqNumber()
        }
        binding.tvCartonValue.text = viewModel.getcartonReqNumber()
        binding.itemCode.text = viewModel.getitemData()
        binding.tvDescValue.text = viewModel.getItemDesc()
        binding.tvLotNumber.visibility = View.VISIBLE

        binding.btnEndPackout.isEnabled = false
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    fun setUpListeners(){
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
            Log.d("debug", "BackButton Clicked")
            navigateToBack()
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            FlareLog.i(TAG, "${event?.action}")
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        val lotNumbersList = ArrayList<String>(viewModel.getLotNumbers(viewModel.currentItemBarCode))
        binding.lotNumberSpinner.setOptions(lotNumbersList)
        binding.lotNumberSpinner.boolFoo.observe(viewLifecycleOwner) { isUpdated ->
            validateField()
        }
    }

    fun navigateToBack() {
        findNavController().popBackStack()
    }

    private fun validateField() {
        binding.lotNumberSelectionError.text = ""
        if (binding.lotNumberSpinner.text == getString(R.string.select_lot_number)) {
            binding.lotNumberSelectionError.text = getString(R.string.select_lot_number)
        } else {
            viewModel.lotNumberSelectedFromDeKitting = true
            viewModel.setlotNumber(binding.lotNumberSpinner.text.toString())

            if (viewModel.isItemHasMultipleInventoryTypes()) {
                // Show InventoryTypesFragment
                val action =
                    PackoutLotNumbersFragmentDirections.actionPackoutLotNumbersFragmentToPackoutInventoryTypesFragment()
                moveToFragment(action)
            } else {
                // Show LockCodesFragment
                val action =
                    PackoutLotNumbersFragmentDirections.actionPackoutLotNumbersFragmentToPackoutLockCodeFragment()
                moveToFragment(action)
            }
        }
    }

}