package com.fsc.flare.log

import android.net.Uri
import android.util.Log
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.LoggerContext
import ch.qos.logback.classic.android.LogcatAppender
import ch.qos.logback.classic.encoder.PatternLayoutEncoder
import ch.qos.logback.classic.spi.ILoggingEvent
import ch.qos.logback.core.rolling.RollingFileAppender
import ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy
import ch.qos.logback.core.util.FileSize
import ch.qos.logback.core.util.StatusPrinter
import com.fsc.flare.BuildConfig
import org.slf4j.Logger
import org.slf4j.LoggerFactory

object FlareLog {
    private const val LOG_TAG = "FlareLog"
    private var sLogger: Logger? = null
    private val sFileAppender: RollingFileAppender<ILoggingEvent>? = null
    var logFilesDirectory: String? = null
        private set
    private var sLogFileNameNoExtension: String? = null
    private const val LOG_MESSAGE_FORMATTER = "%1\$s|%2\$s"
    private const val CAPTAINS_LOG_MESSAGE_FORMAT = "%d{'yyyy-MM-dd HH:mm:ss,SSS'} GMT%d{ZZZ}  %-5p %m%n"

    //https://github.com/tony19/logback-android/wiki/Appender-Notes
    fun initializeFlareLog(logDirectory: String?, logFileNameNoExtension: String?) {
        if (sLogger == null) {
            val logbackContext = LoggerFactory.getILoggerFactory() as LoggerContext
            logbackContext.reset()
            logFilesDirectory = logDirectory
            sLogFileNameNoExtension = logFileNameNoExtension
            val fileAppender = RollingFileAppender<ILoggingEvent>()
            fileAppender.isAppend = true
            fileAppender.name = LOG_TAG
            fileAppender.context = logbackContext
            val logFilePattern = Uri.Builder()
                .appendEncodedPath(logFilesDirectory)
                .appendEncodedPath("$sLogFileNameNoExtension.%d.%i.txt")
                .build()
                .toString()
            val rollingPolicy = SizeAndTimeBasedRollingPolicy<ILoggingEvent>()
            rollingPolicy.fileNamePattern = logFilePattern
            rollingPolicy.maxHistory = 10
            rollingPolicy.setMaxFileSize(FileSize.valueOf("1 mb"))
            rollingPolicy.setParent(fileAppender)
            rollingPolicy.context = logbackContext
            rollingPolicy.start()
            fileAppender.rollingPolicy = rollingPolicy
            val encoder = PatternLayoutEncoder()
            encoder.pattern = CAPTAINS_LOG_MESSAGE_FORMAT
            encoder.context = logbackContext
            encoder.start()
            fileAppender.encoder = encoder
            fileAppender.start()
            val root =
                LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME) as ch.qos.logback.classic.Logger
            root.level =
                if (BuildConfig.DEBUG) Level.DEBUG else Level.INFO
            root.addAppender(fileAppender)
            if (BuildConfig.DEBUG) {
                val msgPattern = PatternLayoutEncoder()
                msgPattern.context = logbackContext
                msgPattern.pattern = "%msg"
                msgPattern.start()
                val logcatAppender = LogcatAppender()
                logcatAppender.context = logbackContext
                logcatAppender.name = "Logcat"
                logcatAppender.encoder = msgPattern
                logcatAppender.start()
                root.addAppender(logcatAppender)
            }
            StatusPrinter.print(logbackContext)
            sLogger = LoggerFactory.getLogger(FlareLog::class.java)
        }
    }

    fun i(logTag: String, logMessage: String) {
        log(logTag, logMessage, null, Level.INFO_INT)
    }

    fun i(logTag: String, logMessage: String, e: Throwable?) {
        log(logTag, logMessage, e, Level.INFO_INT)
    }

    fun d(logTag: String, logMessage: String) {
        log(logTag, logMessage, null, Level.DEBUG_INT)
    }

    fun d(logTag: String, logMessage: String, e: Throwable?) {
        log(logTag, logMessage, e, Level.DEBUG_INT)
    }

    fun w(logTag: String, logMessage: String) {
        log(logTag, logMessage, null, Level.WARN_INT)
    }

    fun w(logTag: String, logMessage: String, e: Throwable?) {
        log(logTag, logMessage, e, Level.WARN_INT)
    }

    fun e(logTag: String, logMessage: String) {
        log(logTag, logMessage, null, Level.ERROR_INT)
    }

    fun e(logTag: String, logMessage: String, e: Throwable?) {
        log(logTag, logMessage, e, Level.ERROR_INT)
    }

    fun t(logTag: String, logMessage: String) {
        log(logTag, logMessage, null, Level.TRACE_INT)
    }

    fun t(logTag: String, logMessage: String, e: Throwable?) {
        log(logTag, logMessage, e, Level.TRACE_INT)
    }

    private fun log(logTag: String, logMessage: String, e: Throwable?, level: Int) {
        if (sLogger != null) {
            useCaptainLogger(String.format(LOG_MESSAGE_FORMATTER, logTag, logMessage), e, level)
        } else {
            useAndroidLogger(
                logTag,
                String.format(LOG_MESSAGE_FORMATTER, logTag, logMessage),
                e,
                level
            )
        }
    }

    private fun useCaptainLogger(logMessage: String, e: Throwable?, level: Int) {
        when (level) {
            Level.DEBUG_INT -> sLogger!!.debug(logMessage, e)
            Level.ERROR_INT -> sLogger!!.error(logMessage, e)
            Level.INFO_INT -> sLogger!!.info(logMessage, e)
            Level.TRACE_INT -> sLogger!!.trace(logMessage, e)
            Level.WARN_INT -> sLogger!!.warn(logMessage, e)
            else -> {}
        }
    }

    private fun useAndroidLogger(logTag: String, logMessage: String, e: Throwable?, level: Int) {
        when (level) {
            Level.DEBUG_INT, Level.TRACE_INT -> Log.d(logTag, logMessage, e)
            Level.ERROR_INT -> Log.e(logTag, logMessage, e)
            Level.INFO_INT -> Log.i(logTag, logMessage, e)
            Level.WARN_INT -> Log.w(logTag, logMessage, e)
            else -> {}
        }
    }

    fun reset() {
        sLogger = null
        initializeFlareLog(logFilesDirectory, sLogFileNameNoExtension)
    }
}