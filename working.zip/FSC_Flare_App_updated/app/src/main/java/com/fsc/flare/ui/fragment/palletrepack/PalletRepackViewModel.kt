package com.fsc.flare.ui.fragment.palletrepack

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.masterpalletrepack.*
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitResponse
import com.fsc.flare.source.repository.MasterPalletRepackRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PalletRepackViewModel"

@HiltViewModel
class PalletRepackViewModel @Inject constructor(
    private val masterPalletRepackRepository: MasterPalletRepackRepository
) : BaseViewModel() {

    val printRequestorResponse: MutableLiveData<Resource<PrintRequesterResponse>> = SingleLiveEvent()
    val mprTransParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> = SingleLiveEvent()
    val mprSubmitResponse: MutableLiveData<Resource<MPRSubmitResponse>> = SingleLiveEvent()

    //val containerResponse: MutableLiveData<Resource<UserDirectedPutawayContainerResponse>> = SingleLiveEvent()
    val palletDetailKey = "pallet"
    val containerDetailKey = "Container"
    val newCaseNumberKey = "casenum"
    val palletTransferTypeKey = "PALLET"

    val palletDetailResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val locationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val submitUDPutawayResponse: MutableLiveData<Resource<UserDirectedPutawaySubmitResponse>> = SingleLiveEvent()
    val transactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val containerDetailResponse: MutableLiveData<Resource<CaseTransferContainerResponse>> = SingleLiveEvent()


    val itemCodeResponse: MutableLiveData<Resource<MasterPalletRepackItemCodeResponse>> = SingleLiveEvent()
    val masterPalletRepackTempContainerResponse: MutableLiveData<Resource<MasterPalletRepackTempContainerResponse>> = SingleLiveEvent()
    val masterPalletRepackTempPalletResponse: MutableLiveData<Resource<MasterPalletRepackTempContainerResponse>> = SingleLiveEvent()
    val masterPalletRepackTempPostResponse: MutableLiveData<Resource<MasterPalletRepackTempContainerResponse>> = SingleLiveEvent()
    val printContainerLabelResponse: MutableLiveData<Resource<PrintContainerLabelResponse>> = SingleLiveEvent()
    val containerInfo= arrayListOf<String>()

    /**
     * method to get printer requestor config list
     */
    fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) = viewModelScope.launch {
        printRequestorResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.getPrintRequestorList(printerConfigRequest)
        printRequestorResponse.postValue(handlePrintRequestorListResponse(response))
    }

    /**
     * method to handle printer requestor config response
     */
    private fun handlePrintRequestorListResponse(response: Response<PrintRequesterResponse>): Resource<PrintRequesterResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PrintRequesterResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get container details
     */
    fun getPalletDetail(palletNumber: String, itemInfo: String) = viewModelScope.launch {
        palletDetailResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.getContainer(palletNumber, itemInfo)
        palletDetailResponse.postValue(handlePalletDetailResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handlePalletDetailResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Pallet Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateContainerDetail(containerNumber: String, transferType: String) = viewModelScope.launch {
        containerDetailResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.validateContainer(containerNumber, transferType)
        containerDetailResponse.postValue(handleContainerResponse(response))
    }

    private fun handleContainerResponse(response: Response<CaseTransferContainerResponse>): Resource<CaseTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to get location details
     */
    fun validateLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "Location Request: $locationClassReq")
        locationResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.validateLocation(locationClassReq)
        locationResponse.postValue(handleLocationResponse(response))
    }

    /**
     * method to handle location response
     */
    private fun handleLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to get transaction param details
     */
    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionParamResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.getTransactionParam(transactionParamRequest)
        transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(transactionParamResponse.code(), transactionParamResponse.errorBody(), transactionParamResponse.message())
            FlareLog.e(TAG, "TransactionParam Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun generatePalletCaseNumber(type: String) = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.generatePalletCaseNumber(type)
        newPalletDetailResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get transaction param details
     */
    fun getMPRTransactionParam(mprTransParamRequest: MPRTransParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "MPRtransactionParam Request: $mprTransParamRequest")
        mprTransParamResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.getMPRTransactionParam(mprTransParamRequest)
        mprTransParamResponse.postValue(handleMPRTransactionParamResponse(response))
    }

    /**
     * method to handle MPR transaction param response
     */
    private fun handleMPRTransactionParamResponse(response: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "MPRTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "MPRTransactionParamResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateItemCode(itemCode: String) = viewModelScope.launch {
        itemCodeResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.validateItemCode(itemCode)
        itemCodeResponse.postValue(handleItemCodeResponse(response))
    }

    private fun handleItemCodeResponse(response: Response<MasterPalletRepackItemCodeResponse>): Resource<MasterPalletRepackItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateTempTable(palletNumber: String, containerNumber: String) = viewModelScope.launch {
        masterPalletRepackTempContainerResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.validateTempTable(palletNumber, containerNumber)
        masterPalletRepackTempContainerResponse.postValue(handleTempContainerResponse(response))
    }

    fun validateTempTablePallet(palletNumber: String, containerNumber: String) = viewModelScope.launch {
        masterPalletRepackTempPalletResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.validateTempTable(palletNumber, containerNumber)
        masterPalletRepackTempPalletResponse.postValue(handleTempContainerResponse(response))
    }

    private fun handleTempContainerResponse(response: Response<MasterPalletRepackTempContainerResponse>): Resource<MasterPalletRepackTempContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TempContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TempContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun postTempTable(palletRepackPostRequest: PalletRepackPostRequest) = viewModelScope.launch {
        masterPalletRepackTempPostResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.postTempContainer(palletRepackPostRequest)
        masterPalletRepackTempPostResponse.postValue(handleTempTablePostResponse(response))
    }

    fun printContainerLabels(printContainerLabelRequest: PrintContainerLabelRequest) = viewModelScope.launch {
        printContainerLabelResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.printContainerLabelInfo(printContainerLabelRequest)
        printContainerLabelResponse.postValue(handlePrintContainerLabelResponse(response))
    }

    private fun handleTempTablePostResponse(response: Response<MasterPalletRepackTempContainerResponse>): Resource<MasterPalletRepackTempContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TempContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TempContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handlePrintContainerLabelResponse(response: Response<PrintContainerLabelResponse>): Resource<PrintContainerLabelResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Print Container Label Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Print Container Label Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to submit MPR
     */
    fun submitMPR(mprSubmitRequest: MPRSubmitRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "SubmitMPR Request: $mprSubmitRequest")
        mprSubmitResponse.postValue(Resource.Loading())
        val response = masterPalletRepackRepository.submitMPR(mprSubmitRequest)
        mprSubmitResponse.postValue(handleSubmitMPRResponse(response))
    }

    /**
     * method to handle Submit MPR Response
     */
    private fun handleSubmitMPRResponse(response: Response<MPRSubmitResponse>): Resource<MPRSubmitResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SubmitMPRResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SubmitMPRResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    //Save data into view model
    private var mprTransactionParamData: MutableLiveData<MPRepackTransParamResponse> = MutableLiveData<MPRepackTransParamResponse>()
    private var selectedPrinterData: MutableLiveData<PrinterConfig> = MutableLiveData<PrinterConfig>()
    private  var printCaseLabelData: Boolean = false
    private var printPalletLabelData: Boolean = false
    private var printertNameData: String = ""
    var transactionIdentifier: MutableLiveData<Int> = MutableLiveData<Int>()

    private var palletRepackData = MutableLiveData<PalletRepackData>()
    private var itemId = ""
    private var masterPalletRepackItemCodeResponse = MasterPalletRepackItemCodeResponse()
    private var masterPalletRepackTempTableResponse = MasterPalletRepackTempContainerResponse()
    private val containerSerialNumbers =  MutableLiveData<List<MasterPalletRepackTempContainerResponse.SerialNumbersEntity>?>()
    private var allSerialNumbers =  arrayListOf<String>()
    private val transactionParamHahMap = HashMap<String, Boolean>()

    fun setMPRTransactionParamData(transactionParamResponse: MPRepackTransParamResponse?) {
        transactionParamResponse!!.transParams?.forEach {
            transactionParamHahMap[it.transCode] = it.required
        }
        this.mprTransactionParamData.value = transactionParamResponse
    }

    fun getMPRTransactionParamData(): MPRepackTransParamResponse? {
        return mprTransactionParamData.value
    }

    fun setSelectedPrinterData(printerConfig: PrinterConfig?) {
        this.selectedPrinterData.value = printerConfig
    }

    fun getSelectedPrinterData(): PrinterConfig? {
        return selectedPrinterData.value
    }

    fun setPalletData(palletNumber: PalletRepackData) {
        this.palletRepackData.value = palletNumber
    }

    fun getPalletData(): PalletRepackData {
        return palletRepackData.value!!
    }

    fun getItemId(): String {
        return itemId
    }

    fun setItem(itemId: String) {
        this.itemId = itemId
    }

    fun setItemResponse(response: MasterPalletRepackItemCodeResponse) {
        masterPalletRepackItemCodeResponse = response
    }

    fun getItemResponse(): MasterPalletRepackItemCodeResponse {
        return masterPalletRepackItemCodeResponse
    }

    fun setTempTableData(tempTableData: MasterPalletRepackTempContainerResponse?) {
        if (tempTableData != null) {
            masterPalletRepackTempTableResponse = tempTableData
        }
    }

    fun saveContainerSerialNumbers(serialNumbers: List<MasterPalletRepackTempContainerResponse.SerialNumbersEntity>?) {
        containerSerialNumbers.value = serialNumbers
    }

    fun getContainerSerialNumbers(): List<MasterPalletRepackTempContainerResponse.SerialNumbersEntity>? {
        return containerSerialNumbers.value
    }

    fun setSerialNumbers(containerDetails: List<MasterPalletRepackTempContainerResponse.ContainerDetailsEntity>): ArrayList<String> {
        val allSerialList = arrayListOf<String>()
        for (container in containerDetails) {
            for (serialNumberObj in container.serialNumbers!!) {
                allSerialList.add(serialNumberObj.serialNumber!!)
            }
        }
        allSerialNumbers = allSerialList
        return allSerialList
    }

    fun getSerialNumbers(): List<String> {
        return allSerialNumbers
    }

    fun setPrintCaseLabelData(boolean: Boolean) {
        this.printCaseLabelData = boolean
    }

    fun getPrintCaseLabelData(): Boolean {
        return printCaseLabelData
    }

    fun setPrintPalletLabelData(boolean: Boolean) {
        this.printPalletLabelData = boolean
    }

    fun setPrinterNameData(string: String) {
        this.printertNameData = string
    }

    fun getPrinterNameData(): String {
        return printertNameData
    }

    fun setTempTableTransactionIdentifier(transactionIdentifier : Int) {
        this.transactionIdentifier.value = transactionIdentifier
    }

    fun getTempTableTransactionIdentifier(): Int {
        return transactionIdentifier.value!!
    }

    /**
     * method to get transactionParam to configure
     */
    fun getTransactionParamByTransCode(transCode:String): Boolean {
        return transactionParamHahMap[transCode]!!
    }

    fun getPalletQuantity(containersList: List<MasterPalletRepackTempContainerResponse.ContainerDetailsEntity>): Int {
        var quantity = 0
        for (container in containersList) {
            quantity += container.containerQty
        }
        return quantity
    }

    fun saveContainerNumber(containerNumber:String){
        if(!containerInfo.contains(containerNumber))
            containerInfo.add(containerNumber)
    }

    fun setDataToDefault() {
        setItem("")
        containerInfo.clear()
        allSerialNumbers.clear()
        containerSerialNumbers.value = null
    }
}