package com.fsc.flare.ui.fragment.inventory.containertoactive

import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerLocationRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTransferLocationResponse
import com.fsc.flare.source.repository.InventoryRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private val TAG = CTAViewModel::class.java.simpleName.toString()
@HiltViewModel
class CTAViewModel @Inject constructor(
    private val inventoryRepository: InventoryRepository
) : BaseViewModel() {

    private val _ctaContainerResponse = SingleLiveEvent<Resource<InventoryTransferContainerResponse>>()
    private val _ctaLocationResponse = SingleLiveEvent<Resource<InventoryTransferLocationResponse>>()
    private val _locationResponse = SingleLiveEvent<Resource<LocationInquiryResponse>>()
    fun getCTAContainerResponse(): LiveData<Resource<InventoryTransferContainerResponse>> {
        return _ctaContainerResponse
    }

    var ctaContainerResponse: InventoryTransferContainerResponse? = null
    fun fetchCtaContainerResponse(): InventoryTransferContainerResponse? = ctaContainerResponse
    fun getCTALocationResponse(): LiveData<Resource<InventoryTransferLocationResponse>> {
        return _ctaLocationResponse
    }

    var ctaLocationResponse: InventoryTransferLocationResponse? = null
    fun fetchCtaLocationResponse(): InventoryTransferLocationResponse? = ctaLocationResponse

    fun getLocationResponse(): LiveData<Resource<LocationInquiryResponse>> {
        return _locationResponse
    }
    fun inventoryTransferContainer(ctaContainerRequest: GetContDetailRequest) = viewModelScope.launch {
        _ctaContainerResponse.postValue(Resource.Loading())
        val response = inventoryRepository.inventoryTransferContainerResponse(ctaContainerRequest)
        _ctaContainerResponse.postValue(handleCTAContainerResponse(response))
    }

    private fun handleCTAContainerResponse(response: Response<InventoryTransferContainerResponse>): Resource<InventoryTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CTAContainerResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CTAContainerResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun getLocationInfo(locBarCode: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getLocationInfo Request: $locBarCode")
        _locationResponse.postValue(Resource.Loading())
        val response = inventoryRepository.getLocationInfo(locBarCode)
        _locationResponse.postValue(handleLocationInquiryResponse(response))
    }

    private fun handleLocationInquiryResponse(response: Response<LocationInquiryResponse>): Resource<LocationInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "LocationInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "LocationInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun inventoryTransferContainerLocation(inventoryTransferContainerLocationRequest: InventoryTransferContainerLocationRequest) =
        viewModelScope.launch {
            _ctaLocationResponse.postValue(Resource.Loading())
            val response = inventoryRepository.inventoryTransferContainerLocationResponse(inventoryTransferContainerLocationRequest)
            _ctaLocationResponse.postValue(handleCTALocationResponse(response))
        }

    private fun handleCTALocationResponse(response: Response<InventoryTransferLocationResponse>): Resource<InventoryTransferLocationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryTransferLocationResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryTransferLocationResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}