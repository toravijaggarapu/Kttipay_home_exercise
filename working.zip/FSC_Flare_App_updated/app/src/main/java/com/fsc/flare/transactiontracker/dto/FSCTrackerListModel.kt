package com.fsc.flare.transactiontracker.dto

data class FSCTrackerListModel(
    var transactionType: String = "",
    var startTimeStamp: String?,
    var endTimeStamp: String?,
    var events: ArrayList<FSCTransactionDetailModel>,
    var customerId: Long? = null,
    var businessId: Long? = null,
    var facilityId: Long? = null,
    var enrollmentType: String? = null
)
