package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenDeliveryTaskModeBinding
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [ReplenishmentDeliveryTaskModeFragment] class.
 */
@AndroidEntryPoint
class ReplenishmentDeliveryTaskModeFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var binding: FragmentReplenDeliveryTaskModeBinding
    private val sharedViewModel: ReplenishmentDeliverySharedViewModel by activityViewModels()

    private val taskModeList by lazy {
        ArrayList<String>().apply {
            add(getString(R.string.system_directed))
            add(getString(R.string.user_directed))
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentReplenDeliveryTaskModeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Set the header title
        binding.tvHeaderTitle.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)

        binding.ddPickTaskMode.setOptions(taskModeList)
        binding.ddPickTaskMode.boolFoo.observe(viewLifecycleOwner) { isUpdated ->

            sharedViewModel.clearData()

            val action = if (isUpdated == getString(R.string.user_directed)) {
                sharedViewModel.selectedTaskMode = USER_DIRECTED
                ReplenishmentDeliveryTaskModeFragmentDirections.actionReplenDeliveryTaskGroupToReplenDeliveryPallet()
            } else {
                sharedViewModel.selectedTaskMode = SYSTEM_DIRECTED
                ReplenishmentDeliveryTaskModeFragmentDirections.actionReplenDeliveryTaskGroupToReplenDeliveryTask()
            }

            findNavController().navigate(action)
        }
    }
}