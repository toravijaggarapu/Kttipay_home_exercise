package com.fsc.flare.ui.fragment.home

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockCodeResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.data.dto.login.FacilityInfo
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.login.UserModulesByCustomer
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.LookupCode
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.repository.AccountRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.LockCodeValuesUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import com.fsc.flare.utils.Utility
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Runnable
import kotlinx.coroutines.launch
import retrofit2.Response
import java.lang.RuntimeException
import java.util.Calendar
import javax.inject.Inject

private const val TAG = "HomeViewModel"

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val accountRepository: AccountRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {
    val fetchAuthMenu = SingleLiveEvent<Resource<AuthorizedMenu>>()
    val containerType = SingleLiveEvent<Resource<CustomerContainerTypes>>()
    val facilityInfo: MutableLiveData<Resource<FacilityInfo>> = MutableLiveData()
    val updateLastLoginResponse: MutableLiveData<Resource<LangUpdateResponse>> = MutableLiveData()
    val lookUpResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val allTransactionsParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> =
        SingleLiveEvent()
    var transValue: MutableLiveData<String> = MutableLiveData()


    /**
     * method to get inventory lockcodes
     *
     *
     */
    val inventoryLockcodeResponse: MutableLiveData<Resource<InventoryLockCodeResponse>> =
        SingleLiveEvent()

    fun getInventoryLockcodes(inventoryLockcodeRequest: InventoryLockcodeRequest) =
        viewModelScope.launch {
            inventoryLockcodeResponse.postValue(Resource.Loading())
            val response = accountRepository.getInventoryLockCodes(inventoryLockcodeRequest)
            inventoryLockcodeResponse.postValue(handleInventoryLockCodesResponse(response))
        }

    /**
     * method to handle inventory lockcodes response
     */
    private fun handleInventoryLockCodesResponse(response: Response<InventoryLockCodeResponse>): Resource<InventoryLockCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryLockcodesResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "getInventoryLockcodes Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setTransValue(transValue: String) {
        this.transValue.value = transValue
    }

    fun getTransValue(): String {
        return transValue.value!!
    }

    var userModulesByCustomerList = mutableListOf<UserModulesByCustomer>()
    fun fetchUserModulesByCustomerList(): MutableList<UserModulesByCustomer> {
        return userModulesByCustomerList
    }


    fun fetchAuthorizedMenu() = viewModelScope.launch {
        fetchAuthMenu.postValue(Resource.Loading())
        val token = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            sharedPreferences.getString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, "")!!
        } else {
            sharedPreferences.getString(PreferenceKeys.OKTA_ACCESS_TOKEN, "")!!
        }
        val response = accountRepository.fetchAuthorizedMenu(token)
        fetchAuthMenu.postValue(handleAuthMenuResponse(response))
    }

    private fun handleAuthMenuResponse(response: Response<AuthorizedMenu>): Resource<AuthorizedMenu> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse =
            handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        return Resource.Error(errorResponse)
    }

    fun getFacilityInfo(facilityName: String) = viewModelScope.launch {
        facilityInfo.postValue(Resource.Loading())
        val response = accountRepository.getFacilityDetails(facilityName)
        facilityInfo.postValue(handleFacilityInfoResponse(response))
    }

    private fun handleFacilityInfoResponse(response: Response<FacilityInfo>): Resource<FacilityInfo> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun fetchContainerTypes() = viewModelScope.launch {
        containerType.postValue(Resource.Loading())
        val response = accountRepository.getContainerTypes()
        containerType.postValue(handleContainerTypesResponse(response))
    }

    private fun handleContainerTypesResponse(response: Response<CustomerContainerTypes>): Resource<CustomerContainerTypes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun updateLastLoginTime() = viewModelScope.launch {
        updateLastLoginResponse.postValue(Resource.Loading())
        val response = accountRepository.updateLastLoginTimeForCustomer()
        updateLastLoginResponse.postValue(handleLastLoginResponse(response))
    }

    private fun handleLastLoginResponse(response: Response<LangUpdateResponse>): Resource<LangUpdateResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun getLookUps(lookUpsRequest: LookUpsRequest) = viewModelScope.launch {
        lookUpResponse.postValue(Resource.Loading())
        val response = accountRepository.getLookUps(lookUpsRequest)
        lookUpResponse.postValue(handleLookUpsResponse(response))
    }

    // B-2379410 PI Lock Operation start
    fun getLookupForPILock(cusId: Int, fscId: Int, buId: Int) {
        // set time constraint according to update PI Key
        val timeDiff =
            (Calendar.getInstance().time.time - LockCodeValuesUtil.lastFetchDateTimeLookup) / 1000
        if (timeDiff > Constants.PI_LOCK_STATE_REFRESH_INTERVAL_SECONDS) {
            getLookUps(
                LookUpsRequest(
                    fcyId = fscId,
                    cusId = cusId,
                    buId = buId,
                    lookupNames = Constants.Lookup.LOOKUP_PI_LOCK_STATUS
                )
            )
        }
    }

    private fun handleLookUpsResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getLookUps Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "getLookUps Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // B-2379410 PI Lock Operation start
    fun updatePILockStatus(lookupCodes: List<LookupCode>) {
        FlareLog.e(TAG, "Updated PI lock status in local.")
        if (!lookupCodes.isNullOrEmpty() && lookupCodes[0].lookupCode == Constants.PI_LOCK_STATE_VALUE_YES) {
            LockCodeValuesUtil.isPILockEnabled = true
        } else {
            LockCodeValuesUtil.isPILockEnabled = false;
        }
    }


    // B-2379410 PI Lock Operation start
    fun parseLookupSuccess(lookupsResult: LookUps?) {
        try {
            lookupsResult.let { lookResponse ->
                FlareLog.i(TAG, "lookUp success: $lookResponse")
                lookResponse?.lookups?.forEach { lookupIt ->
                    when (lookupIt.lookupName) {
                        Constants.Lookup.LOOKUP_PI_LOCK_STATUS -> updatePILockStatus(
                            lookupIt.lookupCodes
                        )

                        else -> throw NullPointerException("lookUpResponse Empty from menu.")
                    }
                }
            }
        } catch (rex: NullPointerException) {
            FlareLog.e(TAG, rex.localizedMessage)
            updatePILockStatus(emptyList()) // Handle other lookup types if needed
        }
    }

    fun isPILockEnabledForFeature(displayMenuName: String?) =
        displayMenuName in Constants.PhysicalInventoryCountTypes.PI_LOCK_MENU_NAME && LockCodeValuesUtil.isPILockEnabled


    fun getAllTransactionParam(transactionParamRequest: MPRTransParamRequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
            allTransactionsParamResponse.postValue(Resource.Loading())
            val response = accountRepository.getTransactionParam(transactionParamRequest)
            allTransactionsParamResponse.postValue(handleTransactionParamResponse(response))
        }

    /**
     * method to handle transaction param response
     *
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                transactionParamResponse.code(),
                transactionParamResponse.errorBody(),
                transactionParamResponse.message()
            )
            FlareLog.e(TAG, "TransactionParamResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}