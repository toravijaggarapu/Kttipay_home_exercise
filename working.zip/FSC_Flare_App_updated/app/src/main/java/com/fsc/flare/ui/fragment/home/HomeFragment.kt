package com.fsc.flare.ui.fragment.home

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentHomeBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockCodeResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.data.dto.login.FacilityInfo
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.login.NavItem
import com.fsc.flare.source.data.dto.login.UserModulesByCustomer
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.lookups.getCodesAsJsonString
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.Constants.HomeAdapter.Companion.INTERLEAVING
import com.fsc.flare.utils.Constants.Lookup.ALLOC_TYPE_ORD_TYPE_SELECTION
import com.fsc.flare.utils.Constants.Lookup.CASE_PICK_METHOD
import com.fsc.flare.utils.Constants.Lookup.ENABLE_DMG_LOC_MVMNT
import com.fsc.flare.utils.Constants.Lookup.ENABLE_REPLEN_PICK_DROP
import com.fsc.flare.utils.Constants.Lookup.LOCK_COMPARE_IN_PALLETIZE_CONT
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_CONTAINER_STATUS
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_INVENTORY_TYPES
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_LOCATION_CLASSES
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_LOCATION_STATUS
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_LOCATION_TYPE
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_ORDER_STATUS
import com.fsc.flare.utils.Constants.Lookup.LOOKUP_PI_LOCK_STATUS
import com.fsc.flare.utils.Constants.Lookup.LTL_ORD_TYPES
import com.fsc.flare.utils.Constants.Lookup.PCL_ORD_TYPES
import com.fsc.flare.utils.Constants.Lookup.PICK_ORD_TYPE_SELECTION
import com.fsc.flare.utils.Constants.Lookup.PPP_OUTBOUND_DOCUMENT_TYPE
import com.fsc.flare.utils.Constants.Lookup.RESTRICT_LOCKS_FWD_INV_TRANS
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE
import com.fsc.flare.utils.PreferenceKeys.Companion.ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS
import com.fsc.flare.utils.PreferenceKeys.Companion.PICK_ORD_TYPE_SELECTION_PREFERENCE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.StringUtils
import com.fsc.flare.utils.TransCodes.AOPCCP
import com.fsc.flare.utils.TransCodes.MIP
import com.fsc.flare.utils.TransCodes.UOM_VALID
import com.fsc.flare.utils.TransCodes.VCPILR
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import javax.inject.Inject


private const val TAG = "HomeFragment"

/**
 * A simple [HomeFragment] class.
 */
@AndroidEntryPoint
class HomeFragment : BaseFragment(), HomeAdapter.OnAdapterClickListener {

    lateinit var homeAdapter: HomeAdapter
    private lateinit var binding: FragmentHomeBinding
    lateinit var navController: NavController
    private val viewModel: HomeViewModel by activityViewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    /**
     *  Lookups to be request from server.
     *
     *  @Note: If any new lookups are required in the future, please add them to this array.
     */
    private val lookupsToBeRequest = arrayOf(
        LOOKUP_INVENTORY_TYPES,
        LOOKUP_ORDER_STATUS,
        LOOKUP_CONTAINER_STATUS,
        LOOKUP_LOCATION_STATUS,
        LOOKUP_LOCATION_TYPE,
        LOOKUP_LOCATION_CLASSES,
        LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE,
        RESTRICT_LOCKS_FWD_INV_TRANS,
        PICK_ORD_TYPE_SELECTION,
        ALLOC_TYPE_ORD_TYPE_SELECTION,
        PCL_ORD_TYPES,
        LTL_ORD_TYPES,
        LOCK_COMPARE_IN_PALLETIZE_CONT,
        ENABLE_DMG_LOC_MVMNT,
        CASE_PICK_METHOD,
        PPP_OUTBOUND_DOCUMENT_TYPE,
        ENABLE_REPLEN_PICK_DROP,
        LOOKUP_PI_LOCK_STATUS
    )

    /**
     *  Transaction codes to be request from server.
     *
     */
    private val transCodesToBeRequest = arrayOf(
        AOPCCP,
        UOM_VALID,
        MIP,
        VCPILR
    )

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferencesBase.getString(PreferenceKeys.CUST_NAME, null)
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isNetworkConnected()) {
            lifecycleScope.launch {
                // Use async to launch coroutines concurrently
                val fetchContainerTypesDeferred = async { viewModel.fetchContainerTypes() }
                val getFacilityInfoDeferred = async {
                    viewModel.getFacilityInfo(
                        sharedPreferencesBase.getString(
                            PreferenceKeys.FACILITY_NAME,
                            ""
                        )!!
                    )
                }
                val getLookUpsDeferred = async {
                    viewModel.getLookUps(
                        LookUpsRequest(
                            fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                            cusId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                            buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            lookupNames = lookupsToBeRequest.joinToString(",")
                        )
                    )
                }


                val getLockCodes = async {
                    viewModel.getInventoryLockcodes(
                        InventoryLockcodeRequest(
                            custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                            fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                            buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                        )
                    )
                }

                val getAllTransactionParamDeferred = async {
                    viewModel.getAllTransactionParam(
                        MPRTransParamRequest(
                            custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                            buId = sharedPreferencesBase.getInt(
                                PreferenceKeys.BUSINESS_UNIT_ID,
                                -1
                            ),
                            fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                            transCode = transCodesToBeRequest.joinToString(",")
                        )
                    )
                }
                val updateLastLoginTimeDeferred = async { viewModel.updateLastLoginTime() }

                // Await for the completion of all coroutines
                fetchContainerTypesDeferred.await()
                getFacilityInfoDeferred.await()
                getLookUpsDeferred.await()
                getLockCodes.await()
                getAllTransactionParamDeferred.await()
                updateLastLoginTimeDeferred.await()
            }
        } else {
            showErrorSnackBar(resources.getString(R.string.network_error_occurred))
        }
    }

    override fun onCreateMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.main_menu, menu)
        val item = menu.findItem(R.id.action_search)
        val searchView = item.actionView as SearchView
        searchView.maxWidth = Int.MAX_VALUE
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setIconifiedByDefault(true)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                homeAdapter.filter.filter(newText)
                return false
            }
        })
        item?.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }

            override fun onMenuItemActionCollapse(p0: MenuItem): Boolean {
                HomeAdapter.row_index = -1
                return true
            }
        })
        super.onCreateMenu(menu, inflater)
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.account)?.isVisible = true
        menu.findItem(R.id.action_search)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.language)?.isVisible = false
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        viewModel.fetchAuthorizedMenu()
    }

    @android.annotation.SuppressLint("SuspiciousIndentation")
    private fun subscribeObservers() {
        viewModel.fetchAuthMenu.observe(viewLifecycleOwner) { authorizedMenusResponse ->
            FlareLog.i(TAG, "AuthMenuResponse: ${authorizedMenusResponse.data}")
            handleAuthorizedMenusResponse(authorizedMenusResponse)
        }
        viewModel.containerType.observe(viewLifecycleOwner) { containerTypeResponse ->
            handleContainerTypesResponse(containerTypeResponse)
        }

        viewModel.facilityInfo.observe(viewLifecycleOwner) { facilityInfoResponse ->
            handleFacilityInfoResponse(facilityInfoResponse)
        }
        viewModel.updateLastLoginResponse.observe(viewLifecycleOwner) { updateLastLoginResponse ->
            handleLastLoginResponse(updateLastLoginResponse)
        }

        viewModel.lookUpResponse.observe(viewLifecycleOwner) { response ->
            handleLookUpResponse(response)
        }

        viewModel.inventoryLockcodeResponse.observe(viewLifecycleOwner) { response ->
            handleInventoryLockCodesResponse(response)
        }

        viewModel.allTransactionsParamResponse.observe(viewLifecycleOwner) { response ->
            handleAllTransactionsParamResponse(response)
        }
    }

    private fun handleInventoryLockCodesResponse(response: Resource<InventoryLockCodeResponse>) {
        when (response) {
            is Resource.Success -> {
                hideProgressBar()
                response.data?.let { lookUpResponse ->
                    FlareLog.i(TAG, "InventoryLockCodeResponse success: $lookUpResponse")
                    val lockCodeHashMap: HashMap<String, String> = HashMap()
                    lookUpResponse.lockCodes.forEach { lookupCode ->
                        if (!lookupCode.code.isNullOrEmpty()) {
                            lockCodeHashMap[lookupCode.code] = lookupCode.description
                        }
                    }
                    sharedPreferencesBase.edit().putString(
                        PreferenceKeys.LOCK_CODES_HASH_MAP,
                        Gson().toJson(lockCodeHashMap)
                    ).apply()
                }
            }

            is Resource.Error -> {
                hideProgressBar()
                response.message?.let { message ->
                    FlareLog.e(TAG, "lookUpResponse Error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun handleAllTransactionsParamResponse(
        response: Resource<MPRepackTransParamResponse>
    ) {
        when (response) {
            is Resource.Success -> {
                hideProgressBar()
                response.data?.let { transactionParamResponse ->
                    if (transactionParamResponse.success) {
                        FlareLog.i(
                            TAG,
                            "AllTransactionParamResponse success: $transactionParamResponse"
                        )
                        if (!transactionParamResponse.transParams.isNullOrEmpty()) {
                            val configList = listOf(
                                AOPCCP to PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                                UOM_VALID to PreferenceKeys.FOLLOW_ITEM_UOMS,
                                MIP to PreferenceKeys.MIXED_ATTR_LOOKUP_CODE,
                                VCPILR to PreferenceKeys.PALLATIZE_RECEIVING_ITEM_PREFERENCE
                            )

                            configList.forEach { (transCode, prefKey) ->
                                val config = transactionParamResponse.transParams.find {
                                    it.transCode == transCode
                                }
                                val enabled = config?.transVal == 24 || config?.transVal == 27 ||
                                        config?.transVal == 1 || config?.transVal == 31
                                sharedPreferencesBase.edit().putBoolean(prefKey, enabled).apply()
                            }
                        } else {
                            FlareLog.i(TAG, resources.getString(R.string.transaction_param_error))
                        }
                    }
                }
            }

            is Resource.Error -> {
                hideProgressBar()
                response.message?.let { message ->
                    FlareLog.e(TAG, "AllTransactionParamResponse error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun handleLookUpResponse(response: Resource<LookUps>) {
        when (response) {
            is Resource.Success -> {
                hideProgressBar()
                response.data?.let { lookUpResponse ->
                    FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                    lookUpResponse.lookups.forEach { lookupIt ->
                        when (lookupIt.lookupName) {
                            LOOKUP_INVENTORY_TYPES -> {
                                processLookupData(
                                    lookupIt,
                                    PreferenceKeys.DEFAULT_INV_TYPE_CODE,
                                    PreferenceKeys.DEFAULT_INV_TYPE_DESC,
                                    PreferenceKeys.INVENTORY_TYPES_HASH_MAP
                                )
                            }

                            LOOKUP_ORDER_STATUS -> {
                                processLookupData(
                                    lookupIt,
                                    PreferenceKeys.DEFAULT_ORDER_STATUS_CODE,
                                    PreferenceKeys.DEFAULT_ORDER_STATUS_DESC,
                                    PreferenceKeys.ORDER_STATUS_HASH_MAP
                                )
                            }

                            LOOKUP_CONTAINER_STATUS -> {
                                processLookupData(
                                    lookupIt,
                                    PreferenceKeys.DEFAULT_CONTAINER_STATUS_CODE,
                                    PreferenceKeys.DEFAULT_CONTAINER_STATUS_DESC,
                                    PreferenceKeys.CONTAINER_STATUS_HASH_MAP
                                )
                            }

                            LOOKUP_LOCATION_STATUS -> {
                                val locationStatusHashMap: HashMap<String, String> = HashMap()
                                lookupIt.lookupCodes.forEach { lookupCode ->
                                    locationStatusHashMap[lookupCode.lookupCode] =
                                        lookupCode.lookupCodeDescription
                                }
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.LOCATION_STATUS_HASH_MAP,
                                    Gson().toJson(locationStatusHashMap)
                                ).apply()
                            }

                            LOOKUP_LOCATION_TYPE -> {
                                val locationTypeHashMap: HashMap<String, String> = HashMap()
                                lookupIt.lookupCodes.forEach { lookupCode ->
                                    locationTypeHashMap[lookupCode.lookupCode] =
                                        lookupCode.lookupCodeDescription
                                }
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.LOCATION_TYPE_HASH_MAP,
                                    Gson().toJson(locationTypeHashMap)
                                ).apply()
                            }

                            LOOKUP_LOCATION_CLASSES -> {
                                val locationClassesHashMap: HashMap<String, String> = HashMap()
                                lookupIt.lookupCodes.forEach { lookupCode ->
                                    locationClassesHashMap[lookupCode.lookupCode] =
                                        lookupCode.lookupCodeDescription
                                }
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.LOCATION_CLASS_HASH_MAP,
                                    Gson().toJson(locationClassesHashMap)
                                ).apply()
                            }

                            RESTRICT_LOCKS_FWD_INV_TRANS -> {
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.RESTRICT_LOCKS_HASH_MAP,
                                    Gson().toJson(lookupIt.lookupCodes.associate { it.lookupCode to it.lookupCodeDescription })
                                ).apply()
                            }

                            PICK_ORD_TYPE_SELECTION -> {
                                sharedPreferencesBase.edit().putBoolean(
                                    PICK_ORD_TYPE_SELECTION_PREFERENCE,
                                    lookupIt.lookupCodes.any { it.lookupCode == YES }
                                ).apply()
                            }

                            ALLOC_TYPE_ORD_TYPE_SELECTION -> {
                                sharedPreferencesBase.edit().putString(
                                    ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE,
                                    lookupIt.lookupCodes?.let { lookup -> lookup.joinToString(",") { it.lookupCode }  } ?: ""
                                ).apply()
                            }

                            LTL_ORD_TYPES -> {
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.LTL_ORD_TYPES_PREFERENCE,
                                    lookupIt.getCodesAsJsonString()
                                ).apply()
                            }

                            PCL_ORD_TYPES -> {
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.PCL_ORD_TYPES_PREFERENCE,
                                    lookupIt.getCodesAsJsonString()
                                ).apply()
                            }

                            LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE -> {
                                val isActive = lookupIt.lookupCodes.firstOrNull { it.lookupCode == YES }?.active ?: false
                                println("LD_ULD_TRAIL_PALLET_OVERRIDE is ${if (isActive) "enabled" else "disabled"}")
                                sharedPreferencesBase.edit().putBoolean(
                                    PreferenceKeys.LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE,
                                    isActive
                                ).apply()
                            }

                            LOCK_COMPARE_IN_PALLETIZE_CONT -> {
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.LOCK_COMPARE_IN_PALLETIZE_CONT_HASH_MAP,
                                    Gson().toJson(lookupIt.lookupCodes.associate { it.lookupCode to it.lookupCodeDescription })
                                ).apply()
                            }

                            ENABLE_DMG_LOC_MVMNT -> {
                                sharedPreferencesBase.edit().putBoolean(
                                    ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS,
                                    lookupIt.lookupCodes.any { it.lookupCode == YES }
                                ).apply()
                            }

                            ENABLE_REPLEN_PICK_DROP -> {
                                sharedPreferencesBase.edit().putBoolean(
                                    PreferenceKeys.ALLOW_REPLENISHMENT_TO_P_N_D_LOCATION,
                                    lookupIt.lookupCodes.any { it.lookupCode == YES }
                                ).apply()
                            }

                            CASE_PICK_METHOD -> {
                                sharedPreferencesBase.edit().apply {
                                    putString(
                                        PreferenceKeys.CASE_PICK_METHOD_LIST_PREFERENCE,
                                        Gson().toJson(lookupIt.lookupCodes.filter { it.active }.map { it.lookupCode })
                                    )
                                }.apply()
                            }

                            PPP_OUTBOUND_DOCUMENT_TYPE -> {
                                sharedPreferencesBase.edit().putString(
                                    PreferenceKeys.DOCUMENTS_LOOKUP_MAP,
                                    Gson().toJson(lookupIt.lookupCodes.associate { it.lookupCode to it.lookupCodeDescription })
                                ).apply()
                            }
                            LOOKUP_PI_LOCK_STATUS -> {
                                viewModel.updatePILockStatus(lookupIt.lookupCodes)
                            }
                            else -> {
                                // Handle other lookup types if needed
                            }
                        }
                    }
                }
            }

            is Resource.Error -> {
                hideProgressBar()
                response.message?.let { message ->
                    FlareLog.e(TAG, "lookUpResponse Error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun processLookupData(
        lookupData: Lookup,
        defaultCodeKey: String,
        defaultDescKey: String,
        hashMapKey: String
    ) {
        val defaultTypeList = lookupData.lookupCodes.filter { it.destinationSystemValue == "F" }
        if (defaultTypeList.isNotEmpty()) {
            val defaultTypeCode = defaultTypeList[0].lookupCode
            sharedPreferencesBase.edit().putString(defaultCodeKey, defaultTypeCode).apply()
            val defaultTypeDesc = defaultTypeList[0].lookupCodeDescription
            sharedPreferencesBase.edit().putString(defaultDescKey, defaultTypeDesc).apply()
        }

        val typeHashMap: HashMap<String, String> = HashMap()
        lookupData.lookupCodes.forEach { lookupCode ->
            typeHashMap[lookupCode.lookupCode] = lookupCode.lookupCodeDescription
        }

        sharedPreferencesBase.edit().putString(hashMapKey, Gson().toJson(typeHashMap)).apply()
    }

    private fun handleLastLoginResponse(updateLastLoginResponse: Resource<LangUpdateResponse>) {
        when (updateLastLoginResponse) {
            is Resource.Success -> {
                hideProgressBar()
                Log.d(TAG, "UserInfo Response : " + updateLastLoginResponse.data?.toString())
                if (updateLastLoginResponse.data != null) {
                    FlareLog.i(TAG, "Last Login Update Response: ${updateLastLoginResponse.data}")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }

            is Resource.Error -> {
                hideProgressBar()
            }
        }
    }

    private fun handleContainerTypesResponse(containerTypeResponse: Resource<CustomerContainerTypes>?) {
        when (containerTypeResponse) {
            is Resource.Success -> {
                hideProgressBar()
                containerTypeResponse.data?.let { containerData ->
                    FlareLog.i(TAG, "ContainerTypeResponse: $containerTypeResponse")
                    val containerTypesJson = if (!containerData.containerTypes.isNullOrEmpty()) {
                        Gson().toJson(containerData, CustomerContainerTypes::class.java)
                    } else {
                        ""
                    }
                    sharedPreferencesBase.edit()
                        .putString(PreferenceKeys.CONTAINER_TYPES, containerTypesJson).apply()
                }

            }

            is Resource.Error -> {
                hideProgressBar()
                containerTypeResponse.message?.let { message ->
                    FlareLog.e(TAG, "ContainerTypeResponse error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }

            else -> {}
        }
    }

    private fun handleFacilityInfoResponse(facilityInfoResponse: Resource<FacilityInfo>?) {
        when (facilityInfoResponse) {
            is Resource.Success -> {
                hideProgressBar()
                if (facilityInfoResponse.data != null) {
                    FlareLog.i(TAG, "facilityInfoResponse: $facilityInfoResponse")
                    if (!facilityInfoResponse.data.facilities.isNullOrEmpty()) {
                        sharedPreferencesBase.edit().putString(
                            PreferenceKeys.FACILITY_TIMEZONE,
                            facilityInfoResponse.data.facilities[0].timeZone
                        ).apply()
                        sharedPreferencesBase.edit().putString(
                            PreferenceKeys.FACILITY_GMT_OFFSET,
                            facilityInfoResponse.data.facilities[0].gmtOffsetHours
                        ).apply()
                    }
                }
            }

            is Resource.Error -> {
                hideProgressBar()
                facilityInfoResponse.message?.let { message ->
                    FlareLog.e(TAG, "facilityInfoResponse error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }

            else -> {}
        }
    }

    private fun handleAuthorizedMenusResponse(authorizedMenusResponse: Resource<AuthorizedMenu>) {
        when (authorizedMenusResponse) {
            is Resource.Success -> {
                FlareLog.i(TAG, "AuthorizedMenusResponse success: $authorizedMenusResponse")
                hideProgressBar()
                if (authorizedMenusResponse.data != null) {
                    val userModulesByCustomer = authorizedMenusResponse.data.userModulesByCustomer
                    viewModel.userModulesByCustomerList = userModulesByCustomer
                    if (viewModel.fetchUserModulesByCustomerList().isNotEmpty()) {
                        generateSubMenuList(viewModel.fetchUserModulesByCustomerList())
                    }
                }
            }

            is Resource.Error -> {
                hideProgressBar()
                authorizedMenusResponse.message?.let { message ->
                    FlareLog.e(TAG, "AuthorizedMenusResponse error: $message")
                }
            }

            is Resource.Loading -> {
                showProgressBar()
            }
        }
    }

    private fun generateSubMenuList(userModulesByCustomer: List<UserModulesByCustomer>) {
        val navItemsList = arrayListOf<NavItem>()
        val currentCustomerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)

        // Flag to check if we found a matching cusId
        var foundMatchingCusId = false
        // First, check for matching cusId
        userModulesByCustomer.forEach { userModule ->
            if (userModule.cusId.toInt() == currentCustomerId) {
                foundMatchingCusId = true
                userModule.modules.forEach { module ->
                    navItemsList.addAll(module.navItems)
                }
            }
        }

        // If no matching cusId was found, check for cusId == -1
        if (!foundMatchingCusId) {
            userModulesByCustomer.forEach { userModule ->
                if (userModule.cusId.toInt() == -1) {
                    userModule.modules.forEach { module ->
                        navItemsList.addAll(module.navItems)
                    }
                }
            }
        }
        setupRecyclerView(navItemsList)
    }

    private fun setupRecyclerView(navItemsList: ArrayList<NavItem>) {
        homeAdapter = HomeAdapter(navItemsList, this, fragmentContext)
        binding.customerRecycler.apply {
            adapter = homeAdapter
            layoutManager = GridLayoutManager(activity, 2)
        }
    }

    private fun hideProgressBar() {
        binding.progressBarHome.visibility = View.INVISIBLE
    }


    private fun showProgressBar() {
        binding.progressBarHome.visibility = View.VISIBLE
    }

    override fun onItemSelected(item: String?, menuId: String?) {
        if (viewModel.isPILockEnabledForFeature(item)) {
            FlareLog.e(TAG, "Pi inprogress, dialog visible.")
            showCustomDialog(getString(R.string.pi_count_inprogress_operation_not_allowed)) {
                FlareLog.e(TAG, "Pi inprogress, dialog dismissed.")
            }
            return
        }
        val menuName = StringUtils.langConvertedName(menuId, item, context)
        val bundle = bundleOf(
            Constants.DISPLAY_NAME to menuName,
            Constants.ROOT_MENU_NAME to item
        )
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
        if (item == INTERLEAVING) {
            navController.navigate(R.id.action_homeFragment_to_interLeaving, bundle)
        } else {
            navController.navigate(R.id.action_homeFragment_to_submenufragment, bundle)
        }
    }
}
