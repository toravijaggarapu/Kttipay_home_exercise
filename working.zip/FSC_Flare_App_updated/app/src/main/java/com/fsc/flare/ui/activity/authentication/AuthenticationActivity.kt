package com.fsc.flare.ui.activity.authentication

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.MenuProvider
import androidx.databinding.DataBindingUtil
import com.fsc.flare.BuildConfig
import com.fsc.flare.R
import com.fsc.flare.databinding.ActivityAuthenticationBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.Token
import com.fsc.flare.utils.AuthConstants
import com.fsc.flare.utils.AuthFailure
import com.fsc.flare.utils.FlareSecurityManager
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.util.UUID
import javax.inject.Inject
import javax.net.ssl.HttpsURLConnection

@AndroidEntryPoint
class AuthenticationActivity : AppCompatActivity(), MenuProvider {

    companion object {
        private const val TAG = "AuthenticationActivity"
        const val EXTRA_REAUTHENTICATING = "com.fsc.flare.extra_reauthenticating"
        const val EXTRA_AUTH_FAILURE = "com.fsc.flare.extra_auth_failure_reason"
        const val EXTRA_TOKEN = "com.fsc.flare.extra_token"
        const val QUERY_PARAM_CODE = "code"
        const val QUERY_PARAM_STATE = "state"
        const val RESULT_AUTHENTICATION_FAILURE = 100
    }

    private var mLoadedUrl: String? = null
    private var mCodeChallenge: String? = null
    private lateinit var mVerifier: String
    private var mStateParam: String? = null

    private val viewModel: AuthenticationViewModel by viewModels()

    @Inject
    lateinit var flareSecurityManager: FlareSecurityManager

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var binding: ActivityAuthenticationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        //Thread.setDefaultUncaughtExceptionHandler(UnCaughtException(this));
        super.onCreate(savedInstanceState)
        addMenuProvider(this)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_authentication)

        setSupportActionBar(binding.authenticationToolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        configureWebView()
        initializeWebView()
        subscribeObservers()
        binding.authenticationToolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun subscribeObservers() {
        viewModel.oktaTokenResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    if (response.data != null) {
                        sharedPreferences.apply {
                            if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
                                sharedPreferences.edit().putString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, response.data.accessToken).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.OKTA_USER_ID, response.data.accessToken).apply()
                            } else {
                                sharedPreferences.edit().putString(PreferenceKeys.OKTA_ACCESS_TOKEN, response.data.accessToken).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.OKTA_USER_ID, response.data.accessToken).apply()
                            }
                            sharedPreferences.edit().putString(PreferenceKeys.OKTA_REFRESH_TOKEN, response.data.refreshToken).apply()
                            sharedPreferences.edit().putString(PreferenceKeys.OKTA_ID_TOKEN, response.data.idToken).apply()
                            Log.d(TAG, "saved okta token response to sharedpreferences:" + response.data.accessToken)
                        }
                        viewModel.fetchAppProperties()
                        finishWithToken(response.data)
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                }
            }
        }
        viewModel.appPropertiesResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    if (response.data != null) {
                        sharedPreferences.apply {
                            sharedPreferences.edit().putString(PreferenceKeys.API_GATEWAY_CLIENT_ID, response.data.apiGatewayClientId).apply()
                            sharedPreferences.edit().putString(PreferenceKeys.API_GATEWAY_SECRET, response.data.apiGatewaySecret).apply()
                            Log.d(TAG, "saved api gateway clientId and secret to sharedpreferences")
                        }
                        viewModel.fetchGatewayToken(
                            sharedPreferences.getString(PreferenceKeys.API_GATEWAY_CLIENT_ID, null)!!,
                            sharedPreferences.getString(PreferenceKeys.API_GATEWAY_SECRET, null)!!
                        )
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                }
            }
        }

        viewModel.gatewayTokenResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    Log.d(TAG, "Gateway Token Response : " + response.data?.toString())
                    if (response.data != null) {
                        sharedPreferences.apply {
                            sharedPreferences.edit().putString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, response.data.access_token).apply()
                            Log.d(TAG, "saved gateway token to sharedpreferences:" + response.data.access_token)
                        }
                        viewModel.fetchUserInfo()
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                }
            }
        }

        viewModel.userInfoResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    Log.d(TAG, "UserInfo Response : " + response.data?.toString())
                    if (response.data != null) {
                        if(response.data.employeeNumber != null){
                            if (!sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)){
                                sharedPreferences.edit().putString(PreferenceKeys.FEDEX_ID, response.data.employeeNumber).apply()
                                Log.d(TAG, "saved employee number to sharedpreferences")
                            }
                        }
                        viewModel.fetchUserID()
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                }

            }
        }

        viewModel.updateLastLoginResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    Log.d(TAG, "UserInfo Response : " + response.data?.toString())
                    if (response.data != null) {
                        FlareLog.i(TAG, "Last Login Update Response: ${response.data}")
                        finish()
                    }else{
                        finish()
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                    finish()
                }
            }
        }

        viewModel.externalUserIDResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    Log.d(TAG, "External UserID Response : " + response.data)
                    if (response.data != null) {
                        if(response.data.success){
                            if(response.data.user.type == "T"){
                                sharedPreferences.edit().putInt(PreferenceKeys.USER_ID, response.data.user.id).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.FEDEX_ID, response.data.user.loginId).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.FEDEX_EMAIL, response.data.user.email).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.APP_LANGUAGE, response.data.user.locale).apply()
                            } else {
                                sharedPreferences.edit().putInt(PreferenceKeys.USER_ID, response.data.user.id).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.FEDEX_ID, response.data.user.loginId).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.FEDEX_EMAIL, response.data.user.email).apply()
                                sharedPreferences.edit().putString(PreferenceKeys.APP_LANGUAGE, response.data.user.locale).apply()
                            }
                        }
                        viewModel.storeLoginTime()
                        viewModel.updateLastLoginTime()
                      //  finish()
                    }
                }
                is Resource.Loading -> {
                    toggleLoadingIconVisibility(true)
                }
                is Resource.Error -> {
                    toggleLoadingIconVisibility(false)
                }
            }
        }

    }

    private fun initializeWebView() {
        loadInitialLoginPage()
    }

    private fun loadInitialLoginPage() {
        generatePKCEValues()
        mStateParam = UUID.randomUUID().toString()
        mLoadedUrl = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            buildLoginPageUrlTempUser()
        } else {
            buildLoginPageUrl()
        }
        showWebPage(mLoadedUrl!!)
    }

    private fun showWebPage(mLoadedUrl: String) {
        Log.d(TAG, "showWebPage: $mLoadedUrl")
        binding.authenticationWebview.loadUrl(mLoadedUrl)
    }


    private fun buildLoginPageUrl(): String {
        return AuthConstants.LOGIN_PAGE_URL +
                "client_id=" + BuildConfig.CLIENT_ID +
                "&redirect_uri=" + AuthConstants.LOGIN_PAGE_REDIRECT_URI +
                "&response_type=" + AuthConstants.LOGIN_PAGE_RESPONSE_TYPE +
                "&code_challenge=" + mCodeChallenge +
                "&code_challenge_method=" + AuthConstants.LOGIN_PAGE_CHALLENGE_METHOD +
                "&state=" + mStateParam +
                "&scope=" + AuthConstants.LOGIN_PAGE_SCOPE
    }

    private fun buildLoginPageUrlTempUser(): String {
        return AuthConstants.LOGIN_PAGE_URL_TEMP_USER +
                "client_id=" + BuildConfig.TEMP_WORKER_CLIENT_ID +
                "&redirect_uri=" + AuthConstants.LOGIN_PAGE_REDIRECT_URI +
                "&response_type=" + AuthConstants.LOGIN_PAGE_RESPONSE_TYPE +
                "&code_challenge=" + mCodeChallenge +
                "&code_challenge_method=" + AuthConstants.LOGIN_PAGE_CHALLENGE_METHOD +
                "&state=" + mStateParam +
                "&scope=" + AuthConstants.LOGIN_PAGE_SCOPE
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun configureWebView() {
        resetWebView()
        initDebugging()

        binding.authenticationWebview.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        binding.authenticationWebview.settings.javaScriptEnabled = true
        binding.authenticationWebview.settings.allowContentAccess = false
        binding.authenticationWebview.settings.allowFileAccess = false

        binding.authenticationWebview.webViewClient = AuthCodeWebViewClient()
        binding.authenticationWebview.addJavascriptInterface(this, "HTMLOUT")
    }

    /**
     * Enables WebView debugging based on the 'debuggable' attribute.
     * [] https://stackoverflow.com/a/7024481/4672234
     */
    private fun initDebugging() {
        val isDebuggable = 0 != applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE
        if (isDebuggable) {
            Log.d(TAG, "Enabling debugging on WebView.")
            WebView.setWebContentsDebuggingEnabled(true)
        }
    }

    private fun resetWebView() {
        CookieManager.getInstance().removeAllCookies(null)
        binding.authenticationWebview.clearHistory()
        binding.authenticationWebview.clearCache(true)
        binding.authenticationWebview.clearSslPreferences()
        binding.authenticationWebview.clearFormData()
    }

    fun shouldOverrideUrlLoading(request: WebResourceRequest): Boolean {
        if (isRedirectUrl(request)) {
            handleRedirectReceived(request)
            return true
        }
        return false
    }

    private fun handleRedirectReceived(request: WebResourceRequest) {
        Log.i(TAG, "Redirect received.")
        val authCode = request.url.getQueryParameter(QUERY_PARAM_CODE)
        val state = request.url.getQueryParameter(QUERY_PARAM_STATE)
        when {
            authCode == null -> {
                Log.e(TAG, "Failed to parse auth code from redirect.")
                finishWithAuthFailure(AuthFailure.PARSE_AUTH_CODE_ERROR)
            }
            mStateParam == state -> {
                Log.d(TAG, "handleRedirectReceived: authcode:: $authCode")
                Log.d(TAG, "handleRedirectReceived: state:: $state")
                viewModel.fetchToken(authCode, mVerifier)
            }
            else -> {
                Log.e(TAG, "States do not match: expected $mStateParam, got $state")
                finishWithAuthFailure(AuthFailure.PARSE_AUTH_CODE_ERROR)
            }
        }
    }

    private fun isRedirectUrl(request: WebResourceRequest): Boolean {
        return request.url.scheme != null && this.getString(R.string.oauth_redirect_uri_scheme) == request.url.scheme
    }

    inner class AuthCodeWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return shouldOverrideUrlLoading(request)
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            var logLine = "Performing request to " + request.url
            logLine += if (request.requestHeaders != null) {
                " with Headers: " + request.requestHeaders.toString()
            } else {
                " (unknown headers)"
            }
            Log.i(TAG, logLine)
            return super.shouldInterceptRequest(view, request)
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            handlePageLoadStarted(url)
        }

        /**
         * [.processHTML]
         */
        override fun onPageFinished(view: WebView, url: String) {
            handlePageLoadFinished(url)
            view.loadUrl("javascript:window.HTMLOUT.processHTML('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');")
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
            handleReceivedHttpError(request, errorResponse)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            handleReceivedError(request, error)
        }
    }

    private fun finishWithAuthFailure(@AuthFailure authFailure: String?) {
        setResult(RESULT_AUTHENTICATION_FAILURE, Intent().putExtra(EXTRA_AUTH_FAILURE, authFailure))
        finish()
    }

    fun handlePageLoadStarted(url: String) {
        Log.d(TAG, "onPageStarted: $url")
        toggleLoadingIconVisibility(true)
    }

    private fun toggleLoadingIconVisibility(visible: Boolean) {
        binding.authenticationProgressbar.visibility = if (visible) View.VISIBLE else View.GONE
    }

    fun handlePageLoadFinished(url: String) {
        Log.d(TAG, "onPageFinished: $url")
        toggleLoadingIconVisibility(false)
    }

    fun handleReceivedHttpError(request: WebResourceRequest, errorResponse: WebResourceResponse) {
        if (request.url != null && request.url.toString().contains("favicon")) {
            return
        }
        Log.w(TAG, "onReceivedHttpError: " + request.url + " failed due to " + errorResponse.statusCode + ": " + errorResponse.reasonPhrase)
        if (request.url != null && request.url.toString() == mLoadedUrl) {
            finishWithAuthFailure(AuthFailure.LOGIN_PAGE_HTTP_ERROR)
            return
        }
        if (errorResponse.statusCode == HttpsURLConnection.HTTP_UNAUTHORIZED ||
            errorResponse.statusCode == HttpsURLConnection.HTTP_BAD_REQUEST
        ) {
            finishWithAuthFailure(AuthFailure.LOGIN_PAGE_HTTP_ERROR)
        }
    }

    fun handleReceivedError(request: WebResourceRequest, error: WebResourceError) {
        Log.e(
            TAG, "onReceivedError: " + request.url + " failed due to " + error.errorCode + ": " + error.description
        )
        if (request.isForMainFrame && error.errorCode < 0) {
            if (error.errorCode == WebViewClient.ERROR_UNKNOWN) {
                Log.e(TAG, "Reloading login page.")
                loadInitialLoginPage()
                return
            } else if (error.errorCode == WebViewClient.ERROR_UNSUPPORTED_SCHEME) {
                if (isRedirectUrl(request)) {
                    hideWebView() //Don't let user see the scheme error
                    handleRedirectReceived(request)
                } else {
                    finishWithAuthFailure(AuthFailure.PARSE_AUTH_CODE_ERROR)
                }
                return
            }
            finishWithAuthFailure(AuthFailure.LOGIN_PAGE_NETWORK_ERROR)
        }
    }

    private fun hideWebView() {
        binding.authenticationWebview.visibility = View.INVISIBLE
    }

    private fun finishWithToken(token: Token?) {
        val resultIntent = Intent()
        resultIntent.putExtra(EXTRA_TOKEN, token)
        setResult(RESULT_OK, resultIntent)
        //finish()
    }

    private fun generatePKCEValues() {
        try {
            mVerifier = flareSecurityManager.generateChallengeCodeVerifier()
            mCodeChallenge = flareSecurityManager.generateChallengeCodeFromVerifier(mVerifier)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to hash challenge code verifier")
            finishWithAuthFailure(AuthFailure.HASH_CHALLENGE_ERROR)
        }
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.menu_authentication, menu)
    }

    override fun onMenuItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_auth_refresh -> {
                resetWebView()
                loadInitialLoginPage()
                true
            }
            else -> true
        }
    }

}