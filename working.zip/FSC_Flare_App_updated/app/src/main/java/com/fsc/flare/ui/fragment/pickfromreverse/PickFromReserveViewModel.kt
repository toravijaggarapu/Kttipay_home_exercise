package com.fsc.flare.ui.fragment.pickfromreverse


import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLookupsRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveRequest
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoValidateQtyRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoValidateQtyResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteRequestTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteResponseTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoPickReverseRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoReverseResponse
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.res.CycleCountTriggerResponse
import com.fsc.flare.source.data.dto.pickingforward.res.KitStagingLocationResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.SkipPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.pickingforward.res.UpcOrSlpResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ZeroLocationPromptResp
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.source.data.dto.receiving.serial.LotNumberResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.PickFromReserveRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import com.fsc.flare.utils.TivoPFR
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import java.util.Locale
import javax.inject.Inject

private const val TAG = "PickFromReserveViewModel"

@HiltViewModel
class PickFromReserveViewModel @Inject constructor(
    private val pickFromReserveRepository: PickFromReserveRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {
    val ltlFLowEnabledKey = 17
    var orderType: String? = null
    var isRTV: Boolean = false
    val taskGroupResponse: MutableLiveData<Resource<TaskGroupResponse>> = SingleLiveEvent()
    var taskGroupsList: MutableLiveData<ArrayList<TaskGroup>> = MutableLiveData<ArrayList<TaskGroup>>()
    var taskGroupCodeOptions: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    val taskPickResponse: MutableLiveData<Resource<TaskPickResponse>> = SingleLiveEvent()
    val reservePickCompleteResponse: MutableLiveData<Resource<ReservePickCompleteResponse>> = SingleLiveEvent()
    val reservePickStageResponse: MutableLiveData<Resource<ReservePickStageResponse>> = SingleLiveEvent()
    val validateQtyResponse: MutableLiveData<Resource<TivoValidateQtyResponse>> = SingleLiveEvent()
    val containerResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val unitPickCompleteResponse: MutableLiveData<Resource<TivoUnitPickCompleteResponse>> = SingleLiveEvent()
    val palletPickCompleteResponse: MutableLiveData<Resource<PalletPickFromReserveResponse>> = SingleLiveEvent()
    val serialValidationResponse: MutableLiveData<Resource<InventoryTaskSerialNumberResponse>> = SingleLiveEvent()
    val lookupsResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val skipPickCartResponse: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val kittingStagingLocationResponse: MutableLiveData<Resource<KitStagingLocationResponse>> = SingleLiveEvent()

    val palletContainerSerialNumberValidationResponse: MutableLiveData<Resource<ValidatePalletContainerSerialNumberTivoReverseResponse>> =
        SingleLiveEvent()
    val markTaskCompleteTivoPFRResponse: MutableLiveData<Resource<MarkTaskCompleteResponseTivoPFR>> = SingleLiveEvent()

    val tivoPickFromReserveReleaseResponse: MutableLiveData<Resource<ReservePickStageResponse>> = SingleLiveEvent()

    val tivoPickFromReserveValidateLotNumberResponse: MutableLiveData<Resource<ValidateLotNumberResponse>> = SingleLiveEvent()
    val pickFromReserveValidateLotNumberResponse: MutableLiveData<Resource<LotNumberResponse>> = SingleLiveEvent()
    val transactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val itemAttrTransParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> = SingleLiveEvent()
    val upcOrSlpResponse: MutableLiveData<Resource<UpcOrSlpResponse>> = SingleLiveEvent()
    val ltlTransactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val inventoryLocksResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    var isLTLCubingEnabled= false
    val locationDetailsResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val validatePalletOverrideResponse: MutableLiveData<Resource<ValidatePalletOverrideResponse>> = SingleLiveEvent()
    val cycleCountTriggerResponse: MutableLiveData<Resource<CycleCountTriggerResponse>> = SingleLiveEvent()
    val zeroLocationPromptResponse: MutableLiveData<Resource<ZeroLocationPromptResp>> = SingleLiveEvent()
    private var scannedPallet: MutableLiveData<String> = MutableLiveData()
    private var _generateCycleCount: Boolean = false
    var generateCycleCount: Boolean
        get() = _generateCycleCount
        set(value) {
            _generateCycleCount = value
        }
    fun getTaskGroups(allocationType: String) = viewModelScope.launch {
        taskGroupResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getTaskGroups(allocationType)
        taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }
    /**
     * method to get transaction param details
     */
    fun getLTLTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        ltlTransactionParamResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getTransactionParam(transactionParamRequest)
        ltlTransactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    fun getTaskPick(taskPickReq: TaskPickReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getTaskPick Request: $taskPickReq")
        taskPickResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getTaskPick(taskPickReq)
        taskPickResponse.postValue(handleTaskPickResponse(response))
    }

    fun getKittingStagingLocation(psuedoOrderId:Int, orderType: String) = viewModelScope.launch {
        kittingStagingLocationResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getKitStagingLocation(psuedoOrderId, orderType)
        kittingStagingLocationResponse.postValue(handleKitStagingLocationResponse(response))
    }

    private fun handleKitStagingLocationResponse(response: Response<KitStagingLocationResponse>): Resource<KitStagingLocationResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Kit Staging Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun tivoGetTaskPick(taskPickReq: TaskPickReq) = viewModelScope.launch {
        FlareLog.i(TAG, "tivoGetTaskPick Request: $taskPickReq")
        taskPickResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getTivoTaskPick(taskPickReq)
        taskPickResponse.postValue(handleTaskPickResponse(response))
    }

    private fun handleTaskPickResponse(response: Response<TaskPickResponse>): Resource<TaskPickResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskPickResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskPick Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TaskGroupsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskGroups Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }


    /**
     * method to validate qty
     */
    fun validateQty(tivoValidateQtyRequest: TivoValidateQtyRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "tivoValidateQtyRequest Request: $tivoValidateQtyRequest")
        validateQtyResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.tivoValidateQty(tivoValidateQtyRequest)
        validateQtyResponse.postValue(handleValidateQtyResponse(response))
    }

    /**
     * method to handle validate qty response
     */
    private fun handleValidateQtyResponse(tivoValidateQtyResponse: Response<TivoValidateQtyResponse>): Resource<TivoValidateQtyResponse>? {
        if (tivoValidateQtyResponse.isSuccessful) {
            tivoValidateQtyResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "tivoValidateQtyResponse Sucess: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(tivoValidateQtyResponse.code(), tivoValidateQtyResponse.errorBody(), tivoValidateQtyResponse.message())
            FlareLog.e(TAG, "tivoValidateQty Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get container details
     */
    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getContainer(container, itemInfo)
        containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }


    /**
     * method to call fullpalletpick submit
     */
    fun palletPickComplete(palletPickFromReserveRequest: PalletPickFromReserveRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "palletPickComplete Request: $palletPickFromReserveRequest")
        palletPickCompleteResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.palletPickReserve(palletPickFromReserveRequest)
        palletPickCompleteResponse.postValue(handlePalletPickCompleteResponse(response))
    }

    /**
     * method to handle fullpalletpick response
     */
    private fun handlePalletPickCompleteResponse(response: Response<PalletPickFromReserveResponse>): Resource<PalletPickFromReserveResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletPickCompleteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletPickCompleteResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to call unitpickcomplete
     */
    fun unitPickComplete(tivoUnitPickCompleteRequest: TivoUnitPickCompleteRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "tivoUnitPickComplete Request: $tivoUnitPickCompleteRequest")
        unitPickCompleteResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.unitPickComplete(tivoUnitPickCompleteRequest)
        unitPickCompleteResponse.postValue(handleUnitPickCompleteResponse(response))
    }

    /**
     * method to handle unitpickcomplete response
     */
    private fun handleUnitPickCompleteResponse(response: Response<TivoUnitPickCompleteResponse>): Resource<TivoUnitPickCompleteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TivoUnitPickCompleteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TivoUnitPickComplete Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
    /**
     * method to validate serial number API
     */
    fun validateTaskSerialNumber(inventoryTaskSerialNumberRequest: InventoryTaskSerialNumberRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validateTaskSerialNumber Request: $inventoryTaskSerialNumberRequest")
        serialValidationResponse.postValue(Resource.Loading())
        val serialNumberValidationRes = pickFromReserveRepository.validateInventoryTaskSerialNumber(inventoryTaskSerialNumberRequest)
        serialValidationResponse.postValue(handleSerialNumberValidationResponse(serialNumberValidationRes))
    }

    /**
     * method to handle serial validation response
     */
    private fun handleSerialNumberValidationResponse(response: Response<InventoryTaskSerialNumberResponse>): Resource<InventoryTaskSerialNumberResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SerialNumberResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SerialNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get inventory lookups
     */
    fun getInventoryLookups(inventoryLookupsRequest: InventoryLookupsRequest) = viewModelScope.launch {
        lookupsResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getInventoryLookups(inventoryLookupsRequest)
        lookupsResponse.postValue(handleLookupsResponse(response))
    }

    /**
     * method to handle inventory lookups response
     */
    private fun handleLookupsResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryLookupsResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getInventoryLookups Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate pallet no tivo pick from reserve
     */
    fun validatePalletContainerSerialNumberTivoPickFromReserve(request: ValidatePalletContainerSerialNumberTivoPickReverseRequest, type: TivoPFR) =
        viewModelScope.launch {
            FlareLog.i(TAG, "validate_pallet_and_serial_number_Request: $request")
            palletContainerSerialNumberValidationResponse.postValue(Resource.Loading())
            val response = when (type) {
                TivoPFR.VALIDATE_PALLET_NUMBER -> pickFromReserveRepository.validatePalletNumberTivoPFR(request)
                TivoPFR.VALIDATE_PALLET_SERIAL_NUMBER -> pickFromReserveRepository.validatePalletSerialNumberTivoPFR(request)
                TivoPFR.VALIDATE_PALLET_NUMBER_USER_DIRECTED -> pickFromReserveRepository.validatePalletNumberTivoPFRUserDirected(request)
                TivoPFR.VALIDATE_CONTAINER_NUMBER_USER_DIRECTED -> pickFromReserveRepository.validatePalletSerialNumberTivoPFRUserDirected(request)
                TivoPFR.VALIDATE_CONTAINER_NUMBER -> pickFromReserveRepository.validateContainerNumberTivoPFR(request)
                TivoPFR.VALIDATE_CONTAINER_SERIAL_NUMBER -> pickFromReserveRepository.validateContainerSerialNumberTivoPFR(request)
            }

            palletContainerSerialNumberValidationResponse.postValue(handleResponseTivoPickFromReserve(response))

        }

    fun taskReservePickCompleteTivoPFR(request: MarkTaskCompleteRequestTivoPFR) = viewModelScope.launch {
        markTaskCompleteTivoPFRResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.markTaskCompleteTivPFRComplete(request)
        markTaskCompleteTivoPFRResponse.postValue(handleMarkTaskCompleteTivoPFRCompleteResponse(response))
    }

    fun tivoPickFromReserveLocationInfo() = viewModelScope.launch {
        tivoPickFromReserveReleaseResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.reservepickstage()
        tivoPickFromReserveReleaseResponse.postValue(handleReservePickStageResponse(response))
    }

    private fun handleMarkTaskCompleteTivoPFRCompleteResponse(response: Response<MarkTaskCompleteResponseTivoPFR>): Resource<MarkTaskCompleteResponseTivoPFR>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ReservePickCompleteResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ReservePickComplete Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    fun tivoPickFromReserveValidateLotNumber(request:ValidateLotNumberRequest) = viewModelScope.launch {
        tivoPickFromReserveValidateLotNumberResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.validateLotNumberTivoPFR(request)
        tivoPickFromReserveValidateLotNumberResponse.postValue(handleValidateLotNumberResponse(response))
    }

    private fun handleValidateLotNumberResponse(response: Response<ValidateLotNumberResponse>): Resource<ValidateLotNumberResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateLotNumberResponseTivoPFRResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    fun pickFromReserveValidateLotNumber(request: LotNumReqBody) = viewModelScope.launch {
        pickFromReserveValidateLotNumberResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.validateLotNumberPFR(request)
        pickFromReserveValidateLotNumberResponse.postValue(handleValidateLotNumberTivoPFRResponse(response))
    }


    private fun handleValidateLotNumberTivoPFRResponse(response: Response<LotNumberResponse>): Resource<LotNumberResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ValidateLotNumberResponseTivoPFRResponse: $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ValidateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
    }

    /**
     * method to handle serial validation response
     */
    private fun handleResponseTivoPickFromReserve(response: Response<ValidatePalletContainerSerialNumberTivoReverseResponse>): Resource<ValidatePalletContainerSerialNumberTivoReverseResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SerialNumberResponse : $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SerialNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }

    }

    /**
     * method to get transaction param details
     */
    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionParamResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getTransactionParam(transactionParamRequest)
        transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(transactionParamResponse.code(), transactionParamResponse.errorBody(), transactionParamResponse.message())
            FlareLog.e(TAG, "TransactionParam Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
    /**
     * method to get transaction param details
     */
    fun getItemAttributesTransactionParam(mprTransParamRequest: MPRTransParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Item Attributes transactionParam Request: $mprTransParamRequest")
        itemAttrTransParamResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getItemAttrTransactionParam(mprTransParamRequest)
        itemAttrTransParamResponse.postValue(handleItemAttrTransactionParamResponse(response))
    }

    /**
     * method to handle MPR transaction param response
     */
    private fun handleItemAttrTransactionParamResponse(response: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "MPRTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "MPRTransactionParamResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getInventoryReasonCodes() = viewModelScope.launch {
        inventoryLocksResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.getInventoryReasonCodes()
        inventoryLocksResponse.postValue(handleInventoryLocksResponse(response))
    }

    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryLocksResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryLocksResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    var containerDetails: MutableLiveData<Container> = MutableLiveData<Container>()
    var serialNumberList: MutableLiveData<List<String>> = MutableLiveData<List<String>>()
    var inventoryLocksList: MutableLiveData<List<Lookup>> = MutableLiveData()
    var isOverrideItemAttributes: Int = -1

    fun getSerialNumberList(): List<String> {
        return serialNumberList.value!!
    }

    fun setSerialNumberList(serialList: List<String>) {
        this.serialNumberList.value = serialList
    }

    fun settaskGroupCodeOptions(taskGroupOptions: ArrayList<String>) {
        this.taskGroupCodeOptions.value = taskGroupOptions
    }

    fun gettaskGroupCodeOptions(): ArrayList<String>? {
        return taskGroupCodeOptions.value
    }


    fun getTaskGroupsList(): ArrayList<TaskGroup>? {
        return taskGroupsList.value
    }

    fun setTaskGroupsList(taskGroups: ArrayList<TaskGroup>) {
        this.taskGroupsList.value = taskGroups
    }

    var pickTaskDetails: MutableLiveData<TaskDetails> = MutableLiveData<TaskDetails>()


    fun getPickTaskDetails(): TaskDetails? {
        return pickTaskDetails.value
    }

    fun setPickTaskDetails(pickTaskDetails: TaskDetails) {
        this.pickTaskDetails.value = pickTaskDetails
    }


    var stageTaskDetails: MutableLiveData<TaskDetails> =
        MutableLiveData<TaskDetails>()

    fun getStageTaskDetails(): TaskDetails? {
        return stageTaskDetails.value
    }

    fun setStageTaskDetails(stageTaskDetails: TaskDetails) {
        this.stageTaskDetails.value = stageTaskDetails
    }

    fun taskReservePickComplete(reservePickCompleteRequest: ReservePickCompleteRequest) = viewModelScope.launch {
        reservePickCompleteResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.taskReservePickComplete(reservePickCompleteRequest)
        reservePickCompleteResponse.postValue(handleReservePickCompleteResponse(response))
    }

    private fun handleReservePickCompleteResponse(response: Response<ReservePickCompleteResponse>): Resource<ReservePickCompleteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ReservePickCompleteResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ReservePick Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun reservepickstage() = viewModelScope.launch {
        reservePickStageResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.reservepickstage()
        reservePickStageResponse.postValue(handleReservePickStageResponse(response))
    }


    fun reservepickstageupdate(reservePickStageRequest: ReservePickStageRequest) = viewModelScope.launch {
        reservePickStageResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.reservepickstageupdate(reservePickStageRequest)
        reservePickStageResponse.postValue(handleReservePickStageResponse(response))
    }

    private fun handleReservePickStageResponse(response: Response<ReservePickStageResponse>): Resource<ReservePickStageResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ReservePickCompleteResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ReservePickComplete Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate staging location
     */
    fun validateLocationDetails(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "Location Details Request: $locationClassReq")
        locationDetailsResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.validateLocationDetails(locationClassReq)
        locationDetailsResponse.postValue(handleStagingLocationResponse(response))
    }

    /**
     * method to handle staging location response
     */
    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Location Details Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }


    fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = viewModelScope.launch {
        FlareLog.i(TAG, "validateUPCorSLP Request: itemCode: $itemCode , upcOrSlp: $upcOrSlp")
        upcOrSlpResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.validateUPCorSLP(itemCode, upcOrSlp)
        upcOrSlpResponse.postValue(handleValidateUPCorSLP(response))
    }

    private fun handleValidateUPCorSLP(response: Response<UpcOrSlpResponse>): Resource<UpcOrSlpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateUPCorSLP Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateUPCorSLP Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun skipTaskLineItem(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        skipPickCartResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.ltlSkipTask(skipPickCartReq)
        skipPickCartResponse.postValue(handleSkipPickCartResponse(response))
    }


    private fun handleSkipPickCartResponse(response: Response<SkipPickCartRes>): Resource<SkipPickCartRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickSkipCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "pickSkipCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun isSerialNumberField(): Boolean {
        val taskPickResponse = getPickTaskDetails()

        val serialTracked = taskPickResponse?.itemSerialTracked ?: ""
        val uom = taskPickResponse?.taskQtyUom?.lowercase(Locale.ROOT) ?: ""
        return if (serialTracked == "1" && uom == "pallets") {
            true
        } else if (serialTracked == "1" && uom == "cases")
            true
        else if (serialTracked == "4" && uom == "cases")
            true
        else (serialTracked == "4" && uom == "pallets")

    }

    fun isNumberField(): Boolean {
        val taskPickResponse = getPickTaskDetails()

        val serialTracked = taskPickResponse?.itemSerialTracked ?: ""
        val uom = taskPickResponse?.taskQtyUom?.lowercase(Locale.ROOT) ?: ""
        return if (serialTracked == "0" && uom == "pallets") {
            true
        } else serialTracked == "0" && uom == "cases"

    }

     fun isPallet(taskDetail: TaskDetails?): Boolean {
        val uom = taskDetail?.taskQtyUom?.lowercase(Locale.ROOT) ?: ""
         return (uom == "pallets")
    }
    fun isPallet(uom: String?): Boolean {
        return (uom?.lowercase(Locale.ROOT) == "pallets")
    }


    // Live data to keep task completed list by user
    var completedTaskList: MutableLiveData<ArrayList<TaskDetails?>> = MutableLiveData<ArrayList<TaskDetails?>>()


    fun getTasksCompletedList(): ArrayList<TaskDetails?>? {
        return completedTaskList.value
    }

    fun setTasksCompletedList(dataList: ArrayList<TaskDetails?>) {
        this.completedTaskList.value = dataList
    }

    var onStageFromUserDirectedScreen=false
    //var popUpBackCount=0
    var markTaskCompleteRequest:MarkTaskCompleteRequestTivoPFR?=null

    var lotNumberTrackedPFA: MutableLiveData<String> = MutableLiveData<String>()
    var taskId: MutableLiveData<Int> = MutableLiveData<Int>()
    var orderId: MutableLiveData<Int> = MutableLiveData<Int>()
    private var qtyEntered: Int = 0
    var customerOrderNumber: MutableLiveData<String> = MutableLiveData<String>()

    fun setLotNumberTrackedPFA(lotNumberPFA: String){
        this.lotNumberTrackedPFA.value = lotNumberPFA
    }

    fun getLotNumberTrackedPFA():String?{
        return lotNumberTrackedPFA.value
    }

    fun setTaskId(taskId: Int) {
        this.taskId.value = taskId
    }

    fun getTaskId(): Int {
        return taskId.value!!
    }

    fun setOrderId(orderId: Int?) {
        this.orderId.value = orderId
    }

    fun getOrderId():Int? {
        return orderId.value
    }

    fun setCustomerOrderNumber(customerOrderNumber: String?) {
        this.customerOrderNumber.value = customerOrderNumber
    }

    fun getCustomerOrderNumber():String? {
        return customerOrderNumber.value
    }

    fun setQtyEntered(orderId: Int) {
        this.qtyEntered = orderId
    }

    fun getQtyEntered():Int {
        return qtyEntered
    }

    fun getInventoryLocksList(): List<Lookup> {
        return inventoryLocksList.value!!
    }

    fun setInventoryLocksList(inventoryLocksList: List<Lookup>) {
        this.inventoryLocksList.value = inventoryLocksList
    }
    fun validatePalletOverride(validatePalletOverrideRequest : ValidatePalletOverrideRequest) = viewModelScope.launch {
        validatePalletOverrideResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.validatePalletOverride(validatePalletOverrideRequest)
        validatePalletOverrideResponse.postValue(handleValidatePalletOverride(response))
    }
    private fun handleValidatePalletOverride(response: Response<ValidatePalletOverrideResponse>): Resource<ValidatePalletOverrideResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handleValidatePalletOverride Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handleValidatePalletOverride Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
    fun getScannedPallet(): String {
        return scannedPallet.value!!
    }
    fun setScannedPallet(scannedPallet: String) {
        this.scannedPallet.value = scannedPallet
    }
    fun generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest : CycleCountTriggerRequest, locationId: Long) = viewModelScope.launch {
        cycleCountTriggerResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest, locationId)
        cycleCountTriggerResponse.postValue(handleGenerateCycleCountToVerifyZeroLocation(response))
        generateCycleCount = false
    }
    private fun handleGenerateCycleCountToVerifyZeroLocation(response: Response<CycleCountTriggerResponse>): Resource<CycleCountTriggerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "cycleCountTriggerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "cycleCountTriggerResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun zeroLocationPromptCall(locationId: Long, skipPalletId: List<Long>) = viewModelScope.launch {
        zeroLocationPromptResponse.postValue(Resource.Loading())
        val response = pickFromReserveRepository.zeroLocationPromptCall(locationId, skipPalletId)
        zeroLocationPromptResponse.postValue(handleZeroLocationPromptCall(response))
    }
    private fun handleZeroLocationPromptCall(response: Response<ZeroLocationPromptResp>): Resource<ZeroLocationPromptResp>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "zeroLocationPromptResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "zeroLocationPromptResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun getLocationClassBasedOnAllocationType() = mapOf( AllocationType.PICK_FROM_RESERVE_RTV.code to "R",
        AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code to "QR",
        AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code to "DMR",
        AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code to "IL")

    fun getLocationValue(allocationCode: String?): String {
        val allocationMap = getLocationClassBasedOnAllocationType()
        return allocationMap[allocationCode] ?: "R"
    }

    fun isPickOrderTypeEnabled() =
        sharedPreferences.getBoolean(PreferenceKeys.PICK_ORD_TYPE_SELECTION_PREFERENCE, false)

    fun getConfiguredOrderTypes() =
        sharedPreferences.getString(ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE, null)?.split(",")
}