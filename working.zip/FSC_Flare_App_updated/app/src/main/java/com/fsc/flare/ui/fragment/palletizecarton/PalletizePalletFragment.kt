package com.fsc.flare.ui.fragment.palletizecarton

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizePalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizePalletFragment"
private const val ARG_PARAM1 = "screenTagName"
/**
 * A simple [PalletizePalletFragment] class.
 */
@AndroidEntryPoint
class PalletizePalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var screenTagName: String? = null

    private val viewModel: PalletizeViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizePalletBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null)
            arguments?.let {
                screenTagName = it.getString(ARG_PARAM1)
            }
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.pallet.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.pallet)
                FlareLog.i(TAG, "Pallet field focused")
                validateField()
            }
            false
        }
        subscribeObservers()

        binding.pallet.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.palletResponse.text = null
            }
        })
    }

    private fun validateField() {
        if (!binding.pallet.text?.trim().isNullOrEmpty()) {
            val containerType = viewModel.validateContainerType(sharedPreferences, "Pallet")
            val palletNumber = binding.pallet.text.toString().trim()
            if (containerType != null && (!palletNumber.startsWith(containerType.ctyId!!) || palletNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.palletResponse.text =
                    getString(R.string.pallet_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                viewModel.getPallet(binding.pallet.text.toString(), "N")
            }
        } else {
            binding.palletResponse.text = resources.getString(R.string.lbl_enter_valid_pallet_number)
        }
    }

    private fun subscribeObservers() {
        viewModel.palletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.container.isEmpty()) {
                            if (!screenTagName!!.contains("DE")) {
                                viewModel.setContainerInfo(containerResponse.container)
                                sharedPreferences.edit().putString(PreferenceKeys.Inventory.CONTAINER_NUMBER, binding.pallet.text.toString()).apply()
                                binding.pallet.text = null
                                val bundle = bundleOf(
                                    "screenTagName" to screenTagName
                                )
                                val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                navController.navigate(R.id.action_palletizePalletFragment_to_palletizeCartonFragment, bundle)
                            } else {
                                binding.palletResponse.text = resources.getString(R.string.lbl_invalid_pallet)
                                binding.pallet.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.pallet)
                            }
                        } else {
                            if (containerResponse.container.isNotEmpty()) {
                                val containerData = containerResponse.container[0]
                                if (containerData.containerType == "P") {
                                    if(containerData.ibObCode == "OB"){
                                        viewModel.setContainerInfo(containerResponse.container)
                                        binding.pallet.text = null
                                        val bundle = bundleOf(
                                            "screenTagName" to screenTagName
                                        )
                                        val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                                        navController.navigate(R.id.action_palletizePalletFragment_to_palletizeCartonFragment, bundle)
                                    }else{
                                        binding.palletResponse.text = resources.getString(R.string.lbl_invalid_pallet)
                                    }

                                } else {
                                    binding.palletResponse.text = resources.getString(R.string.lbl_invalid_container_type)
                                    binding.pallet.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.pallet)
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.palletResponse.text = message
                        binding.pallet.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.pallet)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizePalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.pallet.setText(scan?.barcode.toString())
            binding.pallet.text?.length?.let {
                binding.pallet.setSelection(
                    it
                )
            }
            FlareLog.i(TAG, "Pallet field focused")
            validateField()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}