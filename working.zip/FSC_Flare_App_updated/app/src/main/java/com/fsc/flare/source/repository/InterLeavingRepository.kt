package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTask
import com.fsc.flare.source.data.dto.interleaving.RegisterLocationRequest
import com.fsc.flare.source.data.dto.interleaving.ValidateContainerRequest
import com.fsc.flare.source.data.dto.putawayreverse.ContainerRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InterLeavingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences,
) {

    suspend fun getEquipmentType() = apiGatewayInterface.getEquipmentType(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )

    suspend fun getEquipmentCurrentPosition(equipmentNbr : String) = apiGatewayInterface.getEquipmentCurrentPosition(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        equipmentNbr = equipmentNbr
    )

    suspend fun interLeavingResisterLocation(taskType: String, registerLocationRequest: RegisterLocationRequest) = apiGatewayInterface.interLeavingResisterLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskType = taskType,
        registerLocationRequest = registerLocationRequest,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )

    suspend fun getInterLeaving(getInterLeavingPayload: GetInterLeavingRequest) = apiGatewayInterface.getInterLeaving(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        getInterLeavingPayload = getInterLeavingPayload,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )

    suspend fun validateContainer(taskType: String, containerRequest: ValidateContainerRequest) = apiGatewayInterface.interLeavingValidateContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskType =taskType,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        getInterLeavingPayload = containerRequest
    )

    suspend fun endInterleavingTask( containerRequest: InterLeavingEndTask) = apiGatewayInterface.interLeavingEndTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        getInterLeavingPayload = containerRequest
    )

    suspend fun executeInterLeavingTask( executeTaskRequest: ExecuteTaskRequest) = apiGatewayInterface.executeInterLeavingTask(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        executeTaskRequest = executeTaskRequest,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )
}