package com.fsc.flare.ui.fragment.inventory.casetransfer

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCasetransferContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainer
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerModel
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_COO
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_EXP_DATE
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_LOT
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_MFG_DATE
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CaseTransferContainerFragment"
private const val PALLET_NOT_IN_PUTAWAY_STATUS = "ERR-INV-0114"

/**
 * A simple [CaseTransferContainerFragment] class.
 */
@AndroidEntryPoint
class CaseTransferContainerFragment : BaseFragment(), FlareScannable, CaseTransferContainerAdapter.RemoveContainerInterface {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentCasetransferContainerBinding
    lateinit var cb1: CustomVisibilityCallback
    lateinit var adapter : CaseTransferContainerAdapter
    private var containerList = ArrayList<CaseTransferContainerModel>()
    private var itemId: String? = null
    var itemName:String? = null
    var itemBarCode:String? =null
    var inventoryType:String? =null
    var itemAttributes:CaseTransferContainer? =null
    private val checkedContainers = ArrayList<String>()
    private var containerNbrList = ArrayList<String>()
    private var itemUomConversionRateUtil: ItemUOMConversionRateUtil? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
        setItemInfo()
        enableButtonCheck()
    }

    private fun handleContainerCountView() {
        if(containerList.size>0)
        {
            binding.tvContainerListLbl.visibility = View.VISIBLE
            binding.tvView.visibility = View.VISIBLE
            binding.lnrItem.visibility = View.VISIBLE
            binding.lnrInventoryType.visibility = View.VISIBLE
            binding.btnEndCaseTransfer.isEnabled = true
        }else
        {
            binding.tvContainerListLbl.visibility = View.GONE
            binding.tvView.visibility = View.GONE
            binding.lnrItem.visibility = View.GONE
            binding.lnrInventoryType.visibility = View.GONE
            binding.btnEndCaseTransfer.isEnabled = false
            itemId = null
            itemName = null
            itemBarCode = null
            inventoryType = null
            itemAttributes = null
        }
    }

    private fun setItemInfo() {
        itemId = viewModel.getItemID()
        itemBarCode = viewModel.getItemCode()
        inventoryType = viewModel.getInventoryType()
        binding.tvInventoryType.text= inventoryType?.let { getInventoryDescription(it) }
        binding.tvItemBarcode.text = itemBarCode
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCasetransferContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.caseTransferHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        setupRecyclerView()
        updateContainerCountAndQtyCount()
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtContainer)
                    if (binding.edtContainer.isFocused && !binding.edtContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        ContainerInquiryCall()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.edtContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.edtContainer)
                FlareLog.i(TAG, "Container field focused")
                ContainerInquiryCall()
            }
            false
        }


        binding.btnEndCaseTransfer.setOnClickListener {
            //Set the container list to viewModel.
            viewModel.setCaseTransferContainerList(containerList)
            //Navigate to the Pallet scan page.
            navigatePalletScanPage()
        }

        subscribeObservers()

        if(containerList.size > 0){
            binding.tvContainerListLbl.visibility = View.VISIBLE
            binding.tvView.visibility = View.VISIBLE
        }

        binding.tvView.setOnClickListener{
            showScannedContainersList()
        }
        binding.edtContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerError.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun ContainerInquiryCall(){
        if(binding.edtContainer.text?.trim().toString().isNotEmpty()){
            viewModel.getContainerDetails(binding.edtContainer.text.toString().trim(),sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false))
        }
    }

    private fun showScannedContainersList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.containers_scanned))
        checkedContainers.clear()
        containerNbrList  = ArrayList(containerList.map { it.containerNumber})

        val ContainersArray = containerList.map { "${it.containerNumber}    ${it.qty} Units" }.toTypedArray()
        builder.setMultiChoiceItems(ContainersArray, null) { dialog, which, isChecked ->
            if(isChecked)
            {
                checkedContainers.add(containerNbrList[which])
            }
            else
            {
                checkedContainers.remove(containerNbrList[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
            //    Log.d("debug", "Position:" + which)
            //   Log.d("debug", "isChecked Item:$"+viewModel.getToteNumbersList()[which])
        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            removeCheckedContainers(checkedContainers)
            handleContainerCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }

    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedContainers.size>0
        if(checkedContainers.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    private fun removeCheckedContainers(checkedContainers: ArrayList<String>) {
        val filteredContianers = containerList.filter { it -> it.containerNumber !in checkedContainers }
        containerList.clear()
        containerList.addAll(filteredContianers)
        updateContainerCountAndQtyCount()
    }

    //Initialize recyclerview.
//    private fun setupRecyclerView() {
//        binding.containerRecyclerView.layoutManager = LinearLayoutManager(fragmentContext)
//        adapter = CaseTransferContainerAdapter(containerList, this)
//        binding.containerRecyclerView.adapter = adapter
//    }

    private fun enableButtonCheck(){
        binding.btnEndCaseTransfer.isEnabled = containerList.isNotEmpty()

        when {
            containerList.isNotEmpty() -> {
                binding.tvContainerListLbl.visibility = View.VISIBLE
                binding.lnrItem.visibility = View.VISIBLE
                binding.lnrInventoryType.visibility = View.VISIBLE
//                binding.labelLayout.visibility = View.VISIBLE
            }
            else -> {
                if(itemBarCode!=null)
                {
                    resetItemInfo()
                }
                binding.tvContainerListLbl.visibility = View.INVISIBLE
                binding.lnrItem.visibility = View.INVISIBLE
                binding.lnrInventoryType.visibility = View.INVISIBLE
//                binding.labelLayout.visibility = View.INVISIBLE
            }
        }
    }

    private fun resetItemInfo() {
        itemBarCode = null
        inventoryType = null
        itemId = null
        itemName = null
        viewModel.itemId = null
        viewModel.itemBarCode = null
        viewModel.itemInentoryType = null
    }

    private fun validateContainerApi() {
        if(binding.edtContainer.text.toString().trim().isNotEmpty()) {
            //Check if container is already scanned.
            if (isContainerScanned(binding.edtContainer.text.toString())) {
                binding.containerError.text = getString(R.string.case_transfer_container_already_scanned)
            } else {
                //validate container API.
                binding.containerError.text = null
                viewModel.caseTransferValidateContainer(binding.edtContainer.text.toString(), "Container")
            }
        }
    }

    private fun isContainerScanned(containerNbr: String):Boolean{
        var isScannedAlready = false
        if(containerList.isNotEmpty()){
            for(containerObj in containerList){
                if(containerObj.containerNumber.equals(containerNbr, true)){
                    isScannedAlready = true
                    break
                }
            }
        }
        return isScannedAlready
    }

    private fun subscribeObservers() {

        viewModel.containerInquiryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { containerResponse ->
                        if(!containerResponse.itemUOMConversions.isNullOrEmpty() && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false))){
                            itemUomConversionRateUtil = ItemUOMConversionRateUtil(containerResponse.itemUOMConversions)
                            viewModel.palletUomDefined(itemUomConversionRateUtil!!.isPalletUomDefined)
                            itemUomConversionRateUtil!!.getCasesQtyInAPallet()?.let { viewModel.setDefinedCaseQtyPerPallet(it) }
                        }
                        if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)){
                            if(containerResponse.containers?.get(0)?.lockCode == "CC"){
                                binding.containerError.text = getString(R.string.cycle_count_in_progress_for_given_location)
                            }else{
                                validateContainerApi()
                            }
                        }else{
                            if(containerResponse.containers?.get(0)?.cycleCountPending == "Y"){
                                binding.containerError.text = getString(R.string.cycle_count_is_pending_for_given_location)
                            }else{
                                validateContainerApi()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                FlareLog.e(TAG, "container error: $msgArray[1]")
                                binding.containerError.text = msgArray[1]
                            }
                        } else {
                            binding.containerError.text = message
                            FlareLog.e(TAG, "container error: $message")
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.caseTransferContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            if(itemUomConversionRateUtil != null && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) && (itemUomConversionRateUtil!!.isPalletUomDefined && viewModel.getCaseScannedCount() >= viewModel.getDefinedCaseQtyPerPallet()!!))){
                                binding.containerError.text = resources.getString(R.string.lbl_max_pallet_capacity_is_reached)
                            }else if(itemUomConversionRateUtil != null && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false) && (itemUomConversionRateUtil!!.isCaseUomDefined && containerResponse.palletInquiry.containerQuantity > itemUomConversionRateUtil!!.getEachesQtyInACase()!!))){
                                binding.containerError.text = resources.getString(R.string.lbl_scanned_case_is_having_qty_greater_than_case_uom)
                            }else{
                                addContainerToList(containerResponse.palletInquiry)
                                handleContainerCountView()
                            }
                        } else {
                            if (containerResponse.message != null && containerResponse.message.isNotEmpty()) {
                                binding.containerError.text = containerResponse.message
                            } else {
                                binding.containerError.text = getString(R.string.container_cannot_be_transferred)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                if(msgArray[0] == PALLET_NOT_IN_PUTAWAY_STATUS && binding.edtContainer.text.toString().trim().isNotEmpty())
                                {
                                    binding.edtContainer.requestFocus()
                                    binding.containerError.text = msgArray[1]
                                    binding.edtContainer.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.edtContainer)
                                }
                                else
                                {
                                    binding.edtContainer.requestFocus()
                                    binding.containerError.text = msgArray[1]
                                    binding.edtContainer.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.edtContainer)
                                }
                            }
                        }
                        else
                        {
                            binding.edtContainer.requestFocus()
                            binding.containerError.text = message
                            binding.edtContainer.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.edtContainer)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtContainer.setText(scan?.barcode.toString())
            binding.edtContainer.text?.length?.let {
                binding.edtContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Container field focused")
            ContainerInquiryCall()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun addContainerToList(caseTransferContainer: CaseTransferContainer) {
        if (caseTransferContainer.containerNumber != null) {
            if (containerList.isEmpty()) {
                if (caseTransferContainer.currentLocationType != null && (caseTransferContainer.currentLocationType == "R" || caseTransferContainer.currentLocationType == "C")) {
                    addToList(caseTransferContainer)
                } else {
                    binding.containerError.text =
                        getString(R.string.case_must_belong_to_reserve_or_casepick)
                }
            } else {
                if (isContainerScanned(caseTransferContainer.containerNumber)) {
                    binding.containerError.text =
                        getString(R.string.case_transfer_container_already_scanned)
                } else if (caseTransferContainer.currentLocationType != null && (caseTransferContainer.currentLocationType == "R" || caseTransferContainer.currentLocationType == "C")) {
                    // If item doesn't match
                    if (itemId != null && itemId != caseTransferContainer.itemId) {
                        // showErrorSnackBar(getString(R.string.label_error_mismatch_container_count))
                        showErrorAlert(true)
                    } else if (inventoryType != null && caseTransferContainer.inventoryType != inventoryType) {
                        showErrorAlert(false)
                    } else if (itemAttributes != null) {
                        val mixedAttributes = hasMixedAttributes(itemAttributes!!, caseTransferContainer)
                        when {
                            mixedAttributes.size > 1 -> {
                                showMixedAttributeError(getString(R.string.mixed_attributes_are_not_allowed_to_be_part_of_a_pallet))
                                return
                            }

                            mixedAttributes.size == 1 -> {
                                when {
                                    mixedAttributes[0] == MIXED_ATTRIBUTE_LOT -> {
                                        showMixedAttributeError(getString(R.string.mixed_lots_are_not_allowed_to_be_part_of_a_pallet))
                                    }

                                    mixedAttributes[0] == MIXED_ATTRIBUTE_EXP_DATE -> {
                                        showMixedAttributeError(getString(R.string.mixed_expiry_dates_are_not_allowed_to_be_part_of_a_pallet))
                                    }

                                    mixedAttributes[0] == MIXED_ATTRIBUTE_COO -> {
                                        showMixedAttributeError(getString(R.string.mixed_coo_s_are_not_allowed_to_be_part_of_a_pallet))
                                    }

                                    mixedAttributes[0] == MIXED_ATTRIBUTE_MFG_DATE -> {
                                        showMixedAttributeError(getString(R.string.mixed_manufacturing_dates_are_not_allowed_to_be_part_of_a_pallet))
                                    }
                                }
                                return
                            }
                            else -> {
                                addToList(caseTransferContainer)
                            }
                        }
                    } else {
                        addToList(caseTransferContainer)
                    }
                } else {
                    binding.containerError.text =
                        getString(R.string.case_must_belong_to_reserve_or_casepick)
                }
            }
            itemAttributes = caseTransferContainer
        } else {
            binding.containerError.text = getString(R.string.invalid_case_serial_number)
        }
        enableButtonCheck()
        updateContainerCountAndQtyCount()
    }

    private fun addToList(caseTransferContainer: CaseTransferContainer){

        if (itemId == null) {
            itemId = caseTransferContainer.itemId
            itemName = caseTransferContainer.itemName
            itemBarCode = caseTransferContainer.itemBarCode
            viewModel.itemId = itemId
            viewModel.itemBarCode = itemBarCode
        }
        if(inventoryType == null)
        {
            inventoryType = caseTransferContainer.inventoryType
            viewModel.itemInentoryType = inventoryType
        }
        containerList.add(CaseTransferContainerModel(caseTransferContainer.containerNumber,
            caseTransferContainer.containerQuantity,
            itemId,
            caseTransferContainer.itemCode,
            caseTransferContainer.itemDescription,
            inventoryType,
            caseTransferContainer.currentLocation
        ))
        binding.containerError.text = null
        binding.edtContainer.text = null

        if(itemBarCode!=null)
        {
            binding.lnrItem.visibility = View.VISIBLE
            binding.tvItemBarcode.text = itemBarCode
        }
        if(inventoryType!=null)
        {
            binding.lnrInventoryType.visibility = View.VISIBLE
            binding.tvInventoryType.text= inventoryType?.let { getInventoryDescription(it) }
        }
    }

    private fun showErrorAlert(isMixedItem: Boolean) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(if (isMixedItem) resources.getString(R.string.lbl_mixed_items_not_allowed) else getString(R.string.receiving_mixed_inventory_not_allowed))
        builder.setMessage(if (isMixedItem) resources.getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check) else getString(
            R.string.containers_have_different_inventory_type_can_not_palletize_together))

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, which ->
            dialogInterface.dismiss()
            binding.edtContainer.text = null
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showMixedAttributeError(message: String) {
        binding.edtContainer.requestFocus()
        binding.containerError.text = message
        binding.edtContainer.selectAll()
        showSoftKeyBoard(fragmentContext, binding.edtContainer)
    }

    private fun navigatePalletScanPage(){
      //Navigate to the Pallet scan page.
        getNavigationController()
            .navigate(CaseTransferContainerFragmentDirections.actionCaseTransferContainerFragmentToCaseTransferPalletFragment())
    }

    override fun removeClick(position: Int) {
        if(containerList.isNotEmpty()){
            containerList.removeAt(position)
//            adapter.notifyDataSetChanged()
            enableButtonCheck()
            updateContainerCountAndQtyCount()
        }
    }

    private fun updateContainerCountAndQtyCount() {
        var caseScannedCount = 0
        var caseQtyUnits = 0
        if(containerList.isNotEmpty()) {
            for (containerObj in containerList) {
                caseQtyUnits = caseQtyUnits.plus(containerObj.qty.toInt())
                caseScannedCount = caseScannedCount.plus(1)
            }
        }

        viewModel.setCaseScannedCount(caseScannedCount)
        viewModel.setCaseQtyUnits(caseQtyUnits)

        binding.tvContainerListLbl.text = getString(R.string.case_transfer_cnt_list_lbl_new,
            resources.getQuantityString(R.plurals.case_transfer_scanned_cases, caseScannedCount, caseScannedCount),
            resources.getQuantityString(R.plurals.case_transfer_scanned_case_units, caseQtyUnits, caseQtyUnits))
    }

    private fun hasMixedAttributes(
        itemAttributes: CaseTransferContainer?,
        validateLPNResponse: CaseTransferContainer?
    ): ArrayList<String> {
        val mixedAttributes = arrayListOf<String>()
        if (itemAttributes?.lotNumber != validateLPNResponse?.lotNumber) {
            mixedAttributes.add(MIXED_ATTRIBUTE_LOT)
        }
        if (itemAttributes?.expDate != validateLPNResponse?.expDate) {
            mixedAttributes.add(MIXED_ATTRIBUTE_EXP_DATE)
        }
        if (itemAttributes?.coo != validateLPNResponse?.coo) {
            mixedAttributes.add(MIXED_ATTRIBUTE_COO)
        }
        if (itemAttributes?.mfgDate != validateLPNResponse?.mfgDate) {
            mixedAttributes.add(MIXED_ATTRIBUTE_MFG_DATE)
        }
        return mixedAttributes
    }
}

