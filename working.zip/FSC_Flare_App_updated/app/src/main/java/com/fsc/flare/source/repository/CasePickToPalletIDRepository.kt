package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class CasePickToPalletIDRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    private val apiGatewayAccessToken =
        sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)
    private val userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1)
    private val fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
    val custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)
    val buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
    val fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    val allocationType = "20"
    val casePicktoPalletAllocationTypes = "20,21"

    suspend fun getTransactionParam(ltlCubeTransParamsKey: String) =
        apiGatewayInterface.validateTransactionParam(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = custId,
            buId = buId,
            fcyId = fcyId,
            transCode = ltlCubeTransParamsKey
        )

    suspend fun generatePalletCaseNumber(type: String) = fedexId?.let {
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer $apiGatewayAccessToken", it, custId, buId, fcyId, type = type
        )
    }

    suspend fun getTaskPick(taskPickReq: TaskPickCartReq) = apiGatewayInterface.getTaskPickCart(
        "Bearer $apiGatewayAccessToken", userId, taskPickCartReq = taskPickReq
    )

    suspend fun pickEndCart(endPickCartReq: EndPickCartReq) = apiGatewayInterface.pickEndCart(
        "Bearer $apiGatewayAccessToken", userId = userId, endPickCartReq = endPickCartReq
    )

    suspend fun buildSkipCart(
        pickCartNbr: String, skipTaskId: String, skipTaskDetId: String, isLTLCubingEnabled: Boolean
    ) = apiGatewayInterface.buildSkipCart(
        "Bearer $apiGatewayAccessToken",
        userId = userId,
        fcyId = fcyId,
        custId = custId,
        buId = buId,
        pickCartNbr = pickCartNbr,
        assignedTo = userId,
        allocationType = allocationType,
        skipTaskId = skipTaskId,
        skipTaskDetId = skipTaskDetId,
        isLTLcubing = isLTLCubingEnabled,
        casePickWithPallet = true
    )

    suspend fun taskCasePickComplete(taskCasePickCompleteReq: TaskCasePickCompleteReq) =
        apiGatewayInterface.taskcasepickcomplete(
            "Bearer $apiGatewayAccessToken",
            userId = userId,
            taskCasePickCompleteReq = taskCasePickCompleteReq
        )

    suspend fun validateStagingLocation(locationBarcode: String) =
        apiGatewayInterface.validateStagingLocation(
            "Bearer $apiGatewayAccessToken",
            userId = userId,
            customerId = custId,
            facility = fcyId,
            barcode = locationBarcode,
            locationClass = ""
        )

    suspend fun getInventoryReasonCodes() = fedexId?.let {
        apiGatewayInterface.getInventoryReasonCodes(
            "Bearer $apiGatewayAccessToken",
            it,
            cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        )

    }

    suspend fun validateContainerOverride(validateCaseOverrideRequest: ValidateCaseOverrideRequest) =
        apiGatewayInterface.validatePalletOverride(
            "Bearer $apiGatewayAccessToken",
            userId = userId,
            custId = custId,
            buId = buId,
            fcyId = fcyId,
            validateCaseOverrideRequest = validateCaseOverrideRequest
        )

    suspend fun taskActivePickStaging(taskPickActiveStagingReq: TaskPickActiveStagingReq) =
        apiGatewayInterface.taskactivepickstaging(
            "Bearer $apiGatewayAccessToken",
            sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            taskPickActiveStagingReq = taskPickActiveStagingReq
        )

    suspend fun getTaskGroups() = apiGatewayInterface.getTaskGroupsSrf(
        "Bearer $apiGatewayAccessToken",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        allocationType = casePicktoPalletAllocationTypes
    )

    suspend fun validateSerialNumberWithItemCode(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        containerId: Int
    ) = apiGatewayInterface.validateSerialNumberWithItemCodeForContainerPicking(
        "Bearer $apiGatewayAccessToken",
        fedexId = fedexId ?: "",
        custId = custId,
        buId = buId,
        fcyId = fcyId,
        serialNumberOrItemId = serialNumberOrItemId,
        isOutBoundOnly = isOutBoundOnly,
        pickLocationId = pickLocationId,
        itemId = itemId,
        containerId = containerId
    )

    suspend fun getContainer(container: String, itemInfo: String) =
        apiGatewayInterface.getContainer(
            "Bearer $apiGatewayAccessToken",
            fedexId = fedexId ?: "",
            custId = custId,
            buId = buId,
            fcyId = fcyId,
            containerNumber = container,
            itemInfo = itemInfo
        )

}