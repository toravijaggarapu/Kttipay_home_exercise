package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBCOOBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBCOOFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBCOOFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBCOOFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBCOOBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        cb1.onVisibilityChange(true)
        super.onResume()
    }



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBCOOBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val itemData = viewModel.getItemBarcodeData()

        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.tvItemCodeValue.text = itemData?.itemBarCode
        binding.tvItemDescValue.text = itemData?.description

        binding.etCoo.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etCoo)
                FlareLog.i(TAG, "Country Of Origin field focused")
                if (!binding.etCoo.text.isNullOrEmpty()) {
                    validateCOO()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etCoo.isFocused && !binding.etCoo.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Country Of Origin field focused")
                        validateCOO()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etCoo.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvCooResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    /**
     * method to validate COO
     */
    private fun validateCOO() {
        viewModel.setInputCoo(binding.etCoo.text.toString())
        navigate()
    }

    /**
     * method to handle navigation to next screen
     */
    private fun navigate() {
        val itemData = viewModel.getItemBarcodeData()
        if (itemData?.tracking != null) {
            when (itemData.tracking.serialNumberRequired) {
                "4" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBCOOFragmentDirections.actionUomFragmentToSerialFragment()
                    navController.navigate(action)
                }
                else -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBCOOFragmentDirections.actionCooFragmentToLockReasonCodeFragment()
                    navController.navigate(action)
                }
            }
        }
    }



    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etCoo.setText(scan?.barcode.toString())
                binding.etCoo.text?.length?.let {
                    binding.etCoo.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Country Of Origin field focused")
                    validateCOO()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}