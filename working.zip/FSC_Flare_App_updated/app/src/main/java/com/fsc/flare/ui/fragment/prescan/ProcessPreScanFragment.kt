package com.fsc.flare.ui.fragment.prescan

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentProcessPrescanBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.prescan.createShipment.request.CreateShipmentRequest
import com.fsc.flare.source.data.dto.prescan.createShipment.request.Destination
import com.fsc.flare.source.data.dto.prescan.createShipment.request.InboundShipment
import com.fsc.flare.source.data.dto.prescan.createShipment.request.ItemLPN
import com.fsc.flare.source.data.dto.prescan.trackingNumber.ValidateTrackingNumberRequest
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.CUSTOMER_DETAILS
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.DEFAULT_VENDOR_CODE
import com.fsc.flare.utils.Constants.PreScanScreen.Companion.LAUNCHED_FROM_PRE_PROCESS_SCREEN
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = ProcessPreScanFragment::class.java.simpleName.toString()

/**
 * A Fragment for Process PreScan and create new shipment , this fragment is launched from create shipment fragment.
 */
@AndroidEntryPoint
class ProcessPreScanFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PreScanViewModel by activityViewModels()

    private lateinit var fragmentProcessPrescanBinding: FragmentProcessPrescanBinding
    private lateinit var defaultVendorCode: String

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fragmentProcessPrescanBinding =
            FragmentProcessPrescanBinding.inflate(inflater, container, false)
        return fragmentProcessPrescanBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setBundledData()
        setListeners()
        callLookUpAPI()
        subscribeObservers()
        setStoreNumber()
    }

    private fun setBundledData() {
        with(fragmentProcessPrescanBinding) {
            tvCustomerDetails.text =
                requireArguments().getString(CUSTOMER_DETAILS) ?: ""
        }
        defaultVendorCode = requireArguments().getString(DEFAULT_VENDOR_CODE) ?: ""
    }

    private fun setListeners() {
        with(fragmentProcessPrescanBinding) {
            btnProcessPrescan.setOnClickListener {
                verifyNecessaryFeildsAndPresacnApiCall()
            }

            etTrackingNumber.addTextChangedListener {
                setVisibilityForErrorTrackingNumber(it)
            }
        }
    }

    /**
     * method to set Store number
     */
    private fun setStoreNumber(){
        viewModel.storeNumber.observe(viewLifecycleOwner) {
            fragmentProcessPrescanBinding.tvStoreNumber.text  = it
        }
    }

    /**
     * method to set visibility for if tracking number not enter error message
     */
    private fun setVisibilityForErrorTrackingNumber(editable: Editable?) {
        fragmentProcessPrescanBinding.tvTrackingNumberError.visibility =
            if (editable.isNullOrBlank()) View.VISIBLE else View.GONE
    }

    /**
     * A method to subscribeObservers for create shipment or process prescan
     */
    private fun subscribeObservers() {
        viewModel.listCarrierScac.observe(viewLifecycleOwner) {
            handleCarrierScacSuccessReponse(it)
        }

        viewModel.createShipmentResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { vendorsResponse ->
                        FlareLog.i(TAG, "Create Shipment response Success:")
                        if (vendorsResponse.success) {
                            navigateToPrescanFragment()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "Create Shipment response error: $message")
                        showErrorSnackBar(resources.getString(R.string.alert_something_went_wrong))
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

            }
        }

        viewModel.validateTrackingNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { trackingNumberResponse ->
                        FlareLog.i(TAG, "validateTrackingNumberResponse Success:")
                        if (trackingNumberResponse.success) {
                            processPrescanApiCall()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "validateTrackingNumberResponse response error: $message")
                        showAlertDialog(
                            "",
                            message
                        ) {}
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

            }
        }
    }

    private fun handleCarrierScacSuccessReponse(carrierScacDropDownList: List<String>?) {
        with(fragmentProcessPrescanBinding) {
            if (!carrierScacDropDownList.isNullOrEmpty()) {
                carrierScacDropDown.setOptions(carrierScacDropDownList)
            }
            tvRmaNumber.text =
                viewModel.validateRMAResponse.customerASNNumber

            viewModel.validateRMAResponse.customerInformation?.customerNumber?.let {
                etCustomerNumber.text = it
            }
            //etCustomerNumber.text = viewModel.getVendorNumber()
            setVisibilityToReturnType()
        }
    }

    private fun FragmentProcessPrescanBinding.setVisibilityToReturnType() {
        if (viewModel.getSelectedReturnType().isNullOrEmpty()){
            tvReturnType.visibility = View.GONE
            tvReturnTypeTitle.visibility = View.GONE
        }else {
            tvReturnType.text = viewModel.getSelectedReturnType()
        }
    }

    /**
     *  A Override method for show home ,logout,account menu icon in action bar
     */

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to verify All necessary data are field
     */
    private fun verifyNecessaryFeildsAndPresacnApiCall() {
        when {
            fragmentProcessPrescanBinding.etTrackingNumber.text.isNullOrEmpty() ->
                displayErrorMessage(resources.getString(R.string.tracking_number_alert_dialog_message))

            fragmentProcessPrescanBinding.etClaimNumber.text.isNullOrEmpty() ->
                showEnterClaimNumberSuggestionAlertDialog(
                    resources.getString(R.string.trailer_number_alert_dialog_message)
                )

            else -> {
                validateTrackingNumbernApiCall()
            }
        }
    }

    /**
     * method to call lookup API for get get CarrierSCAC
     */
    private fun callLookUpAPI() {
        viewModel.getCarrierSCAC()
    }

    /**
     * Function to Validate tracking number before process pre scan api call
     */
    private fun validateTrackingNumbernApiCall() {
        viewModel.getValidateTrackingNumber(
            ValidateTrackingNumberRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                trackingNumber = fragmentProcessPrescanBinding.etTrackingNumber.text.toString().trim()
            )
        )
    }

    /**
     * Function to process pre scan api call
     */
    private fun processPrescanApiCall() {
        viewModel.processPrescan(
            CreateShipmentRequest(
                inboundShipment = InboundShipment(
                    asnType = fragmentProcessPrescanBinding.tvReturnType.text.toString().trim(),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custFcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    custVendorNumber = fragmentProcessPrescanBinding.etCustomerNumber.text.toString().trim(),
                    customerASNNumber = viewModel.validateRMAResponseObject.customerASNNumber,
                    customerID = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    destination = Destination(
                        businessUnit = sharedPreferences.getString(
                            PreferenceKeys.CUST_CODE,
                            null
                        ),
                        facilityCode = sharedPreferences.getString(PreferenceKeys.FACILITY_NAME, "")
                    ),
                    itemLPN = listOf(
                        with(fragmentProcessPrescanBinding) {
                            ItemLPN(
                                trackingNbr = etTrackingNumber.text.toString().trim(),
                                trailerNumber = etTrailerNumber.text.toString().trim(),
                                claimNumber = etClaimNumber.text.toString().trim(),
                                raCarrierCode = viewModel.getCodeFromSelectedDescription(
                                    carrierScacDropDown.text.toString().trim()
                                ),
                                raBolNumber = etBolNumber.text.toString().trim(),
                                storeNumber = tvStoreNumber.text.toString().trim(),
                                custVendorNumber = etCustomerNumber.text.toString().trim()
                            )
                        }
                    )
                )
            )
        )
    }

    /**
     * Function to display Claim number enter suggestion Alert dialog
     */
    private fun showEnterClaimNumberSuggestionAlertDialog(
        message: String?
    ) {
        if (message != null) {
            showAlertDialog("", message,
                onPositiveClick = {
                    validateTrackingNumbernApiCall()
                },
                onNegativeClick = { })
        }
    }

    /**
     * method to display Error Message if Tracking Number missing
     */
    private fun displayErrorMessage(errorMessage: String) {
        with(fragmentProcessPrescanBinding) {
            setVisibilityForErrorTrackingNumber(etTrackingNumber.text)
            tvTrackingNumberError.text = errorMessage
            etTrackingNumber.requestFocus()
            etTrackingNumber.selectAll()
            showSoftKeyBoard(fragmentContext, etTrackingNumber)
        }
    }


    /**
     * method to navigate to prescan fragment if process scan success
     */
    fun navigateToPrescanFragment() {
        FlareLog.e(TAG, "navigateToProcessPrescanFragment called")
        val bundle = bundleOf(
            LAUNCHED_FROM_PRE_PROCESS_SCREEN to TAG,
        )
        getNavigationController().navigate(
            R.id.action_processPreScanFragment_to_preScanFragment,
            bundle
        )
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        fragmentProcessPrescanBinding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        fragmentProcessPrescanBinding.progressBar.visibility = View.GONE
    }
}