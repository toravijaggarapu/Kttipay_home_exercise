package com.fsc.flare.ui.fragment.createIBContainer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCIBLotBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "CIBLotFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [CIBLotFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class CIBLotFragment : BaseFragment(), FlareScannable {

    private val viewModel: CIBViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    private lateinit var binding: FragmentCIBLotBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCIBLotBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etLotNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvLotNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        val itemData = viewModel.getItemBarcodeData()

        binding.tvContainerNumberValue.text = viewModel.getInputContainerNumber()
        binding.tvItemCodeValue.text = itemData?.itemBarCode
        binding.tvItemDescValue.text = itemData?.description

        binding.etLotNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLotNumber)
                FlareLog.i(TAG, "Lot Number field focused")
                if (!binding.etLotNumber.text.isNullOrEmpty()) {
                    validateLotNumber()
                }
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etLotNumber.isFocused && !binding.etLotNumber.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Lot Number field focused")
                        validateLotNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeContainerObserver()
    }


    /**
     * method to validate LotNumber
     */
    private fun validateLotNumber() {
        if(binding.etLotNumber.text.toString().trim().isNotEmpty())
        {
            viewModel.validateLotNumber(
                ValidateLotNumberRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    batchNumber = binding.etLotNumber.text.toString(),
                    itemName = viewModel.getItemBarcodeData()?.itemName!!,
                    itemId = viewModel.getItemBarcodeData()?.itemId!!
                )
            )
        }else
        {
            binding.tvLotNumberResponse.text = getString(R.string.enter_lot_num)
            binding.etLotNumber.requestFocus()
            binding.etLotNumber.selectAll()
            showSoftKeyBoard(fragmentContext, binding.etLotNumber)
        }
    }
    /**
     * method to subscribe validate container observer
     */
    private fun subscribeContainerObserver() {
        viewModel.lotNumberResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lotNumberResponse ->
                        if (lotNumberResponse.success != null && lotNumberResponse.success) {
                            if(lotNumberResponse.batchDetail!=null && lotNumberResponse.batchDetail.isNotEmpty())
                            {
                                viewModel.setInputLotNumber(binding.etLotNumber.text.toString())
                                navigate()
                            }else{
                                binding.tvLotNumberResponse.text = getString(R.string.no_lot_found)
                                binding.etLotNumber.requestFocus()
                                binding.etLotNumber.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etLotNumber)
                            }

                        } else {
                            binding.tvLotNumberResponse.text = lotNumberResponse.message
                            binding.etLotNumber.requestFocus()
                            binding.etLotNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etLotNumber)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
            }
        }
    }


    /**
     * method to handle navigation to next screen
     */
    private fun navigate() {
        val itemData = viewModel.getItemBarcodeData()
        if (itemData?.tracking != null) {
            when {
                itemData.tracking.expirationRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBLotFragmentDirections.actionUomFragmentToExpiryDateFragment()
                    navController.navigate(action)
                }
                itemData.tracking.countryOfOriginRequired == "1" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBLotFragmentDirections.actionUomFragmentToCooFragment()
                    navController.navigate(action)
                }
                /*itemData.tracking.serialNumberRequired == "1" ||*/ itemData.tracking.serialNumberRequired == "4" -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBLotFragmentDirections.actionUomFragmentToSerialFragment()
                    navController.navigate(action)
                }
                else -> {
                    val navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action =
                        CIBLotFragmentDirections.actionLotFragmentToLockReasonCodeFragment()
                    navController.navigate(action)
                }
            }
        }
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etLotNumber.setText(scan?.barcode.toString())
                binding.etLotNumber.text?.length?.let {
                    binding.etLotNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Lot Number field focused")
                    validateLotNumber()
                }
    }


    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}