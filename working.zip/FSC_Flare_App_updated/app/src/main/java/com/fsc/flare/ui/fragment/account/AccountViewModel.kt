package com.fsc.flare.ui.fragment.account

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.LangUpdateRequest
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.repository.AccountRepository
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.CUSTOMER_ENROLLMENT_TYPE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class AccountViewModel @Inject constructor(
    private val accountRepository: AccountRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {
    val fetchAuthMenu = SingleLiveEvent<Resource<AuthorizedMenu>>()
    val updateLanguage: MutableLiveData<Resource<LangUpdateResponse>> = MutableLiveData()

    private val _customerDetailsState = MutableLiveData<CustomerDetailsFetchState?>()
    val customerDetailsState: LiveData<CustomerDetailsFetchState?> = _customerDetailsState

    fun fetchAuthorizedMenu() = viewModelScope.launch {
        fetchAuthMenu.postValue(Resource.Loading())
        val token = if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
            sharedPreferences.getString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, "")!!
        } else {
            sharedPreferences.getString(PreferenceKeys.OKTA_ACCESS_TOKEN, "")!!
        }
        val response = accountRepository.fetchAuthorizedMenu(token)
        fetchAuthMenu.postValue(handleAuthMenuResponse(response))
    }

    private fun handleAuthMenuResponse(response: Response<AuthorizedMenu>): Resource<AuthorizedMenu> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun updateAppLanguage(lang:String) = viewModelScope.launch {
        updateLanguage.postValue(Resource.Loading())
        val response = accountRepository.updateAppLanguage(LangUpdateRequest(lang))
        updateLanguage.postValue(handleLangUpdateResponse(response))
    }

    private fun handleLangUpdateResponse(response: Response<LangUpdateResponse>): Resource<LangUpdateResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "Success response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    fun fetchSelectedCustomerDetailsAndSaveEnrollmentType(customerId: Int, scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _customerDetailsState.postValue(CustomerDetailsFetchState.Loading)
            val response = accountRepository.getCustomerDetails(customerId)
            if (response.isSuccessful && response.body() != null) {
                response.body()?.customers?.getOrNull(0)?.let { customer ->
                    sharedPreferences.edit().putString(CUSTOMER_ENROLLMENT_TYPE, customer.enrollmentType).apply()
                }
            } else {
                val errorResponse = handleForwardErrorResponse(
                    response.code(),
                    response.errorBody(),
                    response.message()
                )
                FlareLog.e(TAG, "Error Response: $errorResponse")
            }
            _customerDetailsState.postValue(CustomerDetailsFetchState.NavigateToHome)
        }
    }

    fun clearStates() {
        _customerDetailsState.value = null
    }
}

sealed class CustomerDetailsFetchState {
    data object Loading: CustomerDetailsFetchState()
    data object NavigateToHome: CustomerDetailsFetchState()
}