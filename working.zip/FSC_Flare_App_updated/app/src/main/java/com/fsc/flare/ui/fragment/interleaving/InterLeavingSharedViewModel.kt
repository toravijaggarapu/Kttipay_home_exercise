package com.fsc.flare.ui.fragment.interleaving

import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.interleaving.TaskInterLeavingData
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingResponse

class InterLeavingSharedViewModel : ViewModel() {

    var taskInterLeavingResponse: TaskInterLeavingData? = null
    var taskType : String? = null
    var validateContainerResponse: GetInterLeavingResponse? = null

    var equipmentId : Int? = null
    var equipmentTypeId : Int? = null

    fun clearData() {
        taskInterLeavingResponse = null
        taskType = null
        validateContainerResponse = null
        equipmentId = null
        equipmentTypeId = null
    }
}