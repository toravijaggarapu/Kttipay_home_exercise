package com.fsc.flare.base

import android.content.Context
import android.content.DialogInterface
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.View.OnClickListener
import android.view.View.OnFocusChangeListener
import android.view.View.OnTouchListener
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RadioGroup.OnCheckedChangeListener
import android.widget.TextView
import android.widget.TextView.OnEditorActionListener
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.BuildConfig
import com.fsc.flare.R
import com.fsc.flare.databinding.RfContentCenterDialogBinding
import com.fsc.flare.databinding.RfCustomDialogBinding
import com.fsc.flare.databinding.RfKitItemDialogBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.kitting.KitItem
import com.fsc.flare.transactiontracker.FSCTransactionTracker
import com.fsc.flare.transactiontracker.dto.FSCTransactionDetailModel
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_ALERT
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_BUTTON
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_CANCEL
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_CHECKED
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_CLICK
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_CLOSE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_CUSTOM_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_DELETE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_DISPLAY
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_DROPDOWN
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_ENTER
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_ERROR_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_EXIT
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_FOCUS
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_INFO_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_ITEM_LIST
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_KIT_LIST
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_MANUAL
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_NAVIGATION
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_NEW_TASK
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_NO
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_OK
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_RADIOBUTTON
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SCAN
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SCANNER
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SCREEN
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SELECT
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_STAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SUBMIT
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_SUCCESS_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_TEXTVIEW
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_TEXT_FIELD
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_TOAST
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_WARN_MESSAGE
import com.fsc.flare.transactiontracker.logs.FSCTransactionConstants.TRACKER_YES
import com.fsc.flare.ui.activity.main.MainActivity
import com.fsc.flare.ui.fragment.kitting.KittingComponentAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.getUTCServerTimeStamp
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

private const val SHOW_EXTRA_LONG_TIME = 4000

@AndroidEntryPoint
abstract class BaseFragment : Fragment(),
    MenuProvider,
    FlareScannable,
    OnClickListener,
    OnCheckedChangeListener,
    OnFocusChangeListener,
    OnTouchListener,
    OnEditorActionListener,
    AdapterView.OnItemClickListener {

    var screenName: String = this.javaClass.simpleName
    private var isScanned = false
    protected lateinit var fragmentContext: Context
    private var messageSnackBar: Snackbar? = null

    @Inject
    lateinit var sharedPreferencesBase: SharedPreferences
    private var customVisibilityCallback: CustomVisibilityCallback? = null
    @Inject
    lateinit var trackerInstance: FSCTransactionTracker

    private var focusedEditText: EditText? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentContext = context
    }

    override fun onResume() {
        updateTracker("", TRACKER_ENTER, TRACKER_NAVIGATION, Date(), "", "")
        messageSnackBar?.dismiss()
        super.onResume()
        FlareLog.d("RunningFragment ====>", this.javaClass.name)
        isProgressBarVisible()
        if (sharedPreferencesBase.getString(PreferenceKeys.CUST_CODE, null) != null) {
            val actionBar = (activity as AppCompatActivity).supportActionBar
            actionBar?.title = sharedPreferencesBase.getString(PreferenceKeys.CUST_CODE, null) +
                    " - " + sharedPreferencesBase.getString(PreferenceKeys.FEDEX_ID, null)
            customVisibilityCallback?.onVisibilityChange(true)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val menuHost: MenuHost = requireHost() as MenuHost
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    override fun onPause() {
        messageSnackBar?.dismiss()
        updateTracker("", TRACKER_EXIT, TRACKER_NAVIGATION, Date(), "", "")
        super.onPause()
    }

    private fun eventTrackMessage(objectType: String, elementName: String, action: String, message: String) {
        updateTracker(objectType, elementName, action, Date(), TRACKER_MESSAGE, message)
    }

    fun showSuccessSnackBar(message: String) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message, Snackbar.LENGTH_LONG
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.green
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            textView.setTypeface(null, Typeface.BOLD)
            snackBar.setTextColor(Color.WHITE)
            snackBar.show()
        }
        messageSnackBar?.view?.setOnClickListener { _ -> messageSnackBar?.dismiss() }
        eventTrackMessage(TRACKER_TOAST, TRACKER_SUCCESS_MESSAGE, "", message)
    }

    fun showSuccessSnackBarStd(message: String, onDismiss: () -> Unit) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message, Snackbar.LENGTH_LONG
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.green
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            textView.setTypeface(null, Typeface.BOLD)
            snackBar.setTextColor(Color.WHITE)
            snackBar.show()
        }
        messageSnackBar!!.addCallback(object : BaseTransientBottomBar.BaseCallback<Snackbar>() {
            override fun onShown(transientBottomBar: Snackbar?) {

            }

            override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                onDismiss()
            }
        })
        messageSnackBar?.view?.setOnClickListener { _ -> messageSnackBar?.dismiss() }
        eventTrackMessage(TRACKER_TOAST, TRACKER_SUCCESS_MESSAGE, "", message)
    }

    fun showSuccessSnackBarImp(message: String, onDismiss: () -> Unit) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message,
            SHOW_EXTRA_LONG_TIME
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.green
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            textView.setTypeface(null, Typeface.BOLD)
            snackBar.setTextColor(Color.WHITE)
            snackBar.show()
        }
        messageSnackBar!!.addCallback(object : BaseTransientBottomBar.BaseCallback<Snackbar>() {
            override fun onShown(transientBottomBar: Snackbar?) {

            }

            override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                onDismiss()
            }
        })
        messageSnackBar?.view?.setOnClickListener { _ -> messageSnackBar?.dismiss() }
        eventTrackMessage(TRACKER_TOAST, TRACKER_SUCCESS_MESSAGE, "", message)
    }

    fun showErrorSnackBar(message: String, showMessageExtraLong: Boolean = false) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message,
            if (showMessageExtraLong) SHOW_EXTRA_LONG_TIME else Snackbar.LENGTH_LONG
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.red
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            snackBar.setTextColor(Color.WHITE)
            textView.setTypeface(null, Typeface.BOLD)
            snackBar.show()
        }
        eventTrackMessage(TRACKER_TOAST, TRACKER_ERROR_MESSAGE, "", message)
    }

    fun showSnackBar(message: String) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message, Snackbar.LENGTH_LONG
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.colorAccent
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            snackBar.setTextColor(Color.WHITE)
            snackBar.show()
            eventTrackMessage(TRACKER_TOAST, TRACKER_ERROR_MESSAGE, "", message)
        }
    }

    fun showErrorSnackBarStd(message: String, onDismiss: () -> Unit) {
        val activity = (activity as MainActivity)
        messageSnackBar?.dismiss()
        messageSnackBar = Snackbar.make(
            activity.binding.container, message, Snackbar.LENGTH_LONG
        )
        messageSnackBar?.let { snackBar ->
            snackBar.setBackgroundTint(
                ContextCompat.getColor(
                    requireActivity(), R.color.red
                )
            )
            val snackBarView = snackBar.view
            val textView =
                snackBarView.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView
            textView.maxLines = 3
            textView.setTypeface(null, Typeface.BOLD)
            snackBar.setTextColor(Color.WHITE)
            snackBar.show()
        }
        messageSnackBar!!.addCallback(object : BaseTransientBottomBar.BaseCallback<Snackbar>() {
            override fun onShown(transientBottomBar: Snackbar?) {

            }

            override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                onDismiss()
            }
        })
        messageSnackBar?.view?.setOnClickListener { _ -> messageSnackBar?.dismiss() }
        eventTrackMessage(TRACKER_TOAST, TRACKER_ERROR_MESSAGE, "", message)
    }

    fun hideSoftKeyBoard(context: Context, view: View) {
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun showSoftKeyBoard(context: Context, view: View) {
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
            imm!!.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    protected open fun getNavOptions(): NavOptions {
        return NavOptions.Builder().setEnterAnim(R.anim.slide_in_right)
            .setExitAnim(R.anim.slide_out_left).setPopEnterAnim(R.anim.slide_in_left)
            .setPopExitAnim(R.anim.slide_out_right).build()
    }

    protected fun isNetworkConnected(): Boolean {
        //1
        val connectivityManager =
            requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        //2
        val activeNetwork = connectivityManager.activeNetwork
        //3
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        //4
        return networkCapabilities != null && networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    protected fun showAlertDialog(
        title: String, message: String, onPositiveClick: () -> Unit, focusField: EditText
    ) {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)

        //performing positive action
        builder.setPositiveButton(getString(R.string.yes)) { _, _ ->
            onPositiveClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_YES, message)
        }
        //performing negative action
        builder.setNegativeButton(getString(R.string.no)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            requestFocusInputField(focusField) //set focus to
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_NO, message)
        }
        // Create the AlertDialog
        val alertDialog: MaterialAlertDialogBuilder = builder
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
    }

    protected fun moveToFragment(action: NavDirections) {
        getNavigationController().navigate(action, getNavOptions())
    }

    protected fun requestFocusInputField(view: EditText) {
        view.requestFocus()
        view.selectAll()
        showSoftKeyBoard(requireActivity(), view)

    }

    // When user goes back from the current fragment
    protected fun onBackFromFragment() {
        findNavController().popBackStack()
    }

    protected fun getNavigationController(): NavController {
        return findNavController()
    }

    protected fun showAlertDialog(
        title: String,
        message: String,
        positiveButton: String,
        negativeButton: String,
        alertDialogClickListener: AlertDialogClickListener
    ) {
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton(positiveButton) { dialogInterface, _ ->
            alertDialogClickListener.onPositiveButtonClick()
            dialogInterface.dismiss()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, positiveButton, message)
        }
        builder.setNegativeButton(negativeButton) { dialogInterface, _ ->
            alertDialogClickListener.onNegativeButtonClick()
            dialogInterface.dismiss()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, negativeButton, message)
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
    }

    protected fun showAlertDialog(
        message: String, positiveButton: String, alertDialogClickListener: AlertDialogClickListener
    ) {
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(message)
        builder.setPositiveButton(positiveButton) { dialogInterface, _ ->
            alertDialogClickListener.onPositiveButtonClick()
            dialogInterface.dismiss()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, positiveButton, message)
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
    }

    protected fun showAlertDialog(title: String, message: String, onPositiveClick: () -> Unit): MaterialAlertDialogBuilder {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)

        //performing positive action
        builder.setPositiveButton(getString(R.string.alert_button_ok)) { _, _ ->
            onPositiveClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_OK, message)
        }
        // Create the AlertDialog
        val alertDialog: MaterialAlertDialogBuilder = builder
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
        return alertDialog
    }

    protected fun showWarningDialog(title: String, message: String, onPositiveClick: () -> Unit) {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)

        builder.setIcon(R.drawable.alert_accent)
        //performing positive action
        builder.setPositiveButton(getString(R.string.alert_button_ok)) { _, _ ->
            onPositiveClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_WARN_MESSAGE, TRACKER_OK, message)
        }
        // Create the AlertDialog
        val alertDialog: MaterialAlertDialogBuilder = builder
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_WARN_MESSAGE, "", message)
    }


    protected fun showAlertDialog(
        title: String, message: String, onPositiveClick: () -> Unit, onNegativeClick: () -> Unit
    ) {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)

        //performing positive action
        builder.setPositiveButton(getString(R.string.alert_button_ok)) { _, _ ->
            onPositiveClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_OK, message)
        }

        //performing negative action
        builder.setNegativeButton(getString(R.string.alert_button_cancel)) { _, _ ->
            onNegativeClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_CANCEL, message)
        }
        // Create the AlertDialog
        val alertDialog: MaterialAlertDialogBuilder = builder
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
    }

    protected fun showCustomDialog(message: String, onPositiveClick: () -> Unit) {
        val dialogView = layoutInflater.inflate(R.layout.rf_custom_dialog, null)
        dialogView.findViewById<TextView>(R.id.tvMessage).text = message
        val dialog = AlertDialog.Builder(requireActivity()).setView(dialogView).create()
        dialogView.findViewById<Button>(R.id.btnOk).setOnClickListener {
            dialog.dismiss()
            onPositiveClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_OK, message)
        }
        dialog.setCancelable(false)
        dialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", message)
    }

    protected fun showKitItemDialog(kitItem: KitItem, onPositiveClick: () -> Unit) {
        val dialogView = RfKitItemDialogBinding.inflate(layoutInflater)

        dialogView.kittingItemLayoutInclude.tvKitViewButton.visibility = View.GONE
        dialogView.kittingItemLayoutInclude.tvKitItemNameValue.text = kitItem.kitItemName
        dialogView.kittingItemLayoutInclude.tvKitItemDescValue.text = kitItem.kitItemDescription

        dialogView.kittingComponentLayoutInclude.tvComponentName.typeface = Typeface.DEFAULT_BOLD
        dialogView.kittingComponentLayoutInclude.tvMinQty.typeface = Typeface.DEFAULT_BOLD

        dialogView.rvKitComponents.layoutManager = LinearLayoutManager(requireActivity())

        val dialog = AlertDialog.Builder(requireActivity()).setView(dialogView.root).create()
        dialogView.btnOk.setOnClickListener {
            eventTrackMessage(TRACKER_ALERT, TRACKER_KIT_LIST, TRACKER_OK, kitItem.kitItemName)
            dialog.dismiss()
            onPositiveClick()
        }
        dialog.setCancelable(false)
        dialog.setOnShowListener {
            val kittingComponentAdapter = KittingComponentAdapter(kitItem.kitComponents)
            dialogView.rvKitComponents.adapter = kittingComponentAdapter
        }
        dialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_KIT_LIST, "", kitItem.kitItemName)
    }

    protected fun showAlertDialogItems(
        title: String,
        message: String = "",
        positiveButton: String,
        displayItemsList: List<String>,
        onPositiveClick: (itemPosition: Int) -> Unit
    ) {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        builder.setTitle(title)
        builder.setPositiveButton(positiveButton) { dlg, _ ->
            eventTrackMessage(TRACKER_ALERT, TRACKER_ITEM_LIST, TRACKER_CLOSE, message)
            dlg.dismiss()
        }
        builder.setItems(displayItemsList.toTypedArray()) { _, position ->
            onPositiveClick(position)
            eventTrackMessage(TRACKER_ALERT, TRACKER_ITEM_LIST, TRACKER_SELECT, message)
        }
        builder.create().apply {
            setCancelable(false)
            show()
        }
        eventTrackMessage(TRACKER_ALERT, TRACKER_ITEM_LIST, "", message)
    }

    fun formatExpiryDate(expiryDate: String?): String {
        var formattedExpiryDate = ""
        if (expiryDate != null && expiryDate != "") {
            formattedExpiryDate = try {
                val myFormat1 = "yyyy-MM-dd" // mention the format you need
                val sdf1 = SimpleDateFormat(myFormat1, Locale.US)
                val getApiExpiryDate = sdf1.parse(expiryDate)
                getApiExpiryDate?.let { sdf1.format(it) }.toString()
            } catch (e: Exception) {
                expiryDate
            }
        }
        return formattedExpiryDate
    }

    fun parseExpiryDate(expiryDate: String?): String {
        var formattedExpiryDate = ""
        if (expiryDate != null && expiryDate != "") {
            if (expiryDate.contains("-")) {
                return formatExpiryDate(expiryDate)
            }
            formattedExpiryDate = try {
                val myFormat1 = "yyyyMMdd" // mention the format you need
                val sdf1 = SimpleDateFormat(myFormat1, Locale.US)
                val getApiExpiryDate = sdf1.parse(expiryDate)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(getApiExpiryDate!!)
            } catch (e: Exception) {
                expiryDate
            }
        }
        return formattedExpiryDate
    }

    fun formatDate(inputDate: String): String {
        if (inputDate.isEmpty()) return ""
        val inputFormat = SimpleDateFormat("dd-MMM-yy", Locale.US)
        val outputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return try {
            val date = inputFormat.parse(inputDate)
            outputFormat.format(date!!)
        } catch (e: ParseException) {
            e.printStackTrace()
            inputDate
        }
    }

    fun formatRecallExpirationDate(inputDate: String): String {
        if (inputDate.isEmpty())
            return ""
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outputFormat = SimpleDateFormat("dd-MM-yy", Locale.US)
        return try {
            val date = inputFormat.parse(inputDate)
            outputFormat.format(date!!)
        } catch (e: ParseException) {
            e.printStackTrace()
            inputDate
        }
    }

    protected fun showCustomDialogPFA(
        isShowStageOnly: Boolean,
        message: SpannableString,
        stageClick: () -> Unit,
        newTaskClick: () -> Unit
    ) {
        val dialogView = RfCustomDialogBinding.inflate(layoutInflater)
        dialogView.cmnLayout.visibility = View.GONE
        dialogView.pfaLayout.visibility = View.VISIBLE
        dialogView.tvMessage.text = message
        if (isShowStageOnly) {
            dialogView.txtNewTask.visibility = View.GONE
        }
        val dialog = AlertDialog.Builder(requireActivity()).setView(dialogView.root).create()
        dialogView.txtStage.setOnClickListener {
            dialog.dismiss()
            stageClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_STAGE, message.toString())
        }
        dialogView.txtNewTask.setOnClickListener {
            dialog.dismiss()
            newTaskClick()
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_NEW_TASK, message.toString())
        }
        dialog.setCancelable(false)
        dialog.show()
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE,"", message.toString())
    }

    fun setBoldSpan(text: String, list: List<String>): SpannableString {
        val spannable = SpannableString(text)
        for (data in list) {
            val startIndex = text.indexOf(data)
            val amountOfCharacters = data.length
            spannable.setSpan(
                StyleSpan(Typeface.BOLD), startIndex, // start
                startIndex + amountOfCharacters, // end
                Spannable.SPAN_EXCLUSIVE_INCLUSIVE
            )
        }
        return spannable
    }

    fun isValidDigit(str: String?): Boolean {
        if (!str.isNullOrEmpty()) {
            return str.all { Character.isDigit(it) }
        }
        return false
    }

    fun ccNavigateBackToUpdate() {
        val bundle = bundleOf(
            "update" to true
        )
        val navOptions = NavOptions.Builder().setLaunchSingleTop(true)
            .setPopUpTo(R.id.cycleCountActiveItem, true).build()
        getNavigationController().navigate(R.id.cycleCountActiveItem, bundle, navOptions)
    }

    open fun indexExists(list: List<*>, index: Int): Boolean {
        return index >= 0 && index < list.size
    }

    fun getInventoryDescription(inventoryCode: String): String {
        return if (inventoryCode == resources.getString(R.string.lbl_Mixed)) {
            resources.getString(R.string.lbl_Mixed)
        } else {
            try {
                val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                    sharedPreferencesBase.getString(
                        PreferenceKeys.INVENTORY_TYPES_HASH_MAP,
                        ""
                    ), object : TypeToken<HashMap<String?, String?>?>() {}.type
                )
                return invTypesHashMap[inventoryCode].toString()
            } catch (e: Exception) {
                e.printStackTrace()
                return ""
            }
        }
    }

    fun getInventoryHashMap(): HashMap<String, String> {
        try {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.INVENTORY_TYPES_HASH_MAP,
                    ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap
        } catch (e: Exception) {
            e.printStackTrace()
            return HashMap()
        }
    }

    fun getOrderStatus(orderStatus: String): String {
        val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
            sharedPreferencesBase.getString(
                PreferenceKeys.ORDER_STATUS_HASH_MAP, ""
            ), object : TypeToken<HashMap<String?, String?>?>() {}.type
        )
        return invTypesHashMap[orderStatus].toString()
    }

    fun getContainerStatus(containerStatus: String?): String {
        if (containerStatus != null) {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.CONTAINER_STATUS_HASH_MAP, ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap[containerStatus].toString()
        }
        return ""
    }

    fun getLocationStatus(locationStatus: String?): String {
        if (locationStatus != null) {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.LOCATION_STATUS_HASH_MAP, ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap[locationStatus].toString()
        }
        return ""
    }

    fun getLocationType(locationType: String?): String {
        if (locationType != null) {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.LOCATION_TYPE_HASH_MAP, ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap[locationType].toString()
        }
        return ""
    }

    fun getLocationClass(locationClass: String?): String {
        if (locationClass != null) {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.LOCATION_CLASS_HASH_MAP, ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap[locationClass].toString()
        }
        return ""
    }

    fun getLockCodeDescription(lockCode: String?): String {
        if (lockCode != null) {
            val invTypesHashMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.LOCK_CODES_HASH_MAP, ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            return invTypesHashMap[lockCode].toString()
        }
        return ""
    }

    fun getLockCodesHashMap(): HashMap<String, String> {
        return try {
            val lockCodesMap: HashMap<String, String> = Gson().fromJson(
                sharedPreferencesBase.getString(
                    PreferenceKeys.LOCK_CODES_HASH_MAP,
                    ""
                ), object : TypeToken<HashMap<String?, String?>?>() {}.type
            )
            lockCodesMap
        } catch (e: Exception) {
            hashMapOf()
        }
    }

    fun showScannedMultiItemsListDialog(
        scannedList: List<String>,
        title: String,
        finalList: (List<String>) -> Unit,
        onDismissDialog: () -> Unit = {}
    ) {
        val checkedContainers = ArrayList<String>()
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        builder.setTitle(title)
        builder.setMultiChoiceItems(scannedList.toTypedArray(), null) { dialog, which, isChecked ->
            if (isChecked) {
                checkedContainers.add(scannedList[which])
            } else {
                checkedContainers.remove(scannedList[which])
            }
            (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled =
                checkedContainers.size > 0
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha =
                if (checkedContainers.size > 0) 1f else 0.35f
            eventTrackMessage(
                TRACKER_ALERT,
                TRACKER_CUSTOM_MESSAGE,
                TRACKER_SELECT,
                scannedList[which]
            )
        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            finalList(scannedList.filter { it !in checkedContainers } as ArrayList<String>)
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_DELETE, title)
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel)) { _, _ ->
            eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, TRACKER_CANCEL, title)
        }
        val dialog = builder.create()
        dialog.setOnDismissListener { onDismissDialog() }
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedContainers.size > 0
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha =
            if (checkedContainers.size > 0) 1f else 0.35f
        eventTrackMessage(TRACKER_ALERT, TRACKER_CUSTOM_MESSAGE, "", title)
    }

    fun showSingleItemChoiceDialog(title: String, listOfItems: Array<String>, itemSelect: (selectValue : String) -> Unit) {
        MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme).apply {
            setTitle(title)
            setSingleChoiceItems(listOfItems, -1) { dialogInterface, pos ->
                itemSelect(listOfItems[pos])
                dialogInterface.dismiss()
                eventTrackMessage(TRACKER_ALERT, TRACKER_MESSAGE, TRACKER_SELECT, listOfItems[pos])
            }
            setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
                eventTrackMessage(TRACKER_ALERT, TRACKER_MESSAGE, TRACKER_CANCEL, title)
                dialog.cancel()
            }
            create().apply {
                setCancelable(false)
                show()
            }
        }
        eventTrackMessage(TRACKER_ALERT, TRACKER_MESSAGE, "", title)
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.main_menu, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        sendTrackerDataToServer()
        return when (menuItem.itemId) {
            R.id.home -> {
                getNavigationController().navigate(
                    R.id.homeFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.homeFragment, true).build()
                )
                return true
            }

            R.id.account -> {
                getNavigationController().navigate(
                    R.id.accountFragment,
                    null,
                    NavOptions.Builder().setPopUpTo(R.id.accountFragment, true).build()
                )
                return true
            }

            else -> {
                false
            }
        }
    }

    override fun onScan(scan: Scan?) {
        isScanned = true
        updateTracker(
            scan?.barcode!!, scan.barcode, TRACKER_SCAN, Date(), "", scan.barcode
        )
    }

    override fun onScanError(scanRaw: String?, ex: java.lang.Exception?) {

    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            customVisibilityCallback = it
            it.onVisibilityChange(true)
        }
    }

    override fun isCustomVisible(): Boolean {
        return true
    }

    fun isProgressBarVisible(): Boolean {
        var progressBar = false
        try {
            val progressBarView = view?.findViewById<View>(R.id.progressBar)
            progressBar = progressBarView!!.isShown
        } catch (_: Exception) {
        }

        return progressBar
    }

    protected fun showInfoAlertWithIcon(
        title: String? = null,
        message: String,
        buttonTitle: String = getString(R.string.alert_button_ok),
        @DrawableRes icon: Int? = R.drawable.ic_exclamation,
        onDismiss: () -> Unit
    ) {
        val binding = RfContentCenterDialogBinding.inflate(layoutInflater).apply {
            title?.let {
                tvTitle.visibility = View.VISIBLE
                tvTitle.text = it
            }
            tvMessage.text = message
            icon?.let { ivIcon.setImageResource(it) }
            btnOk.apply { text = buttonTitle }
        }

        val dialog = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme).apply {
            setView(binding.root)
            setCancelable(false)
        }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }

        binding.btnOk.setOnClickListener {
            dialog.dismiss()
            onDismiss.invoke()
            eventTrackMessage(TRACKER_ALERT, TRACKER_INFO_MESSAGE, TRACKER_OK, message)
        }
        eventTrackMessage(TRACKER_ALERT, TRACKER_INFO_MESSAGE, "", message)
    }

    /**
     * Function to set view visibility
     */
    fun setViewVisibility(value: String?, vararg views: View) {
        val visibility = if (value.isNullOrEmpty()) View.GONE else View.VISIBLE
        views.forEach { it.visibility = visibility }
    }

    override fun onClick(v: View?) {
        var elementName = ""
        if (v is TextView) elementName = v.text.toString()
        updateTracker(
            TRACKER_BUTTON,
            elementName,
            TRACKER_CLICK,
            Date(),
            focusedEditText?.hint?.toString() ?: "",
            focusedEditText?.text?.toString() ?: ""
        )
    }

    override fun onCheckedChanged(group: RadioGroup?, checkedId: Int) {
        val elementName = (group?.findViewById<RadioButton>(checkedId))?.text.toString()
        updateTracker(
            TRACKER_RADIOBUTTON,
            elementName,
            TRACKER_SELECT,
            Date(),
            elementName,
            TRACKER_CHECKED
        )
    }

    override fun onFocusChange(v: View?, hasFocus: Boolean) {
        if (v is EditText) focusedEditText = v
        val fieldName = focusedEditText?.hint.toString()
        val elementName = focusedEditText?.text.toString()

        updateTracker(TRACKER_TEXT_FIELD, fieldName, TRACKER_FOCUS, Date(), fieldName, elementName)
    }

    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        updateTracker(
            TRACKER_SCREEN,
            "",
            TRACKER_CLICK,
            Date(),
            focusedEditText?.hint?.toString() ?: "",
            focusedEditText?.text?.toString() ?: ""
        )
        return v?.onTouchEvent(event) ?: false
    }

    override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean {
        if (v is EditText) {
            val elementName = v.text.toString()
            val fieldName = v.hint.toString()
            updateTracker(
                TRACKER_TEXT_FIELD,
                fieldName,
                TRACKER_SUBMIT,
                Date(),
                fieldName,
                elementName
            )
        }
        return false
    }

    override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        // Check if the view is not null and is an instance of MaterialAutoCompleteTextView
        if (view is MaterialAutoCompleteTextView) {
            val elementName = view.text.toString()  // Get the selected item's text
            val fieldName = view.hint.toString()     // Get the hint text

            // Call your updateTracker method with the retrieved values
            updateTracker(TRACKER_DROPDOWN, fieldName, TRACKER_SUBMIT, Date(), fieldName, elementName)
        } else {
            // Handle cases where the view is not of expected type
            FlareLog.e("CooFragment", "Clicked view is not a MaterialAutoCompleteTextView")
        }
    }

    fun spinnerSelected(fieldName: String, fieldValue: String) {
        updateTracker(TRACKER_DROPDOWN, fieldName, TRACKER_SUBMIT, Date(), fieldName, fieldValue)
    }

    private fun updateTracker(
        objType: String,
        objName: String,
        objAction: String,
        startDate: Date,
        fieldName: String,
        fieldValue: String
    ) {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            trackerInstance.setTransactionModel(
                FSCTransactionDetailModel(
                    seqNo = trackerInstance.mainSeqNo,
                    screenName = screenName,
                    objType = objType,
                    objName = objName,
                    objAction = objAction,
                    eventTimeStamp = startDate.getUTCServerTimeStamp(),
                    labelName = fieldName,
                    labelValue = fieldValue,
                    labelInputType = if (isScanned) TRACKER_SCANNER else TRACKER_MANUAL
                )
            )
            trackerInstance.mainSeqNo += 1
            isScanned = false
        }
    }

    fun trackCustomValue(fieldName: String, fieldValue: String) {
        updateTracker(TRACKER_TEXTVIEW, fieldName, TRACKER_DISPLAY, Date(), fieldName, fieldValue)
    }

    open fun trackErrorMessage(message: String) {
        eventTrackMessage(TRACKER_ALERT, TRACKER_ERROR_MESSAGE, "", message)
    }

    fun sendTrackerDataToServer() {
        (activity as MainActivity).startTransactionManager()
    }

    fun showAlertDialog(title: String, items:Array<String>,positiveButton:String) {
        MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
            .setTitle(title)
            .setItems(items, null)
            .setPositiveButton(positiveButton) { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    fun showAlertDialog(
        title: String, message: String, positiveButton:String, onPositiveClick: (alertDialog: DialogInterface) -> Unit, negativeButton:String, onNegativeClick: (alertDialog: DialogInterface) -> Unit
    ) {
        // show dialog
        val builder = MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)

        //performing positive action
        builder.setPositiveButton(positiveButton) { dialog, _ ->
            onPositiveClick(dialog)
        }

        //performing negative action
        builder.setNegativeButton(negativeButton) { dialog, _ ->
            onNegativeClick(dialog)
        }
        // Create the AlertDialog
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    fun showAlertDialog(title: String, items:Array<String>,positiveButton:String,onPositiveClick: (alertDialog: DialogInterface) -> Unit) {
        MaterialAlertDialogBuilder(requireActivity(), R.style.AlertDialogTheme)
            .setTitle(title)
            .setItems(items, null)
            .setPositiveButton(positiveButton) { dialog, _ ->
                onPositiveClick(dialog)
            }
            .setCancelable(false)
            .show()
    }
}