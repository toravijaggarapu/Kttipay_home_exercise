package com.fsc.flare.ui.fragment.inventory.containertoactive

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCtaLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerLocationRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = CTALocationFragment::class.java.simpleName.toString()

/**
 * A simple [CTALocationFragment] class.
 */
@AndroidEntryPoint
class CTALocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: CTAViewModel by activityViewModels()
    private lateinit var binding: FragmentCtaLocationBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onPause() {
        super.onPause()
        binding.etLocation.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etLocation)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCtaLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvInventoryTransfer.text =
            sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        setUpViews()
        return binding.root
    }

    private fun setUpViews() {
        val ctaContainerData = viewModel.fetchCtaContainerResponse()
        ctaContainerData?.let {
            binding.tvContainerValue.text = it.containerNbr
            binding.tvInventoryTypeValue.text = it.inventoryType
            binding.tvItemCodeValue.text = it.itemCode
            binding.tvItemDescriptionValue.text = it.description
            binding.tvQuantityValue.text = it.scanQty.toString()
            binding.tvFromLocationValue.text = it.fromLocationBarcode
            binding.tvToLocationValue.text = it.toLocationBarcode
            if(!ctaContainerData.hazardClassIMDG.isNullOrEmpty()){
                binding.itemClassCodeTv.visibility = View.VISIBLE
                binding.itemClassCode.visibility = View.VISIBLE
                binding.division.visibility = View.VISIBLE
                binding.itemClassCode.text = ctaContainerData.hazardClassIMDG.plus(" /")
                binding.division.text = ctaContainerData.hazmatDivisionText
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etLocation.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        validateLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etLocation)
                FlareLog.i(TAG, "Container field focused")
                if (binding.etLocation.isFocused && !binding.etLocation.text.isNullOrEmpty()) {
                    validateLocation()
                }
            }
            false
        }

        binding.etLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvLocationResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    private fun validateLocation() {
        viewModel.getLocationInfo(binding.etLocation.text.toString())
    }

    private fun subscribeObservers() {
        viewModel.getCTALocationResponse().observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { ctaLocationResponse ->
                        showSuccessSnackBarStd(ctaLocationResponse.message) {
                            val action =
                                CTALocationFragmentDirections.actionCtaLocationFragmentToCtaContainerFragment()
                            getNavigationController().navigate(action)
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "inventoryTransferLocation Error: $message")
                        binding.tvLocationResponse.text = message
                        binding.etLocation.requestFocus()
                        binding.etLocation.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etLocation)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.getLocationResponse().observe(viewLifecycleOwner) { locationInquiryResponse ->
            when (locationInquiryResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    locationInquiryResponse.data?.let { locationResponse ->
                        val ctaContainerData = viewModel.fetchCtaContainerResponse()
                        if (ctaContainerData != null) {
                            viewModel.inventoryTransferContainerLocation(
                                InventoryTransferContainerLocationRequest(
                                    custId = ctaContainerData.custId,
                                    fcyId = ctaContainerData.fcyId,
                                    buId = ctaContainerData.buId,
                                    itemCode = ctaContainerData.itemCode,
                                    description = ctaContainerData.description,
                                    containerNbr = ctaContainerData.containerNbr,
                                    scanQty = ctaContainerData.scanQty,
                                    fromLocationBarcode = ctaContainerData.fromLocationBarcode,
                                    toLocationBarcode = binding.etLocation.text.toString(),
                                    inventoryType = ctaContainerData.inventoryType,
                                    toLocationId = locationResponse.location?.locationId!!,
                                    itemId = ctaContainerData.itemId,
                                    userEnteredLocationBarcode = binding.etLocation.text.toString(),
                                    userEnteredLocationId = null,
                                    zoneGroupId = null,
                                    includeCCLocation = if (sharedPreferences.getBoolean(
                                            PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,
                                            false
                                        )
                                    ) "Y" else "N"
                                )
                            )
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    locationInquiryResponse.message?.let { message ->
                        binding.tvLocationResponse.text = message
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etLocation.setText(scan?.barcode.toString())
        binding.etLocation.text?.length?.let {
            binding.etLocation.setSelection(it)
            FlareLog.i(TAG, "Location field focused")
            validateLocation()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}