package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementTaskdetailsToteBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.ACTION_TYE_COMPLETE_PICK
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.ACTION_TYPE_FETCH
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.ACTION_TYPE_GET
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_GROUP_TNR
import com.fsc.flare.utils.Constants.PartsReplacement.Companion.TASK_TYPE_REPAIR
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementToteFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementToteFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var partsReplacementToteBinding: FragmentPartsReplacementTaskdetailsToteBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>
    var isNextTask : Boolean = false


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        setVisibilityButton(false)
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementToteBinding =
            FragmentPartsReplacementTaskdetailsToteBinding.inflate(inflater, container, false)
        partsReplacementToteBinding.lifecycleOwner = this
        return partsReplacementToteBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        with(partsReplacementToteBinding) {
            tvTaskIdValue.text = taskDetails.get(0).taskId
            tvSourceLocationValue.text = taskDetails.get(0).sourceLocation
        }
        addListeners()
        setClickListeners()
        subscribeObservers()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {

        partsReplacementToteBinding.etToteValue.doAfterTextChanged {
            partsReplacementToteBinding.errResponses.text = null
        }

        partsReplacementToteBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(
                        fragmentContext,
                        partsReplacementToteBinding.etToteValue
                    )
                    if (partsReplacementToteBinding.etToteValue.isFocused) {
                        updateToteNumber()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementToteBinding.etToteValue.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(
                    fragmentContext,
                    partsReplacementToteBinding.etToteValue
                )
                updateToteNumber()
            }
            false
        }
    }

    private fun setClickListeners() {
        partsReplacementToteBinding.btnNextTask.setOnClickListener {
            isNextTask = true
            onNextTaskPick()
        }
        partsReplacementToteBinding.btnCompleteTask.setOnClickListener {
            isNextTask = false
            onCompleteTask()
        }
    }

    private fun onNextTaskPick() {
            getRepairTaskRf()
    }
    private fun onCompleteTask() {
        completeTask()
    }

    @SuppressLint("SuspiciousIndentation")
    private fun updateToteNumber() {
        val etToteValue =
            partsReplacementToteBinding.etToteValue.text.toString().trim()
        if (etToteValue.isNotEmpty()) {
            partsReplacementToteBinding.etToteValue.text = null

            task.firstOrNull()?.let {
                viewModel.updateMoveTaskDetailsRf(
                    UpdateMoveTaskDetailsRequest(
                        taskId = it.taskId,
                        taskType = TASK_TYPE_REPAIR,
                        actionType = ACTION_TYE_COMPLETE_PICK,
                        toteNumber = etToteValue,
                        toteId = taskDetails.get(0).refContainerId,
                        partRunnerCart = it.partRunnerCart,
                        partRunnerCartId = it.partRunnerCartId?.toIntOrNull() ?: 0
                    )
                )
            }
        }
    }

    private fun getRepairTaskRf() {
            viewModel.getRepairTaskRf(
                GetRepairTaskRf(
                    partRunnerCart = task.get(0).partRunnerCart,
                    taskType = TASK_TYPE_REPAIR,
                    taskgroup = TASK_GROUP_TNR,
                    actionType = ACTION_TYPE_GET
                )
            )
    }

    private fun completeTask() {
        viewModel.getRepairTaskRf(
            GetRepairTaskRf(
                partRunnerCart = task.get(0).partRunnerCart,
                taskType = TASK_TYPE_REPAIR,
                taskgroup = TASK_GROUP_TNR,
                actionType = ACTION_TYPE_FETCH
            )
        )
    }


    private fun subscribeObservers() {
        viewModel.updateMoveTaskDetailsRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { updateTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(updateTaskRfResponse)
                        FlareLog.e(
                            TAG,
                            "getMoveTaskRfResponse : ${updateTaskRfResponse.toString()}"
                        )
                        setVisibilityButton(true)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "PartsReplacement UpdateMoveTask error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.getRepairTaskRfResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { getRepairTaskRfResponse ->
                        viewModel.setMoveTaskRfResponse(getRepairTaskRfResponse)
                        FlareLog.e(
                            TAG,
                            "getMoveTaskRfResponse  tote fragment: ${getRepairTaskRfResponse.toString()}"
                        )
                        FlareLog.e(
                            TAG,
                            "getMoveTaskRfResponse  isNextTask: ${isNextTask}"
                        )
                        if(isNextTask){
                            FlareLog.e(
                                TAG,
                                "inside true  isNextTask: ${isNextTask}")
                            navigateToPartsReplacementSourceLocationFragment()
                        }
                        else {
                            navigateToPartsReplacementDeviceHoldTaskIDFragment()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        var msg = message
                        if (message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                msg = msgArray[1]
                            }
                        }
                        FlareLog.e(TAG, "PartsReplacement getRepair error: $msg")
                        displayErrorMessage(msg)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun setVisibilityButton(visible: Boolean) {
        if (visible) {
            partsReplacementToteBinding.btnNextTask.visibility = View.VISIBLE
            partsReplacementToteBinding.btnCompleteTask.visibility = View.VISIBLE
        } else {
            partsReplacementToteBinding.btnNextTask.visibility = View.INVISIBLE
            partsReplacementToteBinding.btnCompleteTask.visibility = View.INVISIBLE
        }
    }

    private fun hideProgressBar() {
        partsReplacementToteBinding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        partsReplacementToteBinding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementToteBinding.etToteValue.setText(scan?.barcode.toString())
        partsReplacementToteBinding.etToteValue.text?.length?.let {
            partsReplacementToteBinding.etToteValue.setSelection(it)
        }
        updateToteNumber()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementToteBinding.errResponses.text = errorMessage
        partsReplacementToteBinding.etToteValue.requestFocus()
        partsReplacementToteBinding.etToteValue.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementToteBinding.etToteValue)
    }

    private fun navigateToPartsReplacementDeviceHoldTaskIDFragment() {
        val action =
            PartsReplacementToteFragmentDirections.actionPartsReplacementToteFragmentToPartsReplacementDeviceHoldTaskIDFragment()
        findNavController().navigate(action)
    }

    private fun navigateToPartsReplacementSourceLocationFragment() {
        val action =
            PartsReplacementToteFragmentDirections.actionPartsReplacementToteFragmentToPartsReplacementSourceLocationFragment()
        findNavController().navigate(action)
    }
}