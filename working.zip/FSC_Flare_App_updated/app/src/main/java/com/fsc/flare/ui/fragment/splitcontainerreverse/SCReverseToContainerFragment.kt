package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentSCReverseToContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitPutawayDetails
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "SCReverseToContainerFragment"
@AndroidEntryPoint
class SCReverseToContainerFragment : BaseFragment(), FlareScannable {

    private val viewModel: SplitContainerReverseViewModel by activityViewModels()
    private lateinit var binding: FragmentSCReverseToContainerBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSCReverseToContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //set container number
        binding.tvContainerNumberValue.text = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null)
        //set SKU for reverse/ Item barcode for Forward
        if (sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString() == "R") {
            binding.wgSku.visibility = View.VISIBLE
            binding.wgItemBarcode.visibility = View.GONE
            binding.tvSKUValue.text = sharedPreferences.getString(PreferenceKeys.SC_SKU_ITEMBARCODE, null)
        } else if (sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString() == "F") {
            binding.wgSku.visibility = View.GONE
            binding.wgItemBarcode.visibility = View.VISIBLE
            binding.tvItemBarcodeValue.text = sharedPreferences.getString(PreferenceKeys.SC_SKU_ITEMBARCODE, null)
        }
        //set qty
        binding.tvQtyValue.text = sharedPreferences.getInt(PreferenceKeys.SC_QTY, -1).toString()


        binding.etToContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.txtToContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etToContainer.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.etToContainer.isFocused && !binding.etToContainer.text.isNullOrEmpty()) {
            FlareLog.i(TAG,"ToContainer field focused")
            validateSubmitSplitContainerAPI()
        }
    }


    /**
     * method to call submit split container API
     */
    private fun validateSubmitSplitContainerAPI() {
        viewModel.validateSubmitSplitContainer(
            SplitContSubmitRequest(
                dataSource = "RF",
                putaway = SplitContSubmitPutawayDetails(
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                    whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    usrId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                    source = sharedPreferences.getString(PreferenceKeys.SC_FROM_CONT, null).toString(),
                    qty = sharedPreferences.getInt(PreferenceKeys.SC_QTY, -1),
                    channel = sharedPreferences.getString(PreferenceKeys.SC_CHANNEL_TYPE, null).toString(),
                    sku = sharedPreferences.getString(PreferenceKeys.SC_SKU_ITEMBARCODE, null).toString(),
                    destination = binding.etToContainer.text.toString()
                )

            )
        )
    }


    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSubmitContainerObserver()
    }


    /**
     * method for submit split container observer
     */
    private fun subscribeSubmitContainerObserver() {
        viewModel.submitConResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { submitSplitConRes ->
                        FlareLog.i(TAG, "SubmitSplitCont response: $response")
                        when (submitSplitConRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(TAG, "SubmitSplitCont response Error: ${submitSplitConRes.statusHandler.error}")
                                showErrorSnackBar(submitSplitConRes.statusHandler.message)
                            }
                            "200" -> {
                                FlareLog.i(TAG, "SubmitSplitCont response Success: $submitSplitConRes")
                                showSuccessSnackBarStd(submitSplitConRes.statusHandler.message) {
                                    val action = SCReverseToContainerFragmentDirections.actionSCReverseToContainerToSCReverseFromContainerFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.SCReverseFromContainerFragment, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                }
                            }
                            else ->
                                FlareLog.e(TAG, "SubmitSplitCont response error: ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "SubmitSplitCont response error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }




    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG,"onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etToContainer.setText(scan?.barcode.toString())
                binding.etToContainer.text?.length?.let {
                    binding.etToContainer.setSelection(
                        it
                    )
                    FlareLog.i(TAG,"ToContainer field focused")
                    validateSubmitSplitContainerAPI()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.i(TAG, "onScanError: $scanRaw")
    }

}