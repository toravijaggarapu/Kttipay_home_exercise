package com.fsc.flare.utils

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.PopupWindow
import androidx.appcompat.widget.AppCompatTextView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class DropDown : AppCompatTextView, View.OnClickListener {

    private var options = mutableListOf<String>()
    private val updated: MutableLiveData<String> = SingleLiveEvent()

    val boolFoo: LiveData<String>
        get() = updated

    constructor(context: Context) : super(context) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        initView()
    }

    private fun initView() {
        this.setOnClickListener(this)
    }

    private fun popupWindowSort(context: Context): PopupWindow {
        // initialize a pop up window type

        val popupWindow = PopupWindow(context)
        popupWindow.setBackgroundDrawable(ColorDrawable(Color.parseColor("#FFFFFF")))
        popupWindow.width = this.width

        val adapter = ArrayAdapter(
            context, android.R.layout.simple_list_item_1,
            options
        )

        // the drop down list is a list view
        val listViewSort = ListView(context)

        // set our adapter and pass our pop up window contents
        listViewSort.adapter = adapter

        // set on item selected
        listViewSort.onItemClickListener =
            AdapterView.OnItemClickListener { _: AdapterView<*>?, _: View?, position: Int, _: Long ->
                this.text = options[position]
                updated.value = options[position]
                popupWindow.dismiss()
            }
        // some other visual settings for popup window
        popupWindow.isFocusable = true
        // popupWindow.setBackgroundDrawable(getResources().getDrawable(R.drawable.white));
        popupWindow.height = WindowManager.LayoutParams.WRAP_CONTENT
        popupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        popupWindow.inputMethodMode = PopupWindow.INPUT_METHOD_NEEDED
        popupWindow.showAtLocation(listViewSort, Gravity.TOP, 0, 0)
        // set the listview as popup content
        popupWindow.contentView = listViewSort

        return popupWindow
    }

    override fun onClick(v: View) {
        if (v === this) {
            val window = popupWindowSort(v.getContext())
            window.inputMethodMode = v.getOverScrollMode()
            window.showAsDropDown(v, -5, 0)
        }
    }

    fun setOptions(options: List<String>?) {
        this.options.clear()
        options?.let {
            this.options.addAll(options)
        }
    }

    fun setSelectedValue(mySelectedVal: String?) {
        this.text = mySelectedVal
        updated.value = mySelectedVal.orEmpty()
    }
}
