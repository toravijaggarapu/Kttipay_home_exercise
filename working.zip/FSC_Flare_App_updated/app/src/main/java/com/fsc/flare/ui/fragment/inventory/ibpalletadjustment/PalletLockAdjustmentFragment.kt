package com.fsc.flare.ui.fragment.inventory.ibpalletadjustment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletLockAdjustmentBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.ui.fragment.inventory.InventoryViewModel
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletLockAdjustmentFragment"

/**
 * A simple [PalletLockAdjustmentFragment] class.
 */
@AndroidEntryPoint
class PalletLockAdjustmentFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InventoryViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletLockAdjustmentBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletLockAdjustmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvPalletAdjustment.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    private fun checkPalletFieldValidation(){
        if (!binding.edtPallet.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "IB Pallet Adjustment field focused")
            binding.edtPallet.clearFocus()
            getPalletDetail()
        }
    }

    private fun getPalletDetail(){
        viewModel.getPalletDetail(binding.edtPallet.text.toString())
    }

    private fun subscribeObservers() {
        //Transaction param API response.
        viewModel.transactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (transactionParamResponse.noOfCases != null && transactionParamResponse.noOfCases.isNotEmpty()) {
                                navigateDetailPage(transactionParamResponse.noOfCases[0].transValDesc.equals(Constants.ReceivingPalletFromScreen.ITEM_ATTRIBUTES_REQUIRED, ignoreCase = true))
                            } else {
                                navigateDetailPage(false)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        navigateDetailPage(false)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //Get Pallet detail response.
        viewModel.palletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { palletResponse ->
                        //Set the Container list.
                        viewModel.setContainerList(palletResponse.containers)

                        if(palletResponse.containers.isNotEmpty()){
                            for (palletObject in palletResponse.containers) {
                                if(palletObject.containerType.equals("P", true)){
                                    viewModel.setPalletDetail(palletObject)
                                    break
                                }
                            }
                            //Call transaction param API.
                            callTransactionParamConfigAPI()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.edtPallet.requestFocus()
                        binding.palletResponse.text = message
                        binding.edtPallet.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.edtPallet)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.edtPallet)
                    checkPalletFieldValidation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()

        binding.edtPallet.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.palletResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.edtPallet.setText(scan?.barcode.toString())
            binding.edtPallet.text?.length?.let {
                binding.edtPallet.setSelection(it)
            }
            FlareLog.i(TAG, "Pallet field focused")
            checkPalletFieldValidation()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    private fun callTransactionParamConfigAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "IA"
            )
        )
    }

    private fun navigateDetailPage(rfTransactionParam:Boolean){
        //Save the config. value to viewModel.
        viewModel.showItemAttributes(rfTransactionParam)
        //Navigate to the Detail page.
        val action = PalletLockAdjustmentFragmentDirections.actionPalletLockAdjustmentFragmentToPalletLockAdjustmentDetailFragment()
        getNavigationController().navigate(action)
    }

}

