package com.fsc.flare.transactiontracker.dto

data class FSCTrackerResponse (
    val eventMasterId: Int = 0,
    val requestIdentifier: String,
    val success: Boolean
)