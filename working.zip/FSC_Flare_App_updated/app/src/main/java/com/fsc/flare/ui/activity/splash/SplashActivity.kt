package com.fsc.flare.ui.activity.splash

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.fsc.flare.BuildConfig
import com.fsc.flare.R
import com.fsc.flare.databinding.ActivitySplashBinding
import com.fsc.flare.di.AndroidId
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.login.Token
import com.fsc.flare.ui.activity.authentication.AuthenticationActivity
import com.fsc.flare.ui.activity.authentication.AuthenticationFailureDialogFragment
import com.fsc.flare.ui.activity.main.MainActivity
import com.fsc.flare.utils.AuthFailure
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.serializable
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private const val TAG = "SplashActivity"

@AndroidEntryPoint
class SplashActivity : AppCompatActivity(),
    AuthenticationFailureDialogFragment.AuthenticationFailureListener {

    companion object {
        const val EXTRA_LOGGING_OUT = "com.fsc.flare.authenticate.logging_out"
        const val ACTION_REAUTHENTICATE = "com.fsc.flare.authenticate.reauthenticate"
    }

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    @AndroidId
    lateinit var androidId: String

    private val fTagAuthFailure = "Auth_Failure"
    private val viewModel: SplashViewModel by viewModels()
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)
        binding.loginButton.setOnClickListener { openAuthenticationForResult(isTempUser = false) }
        binding.tempUserLoginButton.setOnClickListener { openAuthenticationForResult(isTempUser = true) }
        attachViewModel(savedInstanceState)
        subscribeObservers()
        showBuildDetails()
    }

    private fun openAuthenticationForResult(isTempUser: Boolean = false) {
        sharedPreferences.edit().putBoolean(PreferenceKeys.ISTEMP_USER, isTempUser).apply()
        val intent = Intent(this, AuthenticationActivity::class.java)
        intent.putExtra(AuthenticationActivity.EXTRA_REAUTHENTICATING, false)
        authenticationStartForResult.launch(intent)
    }

    private fun attachViewModel(savedInstanceState: Bundle?) {
        if (savedInstanceState == null || lastNonConfigurationInstance == null) {
            viewModel.initialize(intent)
        }
    }

    private fun showBuildDetails() {
        binding.splashAppVersion.text = BuildConfig.VERSION_NAME
        binding.splashServerLevel.text = BuildConfig.BASE_URL
        binding.splashDeviceId.text = androidId

        FlareLog.i(
            "App Details",
            "App Version: " + BuildConfig.VERSION_NAME + "Server URL" + BuildConfig.BASE_URL
                    + "Device ID" + androidId
        )
    }

    private fun subscribeObservers() {

        viewModel.finishReAuthentication.observe(this) {
            val intent = Intent()
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        viewModel.logoutToast.observe(this) {
            Toast.makeText(this, getString(R.string.toast_logout), Toast.LENGTH_SHORT).show()
        }

        viewModel.showReAuthenticateMessage.observe(this) {
            binding.messageLoginExpiredTextView.visibility = View.VISIBLE
        }

        viewModel.navigateToHome.observe(this) {
            if (it) {
                val intent = Intent(this, MainActivity::class.java)
                val options =
                    ActivityOptions.makeCustomAnimation(this, R.anim.fade_in, R.anim.fade_out)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent, options.toBundle())
                finish()
            }
        }

        viewModel.showLoginCriticalErrorMessage.observe(this) { showDelayedLoginCriticalError() }
        viewModel.showLoginIdMismatch.observe(this) { showLoginIdMismatch(viewModel.userIdScanned, viewModel.userIdInToken) }
    }

    private fun showDelayedLoginCriticalError() {
        Log.i(
            TAG,
            "Delayed Login Critical Error Dialog: " + getString(R.string.login_critical_error_message)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.login_critical_error_title)
            .setMessage(R.string.login_critical_error_message)
            .setIcon(R.drawable.alert_accent)
            .setPositiveButton(android.R.string.ok) { _: DialogInterface?, _: Int ->
                Log.i(TAG, "Login Critical Error Dialog: Clicked OK")
                handleAuthFailureAcknowledged()
            }
            .create()
            .show()
    }

    private fun handleAuthFailureAcknowledged() {
        showReAuthenticationCancelledToast()
        finishWithFailure()
    }

    private fun showReAuthenticationCancelledToast() {
        Toast.makeText(this, R.string.login_canceled, Toast.LENGTH_SHORT).show()
    }

    private val authenticationStartForResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            when(result.resultCode) {
                RESULT_OK -> {
                    result.data?.serializable<Token>(AuthenticationActivity.EXTRA_TOKEN)?.let {
                        viewModel.handleTokenRequestResult(it)
                    }
                }

                AuthenticationActivity.RESULT_AUTHENTICATION_FAILURE -> {
                    handleAuthFailure(result.data?.getStringExtra(AuthenticationActivity.EXTRA_AUTH_FAILURE))
                }
            }
        }


    private fun handleAuthFailure(@AuthFailure authFailure: String?) {
        showAuthFailure(authFailure)
    }

    private fun showAuthFailure(@AuthFailure authFailure: String?) {
        AuthenticationFailureDialogFragment.newInstance(authFailure).showNow(supportFragmentManager, fTagAuthFailure)
    }

    override fun onAuthFailureAcknowledged() {
        Log.d(TAG, "Auth failure during attempt to reauthenticate.")
        Toast.makeText(this, R.string.login_canceled, Toast.LENGTH_SHORT).show()
    }

    override fun finishWithFailure() {
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun showLoginIdMismatch(expectedId: String?, actualId: String?) {
        Log.i(
            TAG,
            "Delayed Login ID Mismatch Dialog: " + getString(
                R.string.login_id_mismatch_message,
                expectedId,
                actualId
            )
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.login_id_mismatch_title)
            .setMessage(getString(R.string.login_id_mismatch_message, expectedId, actualId))
            .setIcon(R.drawable.alert_accent)
            .setPositiveButton(android.R.string.ok) { _: DialogInterface?, _: Int ->
                Log.i(TAG, "Login ID Mismatch Dialog: Clicked OK")
                handleAuthFailureAcknowledged()
            }
            .create()
            .show()
    }
}