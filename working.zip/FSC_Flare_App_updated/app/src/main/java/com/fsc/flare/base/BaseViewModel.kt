package com.fsc.flare.base

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.fsc.flare.source.data.dto.ForwardErrorResponse
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.utils.Constants.Companion.COMMON_ERROR_MESSAGE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.GsonBuilder
import okhttp3.ResponseBody
import retrofit2.Response

abstract class BaseViewModel() : ViewModel() {
    val TAG = this::class.java.simpleName

    fun getManufacturingDate(validateLotNumberResponse: LiveData<Resource<ValidateLotNumberResponse>>): String {
        if (validateLotNumberResponse.value == null || validateLotNumberResponse.value?.data == null || validateLotNumberResponse.value?.data?.batchDetail.isNullOrEmpty()) {
            return ""
        }
        return if (validateLotNumberResponse.value!!.data!!.batchDetail?.get(0)?.manufacturingDate.isNullOrEmpty()) "" else validateLotNumberResponse.value!!.data!!.batchDetail?.get(
            0
        )?.manufacturingDate.toString()
    }

    fun handleResponseError(errorBody: ResponseBody?, message: String): String {
        val gson = GsonBuilder().create()
        return try {
            val error = gson.fromJson(errorBody?.charStream(), ForwardErrorResponse::class.java)
            error?.message ?: error.errors.errorMessage
        } catch (e: Exception) {
            message
        }
    }

    /**
     * method to handle forward error response
     */
    fun handleForwardErrorResponse(errorBody: ResponseBody?, message: String): String {
        val gson = GsonBuilder().create()
        return try {
            val error = gson.fromJson(errorBody?.charStream(), ForwardErrorResponse::class.java)
            if (error?.errors?.errorMessage != null) {
                error.errors.errorMessage
            } else {
                message
            }
        } catch (e: Exception) {
            e.printStackTrace()
            message
        }
    }

    fun handleForwardErrorResponse(
        errorCode: Int,
        errorBody: ResponseBody?,
        message: String
    ): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create()
                    .fromJson(errorBody?.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors?.errorMessage != null) {
                    error.errors.errorMessage
                } else {
                    validateErrorMessage(message)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                validateErrorMessage(message)
            }
        } else {
            validateErrorMessage(message)
        }
    }

    fun handleForwardErrorResponseErrorCode(
        errorCode: Int,
        errorBody: ResponseBody?,
        message: String
    ): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create()
                    .fromJson(errorBody!!.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors?.exceptionResponse != null && error.errors.exceptionResponse.isNotEmpty()) {
                    error.errors.exceptionResponse[0].code
                } else {
                    validateErrorMessage(message)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                validateErrorMessage(message)
            }
        } else {
            validateErrorMessage(message)
        }
    }

    fun handleForwardErrorDescription(errorCode: Int, errorBody: ResponseBody?, message: String?): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create().fromJson(errorBody!!.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors != null && error.errors.exceptionResponse.isNotEmpty() && error.errors.exceptionResponse[0].description.isNotEmpty()) {
                    error.errors.exceptionResponse[0].description
                } else {
                    // Check if message is null and provide a fallback error message
                    validateErrorMessage(message ?: COMMON_ERROR_MESSAGE)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                // Check if message is null and provide a fallback error message
                validateErrorMessage(message ?: COMMON_ERROR_MESSAGE)
            }
        } else {
            // Check if message is null and provide a fallback error message
            validateErrorMessage(message ?: COMMON_ERROR_MESSAGE)
        }
    }

    fun handleForwardErrorCode(errorCode: Int, errorBody: ResponseBody?, message: String): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create()
                    .fromJson(errorBody!!.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors != null && error.errors.exceptionResponse.isNotEmpty() && error.errors.exceptionResponse[0].code.isNotEmpty()) {
                    error.errors.exceptionResponse[0].code
                } else {
                    validateErrorMessage(message)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                validateErrorMessage(message)
            }
        } else {
            validateErrorMessage(message)
        }
    }

    fun handleForwardErrorCodeAndDescription(
        errorCode: Int,
        errorBody: ResponseBody?,
        message: String
    ): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create()
                    .fromJson(errorBody!!.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors != null && error.errors.exceptionResponse.isNotEmpty() && error.errors.exceptionResponse[0].code.isNotEmpty()) {
                    "${error.errors.exceptionResponse[0].code}_${error.errors.exceptionResponse[0].description}"
                } else {
                    validateErrorMessage(message)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                validateErrorMessage(message)
            }
        } else {
            validateErrorMessage(message)
        }
    }

    fun handleForwardErrorCodeAndDescriptionForGilt(
        errorCode: Int,
        errorBody: ResponseBody?,
        message: String
    ): String {
        return if (errorCode in 400..501) {
            try {
                val error = GsonBuilder().create()
                    .fromJson(errorBody!!.charStream(), ForwardErrorResponse::class.java)
                if (error?.errors?.exceptionResponse != null && error.errors.exceptionResponse.isNotEmpty() && error.errors.exceptionResponse[0].code.isNotEmpty()) {
                    "${error.errors.exceptionResponse[0].code}##${error.errors.exceptionResponse[0].description}"
                } else if (error?.errors?.errorMessage != null) {
                    error.errors.errorMessage
                } else {
                    validateErrorMessage(message)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                validateErrorMessage(message)
            }
        } else {
            validateErrorMessage(message)
        }
    }

    private fun validateErrorMessage(message: String?): String {
        return if (!message.isNullOrEmpty())
            message
        else
            COMMON_ERROR_MESSAGE
    }

    fun validateContainerType(
        sharePref: SharedPreferences,
        type: String
    ): CustomerContainerTypes.ContainerTypesEntity? {
        val typesArray = GsonBuilder().create().fromJson(
            sharePref.getString(PreferenceKeys.CONTAINER_TYPES, ""),
            CustomerContainerTypes::class.java
        )
            ?: return null
        for (item in typesArray.containerTypes!!) {
            if (item.ctyName == type) {
                return item
            }
        }
        return null
    }

    fun <T> Response<T>.toResource(): Resource<T>?{
        if (isSuccessful) {
            body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            return Resource.Error(handleForwardErrorResponse(code(), errorBody(), message()))
        }

        return null
    }

    /**
     *  Get error message from response body [Gilt format]
     */
    fun <T> Response<T>?.getGiltErrorMessage() = this?.let {
        val errorCodeAndDescription = handleForwardErrorCodeAndDescriptionForGilt(it.code(), it.errorBody(), it.message())
        return if (errorCodeAndDescription.contains("##")) {
            val msg = errorCodeAndDescription.split("##")
            msg[1]
        } else {
            errorCodeAndDescription
        }
    } ?: COMMON_ERROR_MESSAGE
}
