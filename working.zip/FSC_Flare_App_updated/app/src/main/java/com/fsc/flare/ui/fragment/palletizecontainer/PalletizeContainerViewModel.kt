package com.fsc.flare.ui.fragment.palletizecontainer

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletResponse
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.repository.PalletizeRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PalletizeContainerViewModel"

@HiltViewModel
class PalletizeContainerViewModel @Inject constructor(
    private val palletizeRepository: PalletizeRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {

    val stagingLocationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val caseDetailsResp: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val palletizeContainerResponse: MutableLiveData<Resource<PalletizeContainerResponse>> = SingleLiveEvent()
    val palletizeContainerPalletResponse: MutableLiveData<Resource<PalletizeContainerPalletResponse>> = SingleLiveEvent()
    val containerInquiryResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()
    val palletDetailsResp = SingleLiveEvent<Resource<InventoryContainerResponse>>()

    var palletHasDamageLocks = false
    var palletDamageLock: String? = null
    var restrictedLockCodesMixListOnPallet = emptyList<String?>()

    // Send PR API
    val sendToPRResponse: MutableLiveData<Resource<SendToPRResponse>> = SingleLiveEvent()

    /**
     * method to validate staging location
     */
    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "StagingLocation Request: $locationClassReq")
        stagingLocationResponse.postValue(Resource.Loading())
        val response = palletizeRepository.validateStagingLocation(locationClassReq)
        stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    /**
     * method to handle staging location response
     */
    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Staging Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to palletize container
     */
    fun palletizeContainer(palletizeContainerRequest: PalletizeContainerRequest) = viewModelScope.launch {
        palletizeContainerResponse.postValue(Resource.Loading())
        val response = palletizeRepository.palletizeContainer(palletizeContainerRequest)
        palletizeContainerResponse.postValue(handlePalletizeContainerResponse(response))
    }

    /**
     * method to handle palletize container response
     */
    private fun handlePalletizeContainerResponse(response: Response<PalletizeContainerResponse>): Resource<PalletizeContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletizeContainerResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletizeContainer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    // Palletize container calling and data access

     private var palletizeContainerPalletInfo = PalletizeContainerPalletResponse()

    fun getPalletizeContainerPalletInfo(): PalletizeContainerPalletResponse {
        return palletizeContainerPalletInfo
    }

    fun setPalletizeContainerPalletInfo(response: PalletizeContainerPalletResponse) {
        this.palletizeContainerPalletInfo = response
    }

    // To keep all de asociated container ids
    var associatedContainersIds=ArrayList<Int>()

    fun getCaseDetails(containerNumber: String, itemInfo: String) = viewModelScope.launch {
        caseDetailsResp.postValue(Resource.Loading())
        val response = palletizeRepository.getPalletizeContainer(containerNumber, itemInfo)
        caseDetailsResp.postValue(handleResponsePalletizeContainer(response))
    }

    private fun handleResponsePalletizeContainer(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletizeContainerResponse : $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletizeContainer Error Response: $errorResponse")
            Resource.Error(errorResponse)
        }

    }

    fun getPalletizePallet(request: PalletizeContainerPalletRequest) = viewModelScope.launch {
        palletizeContainerPalletResponse.postValue(Resource.Loading())
        val response = palletizeRepository.getPalletizeContainerPallet(request)
        palletizeContainerPalletResponse.postValue(handleResponsePalletizeContainerPallet(response))
    }

    private fun handleResponsePalletizeContainerPallet(response: Response<PalletizeContainerPalletResponse>): Resource<PalletizeContainerPalletResponse>? {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletizeContainerPalletResponse : $resultResponse")
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletizeContainer Error Response: $errorResponse")
            Resource.Error(errorResponse)
        }

    }

    fun getPalletDetails(palletNumber: String) = viewModelScope.launch {
        palletDetailsResp.postValue(Resource.Loading())
        val response = palletizeRepository.getPalletDetail(palletNumber)
        palletDetailsResp.postValue(handlePalletDetailResponse(response))
    }

    private fun handlePalletDetailResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "palletDetailResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "palletDetailResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun sendToPR(request: SendToPRRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Confirm SendToPR Request:")
        sendToPRResponse.postValue(Resource.Loading())
        val response = palletizeRepository.sendToPR(request)
        sendToPRResponse.postValue(handleSendToPRResponse(response))
    }
    private fun handleSendToPRResponse(response: Response<SendToPRResponse>): Resource<SendToPRResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SendToPRResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SendToPRResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}