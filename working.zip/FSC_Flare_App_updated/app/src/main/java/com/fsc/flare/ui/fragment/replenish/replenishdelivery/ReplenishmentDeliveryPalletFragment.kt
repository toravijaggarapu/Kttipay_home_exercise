package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenDeliveryPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.receiving.CASE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

@AndroidEntryPoint
class ReplenishmentDeliveryPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var binding: FragmentReplenDeliveryPalletBinding

    private val sharedViewModel: ReplenishmentDeliverySharedViewModel by activityViewModels()
    private val viewModel: ReplenishmentDeliveryPalletViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenDeliveryPalletBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initScreenUI()
        binding.etPalletOrContainer.setOnEditorActionListener { _, actionId, event ->
            if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validatePallet()
            }
            false
        }

        binding.etPalletOrContainer.doAfterTextChanged { binding.tvErrorMessage.text = null }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        observeFlowOnUI { observeScreenState() }
    }

    private fun initScreenUI() {
        binding.tvHeaderTitle.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, "")

        binding.grpPalletNumber.visibility = if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED)
            View.VISIBLE
        else
            View.GONE

        sharedViewModel.task?.let { task ->
            binding.tvPalletOrContainer.text = task.containerNbr
            if (sharedViewModel.selectedTaskMode == USER_DIRECTED) {
                binding.tvPalletOrContainerTitle.text = getString(R.string.lbl_pallet_container_id)
                binding.tvPalletOrContainerSecond.text = getString(R.string.scan_pallet_container)
                binding.etPalletOrContainer.hint = getString(R.string.scan_pallet_container)
            } else if (task.taskContainer == CASE) {
                binding.tvPalletOrContainerTitle.text = getString(R.string.lbl_container_colon)
                binding.tvPalletOrContainerSecond.text = getString(R.string.lbl_scan_container)
                binding.etPalletOrContainer.hint = getString(R.string.lbl_scan_container)
            } else {
                binding.tvPalletOrContainerTitle.text = getString(R.string.lbl_pallet_colon)
                binding.tvPalletOrContainerSecond.text = getString(R.string.lbl_scan_pallet)
                binding.etPalletOrContainer.hint = getString(R.string.lbl_scan_pallet)
            }
        }
    }

    private suspend fun observeScreenState() {
        viewModel.screenState.filterNotNull().collect { state ->
            when (state) {
                ReplenishmentDeliveryPalletState.ShowLoading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    disableTouch()
                }

                ReplenishmentDeliveryPalletState.HideLoading -> {
                    binding.progressBar.visibility = View.GONE
                    enableTouch()
                }

                is ReplenishmentDeliveryPalletState.TaskFetchSuccess -> {
                    sharedViewModel.task = state.task
                    navigateToDeliveryLocation(isUserDirected = true)
                }

                is ReplenishmentDeliveryPalletState.Error -> {
                    binding.tvErrorMessage.text = state.message ?: getString(R.string.lbl_something_went_wrong)
                }
            }
        }
    }

    private fun validatePallet() {
        val inputString = binding.etPalletOrContainer.text.toString().trim()
        hideSoftKeyBoard(requireContext(), binding.etPalletOrContainer)
        if (inputString.isEmpty()) return
        if (sharedViewModel.selectedTaskMode == USER_DIRECTED) {
            viewModel.getTaskForScannedContainer(containerNumber = inputString)
        } else {
            if (inputString == sharedViewModel.task?.containerNbr) {
                navigateToDeliveryLocation()
            } else {
                binding.tvErrorMessage.text =
                    if (sharedViewModel.task?.taskContainer == CASE)
                        getString(R.string.invalid_container_number)
                    else
                        getString(R.string.invalid_pallet_number)
                binding.etPalletOrContainer.selectAll()
            }
        }
    }

    private fun navigateToDeliveryLocation(isUserDirected: Boolean = false) {
        val action = if (isUserDirected)
            ReplenishmentDeliveryPalletFragmentDirections.actionContainerScanToScanFromLocation()
        else
            ReplenishmentDeliveryPalletFragmentDirections.actionContainerScanToDeliveryLocation()
        findNavController().navigate(action)
        binding.etPalletOrContainer.text = null
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        FlareLog.i(screenName, "onScan: $scan")
        if (binding.progressBar.visibility == View.VISIBLE) return
        val barcode = scan?.barcode.toString().trim()
        binding.etPalletOrContainer.setText(barcode)
        binding.etPalletOrContainer.text?.length?.let { binding.etPalletOrContainer.setSelection(it) }
        validatePallet()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(screenName, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearScreenState()
    }
}