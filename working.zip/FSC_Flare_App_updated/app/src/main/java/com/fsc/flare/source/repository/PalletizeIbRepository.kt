package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject

class PalletizeIbRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface, private val sharedPreferences: SharedPreferences) {

    suspend fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) = apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigRequest.fcyId,
        page = printerConfigRequest.page,
        pageLimit = printerConfigRequest.pageLimit,
        printerType = printerConfigRequest.printerType
    )

    suspend fun generatePalletCaseNumber(type: String) =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = type
        )

    suspend fun getMPRTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun validateStagingLocation(locBarCode: String) = apiGatewayInterface.validateStagingLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        barcode = locBarCode,
        locationClass = ""
    )

    suspend fun printContainerLabelInfo(printContainerLabelRequest: PrintContainerLabelRequest) =
        apiGatewayInterface.masterPalletRepackPrintContainerLabel(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            printContainerLabelRequest = printContainerLabelRequest
        )

    suspend fun palletizeIBSubmitAPI(palletizeIbSubmitRequest: PalletizeIbSubmitRequest) =
        apiGatewayInterface.palletizeIBSubmitAPI(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            palletizeIbSubmitRequest = palletizeIbSubmitRequest
        )

    suspend fun postTempContainer(palletRepackPostRequest: PalletRepackPostRequest) =
        apiGatewayInterface.masterPalletRepackPostTempTable(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletRepackPostRequest = palletRepackPostRequest
        )

    suspend fun validateTempTable(palletNumber: String, containerNumber: String) =
        apiGatewayInterface.masterPalletRepackValidateTempTable(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            pallet = palletNumber,
            container = containerNumber
        )

    suspend fun getCaseDetails(caseNumber: String) =
        apiGatewayInterface.getContainerDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null) ?: "",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = caseNumber,
            itemInfo = YES,
            fetchChild = false
        )

    suspend fun getPalletDetail(palletNumber: String) =
        apiGatewayInterface.getContainerDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            containerNumber = palletNumber,
            itemInfo = YES,
            fetchChild = true
        )

    suspend fun getContainerDetails(containerNum: String) = apiGatewayInterface.getInquiryContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum
    )
    suspend fun deleteTempTableContainer(containerNum: String, identifier:String) = apiGatewayInterface.deleteTempContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = containerNum,
        transactionIdentifier = identifier
    )
}