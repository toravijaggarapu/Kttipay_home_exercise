package com.fsc.flare.source.data.dto

data class PalletPrinterReq(
    val cases: List<CasesBean>? = null,
    val pallet: String? = null,
    val printPalletLabel: Int = 0,
    var asnId: Int = 0,
    var facilityCode: String,
    var customerCode: String,
    var buCode: String,
    var fcyId: Int,
    var buId: Int,
    var custId: Int,
    val printRequester: String
)

class CasesBean(
    val serialNumbers: List<String>? = null,
    val qty: Int = 0,
    val itemCode: String? = null,
    val itemBarCode: String? = null,
    val caseNumber: String? = null,
)

