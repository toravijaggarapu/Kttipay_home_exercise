package com.fsc.flare.ui.fragment.inventory.combinebypallet

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryCcActTaskModeBinding
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

@AndroidEntryPoint
class CombineByPalletTaskModeFragment : BaseFragment() {

    @Inject
    lateinit var alertHandler: AlertHandler

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val sharedViewModel: CombineByPalletSharedViewModel by activityViewModels()
    private val viewModel: CombineByPalletTaskModeViewModel by viewModels()

    private lateinit var binding: FragmentInventoryCcActTaskModeBinding
    private var isSysICPEnabled = false

    private val taskModeList by lazy {
        ArrayList<String>().apply {
            add(getString(R.string.system_directed))
            add(getString(R.string.user_directed))
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentInventoryCcActTaskModeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        subscribeObservable()
        observeFlowOnUI { subscribeScreenState() }
        viewModel.verifyICP()
    }

    private suspend fun subscribeScreenState() {
        viewModel.icpLookUpVerification.filterNotNull().collect { state ->
            when(state) {

                CombineByPalletTaskModeEvent.ShowLoading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    disableTouch()
                }

                CombineByPalletTaskModeEvent.HideLoading -> {
                    binding.progressBar.visibility = View.GONE
                    enableTouch()
                }

                is CombineByPalletTaskModeEvent.ShowError -> {
                    showErrorSnackBar(message = state.message ?: getString(R.string.lbl_something_went_wrong))
                }

                is CombineByPalletTaskModeEvent.ICPTaskEnabled -> {
                    isSysICPEnabled = state.enabled
                }
            }
        }
    }

    private fun initViews() {
        binding.tvInventoryCc.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.actTaskModeTv.text = getString(R.string.combine_by_pallet_mode_c)
        binding.actTaskModeDropDown.text = null
        binding.actTaskModeDropDown.hint = getString(R.string.select_combine_by_pallet_mode)
        binding.actTaskModeDropDown.setOptions(taskModeList)
    }

    private fun subscribeObservable() {
        binding.actTaskModeDropDown.boolFoo.observe(viewLifecycleOwner) { selectedOption ->
            sharedViewModel.clearData()
            sharedViewModel.taskMode = selectedOption

            val action = when (selectedOption) {

                getString(R.string.system_directed) -> {
                    if (isSysICPEnabled) {
                        CombineByPalletTaskModeFragmentDirections.actionCombineByPalletTaskModeToCombineByPalletSystemTask()
                    } else {
                        alertHandler.showSimpleAlert(message = getString(R.string.system_directed_is_disabled_for_this_feature_please_check))
                        null
                    }
                }

                getString(R.string.user_directed) -> {
                    CombineByPalletTaskModeFragmentDirections.actionCombineByPalletTaskModeToCombineByPallet()
                }

                else -> null
            }

            action?.let { findNavController().navigate(it) }
            binding.actTaskModeDropDown.text = null
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearData()
    }
}