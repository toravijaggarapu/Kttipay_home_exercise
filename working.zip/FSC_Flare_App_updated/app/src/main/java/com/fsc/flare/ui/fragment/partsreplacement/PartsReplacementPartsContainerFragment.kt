package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementPartscontainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementPartsContainerFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementPartsContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var partsReplacementPartsContainerBinding: FragmentPartsReplacementPartscontainerBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails : List<TaskDetail>
    lateinit var task : List<Task>


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementPartsContainerBinding =
            FragmentPartsReplacementPartscontainerBinding.inflate(inflater, container, false)
        partsReplacementPartsContainerBinding.lifecycleOwner = this
        return partsReplacementPartsContainerBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        FlareLog.e(TAG, "taskDetails : ${taskDetails.toString()}")
        with(partsReplacementPartsContainerBinding) {
            tvPalletCartIdValue.text = taskDetails.get(viewModel.getIndexCountValue()).taskId
            tvItemValue.text = taskDetails.get(viewModel.getIndexCountValue()).itemId
            tvDescriptionValue.text = taskDetails.get(viewModel.getIndexCountValue()).itemDescription
            tvInventoryValue.text =  taskDetails.get(viewModel.getIndexCountValue()).invType
            tvPartContainerValue.text = taskDetails.get(viewModel.getIndexCountValue()).ibContainerNumber
         }
        partsReplacementPartsContainerBinding.etPartContainer.doAfterTextChanged {
            partsReplacementPartsContainerBinding.errResponse.text = null
        }

        partsReplacementPartsContainerBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementPartsContainerBinding.etPartContainer)
                    if (partsReplacementPartsContainerBinding.etPartContainer.isFocused) {
                        validateTest()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementPartsContainerBinding.etPartContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementPartsContainerBinding.etPartContainer)
                validateTest()
            }
            false
        }
    }

    private fun validateTest() {
        val etPartContainer = partsReplacementPartsContainerBinding.etPartContainer.text.toString().trim()
        if (etPartContainer.isNotEmpty()) {
            partsReplacementPartsContainerBinding.errResponse.text = null
            if (partsReplacementPartsContainerBinding.tvPartContainerValue.text.toString().trim()==etPartContainer){
                navigateToPartsItemFragment()
            } else {
                displayErrorMessage(resources.getString(R.string.parts_replacement_parts_container_error_message))
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementPartsContainerBinding.etPartContainer.setText(scan?.barcode.toString())
        partsReplacementPartsContainerBinding.etPartContainer.text?.length?.let {
            partsReplacementPartsContainerBinding.etPartContainer.setSelection(it)
        }
        validateTest()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToPartsItemFragment() {
        val action = PartsReplacementPartsContainerFragmentDirections.actionPartsReplacementPartsContainerFragmentToPartsReplacementPartsContainerItemFragment()
        findNavController().navigate(action)
    }

    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementPartsContainerBinding.errResponse.text = errorMessage
        partsReplacementPartsContainerBinding.etPartContainer.requestFocus()
        partsReplacementPartsContainerBinding.etPartContainer.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementPartsContainerBinding.etPartContainer)
    }

}