package com.fsc.flare.source.data.api

import com.fsc.flare.source.data.dto.PalletPrinterReq
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailResBase
import com.fsc.flare.source.data.dto.containertracking.screenconfig.ScreenConfigBaseRes
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseRes
import com.fsc.flare.source.data.dto.createIBContainer.CIBItembarcodeResponse
import com.fsc.flare.source.data.dto.createIBContainer.CIBPostRequest
import com.fsc.flare.source.data.dto.createIBContainer.CIBPostResponse
import com.fsc.flare.source.data.dto.customer.CustomerDetails
import com.fsc.flare.source.data.dto.cyclecount.CCDetailsUpdateResponse
import com.fsc.flare.source.data.dto.cyclecount.CCLocationInquiryResponse
import com.fsc.flare.source.data.dto.cyclecount.CCQtyUpdateResponse
import com.fsc.flare.source.data.dto.cyclecount.CCTaskDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsForwardRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedDetailsReverseRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedRequest
import com.fsc.flare.source.data.dto.cyclecount.CCUserDirectedResponse
import com.fsc.flare.source.data.dto.cyclecount.CCValidateSlpResponse
import com.fsc.flare.source.data.dto.cyclecount.CountPendingResponse
import com.fsc.flare.source.data.dto.cyclecount.CreateCycleCountDetailResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetailRequest
import com.fsc.flare.source.data.dto.cyclecount.CycleCountDetailsResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTaskDetailResponse
import com.fsc.flare.source.data.dto.cyclecount.CycleCountTaskResponse
import com.fsc.flare.source.data.dto.cyclecount.EndCycleCountResponse
import com.fsc.flare.source.data.dto.cyclecount.EndUserDirectedCCRequest
import com.fsc.flare.source.data.dto.cyclecount.EndUserDirectedCCResponse
import com.fsc.flare.source.data.dto.cyclecount.InventoryMasterMultipleResponse
import com.fsc.flare.source.data.dto.cyclecount.InventoryMasterResponse
import com.fsc.flare.source.data.dto.cyclecount.LocationInventoryCount
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountDetailsRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateCycleCountRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateVirtualContainersCountRequest
import com.fsc.flare.source.data.dto.cyclecount.UpdateVirtualContainersCountResponse
import com.fsc.flare.source.data.dto.cyclecount.ValidateLotOrMfgCodeResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesContainerRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesContainerResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesEndCCRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesEndCycleCountResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesLocationRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesLocationResponse
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesQtyRequest
import com.fsc.flare.source.data.dto.cyclecount.bylocationineaches.CCByLocationInEachesQtyResponse
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPalletInquiryPrintLabelResponse
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPalletInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPrintPalletRequest
import com.fsc.flare.source.data.dto.inquiry.asn.ASNRenamePalletRequest
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.container.TempContainerDeleteResponse
import com.fsc.flare.source.data.dto.inquiry.inventorytransfer.InventoryTransferContainerInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.inventorytransfer.InventoryTransferSlpInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.itembarcode.ItemBarcodeResponse
import com.fsc.flare.source.data.dto.inquiry.location.LocationInquiryResponse
import com.fsc.flare.source.data.dto.inquiry.location.LocationInventoryResponse
import com.fsc.flare.source.data.dto.inquiry.location.resp.LocationDetailsResponse
import com.fsc.flare.source.data.dto.inquiry.location.resp.RlogLocationInquiryResp
import com.fsc.flare.source.data.dto.inquiry.slp.InquirySLPResponse
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.GetEquipmentCurrentPosition
import com.fsc.flare.source.data.dto.interleaving.GetEquipmentTypeResponse
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingRequest
import com.fsc.flare.source.data.dto.interleaving.GetInterLeavingResponse
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTask
import com.fsc.flare.source.data.dto.interleaving.InterLeavingEndTaskResponse
import com.fsc.flare.source.data.dto.interleaving.RegisterLocationRequest
import com.fsc.flare.source.data.dto.interleaving.ResisterLocationResponse
import com.fsc.flare.source.data.dto.interleaving.ValidateContainerRequest
import com.fsc.flare.source.data.dto.inventory.CartonAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.CartonAdjustmentResponse
import com.fsc.flare.source.data.dto.inventory.CartonDetailsResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferSubmitRequest
import com.fsc.flare.source.data.dto.inventory.CaseTransferSubmitResponse
import com.fsc.flare.source.data.dto.inventory.CombinePalletRequest
import com.fsc.flare.source.data.dto.inventory.CombinePalletResponse
import com.fsc.flare.source.data.dto.inventory.InventoryAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryIbPalletLockUnlockAdjustmentRequest
import com.fsc.flare.source.data.dto.inventory.InventoryLockCodeResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLockRequest
import com.fsc.flare.source.data.dto.inventory.InventoryPalletLockUnlockResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTaskSerialNumberResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerLocationRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryTransferLocationRequest
import com.fsc.flare.source.data.dto.inventory.InventoryTransferLocationResponse
import com.fsc.flare.source.data.dto.inventory.LockListResponse
import com.fsc.flare.source.data.dto.inventory.PalletAdjustmentDetailResponse
import com.fsc.flare.source.data.dto.inventory.PalletCombineDetailResponse
import com.fsc.flare.source.data.dto.inventory.TempLpnsResponse
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.GetDestinationLocationResponse
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.InvmTaskCompleteRequest
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.ReasonCodesResponse
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.SourceDetailResponse
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.SubmitDestinationLocationRequest
import com.fsc.flare.source.data.dto.inventory.inventoryMovement.SubmitDestinationLocationResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonRequest
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonResponse
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.ValidateCartonHandlerTypeResponse
import com.fsc.flare.source.data.dto.inventory.palletconsolidation.ICPTaskRequest
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletRequest
import com.fsc.flare.source.data.dto.inventorymanagement.RenamePalletResponse
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitRequest
import com.fsc.flare.source.data.dto.inventorymanagement.palletizeib.PalletizeIbSubmitResponse
import com.fsc.flare.source.data.dto.kitting.KittingCompleteRequest
import com.fsc.flare.source.data.dto.kitting.KittingCompleteResponse
import com.fsc.flare.source.data.dto.kitting.KittingContainerResponse
import com.fsc.flare.source.data.dto.kitting.KittingDescriptionResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.InternationalPrintDocuments
import com.fsc.flare.source.data.dto.labelsanddocuments.InternationalPrintDocumentsResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintCartonRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintDocAndLabelResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintOrderRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintPalletRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintPalletRequestNew
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintRequesterResponse
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentDocumentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.ReprintShipmentDocumentRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerPatchRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.SendPalletToPRRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerResponse
import com.fsc.flare.source.data.dto.login.AppProperties
import com.fsc.flare.source.data.dto.login.AuthorizedMenu
import com.fsc.flare.source.data.dto.login.CustomerContainerTypes
import com.fsc.flare.source.data.dto.login.FacilityInfo
import com.fsc.flare.source.data.dto.login.GatewayToken
import com.fsc.flare.source.data.dto.login.LangUpdateRequest
import com.fsc.flare.source.data.dto.login.LangUpdateResponse
import com.fsc.flare.source.data.dto.login.Token
import com.fsc.flare.source.data.dto.login.UserInfo
import com.fsc.flare.source.data.dto.login.externaluser.ExternalUserResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRSubmitRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRSubmitResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.MasterPalletRepackItemCodeResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.MasterPalletRepackTempContainerResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PalletRepackPostRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelResponse
import com.fsc.flare.source.data.dto.materialMovement.ContainerSourceDetail
import com.fsc.flare.source.data.dto.materialMovement.TransferToLocationRequest
import com.fsc.flare.source.data.dto.materialMovement.TransferToLocationResponse
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayRequest
import com.fsc.flare.source.data.dto.mixedSBPutaway.MSBPutawayResponse
import com.fsc.flare.source.data.dto.packing.req.DeManifestRequest
import com.fsc.flare.source.data.dto.packing.req.ManifestRequest
import com.fsc.flare.source.data.dto.packing.req.PackingConfirmQtyRequest
import com.fsc.flare.source.data.dto.packing.req.PrintLabelRequest
import com.fsc.flare.source.data.dto.packing.req.SendToPRRequest
import com.fsc.flare.source.data.dto.packing.req.UnPackRequest
import com.fsc.flare.source.data.dto.packing.res.CartonTypesResponse
import com.fsc.flare.source.data.dto.packing.res.ManifestAPIResponse
import com.fsc.flare.source.data.dto.packing.res.PackingConfirmQtyResponse
import com.fsc.flare.source.data.dto.packing.res.PackingPackResponse
import com.fsc.flare.source.data.dto.packing.res.PackingValidateSerialNumberResponse
import com.fsc.flare.source.data.dto.packing.res.PrintLabelResponse
import com.fsc.flare.source.data.dto.packing.res.SendToPRResponse
import com.fsc.flare.source.data.dto.packing.res.UnPackResponse
import com.fsc.flare.source.data.dto.packout.req.PackOutEndReq
import com.fsc.flare.source.data.dto.packout.req.PackOutSaveTmp
import com.fsc.flare.source.data.dto.packout.req.PrintCaseLabelPackoutReq
import com.fsc.flare.source.data.dto.packout.res.PackOutEndRes
import com.fsc.flare.source.data.dto.packout.res.PackOutLotResponse
import com.fsc.flare.source.data.dto.packout.res.PackOutPalletResponse
import com.fsc.flare.source.data.dto.packout.res.PackOutSaveTmpResponse
import com.fsc.flare.source.data.dto.packout.res.PackoutBase
import com.fsc.flare.source.data.dto.packout.res.PrintCaseLabelResponse
import com.fsc.flare.source.data.dto.packout.res.workOrderStatusResponse
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteResponse
import com.fsc.flare.source.data.dto.packouttoprtote.PackStationToteToPRLocationRequest
import com.fsc.flare.source.data.dto.palletize.CartonDetailResponse
import com.fsc.flare.source.data.dto.palletize.PalletizeRequest
import com.fsc.flare.source.data.dto.palletize.PalletizeResponse
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerPalletResponse
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerRequest
import com.fsc.flare.source.data.dto.palletizecontainer.PalletizeContainerResponse
import com.fsc.flare.source.data.dto.pallettransfer.PalletDetailResponse
import com.fsc.flare.source.data.dto.pallettransfer.PalletGenerateResponse
import com.fsc.flare.source.data.dto.pallettransfer.PalletTransferRequest
import com.fsc.flare.source.data.dto.pallettransfer.PalletTransferResponse
import com.fsc.flare.source.data.dto.pallettransfer.PalletTransferSplitRequest
import com.fsc.flare.source.data.dto.partsreplacement.request.CompleteMoveTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.GetRepairTaskRf
import com.fsc.flare.source.data.dto.partsreplacement.request.PrintTaskLabelRequest
import com.fsc.flare.source.data.dto.partsreplacement.request.UpdateMoveTaskDetailsRequest
import com.fsc.flare.source.data.dto.partsreplacement.response.GetMoveTaskRfResponse
import com.fsc.flare.source.data.dto.partsreplacement.response.LabelPrintingResponse
import com.fsc.flare.source.data.dto.pickingforward.req.RepairTaskRequest
import com.fsc.flare.source.data.dto.pickingforward.res.RepairTaskResponse
import com.fsc.flare.source.data.dto.physicalInventory.AssignBatchReq
import com.fsc.flare.source.data.dto.physicalInventory.BatchSummaryResp
import com.fsc.flare.source.data.dto.physicalInventory.BatchTaskDetailsResp
import com.fsc.flare.source.data.dto.physicalInventory.UpdateBatchTaskReq
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveRequest
import com.fsc.flare.source.data.dto.pickfromreserve.PalletPickFromReserveResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickCompleteResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ReservePickStageResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoUnitPickCompleteResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivo.TivoValidateQtyResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteRequestTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.MarkTaskCompleteResponseTivoPFR
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidatePalletContainerSerialNumberTivoReverseResponse
import com.fsc.flare.source.data.dto.picking.PickingLocationToRequest
import com.fsc.flare.source.data.dto.picking.PickingSubmitRequest
import com.fsc.flare.source.data.dto.picking.PickingSubmitResponse
import com.fsc.flare.source.data.dto.picking.PickingValidateBlRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateBlResponse
import com.fsc.flare.source.data.dto.picking.PickingValidateContainerIdRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateContainerIdResponse
import com.fsc.flare.source.data.dto.picking.PickingValidateLocationRequest
import com.fsc.flare.source.data.dto.picking.PickingValidateLocationResponse
import com.fsc.flare.source.data.dto.picking.PickingWeightResponse
import com.fsc.flare.source.data.dto.pickingforward.req.BuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteCartonReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteReq
import com.fsc.flare.source.data.dto.pickingforward.res.AllocationTypeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.BuildCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.CycleCountTriggerResponse
import com.fsc.flare.source.data.dto.pickingforward.res.DekitPackoutResponse
import com.fsc.flare.source.data.dto.pickingforward.res.EndPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.KitStagingLocationResponse
import com.fsc.flare.source.data.dto.pickingforward.res.KitStationLocationResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ShortPickToteResponse
import com.fsc.flare.source.data.dto.pickingforward.res.SkipPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickActiveStagingRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickQtyUpdateRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.pickingforward.res.UpcOrSlpResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ValidateToteRes
import com.fsc.flare.source.data.dto.pickingforward.res.WorkOrderDetailsResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ZeroLocationPromptResp
import com.fsc.flare.source.data.dto.prescan.createShipment.request.CreateShipmentRequest
import com.fsc.flare.source.data.dto.prescan.createShipment.response.CreateShipmentResponse
import com.fsc.flare.source.data.dto.prescan.fetch.PreScanValidateRMAResponse
import com.fsc.flare.source.data.dto.prescan.returntype.PrescanReturnTypeResponse
import com.fsc.flare.source.data.dto.prescan.trackingNumber.ValidateTrackingNumberResponse
import com.fsc.flare.source.data.dto.prescan.vendor.PrescanGetCustomerDetailsResponse
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteResponse
import com.fsc.flare.source.data.dto.prtotetopackstation.PRToteStageReq
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayForwardGetResponse
import com.fsc.flare.source.data.dto.putawayreverse.ContainerRequest
import com.fsc.flare.source.data.dto.putawayreverse.ContainerResponse
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayRequest
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayResponse
import com.fsc.flare.source.data.dto.putawayreverse.LocationIDRequest
import com.fsc.flare.source.data.dto.putawayreverse.LocationIDResponse
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcRequest
import com.fsc.flare.source.data.dto.putawayreverse.putawaybyupc.ValidateUpcResponse
import com.fsc.flare.source.data.dto.receiving.ExitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.ExitReceivingResponse
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockResponse
import com.fsc.flare.source.data.dto.receiving.RCSubmitReceivingLPNRequest
import com.fsc.flare.source.data.dto.receiving.RCSubmitReceivingLPNResponse
import com.fsc.flare.source.data.dto.receiving.RCValidateLPNResponse
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingResponse
import com.fsc.flare.source.data.dto.receiving.ValidateOverReceiptResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.receiving.inboundshipment.CriteriaFirstInspectionResponse
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentResponse
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.data.dto.receiving.location.DockDoorLocationResponse
import com.fsc.flare.source.data.dto.receiving.serial.LotNumberResponse
import com.fsc.flare.source.data.dto.receiving.serial.SerialValidationResponse
import com.fsc.flare.source.data.dto.receivingpallet.EndReceiving
import com.fsc.flare.source.data.dto.replenishment.ReplenPatchRequest
import com.fsc.flare.source.data.dto.replenishment.ReplenTaskCompleteRequest
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTaskResponse
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsResponse
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateRequest
import com.fsc.flare.source.data.dto.replenishment.TaskRCAInterimUpdateResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenResponse
import com.fsc.flare.source.data.dto.replenishment.TaskReplenUnloadRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenUnloadResponse
import com.fsc.flare.source.data.dto.replenishment.ValidateBlindContainerRequest
import com.fsc.flare.source.data.dto.replenishment.ValidateBlindContainerResponse
import com.fsc.flare.source.data.dto.rewarehouse.ContainerDetailsResponse
import com.fsc.flare.source.data.dto.rewarehouse.RewareHouseSbNumberResponse
import com.fsc.flare.source.data.dto.rewarehouse.RewareHouseSerialResponse
import com.fsc.flare.source.data.dto.rewarehouse.RewareMovesResponse
import com.fsc.flare.source.data.dto.rewarehouse.RewareSubmitRequestBody
import com.fsc.flare.source.data.dto.rewarehouse.SubmitRewarehouseResponse
import com.fsc.flare.source.data.dto.rewarehouse.ValidateFromLocationResponse
import com.fsc.flare.source.data.dto.rewarehouse.ValidateToContainerResponse
import com.fsc.flare.source.data.dto.rewarehouse.ValidateToLocResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerRequest
import com.fsc.flare.source.data.dto.shipmenttrailer.CloseTrailerResponse
import com.fsc.flare.source.data.dto.shipmenttrailer.ShipmentDockDoorResponse
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPCompleteRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPSystemTask
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPTaskComplete
import com.fsc.flare.source.data.dto.splitcontainerreverse.QtyBaseReq
import com.fsc.flare.source.data.dto.splitcontainerreverse.QtyBaseRes
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContDetailsRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContDetailsResponse
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitContSubmitResponse
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.SplitSkuResponse
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrRequest
import com.fsc.flare.source.data.dto.stagetopr.InventoryStageToPrResponse
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationRequest
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationResponse
import com.fsc.flare.source.data.dto.taskgroup.GroupedTaskResponse
import com.fsc.flare.source.data.dto.taskgroup.PickGroupedTaskRequest
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitResponse
import com.fsc.flare.source.data.dto.utility.itemsizebyslp.UpdateItemSizeBySLPRequest
import com.fsc.flare.source.data.dto.utility.itemsizebyslp.UpdateItemSizeBySLPResponse
import com.fsc.flare.source.data.dto.utility.itemsizebyslp.UtilitySlpResponse
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.fsc.flare.transactiontracker.dto.FSCTrackerResponse
import com.fsc.flare.ui.fragment.packout.PackOutQuantityResponse
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.ICPConstants
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap
import retrofit2.http.Url
import java.math.BigInteger

interface ApiGatewayInterface {

    @FormUrlEncoded
    @POST("v1/token")
    suspend fun getInitialToken(
        @Field("code") authorizationCode: String,
        @Field("code_verifier") challengeCodeVerifier: String,
        @Field("grant_type") grantType: String,
        @Field("client_id") clientId: String,
        @Field("redirect_uri") redirectUri: String
    ): Response<Token>

    @FormUrlEncoded
    @POST("v1/token")
    suspend fun getRefreshedToken(
        @Field("refresh_token") refreshToken: String?,
        @Field("client_id") clientId: String?,
        @Field("grant_type") grantType: String?,
        @Field("redirect_uri") redirectUri: String?
    ): Response<Token>

    @POST("rlog/api/v1/putaway/containerId")
    suspend fun validateContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body containerRequest: ContainerRequest
    ): Response<ContainerResponse>

    @POST("rlog/api/v1/putaway/locationId")
    suspend fun validateLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body locationIDRequest: LocationIDRequest
    ): Response<LocationIDResponse>

    @POST("rlog/api/v1/putaway/doPutaway")
    suspend fun doPutAway(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body doPutawayRequest: DoPutawayRequest
    ): Response<DoPutawayResponse>

    @POST("rlog/api/v1/putaway/imeiPutaway")
    suspend fun doIMEIPutAway(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body doPutawayRequest: DoPutawayRequest
    ): Response<DoPutawayResponse>

    @GET("fetchAppProperties")
    suspend fun fetchAppProperties(): Response<AppProperties>

    @FormUrlEncoded
    @POST("auth/oauth/v2/token")
    suspend fun fetchGatewayToken(
        @Field("client_id") client_id: String,
        @Field("client_secret") client_secret: String,
        @Field("grant_type") grant_type: String,
        @Field("scope") scope: String
    ): Response<GatewayToken>

    @GET("v1/userinfo")
    suspend fun fetchUserInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) oktaToken: String,
    ): Response<UserInfo>

    @GET("userservices/api/v1/getAuthorizedMenus?device=RF")
    suspend fun fetchAuthorizedMenu(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("jwtToken") jwtToken: String
    ): Response<AuthorizedMenu>

    @GET("userservices/api/v1/getAuthorizedMenus?device=RF")
    suspend fun fetchTempAuthorizedMenu(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String
    ): Response<AuthorizedMenu>

    @GET("v1/facility?page=0&pageLimit=5")
    suspend fun getFacilityDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("facilityName") facilityName: String
    ): Response<FacilityInfo>

    @GET("/rlog/api/v1/containertypes/rfContainertypes")
    suspend fun fetchContainerTypes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("ctyConfigCusId") cusId: Int,
        @Query("ctyConfigBuId") buId: Int,
        @Query("ctyWhsId") whsId: Int
    ): Response<CustomerContainerTypes>

    @PATCH("userservices/api/v1/users/updateUserLocale")
    suspend fun appLanguageUpdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("usrId") usrId: Int,
        @Body languageRequest: LangUpdateRequest
    ): Response<LangUpdateResponse>

    @PATCH("userservices/api/v1/updateUserAndFacilityLoginDetails?selectedCustomerId=")
    suspend fun updateLastLoginTime(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("usrId") usrId: Int,
    ): Response<LangUpdateResponse>

    @PATCH("userservices/api/v1/updateUserAndFacilityLoginDetails")
    suspend fun updateLastLoginTimeForCustomer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("usrId") usrId: Int,
        @Query("selectedCustomerId") custId: Int
    ): Response<LangUpdateResponse>

    // Added logic for getting External user details.

    @GET("userservices/api/v1/validateExternalUser")
    suspend fun fetchExternalUserID(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("usrId") usrId: String,
        @Query("userType") type: String
    ): Response<ExternalUserResponse>

    //REWAREHOUSE APIS
    @GET("rlog/api/v1/rewarehouse/conDetails")
    suspend fun containerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cntId") cntId: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String
    ): Response<ContainerDetailsResponse>

    @GET("rlog/api/v1/rewarehouse/rewareMoves")
    suspend fun rewareMoves(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cntId") cntId: String,
        @Query("sbNum") sbNum: String,
        @Query("fromLoc") fromLoc: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String
    ): Response<RewareMovesResponse>

    @GET("rlog/api/v1/rewarehouse/toLocation")
    suspend fun validateToLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("toLoc") toLoc: String,
        @Query("cntId") cntId: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String,
        @Query("sbNum") sbNum: String
    ): Response<ValidateToLocResponse>

    @GET("rlog/api/v1/rewarehouse/fromLocation")
    suspend fun validateFromLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("locId") locId: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String
    ): Response<ValidateFromLocationResponse>

    @GET("rlog/api/v1/rewarehouse/toContainer")
    suspend fun validateToContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("whsId") whsId: Int,
        @Query("cusId") cusId: Int,
        @Query("cntId") cntId: String,
        @Query("toLoc") toLoc: String,
        @Query("toCont") toCont: String,
        @Query("sbNum") sbNum: String

    ): Response<ValidateToContainerResponse>

    // MN:SbNum
    @GET("rlog/api/v1/rewarehouse/sbNum")
    suspend fun validateSbNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("locId") locId: String,
        @Query("sbNum") sbNum: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String
    ): Response<RewareHouseSbNumberResponse>


    @POST("rlog/api/v1/rewarehouse/rewarehouseSubmit")
    suspend fun submitRewarehouse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body rewareSubmitRequestBody: RewareSubmitRequestBody,
        @Query("whsId") whsId: Int,
        @Query("cusId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("userId") userId: Int,
        @Query("cntId") cntId: String,
        @Query("locId") locId: String,
        @Query("Weight") Weight: String,
        @Query("toLoc") toLoc: String,
        @Query("sbNum") sbNum: String,
        @Query("toCont") toCont: String,
        @Query("isContValidated") isContValidated: String

    ): Response<SubmitRewarehouseResponse>


    @GET("v1/locations")
    suspend fun getDockDoorLocationId(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("locationId") locationId: String,
        @Query("barcode") barcode: String,
        @Query("locationClass") locationClass: String,
    ): Response<DockDoorLocationResponse>


    @GET("v1/locations")
    suspend fun getPackOutLocationId(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String,
        @Query("itemInfo") itemInfo: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int
    ): Response<PackoutBase>

    @GET("v1/inventory/packout")
    suspend fun getPackOutPalletId(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("palletNumber") palletNumber: String?,
        @Query("ibCartonNumber") ibCartonNumber: String
    ): Response<PackOutPalletResponse>

    //lot number validate
    @GET("v1/lotnumbers")
    suspend fun getPackOutLotNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("batchNumber") lotNumber: String,
        @Query("itemName") itemName: String,
        @Query("itemId") itemId: Int
    ): Response<PackOutLotResponse>

    @POST("v1/inventory/endpackout")
    suspend fun endPackout(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body packOutEndReq: PackOutEndReq
    ): Response<PackOutEndRes>


    @POST("v1/inventory/packout")
    suspend fun submitPackout(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body packOutSaveTmp: PackOutSaveTmp
    ): Response<PackOutSaveTmpResponse>

    //packout Location
    @GET("/v1/inventory/validateQty")
    suspend fun getQtyId(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("qty") qty: Int,
        @Query("palletQty") palletQty: Int,
        @Query("caseQty") caseQty: Int,
        @Query("locationBarCode") locationBarCode: String,
        @Query("transactionIdentifier") transactionIdentifier: String,
        @Query("isKitting") isKitting: Boolean,
        @Query("itemId") itemId: Int
    ): Response<PackOutQuantityResponse>

    //packoutserial number

    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validatePackOutSerialNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("containerNumber") containerNumber: String,
        @Query("palletNumber") palletNumber: String,
        @Query("containerSerialNumber") containerSerialNumber: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("userDirected") userDirected: Boolean,
        @Query("taskUom") taskUom: String
    ): Response<InventoryTaskSerialNumberResponse>

    @GET("v1/inboundshipments")
    suspend fun getASN(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("responseFilter") responseFilter: String,
        @Query("customerId") customerId: Int,
        @Query("locBarcode") locBarcode: String,
        @Query("fcyId") fcyId: Int
    ): Response<PackageInboundShipmentResponse>

    //Packout item barcode need to be used this
    @GET("v1/items")
    suspend fun getItems(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("responseFilter") responseFilter: String,
        @Query("customerId") customerId: String,
        @Query("fcyId") fcyId: String,
        @Query("page") page: String,
        @Query("itemBarcode") itemBarcode: String,
        @Query("itemId") itemId: String
    ): Response<PackageItemResponse>


    //Item Recall Lock
    @GET("v1/inventory/recall")
    suspend fun getItemRecallLock(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Long,
        @Query("buId") buId: Long,
        @Query("fcyId") fcyId: Long,
        @Query("itemCode") itemCode: String,
        @Query("asnNumber") asnNumber: String? = null,
        @Query("lotNumber") lotNumber: String? = null,
        @Query("coo") coo: String? = null,
        @Query("invType") invType: String? = null,
        @Query("vendorName") vendorName: String? = null,
        @Query("expiryDate") expiryDate: String? = null,
        @Query("status") status: ArrayList<String>? = null
    ): Response<ItemRecallLockResponse>

    //Packout item barcode need to be used this
    @GET("v1/items/itemBarCodeOrUpc")
    suspend fun getItemsorUPC(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("responseFilter") responseFilter: String,
        @Query("customerId") customerId: String,
        @Query("buId") buId: String,
        @Query("fcyId") fcyId: String,
        @Query("page") page: String,
        @Query("itemBarcode") itemBarcode: String,
    ): Response<PackageItemResponse>

    @POST("v1/receiving")
    suspend fun submitReceiving(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body submitReceivingRequest: SubmitReceivingRequest
    ): Response<SubmitReceivingResponse>


    @PATCH("v1/inboundshipment/verify")
    suspend fun exitReceiving(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body exitReceivingRequest: ExitReceivingRequest
    ): Response<ExitReceivingResponse>

    //region Reverse Picking

    @GET
    suspend fun getWeightReq(
        @Url url: String,
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
    ): Response<PickingWeightResponse>

    @POST("rlog/api/v1/picking/validateBl")
    suspend fun isValidBL(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body pickingValidateBlRequest: PickingValidateBlRequest
    ): Response<PickingValidateBlResponse>

    @POST("rlog/api/v1/picking/validateLocation")
    suspend fun isValidLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body pickingValidateLocationRequest: PickingValidateLocationRequest
    ): Response<PickingValidateLocationResponse>

    @POST("rlog/api/v1/picking/validateContainerId")
    suspend fun isValidContainerId(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body pickingValidateContainerIdRequest: PickingValidateContainerIdRequest
    ): Response<PickingValidateContainerIdResponse>

    @POST("rlog/api/v1/picking/validateLocationTo")
    suspend fun isValidLocationTo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body pickingLocationToRequest: PickingLocationToRequest
    ): Response<PickingValidateLocationResponse>

    @POST("rlog/api/v1/picking/doPick")
    suspend fun isValidToDoPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body pickingSubmitRequest: PickingSubmitRequest
    ): Response<PickingSubmitResponse>

    //endregion

    //CONTAINER TRACKING APIs

    @POST("rlog/api/v1/containerTracking")
    suspend fun saveContTracking(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body sendContainerTrackingBaseReq: SendContainerTrackingBaseReq
    ): Response<SendContainerTrackingBaseRes>

    @GET("rlog/api/v1/containerTracking")
    suspend fun getContTracking(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: String,
        @Query("buId") buId: String,
        @Query("fcyId") fcyId: String,
        @Query("containerNbr") containerNbr: String,
        @Query("includeCCLocation") includeCCLocation: String
    ): Response<GetContDetailResBase>

    @GET("rlog/api/v1/screen/screenConfigDetails")
    suspend fun getScreenConfig(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("program") program: String,
        @Query("cusId") cusId: String,
        @Query("whsId") whsId: String,
        @Query("deletedFlag") deletedFlag: String
    ): Response<ScreenConfigBaseRes>


    @GET("v1/putaway/{cntNumber}/{locClass}/{containerType}")
    suspend fun getPutawaySystemDirected(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcy_id") fcy_id: String,
        @Header("bu_id") bu_id: String,
        @Header("cust_id") cust_id: String,
        @Path("cntNumber") cntNumber: String,
        @Path("locClass") locClass: String,
        @Path("containerType") containerType: String,
    ): Response<PutawayForwardGetResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getInquiryContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNbr: String
    ): Response<ContainerInventoryInquiryResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getContainerInquiryWithItemUom(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNbr: String,
        @Query("itemUOMRequired") itemUOMRequired: Boolean,
    ): Response<ContainerInventoryInquiryResponse>

    @DELETE("v1/inventory/templpns")
    suspend fun deleteTempContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("transactionIdentifier") transactionIdentifier: String
    ): Response<TempContainerDeleteResponse>

    @GET("v1/locationsInquiry")
    suspend fun getLocationInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("locBarCode") locBarCode: String
    ): Response<LocationInquiryResponse>


    @GET("v1/locationsInquiry")
    suspend fun getDockDoorInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("locBarCode") locBarCode: String,
        @Query("locClass") locClass: String
    ): Response<LocationInquiryResponse>

    @GET("v1/items")
    suspend fun getInquiryItemInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("responseFilter") responseFilter: String,
        @Query("itemBarcode") itemBarcode: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int
    ): Response<ItemBarcodeResponse>

    @GET("v1/lookups?active=Y&lookupNames=TASK_TYPE")
    suspend fun getTaskGroups(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
    ): Response<LookUps>


    @GET("v1/taskgroupsrf")
    suspend fun getTaskGroupsSrf(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("allocationType") allocationType: String,
    ): Response<TaskGroupResponse>

    @GET("v1/lookups?active=Y&lookupNames=INVENTORY_ADJUST_REASON_CODES")
    suspend fun getInventoryReasonCodes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cusId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
    ): Response<LookUps>

    @GET("v1/cyclecount?page=0&pageLimit=10")
    suspend fun getCycleCountTaskForLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("status") status: String,
        @Query("custId") custId: Int,
        @Query("responseFilter") responseFilter: String,
        @Query("buId") buId: Int,
        @Query("locationId") locationId: Int
    ): Response<CCTaskDetailsResponse>

    @GET("v1/cyclecount?page=0&pageLimit=10")
    suspend fun getCycleCountTaskForLocationPending(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("status") status: String,
        @Query("custId") custId: Int,
        @Query("responseFilter") responseFilter: String,
        @Query("buId") buId: Int,
        @Query("taskType") taskType: String,
        @Query("userId") userID: String
    ): Response<CCTaskDetailsResponse>

    @GET("v1/cyclecount?page=0&pageLimit=10")
    suspend fun getCycleCountTaskForPalletCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("status") status: String,
        @Query("custId") custId: Int,
        @Query("responseFilter") responseFilter: String,
        @Query("buId") buId: Int,
        @Query("taskType") taskType: String,
        @Query("userId") userID: String,
        @Query("locationId") locationId: Int
    ): Response<CCTaskDetailsResponse>

    @GET("v1/cyclecounttask")
    suspend fun getCycleCountTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("taskMode") taskMode: String?,
        @Query("taskType") taskType: String?,
        @Query("locationId") locationId: String? = null
    ): Response<CycleCountTaskResponse>

    @GET("v1/cyclecountcontainer")
    suspend fun cyclecountcontainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("userId") userId: Int,
        @Query("ccHeaderId") ccHeaderId: Int,
        @Query("locationId") locationId: Int,
        @Query("containerNbr") containerNbr: String,
        @Query("createNewExcessInventory") createNewExcessInventory: String,
        @Query("acceptBlindCase") acceptBlindCase: Boolean,
        @Query("taskType") taskType: String?,
        @Query("reasonCode") reasonCode: String?
    ): Response<CycleCountDetailsResponse>

    @PATCH("v1/cyclecountqtyupdate/{ccDetId}")
    suspend fun ccQtyUpdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Path("ccDetId") ccDetId: Long,
        @Body updateCycleCountRequest: UpdateCycleCountRequest
    ): Response<CCQtyUpdateResponse>

    @PATCH("v1/cyclecountclose/{ccHeaderId}")
    suspend fun endCycleCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header("override") override: Boolean,
        @Path("ccHeaderId") ccHeaderId: Int
    ): Response<EndCycleCountResponse>


    @PATCH("v1/cyclecountvalidateslp")
    suspend fun validateSlp(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("ccHeaderId") ccHeaderId: Int,
        @Query("slp") slp: String,
        @Query("containerId") containerId: Long
    ): Response<CCValidateSlpResponse>

    @POST("v1/cyclecountdetails")
    suspend fun updateCycleCountDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body cycleCountDetails: UpdateCycleCountDetailsRequest
    ): Response<CCDetailsUpdateResponse>

    @PATCH("v1/taskreplen")
    suspend fun getTaskReplen(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskReplenRequest: TaskReplenRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/taskreplen")
    suspend fun getTaskCartReplen(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskReplenRequest: TaskReplenCartRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/taskbuildcartend")
    suspend fun updateReplenEndCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskReplenEndCartRequest: TaskReplenEndCartRequest
    ): Response<TaskReplenEndCartResponse>

    @PATCH("v1/task/taskRCAInterimUpdate")
    suspend fun handleTaskRCAInterimUpdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskRCAInterimUpdateRequest: TaskRCAInterimUpdateRequest
    ): Response<TaskRCAInterimUpdateResponse>

    @GET("v1/taskreplnskip")
    suspend fun taskReplenSkip(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("pickCartNbr") pickCartNbr: String?,
        @Query("assignedTo") assignedTo: Int,
        @Query("allocationType") allocationType: String,
        @Query("skipTaskId") skipTaskId: String,
        @Query("skipTaskDetId") skipTaskDetId: String?,
    ): Response<SkipTaskDetailsResponse>

    @GET("v1/taskbuildskip")
    suspend fun replenTaskSkip(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("pickCartNbr") pickCartNbr: String?,
        @Query("assignedTo") assignedTo: Int,
        @Query("allocationType") allocationType: String,
        @Query("skipTaskId") skipTaskId: String,
        @Query("skipTaskDetId") skipTaskDetId: String?,
    ): Response<TaskReplenResponse>

    @PATCH("v1/taskreplenload")
    suspend fun validateBlindContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body validateBlindContainerRequest: ValidateBlindContainerRequest
    ): Response<ValidateBlindContainerResponse>

    @PATCH("v1/taskreplenunload")
    suspend fun unloadReplen(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskReplenUnloadRequest: TaskReplenUnloadRequest
    ): Response<TaskReplenUnloadResponse>

    //PICKING FORWARD APIs
    @POST("v1/taskcontainertotevalid")
    suspend fun validateTote(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body validateToteReq: ValidateToteReq
    ): Response<ValidateToteRes>

    @PATCH("v1/taskpick")
    suspend fun getTaskPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickReq: TaskPickReq
    ): Response<TaskPickResponse>

    @PATCH("v1/taskpick")
    suspend fun getReplenTaskPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body replenPickTaskRequest: TaskReplenRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/taskpick")
    suspend fun getReplenCaseToActiveTaskPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskReplenCartRequest: TaskReplenCartRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/task/replen/50")
    suspend fun submitReplenCasePickTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body replenCasePickTaskRequest: ReplenPatchRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/task/replen/40")
    suspend fun submitReplenActiveTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body replenActivePickTaskRequest: ReplenPatchRequest
    ): Response<TaskReplenResponse>

    @PATCH("v1/task/replen/60")
    suspend fun submitReplenCaseToActiveTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body replenCaseToActiveRequest: ReplenPatchRequest
    ): Response<TaskRCAInterimUpdateResponse>

    @PATCH("v1/taskpick")
    suspend fun getTaskPickCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickCartReq: TaskPickCartReq
    ): Response<TaskPickResponse>

    @PATCH("v1/taskbuildcartend")
    suspend fun pickEndCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body endPickCartReq: EndPickCartReq
    ): Response<EndPickCartRes>

    @GET("v1/task/getWorkOrdersForAssignedTasks")
    suspend fun getWorkOrderDetailsForAssignedTasks(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("assignedTo") assignedTo: Int?,
        @Query("allocationType") allocationType: String?,
        @Query("taskGroup") taskGroup: String?
    ): Response<WorkOrderDetailsResponse>

    @GET("v1/taskbuildskip")
    suspend fun pickSkipCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("pickCartNbr") pickCartNbr: String?,
        @Query("assignedTo") assignedTo: Int?,
        @Query("allocationType") allocationType: String?,
        @Query("skipTaskId") skipTaskId: String?,
        @Query("skipTaskDetId") skipTaskDetId: String?,
        @Query("replenType") replenType: String?,
        @Query("isLTLcubing") isLTLcubing: Boolean,
        @Query("orderType") orderType: String? = null
    ): Response<SkipPickCartRes>

    @GET("v1/taskbuildskip")
    suspend fun buildSkipCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("pickCartNbr") pickCartNbr: String,
        @Query("assignedTo") assignedTo: Int,
        @Query("allocationType") allocationType: String,
        @Query("skipTaskId") skipTaskId: String,
        @Query("skipTaskDetId") skipTaskDetId: String?,
        @Query("isLTLcubing") isLTLcubing: Boolean,
        @Query("casePickWithPallet") casePickWithPallet: Boolean,
        @Query("orderType") orderType: String? = null
    ): Response<SkipPickCartRes>

    @PATCH("v1/taskbuildcart")
    suspend fun taskBuildCart(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body buildCartReq: BuildCartReq
    ): Response<BuildCartRes>

    @POST("v1/taskcartslotvalid")
    suspend fun validateSlot(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body buildCartReq: BuildCartReq
    ): Response<BuildCartRes>

    @PATCH("v1/taskcasepickcomplete")
    suspend fun taskcasepickcomplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskCasePickCompleteReq: TaskCasePickCompleteReq
    ): Response<TaskCasePickCompleteRes>

    @PATCH("v1/taskpickqtyupdate")
    suspend fun taskPickQtyUpdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickQtyUpdateReq: TaskPickQtyUpdateReq
    ): Response<TaskPickQtyUpdateRes>

    @GET("v1/locations")
    suspend fun validateStagingLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String,
        @Query("locationClass") locationClass: String
    ): Response<LocationClassRes>

    @GET("v1/task/orderprocesslocation")
    suspend fun getKitStagingLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("psuedoOrderId") psuedoOrderId: Int,
        @Query("orderType") orderType: String,
    ): Response<KitStagingLocationResponse>

    @GET("v1/task/orderprocesslocation")
    suspend fun getOrderProcessLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("psuedoOrderId") psuedoOrderId: Int,
        @Query("orderType") orderType: String,
    ): Response<KitStagingLocationResponse>

    @GET("v1/locations")
    suspend fun validatePRLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String,
        @Query("locationClass") locationClass: String
    ): Response<LocationClassRes>

    @GET("v1/locations")
    suspend fun validateLocationCycleCountStatus(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String,
        @Query("locationClass") locationClass: String
    ): Response<LocationClassRes>

    @PATCH("v1/taskactivepickstaging")
    suspend fun taskactivepickstaging(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickActiveStagingReq: TaskPickActiveStagingReq
    ): Response<TaskPickActiveStagingRes>

    @PATCH("v1/taskStaging")
    suspend fun taskstaging(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskStagingRequest: TaskStagingRequest
    ): Response<TaskPickActiveStagingRes>

    //Split container API

    @POST("rlog/api/v1/partsconsumption/validate/source")
    suspend fun validateFromContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body splitContDetailsRequest: SplitContDetailsRequest
    ): Response<SplitContDetailsResponse>

    @POST("rlog/api/v1/partsconsumption/validate/sku")
    suspend fun validateSku(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body splitSkuRequest: SplitSkuRequest
    ): Response<SplitSkuResponse>

    @POST("rlog/api/v1/partsconsumption/validate/sku")
    suspend fun validateItemBarcode(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body splitSkuRequest: SplitSkuRequest
    ): Response<SplitSkuResponse>

    @POST("/rlog/api/v1/partsconsumption/validate/quantity")
    suspend fun validateQty(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body qtyBaseReq: QtyBaseReq
    ): Response<QtyBaseRes>

    @POST("rlog/api/v1/partsconsumption/processparts")
    suspend fun validateSubmitContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_BUID) buId: Int,
        @Body splitContSubmitRequest: SplitContSubmitRequest
    ): Response<SplitContSubmitResponse>


    @GET("rlog/api/v1/rewarehouse/serial")
    suspend fun rewareHouseSerial(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("serial") serial: String,
        @Query("cusId") cusId: Int,
        @Query("whsId") whsId: Int
    ): Response<RewareHouseSerialResponse>

    @GET("v1/criteriafirstinspection")
    suspend fun criteriaFirstInspection(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("criteriaType") criteriaType: String,
        @Query("itemId") itemId: Int
    ): Response<CriteriaFirstInspectionResponse>

    @POST("v1/inboundshipment/validateSerialNumber")
    suspend fun validateSerialNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("bu_id") buId: Int,
        @Header("cust_id") custId: Int,
        @Header("fcy_id") fcyId: Int,
        @Header("asn_id") asnId: Int,
        @Header("item_id") itemId: Int,
        @Header("serial_num") serialNum: String
    ): Response<SerialValidationResponse>

    @GET("v1/inventory/validateSerialNumberOrItemCode")
    suspend fun validateSerialNumberWithItemCode(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("serialNumberOrItemCode") serialNumberOrItemId: String,
        @Query("outBoundOnly") isOutBoundOnly: Boolean
    ): Response<PickingSerialOrItemCodeResponse>

    @GET("v1/containers")
    suspend fun getContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("itemInfo") itemInfo: String
    ): Response<InventoryContainerResponse>

    @PATCH("v1/inventorymaster/locksandadjustment")
    suspend fun inventoryLockAdjustment(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryAdjustmentRequest: InventoryAdjustmentRequest
    ): Response<InventoryPalletLockUnlockResponse>

    @PATCH("v1/inventorymaster/locksandadjustment")
    suspend fun inventoryLockRequest(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryLockRequest: InventoryLockRequest
    ): Response<InventoryPalletLockUnlockResponse>

    @GET("v1/shipments/flare/shipmentcartons")
    suspend fun shipmentCartons(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("obContainerId") obContainerId: Int,
        @Query("itemBarcode") itemBarcode: String,
        @Header("buId") buId: Int,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int
    ): Response<CartonDetailsResponse>

    @PATCH("v1/packqtyconfirm")
    suspend fun packqtyconfirm(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body cartonAdjustmentRequest: CartonAdjustmentRequest
    ): Response<CartonAdjustmentResponse>

    @GET("v1/inboundshipment/validatelotnumber")
    suspend fun validateLotNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("lotNumber") lotNumber: String,
        @Header("asnId") asnId: Int?,
        @Header("itemId") itemId: Int?,
        @Header("lotNumberCheck") lotNumberCheck: Boolean?
    ): Response<LotNumberResponse>

    @PATCH("v1/packing/palletize")
    suspend fun palletize(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body palletizeRequest: PalletizeRequest
    ): Response<PalletizeResponse>


    @GET("v1/shipments/flare/dockdoor")
    suspend fun getShipmentDockDoor(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("dockDoorId") dockDoorId: Int,
        @Query("closeTrailer") closeTrailer: Boolean,
    ): Response<ShipmentDockDoorResponse>

    @PATCH("v1/shipments/flare/closetrailer")
    suspend fun closeTrailer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body closeTrailerRequest: CloseTrailerRequest
    ): Response<CloseTrailerResponse>

    @GET("v1/containers")
    suspend fun validateStagingPallet(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("itemInfo") itemInfo: String
    ): Response<InventoryContainerResponse>

    @PATCH("v1/taskstagepallet")
    suspend fun validatePalletStagingLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body stagingPalletLocationRequest: StagingPalletLocationRequest
    ): Response<StagingPalletLocationResponse>

    @GET("v1/shipments/flare/load")
    suspend fun loadTrailer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Long,
        @Query("shipmentId") shipmentId: Int,
        @Query("containerId") containerId: String
    ): Response<LoadTrailerResponse>

    @GET("v1/shipments/flare/unload")
    suspend fun unloadTrailer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Long,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("shipmentId") shipmentId: Int,
        @Query("containerId") containerId: String
    ): Response<UnloadTrailerResponse>

    @PATCH("v1/shipments/flare/load")
    suspend fun loadTrailerPatch(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body loadTrailerPatchRequest: LoadTrailerPatchRequest
    ): Response<LoadTrailerResponse>


    @PATCH("v1/shipments/flare/unload")
    suspend fun unLoadTrailerPatch(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body unloadTrailerRequest: UnloadTrailerRequest
    ): Response<UnloadTrailerResponse>

    @PATCH("v1/taskreservepickcomplete")
    suspend fun taskReservePickComplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body reservePickCompleteRequest: ReservePickCompleteRequest
    ): Response<ReservePickCompleteResponse>

    @PATCH("v1/task/reservepickstage/release")
    suspend fun reservepickstage(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcy_id") fcy_id: Int,
        @Query("cust_id") cust_id: Int,
        @Query("bu_id") bu_id: Int
    ): Response<ReservePickStageResponse>

    @PATCH("v1/task/reservepickstage")
    suspend fun reservepickstageupdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body reservePickStageRequest: ReservePickStageRequest
    ): Response<ReservePickStageResponse>

    @GET("v1/printerconfig")
    suspend fun getPrinterConfigs(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("requestor") requestor: String
    ): Response<PrintRequesterResponse>

    @GET("v1/lookups?active=Y")
    suspend fun getLookup(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("lookupNames") lookupNames: String
    ): Response<LookUps>

    @GET("v1/shipments/flare/validateinputforprinting")
    suspend fun validateInputForPrinting(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("searchEntity") searchEntity: String,
        @Query("inputVal") inputVal: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int
    ): Response<ValidateInputResponse>

    @PATCH("v1/shipments/flare/printdocandlabel")
    suspend fun printPallet(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printPalletRequest: PrintPalletRequest
    ): Response<PrintDocAndLabelResponse>

    @PATCH("v1/shipments/flare/printdocandlabel")
    suspend fun printOrder(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printOrderRequest: PrintOrderRequest
    ): Response<PrintDocAndLabelResponse>

    @PATCH("v1/shipments/flare/printdocandlabel")
    suspend fun printShipment(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printShipmentRequest: PrintShipmentRequest
    ): Response<PrintDocAndLabelResponse>

    @PATCH("v1/shipments/flare/printdocandlabel")
    suspend fun printCarton(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printCartonRequest: PrintCartonRequest
    ): Response<PrintDocAndLabelResponse>

    @GET("v1/inboundshipments")
    suspend fun getReceivingASNDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") custId: Int,
        @Query("customerId") customerId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("pageLimit") pageLimit: String,
        @Query("asnNumber") asnNumber: String
    ): Response<PackageInboundShipmentResponse>

    @GET("v1/inboundshipments")
    suspend fun getReceivingDockDoorDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") custId: Int,
        @Query("customerId") customerId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("pageLimit") pageLimit: Int,
        @Query("dockDoor") dockDoor: Int
    ): Response<PackageInboundShipmentResponse>


    @GET("v1/inboundshipment/flare/validatelpn")
    suspend fun validateLPN(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("asnId") asnId: Int,
        @Query("caseNbr") caseNbr: String,
        @Query("receivingType") receivingType: String
    ): Response<RCValidateLPNResponse>

    @GET("v1/inboundshipment/flare/validatelpn")
    suspend fun validateLPNForConainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("asnId") asnId: Int,
        @Query("caseNbr") caseNbr: String,
        @Query("receivingType") receivingType: String,
        @Query("palletNbr") palletNbr: String
    ): Response<RCValidateLPNResponse>

    @POST("v1/receiving/lpn")
    suspend fun submitReceivingLPN(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body rcReceivingLPNRequest: RCSubmitReceivingLPNRequest
    ): Response<RCSubmitReceivingLPNResponse>

    @GET("v1/inboundshipment/flare/validatelpn")
    suspend fun validatePalletNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("asnId") asnId: Int,
        @Query("palletNbr") palletNbr: String,
        @Query("receivingType") receivingType: String
    ): Response<RCValidateLPNResponse>


    @PATCH("v1/inboundshipment/verify")
    suspend fun endReceiving(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body endReceiving: EndReceiving
    ): Response<ExitReceivingResponse>


    @GET("rlog/api/v1/scans/getSlpInquiry")
    suspend fun getSLPDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("CUSTOMER") customer: Int,
        @Header("FCYID") fcyId: Int,
        @Header("BUID") buId: Int,
        @Query("slp") slp: BigInteger
    ): Response<InquirySLPResponse>

    @POST("/v1/cyclecount/userdirected")
    suspend fun cycleCountUserDirected(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: Int,
        @Body CCUserDirectedRequest: CCUserDirectedRequest
    ): Response<CCUserDirectedResponse>

    @POST("v1/cyclecount/userdirectedcyclecountdtls")
    suspend fun ccUserDirectedDetailsForward(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body ccUserDirectedDetailsForwardRequest: CCUserDirectedDetailsForwardRequest
    ): Response<CCUserDirectedDetailsResponse>

    @POST("v1/cyclecount/userdirectedcyclecountdtls")
    suspend fun ccUserDirectedDetailsReverse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body ccUserDirectedDetailsReverseRequest: CCUserDirectedDetailsReverseRequest
    ): Response<CCUserDirectedDetailsResponse>

    @POST("v1/cyclecount/userdirectedcyclecntend")
    suspend fun endUserDirectedCycleCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body endUserDirectedCCRequest: EndUserDirectedCCRequest
    ): Response<EndUserDirectedCCResponse>

    @GET("v1/task/rf/transactionparam")
    suspend fun getTransactionParam(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cust_id") custId: Int,
        @Query("bu_id") buId: Int,
        @Query("fcy_id") fcyId: Int,
        @Query("trans_code") transCode: String,
    ): Response<TransactionParamResponse>

    @GET("v1/inventory/validateQty")
    suspend fun tivoValidateQty(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("qty") qty: Int,
        @Query("palletQty") palletQty: Int,
        @Query("caseQty") caseQty: Int,
        @Query("locationBarCode") locationBarCode: String,
        @Query("transactionIdentifier") transactionIdentifier: Int,
    ): Response<TivoValidateQtyResponse>

    @PATCH("v1/task/reservepickcomplete")
    suspend fun palletPickReserveComplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body palletPickFromReserveRequest: PalletPickFromReserveRequest
    ): Response<PalletPickFromReserveResponse>


    @PATCH("v1/tasks/unitpickcomplete")
    suspend fun unitPickComplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body tivoUnitPickCompleteRequest: TivoUnitPickCompleteRequest
    ): Response<TivoUnitPickCompleteResponse>

    @PATCH("v1/taskpick")
    suspend fun tivoGetTaskPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickReq: TaskPickReq
    ): Response<TaskPickResponse>


    @GET("v1/task/rf/transactionparam")
    suspend fun validateTransactionParam(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cust_id") custId: Int,
        @Query("fcy_id") fcyId: Int,
        @Query("bu_id") buId: Int,
        @Query("trans_code") transCode: String,
    ): Response<TransactionParamResponse>

    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validateInventoryTaskSerialNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("containerNumber") containerNumber: String,
        @Query("palletNumber") palletNumber: String,
        @Query("containerSerialNumber") containerSerialNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("userDirected") userDirected: Boolean,
        @Query("outBoundOnly") outBoundOnly: Boolean,
    ): Response<InventoryTaskSerialNumberResponse>

    @GET("v1/lookups")
    suspend fun getInventoryLookups(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("lookupNames") lookupNames: String
    ): Response<LookUps>


    /* ------------------- Tivo pick from reserve --------------------*/


    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validatePalletNumberTivoPFR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("palletNumber") palletNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
    ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>

    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validatePalletSerialNumberTivoPFR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("containerSerialNumber") containerSerialNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("palletNumber") palletNumber: String,

        ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>


    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validatePalletNumberTivoPFRUserDirected(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("containerSerialNumber") containerSerialNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("taskDetailId") taskDetailId: Int,
    ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>

    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validateContainerNumberTivoPFRUserDirected(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("taskDetailId") taskDetailId: Int,
    ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>


    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validateContainerNumberTivoPFR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("palletNumber") palletNumber: String,
    ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>

    @GET("v1/tasks/validatelpnserialnumber")
    suspend fun validateContainerSerialNumberTivoPFR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("containerSerialNumber") containerSerialNumber: String,
        @Query("taskUom") taskUom: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("palletNumber") palletNumber: String,
        @Query("containerNumber") containerNumber: String,
    ): Response<ValidatePalletContainerSerialNumberTivoReverseResponse>

    @PATCH("v1/taskreservepickcomplete")
    suspend fun markTaskCompleteTivoPFRPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body request: MarkTaskCompleteRequestTivoPFR
    ): Response<MarkTaskCompleteResponseTivoPFR>


    @GET("v1/lotnumbers")
    suspend fun validateLotNumberTivoPFR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("FCY_ID") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("batchNumber") batchNumber: String,
        @Query("itemName") itemName: String,
        @Query("itemId") itemId: Int
    ): Response<ValidateLotNumberResponse>


    @GET("v1/lotnumbers")
    suspend fun validateLotNumberWithASN(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("FCY_ID") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("batchNumber") batchNumber: String,
        @Query("itemName") itemName: String,
        @Query("itemId") itemId: Int,
        @Query("asnId") asnId: Int,
        @Header("isASN") isASN: Boolean,
        @Query("itemLevelReceiving") itemLevelReceiving: Boolean,
    ): Response<ValidateLotNumberResponse>


    @GET("v1/lotnumbers")
    suspend fun validateLotNumberFromLotMaster(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("itemName") itemName: String
    ): Response<ValidateLotNumberResponse>

    /* ------------------- end here --------------------*/
    /**
     * Endpoint to validate/get location details
     */
    @GET("v1/locations")
    suspend fun validateLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String,
        @Query("locationClass") locationClass: String
    ): Response<LocationClassRes>


    /**
     * Endpoint to validate/get container details putaway userdirected
     */
    @GET("v1/containers/validatepalletcontainers")
    suspend fun validateContainerPutawayUserDirected(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("putAwayType") putAwayType: String,
        @Query("userDirected") userDirected: Boolean,
        @Query("containerType") containerType: String,
        @Query("includeCCLocation") includeCCLocation: String,
        @Query("recallLockExists") recallLockExists: Boolean,
    ): Response<UserDirectedPutawayContainerResponse>

    /**
     * Endpoint to submit userdirected putaway
     */
    @POST("v1/putaway/userdireted")
    suspend fun submitUserDirectedPutaway(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body requestBody: UserDirectedPutawaySubmitRequest
    ): Response<UserDirectedPutawaySubmitResponse>

    /*Inventory transfer*/
    @GET("v1/inventory/transfer/slp/{slp}")
    suspend fun inventoryTransferSlpResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("slp") containerNum: String,
        @Query("custId") custId: String,
        @Query("fcyId") fcyId: String,
        @Query("buId") buId: String,
        @Query("includeCCLocation") includeCCLocation: String
    ): Response<InventoryTransferSlpInquiryResponse>


    @PATCH("v1/inventory/transfer/slp")
    suspend fun inventoryTransferLocationResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryTransferLocationRequest: InventoryTransferLocationRequest
    ): Response<InventoryTransferLocationResponse>

    /*Inventory transfer*/

    @PATCH("v1/packing/palletize")
    suspend fun palletizeContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body palletizeContainerRequest: PalletizeContainerRequest
    ): Response<PalletizeContainerResponse>

    @GET("v1/inventory/packout")
    suspend fun getPalletizeContainerPallet(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("palletNumber") palletNumber: String,
        @Query("ibPalletize") ibPalletize: Boolean
    ): Response<PalletizeContainerPalletResponse>


    @GET("v1/containers")
    suspend fun getPalletizeContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("itemInfo") itemInfo: String
    ): Response<InventoryContainerResponse>


    @GET("v1/inventory/lockcodes")
    suspend fun getInventoryLockCodes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int
    ): Response<InventoryLockCodeResponse>

    /*Inventory transfer container detail*/
    @GET("v1/inventory/transfer/container")
    suspend fun inventoryTransferContainerResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("containerNbr") containerNbr: String,
        @Query("custId") custId: String,
        @Query("fcyId") fcyId: String,
        @Query("buId") buId: String,
        @Query("includeCCLocation") includeCCLocation: String,
        @Query("locClass") locClass: String? = null,
    ): Response<InventoryTransferContainerResponse>

    @GET("v1/inventory/transfer/containerReverseToForward")
    suspend fun inventoryTransferContainerReverseToForwardResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("containerNbr") containerNbr: String,
        @Query("custId") custId: String,
        @Query("fcyId") fcyId: String,
        @Query("buId") buId: String
    ): Response<InventoryTransferContainerResponse>


    /*Inventory transfer container location patch*/
    @PATCH("v1/inventory/transfer/container")
    suspend fun inventoryTransferContainerLocationResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryTransferContainerLocationRequest: InventoryTransferContainerLocationRequest
    ): Response<InventoryTransferLocationResponse>

    @GET("v1/inventory/transfer/slp/{slp}")
    suspend fun getInventoryTransferSlpInquiry(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("slp") slp: String,
        @Query("custId") customer: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("includeCCLocation") includeCCLocation: String
    ): Response<InventoryTransferSlpInquiryResponse>

    @GET("v1/inventory/transfer/container")
    suspend fun inventoryTransferContainerInquiryResponse(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("containerNbr") containerNbr: String,
        @Query("custId") custId: String,
        @Query("fcyId") fcyId: String,
        @Query("buId") buId: String,
        @Query("includeCCLocation") includeCCLocation: String,
    ): Response<InventoryTransferContainerInquiryResponse>

    @GET("v1/inventory/transfer/serial/{serial}")
    suspend fun getInventoryTransferSerialInquiry(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("serial") serial: String,
        @Query("custId") custId: String,
        @Query("fcyId") fcyId: String,
        @Query("buId") buId: String,
        @Query("includeCCLocation") includeCCLocation: String
    ): Response<InventoryTransferSlpInquiryResponse>

    @GET("v1/inboundshipment/palletinquiry")
    suspend fun getASNInquiryPalletDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        //   @Header("asnId") asnId: Int,
        @Header("container") container: String,
    ): Response<ASNPalletInquiryResponse>

    @PATCH("v1/inventorymaster/locksandadjustment")
    suspend fun inventoryIbPalletAdjustment(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryAdjustmentRequest: InventoryIbPalletAdjustmentRequest
    ): Response<InventoryPalletLockUnlockResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getPalletDetail(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("palletNumber") palletNumber: String
    ): Response<PalletAdjustmentDetailResponse>

    @GET("v1/inventoryLocksList")
    suspend fun getLockList(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("container_id") containerId: Long,
        @Query("containerType") containerType: String
    ): Response<LockListResponse>

    @PATCH("v1/inventorymaster/locksandadjustment")
    suspend fun inventoryIbPalletLockUnlockAdjustment(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body inventoryIbPalletLockUnlockAdjustmentRequest: InventoryIbPalletLockUnlockAdjustmentRequest
    ): Response<InventoryPalletLockUnlockResponse>

    @POST("rlog/api/v1/putaway/containerId")
    suspend fun mixedSBPutawayValidateToContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body msbPutawayRequest: MSBPutawayRequest
    ): Response<MSBPutawayResponse>

    @POST("rlog/api/v1/putaway/locationId")
    suspend fun mixedSBPutawayValidateToLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body msbPutawayRequest: MSBPutawayRequest
    ): Response<MSBPutawayResponse>

    @POST("rlog/api/v1/putaway/validateserialnum")
    suspend fun mixedSBPutawayValidateSerialNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body msbPutawayRequest: MSBPutawayRequest
    ): Response<MSBPutawayResponse>

    @POST("rlog/api/v1/putaway/doPutaway")
    suspend fun mixedSBPutawaySubmit(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body msbPutawayRequest: MSBPutawayRequest
    ): Response<MSBPutawayResponse>

    @GET("v1/inventory/transfer/casepallet")
    suspend fun getPalletDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("container") palletNumber: String,
        @Header("transferType") transferType: String
    ): Response<PalletDetailResponse>

    @GET("v1/inventory/transfer/casepallet")
    suspend fun getPalletDetailsForCombine(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("container") palletNumber: String,
        @Header("transferType") transferType: String,
        @Header("combineBy") combineBy: String
    ): Response<PalletCombineDetailResponse>

    @POST("v1/inventory/loadtransfer")
    suspend fun confirmDestinationLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body requestBody: PalletTransferRequest
    ): Response<PalletTransferResponse>

    @PATCH("v1/inventory/pallet/combine")
    suspend fun combinePallet(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Body requestBody: CombinePalletRequest
    ): Response<CombinePalletResponse>


    @POST("v1/inventory/loadtransfer")
    suspend fun confirmSplitDestinationLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body requestBody: PalletTransferSplitRequest
    ): Response<PalletTransferResponse>


    @GET("v1/inventory/generatenumber")
    suspend fun generatePalletNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("type") type: String
    ): Response<PalletGenerateResponse>

    @GET("v1/inventory/transfer/casepallet")
    suspend fun caseTransferValidateContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("container") container: String,
        @Header("transferType") transferType: String,
    ): Response<CaseTransferContainerResponse>

    @GET("v1/inventory/generatenumber")
    suspend fun generatePalletCaseNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("type") type: String
    ): Response<CaseTransferPalletGenerateResponse>

    @POST("v1/inventory/loadtransfer")
    suspend fun caseTransferSubmitDestinationLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body caseTransferSubmitRequest: CaseTransferSubmitRequest,
    ): Response<CaseTransferSubmitResponse>

    @GET("v1/inventory/itemserialnumber")
    suspend fun validateItemCode(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("serial") itemCode: String,
    ): Response<MasterPalletRepackItemCodeResponse>

    @GET("v1/printerconfig")
    suspend fun masterPalletRepackGetPrintRequestorList(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("page") page: Int,
        @Query("pageLimit") pageLimit: Int,
        @Query("printerType") printerType: String,
    ): Response<PrintRequesterResponse>

    @GET("v1/task/rf/txparam")
    suspend fun masterPalletRepackGetTransactionParam(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("transCode") transCode: String,
    ): Response<MPRepackTransParamResponse>

    @GET("v1/task")
    suspend fun cycleCountTaskAssignedCheck(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("taskType") taskType: String,
//        @Query("status") status: Long,
        @Query("assignedTo") assignedTo: String,
    ): Response<CycleCountTaskDetailResponse>

    @PATCH("v1/cyclecount/createOrUpdateCCDetails")
    suspend fun cycleCountTaskAssignUpdate(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("locationId") locationId: Int,
    ): Response<CycleCountTaskDetailResponse>

    @GET("v1/inventory/masterpalletstage")
    suspend fun masterPalletRepackValidateTempTable(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("pallet") pallet: String,
        @Header("container") container: String,
    ): Response<MasterPalletRepackTempContainerResponse>


    @POST("v1/inventory/masterpalletstage")
    suspend fun masterPalletRepackPostTempTable(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Body palletRepackPostRequest: PalletRepackPostRequest,
    ): Response<MasterPalletRepackTempContainerResponse>

    @POST("v1/inventory/tmpcontainerlabel")
    suspend fun masterPalletRepackPrintContainerLabel(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Body printContainerLabelRequest: PrintContainerLabelRequest,
    ): Response<PrintContainerLabelResponse>

    @POST("v1/inventory/masterpalletrepack")
    suspend fun masterPalletRepackSubmit(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body mprSubmitRequest: MPRSubmitRequest,
    ): Response<MPRSubmitResponse>

    @POST("v1/inventory/ibcontainerize")
    suspend fun createIBContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body cibPostRequest: CIBPostRequest,
    ): Response<CIBPostResponse>

    @PATCH("v1/inventory/renamePallet")
    suspend fun renamePalletNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body renamePalletRequest: RenamePalletRequest
    ): Response<RenamePalletResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getCIBContainerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String
    ): Response<PalletAdjustmentDetailResponse>

    @GET("v1/items")
    suspend fun getCIBItemDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("customerId") customerId: Int,
        @Query("itemNames") itemName: String,
    ): Response<CIBItembarcodeResponse>


    @POST("v1/inventory/ibpalletize")
    suspend fun palletizeIBSubmitAPI(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body palletizeIbSubmitRequest: PalletizeIbSubmitRequest
    ): Response<PalletizeIbSubmitResponse>

    @GET("v1/items/validateUpcOrSlp")
    suspend fun validateUPCorSLP(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("itemCode") itemCode: String,
        @Query("upcOrSlp") upcOrSlp: String,
    ): Response<UpcOrSlpResponse>

    @PATCH("v1/inboundshipment/renamePallet")
    suspend fun renameASNPalletNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body renamePalletRequest: ASNRenamePalletRequest
    ): Response<RenamePalletResponse>

    @POST("v1/inboundshipment/printPalletCaseLabel")
    suspend fun printASNPalletLabel(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body asnPrintPalletRequest: ASNPrintPalletRequest
    ): Response<ASNPalletInquiryPrintLabelResponse>


    @GET("v1/taskbuildskip")
    suspend fun ltlSkipTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("allocationType") allocationType: String?,
        @Query("skipTaskId") skipTaskId: String?,
        @Query("skipTaskDetId") skipTaskDetId: String?,
        @Query("isLTLcubing") isLTLcubing: Boolean,
        @Query("orderType") orderType: String? = null
    ): Response<SkipPickCartRes>

    @PATCH("v1/shipments/flare/printdocandlabelshpmgmt")
    suspend fun printPalletNew(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printPalletRequestNew: PrintPalletRequestNew
    ): Response<PrintDocAndLabelResponse>

    @POST("v1/cyclecountdetails")
    suspend fun updateScannedPalletsDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body cycleCountDetails: CycleCountDetailRequest
    ): Response<CCDetailsUpdateResponse>


    @GET("v1/containers")
    suspend fun getValidateContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("pageLimit") pageLimit: Int,
        @Query("excludeLocationInfo") excludeLocationInfo: Boolean,
        @Query("containerType") containerType: String
    ): Response<InventoryContainerResponse>

    @GET("v1/task/shortpickedtotes")
    suspend fun getShortPickedTotes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("allocationType") allocationType: String?,
        @Query("cartNumber") cartNumber: String,
        @Query("cartId") cartId: Int
    ): Response<ShortPickToteResponse>

    @PATCH("v1/task/transferTotetoPR")
    suspend fun transferTotePR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body validateToteReq: ValidateToteCartonReq
    ): Response<ValidateToteRes>

    @GET("v1/task/prlocationtote")
    suspend fun prToteDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("toteNumber") toteNumber: String,
    ): Response<PRToteResponse>

    @GET("v1/task/prlocationtoteForKitting")
    suspend fun kitPrToteDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("toteNumber") toteNumber: String,
        @Query("workOrderNumber") workOrderNumber: String,
    ): Response<PRToteResponse>

    @GET("v1/pack/carton/hold")
    suspend fun getPackStationToteDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("toteOrCartonNo") toteOrCartonNo: String,
    ): Response<PackStationToteResponse>

    @PATCH("v1/task/transferPRToteToStgLoc")
    suspend fun updatePackStationToPRLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body packStationToteToPRLocationRequest: PackStationToteToPRLocationRequest
    ): Response<PickingSerialResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getLocationInquiry(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("locationBarCode") locationBarcode: String,
        @Query("containerNumber") containerNumber: String,
        @Query("itemId") itemId: String
    ): Response<CCLocationInquiryResponse>

    @GET("v1/inventorymaster")
    suspend fun getContainerInquiry(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") custId: Int,
        @Header("bu_id") buId: Int,
        @Header("fcy_id") fcyId: Int,
        @Header("container_id") containerId: String,
        @Header("item_id") itemId: String,
        @Header("itemInfo") itemInfo: String
    ): Response<InventoryMasterResponse>

    @GET("v1/inventorymaster")
    suspend fun getLocationInquiryWithContainerInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") custId: Int,
        @Header("bu_id") buId: Int,
        @Header("fcy_id") fcyId: Int,
        @Header("location_id") locationId: String,
        @Header("itemInfo") itemInfo: String
    ): Response<InventoryMasterMultipleResponse>

    @GET("v1/inventorymaster/count")
    suspend fun getLocationInventoryCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cust_id") custId: Int,
        @Query("bu_id") buId: Int,
        @Query("fcy_id") fcyId: Int,
        @Query("location_id") locationId: String?,
        @Query("palletId") palletId: Int? = null
    ): Response<LocationInventoryCount>

    @GET("v1/inventory/templpns")
    suspend fun getLpnsInTempTable(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("location_id") locationId: Long,
    ): Response<TempLpnsResponse>

    @PATCH("v1/task/transferPRToteToStgLoc")
    suspend fun updatePRLocToPackStation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body prToteStageReq: PRToteStageReq
    ): Response<PickingSerialResponse>

    @PATCH("v1/task/transferPRTotetokitstagingloc")
    suspend fun updatePRLocToKitStaging(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body prToteStageReq: PRToteStageReq
    ): Response<PickingSerialResponse>

    @GET("v1/lookups?active=Y&lookupNames=ENABLE_CC_QTY_CAPTURE")
    suspend fun getEnableQtyCapture(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int,
    ): Response<LookUps>

    @GET("v1/lookups?active=Y&lookupNames=CC_PALLET_CONTAINER_SCANNING")
    suspend fun getEnableContainerScanning(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int,
    ): Response<LookUps>

    @GET("v1/lookups")
    suspend fun getLookUps(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("cusId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("lookupNames") lookupNames: String
    ): Response<LookUps>

    @GET("v1/locationsInquiry")
    suspend fun getDestinationLocationInfo(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("locBarCode") locBarCode: String,
        @Query("locClass") locClass: String
    ): Response<LocationInquiryResponse>

    @GET("v1/inventory/movement/casepallet")
    suspend fun kittingValidateContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("containerNbr") containerNbr: String,
        @Header("locationClass") locationClass: String,
    ): Response<KittingContainerResponse>

    @GET("v1/inventory/movement/kitstation")
    suspend fun validateKitStation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        @Header("locationBarcode") locationBarcode: String,
        @Header("locationClass") locationClass: String
    ): Response<KittingContainerResponse>

    @GET("v1/orders/workorderbom")
    suspend fun kittingItemDescription(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        @Query("containerId") containerId: Int
    ): Response<KittingDescriptionResponse>

    @POST("v1/inventory/transaction/movement/kitting")
    suspend fun validateKittingComplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body kittingCompleteRequest: KittingCompleteRequest
    ): Response<KittingCompleteResponse>

    @POST("v1/inventory/transaction/movement/kitstation")
    suspend fun inventoryMoveKSToKS(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body kittingCompleteRequest: KittingCompleteRequest
    ): Response<KittingCompleteResponse>

    @GET("v1/printerconfig")
    suspend fun getPrintRequestorListForPackout(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("page") page: Int,
        @Query("pageLimit") pageLimit: Int,
        @Query("printerType") printerType: String,
    ): Response<PrintRequesterResponse>

    @GET("/v1/orders/ordProcessLoc")
    suspend fun getPrinterForTheKitStation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("locationId") locationId: Int,
    ): Response<KitStationLocationResponse>

    @POST("v1/inventory/printCaselabels")
    suspend fun printCaseLabelsFromPackout(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header("fscUser") fscUser: Int,
        @Header("cust_id") custId: Int,
        @Header("bu_id") buId: Int,
        @Header("fcy_id") fcyId: Int,
        @Body printCaseLabelPackoutReq: PrintCaseLabelPackoutReq
    ): Response<PrintCaseLabelResponse>

    @GET("v1/inventory/validateSerialNumberOrItemCode")
    suspend fun validateSerialNumberWithItemCodeForPicking(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("serialNumberOrItemCode") serialNumberOrItemId: String,
        @Query("outBoundOnly") isOutBoundOnly: Boolean,
        @Query("pickLocationId") pickLocationId: Long,
        @Query("itemId") itemId: Int,
        @Query("taskId") taskId: Long,
        @Query("containerNbr") containerNbr:String,
        @Query("containerId") containerId:Int
    ): Response<PickingSerialOrItemCodeResponse>

    @GET("v1/inventory/validateSerialNumberOrItemCode")
    suspend fun validateSerialNumberWithItemCodeForContainerPicking(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("serialNumberOrItemCode") serialNumberOrItemId: String,
        @Query("outBoundOnly") isOutBoundOnly: Boolean,
        @Query("pickLocationId") pickLocationId: Long,
        @Query("itemId") itemId: Int,
        @Query("containerId") containerId: Int
    ): Response<PickingSerialOrItemCodeResponse>


    @GET("v1/orders/workorders/workOrderStatus")
    suspend fun getWorkOrderStatus(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("kitLocationId") kitLocationId: Int,
    ): Response<workOrderStatusResponse>

    @PATCH("v1/packqtyconfirm")
    suspend fun confirmPackQty(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body packingConfirmQtyRequest: PackingConfirmQtyRequest
    ): Response<PackingConfirmQtyResponse>

    @GET("v1/inventory/validateSerialNumberOrItemCode")
    suspend fun validateSerialNumberOrItemCode(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("serialNumberOrItemCode") serialNumberOrItemCode: String,
        @Query("responseFilter") responseFilter: String,
        @Query("isPackStation") isPackStation: Boolean,
    ): Response<PackingValidateSerialNumberResponse>


    @PATCH("v1/pack/hold")
    suspend fun sendToPR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body request: SendToPRRequest
    ): Response<SendToPRResponse>

    @POST("v1/pack")
    suspend fun printPackedItem(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printLabelRequest: PrintLabelRequest
    ): Response<PrintLabelResponse>

    @PATCH("v1/pack")
    suspend fun manifest(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body manifestRequest: ManifestRequest,
    ): Response<ManifestAPIResponse>


    @PATCH("v1/pack")
    suspend fun demanifest(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body manifestRequest: DeManifestRequest,
    ): Response<ManifestAPIResponse>

    @GET("v1/pack")
    suspend fun pack(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("toteNumber") toteNumber: String,
        @Query("obContainerNumber") obContainerNumber: String,
    ): Response<PackingPackResponse>


    @GET("v1/cartontypes")
    suspend fun cartontypes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
    ): Response<CartonTypesResponse>

    @GET("v1/printerconfig")
    suspend fun getPackStationList(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("page") page: Int,
        @Query("pageLimit") pageLimit: Int,
    ): Response<PrintRequesterResponse>

    @GET("v1/lookups?active=Y&lookupNames=PACK_METHOD_LIST")
    suspend fun getPackMethodList(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int,
    ): Response<LookUps>

    @GET("v1/lookups?active=Y&lookupNames=FEDEX_SHIP_VIA")
    suspend fun getShipmentMethods(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int,
    ): Response<LookUps>

    @PATCH("v1/task/outbound/override")
    suspend fun validatePalletOverride(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Body validatePalletOverrideRequest: ValidatePalletOverrideRequest
    ): Response<ValidatePalletOverrideResponse>

    @PATCH("v1/task/outbound/override")
    suspend fun validatePalletOverride(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Body validateCaseOverrideRequest: ValidateCaseOverrideRequest
    ): Response<ValidatePalletOverrideResponse>

    @GET("v1/inboundshipment/flare/over-receipt/validate")
    suspend fun validateOverReceipt(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("asnId") asnId: Int,
        @Query("itemId") itemId: Int,
        @Query("qty") qty: Int,
        @Query("invType") invType: String?,
        @Query("lotNumber") lotNumber: String?,
    ): Response<ValidateOverReceiptResponse>

    @GET("v1/inventory/validateLotOrMfgCode")
    suspend fun validateLotOrMfgCodeRequest(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("lotOrMfgCode") lotOrMfgCode: String,
        @Query("item_id") itemId: Int
    ): Response<ValidateLotOrMfgCodeResponse>

    @POST("v1/cyclecount/createTasksForLocationIds/{locationId}")
    suspend fun generateCycleCountToVerifyZeroLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Path("locationId") locationId: Long,
        @Body cycleCountTriggerRequest: CycleCountTriggerRequest
    ): Response<CycleCountTriggerResponse>

    @GET("v1/inventorymaster/zero-loc-prompt/eligible")
    suspend fun zeroLocationPromptCall(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcy_id") fcy_id: Int,
        @Query("bu_id") bu_id: Int,
        @Query("cust_id") cust_id: Int,
        @Query("location_id") location_id: Long,
        @Query("skip_pallet_id") skip_pallet_id: List<Long>
    ): Response<ZeroLocationPromptResp>

    @POST("v1/cyclecount/summary/location/validate")
    suspend fun validateCCLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body ccByLocationInEachesReq: CCByLocationInEachesLocationRequest
    ): Response<CCByLocationInEachesLocationResponse>

    @POST("v1/cyclecount/{ccHeaderId}/summary/container/validate")
    suspend fun validateCCContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("ccHeaderId") ccHeaderId: String,
        @Body ccByLocationInEachesContainerRequest: CCByLocationInEachesContainerRequest
    ): Response<CCByLocationInEachesContainerResponse>

    @PATCH("v1/cyclecount/{ccHeaderId}/summary/qty")
    suspend fun validateCCQty(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("ccHeaderId") ccHeaderId: String,
        @Body ccByLocationInEachesQtyRequest: CCByLocationInEachesQtyRequest
    ): Response<CCByLocationInEachesQtyResponse>

    @PATCH("v1/cyclecount/{ccHeaderId}/summary/end/{ccMode}")
    suspend fun endSummaryLevelCycleCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("ccHeaderId") ccHeaderId: String,
        @Path("ccMode") ccMode: String,
        @Body ccByLocationInEachesEndCCReq: CCByLocationInEachesEndCCRequest
    ): Response<CCByLocationInEachesEndCycleCountResponse>

    @GET("v1/locations")
    suspend fun getLocationDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: String,
        @Query("customerId") customerId: Int,
        @Query("facility") facility: Int,
        @Query("barcode") barcode: String? = null,
        @Query("locationClass") locationClass: String? = null,
        @Query("locationStatus") locationStatus: String = "All"
    ): Response<LocationDetailsResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getLocationInventory(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") cusId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("locationBarCode") locationBarCode: String,
        @Query("page") page: Int?,
        @Query("pageLimit") pageLimit: Int?
    ): Response<LocationInventoryResponse>

    @GET("v1/inventory/containerinquiry")
    suspend fun getPalletInventory(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("palletNumber") palletNumber: String,
        @Query("page") page: Int?,
        @Query("pageLimit") pageLimit: Int?
    ): Response<PalletAdjustmentDetailResponse>

    @GET("rlog/api/v1/inquiry/locationinquiry")
    suspend fun rlogLocationInquiry(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("Customer") customer: Int,
        @Header("Warehouse") warehouse: Int,
        @Query("locationBarcode") locationBarcode: String,
    ): Response<RlogLocationInquiryResp>

    @POST("rlog/api/v1/putaway/validateupc")
    suspend fun validateUPC(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body validateUpcRequest: ValidateUpcRequest
    ): Response<ValidateUpcResponse>


    @GET("v1/inventorymaster/deKitPackout")
    suspend fun deKitPackout(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcyId") fcyId: Int,
        @Query("kitLocationId") kitLocationId: Int
    ): Response<DekitPackoutResponse>

    @GET("v1/physicalinventory/batchsummary")
    suspend fun getBatchSummary(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("assignedTo") assignedTo: Int,
        @Query("batchNumber") batchNumber: String?,
        @Query("skipBatchId") skipBatchId: String?,
        @Query("countType") countType: String?
    ): Response<BatchSummaryResp>

    @PATCH("v1/physicalinventory/assignBatch")
    suspend fun getBatchTaskDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: String,
        @Body assignBatchReq: AssignBatchReq
    ): Response<BatchTaskDetailsResp>

    @PATCH("/v1/physicalinventory/updateTask")
    suspend fun updateBatchTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: String,
        @Body updateBatchTaskReq: UpdateBatchTaskReq?
    ): Response<BatchTaskDetailsResp>

    @GET("v1/containers")
    suspend fun getCaseDetailsByPallet(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("parentContainerId") parentContainerId: String,
        @Query("excludeLocationInfo") excludeLocationInfo: Boolean,
        @Query("itemInfo") itemInfo: String
    ): Response<InventoryContainerResponse>

    @GET("rlog/api/v1/inquiry/scaninquiry")
    suspend fun validateSlp(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("Warehouse") warehouse: Int,
        @Header("Facid") facid: Int,
        @Header("Customer") customer: Int,
        @Query("scnLp") scnLp: String,
        @Query("itemSizeSLP") itemSizeSLP: String
    ): Response<UtilitySlpResponse>

    @GET("v1/lookups?active=Y&lookupNames=PRODUCT_SIZES")
    suspend fun getProductSizesLookup(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int,
    ): Response<LookUps>

    @PUT("rlog/api/v1/scans/updateSlpItemSize")
    suspend fun updateItemSizeBySlp(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("WAREHOUSE") warehouse: Int,
        @Header("BUID") buId: Int,
        @Header("CUSTOMER") customer: Int,
        @Query("slp") slp: String,
        @Query("size") size: String
    ): Response<UpdateItemSizeBySLPResponse>

    @POST("rlog/api/v1/scans/validate/slp")
    suspend fun updateItemSizeBySlp(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("Warehouse") warehouse: Int,
        @Header("BUID") buId: Int,
        @Header("Customer") customer: Int,
        @Body updateItemSizeBySLPRequest: UpdateItemSizeBySLPRequest
    ): Response<UpdateItemSizeBySLPResponse>

    @GET("v1/inventory/validateSerialNumberOrItemCode")
    suspend fun validatePISerialNumberWithItemCode(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("itemId") itemId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Query("serialNumberOrItemCode") serialNumberOrItemId: String,
        @Query("outBoundOnly") isOutBoundOnly: Boolean
    ): Response<PickingSerialOrItemCodeResponse>

    @GET("v1/customers")
    suspend fun getCustomerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("responseFilter") fcyId: String = Constants.CustomersApi.DETAILS_FILTER,
        @Query("customerId") customerId: Int,
    ): Response<CustomerDetails>

    @GET("v1/inventory/movement/container/validate")
    suspend fun getSourceDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Long,
        @Query("containerNumber") containerNumber: String
    ): Response<SourceDetailResponse>

    @GET("v1/inv-movement/reason-codes")
    suspend fun getReasonCodes(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Query("sourceLocationClass") sourceLocationClass: String,
        @Query("containerType") containerType: String,
        @Query("itemCategory") itemCategory: String,
        @Query("fetchBySrc") fetchBySrc: Boolean,
        @Query("destLocationCls") destLocationCls: String
    ): Response<ReasonCodesResponse>

    @GET("v1/inventory/movement/destination-location")
    suspend fun getDestinationLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Query("containerNbr") containerNbr: String,
        @Query("reasonCode") reasonCode: String
    ): Response<GetDestinationLocationResponse>

    @POST("v1/inventory/movement")
    suspend fun submitDestinationLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Body validateUpcRequest: SubmitDestinationLocationRequest
    ): Response<SubmitDestinationLocationResponse>

    @GET("v1/containers")
    suspend fun getContainerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("containerNumber") containerNumber: String,
        @Query("itemInfo") itemInfo: String,
        @Query("fetchChild") fetchChild: Boolean,
    ): Response<InventoryContainerResponse>

    /**
     * Prescan GET And PUT API calls
     *
     */
    @GET("v1/prescan/rma")
    suspend fun validateRMANumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") cust_id: Int,
        @Header("custid") custid: Int,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("rmaNumber") rmaNumber: String,
        @Query("page") page: Int,
        @Query("pageLimit") pageLimit: Int
    ): Response<PreScanValidateRMAResponse>

    @POST("v1/prescan/rma")
    suspend fun createShipmentRMANumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("cust_id") cust_id: Int,
        @Body createShipmentRequest: CreateShipmentRequest
    ): Response<CreateShipmentResponse>


    @GET("/rlog/api/v1/returntype/getReturnTypes/{Facid}/{custId}/{scan}")
    suspend fun getReturnType(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Path("Facid") facid: Int,
        @Path("custId") custId: Int,
        @Path("scan") scan: String
    ): Response<PrescanReturnTypeResponse>

    @GET("/v1/vendors")
    suspend fun getVendor(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("customerId") customerId: Int,
        @Query("vendorName") vendorName: String,
        @Query("active") active: Int
    ): Response<PrescanGetCustomerDetailsResponse>

    @GET("v1/lookups?active=Y&lookupNames=FLARE_LTL_TL_CARRIER_CODE&lookupCode=undefined")
    suspend fun getPrescanCarrierSCAC(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int
    ): Response<LookUps>


    @GET("v1/lookups?active=Y&lookupNames=PRESCAN_DEFAULT_VENDOR&lookupNames=RETURN_TYPES")
    suspend fun getPrescanDefaultVendor(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("cusId") custId: Int,
        @Query("buId") buId: Int
    ): Response<LookUps>

    @POST("v1/task/complete/{taskType}")
    suspend fun invmTaskComplete(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("taskType") taskType: String?,
        @Body invmTaskCompleteRequest: InvmTaskCompleteRequest
    ): Response<TaskPickResponse>

    @POST("v1/inboundshipment/printPalletCaseLabel")
    suspend fun printPalletLabel(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body palletPrinterReq: PalletPrinterReq
    ): Response<ASNPalletInquiryPrintLabelResponse>

    @GET("/v1/inboundshipments/validatetracking")
    suspend fun validateTrackingNumber(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("trackingNumber") trackingNumber: String
    ): Response<ValidateTrackingNumberResponse>

    @PATCH("v1/taskpick")
    suspend fun getICPTaskPick(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body taskPickReq: ICPTaskRequest
    ): Response<ICPSystemTask>

    @GET("v1/pack")
    suspend fun getCartonDetailsFromTote(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("toteNumber") toteNumber: String,
        @Query("obContainerNumber") obContainerNumber: String,
        @Query("packMethod") packMethod: String
    ): Response<CartonDetailResponse>

    @GET("v1/cartonhandler/{cartonNbr}/validate/{type}")
    suspend fun fetchObCartonDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("cartonNbr") cartonNbr: String,
        @Path("type") type: String,
        @Query("responseLevel") responseLevel: String
    ): Response<ValidateCartonHandlerTypeResponse>

    @POST("v1/cartonhandler/split-transform/{type}")
    suspend fun transformObToIbCarton(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("type") type: String,
        @Body transformObToIbCartonRequest: TransformObToIbCartonRequest
    ): Response<TransformObToIbCartonResponse>

    @GET("v1/cartonhandler/lock/{lock}/containers")
    suspend fun fetchRecallLockOBContainerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("lock") lock: String,
        @Query("palletNbr") palletNbr: String
    ): Response<OBCartonRCLockResponse>

    @PATCH("v1/inventory/stage-pr")
    suspend fun inventoryStagePrReCall(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Header("buId") buId: Int,
        @Header("custId") custId: Int,
        @Body inventoryStageToPrRequest: InventoryStageToPrRequest
    ): Response<InventoryStageToPrResponse>

    @PATCH("v1/pack/void-pack")
    suspend fun unpack(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("custId") custId: Int,
        @Header("buId") buId: Int,
        @Header("fcy_id") fcyId: Int,
        @Body unpackRequest: UnPackRequest
    ): Response<UnPackResponse>

    @POST("v1/activity/events")
    suspend fun postTransactionEvents(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body fscTrackerModel: FSCTrackerListModel?
    ): Response<FSCTrackerResponse>

    @GET("v1/cartonhandler/lock/{lock}/containers")
    suspend fun fetchRecallLockOBContainerDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("lock") lock: String,
        @Query("dockDoorId") dockDoorId: Int
    ): Response<OBCartonRCLockResponse>

    @GET("v1/cyclecount/pending/containers")
    suspend fun getCountPendingContainers(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("custId") custId: Int,
        @Query("buId") buId: Int,
        @Query("fcyId") fcyId: Int,
        @Query("locationId") locationId: Int,
        @Query("ccHeaderId") ccHeaderId: Int,
        @Query("itemId") itemId: Int,
        @Query("lotNumber") lotNumber: String?,
        @Query("invType") invType: String?,
        @Query("palletNbr") palletNbr: String?,
        @Query("palletId") palletId: Int?,
        @Query("palletLocationId") palletLocationId: Int?
    ): Response<CountPendingResponse>

    @PATCH("v1/cyclecount/virtual-containers")
    suspend fun updateVirtualContainersCount(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body updateVirtualContainersCountRequest: UpdateVirtualContainersCountRequest
    ): Response<UpdateVirtualContainersCountResponse>

    @GET("v1/taskbuildskip")
    suspend fun palletConsolidationTaskSkip(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Query(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Query(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Query(ICPConstants.ICP_SKIP_TASK_ID) skipTaskId: Int,
        @Query(ICPConstants.ICP_ALLOCATION_TYPE) allocationType: String = "130",
        @Query(ICPConstants.ICP_PICK_CART_NBR) pickCartNbr: String = "",
        @Query(ICPConstants.ICP_IS_LTL_FLOW) isLTLFlow: Boolean = false,
    ): Response<ICPSystemTask>

    @POST("v1/task/complete/ICP")
    suspend fun completeICPTak(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Body icpCompleteRequest: ICPCompleteRequest
    ): Response<ICPTaskComplete>

    @GET("v1/task/grouped")
    suspend fun fetchGroupedTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @QueryMap queryMap: Map<String, String>
    ): Response<GroupedTaskResponse>

    @PATCH("v1/task/grouped/pick")
    suspend fun pickGroupedTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Body pickGroupedTaskRequest: PickGroupedTaskRequest
    ): Response<GroupedTaskResponse>

    @PATCH("v1/shipments/load/hold")
    suspend fun sendPalletToPR(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body request: SendPalletToPRRequest
    ): Response<SendToPRResponse>

    @POST("/v1/task/getRepairTaskRf")
    suspend fun getRepairTaskRf(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Body moveTaskRequest: GetRepairTaskRf
    ): Response<GetMoveTaskRfResponse>

    @POST("v1/task/updateRepairTaskDetailsRf")
    suspend fun updateMoveTaskDetailsRf(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Body moveTaskRequest: UpdateMoveTaskDetailsRequest
    ): Response<GetMoveTaskRfResponse>

    @POST("v1/repair/task/printRepairTaskLabel")
    suspend fun printPartsReplacementRf(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body printTaskLabelRequest: PrintTaskLabelRequest
    ): Response<LabelPrintingResponse>

    @POST("v1/task/completeRepairTaskRf")
    suspend fun completeMoveTaskRf(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Query("fcyId") fcyId: Int,
        @Query("buId") buId: Int,
        @Query("custId") custId: Int,
        @Body moveTaskRequest: CompleteMoveTaskRf
    ): Response<GetMoveTaskRfResponse>

    @POST("/v1/task/initiateRepairFlow")
    suspend fun initiateRepairFlow(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Body repairTaskRequest: RepairTaskRequest
    ): Response<RepairTaskResponse>

    @GET("service/documents/getNumOfPrints")
    suspend fun getInternationShipmentPrintDocs(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @QueryMap queryMap: Map<String, String>
    ): Response<InternationalPrintDocuments>

    @POST("service/documents/printDocument")
    suspend fun rePrintInternationalShipmentDocuments(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Body printOrderRequest: ReprintShipmentDocumentRequest
    ): Response<InternationalPrintDocumentsResponse>

    @PATCH("v1/shipments/flare/printdocandlabel")
    suspend fun printInternationalShipmentDocuments(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Body printOrderRequest: PrintShipmentDocumentRequest
    ): Response<PrintDocAndLabelResponse>

    @GET("v1/task/allocation-type/{cartNbr}")
    suspend fun getAllocationType(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) fedexId: String,
        @Header("fcyId") fcyId: Int,
        @Path("cartNbr") cartNbr: String
    ): Response<AllocationTypeResponse>

    @POST("v1/cyclecountdetails")
    suspend fun createCycleCountDetails(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body cycleCountDetails: UpdateCycleCountDetailsRequest
    ): Response<CreateCycleCountDetailResponse>

    @PATCH("v1/taskpick")
    suspend fun getReplenishDeliveryTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Body replenPickTaskRequest: TaskReplenRequest
    ): Response<ReplenishDeliveryTaskResponse>

    @GET("v1/taskbuildskip")
    suspend fun skipReplenishTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Query(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Query(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Query("allocationType") allocationType: String,
        @Query("skipTaskId") skipTaskId: String,
        @Query("skipTaskDetId") skipTaskDetId: String,
    ): Response<ReplenishDeliveryTaskResponse>

    @PATCH("v1/task/replen/{allocationType}")
    suspend fun completeReplenishDelivery(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Path("allocationType") allocationType: String,
        @Body requestPayload: ReplenTaskCompleteRequest
    ): Response<TaskReplenResponse>

    @GET("v1/facility/equipment-type")
    suspend fun getEquipmentType(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
    ):Response<GetEquipmentTypeResponse>

    @GET("v1/task/equipment/current-position")
    suspend fun getEquipmentCurrentPosition(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Query("equipmentNbr") equipmentNbr: String,
        @Query(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int
    ):Response<GetEquipmentCurrentPosition>

    @PATCH("v1/task/interleaving")
    suspend fun getInterLeaving(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Body getInterLeavingPayload: GetInterLeavingRequest
    ): Response<GetInterLeavingResponse>

    @PATCH("v1/task/interleaving/execute-task")
    suspend fun executeInterLeavingTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Body executeTaskRequest: ExecuteTaskRequest
    ): Response<GetInterLeavingResponse>

    @PATCH("v1/task/task-type/{taskType}/interleaving/register-location")
    suspend fun interLeavingResisterLocation(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Path("taskType") taskType: String,
        @Body registerLocationRequest: RegisterLocationRequest
    ): Response<ResisterLocationResponse>

    @PATCH("v1/task/task-type/{taskType}/interleaving/validate-container")
    suspend fun interLeavingValidateContainer(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Path("taskType") taskType: String,
        @Body getInterLeavingPayload: ValidateContainerRequest
    ): Response<GetInterLeavingResponse>

    @PATCH("v1/task/interleaving/end")
    suspend fun interLeavingEndTask(
        @Header(Constants.RequestHeaders.HEADER_AUTHORIZATION) gatewayToken: String,
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Body getInterLeavingPayload: InterLeavingEndTask
    ): Response<InterLeavingEndTaskResponse>

    @GET("v1/pack/toteCartonOrPalletDetails")
    suspend fun getMaterialMovementSourceDetails(
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyIdHeader: Int,
        @Header(Constants.RequestHeaders.HEADER_BU_ID) buIdHeader: Int,
        @Header(Constants.RequestHeaders.HEADER_CUST_ID) custIdHeader: Int,
        @Query(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Query(Constants.RequestHeaders.HEADER_BU_ID) buId: Int,
        @Query(Constants.RequestHeaders.HEADER_CUST_ID) custId: Int,
        @Query("toteOrCartonOrPalletID") toteOrCartonOrPalletID: String,
        @Query("movementType") movementType: String,
        @Query("transferTo") transferTo: String,
    ): Response<ContainerSourceDetail>

    @PATCH("v1/pack/transferToteOrCartonOrPallet")
    suspend fun transferToLocation(
        @Header(Constants.RequestHeaders.HEADER_FSC_USER) userId: Int,
        @Header(Constants.RequestHeaders.HEADER_FCY_ID) fcyId: Int,
        @Body transferToLocationRequest: TransferToLocationRequest
    ): Response<TransferToLocationResponse>
}
