package com.fsc.flare.ui.common

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.databinding.ItemSimpleTextBinding

class SimpleListAdapter(
    private val displayList: List<String>
) : RecyclerView.Adapter<SimpleListAdapter.SimpleListViewHolder>() {

    inner class SimpleListViewHolder(private val binding: ItemSimpleTextBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: String, isLastItem: Boolean) {
            binding.tvContent.text = item
            binding.vSeparator.visibility = if (isLastItem) View.GONE else View.VISIBLE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SimpleListViewHolder {
        val binding =
            ItemSimpleTextBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SimpleListViewHolder(binding)
    }

    override fun getItemCount() = displayList.size

    override fun onBindViewHolder(holder: SimpleListViewHolder, position: Int) {
        holder.bind(
            item = displayList[position], isLastItem = position == displayList.size - 1
        )
    }
}