package com.fsc.flare.ui.fragment.loadunloadtrailer.unloadtrailer

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogPalletLoadBinding
import com.fsc.flare.databinding.FragmentUnloadCartonPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.ContainerStatus
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.Pallet
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.ValidationResult
import com.fsc.flare.ui.fragment.loadunloadtrailer.LoadUnloadViewModel
import com.fsc.flare.ui.fragment.loadunloadtrailer.PalletAdapter
import com.fsc.flare.utils.PreferenceKeys
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

private val TAG = UnloadCartonPalletFragment::class.java.simpleName.toString()
@AndroidEntryPoint
class UnloadCartonPalletFragment : BaseFragment(), FlareScannable {
    private val viewModel: LoadUnloadViewModel by activityViewModels()
    private lateinit var binding: FragmentUnloadCartonPalletBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentUnloadCartonPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.etCartonPallet.requestFocus()
        handleTouchAndFocusEvents()
        return binding.root
    }
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etCartonPallet.isFocused && !binding.etCartonPallet.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Carton/Pallet field focused")
                        validateCartonPallet()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etCartonPallet.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etCartonPallet)
                FlareLog.i(TAG, "Carton/Pallet field focused")
                validateCartonPallet()
            }
            return@setOnEditorActionListener false
        }

        binding.etCartonPallet.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvCartonPalletResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnEnd.setOnClickListener {
            val navOptions = NavOptions.Builder().setPopUpTo(R.id.UnLoadDockDoorFragment, true).build()
            getNavigationController().navigate(R.id.action_unloadCartonPallet_to_unloadDockDoorFragment, null, navOptions)
        }
    }

    /**
     * Function to set up views with data
     */
    private fun setUpViews() {
        val dockDoorShipmentData = viewModel.dockDoorShipment
        dockDoorShipmentData?.let {
            binding.tvTotalStopValue.text = it.totalStops.toString()
        }
        viewModel.unloadTrailer?.let { data ->
            // Set Trailer information
            binding.apply {
                tvShipmentNumberValue.text = data.shipmentNumber
                tvCartonPalletValue.text = data.palletNumber
                tvLoadingStopValue.text = data.stopSequence.toString()
            }

            // Setup click listener and update pallet count
            data.palletsForStop?.let { palletList ->
                val loadedPalletsListSize = palletList.count { it.status == ContainerStatus.OUTBOUND_STAGED.code }
                val totalPalletsToLoadSize = palletList.size
                binding.tvCartonPalletCountValue.text = getString(
                    R.string.lbl_carton_pallet_count_value,
                    loadedPalletsListSize,
                    totalPalletsToLoadSize
                )

                binding.tvCartonPalletCountView.setOnClickListener {
                    showPalletLoadStatusDialog(palletList)
                }
            }
        }
    }

    /**
     * Function to display pallet load status dialog
     */
    private fun showPalletLoadStatusDialog(palletList: List<Pallet>) {
        val dialogView = LayoutInflater.from(fragmentContext).inflate(R.layout.dialog_pallet_load, null)
        val binding = DataBindingUtil.bind<DialogPalletLoadBinding>(dialogView)

        binding?.run {
            // Set up the RecyclerView with the adapter
            titleTextView.text = getString(R.string.lbl_pallet_load_unload_status)
            palletRecyclerView.layoutManager = LinearLayoutManager(fragmentContext) // Set LayoutManager
            palletRecyclerView.adapter = PalletAdapter(palletList)

            val dividerItemDecoration = DividerItemDecoration(
                palletRecyclerView.context,
                DividerItemDecoration.VERTICAL
            )
            //set a custom drawable
            dividerItemDecoration.setDrawable(ContextCompat.getDrawable(fragmentContext, R.drawable.item_divider)!!)
            // Add the divider decoration
            palletRecyclerView.addItemDecoration(
                dividerItemDecoration
            )
        }

        // show the dialog
        val dialog = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
            .setView(dialogView)
            .setCancelable(false)
            .setPositiveButton(getString(R.string.alert_button_ok)) { dialog, _ -> dialog.dismiss() }
            .create()
        dialog.show()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpViews()
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to validate pallet/carton and call load trailer patch api
     */
    private fun validateCartonPallet() {
        val data = viewModel.unloadTrailer
        val palletToUnload = binding.etCartonPallet.text.toString()

        data?.let { unloadTrailerResponse ->
            val validationResult = validatePalletNumber(unloadTrailerResponse, palletToUnload)

            if (validationResult.isValidPallet) {
                viewModel.validationResult = validationResult
                navigateToUnloadStagingLocationFragment()
            } else {
                handleInvalidPallet(validationResult.isOverrideActive)
            }
        }
    }

    /**
     * Function to handle Invalid Pallet
     */
    private fun handleInvalidPallet(isOverrideActive: Boolean) {
        val palletToUnload = binding.etCartonPallet.text.toString()
        binding.tvCartonPalletResponse.text = if (isOverrideActive) {
            val unloadTrailerResponse = viewModel.unloadTrailer ?: return
            unloadTrailerResponse.palletsForStop?.asSequence()
                ?.filter { it.status == ContainerStatus.OUTBOUND_STAGED.code }
                ?.find { it.containerNumber == palletToUnload }
                ?.let {
                    getString(R.string.lbl_is_already_unloaded, it.containerNumber)
                } ?: getString(R.string.lbl_invalid_pallet_to_unload)
        } else {
            getString(R.string.lbl_given_pallet_is_not_the_system_directed_pallet)
        }
        binding.etCartonPallet.requestFocus()
        binding.etCartonPallet.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etCartonPallet)
    }

    /**
     * Function to validate Pallet Number from Same Stop
     */
    private fun validatePalletNumber(
        response: UnloadTrailerResponse,
        inputPalletNumber: String
    ): ValidationResult {
        val isOverrideActive = sharedPreferencesBase.getBoolean(PreferenceKeys.LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE, false)

        return if (isOverrideActive) {
            // Filter pallets and check for a match
            response.palletsForStop?.asSequence()
                ?.filter { it.status == ContainerStatus.LOADED_ON_TRUCK.code }
                ?.find { it.containerNumber == inputPalletNumber }
                ?.let { matchingPallet ->
                    ValidationResult(isOverrideActive = true, isValidPallet = true, containerId = matchingPallet.containerId, containerNumber = matchingPallet.containerNumber)
                } ?: ValidationResult(isOverrideActive = true, isValidPallet = false)
        } else {
            // Direct comparison when override is not active
            if (inputPalletNumber == response.palletNumber) {
                ValidationResult(isOverrideActive = false, isValidPallet = true, containerId = response.palletId, containerNumber = response.palletNumber)
            } else {
                ValidationResult(isOverrideActive = false, isValidPallet = false)
            }
        }
    }

    /**
     * Nav Handler to Unload Staging Location Fragment
     */
    private fun navigateToUnloadStagingLocationFragment() {
        binding.etCartonPallet.text = null
        val action = UnloadCartonPalletFragmentDirections.actionUnloadCartonPalletToUnloadStagingLocationFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etCartonPallet.setText(scan?.barcode.toString())
        binding.etCartonPallet.text?.length?.let {
            binding.etCartonPallet.setSelection(
                it
            )
            FlareLog.i(TAG, "Carton/Pallet field focused")
            validateCartonPallet()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}
