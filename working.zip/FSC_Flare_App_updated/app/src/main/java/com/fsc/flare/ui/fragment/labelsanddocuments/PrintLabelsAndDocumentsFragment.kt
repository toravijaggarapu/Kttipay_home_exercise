package com.fsc.flare.ui.fragment.labelsanddocuments

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPrintLabelsAndDocumentsBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintCartonRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintOrderRequest
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintPalletRequestNew
import com.fsc.flare.source.data.dto.labelsanddocuments.PrintShipmentRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PrintDocuments"

/**
 * A simple [PrintLabelsAndDocumentsFragment] class.
 */
@AndroidEntryPoint
class PrintLabelsAndDocumentsFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: LabelsAndDocumentsViewModel by activityViewModels()
    private lateinit var binding: FragmentPrintLabelsAndDocumentsBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPrintLabelsAndDocumentsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    private fun subscribeObservers() {
        viewModel.printerNameResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val printerConfig = viewModel.getPrinterConfigs()
                        val printInput = viewModel.getInput()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach { lookUpCode ->
                                printerConfig?.forEach { printerConfig ->
                                    if(lookUpCode.lookupCode == printerConfig.printerName && printerConfig.printerType == "DOC" && sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null) == "Order"){
                                        viewModel.printOrder(
                                            PrintOrderRequest(
                                                printRequestor = printerConfig.requestor,
                                                documentPrinterName = lookUpCode.lookupCodeDescription,
                                                orderId = printInput?.orderId!!,
                                                packingSlipType = printInput.packingSlipType,
                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                emailGroup = sharedPreferences.getString(PreferenceKeys.FEDEX_EMAIL, null)!!
                                            )
                                        )
                                    } else if(lookUpCode.lookupCode == printerConfig.printerName && printerConfig.printerType == "LBL" && sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null) == "Pallet"){
                                   /*     viewModel.printPallet(
                                            PrintPalletRequest(
                                                printRequestor = printerConfig.requestor,
                                                lablePrinterName = lookUpCode.lookupCodeDescription,
                                                palletId = printInput?.palletId!!,
                                                palletShippingLabel = binding.printCheckBox1.isChecked,
                                                palletContentLabel = binding.printCheckBox2.isChecked,
                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                emailGroup = sharedPreferences.getString(PreferenceKeys.FEDEX_EMAIL, null)!!
                                            )
                                        )
*/
                                        //Defect D-101606 fix by adding the palletId as list and checkbox updated properly.
                                        viewModel.printPalletNew(
                                            PrintPalletRequestNew(
                                                printRequestor = printerConfig.requestor,
                                                lablePrinterName = lookUpCode.lookupCodeDescription,
                                                palletId = arrayListOf(printInput?.palletId!!),
                                                palletShippingLabel = binding.printCheckBox1.isChecked,
                                                palletContentLabel = binding.printCheckBox2.isChecked,
                                                cartonContentLabel = binding.printCheckBox3.isChecked,
                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                emailGroup = sharedPreferences.getString(PreferenceKeys.FEDEX_EMAIL, null)!!
                                            )
                                        )

                                    } else if(lookUpCode.lookupCode == printerConfig.printerName && printerConfig.printerType == "DOC" && sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null) == "Shipment"){
                                        viewModel.printShipment(
                                            PrintShipmentRequest(
                                                printRequestor = printerConfig.requestor,
                                                documentPrinterName = lookUpCode.lookupCodeDescription,
                                                shipmentId = printInput?.shipmentId!!,
                                                bolType = printInput.bolType,
                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                emailGroup = sharedPreferences.getString(PreferenceKeys.FEDEX_EMAIL, null)!!
                                            )
                                        )
                                    } else if(lookUpCode.lookupCode == printerConfig.printerName && printerConfig.printerType == "DOC" && sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null) == "Carton"){
                                        viewModel.printCarton(
                                            PrintCartonRequest(
                                                printRequestor = printerConfig.requestor,
                                                documentPrinterName = lookUpCode.lookupCodeDescription,
                                                obCartonId = printInput?.obCartonId!!,
                                                obCartonLabelType = printInput.obCartonLabelType,
                                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                                emailGroup = sharedPreferences.getString(PreferenceKeys.FEDEX_EMAIL, null)!!
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.printLblAndDocResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printLblAndDocResponse ->
                        if (printLblAndDocResponse.status == true) {
                            showSuccessSnackBarStd(printLblAndDocResponse.responseMessage) {
                                val action =
                                    PrintLabelsAndDocumentsFragmentDirections.actionPrintLabelsAndDocumentsToLabelsAndDocuments()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.labelsAndDocuments, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            if(printLblAndDocResponse.errorCode == "500"){
                                showErrorSnackBar(printLblAndDocResponse.errorDescription.orEmpty())
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "printLblAndDocResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.ldPrintBtn.setOnClickListener {
            if (binding.printCheckBox1.isChecked || binding.printCheckBox2.isChecked || binding.printCheckBox3.isChecked) {
                viewModel.getPrinterName()
            } else {
                showErrorSnackBar(resources.getString(R.string.lbl_select_label_document_checkbox))
            }
        }

        val printerConfig = viewModel.getPrinterConfigs()
        val printInput = viewModel.getInput()
        binding.pldPrintEntityValueTv.text = sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null)
        if (printerConfig != null) {
            binding.pldRequesterValueTv.text = printerConfig[0].requestor
        }
        //binding.pldEntityTv.text = "${sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null)} Number :"
        when (sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null)) {
            "Carton" -> {
                binding.pldEntityValueTv.text = printInput?.obCartonNumber
                binding.pldEntityTv.text = resources.getString(R.string.lbl_carton_number)
                binding.printCheckBox1.visibility = View.VISIBLE
                binding.printCheckBox1.text = printInput?.obCartonLabelTypeDesc
            }
            "Order" -> {
                binding.pldEntityValueTv.text = printInput?.orderNumber
                binding.pldEntityTv.text = resources.getString(R.string.lbl_order_number)
                binding.printCheckBox1.visibility = View.VISIBLE
                binding.printCheckBox1.text = printInput?.packingSlipDescription
            }
            "Pallet" -> {
                binding.pldEntityValueTv.text = printInput?.palletNumber
                binding.pldEntityTv.text = resources.getString(R.string.pallet_number)
                binding.printCheckBox1.visibility = View.VISIBLE
                binding.printCheckBox2.visibility = View.VISIBLE
                binding.printCheckBox3.visibility = View.VISIBLE
                binding.printCheckBox1.text = printInput?.palletShippingLabel
                binding.printCheckBox2.text = printInput?.palletContentLabel
                binding.printCheckBox3.text = resources.getString(R.string.lbl_carton_content_label)
            }
            "Shipment" -> {
                binding.pldEntityValueTv.text = printInput?.shipmentNumber
                binding.pldEntityTv.text = resources.getString(R.string.shipment_number_colon)
                binding.printCheckBox1.visibility = View.VISIBLE
                binding.printCheckBox1.text = printInput?.bolType
            }
        }
    }

}