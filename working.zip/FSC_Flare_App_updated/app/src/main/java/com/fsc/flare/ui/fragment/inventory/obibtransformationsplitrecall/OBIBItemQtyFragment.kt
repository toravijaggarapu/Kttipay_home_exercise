package com.fsc.flare.ui.fragment.inventory.obibtransformationsplitrecall

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentObIbItemQtyBinding
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.Item
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.NextScreen
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBCartonDetails
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.OBIBTransformations
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.SplitInfo
import com.fsc.flare.source.data.dto.inventory.obibtransformationsplitrecall.TransformObToIbCartonResponse
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = OBIBItemQtyFragment::class.java.simpleName.toString()
/**
 *  [OBIBItemQtyFragment] class.
 */
@AndroidEntryPoint
class OBIBItemQtyFragment : BaseFragment() {

    private val sharedViewModel: OBIBTransSplitRecallSharedViewModel by activityViewModels()
    private val viewModel: OBIBTransSplitRecallViewModel by viewModels()
    private lateinit var binding: FragmentObIbItemQtyBinding

    override fun onPause() {
        super.onPause()
        binding.etScanItemQty.clearFocus()
        hideSoftKeyBoard(fragmentContext, binding.etScanItemQty)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentObIbItemQtyBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvObIbTransSplitRecall.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etScanItemQty.requestFocus()
        setUpViews()
        handleTouchAndFocusEvents()
        subscribeObservers()
    }

    /**
     * Function to setup views with data
     */
    private fun setUpViews() {
        val obCartonDetails = sharedViewModel.obCartonDetails
        val itemDetails = sharedViewModel.itemDetails
        val blindIbContainerNumber = sharedViewModel.blindIbContainerNumber.orEmpty()
        val lotNumber = sharedViewModel.lotNumber
        val expiryDate = sharedViewModel.expiryDate
        val coo = sharedViewModel.coo

        obCartonDetails?.let {
            binding.tvObContainerIdValue.text = it.containerNbr
        }
        itemDetails?.let { item ->
            binding.tvItemCodeValue.text = item.itemCode
            binding.tvItemDescriptionValue.text = item.itemDesc
            binding.tvItemQtyValue.text = item.qty.toString().plus(" ").plus(item.qtyUom)
            binding.tvItemQtyUom.text = item.qtyUom
        }

        binding.apply {
            tvIbCartonIdValue.text = blindIbContainerNumber
            tvItemLotValue.text = lotNumber
            tvItemExpiryValue.text = expiryDate
            tvItemCooValue.text = coo
            btnSplitContainer.setOnClickListener {
                when {
                    !etScanItemQty.text.isNullOrEmpty() -> {
                        sharedViewModel.itemQty = etScanItemQty.text.toString().trim()
                        handleSplitBtnClick(obCartonDetails, lotNumber, coo, sharedViewModel.itemQty)
                    }
                    else -> {
                        binding.tvItemQtyResponse.text = getString(R.string.enter_qty)
                    }
                }
            }
        }

        updateViewVisibility(lotNumber, expiryDate, coo)
    }

    /**
     * Function to handle Split Btn click
     */
    private fun handleSplitBtnClick(obCartonDetails: OBCartonDetails?, lotNumber: String?, coo: String?, itemQty: String?) {
        // Retrieve item details from the shared view model
        val itemDetails = sharedViewModel.itemDetails ?: return

        // Ensure obCartonDetails is not null
        obCartonDetails?.let { obCarton ->
            // Create the SplitInfo list
            val splitInfoList = listOf(
                SplitInfo(
                    blindCaseNbr = sharedViewModel.blindIbContainerNumber.orEmpty(),
                    itemId = itemDetails.itemId,
                    qty = itemQty?.toIntOrNull() ?: 0,
                    lotNumber = lotNumber,
                    coo = coo
                )
            )

            // Transform OB to IB carton request
            viewModel.transformObToIbCartonRequest(
                action = OBIBTransformations.SPLIT.type,
                containerId = obCarton.containerId ?: 0,
                splitInfoList = splitInfoList
            )
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        observeTransformObToIbCartonResponse()
    }

    /**
     * Function to observe transform OB to IB Carton response
     */
    private fun observeTransformObToIbCartonResponse() {
        viewModel.obToIbCartonTransformResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleTransformObToIbCartonSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleTransformObToIbCartonErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Transform OB to IB Carton error response
     */
    private fun handleTransformObToIbCartonErrorResponse(message: String?) {
        message?.let {
            showErrorSnackBar(message = message)
        }
    }

    /**
     * Function to handle transform OB to IB Carton success response
     */
    private fun handleTransformObToIbCartonSuccessResponse(response: TransformObToIbCartonResponse?) {
        response?.let {
            if (response.success) {
                if(response.taskMessageCode == Constants.TSK_CREATE_SUCCESS) {
                    displayTaskCreateDialog(response)
                } else {
                    navigateToNextScreen(response)
                }
            }
        }
    }

    /**
     * Function to navigate to next screen based on response
     */
    private fun navigateToNextScreen(
        response: TransformObToIbCartonResponse
    ) {
        response.containerDetails?.first()?.let {
            it.nextScreen.let { nextScreenValue ->
                NextScreen.fromValue(nextScreenValue)?.let { nextScreen ->
                    when (nextScreen) {
                        NextScreen.OB_SCAN -> navigateToCartScreen()
                        NextScreen.IB_CASE_SCAN -> navigateToIBCaseScreen(response.containerDetails.first())
                    }
                }
            }
        }
    }

    /**
     * Function to display Task Create Dialog
     */
    private fun displayTaskCreateDialog(response: TransformObToIbCartonResponse) {
        showAlertDialog(
            title = "",
            message = getString(R.string.lbl_split_inv_task_created),
            onPositiveClick = {
                navigateToNextScreen(response)
            }
        )
    }

    /**
     * Nav Handler to IB Case Scan Screen
     */
    private fun navigateToIBCaseScreen(obCartonDetails: OBCartonDetails) {
        sharedViewModel.obCartonDetails = obCartonDetails
        val action = OBIBItemQtyFragmentDirections.actionScanOBIBItemQtyFragmentToScanBlindIbContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Nav Handler to Cart Screen
     */
    private fun navigateToCartScreen() {
        val action = OBIBItemQtyFragmentDirections.actionScanOBIBItemQtyFragmentToScanObContainerFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to update view visibility
     */
    private fun updateViewVisibility(lotNumber: String?, expiryDate: String?, coo: String?) {
        // Update visibility for lot number
        setViewVisibility(lotNumber, binding.tvItemLot, binding.tvItemLotValue)

        // Update visibility for Expiry Date
        setViewVisibility(expiryDate, binding.tvItemExpiry, binding.tvItemExpiryValue)

        // Update visibility for country of origin
        setViewVisibility(coo, binding.tvItemCoo, binding.tvItemCooValue)
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etScanItemQty.isFocused && !binding.etScanItemQty.text.isNullOrEmpty()) {
                        validateItemQty()
                    }
                }
            }
            v?.onTouchEvent(event) ?: return@setOnTouchListener true
        }

        binding.etScanItemQty.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etScanItemQty)
                if (binding.etScanItemQty.isFocused && !binding.etScanItemQty.text.isNullOrEmpty()) {
                    validateItemQty()
                }
            }
            return@setOnEditorActionListener false
        }

        binding.etScanItemQty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Do something before the text is changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Do something when the text is changed
                binding.tvItemQtyResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {
                // Do something after the text is changed
            }
        })
    }

    /**
     * Function to validate Item Qty
     */
    private fun validateItemQty() {
        val itemQty = binding.etScanItemQty.text.toString().trim()
        val isQtyValid = validateItemQtyFromObCartonDetails(itemQty = itemQty)
        when {
            isQtyValid -> {
                sharedViewModel.itemQty = itemQty
                navigateToNext(sharedViewModel.itemDetails)
            }
            else -> {
                handleInvalidQuantityInput()
            }
        }
    }

    /**
     * Function to handle invalid quantity input
     */
    private fun handleInvalidQuantityInput() {
        with(binding) {
            tvItemQtyResponse.text = getString(R.string.lbl_entered_qty_cannot_be_greater_than_defined_qty)
            etScanItemQty.requestFocus()
            etScanItemQty.selectAll()
            showSoftKeyBoard(requireContext(), etScanItemQty)
        }
    }

    /**
     * Function to validate Item qty from ob carton details
     */
    private fun validateItemQtyFromObCartonDetails(itemQty: String): Boolean {
        val itemDetails = sharedViewModel.itemDetails ?: return false

        // Convert itemQty to Int for comparison; return false if conversion fails
        val inputQty = itemQty.toIntOrNull() ?: return false

        // Return true if requested quantity is less than or equal to matching item's quantity and it cannot be negative
        return inputQty <= itemDetails.qty && inputQty > 0
    }

    /**
     * Nav Handler to Next Screen based on tracking information of Item
     */
    private fun navigateToNext(item: Item?) {
        item?.let {
            when {
                !it.serialNbrs.isNullOrEmpty() -> {
                    binding.etScanItemQty.text = null
                    val action = OBIBItemQtyFragmentDirections.actionScanOBIBItemQtyFragmentToScanOBIBItemSerialFragment()
                    getNavigationController().navigate(action)
                }
                else -> binding.btnSplitContainer.isEnabled = true
            }
        }
    }
}
