package com.fsc.flare.ui.fragment.inventory.pallettransfer

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.container.ContainerInventoryInquiryResponse
import com.fsc.flare.source.data.dto.pallettransfer.*
import com.fsc.flare.source.repository.PalletTransferRepository
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "PalletTransferViewModel"

@HiltViewModel
class PalletTransferViewModel @Inject constructor(
    private val palletTransferRepository: PalletTransferRepository
) : BaseViewModel() {
    val palletTransferTypeKey = "PALLET"
    val palletCaseGenerateKey = "pallet_casenum"
    val palletDetailKey = "Pallet"

    val palletResponse: MutableLiveData<Resource<PalletDetailResponse>> = SingleLiveEvent()
    val palletGenerateResponse: MutableLiveData<Resource<PalletGenerateResponse>> = SingleLiveEvent()
    var palletDetailResponse: MutableLiveData<PalletDetailResponse> = MutableLiveData<PalletDetailResponse>()
    var palletSuccessResponse: MutableLiveData<Resource<PalletTransferResponse>> = SingleLiveEvent()
    val containerInquiryResponse: MutableLiveData<Resource<ContainerInventoryInquiryResponse>> = SingleLiveEvent()

    fun fetchPalletDetail(palletNumber: String, transferType: String) = viewModelScope.launch {
        palletResponse.postValue(Resource.Loading())
        val response = palletTransferRepository.validatePalletNumber(palletNumber, transferType)
        palletResponse.postValue(handlePalletDetailResponse(response))
    }

    private fun handlePalletDetailResponse(response: Response<PalletDetailResponse>): Resource<PalletDetailResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetail response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetail Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun generatePalletNumber(transferType: String) = viewModelScope.launch {
        palletGenerateResponse.postValue(Resource.Loading())
        val response = palletTransferRepository.generatePalletNumber(transferType)
        palletGenerateResponse.postValue(handleGeneratedPalletResponse(response))
    }

    private fun handleGeneratedPalletResponse(response: Response<PalletGenerateResponse>): Resource<PalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletDetail response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletDetail Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun confirmDestinationLocation(palletTransferRequest: PalletTransferRequest) = viewModelScope.launch {
        palletSuccessResponse.postValue(Resource.Loading())
        val response = palletTransferRepository.confirmDestinationLocation(palletTransferRequest)
        palletSuccessResponse.postValue(handlePalletTransferResponse(response))
    }

    fun confirmSplitDestinationLocation(palletTransferRequest: PalletTransferSplitRequest) = viewModelScope.launch {
        palletSuccessResponse.postValue(Resource.Loading())
        val response = palletTransferRepository.confirmSplitDestinationLocation(palletTransferRequest)
        palletSuccessResponse.postValue(handlePalletTransferResponse(response))
    }

    private fun handlePalletTransferResponse(response: Response<PalletTransferResponse>): Resource<PalletTransferResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletTransfer response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletTransfer Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setPalletDetails(palletDetail: PalletDetailResponse) {
        this.palletDetailResponse.value = palletDetail
    }

    fun getPalletDetails(): PalletDetailResponse? {
        return palletDetailResponse.value
    }

    fun getContainerDetails(containerNum: String) = viewModelScope.launch {
        FlareLog.i(TAG, "getContainer Request: $containerNum")
        containerInquiryResponse.postValue(Resource.Loading())
        val response = palletTransferRepository.getContainerDetails(containerNum)
        containerInquiryResponse.postValue(handleContainerInquiryResponse(response))
    }

    private fun handleContainerInquiryResponse(response: Response<ContainerInventoryInquiryResponse>): Resource<ContainerInventoryInquiryResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerInquiryResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerInquiryResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
}