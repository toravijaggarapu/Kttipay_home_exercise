package com.fsc.flare.ui.fragment.packout

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPackoutStagingLocBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.packout.req.PackOutEndReq
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.ui.common.BackButtonHandler
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PackoutStagingLocationFragment"

@AndroidEntryPoint
class PackoutstagingFragment : BaseFragment(), FlareScannable, BackButtonHandler {

    private val viewModel: PackoutVM by activityViewModels()
    private lateinit var binding: FragmentPackoutStagingLocBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        super.onResume()
        cb1.onVisibilityChange(true)

    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPackoutStagingLocBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if(viewModel.getPalletReqNumber()=="") {
            binding.tvPallet.visibility = View.GONE
        }
        else{
            binding.tvPalletValue.text=viewModel.getPalletReqNumber()
        }
        //display previously captured carton/pallet number
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etStagingLoc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.etStagingLocRes.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        binding.etStagingLoc.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.etStagingLoc)
        if (binding.etStagingLoc.isFocused && !binding.etStagingLoc.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "Location field focused")
            validateStagingLocation()
        }
    }

    private fun validateStagingLocation() {
        viewModel.validateStagingLocation(
            LocationClassReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etStagingLoc.text.toString(),
                "S"
            )
        )
    }


    private fun callEndPackOut(locationId: Int) {
        viewModel.endPackOut(
            PackOutEndReq(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                actioveLocationId = viewModel.getLocId(),
                transactionIdentifier = viewModel.gettransIdentifier(),
                stageLocId = locationId,
                isKitting = viewModel.isKitting,
                itemId = viewModel.getItemId()
            )
        )
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeStagingLocationObserver()
        subscribeObserversEndPackOut()
    }


    /**
     * method to subscribe staging location observer
     */
    private fun subscribeStagingLocationObserver() {
        viewModel.stagingLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { stagingLocationResponse ->
                        if (stagingLocationResponse.success != null && stagingLocationResponse.success) {
                            FlareLog.i(TAG, "stagingLocationResponse success: $stagingLocationResponse")
                            if (stagingLocationResponse.locations.isNotEmpty()) {
                                /*if (stagingLocationResponse.locations[0].status != "1") {
                                    callValidateStageLocationAPI(stagingLocationResponse.locations[0].locationId)
                                } else {
                                    binding.tvStagingLocationResponse.text = resources.getString(R.string.invalid_location_in_use)
                                    binding.etStagingLocation.requestFocus()
                                    binding.etStagingLocation.selectAll()
                                    showSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                                }*/
                                callEndPackOut(stagingLocationResponse.locations[0].locationId)

                            } else {
                                binding.etStagingLocRes.text = resources.getString(R.string.invalid_location)
                                binding.etStagingLoc.requestFocus()
                                binding.etStagingLoc.selectAll()
                                showSoftKeyBoard(fragmentContext, binding.etStagingLoc)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PackoutstagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

    }

    private fun subscribeObserversEndPackOut() {
        viewModel.packOutEndResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { response ->
                        FlareLog.i(TAG, "PackOutEnd response:$response")
                        if (response.success) {
                            if (response.message.isNotEmpty()) {
                                showAlertDialog("", response.message, onPositiveClick = {
                                    val action = PackoutstagingFragmentDirections.actionPackoutstagingFragmentToPackoutlocationFragment()
                                    val navOptions = NavOptions.Builder().setPopUpTo(R.id.PackoutLocationFragement, true).build()
                                    getNavigationController().navigate(action, navOptions)
                                })
                            }

                        } else {
                            FlareLog.e(TAG, "Transaction Param Error:${response}")
                            binding.etStagingLocRes.text = response.errors.errorMessage
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "endPackout Error:$message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etStagingLoc.setText(scan?.barcode.toString())
                binding.etStagingLoc.text?.length?.let {
                    binding.etStagingLoc.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Location field focused")
                    validateStagingLocation()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    override fun onBackButtonPressed() {
        hideSoftKeyBoard(fragmentContext, binding.etStagingLoc)
        showSnackBar(resources.getString(R.string.lbl_please_stage_the_carton,viewModel.getcartonReqNumber()))
        binding.etStagingLoc.requestFocus()
    }
}