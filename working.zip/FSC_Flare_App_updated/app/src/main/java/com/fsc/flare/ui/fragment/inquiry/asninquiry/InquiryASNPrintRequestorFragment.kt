package com.fsc.flare.ui.fragment.inquiry.asninquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryAsnPrintRequestorBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.PrinterConfig
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryASNPrintRequestorFragment"

/**
 * A simple InquiryASNPrintRequestorFragment.
 */
@AndroidEntryPoint
class InquiryASNPrintRequestorFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryAsnPrintRequestorBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private var printRequestorDescList = ArrayList<String>()
    private var printRequestorHashmap = HashMap<String, PrinterConfig>()

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        binding.printEntityDropDown.setOptions(printRequestorDescList)

        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getTransactionParam()
    }


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInquiryAsnPrintRequestorBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //If there is no printers configured then hide the print requester dropdown UI at first time
        if (printRequestorHashmap.isEmpty()) {
            binding.printRequesterLayout.visibility = View.GONE
        }
        // Printer selection observer to navigate next screen
        binding.printEntityDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
            val selectedPrinter = printRequestorHashmap[selection]
            selectedPrinter?.let {
                viewModel.setSelectedPrinterData(it)
            }
            val action =
                InquiryASNPrintRequestorFragmentDirections.actionInquiryAsnPrintRequestorFragmentToInquiryPalletNumberFragment()
            getNavigationController().navigate(action)
        }
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeTransactionParamObserver()
        subscribePrintRequestorObserver()
    }

    /**
     * method to get Transaction param details from API
     */
    private fun getTransactionParam() {
        viewModel.getInquiryASNTransactionParam(
            MPRTransParamRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                transCode = "PPL,PCL"
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.inquiryASNTransParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            if (transactionParamResponse.transParams != null && transactionParamResponse.transParams.isNotEmpty()) {
                                viewModel.setInquiryASNTransactionParamData(transactionParamResponse)
                                //Check the printer configured or not, if yes then displaying the dropdown and call the printer list API
                                if (checkIfPrintRequestorAPINeeded(transactionParamResponse)) {
                                    binding.printRequesterLayout.visibility = View.VISIBLE
                                    callGetPrintRequestorListAPI()
                                } else {
                                    // There is no printer configured will navigate directly to next screen and pop the print requestor screen
                                    singleLaunchPalletScreen()
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let {
                        //If any error happened for configuration API also navigate the user to next screen
                        singleLaunchPalletScreen()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun singleLaunchPalletScreen() {
        findNavController().navigate(
            InquiryASNPrintRequestorFragmentDirections.actionInquiryAsnPrintRequestorFragmentToPalletRepackPalletNumberFragmentSingleLaunch()
        )
    }

    /**
     * method to check if Print Requestor API call is needed/not
     */
    private fun checkIfPrintRequestorAPINeeded(transactionParamResponse: MPRepackTransParamResponse): Boolean {
        var pclVal = false
        var pplVal = false
        transactionParamResponse.transParams?.forEach {
            when (it.transCode) {
                "PCL" -> {
                    pclVal = it.required
                }
                "PPL" -> {
                    pplVal = it.required
                }
            }
        }
        return pclVal || pplVal
    }


    /**
     * method to validate print requestor from API
     */
    private fun callGetPrintRequestorListAPI() {
        viewModel.setSelectedPrinterData(null)
        viewModel.getPrintRequestorList(
            PrinterConfigRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                page = 0,
                pageLimit = 100,
                printerType = "LBL"
            )
        )
    }

    /**
     * method to subscribe print requestor observer
     */
    private fun subscribePrintRequestorObserver() {
        viewModel.printRequestorResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printRes ->
                        if (printRes.printerConfigs.isNotEmpty()) {
                            printRes.printerConfigs.forEach {
                                printRequestorDescList.add(it.requestor)
                                printRequestorHashmap[it.requestor] = it
                            }
                            binding.printEntityDropDown.setOptions(printRequestorDescList)
                        } else {
                            showErrorSnackBar(resources.getString(R.string.print_req_shd_have_lbl_associated))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}