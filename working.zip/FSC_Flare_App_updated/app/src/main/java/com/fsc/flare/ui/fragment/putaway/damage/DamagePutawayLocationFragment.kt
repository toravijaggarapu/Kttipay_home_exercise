package com.fsc.flare.ui.fragment.putaway.damage

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.DialogPrintRequesterSelectionBinding
import com.fsc.flare.databinding.FragmentSDPutawayActiveLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.putawayforward.get.res.PutawayForwardGetResponse
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.getNavigationResult
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import java.lang.Boolean
import kotlin.CharSequence
import kotlin.Exception
import kotlin.Int
import kotlin.String
import kotlin.apply
import kotlin.getValue
import kotlin.let
import kotlin.toString
import kotlin.with

private val TAG = DamagePutawayLocationFragment::class.java.simpleName.toString()

/**
 * A simple [DamagePutawayLocationFragment] subclass.
 */
@AndroidEntryPoint
class DamagePutawayLocationFragment : BaseFragment(), FlareScannable {
    val viewModel: DamagePutawayViewModel by activityViewModels()
    private lateinit var binding: FragmentSDPutawayActiveLocationBinding
    private lateinit var containerData: UserDirectedPutawayContainerResponse
    lateinit var cb1: CustomVisibilityCallback
    private var isLocationEmpty = false

    override fun onResume() {
        cb1.onVisibilityChange(true)
        binding.tvHeader.text =
            if (viewModel.isUserDirected) getString(R.string.user_directed_putaway_damaged)
            else getString(R.string.system_directed_putaway_damaged)
        super.onResume()
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getPutawayRequestAPI()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentSDPutawayActiveLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        handleTouchAndFocusEvents()
        subscribeObservers()
        return binding.root
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { _, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (etLocation.isFocused && !etLocation.text.isNullOrEmpty()) {
                            FlareLog.i(TAG, "Location field focused")
                            callSubmitPutawayAPI()
                        } else {
                            tvLocationResponse.text = getString(R.string.lbl_location_is_required)
                            etLocation.requestFocus()
                        }
                    }
                }
                return@setOnTouchListener true
            }

            etLocation.setOnEditorActionListener { _, actionId, event ->
                if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, etLocation)
                    FlareLog.i(TAG, "Location field focused")
                    callSubmitPutawayAPI()
                }
                return@setOnEditorActionListener false
            }

            etLocation.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    tvLocationResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUpViews()
        handleBackStackData()
    }

    /**
     * Function to setup views
     */
    private fun setUpViews() {
        binding.etLocation.isEnabled = true
        containerData = viewModel.getPutawayContainerData()
        with(binding) {
            tvContainerValue.text = containerData.containerNbr
            tvItemCodeValue.text = containerData.itemCode
            tvItemDescValue.text = containerData.itemDescription
            tvQtyValue.text = containerData.let {
                String.format(getString(R.string.format_num_str_label), it.quantity, getString(R.string.each))
            }
            tvStatusValue.text = containerData.status

            containerData.locationBarcode?.let {
                tvLocationValue.text = it
                glLocation.visibility = View.VISIBLE
            } ?: {
                glLocation.visibility = View.GONE
            }
        }
    }

    private fun handleBackStackData() {
        getNavigationResult<String>(SAVED_STATE_CALL_PRINTER) { result ->
            if (result == Boolean.TRUE.toString()) {
                viewModel.getPrintRequesterList()
            }
        }
    }

    /**
     * Function to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeSubmitPutawayObserver()
        slotPutawayAPIObserver()
        subscribePrinterConfigObserver()
        subscribeLocationObserver()
    }

    /**
     * Function to save/submit putaway
     */
    private fun callSubmitPutawayAPI() {
        val enteredLocation = binding.etLocation.text?.trim().toString()
        val expectedLocation = binding.tvLocationValue.text.toString()
        if (enteredLocation.isNotEmpty()) {
            if (viewModel.isUserDirected) {
                validateLocation()
            } else {
                if (enteredLocation == expectedLocation) {
                    displayEmptyLocationAlert()
                } else {
                    binding.tvLocationResponse.text = getString(R.string.location_mismatch)
                }
            }
        }
    }

    private fun displayEmptyLocationAlert() {
        if (isLocationEmpty && !viewModel.isPutawayByPallet) {
            showAlertDialog(
                "",
                getString(R.string.destination_location_does_not_have_the_pallet_please_create_the_blind_carton_scan_the_new_pallet)
            ) {
                getNavigationController().navigate(R.id.damagePutawayNewPalletFragment)
            }
        } else {
            submitPutawayRequest()
        }
    }

    private fun validateLocation() {
        val locationText = binding.etLocation.text?.trim().toString()
        when {
            locationText.isNotEmpty() -> {
                viewModel.prepareLocationRequest(locationText = locationText)
            }

            else -> {
                binding.tvLocationResponse.text = getString(R.string.lbl_location_is_required)
                binding.etLocation.requestFocus()
            }
        }
    }

    private fun submitPutawayRequest() {
        val palletId = if (viewModel.isPutawayByPallet) containerData.palletId.toString() else null
        viewModel.prepareSystemDirectedPutawayRequest(
            containerData = containerData, palletId = palletId
        )
    }

    /**
     * Function to subscribe submit putaway observer
     */
    private fun subscribeSubmitPutawayObserver() {
        viewModel.submitUDPutawayResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { submitResponse ->
                        if (submitResponse.success) {
                            showSuccessSnackBarStd(getString(R.string.putaway_successful)) {
                                navigateToContainerFragment()
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Nav Handler to Container Fragment
     */
    private fun navigateToContainerFragment() {
        viewModel.isRCLockCalled = false
        viewModel.isQHLockOnForUserDirectedPutaway = false
        getNavigationController().popBackStack(R.id.putawayDamageFragment, false)
    }

    /**
     * Function to make slot putaway api
     */
    private fun getPutawayRequestAPI() {
        viewModel.preparePutawayForwardRequest()
    }

    /**
     * Function to observe slot putaway api
     */
    private fun slotPutawayAPIObserver() {
        viewModel.putawayForwardGetRes.observe(viewLifecycleOwner) { slotResponse ->
            when (slotResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    slotResponse.data?.let { response ->
                        handlePutawayForwardSuccessResponse(response)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    slotResponse.message?.let { message ->
                        FlareLog.e(TAG, "PutAwayForwardGetRes Error:$message")
                        showCustomDialog(message) { getNavigationController().popBackStack() }
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle putaway forward success response
     */
    private fun handlePutawayForwardSuccessResponse(response: PutawayForwardGetResponse) {
        if (response.success) {
            viewModel.setPutawayDetails(response.putawayResponse)
            viewModel.setLocationData(response.putawayResponse.locationId.toString())
            binding.tvLocationValue.text = response.putawayResponse.locationBarcode
            isLocationEmpty = response.putawayResponse.locationStatus == 0
        } else {
            showCustomDialog(getString(R.string.location_details_not_found)) { getNavigationController().popBackStack() }
        }
    }

    private fun subscribePrinterConfigObserver() {
        viewModel.printRequestorResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printRes ->
                        if (printRes.printerConfigs.isNotEmpty()) {
                            showPrintRequesters(printRes.printerConfigs.map { it.requestor })
                        } else {
                            submitPutawayRequest()
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let {
                        submitPutawayRequest()
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    private fun showPrintRequesters(requesters : List<String>) {
        if (requesters.isNotEmpty()) {
            viewModel.setDefaultPrinter(requesters[0])
            val dialogBinding = DialogPrintRequesterSelectionBinding.inflate(layoutInflater)
            val dialog =
                MaterialAlertDialogBuilder(requireContext(), R.style.AlertDialogTheme).apply {
                    setView(dialogBinding.root)
                    setCancelable(false)
                }.show().apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }
            dialogBinding.tvPalletNumberValue.text = viewModel.getPalletNumberValue()
            dialogBinding.PrintRequesterDropDown.setOptions(ArrayList(requesters))
            dialogBinding.PrintRequesterDropDown.boolFoo.observe(viewLifecycleOwner) { selectedOption ->
                viewModel.setDefaultPrinter(selectedOption)
            }
            dialogBinding.btnPrint.setOnClickListener {
                dialog.dismiss()
                viewModel.getDefaultPrinter()?.let { it1 -> viewModel.printPalletLabel(it1) }
                submitPutawayRequest()
            }
            dialogBinding.btnCancel.setOnClickListener {
                dialog.dismiss()
            }
            dialogBinding.PrintRequesterDropDown.setSelectedValue(viewModel.getDefaultPrinter())
        }
    }

    /**
     * method to subscribe validate container observer
     */
    private fun subscribeLocationObserver() {
        viewModel.locationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationResponse ->
                        handleLocationSuccessResponse(locationResponse)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "locationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> showProgressBar()
            }
        }
    }

    private fun handleLocationSuccessResponse(locationResponse: LocationClassRes) {
        when {
            locationResponse.success && locationResponse.locations.isNotEmpty() -> {
                val location = locationResponse.locations[0]
                val isAllowedOnCCPendingLocation = sharedPreferencesBase.getBoolean(
                    PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false
                )
                when {
                    location.classification != viewModel.getDamageLocationType() && !viewModel.isQHLockOnForUserDirectedPutaway -> {
                        displayErrorMessage(getString(R.string.cannot_perform_as_container_has_damage_lock_please_use_putaway_to_damage_locations))
                    }
                    isAllowedOnCCPendingLocation && location.lockCode == "CC" -> {
                        displayErrorMessage(getString(R.string.cycle_count_in_progress_for_given_location))
                    }

                    !isAllowedOnCCPendingLocation && location.cycleCountPending == "Y" -> {
                        displayErrorMessage(getString(R.string.cycle_count_is_pending_for_given_location))
                    }

                    else -> {
                        isLocationEmpty = location.status == "0"
                        viewModel.setLocationData(location.locationId.toString())
                        displayEmptyLocationAlert()
                    }
                }
            }

            else -> {
                displayErrorMessage(getString(R.string.invalid_location))
            }
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.tvLocationResponse.text = message
        binding.etLocation.apply {
            requestFocus()
            text?.let { setSelection(it.length) }
            showSoftKeyBoard(fragmentContext, this)
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) return
        val scannedBarcode = scan?.barcode.toString()
        binding.etLocation.apply {
            setText(scannedBarcode)
            setSelection(scannedBarcode.length)
            hideSoftKeyBoard(fragmentContext, binding.etLocation)
        }
        callSubmitPutawayAPI()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}
