package com.fsc.flare.ui.fragment.interleaving

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInterleavingPutwayToReserveBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.interleaving.ExecuteTaskRequest
import com.fsc.flare.source.data.dto.interleaving.PickInfo
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull

private val TAG = PalletPutwayToReserveDetailFragment::class.java.simpleName.toString()

/**
 *  [PalletPutawayToReserveFragment] class.
 */
@AndroidEntryPoint
class PalletPutwayToReserveDetailFragment : BaseFragment(), FlareScannable {

    private lateinit var binding: FragmentInterleavingPutwayToReserveBinding
    private val sharedViewModel: InterLeavingSharedViewModel by activityViewModels()
    private val viewModel: InterLeavingExecuteTaskViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInterleavingPutwayToReserveBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initiateView(sharedViewModel.validateContainerResponse?.interLeavingData?.pickInfo)
        observeFlowOnUI { observeApiResults() }
        disableDeviceBack()
        validateDeliveryLocation()
    }

    private fun initiateView(pickInfo: PickInfo?) {
        binding.tvTaskId.text = pickInfo?.taskId.toString()
        binding.tvItemCode.text = pickInfo?.itemBarcode.toString()
        binding.tvLocation.text = pickInfo?.pickLocBarcode.toString()
        binding.tvPallet.text = pickInfo?.containerNbr.toString()
        binding.tvAsn.text = ""
        binding.tvDeliveryLocation.text = ""
    }

    private suspend fun observeApiResults() {
        viewModel.fetchTaskState.filterNotNull().collect { state ->

            when (state) {
                is PutwayToReserveTaskState.ShowProgress -> {
                    binding.incProgressBar.visibility = if (state.show) View.VISIBLE else View.GONE
                }

                is PutwayToReserveTaskState.PickNextTask -> {
                    initiateView(state.pickInfo)
                }

                is PutwayToReserveTaskState.ShowError -> showErrorSnackBar(state.errorMessage)
                is PutwayToReserveTaskState.EnableScanCurrentLocation -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PalletPutwayToReserveDetailFragmentDirections.actionPutwayToReserveFragmentToScanCurrentLocation()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) // Specify the destination to pop up to
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToCasePick -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_CASE_PICK.code
                    val action =
                        PalletPutwayToReserveDetailFragmentDirections.actionPutwayToReserveFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) // Specify the destination to pop up to
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPickFromReserve -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_PUTWAY_TO_RESERVE.code
                    val action =
                        PalletPutwayToReserveDetailFragmentDirections.actionPutwayToReserveFragmentToPickFromReserve()
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) // Specify the destination to pop up to
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
                is PutwayToReserveTaskState.NavigateToPalletReplenishmentToActive -> {
                    sharedViewModel.taskInterLeavingResponse = state.response
                    sharedViewModel.taskType = InterLeavingTaskType.PALLET_REPLENISHMENT_TO_ACTIVE.code
                    val action =
                        PalletPutwayToReserveDetailFragmentDirections.actionPutwayToReserveFragmentToPalletReplenishmentToCasePick(getString(state.screenTitle))
                    val navOptions = NavOptions.Builder()
                        .setPopUpTo(R.id.scanEquipmentFragment, inclusive = true) // Specify the destination to pop up to
                        .build()

                    getNavigationController().navigate(action, navOptions)
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun validateDeliveryLocation() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (binding.etDeliveryLocation.isFocused && !binding.etDeliveryLocation.text.isNullOrEmpty()) {
                            if (binding.etDeliveryLocation.text.toString() == binding.tvDeliveryLocation.text.toString()) {
                                callExecuteTaskService()
                            } else {
                                binding.tvShowLocationError.visibility = View.VISIBLE
                                binding.tvShowLocationError.text =
                                    getString(R.string.lbl_invalid_location)
                            }

                        } else {
                            binding.tvShowLocationError.visibility = View.VISIBLE
                            binding.tvShowLocationError.text =
                                getString(R.string.lbl_input_required)
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

               binding.etDeliveryLocation.setOnEditorActionListener { _, actionId, event ->
                   if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                       hideSoftKeyBoard(fragmentContext, binding.etDeliveryLocation)
                       callExecuteTaskService()
                   }
                   return@setOnEditorActionListener false
               }

            binding.etDeliveryLocation.doAfterTextChanged { binding.tvShowLocationError.visibility = View.GONE  }
        }
    }

    private fun callExecuteTaskService() {
        viewModel.callExecuteTaskService(
            endTaskRequest = ExecuteTaskRequest(
                binding.etDeliveryLocation.text.toString(),
                sharedViewModel.taskInterLeavingResponse?.sessionId ?: "0",
                sharedViewModel.taskInterLeavingResponse?.pickInfo?.taskId ?: 0
            )
        )
    }

    private fun disableDeviceBack() {
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (binding.etDeliveryLocation.isFocused && binding.etDeliveryLocation.text.isNullOrEmpty()) {
            binding.etDeliveryLocation.setText(scan?.barcode.toString())
            callExecuteTaskService()
        }
    }
}