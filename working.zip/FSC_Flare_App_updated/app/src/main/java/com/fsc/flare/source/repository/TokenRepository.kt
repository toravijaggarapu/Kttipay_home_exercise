package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.BuildConfig
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.transactiontracker.dto.FSCTrackerListModel
import com.fsc.flare.utils.AuthConstants
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Named

class TokenRepository @Inject constructor(
    @Named("auth") private val authApiGatewayInterface: ApiGatewayInterface,
    @Named("tempauth") private val apiGatewayInterfaceTemp: ApiGatewayInterface,
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getInitialToken(
        authorizationCode: String,
        challengeCodeVerifier: String
    ) = authApiGatewayInterface.getInitialToken(
        authorizationCode,
        challengeCodeVerifier,
        AuthConstants.AUTH_GRANT_TYPE_AUTHORIZATION_CODE,
        BuildConfig.CLIENT_ID,
        AuthConstants.LOGIN_PAGE_REDIRECT_URI
    )

    suspend fun getInitialTokenTemp(
        authorizationCode: String,
        challengeCodeVerifier: String
    ) = apiGatewayInterfaceTemp.getInitialToken(
        authorizationCode,
        challengeCodeVerifier,
        AuthConstants.AUTH_GRANT_TYPE_AUTHORIZATION_CODE,
        BuildConfig.TEMP_WORKER_CLIENT_ID,
        AuthConstants.LOGIN_PAGE_REDIRECT_URI
    )


    suspend fun getRefreshedToken(refreshToken: String) = authApiGatewayInterface.getRefreshedToken(
        refreshToken,
        BuildConfig.CLIENT_ID,
        AuthConstants.AUTH_GRANT_TYPE_REFRESH_TOKEN,
        AuthConstants.LOGIN_PAGE_REDIRECT_URI
    )

    suspend fun updateTransactionData(inputData: FSCTrackerListModel?) =
        apiGatewayInterface.postTransactionEvents(
            "Bearer ${
                sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)
            }",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            inputData
        )

   /* fun blockingGetRefreshedToken(refreshToken: String): Response<Token> {
        return getRefreshedToken(refreshToken).blockingGet()
    }*/
}




