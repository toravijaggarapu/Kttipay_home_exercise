package com.fsc.flare.ui.fragment.receiving

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.activityViewModels
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStatusBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.utils.Constants.LockCodes.FIRST_ARTICLE_INSPECTION
import com.fsc.flare.utils.Constants.LockCodes.INCUBATION_HOLD
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "StatusFragment"
private const val LOCK_CODE_AVAILABLE = "Available"

/**
 * A simple [StatusFragment] class
 */
@AndroidEntryPoint
class StatusFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ReceivingViewModel by activityViewModels()
    private lateinit var binding: FragmentStatusBinding
    private var lookupHashMap: HashMap<String, InventoryLockcode> = hashMapOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentStatusBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this

        subscribeLockCodeObserver()
        return binding.root
    }

    private fun subscribeLockCodeObserver() {
        viewModel.inventoryLockcodeResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        viewModel.lockCodesList.clear()
                        viewModel.lockCodesList.addAll(lookUpResponse.lockCodes)
                        val statusList = arrayListOf<String>()
                        lookUpResponse.lockCodes.forEach { lookUp ->
                            if (lookUp.code != INCUBATION_HOLD && lookUp.code != FIRST_ARTICLE_INSPECTION) {
                                statusList.add(lookUp.description)
                            }
                            lookupHashMap[lookUp.description] = lookUp
                        }
                        loadLockCodeSpinner(statusList)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (lookupHashMap.isEmpty()) {
            viewModel.getInventoryLockCodes()
        } else {
            val statusList = ArrayList<String>()
            lookupHashMap.keys.forEach { lookUp ->
                if (lookUp != INCUBATION_HOLD && lookUp != FIRST_ARTICLE_INSPECTION) {
                    statusList.add(lookUp)
                }
            }
            loadLockCodeSpinner(statusList)
        }

        with(binding) {
            val asnData = viewModel.getAsn()
            val item = viewModel.getItem()
            dockDoor.text = sharedPreferencesBase.getString(PreferenceKeys.Item.DD_NUMBER, null)
            asn.text = asnData.asnNumber
            packageBarcode.text = item.itemBarCode
            itemCode.text = item.itemName
            packageBarcodeDesc.text = item.description
            inventoryTypeDesc.text = viewModel.getInventoryTypeSelected()
            val lotNumber = sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null)
            val expirationDate = sharedPreferencesBase.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null)
            if (item.tracking.lotRequired == "1" && !lotNumber.isNullOrEmpty()) {
                lotTv.visibility = View.VISIBLE
                lot.visibility = View.VISIBLE
                lot.text = lotNumber
            }
            if (item.tracking.expirationRequired == "1" && !expirationDate.isNullOrEmpty()) {
                dateTv.visibility = View.VISIBLE
                date.visibility = View.VISIBLE
                date.text = expirationDate
            }

            if (viewModel.getManufacturingDate(viewModel.validateLotNumberResponse).isNotEmpty()) {
                mfdateTv.visibility = View.VISIBLE
                mfdate.visibility = View.VISIBLE
                mfdate.text =
                    parseExpiryDate(viewModel.getManufacturingDate(viewModel.validateLotNumberResponse))
            }

            if (item.tracking.countryOfOriginRequired == "1") {
                cooTv.visibility = View.VISIBLE
                coo.visibility = View.VISIBLE
                coo.text = sharedPreferencesBase.getString(
                    PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null
                )
            }

            if (item.hazmatRequired == "Y") {
                itemClassCodeTv.visibility = View.VISIBLE
                itemClassCode.visibility = View.VISIBLE
                itemClassCode.text = item.hazardous?.hazardClassIMDG
                slash.visibility = View.VISIBLE
                division.visibility = View.VISIBLE
                division.text = item.hazardous?.hazmatDivisionText
            }

            viewModel.selectedContainerType.takeIf { it == CASE || it == PALLET }?.let {
                if (it == PALLET) {
                    grpPalletNumber.visibility = View.VISIBLE
                    tvPalletNumber.text = viewModel.newPalletNumber
                    qty.text = "1"
                    uom.text = getString(R.string.pl)
                } else {
                    qty.text = viewModel.casesQuantity.toString()
                    uom.text = getString(R.string.cs)
                }
                grpContainerQty.visibility = View.VISIBLE
                tvEAQuantity.text = sharedPreferencesBase.getString(PreferenceKeys.Item.QUANTITY_INPUT, null)
            } ?: run {
                qty.text = sharedPreferencesBase.getString(PreferenceKeys.Item.QUANTITY_INPUT, null)
                uom.text = sharedPreferencesBase.getString(PreferenceKeys.Item.UOM_INPUT, null)
            }
        }
        //Initialize the status and lock code spinners
        initSpinnerDropdown()
    }

    private fun initSpinnerDropdown() {
        val statusList = arrayListOf<String>()
        statusList.add(getString(R.string.receiving_status_available))
        statusList.add(getString(R.string.receiving_status_unavailable))
        sharedPreferencesBase.edit().remove(PreferenceKeys.RECEIVING_LOCK_CODES).apply()
        with(binding) {
            statusSpinner.setOptions(statusList)
            statusSpinner.text = statusList[0]
            locksSpinner.boolFoo.observe(viewLifecycleOwner) { lockCodeInput ->
                super.spinnerSelected(binding.lockTv.text.toString(), lockCodeInput)
                if (lockCodeInput != LOCK_CODE_AVAILABLE) {
                    val selectedHashMap = lookupHashMap[lockCodeInput]
                    sharedPreferencesBase.edit().putString(PreferenceKeys.RECEIVING_LOCK_CODES, Gson().toJson(selectedHashMap)).apply()
                }
                navigateToLocation()
            }

            statusSpinner.boolFoo.observe(viewLifecycleOwner) { statusInput ->
                super.spinnerSelected(statusTv.text.toString(), statusList[0])
                try {
                    viewModel.firstArticleLockCode = Gson().toJson(lookupHashMap[FIRST_ARTICLE_INSPECTION])
                } catch (ex: Exception) {
                    viewModel.firstArticleLockCode = null
                    Log.d(TAG, "no first article lock value found in lock codes")
                }
            }
            btnNext.setOnClickListener {
                navigateToLocation()
            }
        }
    }

    private fun navigateToLocation() {
        sharedPreferencesBase.edit().putString(PreferenceKeys.Item.STATUS_INPUT, binding.statusSpinner.text.toString()).apply()
        val action = StatusFragmentDirections.actionStatusFragmentToLocationIdFragment()
        getNavigationController().navigate(action)
    }

    private fun loadLockCodeSpinner(statusList: ArrayList<String>) {
        statusList.sort()
        with(binding) {
            locksSpinner.setOptions(statusList)
            Handler(Looper.getMainLooper()).post {
                scrollViewLayout.fullScroll(View.FOCUS_DOWN)
            }
        }
    }
}