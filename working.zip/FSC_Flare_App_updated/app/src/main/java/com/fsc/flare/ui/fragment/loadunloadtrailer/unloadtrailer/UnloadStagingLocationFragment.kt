package com.fsc.flare.ui.fragment.loadunloadtrailer.unloadtrailer

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentUnloadStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.loadunloadtrailer.Container
import com.fsc.flare.source.data.dto.loadunloadtrailer.OBCartonRCLockResponse
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.Location
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.ui.fragment.loadunloadtrailer.LoadUnloadViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.RecallCodes
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = UnloadStagingLocationFragment::class.java.simpleName.toString()
private const val PALLET_UNLOAD_SUCCESS = "PALLET_UNLOAD_SUCCESS"

@AndroidEntryPoint
class UnloadStagingLocationFragment : BaseFragment(), FlareScannable {
    private val viewModel: LoadUnloadViewModel by activityViewModels()
    private lateinit var binding: FragmentUnloadStagingLocationBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentUnloadStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.etStagingLocation.requestFocus()
        handleTouchAndFocusEvents()
        subscribeObservers()
        return binding.root
    }

    /**
     * Function to handle touch and focus events
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (etStagingLocation.isFocused && !etStagingLocation.text.isNullOrEmpty()) {
                            FlareLog.i(TAG, "StagingLocation field focused")
                            validateStagingLocation()
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            etStagingLocation.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, etStagingLocation)
                    FlareLog.i(TAG, "StagingLocation field focused")
                    validateStagingLocation()
                }
                return@setOnEditorActionListener false
            }

            etStagingLocation.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    tvStagingLocationResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val containerData = viewModel.validationResult
        if (containerData != null) {
            binding.tvContainerNumberValue.text = containerData.containerNumber
        }
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to validate staging location
     */
    private fun validateStagingLocation() {
        viewModel.getStagingLocation(
            LocationClassReq(
                customerId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                facility = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                barcode = binding.etStagingLocation.text.toString(),
                locationClass = "S"
            )
        )
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeStagingLocationObserver()
        subscribeUnloadTrailerObserver()
        observeRecallContainersResponse()
    }

    /**
     * Function to observe Recall Containers Api response
     */
    private fun observeRecallContainersResponse() {
        viewModel.obCartonRCLockResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    handleObCartonRCLockSuccessResponse(response.data)
                }
                is Resource.Error -> {
                    hideProgressBar()
                    handleObCartonRCLockErrorResponse(response.message)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * Function to handle Recall Containers success response
     */
    private fun handleObCartonRCLockSuccessResponse(data: OBCartonRCLockResponse?) {
        binding.etStagingLocation.setText("")
        data?.containers?.let { containers ->
            displayRecallContainersDialog(containers)
        }
    }

    /**
     * Function to display Recall Containers dialog
     */
    private fun displayRecallContainersDialog(containers: List<Container>) {
        showAlertDialog(getString(R.string.lbl_recalled_containers),containers.map { it.containerNumber }.toTypedArray(),getString(R.string.alert_dialog_close_btn),onPositiveClick = {
                dialog: DialogInterface ->
                dialog.dismiss()
            navigateToUnloadDockDoorFragment()
        })
    }

    /**
     * Function to handle Recall Containers error response
     */
    private fun handleObCartonRCLockErrorResponse(message: String?) {
        message?.let { errorMessage ->
            showErrorSnackBar(errorMessage)
        }
    }

    /**
     * Function to subscribe stagingLocation observer
     */
    private fun subscribeStagingLocationObserver() {
        viewModel.stagingLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleStagingLocationSuccess(response.data)
                is Resource.Error -> handleStagingLocationError(response.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    var markPalletForPR = false

    /**
     * Function to handle Staging location success response
     */
    private fun handleStagingLocationSuccess(data: LocationClassRes?) {
        hideProgressBar()
        data?.let { stagingLocationResponse ->
            if (stagingLocationResponse.success) {
                FlareLog.i(TAG, "stagingLocationResponse success: $stagingLocationResponse")
                if (stagingLocationResponse.locations.isNotEmpty()) {
                    markPalletForPR = false
                    callUnloadTrailerAPI(stagingLocationResponse.locations[0],markPalletForPR)
                } else {
                    showInvalidErrorMessage(getString(R.string.invalid_staging_location))
                }
            } else {
                showInvalidErrorMessage(getString(R.string.invalid_staging_location))
            }
        }
    }

    /**
     * Function to handle staging location error response
     */
    private fun handleStagingLocationError(message: String?) {
        hideProgressBar()
        message?.let { msg ->
            FlareLog.e(TAG, "stagingLocationResponse error: $msg")
            showInvalidErrorMessage(getString(R.string.invalid_staging_location))
        }
    }

    /**
     * Function to call unloadTrailer API
     */
    private fun callUnloadTrailerAPI(location: Location, markPalletForPR:Boolean) {
        val containerData = viewModel.validationResult ?: return
        val containerId = containerData.containerId ?: return
        val containerNumber = containerData.containerNumber ?: return
        viewModel.unloadTrailer?.let { data ->
            viewModel.unLoadTrailerPatch(
                UnloadTrailerRequest(
                    fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1),
                    custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    shipmentId = data.shipmentId,
                    stageLocationBarcode = location.locationBarcode,
                    stageLocationId = location.locationId,
                    containerNumber = containerNumber,
                    containerId = containerId,
                    stopSequnceNbr = data.stopSequence,
                    markPalletForPR = markPalletForPR
                )
            )
        }
    }

    /**
     * Function to subscribe Unload Trailer Patch observer
     */
    private fun subscribeUnloadTrailerObserver() {
        viewModel.unLoadTrailerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleUnloadTrailerSuccess(response.data)
                is Resource.Error -> handleUnloadTrailerError(response.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to handle Unload Trailer success response
     */
    private fun handleUnloadTrailerSuccess(data: UnloadTrailerResponse?) {
        hideProgressBar()
        data?.let { unloadTrailerResponse ->
            if (unloadTrailerResponse.success) {
                if(unloadTrailerResponse.messageCode == RecallCodes.RECALL_UNLOAD_CONTAINERS) {
                    displayRecallContainers(unloadTrailerResponse.message)
                    return
                }
                viewModel.validationResult = null
                FlareLog.i(TAG, "unloadTrailerResponse success: $unloadTrailerResponse")
                if(markPalletForPR) {
                    showSuccessSnackBarStd(unloadTrailerResponse.message) {
                        navigateToUnloadDockDoorFragment()
                    }
                    return
                }
                if (unloadTrailerResponse.messageCode == PALLET_UNLOAD_SUCCESS) {
                    showSuccessSnackBarStd(unloadTrailerResponse.message) {
                        navigateToUnloadDockDoorFragment()
                    }
                } else {
                    showSuccessSnackBarStd(unloadTrailerResponse.message) {
                        viewModel.unloadTrailer = unloadTrailerResponse
                        navigateToUnloadCartonPalletFragment()
                    }
                }
            }
            else {
                showInvalidErrorMessage(unloadTrailerResponse.message)
            }
        }
    }

    /**
     * Function to handle unload trailer error response
     */
    private fun handleUnloadTrailerError(message: String?) {
        hideProgressBar()

        message?.let { msg ->
            val errorMessage = msg.split("##")
            val responseMessage = if (errorMessage.size > 1) errorMessage[1] else msg

            when {
                errorMessage[0].equals(RecallCodes.RECALL_UNLOAD_ERROR, ignoreCase = true) -> {
                    displayMarkForPRAlert(errorMessage[1])
                }
                else -> {
                    FlareLog.e(TAG, "unloadTrailerResponse error: $responseMessage")
                    showErrorSnackBar(responseMessage)
                }
            }
        }
    }

    /**
     * Function to display Send To PR alert dialog
     */
    private fun displayMarkForPRAlert(errorMessage: String) {
        showAlertDialog("",errorMessage,getString(R.string.SEND_TO_PR), onPositiveClick = {
                dialog: DialogInterface ->
                dialog.dismiss()
                val location:Location? = viewModel.stagingLocationResponse.value?.data?.locations?.get(0)
                if(location != null) {
                    markPalletForPR = true
                    callUnloadTrailerAPI(location, markPalletForPR)
                }

        },getString(R.string.cancel), onNegativeClick = {
                dialog: DialogInterface ->
            dialog.dismiss()
        })
    }

    /**
     * Function to display Recall containers alert dialog
     */
    private fun displayRecallContainers(errorMessage: String) {
        showAlertDialog("",errorMessage,getString(R.string.alert_button_ok), onPositiveClick = {
                dialog: DialogInterface -> dialog.dismiss()

        },getString(R.string.lbl_view_recall_containers), onNegativeClick = {
                dialog: DialogInterface ->

            dialog.dismiss()
            // call view recall containers api
            val containerNumber = viewModel.validationResult?.containerNumber?:""
            if(!containerNumber.isNullOrEmpty()) {
                viewModel.viewRecallContainersAPIRequest(containerNumber)
            }
        })
    }

    /**
     * Nav Handler to Unload Dock Door Fragment
     */
    private fun navigateToUnloadDockDoorFragment() {
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.UnLoadDockDoorFragment, true).build()
        getNavigationController().navigate(R.id.action_unloadStagingLocation_to_unloadDockDoorFragment, null, navOptions)
    }

    /**
     * Nav Handler to unload carton pallet fragment
     */
    private fun navigateToUnloadCartonPalletFragment() {
        val action = UnloadStagingLocationFragmentDirections.actionUnloadStagingLocationToUnloadCartonPalletFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to display Invalid Error message
     */
    private fun showInvalidErrorMessage(message: String?) {
        binding.tvStagingLocationResponse.text = message
        binding.etStagingLocation.requestFocus()
        binding.etStagingLocation.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etStagingLocation)
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to process scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etStagingLocation.setText(scan?.barcode.toString())
        binding.etStagingLocation.text?.length?.let {
            binding.etStagingLocation.setSelection(
                it
            )
            FlareLog.i(TAG, "StagingLocation field focused")
            validateStagingLocation()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}
