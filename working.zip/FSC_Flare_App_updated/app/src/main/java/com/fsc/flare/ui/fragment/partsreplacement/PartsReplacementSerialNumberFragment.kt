package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementSerialBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.PreferenceKeys
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementSerialNumberFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementSerialNumberFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: PartsRepalcementSerialAdapter
    private lateinit var partsReplacementSerialBinding: FragmentPartsReplacementSerialBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>
    var serialNumberList = mutableListOf<String>()
    private var serialList = ArrayList<String>()
    private var scannedSerial = ""

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementSerialBinding =
            FragmentPartsReplacementSerialBinding.inflate(inflater, container, false)
        partsReplacementSerialBinding.lifecycleOwner = this
        return partsReplacementSerialBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        if (taskDetails != null) {
            serialNumberList = viewModel.getSerialList()
            if (!viewModel.getSerialNumberList().isNullOrEmpty()) {
                serialList = viewModel.getSerialNumberList() as ArrayList<String>
                partsReplacementSerialBinding.tvSerialValue.text =
                    "(${serialNumberList.size}/${viewModel.getSerialNumberCount()})"
                partsReplacementSerialBinding.tvSerialNumberValue.visibility = View.VISIBLE
                partsReplacementSerialBinding.tvSerialNumberReadOnlyLbl.visibility = View.VISIBLE
                partsReplacementSerialBinding.tvSerialNumberValue.text = serialList.get(0)
            }
            setupRecyclerView()
        }

        partsReplacementSerialBinding.etSerialNumber.doAfterTextChanged {
            partsReplacementSerialBinding.tvSerialNumberResponse.text = null
        }

        partsReplacementSerialBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementSerialBinding.etSerialNumber)
                    if (partsReplacementSerialBinding.etSerialNumber.isFocused) {
                        validateTest()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementSerialBinding.etSerialNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementSerialBinding.etSerialNumber)
                validateTest()
            }
            false
        }
    }

    private fun validateTest() {
        if (partsReplacementSerialBinding.etSerialNumber.text.toString().trim()
                .isNotEmpty() && partsReplacementSerialBinding.tvSerialNumberValue.text.toString()
                .trim() == partsReplacementSerialBinding.etSerialNumber.text.toString().trim()
        ) {
            serialNumberValidate()
        } else {
            displayErrorMessage(getString(R.string.serial_number_invalid))
        }
    }

    private fun serialNumberValidate() {
        val taskDetail = viewModel.getMoveTaskDetails()
        if (taskDetail != null) {
            val serialNumber = partsReplacementSerialBinding.etSerialNumber.text.toString().trim()
            if (serialNumberList.size < viewModel.getSerialNumberCount()) {
                if (!serialNumberList.contains(serialNumber)) {
                    if (serialList.contains(serialNumber)) {
                        FlareLog.i(TAG, "serialList contains")
                        scannedSerial =
                            partsReplacementSerialBinding.etSerialNumber.text.toString().trim()
                        showSuccessSnackBar(resources.getString(R.string.serial_number_is_validated))
                        serialNumberUpdate()
                    }
                } else {
                    displayErrorMessage(resources.getString(R.string.duplicate_serial))
                }
            } else {
                partsReplacementSerialBinding.etSerialNumber.text = null
                navigateToPartsPutawayLocationsFragment()
            }
        }
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementSerialBinding.etSerialNumber.setText(scan?.barcode.toString())
        partsReplacementSerialBinding.etSerialNumber.text?.length?.let {
            partsReplacementSerialBinding.etSerialNumber.setSelection(it)
        }
        if (partsReplacementSerialBinding.tvSerialNumberValue.text.toString()
                .trim() == partsReplacementSerialBinding.etSerialNumber.text.toString().trim()
        ) {
            serialNumberValidate()
        } else {
            displayErrorMessage(getString(R.string.serial_number_invalid))
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToPartsPutawayLocationsFragment() {
        viewModel.resetSerialNumber()
        viewModel.setIndexCountValue(0)
        val action = PartsReplacementSerialNumberFragmentDirections.actionPartsReplacementSerialNumberFragmentToPartsReplacementPutawayLocationFragment()
        findNavController().navigate(action)
    }

    private fun navigateToPartsPutawayContainerFragment() {
        viewModel.resetSerialNumber()
        val action = PartsReplacementSerialNumberFragmentDirections.actionPartsReplacementSerialNumberFragmentToPartsReplacementPartsContainerFragment()
        findNavController().navigate(action)
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementSerialBinding.tvSerialNumberResponse.text = errorMessage
        partsReplacementSerialBinding.etSerialNumber.requestFocus()
        partsReplacementSerialBinding.etSerialNumber.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementSerialBinding.etSerialNumber)
    }

    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        partsReplacementSerialBinding.rvSerial.layoutManager = LinearLayoutManager(fragmentContext)
        serialListAdapter = PartsRepalcementSerialAdapter(serialNumberList as ArrayList<String>,getString(R.string.lbl_serial_v3))
        partsReplacementSerialBinding.rvSerial.adapter = serialListAdapter
    }

    private fun serialNumberUpdate() {
        serialNumberList.add(partsReplacementSerialBinding.etSerialNumber.text.toString().trim())
        serialListAdapter.notifyDataSetChanged()
        partsReplacementSerialBinding.etSerialNumber.text = null
        val taskDetail = viewModel.getMoveTaskDetails()
        if (taskDetail != null) {
            partsReplacementSerialBinding.tvSerialValue.text = String.format(getString(R.string.actual_by_required), serialNumberList.size, viewModel.getSerialNumberCount())
            if (serialNumberList.size == viewModel.getSerialNumberCount()) {
                partsReplacementSerialBinding.etSerialNumber.isEnabled = false
                saveSerialListToSharedPref()
                if (viewModel.getIndexCountValue() < viewModel.getTaskDetailsSize()-1) {
                    viewModel.setIndexCountValue(viewModel.getIndexCountValue()+1)
                    navigateToPartsPutawayContainerFragment()
                } else {
                    navigateToPartsPutawayLocationsFragment()
                }
            } else {
                partsReplacementSerialBinding.tvSerialNumberValue.text =
                    serialList.get(serialNumberList.size)
            }
        }
    }

    private fun saveSerialListToSharedPref() {
        val json = Gson().toJson(serialNumberList)
        sharedPreferences.edit().putString(PreferenceKeys.PartsReplacement.PUTAWAY_SERIAL_NUMBER_LIST, json)
            .apply()
    }

}