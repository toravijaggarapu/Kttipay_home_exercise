package com.fsc.flare.ui.fragment.commontasks

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmBlindPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.observeFlowOnUI
import com.fsc.flare.utils.setNavigationResult
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull

const val BLIND_PALLET_RESULT = "blindPalletResult"

@AndroidEntryPoint
class CreateBlindPalletFragment : BaseFragment(), FlareScannable {

    private lateinit var binding: FragmentInvmBlindPalletBinding
    private val viewModel: CreateBlindPalletViewModel by viewModels()

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInvmBlindPalletBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeFlowOnUI { observeScreenEvents() }
        observeFlowOnUI { observeErrors() }
        handleEnterKeyEvent()
        handleTouchEvent()
        setupViews()
    }

    private fun setupViews() {
        binding.tvInventoryMovement.text = getString(R.string.lbl_receiving)
        binding.btnNewPallet.setOnClickListener{
            viewModel.generatePalletNumber()
        }
    }

    /**
     * Observe errors from view model.
     */
    private suspend fun observeErrors() {
        viewModel.blindPalletErrorState.filterNotNull().collect { error ->

            /**
             *  Convert different error types into meaningful message.
             */
            val errorMessage = when (error) {
                is ErrorMessage.Error -> {
                    error.errorMessage
                }

                is ErrorMessage.InvalidPalletError -> {
                    getString(
                        R.string.pallet_prefix_length_validation,
                        error.containerType.ctyId,
                        error.containerType.ctyContainerLength
                    )
                }

                ErrorMessage.PalletAlreadyExist -> {
                    getString(R.string.pallet_already_exist)
                }

                ErrorMessage.SomethingWentWrong -> {
                    getString(R.string.lbl_something_went_wrong)
                }

                ErrorMessage.ClearError -> null
            }

            binding.errResponse.text = errorMessage
        }
    }

    /**
     * Observe screen events from view model.
     */
    private suspend fun observeScreenEvents() {
        viewModel.blindPalletViewState.filterNotNull().collect { event ->
            when (event) {
                /**
                 *  Screen Progressbar show hide events are handle from here.
                 */
                is CreateBlindPalletEvent.ProgressBar -> {
                    binding.incProgressBar.progressLoading.visibility = if (event.isShowProgress)
                        View.VISIBLE
                    else
                        View.GONE
                }

                /**
                 *  Newly generated pallet number will be received here..
                 */
                is CreateBlindPalletEvent.GeneratedPalletNumber -> {
                    binding.palletNumber.setText(event.palletNumber)
                    delay(1000)
                    setNavigationResult(key = BLIND_PALLET_RESULT,result = event.palletNumber)
                    findNavController().popBackStack()
                }
            }
        }
    }

    /**
     * Validate pallet number
     */
    private fun validatePallet() {
        if (binding.palletNumber.isFocused && !binding.palletNumber.text.isNullOrEmpty()){
            viewModel.validatePallet(binding.palletNumber.text.toString().trim())
        }
    }

    private fun handleEnterKeyEvent() {
        binding.palletNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validatePallet()
            }
            false
        }
    }

    private fun handleTouchEvent() {
        binding.rootLayout.apply {
            setOnTouchListener { v, event ->
                when (event?.action) {

                    MotionEvent.ACTION_DOWN -> {
                        validatePallet()
                    }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }

                v?.onTouchEvent(event) ?: true
            }
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        scan?.barcode.toString().trim().let {
            binding.palletNumber.setText(it)
            viewModel.validatePallet(it)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        super.onScanError(scanRaw, ex)
        FlareLog.i(this::class.simpleName.toString(), "onScanError: $scanRaw")
    }
}