package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentNonStorageOrEmptyLocBinding
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


@AndroidEntryPoint
class NonStorageOrEmptyLocFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentNonStorageOrEmptyLocBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentNonStorageOrEmptyLocBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val data = viewModel.getLocation()
        if (data != null) {
            val location = data.locations[0]
            binding.zoneGroup.text = location.groupDescription
            binding.locationId.text = location.locationBarcode
            binding.locationClass.text = getLocationClass(location.classification)
            binding.locationType.text = getLocationType(location.locType)
            binding.status.text = getLocationStatus(location.status)
            binding.locationCapacity.text = location.uom.netVolume.toString()
            binding.locationCapacityUom.text = location.uom.volumeUom

            binding.btnOk.setOnClickListener {
                val action = NonStorageOrEmptyLocFragmentDirections.actionNonStorageLocationDescFragmentToLocationFragment()
                val navOptions =  NavOptions.Builder().setPopUpTo(R.id.inquiryLocation, true).build()
                getNavigationController().navigate(action,navOptions)
            }
        }
    }
}