package com.fsc.flare.ui.fragment.inventory.inventoryMovement

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInvmDestinationLocationBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.AlertMessages
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmDestinationLocationViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.InvmSharedViewModel
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.NavigationFromDestinationScan
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.invmViewModels.SnackBarState
import com.fsc.flare.ui.fragment.inventory.inventoryMovement.model.getSourceDetails
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.ItemCategory.HAZMAT
import com.fsc.flare.utils.Constants.ItemCategory.NON_HAZMAT
import com.fsc.flare.utils.Constants.TaskModes.SYSTEM_DIRECTED
import com.fsc.flare.utils.Constants.TaskModes.USER_DIRECTED
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.enableOrDisableField
import com.fsc.flare.utils.getNavigationResult
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "InvmDestinationLocationFragment"

@AndroidEntryPoint
class InvmDestinationLocationFragment : BaseFragment() {

    private val sharedViewModel: InvmSharedViewModel by activityViewModels()
    private val viewModel: InvmDestinationLocationViewModel by viewModels()
    private lateinit var binding: FragmentInvmDestinationLocationBinding


    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentInvmDestinationLocationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvInventoryMovement.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null).plus(" - ").plus(sharedViewModel.selectedTaskMode)
        setupScreen()
        viewModel.setRequiredData(
            sharedViewModel.selectedTaskMode,
            sharedViewModel.selectedTaskGroup,
            sharedViewModel.taskDetails,
            sharedViewModel.getDestinationLocationResponse.data,
            sharedViewModel.sourceDetails,
            sharedViewModel.taskGroups)
        handleTouchEvent()
        handleEnterKeyEvent()
        setTextChangedListener()
        observeEvents()
    }

    private fun setTextChangedListener() {
        binding.scanDestinationLoc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.errResponse.text = null
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun setupScreen() {
        if(sharedViewModel.selectedTaskMode == USER_DIRECTED){
            binding.sourceDetails = sharedViewModel.sourceDetails
            binding.executePendingBindings()
            binding.quantity.text = sharedViewModel.getRequiredQuantity().toString().plus(" ").plus(sharedViewModel.getRequiredQuantityUOM())
            binding.reasonCode.text = sharedViewModel.selectedReasonCode?.reasonCodeDescription ?: ""
        }else{
            binding.sourceDetails = sharedViewModel.taskDetails.getSourceDetails()
            binding.executePendingBindings()
            binding.quantity.text = sharedViewModel.taskDetails.qty.toString().plus(" ").plus(sharedViewModel.taskDetails.taskQtyUom.orEmpty())
            binding.reasonCode.text = sharedViewModel.taskDetails.reasonCodeDesc
        }
        binding.destinationLocation.text = sharedViewModel.getDestinationLocationResponse.data?.locationBarcode
    }

    private fun handleEnterKeyEvent() {
        binding.scanDestinationLoc.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
    }

        private fun handleTouchEvent() {
            binding.rootLayout.apply {
                setOnTouchListener { v, event ->
                    when (event?.action) {
                        MotionEvent.ACTION_DOWN -> {
                            validateField()
                        }

                    MotionEvent.ACTION_UP -> {
                        performClick()
                    }
                }
                v?.onTouchEvent(event) ?: true
            }
        }
    }

    private fun validateField() {
        if (!binding.scanDestinationLoc.text.isNullOrEmpty()) {
            if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED
                || (sharedViewModel.selectedTaskMode == USER_DIRECTED && !sharedViewModel.sourceDetails.data?.taskInfo?.taskId.isNullOrEmpty())
            ) {
                viewModel.invmTaskComplete(binding.scanDestinationLoc.text.toString().trim(), "")
            } else {
                viewModel.submitDestinationLocation(
                    destLocation = binding.scanDestinationLoc.text.toString().trim(),
                    containerNbr = sharedViewModel.sourceDetails.container,
                    reasonCode = sharedViewModel.selectedReasonCode?.reasonCode,
                    itemId = sharedViewModel.sourceDetails.data?.itemId,
                    itemCategory = if (sharedViewModel.sourceDetails.data?.hazmatRequired == Constants.YES) HAZMAT else NON_HAZMAT,
                    serialNumbers = sharedViewModel.scannedSerials,
                    qty = sharedViewModel.getRequiredQuantity(),
                    palletNbr = sharedViewModel.sourceDetails.data?.palletNbr ?: "",
                    palletId = sharedViewModel.sourceDetails.data?.palletId ?: ""
                )
            }
        }
    }

    private fun observeEvents() {
        viewModel.showProgress.observe(viewLifecycleOwner) { showProgress ->
            binding.progressBar.visibility = if (showProgress) View.VISIBLE else View.GONE
        }

        viewModel.showError.observe(viewLifecycleOwner) { message ->
            if (message.isNotEmpty()) {
                binding.scanDestinationLoc.selectAll()
            }
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            binding.errResponse.text = message ?: ""
        }

        viewModel.showAlert.observe(viewLifecycleOwner) { alert ->
            alert?.let {
                showAlertDialog(
                    title = "",
                    message = getString(R.string.destination_location_does_not_have_the_pallet)
                ) {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    getNavigationController().navigate(InvmDestinationLocationFragmentDirections.actionInvmDestinationLocationFragmentToInvmBlindPalletFragment())
                }
            }
        }

        viewModel.showSnackBar.observe(viewLifecycleOwner) { snackType ->
            snackType?.let {
                hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                when (it) {
                    is SnackBarState.Success -> {
                        showSuccessSnackBar(it.message)
                    }

                    is SnackBarState.Error -> {
                        showErrorSnackBar(it.errorMessage)
                    }
                }
            }
        }

        viewModel.navigateToScreen.observe(viewLifecycleOwner) { inventoryNavigation ->
            inventoryNavigation?.let {
                when (inventoryNavigation) {

                    is NavigationFromDestinationScan.NavigateToTaskModes -> {
                        binding.scanDestinationLoc.enableOrDisableField(isEnable = false)
                        sharedViewModel.clearData()
                        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                        showSuccessSnackBarStd(inventoryNavigation.message) {
                            binding.scanDestinationLoc.text = null
                            getNavigationController().navigate(InvmDestinationLocationFragmentDirections.actionInvmDestinationLocationFragmentToInvmTaskModesFragment())
                        }
                    }

                    is NavigationFromDestinationScan.NavigateToSourceScan -> {
                        sharedViewModel.taskDetails = inventoryNavigation.taskDetails
                        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                        showSuccessSnackBarStd(getString(R.string.inventory_movement_successful)){
                            binding.scanDestinationLoc.text = null
                            getNavigationController().navigate(InvmDestinationLocationFragmentDirections.actionInvmDestinationLocationFragmentToInvmSourceScanFragment())
                        }
                    }
                }
            }
        }

        viewModel.showAlert.observe(viewLifecycleOwner){alert ->
            alert?.let{
                when(alert){
                    AlertMessages.CreateNewPallet -> {
                        showAlertDialog(
                            title = "",
                            message = getString(R.string.destination_location_does_not_have_the_pallet)
                        ){
                            getNavigationController().navigate(InvmDestinationLocationFragmentDirections.actionInvmDestinationLocationFragmentToInvmBlindPalletFragment())
                        }
                    }
                }
            }
        }

        getNavigationResult<String>(BLIND_PALLET_RESULT) { blindPalletNbr ->

            if (sharedViewModel.selectedTaskMode == SYSTEM_DIRECTED
                || (sharedViewModel.selectedTaskMode == USER_DIRECTED && !sharedViewModel.sourceDetails.data?.taskInfo?.taskId.isNullOrEmpty())) {
                viewModel.invmTaskComplete(binding.scanDestinationLoc.text.toString().trim(),blindPalletNbr)
            } else {
                viewModel.submitDestinationLocation(
                    destLocation = binding.scanDestinationLoc.text.toString().trim(),
                    containerNbr = sharedViewModel.sourceDetails.container,
                    reasonCode = sharedViewModel.selectedReasonCode?.reasonCode,
                    itemId = sharedViewModel.sourceDetails.data?.itemId,
                    itemCategory = if (sharedViewModel.sourceDetails.data?.hazmatRequired == Constants.YES) HAZMAT else NON_HAZMAT,
                    serialNumbers = sharedViewModel.scannedSerials,
                    qty = sharedViewModel.getRequiredQuantity(),
                    palletNbr = blindPalletNbr,
                    palletId = ""
                )
            }
        }
    }


    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        binding.scanDestinationLoc.setText(scan?.barcode.toString())
        binding.scanDestinationLoc.text?.length?.let {binding.scanDestinationLoc.setSelection(it)}
        validateField()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearStates()
    }
}