package com.fsc.flare.ui.fragment.pickingforward

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.lookups.Lookup
import com.fsc.flare.source.data.dto.lookups.toLookUpCodes
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRepackTransParamResponse
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideResponse
import com.fsc.flare.source.data.dto.pickingforward.req.BuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.CycleCountTriggerRequest
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.req.RepairTaskRequest
import com.fsc.flare.source.data.dto.pickingforward.req.SkipBuildCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.SkipPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskCasePickCompleteReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickActiveStagingReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickQtyUpdateReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskStagingRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateCaseOverrideRequest
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteCartonReq
import com.fsc.flare.source.data.dto.pickingforward.req.ValidateToteReq
import com.fsc.flare.source.data.dto.pickingforward.req.WorkOrderDetailsReq
import com.fsc.flare.source.data.dto.pickingforward.res.AllocationTypeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.BuildCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.CycleCountTriggerResponse
import com.fsc.flare.source.data.dto.pickingforward.res.EndPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.KitStagingLocationResponse
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.pickingforward.res.PickingSerialOrItemCodeResponse
import com.fsc.flare.source.data.dto.pickingforward.res.RepairTaskResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ShortPickToteResponse
import com.fsc.flare.source.data.dto.pickingforward.res.SkipPickCartRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskCasePickCompleteRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickActiveStagingRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickQtyUpdateRes
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.pickingforward.res.UpcOrSlpResponse
import com.fsc.flare.source.data.dto.pickingforward.res.ValidateToteRes
import com.fsc.flare.source.data.dto.pickingforward.res.WorkOrderDetailsResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.receiving.serial.LotNumReqBody
import com.fsc.flare.source.data.dto.receiving.serial.LotNumberResponse
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.source.data.dto.taskgroup.TaskGroupResponse
import com.fsc.flare.source.repository.PickingForwardRepository
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import java.lang.reflect.Type
import javax.inject.Inject

private const val TAG = "PickingForwardViewModel"
const val IP_VALUE = "IP"

@HiltViewModel
class PickingForwardViewModel @Inject constructor(
    private val pickingRepository: PickingForwardRepository,
    private var sharedPreferences: SharedPreferences
    ) : BaseViewModel() {

    var cartToPRLocationTransferValue: Int = 21
    var isComingFromPickCartFlow:Boolean = false
    var isLTLCubingEnabled:Boolean = false
    val rpcTransEnabledKey = 19
    val ltlFLowEnabledKey = 17
    var orderType: String? = null
    var isRTV = false
    val taskPickResponse: MutableLiveData<Resource<TaskPickResponse>> = SingleLiveEvent()
    val rtvTaskPickResponse = SingleLiveEvent<Resource<TaskPickResponse>>()
    val workOrderDetailsResponse: MutableLiveData<Resource<WorkOrderDetailsResponse>> = SingleLiveEvent()
    val taskGroupResponse: MutableLiveData<Resource<TaskGroupResponse>> = SingleLiveEvent()
    val validateToteResponse: MutableLiveData<Resource<ValidateToteRes>> = SingleLiveEvent()
    val endPickCartResponse: MutableLiveData<Resource<EndPickCartRes>> = SingleLiveEvent()
    val skipPickCartResponse: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val skipPickCartResponseCasePick: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val skipPickCartResponseLTL: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val skipPickCartResponseKittingActive: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val skipPickCartResponseKittingCasepick: MutableLiveData<Resource<SkipPickCartRes>> = SingleLiveEvent()
    val taskBuildCartResponse: MutableLiveData<Resource<BuildCartRes>> = SingleLiveEvent()
    val validateSlotResponse: MutableLiveData<Resource<BuildCartRes>> = SingleLiveEvent()
    val containerResponse = SingleLiveEvent<Resource<InventoryContainerResponse>>()
    val taskCasePickCompleteResponse: MutableLiveData<Resource<TaskCasePickCompleteRes>> = SingleLiveEvent()
    val taskPickQtyUpdateResponse: MutableLiveData<Resource<TaskPickQtyUpdateRes>> = SingleLiveEvent()
    val locationClassResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val taskactivepickstagingresponse: MutableLiveData<Resource<TaskPickActiveStagingRes>> = SingleLiveEvent()
    val taskstagingresponse: MutableLiveData<Resource<TaskPickActiveStagingRes>> = SingleLiveEvent()
    val lotNumberResponse: MutableLiveData<Resource<LotNumberResponse>> = SingleLiveEvent()
    val serialItemIdValidationResponse: MutableLiveData<Resource<PickingSerialOrItemCodeResponse>> = SingleLiveEvent()
    val transactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val ltlTransactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val itemAttrTransParamResponse: MutableLiveData<Resource<MPRepackTransParamResponse>> = SingleLiveEvent()
    val cartToPrLocationTransParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val upcOrSlpResponse: MutableLiveData<Resource<UpcOrSlpResponse>> = SingleLiveEvent()
    val inventoryLocksResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val allocationTypeResponse = SingleLiveEvent<Resource<AllocationTypeResponse>>()
    val shortPickTotesResponse: MutableLiveData<Resource<ShortPickToteResponse>> = SingleLiveEvent()
    val transferTotePRResponse: MutableLiveData<Resource<ValidateToteRes>> = SingleLiveEvent()
    val kittingStagingLocationResponse: MutableLiveData<Resource<KitStagingLocationResponse>> = SingleLiveEvent()
    val validateContainerOverrideResponse: MutableLiveData<Resource<ValidatePalletOverrideResponse>> = SingleLiveEvent()
    val cycleCountTriggerResponse: MutableLiveData<Resource<CycleCountTriggerResponse>> = SingleLiveEvent()
    private var serialNumberList: MutableLiveData<List<String>> = MutableLiveData()

    val initiateRepairFlowResponse: MutableLiveData<Resource<RepairTaskResponse>> =
        SingleLiveEvent()

    fun getWorkOrderDetails(workOrderDetailsReq: WorkOrderDetailsReq) = viewModelScope.launch {
        FlareLog.i(TAG, "work Order Details Request: $workOrderDetailsReq")
        workOrderDetailsResponse.postValue(Resource.Loading())
        val response = pickingRepository.getWorkOrderDetails(workOrderDetailsReq)
        workOrderDetailsResponse.postValue(handleWorkOrderDetailsResponse(response))
    }

    fun getTaskPick(taskPickReq: TaskPickReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getTaskPick Request: $taskPickReq")
        taskPickResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTaskPick(taskPickReq)
        taskPickResponse.postValue(handleTaskPickResponse(response))
    }

   private fun fetchRtvTask(taskPickReq: TaskPickReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getTaskPick Request: $taskPickReq")
        rtvTaskPickResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTaskPick(taskPickReq)
        rtvTaskPickResponse.postValue(handleTaskPickResponse(response))
    }

     fun fetchRtvTasks() {
        fetchRtvTask(
            TaskPickReq(
                allocationType = sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, null) ?: "",
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                custId =  sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskGroup = sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_CODE, null) ?: "",
                isLTLcubing = isLTLCubingEnabled,
                orderType = orderType,
                stageRequired = fetchStagingRequiredValue()
            )
        )
    }

    private fun fetchStagingRequiredValue(): Boolean {
        if (isRTV) {
            val taskGroup = sharedPreferences.getString(
                PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE,
                null
            )
            getConfiguredOrderTypes()?.takeIf {
                isPickOrderTypeEnabled() && it.isNotEmpty() && it.contains(taskGroup)
            }?.let {
                when (taskGroup) {
                    AllocationType.PICK_FROM_RESERVE_RTV.code,
                    AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV.code,
                    AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV.code,
                    AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV.code -> {
                        val orderTypes =
                            (sharedPreferences.getString(PreferenceKeys.PCL_ORD_TYPES_PREFERENCE, null).orEmpty()
                                .toLookUpCodes() +
                                    sharedPreferences.getString(PreferenceKeys.LTL_ORD_TYPES_PREFERENCE, null)
                                        .orEmpty().toLookUpCodes()).distinctBy { it.lookupCode }
                        orderType = orderTypes.getOrNull(0)?.lookupCode
                        return true
                    }

                    else -> return true
                }
            } ?: return true

        }
        return false
    }

    fun getTaskPickCart(taskPickCartReq: TaskPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getTaskPickCart Request: $taskPickCartReq")
        taskPickResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTaskPickCart(taskPickCartReq)
        taskPickResponse.postValue(handleTaskPickResponse(response))
    }

    private fun handleWorkOrderDetailsResponse(response: Response<WorkOrderDetailsResponse>): Resource<WorkOrderDetailsResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "WorkOrder Details Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "WorkOrder Details Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    private fun handleTaskPickResponse(response: Response<TaskPickResponse>): Resource<TaskPickResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getTaskPickResponse Success: $resultResponse")
                resultResponse.taskDetails?.let { setSerialNumberList(it.serialNumberList) }
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getTaskPick Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateTote(validateToteReq: ValidateToteReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateTote Request: $validateToteReq")
        validateToteResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateTote(validateToteReq)
        validateToteResponse.postValue(handleToteValidateResponse(response))
    }



    private fun handleToteValidateResponse(response: Response<ValidateToteRes>): Resource<ValidateToteRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateToteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateTote Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getTaskGroups(allocType:String) = viewModelScope.launch {
        taskGroupResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTaskGroups(allocType)
        taskGroupResponse.postValue(handleTaskGroupsResponse(response))
    }

    private fun handleTaskGroupsResponse(response: Response<TaskGroupResponse>): Resource<TaskGroupResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getTaskGroupsResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getTaskGroups Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get transaction param details
     */
    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionParamResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTransactionParam(transactionParamRequest)
        transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to get transaction param details
     */
    fun getLTLTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        ltlTransactionParamResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTransactionParam(transactionParamRequest)
        ltlTransactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to get transaction param details
     */
    fun getCartToPRransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        cartToPrLocationTransParamResponse.postValue(Resource.Loading())
        val response = pickingRepository.getTransactionParam(transactionParamRequest)
        cartToPrLocationTransParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(transactionParamResponse.code(), transactionParamResponse.errorBody(), transactionParamResponse.message())
            FlareLog.e(TAG, "TransactionParam Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get transaction param details
     */
    fun getItemAttributesTransactionParam(mprTransParamRequest: MPRTransParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "Item Attributes transactionParam Request: $mprTransParamRequest")
        itemAttrTransParamResponse.postValue(Resource.Loading())
        val response = pickingRepository.getItemAttrTransactionParam(mprTransParamRequest)
        itemAttrTransParamResponse.postValue(handleItemAttrTransactionParamResponse(response))
    }

    /**
     * method to handle MPR transaction param response
     */
    private fun handleItemAttrTransactionParamResponse(response: Response<MPRepackTransParamResponse>): Resource<MPRepackTransParamResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "MPRTransactionParamResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "MPRTransactionParamResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun pickEndCart(endPickCartReq: EndPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickEndCart Request: $endPickCartReq")
        endPickCartResponse.postValue(Resource.Loading())
        val response = pickingRepository.pickEndCart(endPickCartReq)
        endPickCartResponse.postValue(handleEndPickCartResponse(response))
    }

    private fun handleEndPickCartResponse(response: Response<EndPickCartRes>): Resource<EndPickCartRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickEndCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "pickEndCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun pickSkipCart(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickSkipCart Request: $skipPickCartReq")
        skipPickCartResponse.postValue(Resource.Loading())
        val response = pickingRepository.pickSkipCart(skipPickCartReq)
        skipPickCartResponse.postValue(handleSkipPickCartResponse(response))
    }

    fun pickSkipCartLTL(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickSkipCartCasePick Request: $skipPickCartReq")
        skipPickCartResponseLTL.postValue(Resource.Loading())
        val response = pickingRepository.pickSkipCart(skipPickCartReq)
        skipPickCartResponseLTL.postValue(handleSkipPickCartResponse(response))
    }

    fun pickSkipCartCasePick(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickSkipCartCasePick Request: $skipPickCartReq")
        skipPickCartResponseCasePick.postValue(Resource.Loading())
        val response = pickingRepository.pickSkipCart(skipPickCartReq)
        skipPickCartResponseCasePick.postValue(handleSkipPickCartResponse(response))
    }

    fun pickSkipCartKittingActive(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickSkipCartCasePick Request: $skipPickCartReq")
        skipPickCartResponseKittingActive.postValue(Resource.Loading())
        val response = pickingRepository.pickSkipCart(skipPickCartReq)
        skipPickCartResponseKittingActive.postValue(handleSkipPickCartResponse(response))
    }

    fun pickSkipCartKittingCasepick(skipPickCartReq: SkipPickCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "pickSkipCartCasePick Request: $skipPickCartReq")
        skipPickCartResponseKittingCasepick.postValue(Resource.Loading())
        val response = pickingRepository.pickSkipCart(skipPickCartReq)
        skipPickCartResponseKittingCasepick.postValue(handleSkipPickCartResponse(response))
    }

    fun buildSkipCart(skipBuildCartReq: SkipBuildCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "buildSkipCart Request: $skipBuildCartReq")
        skipPickCartResponse.postValue(Resource.Loading())
        val response = pickingRepository.buildSkipCart(skipBuildCartReq)
        skipPickCartResponse.postValue(handleSkipPickCartResponse(response))
    }

    private fun handleSkipPickCartResponse(response: Response<SkipPickCartRes>): Resource<SkipPickCartRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "pickSkipCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "pickSkipCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun taskBuildCart(buildCartReq: BuildCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "taskBuildCart Request: $buildCartReq")
        taskBuildCartResponse.postValue(Resource.Loading())
        val response = pickingRepository.taskBuildCart(buildCartReq)
        taskBuildCartResponse.postValue(handleTaskBuildCartResponse(response))
    }

    fun validateSlot(buildCartReq: BuildCartReq) = viewModelScope.launch {
        FlareLog.i(TAG, "Validate Slot Request: $buildCartReq")
        validateSlotResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateSlot(buildCartReq)
        validateSlotResponse.postValue(handleValidateSlotResponse(response))
    }
    private fun handleValidateSlotResponse(response: Response<BuildCartRes>): Resource<BuildCartRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSlotResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateSlotResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleTaskBuildCartResponse(response: Response<BuildCartRes>): Resource<BuildCartRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskBuildCartResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescriptionForGilt(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "taskBuildCart Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get container details
     */
    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = pickingRepository.getContainer(container, itemInfo)
        containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Container Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun taskcasepickcomplete(taskCasePickCompleteReq: TaskCasePickCompleteReq) = viewModelScope.launch {
        taskCasePickCompleteReq.givenCartonNbr = givenCartonNbr
        taskCasePickCompleteReq.serialNumbers = scannedSerialNumbers
        FlareLog.i(TAG, "taskcasepickcomplete Request: $taskCasePickCompleteReq")
        taskCasePickCompleteResponse.postValue(Resource.Loading())
        val response = pickingRepository.taskcasepickcomplete(taskCasePickCompleteReq)
        taskCasePickCompleteResponse.postValue(handleTaskCasePickCompleteResponse(response))
    }

    private fun handleTaskCasePickCompleteResponse(response: Response<TaskCasePickCompleteRes>): Resource<TaskCasePickCompleteRes>? {
        if (response.isSuccessful) {
            givenCartonNbr = null
            scannedSerialNumbers.clear()
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskcasepickcompleteResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(
                response.code(),
                response.errorBody(),
                response.message()
            )
            FlareLog.e(TAG, "taskcasepickcomplete Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun taskPickQtyUpdate(taskPickQtyUpdateReq: TaskPickQtyUpdateReq) = viewModelScope.launch {
        FlareLog.i(TAG, "taskPickQtyUpdate Request: $taskPickQtyUpdateReq")
        taskPickQtyUpdateResponse.postValue(Resource.Loading())
        val response = pickingRepository.taskPickQtyUpdate(taskPickQtyUpdateReq)
        taskPickQtyUpdateResponse.postValue(handleTaskPickQtyUpdateResponse(response))
    }

    private fun handleTaskPickQtyUpdateResponse(response: Response<TaskPickQtyUpdateRes>): Resource<TaskPickQtyUpdateRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskPickQtyUpdateResponse Success: $resultResponse")
                resultResponse.taskDetails?.let { setSerialNumberList(it.serialNumberList) }
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "TaskPickQtyUpdate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validateStagingLocation Request: $locationClassReq")
        locationClassResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateStagingLocation(locationClassReq)
        locationClassResponse.postValue(handleLocationClassResponse(response))
    }

    private fun handleLocationClassResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getKittingStagingLocation(orderId:Int, orderType: String) = viewModelScope.launch {
        kittingStagingLocationResponse.postValue(Resource.Loading())
        val response = pickingRepository.getKitStagingLocation(orderId, orderType)
        kittingStagingLocationResponse.postValue(handleKitStagingLocationResponse(response))
    }
    private fun handleKitStagingLocationResponse(response: Response<KitStagingLocationResponse>): Resource<KitStagingLocationResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Kit Staging Location Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun taskactivepickstaging(taskPickActiveStagingReq: TaskPickActiveStagingReq) = viewModelScope.launch {
        FlareLog.i(TAG, "taskactivepickstaging Request: $taskPickActiveStagingReq")
        taskactivepickstagingresponse.postValue(Resource.Loading())
        val response = pickingRepository.taskactivepickstaging(taskPickActiveStagingReq)
        taskactivepickstagingresponse.postValue(handleTaskActivePickStagingResponse(response))
    }

    private fun handleTaskActivePickStagingResponse(response: Response<TaskPickActiveStagingRes>): Resource<TaskPickActiveStagingRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskactivepickstagingResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "taskactivepickstaging Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun taskstaging(taskStagingRequest: TaskStagingRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "taskstaging Request: $taskStagingRequest")
        taskstagingresponse.postValue(Resource.Loading())
        val response = pickingRepository.taskstaging(taskStagingRequest)
        taskstagingresponse.postValue(handleTaskStagingResponse(response))
    }

    private fun handleTaskStagingResponse(response: Response<TaskPickActiveStagingRes>): Resource<TaskPickActiveStagingRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "taskstagingResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "taskstaging Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    /**
     * method to validate lot number API
     */
    fun validateLotNumber(lotNumReqBody: LotNumReqBody) = viewModelScope.launch {
        FlareLog.i(TAG, "validateLotNumber Request: $lotNumReqBody")
        lotNumberResponse.postValue(Resource.Loading())
        val lotNumberValidationRes = pickingRepository.validateLotNumber(lotNumReqBody)
        lotNumberResponse.postValue(handleLotNumberValidationResponse(lotNumberValidationRes))
    }

    /**
     * method to handle lot number validation response
     */
    private fun handleLotNumberValidationResponse(response: Response<LotNumberResponse>): Resource<LotNumberResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateLotNumberResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate serial number or itemcode API
     */
    fun validateSerialNumberOrItemCode(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        taskId : Long,
        containerNbr:String,
        containerId:Int
    ) = viewModelScope.launch {
        serialItemIdValidationResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = pickingRepository.validateSerialNumberWithItemCode(serialNumberOrItemId, isOutBoundOnly,pickLocationId, itemId, taskId,containerNbr, containerId)
        serialItemIdValidationResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    /**
     * method to validate serial number or itemcode API
     */
    fun validateSerialNumberOrItemCodeContainer(
        serialNumberOrItemId: String,
        isOutBoundOnly: Boolean,
        pickLocationId: Long,
        itemId: Int,
        containerId: Int
    ) = viewModelScope.launch {
        serialItemIdValidationResponse.postValue(Resource.Loading())
        val serialNumberItemValidationRes = pickingRepository.validateSerialNumberWithItemCode(serialNumberOrItemId, isOutBoundOnly,pickLocationId, itemId, containerId)
        serialItemIdValidationResponse.postValue(handleSerialNumberOrItemIdValidationResponse(serialNumberItemValidationRes))
    }

    /**
     * method to handle serial or Item id validation response
     */
    private fun handleSerialNumberOrItemIdValidationResponse(response: Response<PickingSerialOrItemCodeResponse>): Resource<PickingSerialOrItemCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateSerialNumberResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            return if (response.code() in 400..501) {
                val responseMessage = handleForwardErrorResponse(response.errorBody(), response.message())
                if (responseMessage.isEmpty()) {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: ${response.message()}")
                    Resource.Error(response.message())
                } else {
                    FlareLog.e(TAG, "validateSerialNumberResponse Error: $responseMessage")
                    Resource.Error(responseMessage)
                }
            } else {
                Resource.Error(response.message())
            }
        }
        return null
    }

    fun getInventoryReasonCodes() = viewModelScope.launch {
        inventoryLocksResponse.postValue(Resource.Loading())
        val response = pickingRepository.getInventoryReasonCodes()
        inventoryLocksResponse.postValue(handleInventoryLocksResponse(response))
    }

    private fun handleInventoryLocksResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InventoryLocksResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "InventoryLocksResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getAllocationType(cartNbr: String) = viewModelScope.launch {
        allocationTypeResponse.postValue(Resource.Loading())
        val response = pickingRepository.getAllocationType(cartNbr)
        allocationTypeResponse.postValue(handleAllocationTypeResponse(response))
    }

    private fun handleAllocationTypeResponse(response: Response<AllocationTypeResponse>): Resource<AllocationTypeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "AllocationType Success Response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "AllocationType Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate lot number API
     */
    fun getShortPickedTotes(cartNumber: String, cartId: Int) = viewModelScope.launch {
        shortPickTotesResponse.postValue(Resource.Loading())
        val allocationType: String? = if (isRTV) {
            sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, "")
        } else {
            sharedPreferences.getString(
                PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE,
                ""
            )
        }
        val shortPickedTotesResponse =
            pickingRepository.getShortPickedTotes(cartNumber, cartId, allocationType)
        shortPickTotesResponse.postValue(handleShortPickedTotesResponse(shortPickedTotesResponse))
    }

    /**
     * method to handle lot number validation response
     */
    private fun handleShortPickedTotesResponse(response: Response<ShortPickToteResponse>): Resource<ShortPickToteResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateLotNumberResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateLotNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    fun validateToteCarton(validateToteCartonReq: ValidateToteCartonReq) = viewModelScope.launch {
        FlareLog.i(TAG, "validate Tote Carton Request: $validateToteCartonReq")
        transferTotePRResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateToteCarton(validateToteCartonReq)
        transferTotePRResponse.postValue(handleToteCartonResponse(response))
    }

    private fun handleToteCartonResponse(response: Response<ValidateToteRes>): Resource<ValidateToteRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "LocationClass Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    var taskGroupsList: MutableLiveData<ArrayList<TaskGroup>> = MutableLiveData<ArrayList<TaskGroup>>()
    var taskGroupCodeOptions: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var pickTask: MutableLiveData<TaskPickResponse> = MutableLiveData<TaskPickResponse>()
    var shortPickTotes = ShortPickToteResponse()
    var pickTaskDetails: MutableLiveData<TaskDetails> = MutableLiveData<TaskDetails>()
    var inventoryLocksList: MutableLiveData<List<Lookup>> = MutableLiveData()
    var isOverrideItemAttributes: Int = -1
    var totToPrTransactionParam: Int = -1
    var isShortPick: Boolean = false
    var reasonCode: String = ""
    var givenCartonNbr: String? = null
    var kitStageLocation : MutableLiveData<String?> = MutableLiveData<String?>()
    var scannedSerialNumbers = arrayListOf<String>()

    fun getKitStageLocation() : String?{
        return kitStageLocation.value
    }
    fun setKitStageLocation(kitStageLocation: String?){
        this.kitStageLocation.value = kitStageLocation
    }
    fun settaskGroupCodeOptions(taskGroupOptions: ArrayList<String>) {
        this.taskGroupCodeOptions.value = taskGroupOptions
    }

    fun gettaskGroupCodeOptions(): ArrayList<String>? {
        return taskGroupCodeOptions.value
    }

    fun getTaskGroupsList(): ArrayList<TaskGroup>? {
        return taskGroupsList.value
    }

    fun setTaskGroupsList(taskGroups: ArrayList<TaskGroup>) {
        this.taskGroupsList.value = taskGroups
    }


    fun getPickTask(): TaskPickResponse? {
        return pickTask.value
    }

    fun setPickTask(pickTask: TaskPickResponse) {
        this.pickTask.value = pickTask
    }

    fun getPickTaskDetails(): TaskDetails? {
        return pickTaskDetails.value
    }

    fun setPickTaskDetails(pickTaskDetails: TaskDetails) {
        this.pickTaskDetails.value = pickTaskDetails

        if (pickTaskDetails.uomConversions == null)
            return
        // Initiate ItemUOMConversionUtil object
        if (uomConversionRateUtil == null) {
            uomConversionRateUtil = ItemUOMConversionRateUtil(pickTaskDetails.uomConversions)
        } else {
            // Reuse the existing objects
            uomConversionRateUtil!!.updateHashmap(pickTaskDetails.uomConversions)
        }
    }


    fun validateUPCorSLP(itemCode: String, upcOrSlp:String) = viewModelScope.launch {
        FlareLog.i(TAG, "validateUPCorSLP Request: itemCode: $itemCode , upcOrSlp: $upcOrSlp")
        upcOrSlpResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateUPCorSLP(itemCode, upcOrSlp)
        upcOrSlpResponse.postValue(handleValidateUPCorSLP(response))
    }

    private fun handleValidateUPCorSLP(response: Response<UpcOrSlpResponse>): Resource<UpcOrSlpResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateUPCorSLP Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateUPCorSLP Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getSerialList(): ArrayList<String> {
        val serialNumberList: ArrayList<String>
        val serialListJson = sharedPreferences.getString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, null)
        if (serialListJson != null) {
            val type: Type = object : TypeToken<List<String?>?>() {}.type
            serialNumberList = Gson().fromJson(serialListJson, type)
            return serialNumberList
        }
        return ArrayList()
    }

    fun resetSerialNumber() {
        val json = Gson().toJson(ArrayList<String>())
        sharedPreferences.edit().putString(PreferenceKeys.PickingForward.SERIAL_NUM_LIST, json).apply()
    }

    fun getInventoryLocksList(): List<Lookup> {
        return inventoryLocksList.value!!
    }

    fun setInventoryLocksList(inventoryLocksList: List<Lookup>) {
        this.inventoryLocksList.value = inventoryLocksList
    }

    fun setShortPickTotesList(shortPickToteResponse: ShortPickToteResponse) {
        this.shortPickTotes = shortPickToteResponse
    }

    fun getShortPickedList(): ShortPickToteResponse {
        return shortPickTotes
    }

    fun setToteToPrTransParamValue(totToPrTransactionParamValue: Int){
        this.totToPrTransactionParam = totToPrTransactionParamValue
    }

    fun getToteToPrTransParamValue(): Int {
        return totToPrTransactionParam
    }

    fun updateOrderType(orderType:String?) {
        val taskResp = getPickTask()
        if (taskResp != null) {
            taskResp.orderType = orderType
            setPickTask(taskResp)
        }
    }

    fun validateContainerOverride(validateCaseOverrideRequest: ValidateCaseOverrideRequest) = viewModelScope.launch {
        validateContainerOverrideResponse.postValue(Resource.Loading())
        val response = pickingRepository.validateContainerOverride(validateCaseOverrideRequest)
        validateContainerOverrideResponse.postValue(validateContainerOverride(response))
    }
    private fun validateContainerOverride(response: Response<ValidatePalletOverrideResponse>): Resource<ValidatePalletOverrideResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "handlevalidateContainerOverride Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "handlevalidateContainerOverride Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest : CycleCountTriggerRequest,locationId: Long) = viewModelScope.launch {
        cycleCountTriggerResponse.postValue(Resource.Loading())
        val response = pickingRepository.generateCycleCountToVerifyZeroLocation(cycleCountTriggerRequest, locationId)
        cycleCountTriggerResponse.postValue(handleGenerateCycleCountToVerifyZeroLocation(response))
    }
    private fun handleGenerateCycleCountToVerifyZeroLocation(response: Response<CycleCountTriggerResponse>): Resource<CycleCountTriggerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "cycleCountTriggerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "cycleCountTriggerResponse Error: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun initiateRepairFlow(repairTaskRequest: RepairTaskRequest) =
        viewModelScope.launch {
            FlareLog.i(TAG, "repairTaskRequest Request: $repairTaskRequest")
            initiateRepairFlowResponse.postValue(Resource.Loading())
            val repairTaskResponse =
                pickingRepository.initiateRepairFlow(repairTaskRequest)
            initiateRepairFlowResponse.postValue(
                handleInitiateRepairFlowResponse(
                    repairTaskResponse
                )
            )
        }

    private fun handleInitiateRepairFlowResponse(repairTaskResponse: Response<RepairTaskResponse>): Resource<RepairTaskResponse>? {
        if (repairTaskResponse.isSuccessful) {
            repairTaskResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "repairTaskResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(
                repairTaskResponse.code(),
                repairTaskResponse.errorBody(),
                repairTaskResponse.message()
            )
            FlareLog.e(TAG, "repairTaskResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }
    private var uomConversionRateUtil: ItemUOMConversionRateUtil? = null

    // Calculate task qty if it is valid for innerpack
    fun getTaskQty(taskData: TaskDetails): Int {
        return if (isInnerPack())
            taskData.taskQty / getIPConversionRate()
        else
            taskData.taskQty
    }

    // Get the task qty and appending with UOM for all screens label view
    fun getTaskQtyUOMValue(taskData: TaskDetails): String {
        return if (isInnerPack()) {
            String.format("%d %s", getTaskQty(taskData), IP_VALUE)
        } else String.format("%d %s", taskData.taskQty, taskData.taskQtyUom)
    }

    // Get the pick qty for update the qty
    fun getPickQty(taskData: TaskDetails): Int {
        return if (isInnerPack())
            taskData.pickedQty * getIPConversionRate()
        else
            taskData.pickedQty
    }

    // Get the picked qty and appending with UOM for all screens label view
    fun getPickQtyUOMValue(taskData: TaskDetails): String {
        return if (isInnerPack()) {
            String.format("%d %s", taskData.pickedQty, IP_VALUE)
        } else String.format("%d %s", taskData.pickedQty, taskData.taskQtyUom)
    }

    // To get the inner pack conversion
    private fun getIPConversionRate(): Int {
        return if (uomConversionRateUtil != null)
            uomConversionRateUtil!!.getInnerPackRate()
        else 0
    }

    // Check task qty is eligible for inerpack or not
    fun isInnerPack(): Boolean {
        return (getIPConversionRate() > 0 && getPickTaskDetails()!!.taskQty % getIPConversionRate() == 0)
    }

    fun isPickOrderTypeEnabled() =
        sharedPreferences.getBoolean(PreferenceKeys.PICK_ORD_TYPE_SELECTION_PREFERENCE, false)

    fun getConfiguredOrderTypes() =
        sharedPreferences.getString(ALLOC_TYPE_ORD_TYPE_SELECTION_PREFERENCE, null)?.split(",")

    fun setSerialNumberList(serialList: List<String>?) {
        this.serialNumberList.value = serialList
    }

    fun getSerialNumberList(): List<String>? {
        if(!serialNumberList.value.isNullOrEmpty()){
            return serialNumberList.value
        }
        return emptyList()
    }

    /**
     * Function to fetch task groups based on provided allocation type codes.
     */
    private fun fetchTaskGroups(allocationTypes: List<AllocationType>) {
        // Create a list of the desired AllocationType codes
        val allocationTypeCodes = allocationTypes.map { it.code }

        // Join the codes into a single string separated by commas
        val allocationTypeCodesString = allocationTypeCodes.joinToString(",")

        // Call the viewModel method with the concatenated string
        getTaskGroups(allocType = allocationTypeCodesString)
    }


    /**
     * Function to fetch RTV (Return to Vendor) task groups
     */
    fun fetchRTVTaskGroups() {
        fetchTaskGroups(listOf(
            AllocationType.PICK_FROM_ACTIVE_RTV,                     // Code "720"
            AllocationType.PICK_FROM_CASE_PICK_RTV,                  // Code "710"
            AllocationType.PICK_FROM_RESERVE_RTV,                    // Code "700"
            AllocationType.PICK_FROM_QUARANTINE_RESERVE_RTV,         // Code "730"
            AllocationType.PICK_FROM_QUARANTINE_CASE_PICK_RTV,       // Code "740"
            AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV,          // Code "750"
            AllocationType.PICK_FROM_DAMAGED_RESERVE_LTL_RTV,        // Code "760"
            AllocationType.PICK_FROM_DAMAGED_CASE_PICK_LTL_RTV,      // Code "770"
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_RTV,         // Code "780"
            AllocationType.PICK_FROM_ISOLATED_CASE_PICK_PALLET_RTV   // Code "790"
        ))
    }

}