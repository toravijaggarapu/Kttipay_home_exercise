package com.fsc.flare.ui.fragment.replenish.casepicktoactive

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentCaseReplenTaskDetailsBinding
import com.fsc.flare.source.data.dto.enumeration.TaskStatus
import com.fsc.flare.source.data.dto.replenishment.SkipTaskDetailsRequest
import com.fsc.flare.source.data.dto.replenishment.TaskReplenEndCartRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * A simple [CaseReplenTaskDetailsFragment] Fragment class.
 */
@AndroidEntryPoint
class CaseReplenTaskDetailsFragment : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var navController: NavController

    private val viewModel: CaseReplenishmentViewModel by activityViewModels()
    private lateinit var binding: FragmentCaseReplenTaskDetailsBinding

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title =
            sharedPreferences.getString(
                PreferenceKeys.CUST_CODE,
                null
            ) + " - " + sharedPreferences.getString(
                PreferenceKeys.FEDEX_ID, null
            )
        super.onResume()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCaseReplenTaskDetailsBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvCaseReplenishHeader.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        navController = NavHostFragment.findNavController(this)
        setUpViews()
        observeData()
        return binding.root
    }

    private fun observeData() {
        observeReplenCaseSkipTaskData()
        observeReplenEndCartData()
    }

    private fun observeReplenEndCartData() {
        viewModel.replenEndCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endCartResponse ->
                        if (endCartResponse.success) {
                            val taskDetails = endCartResponse.taskDetails
                            if (taskDetails?.taskStatus == TaskStatus.TASK_INTERIM_UPDATE.value) {
                                viewModel.apply {
                                    _pickCartNbr = endCartResponse.cartNbr
                                    _replenTaskDetails.value = taskDetails
                                }
                                getNavigationController().navigate(CaseReplenTaskDetailsFragmentDirections.actionCaseReplenTaskDetailsToCaseReplenDropCaseScan())
                            } else {
                                showErrorSnackBar(endCartResponse.message)
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun observeReplenCaseSkipTaskData() {
        viewModel.replenCaseSkipTaskResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskReplenResponse ->
                        if (taskReplenResponse.success) {
                            val taskDetails = taskReplenResponse.taskDetails
                            if (taskDetails != null) {
                                viewModel.apply {
                                    _replenTaskDetails.value = taskDetails
                                    _pickCartNbr = taskReplenResponse.cartNbr
                                }
                                taskDetails.let {
                                    binding.apply {
                                        tvTaskNumberValue.text = "${it.taskId}"
                                        tvTaskTypeValue.text = it.taskType
                                        tvWaveNumberValue.text = it.waveNumber
                                        tvPriorityValue.text = it.priority
                                        tvTaskStatusValue.text = "${it.taskStatus}"
                                    }
                                }
                            } else {
                                showErrorSnackBar("No Task Details Found")
                            }
                        }
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun setUpViews() {
        binding.tvPalletCartIdValue.text = viewModel.pickCartNbr
        viewModel.replenTaskDetails.value?.let { taskDetails ->
            with(binding) {
                tvTaskNumberValue.text = "${taskDetails.taskId}"
                tvTaskTypeValue.text = taskDetails.taskType
                tvWaveNumberValue.text = taskDetails.waveNumber
                tvPriorityValue.text = taskDetails.priority
                tvTaskStatusValue.text = "${taskDetails.taskStatus}"
            }
        }

        binding.btnSkip.setOnClickListener {
            viewModel.replenCaseSkipTask(
                SkipTaskDetailsRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    pickCartNbr = viewModel.pickCartNbr,
                    assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
                    allocationType = sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, "60") ?: "60",
                    skipTaskId = binding.tvTaskNumberValue.text.toString()
                )
            )
        }

        binding.btnAccept.setOnClickListener {
            val action = CaseReplenTaskDetailsFragmentDirections.actionCaseReplenTaskDetailsToCaseReplenLocationScan()
            getNavigationController().navigate(action)
        }

        binding.btnEndCart.visibility = if (viewModel.enableEndCart) View.VISIBLE else View.GONE

        binding.btnEndCart.setOnClickListener {
            viewModel.updateReplenEndCart(
                TaskReplenEndCartRequest(
                    allocationType = sharedPreferences.getString(PreferenceKeys.CaseReplenishment.CASE_REPLEN_TASK_GROUP_ALLOCATION_TYPE, "0")?.toInt() ?: 0,
                    buId = "${sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)}",
                    custId = "${sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1)}",
                    fcyId = "${sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)}",
                    pickCartNbr = viewModel.pickCartNbr
                )
            )
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        disableTouch()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        enableTouch()
    }
}