package com.fsc.flare.ui.fragment.putaway

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.PutAwayFragmentBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.putawayreverse.ContainerRequest
import com.fsc.flare.source.data.dto.putawayreverse.DoPutawayRequest
import com.fsc.flare.source.data.dto.putawayreverse.LocationIDRequest
import com.fsc.flare.source.data.dto.putawayreverse.Putaway
import com.fsc.flare.source.data.dto.putawayreverse.PutawayContainerReq
import com.fsc.flare.source.data.dto.putawayreverse.PutawayLocIDReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PutAwayFragment"

@AndroidEntryPoint
class PutAwayFragment : BaseFragment(), FlareScannable {

    private val viewModel: PutAwayViewModel by activityViewModels()
    private lateinit var binding: PutAwayFragmentBinding
    lateinit var cb1: CustomVisibilityCallback

    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = PutAwayFragmentBinding.inflate(inflater, container, false)
        binding.putAwayViewModel = viewModel
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.slp.isFocused && !binding.containerId.text.isNullOrEmpty() && !binding.locationId.text.isNullOrEmpty() && !binding.slp.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "slp field focused")
                        doPutAway()
                    } else if (binding.containerId.isFocused && !binding.containerId.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "container field focused")
                        validateContainer()
                    } else if (binding.locationId.isFocused && !binding.locationId.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "location field focused")
                        validateLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.slp.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.slp)
                if (binding.slp.isFocused && !binding.containerId.text.isNullOrEmpty() && !binding.locationId.text.isNullOrEmpty() && !binding.slp.text.isNullOrEmpty()) {
                    FlareLog.i(TAG, "slp field focused")
                    doPutAway()
                }
            }
            false
        }

        binding.containerId.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.containerId)
                FlareLog.i(TAG, " containerId focused")
                validateContainer()
            }
            false
        }

        binding.locationId.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.locationId)
                FlareLog.i(TAG, " locationId focused")
                validateLocation()
            }
            false
        }

        binding.containerId.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.locationId.text = null
                binding.slp.text = null
                binding.containerIdResponse.text = null
                binding.locationIdResponse.text = null
            }
        })
        binding.locationId.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.containerIdResponse.text = null
                binding.locationIdResponse.text = null
            }
        })

        subscribeObservers()
    }

    private fun doPutAway() {
        viewModel.doPutaway(
            DoPutawayRequest(
                "RF",
                Putaway(
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.containerId.text.toString(),
                    binding.locationId.text.toString(),
                    binding.slp.text.toString(),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    private fun validateLocation() {
        viewModel.validateLocationID(
            LocationIDRequest(
                "RF",
                PutawayLocIDReq(
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.locationId.text.toString(),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    private fun validateContainer() {
        viewModel.validateContainer(
            ContainerRequest(
                "RF",
                PutawayContainerReq(
                    sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                    sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    binding.containerId.text.toString(),
                    sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
                    sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
                )
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        FlareLog.i(TAG, "container Response: $response")
                        when (containerResponse.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "container error: ${ containerResponse.statusHandler.message}")
                                binding.containerId.selectAll()
                                binding.containerIdResponse.text =
                                    containerResponse.statusHandler.message
                                showSoftKeyBoard(fragmentContext, binding.containerId)
                            }
                            "200" -> {
                                FlareLog.i(TAG, "container success: $containerResponse")
                                if (containerResponse.putaway != null) {
                                    if (containerResponse.putaway.locId.isNotEmpty()) {
                                        binding.locationId.setText(containerResponse.putaway.locId)
                                        binding.etQuantity.setText(containerResponse.putaway.cntQty.toString())
                                        binding.locationId.text?.length?.let {
                                            binding.locationId.setSelection(it)
                                        }
                                        binding.slp.requestFocus()
                                    }
                                } else {
                                    binding.locationId.requestFocus()
                                }
                            }
                        }
                        FlareLog.i(TAG, "container Response: $containerResponse")
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.containerIdResponse.text = message
                        FlareLog.e(TAG, "container Error: $message")

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.locationIDResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { locationIDResponse ->
                        FlareLog.i(TAG, "locationID Response: $response")
                        when (locationIDResponse.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "locationID error: ${locationIDResponse.statusHandler.message}")
                                binding.locationId.selectAll()
                                binding.locationIdResponse.text =
                                    locationIDResponse.statusHandler.message
                                showSoftKeyBoard(fragmentContext, binding.locationId)
                            }
                            "200" -> {
                                FlareLog.i(TAG, "locationID success: $locationIDResponse")
                                binding.slp.requestFocus()
                            }
                        }
                        FlareLog.i(TAG, "locationID Response: $locationIDResponse")

                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.locationIdResponse.text = message
                        FlareLog.e(TAG, "locationID Error: $message")

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.putawayRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { putawayresponse ->
                        FlareLog.i(TAG, "putaway response: $response")
                        when (putawayresponse.statusHandler.statusCode) {
                            "500" -> {
                                FlareLog.e(TAG, "putaway error: ${putawayresponse.statusHandler.message}")
                                showErrorSnackBar(putawayresponse.statusHandler.message)
                                when {
                                    putawayresponse.statusHandler.message.contains(resources.getString(R.string.lbl_container)) -> {
                                        binding.containerId.requestFocus()
                                        binding.containerId.selectAll()
                                        showSoftKeyBoard(fragmentContext, binding.containerId)
                                    }
                                    putawayresponse.statusHandler.message.contains(resources.getString(R.string.lbl_location)) -> {
                                        binding.locationId.requestFocus()
                                        binding.locationId.selectAll()
                                        showSoftKeyBoard(fragmentContext, binding.locationId)
                                    }
                                    putawayresponse.statusHandler.message.contains(resources.getString(R.string.lbl_slp)) -> {
                                        binding.slp.requestFocus()
                                        binding.slp.selectAll()
                                        showSoftKeyBoard(fragmentContext, binding.slp)
                                    }
                                }
                            }
                            "200" -> {
                                FlareLog.i(TAG, "putaway success: $putawayresponse")
                                binding.etQuantity.setText(putawayresponse.putaway.cntQty.toString())
                                binding.slp.text = null
                                showSuccessSnackBar(putawayresponse.statusHandler.message)
                            }
                        }
                        FlareLog.i(TAG, "PutAway Response: $putawayresponse")
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "PutAway Error: $message")

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.noNetworkUpdate.observe(viewLifecycleOwner) { response ->
            if (response != null) {
                hideProgressBar()
                showErrorSnackBar(resources.getString(R.string.network_connect_failure))
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }

        when {
            binding.containerId.isFocused -> {
                binding.containerId.setText(scan?.barcode.toString())
                binding.containerId.text?.length?.let {
                    binding.containerId.setSelection(it)
                }
                FlareLog.i(TAG, "container field focused")
                validateContainer()
            }
            binding.locationId.isFocused -> {
                binding.locationId.setText(scan?.barcode.toString())
                binding.locationId.text?.length?.let {
                    binding.locationId.setSelection(it)
                }
                FlareLog.i(TAG, "location field focused")
                validateLocation()
            }
            binding.slp.isFocused -> {
                binding.slp.setText(scan?.barcode.toString())
                binding.slp.text?.length?.let {
                    binding.slp.setSelection(it)
                }
                FlareLog.i(TAG, "slp field focused")
                doPutAway()
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

}