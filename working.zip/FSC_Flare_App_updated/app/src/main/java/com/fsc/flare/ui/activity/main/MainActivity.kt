package com.fsc.flare.ui.activity.main

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.activity.addCallback
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.text.bold
import androidx.core.text.color
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.navigateUp
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import com.fsc.flare.BuildConfig
import com.fsc.flare.R
import com.fsc.flare.databinding.ActivityMainBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.service.SESSION_REFRESH
import com.fsc.flare.service.SessionWorkManager
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.ui.activity.BaseActivity
import com.fsc.flare.ui.activity.authentication.AuthenticationViewModel
import com.fsc.flare.ui.activity.splash.SplashActivity
import com.fsc.flare.ui.activity.splash.SplashActivity.Companion.EXTRA_LOGGING_OUT
import com.fsc.flare.ui.common.BackButtonHandler
import com.fsc.flare.ui.fragment.account.AccountFragment
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import java.util.concurrent.TimeUnit
import javax.inject.Inject


private const val TAG = "MainActivity"
private const val ACCESS_TOKEN_SYNC_DATA = "ACCESS_TOKEN_SYNC_DATA"
private const val MAX_TIME_INTERVAL = 55L
private const val MAX_COUNTER_TIME = 3

@AndroidEntryPoint
class MainActivity : BaseActivity(), MenuProvider {

    lateinit var binding: ActivityMainBinding
    lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration
    var sessionManagerCount = 0
    var canRefresh = false

    private val viewModel: AuthenticationViewModel by viewModels()

    //Initiate variables for Work manager tasks
    @Inject
    lateinit var mWorkManager: WorkManager
    private lateinit var constraints: Constraints
    private lateinit var periodicSyncDataWork: PeriodicWorkRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        //Thread.setDefaultUncaughtExceptionHandler(UnCaughtException(this));
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        addMenuProvider(this)
        /*val config = resources.configuration
        val lang = "fr" // your language code
        val locale = Locale(lang)
        Locale.setDefault(locale)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            config.setLocale(locale)
        else
            config.locale = locale

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            createConfigurationContext(config)
        resources.updateConfiguration(config, resources.displayMetrics)*/

        this.setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = getString(R.string.lbl_flare)

        viewModel.getLookUps(
            LookUpsRequest(
                fcyId = 0,
                cusId = 0,
                buId = 0,
                lookupNames = "LANGUAGES_LIST"
            )
        )
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.findNavController()
        appBarConfiguration = AppBarConfiguration(navGraph = navController.graph)
        setupNavigation()
        initiateWorkManager()
        subscribeTokenObserver()
        viewModel.startLogging()
    }

    private fun initiateWorkManager() {
        //Register Local broadcast manager
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(mMessageReceiver, IntentFilter(SESSION_REFRESH))
        //Add constraints for workManager
        constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        //create periodic request for interval time 55 minutes
        periodicSyncDataWork = PeriodicWorkRequest.Builder(
            SessionWorkManager::class.java, MAX_TIME_INTERVAL, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .setBackoffCriteria(
                BackoffPolicy.LINEAR,
                PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .build()
        //UniquePeriod work initiated to keep the only one workManager instance
        mWorkManager.enqueueUniquePeriodicWork(
            ACCESS_TOKEN_SYNC_DATA,
            ExistingPeriodicWorkPolicy.KEEP,  //Existing Periodic Work policy
            periodicSyncDataWork //work request
        )
    }

    private fun setupNavigation() {
        NavigationUI.setupActionBarWithNavController(this, navController)
        NavigationUI.setupWithNavController(binding.toolbar, navController, appBarConfiguration)

        binding.toolbar.setNavigationOnClickListener {
            when(val currentFragment = supportFragmentManager.currentNavigationFragment) {

                is BackButtonHandler -> {
                    (currentFragment as BackButtonHandler).onBackButtonPressed()
                }

                else -> {
                    navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
                }
            }
        }

        navController.addOnDestinationChangedListener { _, destination, _ ->
            if (this.window.currentFocus?.hasFocus() == true) {
                this.window.currentFocus!!.clearFocus()
            }
            //this.window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
            when (destination.id) {
                R.id.loadCartContainer -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.replenFillCasePickContainer -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.buildCartToteFragment -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.pickCartPickLocationFragment -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.pickCartLocationFragment -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.pickCartStagingLocFragment -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }

                R.id.prLocationFragment -> {
                    findViewById<View>(R.id.toolbar).visibility = View.VISIBLE
                    binding.toolbar.navigationIcon = null
                }
            }

            val currentFragment = supportFragmentManager.currentNavigationFragment
            if (currentFragment is BackButtonHandler) {
                onBackPressedDispatcher.addCallback(owner = currentFragment) {
                    (currentFragment as BackButtonHandler).onBackButtonPressed()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onPrepareMenu(menu: Menu) {
        super.onPrepareMenu(menu)
        menu.findItem(R.id.home)?.isVisible = false
        menu.findItem(R.id.language)?.isVisible = false
        menu.findItem(R.id.logout)?.isVisible = true
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.main_menu, menu)
    }

    override fun onMenuItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                showLogoutAlertDialog()
                true
            }

            R.id.language -> {
                showLanguageOptions()
                true
            }

            else -> {
                false
            }
        }
    }

    private fun showLogoutAlertDialog() {
        val builder = MaterialAlertDialogBuilder(this, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.confirm_logout))
            .setMessage(getString(R.string.are_you_sure_you_want_to_logout))
            .setPositiveButton(getString(R.string.alert_button_ok)) { _, _ ->
                startTransactionManager()
                val intent = Intent(this, SplashActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                intent.putExtra(EXTRA_LOGGING_OUT, true)
                startActivity(intent)
            }
            .setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
                dialog.cancel()
            }
        val dialog: MaterialAlertDialogBuilder = builder
        dialog.show()
    }

    private fun showLanguageOptions() {
        val languagesHashMap: java.util.HashMap<String, String> = Gson().fromJson(
            sharedPreferences.getString(PreferenceKeys.LANGUAGES_HASH_MAP, ""),
            object : TypeToken<java.util.HashMap<String?, String?>?>() {}.type
        )
        val items =
            if (languagesHashMap.isNotEmpty()) languagesHashMap.values.toTypedArray() else arrayOf<CharSequence>(
                "ENGLISH"
            )
        val builder = MaterialAlertDialogBuilder(this, R.style.AlertDialogTheme)
        builder.setIcon(R.drawable.ic_lang_translate)
        builder.setTitle(getString(R.string.select_lang_title))

        val selectedLang =
            if (languagesHashMap.isNotEmpty()) languagesHashMap[sharedPreferences.getString(
                PreferenceKeys.APP_LANGUAGE,
                "en"
            )] else "ENGLISH"
        val langPos = items.indexOf(selectedLang.toString())
        builder.setSingleChoiceItems(items, langPos) { dialogInterface, pos ->
            showLangChangeAlert(items[pos].toString())
            dialogInterface.dismiss()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel)) { dialog, _ ->
            dialog.cancel()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun showLangChangeAlert(selectedLanguage: String) {
        val builder = MaterialAlertDialogBuilder(this, R.style.AlertDialogTheme)
        val text1 = getString(R.string.lang_alert_msg)
        val boldText1 = "$selectedLanguage?"

        val myCustomizedString = SpannableStringBuilder()
            .append(text1)
            .color(
                ContextCompat.getColor(
                    this,
                    R.color.colorPrimary
                )
            ) { bold { append(boldText1) } }

        builder.setTitle("")
        builder.setMessage(myCustomizedString)

        builder.setPositiveButton(resources.getString(R.string.btn_change)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            val languagesHashMap: java.util.HashMap<String, String> = Gson().fromJson(
                sharedPreferences.getString(PreferenceKeys.LANGUAGES_HASH_MAP, ""),
                object : TypeToken<java.util.HashMap<String?, String?>?>() {}.type
            )
            val selectedLangCode =
                if (languagesHashMap.isNotEmpty()) languagesHashMap.entries.find { it.value == selectedLanguage }?.key else "en"
            sharedPreferences.edit().putString(PreferenceKeys.APP_LANGUAGE, selectedLangCode)
                .apply()
            updateSelectedLangToServer()
            recreate()
        }
        builder.setNegativeButton(resources.getString(R.string.alert_button_cancel)) { dialogInterface, _ ->
            dialogInterface.dismiss()

        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun updateSelectedLangToServer() {

        if (navController.currentDestination?.id == R.id.accountFragment) {
            Log.d("debug", "Account Frgament")
            val currentFragment = supportFragmentManager.currentNavigationFragment
            (currentFragment as? AccountFragment)?.updateLanguage()
        }
    }

    private val FragmentManager.currentNavigationFragment: Fragment?
        get() = primaryNavigationFragment?.childFragmentManager?.fragments?.first()

    /*override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val view = currentFocus
        if (view != null && (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_MOVE) && view is EditText && !view.javaClass.name.startsWith(
                "android.webkit."
            )
        ) {
            val scrcoords = IntArray(2)
            view.getLocationOnScreen(scrcoords)
            val x = ev.rawX + view.getLeft() - scrcoords[0]
            val y = ev.rawY + view.getTop() - scrcoords[1]
            if (x < view.getLeft() || x > view.getRight() || y < view.getTop() || y > view.getBottom()) (this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
                this.window.decorView.applicationWindowToken, 0
            )
        }
        return super.dispatchTouchEvent(ev)
    }*/

    //Local Broadcast manager defined
    private val mMessageReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            if (sessionManagerCount > MAX_COUNTER_TIME || (sessionManagerCount > 0 && !canRefresh)) {
                cancelSessionWorker()
            } else {
                if (sessionManagerCount > 0) {
                    refreshTokenCall()
                    canRefresh = false
                }
                sessionManagerCount += 1
            }
        }
    }

    private fun refreshTokenCall() {
        viewModel.fetchRefreshToken()
    }

    private fun subscribeTokenObserver() {
        viewModel.oktaTokenResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    if (response.data != null) {
                        sharedPreferences.apply {
                            if (sharedPreferences.getBoolean(PreferenceKeys.ISTEMP_USER, false)) {
                                sharedPreferences.edit().putString(
                                    PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN,
                                    response.data.accessToken
                                ).apply()
                                sharedPreferences.edit().putString(
                                    PreferenceKeys.OKTA_USER_ID,
                                    response.data.accessToken
                                ).apply()
                            } else {
                                sharedPreferences.edit().putString(
                                    PreferenceKeys.OKTA_ACCESS_TOKEN,
                                    response.data.accessToken
                                ).apply()
                                sharedPreferences.edit().putString(
                                    PreferenceKeys.OKTA_USER_ID,
                                    response.data.accessToken
                                ).apply()
                            }
                            sharedPreferences.edit().putString(
                                PreferenceKeys.OKTA_REFRESH_TOKEN,
                                response.data.refreshToken
                            ).apply()
                            sharedPreferences.edit()
                                .putString(PreferenceKeys.OKTA_ID_TOKEN, response.data.idToken)
                                .apply()
                            viewModel.fetchGatewayToken(
                                sharedPreferences.getString(
                                    PreferenceKeys.API_GATEWAY_CLIENT_ID,
                                    null
                                )!!,
                                sharedPreferences.getString(
                                    PreferenceKeys.API_GATEWAY_SECRET,
                                    null
                                )!!
                            )
                            Log.d(
                                TAG,
                                "saved okta token response to sharedpreferences:" + response.data.accessToken
                            )
                        }
                    }
                }

                is Resource.Error -> {}
                is Resource.Loading -> {}
            }
        }
        viewModel.gatewayTokenResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    Log.d(TAG, "Gateway Token Response : " + response.data?.toString())
                    if (response.data != null) {
                        sharedPreferences.apply {
                            sharedPreferences.edit().putString(
                                PreferenceKeys.API_GATEWAY_ACCESS_TOKEN,
                                response.data.access_token
                            ).apply()
                            Log.d(
                                TAG,
                                "saved gateway token to sharedpreferences:" + response.data.access_token
                            )
                        }
                    }
                }

                is Resource.Error -> {}
                is Resource.Loading -> {}
            }
        }

        viewModel.lookUpResponse.observe(this) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        if (lookUpResponse.lookups.isNotEmpty()) {
                            val languageLookups =
                                lookUpResponse.lookups.filter { it.lookupName == "LANGUAGES_LIST" }
                            val languagesHashMap: HashMap<String, String> = HashMap()
                            languageLookups[0].lookupCodes.forEach { lookUp ->
                                lookUp.lookupCode.forEach { _ ->
                                    languagesHashMap[lookUp.lookupCode] =
                                        lookUp.lookupCodeDescription
                                }
                            }
                            sharedPreferences.edit().putString(
                                PreferenceKeys.LANGUAGES_HASH_MAP,
                                Gson().toJson(languagesHashMap)
                            ).apply()
                            if (languageLookups[0].lookupCodes.isNotEmpty()) {
                                sharedPreferences.edit()
                                    .putBoolean(PreferenceKeys.IS_LANGUAGE_LOOKUP_CONFIGURED, true)
                                    .apply()
                            } else {
                                sharedPreferences.edit()
                                    .putBoolean(PreferenceKeys.IS_LANGUAGE_LOOKUP_CONFIGURED, false)
                                    .apply()
                            }
                            invalidateOptionsMenu()
                        }
                    }
                }

                is Resource.Error -> {
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showProgressBar() {
        binding.progressBarMain.visibility = View.VISIBLE
    }

    private fun hideProgressBar() {
        binding.progressBarMain.visibility = View.GONE
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        canRefresh = true
    }

    override fun onResume() {
        super.onResume()
        uploadTrackerFromFile()
    }
    override fun onDestroy() {
        super.onDestroy()
        cancelSessionWorker()
    }

    private fun cancelSessionWorker() {
        sessionManagerCount = 0
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver)
        mWorkManager.cancelAllWork()
    }

    fun startTransactionManager() {
        if(BuildConfig.ENABLE_ACTIVITY_TRANSACTION_TRACKER) {
            viewModel.updateTransactionData()
        }
    }

    private fun uploadTrackerFromFile() {
        viewModel.updateTransactionData(uploadDataFromFile = true)
    }
}
