package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletListBinding
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inquiry.location.CaseObj
import com.fsc.flare.source.data.dto.inquiry.location.PalletObj
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private const val TAG = "PalletListFragment"
@AndroidEntryPoint
class PalletListFragment : BaseFragment(), PalletAdapter.OnAdapterClickListener {

    private lateinit var palletAdapter: PalletAdapter
    private lateinit var binding: FragmentPalletListBinding

    private val viewModel: InquiryViewModel by activityViewModels()
    var page  = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPalletListBinding.inflate(inflater, container, false)
        subscribeObservers()
        setupRecyclerView()
        return binding.root
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(fragmentContext)
        palletAdapter = viewModel.palletListHashMap[page]?.let { PalletAdapter(it,this) }!!
        binding.recyclerView.adapter = palletAdapter
        palletAdapter.notifyDataSetChanged()
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val locData = viewModel.getLocation()
        val locInventoryData = viewModel.locationInventoryCountResponse.value
        val locationInvResp = viewModel.locationInventoryResponse.value
        binding.totalPages.text = (locInventoryData?.data?.palletCount?.div(viewModel.PAGELIMIT))?.plus(1).toString()
        binding.page.text = page.plus(1).toString()
        if (locationInvResp?.data?.paging?.next != null) {
            binding.btnNext.visibility = View.VISIBLE
            if(locInventoryData?.data?.palletCount?.div(viewModel.PAGELIMIT)!! <= 1){
                binding.btnNext.visibility = View.GONE
            }
        }
        if (viewModel.palletListHashMap.size > 1) {
            binding.btnNext.visibility = View.VISIBLE
        }
        binding.btnNext.setOnClickListener {
            page++
            binding.page.text = page.plus(1).toString()
            if (locData != null) {
                if (viewModel.palletListHashMap.containsKey(page)) {
                    setupRecyclerView()
                } else {
                    viewModel.getLocationInventory(locData.locations[0].locationBarcode, page, viewModel.PAGELIMIT)
                }
            }
        }

        binding.btnPrevious.setOnClickListener {
            page--
            binding.btnNext.visibility = View.VISIBLE
            binding.page.text = page.plus(1).toString()
            if(page == 0){
                binding.btnPrevious.visibility = View.GONE
            }
            setupRecyclerView()
        }
    }

    override fun onItemSelected(palletNbr: String?) {
        if (palletNbr != null) {
            viewModel.selectedPallet = palletNbr
            viewModel.getPalletInventory(palletNbr, 0, viewModel.PAGELIMIT)
        }
    }

    private fun subscribeObservers() {
        viewModel.palletInventoryResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { containerResponse ->
                        if(containerResponse.containers.isNotEmpty()){
                            val filteredCaseList = containerResponse.containers.filter { it.containerType == "C" }
                            val caseList = filteredCaseList.map { CaseObj(caseNbr = it.container,qty = it.qty, status = getContainerStatus(it.containerStatus)) }.toMutableList()
                            viewModel.caseListHashMap.clear()
                            viewModel.caseListHashMap[page] = caseList
                            navigateToCaseList()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "container error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.locationInventoryResponse.observe(viewLifecycleOwner) { locationInvResponse ->
            when (locationInvResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "locationInquiry success: $locationInvResponse")
                    hideProgressBar()
                    val locDetails = viewModel.getLocation()
                    locationInvResponse.data?.let { locationInventoryResponse ->
                        viewModel.locationContainer = locationInventoryResponse.containers?.get(0)
                        if (locDetails != null) {
                            if(locDetails.locations[0].classification == "R" && !locationInventoryResponse.containers.isNullOrEmpty()){
                                val palletFilteredList  = locationInventoryResponse.containers.filter { it.containerType == "P" }
                                val palletList: MutableList<PalletObj> = mutableListOf()
                                palletFilteredList.forEach {
                                    val palletObj = PalletObj(it.container, it.qty,getContainerStatus(it.containerStatus),it.noOfCases)
                                    palletList.add(palletObj)
                                }
                                if(locationInventoryResponse.paging?.next == null){
                                    binding.btnNext.visibility = View.VISIBLE
                                }
                                viewModel.palletListHashMap[page] = palletList
                                setupRecyclerView()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    locationInvResponse.message?.let { message ->
                        showErrorSnackBar(message)
                        FlareLog.e(TAG, "locationInquiry Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun navigateToCaseList() {
        val action = PalletListFragmentDirections.actionPalletListFragmentToCaseListFragment()
        getNavigationController().navigate(action)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }
}