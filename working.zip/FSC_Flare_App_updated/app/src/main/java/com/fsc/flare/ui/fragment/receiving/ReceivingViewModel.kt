package com.fsc.flare.ui.fragment.receiving

import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.di.IoDispatcher
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.ContainerStatus
import com.fsc.flare.source.data.dto.inventory.CaseTransferContainerResponse
import com.fsc.flare.source.data.dto.inventory.CaseTransferPalletGenerateResponse
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLockCodeResponse
import com.fsc.flare.source.data.dto.inventory.InventoryLockcode
import com.fsc.flare.source.data.dto.inventory.InventoryLockcodeRequest
import com.fsc.flare.source.data.dto.lookups.LookUps
import com.fsc.flare.source.data.dto.masterpalletrepack.PrintContainerLabelRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.packout.res.BatchDetail
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberASNRequest
import com.fsc.flare.source.data.dto.pickfromreserve.tivopick.ValidateLotNumberResponse
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.pickingforward.res.LocationClassRes
import com.fsc.flare.source.data.dto.receiving.Container
import com.fsc.flare.source.data.dto.receiving.ExitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.ExitReceivingResponse
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockRequest
import com.fsc.flare.source.data.dto.receiving.ItemRecallLockResponse
import com.fsc.flare.source.data.dto.receiving.ItemRequest
import com.fsc.flare.source.data.dto.receiving.Locations
import com.fsc.flare.source.data.dto.receiving.LockcodeRequest
import com.fsc.flare.source.data.dto.receiving.RCSubmitReceivingLPNRequest
import com.fsc.flare.source.data.dto.receiving.RCSubmitReceivingLPNResponse
import com.fsc.flare.source.data.dto.receiving.RCValidateLPNRequest
import com.fsc.flare.source.data.dto.receiving.RCValidateLPNResponse
import com.fsc.flare.source.data.dto.receiving.ReceivingASNRequest
import com.fsc.flare.source.data.dto.receiving.ReceivingDockDoorRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingRequest
import com.fsc.flare.source.data.dto.receiving.SubmitReceivingResponse
import com.fsc.flare.source.data.dto.receiving.ValidateLotNumberRequestFromLotMaster
import com.fsc.flare.source.data.dto.receiving.ValidateOverReceiptResponse
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamResponse
import com.fsc.flare.source.data.dto.receiving.generateCombinations
import com.fsc.flare.source.data.dto.receiving.inboundshipment.CriteriaFirstInspectionRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.CriteriaFirstInspectionResponse
import com.fsc.flare.source.data.dto.receiving.inboundshipment.InboundShipment
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentRequest
import com.fsc.flare.source.data.dto.receiving.inboundshipment.PackageInboundShipmentResponse
import com.fsc.flare.source.data.dto.receiving.item.Item
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemRequest
import com.fsc.flare.source.data.dto.receiving.item.PackageItemResponse
import com.fsc.flare.source.data.dto.receiving.location.DockDoorLocationRequest
import com.fsc.flare.source.data.dto.receiving.location.DockDoorLocationResponse
import com.fsc.flare.source.data.dto.receiving.location.Location
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumReqBody
import com.fsc.flare.source.data.dto.receiving.serial.SerialNumber
import com.fsc.flare.source.data.dto.receiving.serial.SerialValidationResponse
import com.fsc.flare.source.data.dto.receivingpallet.EndReceiving
import com.fsc.flare.source.data.dto.receivingpallet.ReceivingPalletCommonData
import com.fsc.flare.source.repository.MasterPalletRepackRepository
import com.fsc.flare.source.repository.ReceivingRepository
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PrintLabelTypes.IB_CASE_LABEL
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import com.fsc.flare.utils.Utility
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.joda.time.DateTime
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "ReceivingViewModel"

const val CASE = "Case"
const val PALLET = "Pallet"

@HiltViewModel
class ReceivingViewModel @Inject constructor(
    private val receivingRepository: ReceivingRepository,
    private val masterPalletRepackRepository: MasterPalletRepackRepository,
    private var sharedPreferences: SharedPreferences,
    @IoDispatcher private val dispatcher: CoroutineDispatcher
) : BaseViewModel() {
    var isFirstArticleInspectionLockNeeded = false
    var firstArticleLockCode: String? = null
    private var firstArticleMsgShown = mutableListOf<String>()
    val palletDetailKey = "pallet"
    val rpcTransEnabledKey = 15
    val taskGroupResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()
    val validateLocIdResponse: MutableLiveData<Resource<DockDoorLocationResponse>> = SingleLiveEvent()
    val inBoundShipmentResponse: MutableLiveData<Resource<PackageInboundShipmentResponse>> = SingleLiveEvent()
    val packageItemResponse: MutableLiveData<Resource<PackageItemResponse>> = SingleLiveEvent()
    val criteriaFirstInspectionResponse: MutableLiveData<Resource<CriteriaFirstInspectionResponse>> = SingleLiveEvent()
    val submitReceivingResponse: MutableLiveData<Resource<SubmitReceivingResponse>> = SingleLiveEvent()
    val exitReceivingResponse: MutableLiveData<Resource<ExitReceivingResponse>> = SingleLiveEvent()
    val serialValidationResponse: MutableLiveData<Resource<SerialValidationResponse>> = SingleLiveEvent()
    val asnDetailsResponse: MutableLiveData<Resource<PackageInboundShipmentResponse>> = SingleLiveEvent()
    val containerResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val palletResponse: MutableLiveData<Resource<InventoryContainerResponse>> = SingleLiveEvent()
    val stagingLocationResponse: MutableLiveData<Resource<LocationClassRes>> = SingleLiveEvent()
    val dockDoorResponse: MutableLiveData<Resource<PackageInboundShipmentResponse>> = SingleLiveEvent()
    val validateLPNResponse: MutableLiveData<Resource<RCValidateLPNResponse>> = SingleLiveEvent()
    val submitReceivingLPNResponse: MutableLiveData<Resource<RCSubmitReceivingLPNResponse>> = SingleLiveEvent()
    val transactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val transactionRPCParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()

    val endReceivingPalletResponse: MutableLiveData<Resource<ExitReceivingResponse>> = SingleLiveEvent()
    val lpnSubmittedEvent: MutableLiveData<Boolean> = SingleLiveEvent()
    val validateTransactionParamResponse: MutableLiveData<Resource<TransactionParamResponse>> = SingleLiveEvent()
    val newPalletDetailResponse: MutableLiveData<Resource<CaseTransferPalletGenerateResponse>> = SingleLiveEvent()
    val palletDetailResponse: MutableLiveData<Resource<CaseTransferContainerResponse>> = SingleLiveEvent()
    val countriesLookUpResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()

    private val _validateLotNumberResponse = SingleLiveEvent<Resource<ValidateLotNumberResponse>>()

    val validateLotNumberResponse: LiveData<Resource<ValidateLotNumberResponse>>
        get() = _validateLotNumberResponse

    val validateOverReceiptResponse: MutableLiveData<Resource<ValidateOverReceiptResponse>> = SingleLiveEvent()

    private val _itemRecallLockResponse = SingleLiveEvent<Resource<ItemRecallLockResponse>>()

    fun getItemRecallLockResponse(): LiveData<Resource<ItemRecallLockResponse>> {
        return _itemRecallLockResponse
    }

    var isItemRecalled: Boolean = false
    var isItemExpired: Boolean = false

    //=============== R E C E I V I N G   E N H A N C E M E N T S ==========
    private val _containerTypes = SingleLiveEvent<List<String>>()
    val containerTypes: LiveData<List<String>> = _containerTypes

    fun getContainerTypes() {
        _containerTypes.postValue(listOf(PALLET, CASE))
    }

    private val _submitReceivingViewState = MutableStateFlow<SubmitReceiveEvent?>(null)
    val submitReceivingViewState = _submitReceivingViewState.asStateFlow()

    private val _submitReceivingErrorState = MutableStateFlow<SubmitReceiveErrorMessage?>(null)
    val submitReceivingErrorState = _submitReceivingErrorState.asStateFlow()

    private val lockCodesLocalList = mutableListOf<LockcodeRequest>()

    private var containersToBePrint: List<Container>? = null
    private var printRequesters: List<String>? = null

    var selectedContainerType: String? = null
    var casesQuantity: Int = -1
    var newPalletNumber: String? = null
    var printRequester: String? = null
    var eachQuantityInCase: Int = 0

    fun virtualContainersList() = containersToBePrint?.map { it.containerNumber } ?: emptyList()

    fun clearVirtualCaseFlowData() {
        lockCodesLocalList.clear()
        containersToBePrint = null
        printRequesters = null
        selectedContainerType = null
        casesQuantity = -1
        eachQuantityInCase = 0
        newPalletNumber = null
        printRequester = null
        _submitReceivingViewState.value = null
        _submitReceivingErrorState.value = null
    }
    //=============== R E C E I V I N G   E N H A N C E M E N T S ==========

    var lockCodesList = mutableListOf<InventoryLockcode>()

    fun validateLocationId(dockDoorLocationRequest: DockDoorLocationRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "validateLocationId Request: $dockDoorLocationRequest")
        validateLocIdResponse.postValue(Resource.Loading())
        val locIdResponse = receivingRepository.getLocationId(dockDoorLocationRequest)
        validateLocIdResponse.postValue(handleDDLocIdResponse(locIdResponse))
    }

    private fun handleDDLocIdResponse(locIdResponse: Response<DockDoorLocationResponse>): Resource<DockDoorLocationResponse>? {
        if (locIdResponse.isSuccessful) {
            locIdResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DDLocIdResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(locIdResponse.code(), locIdResponse.errorBody(), locIdResponse.message())
            FlareLog.e(TAG, "DDLocId Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getASN(packageInboundShipmentRequest: PackageInboundShipmentRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getASN Request: $packageInboundShipmentRequest")
        inBoundShipmentResponse.postValue(Resource.Loading())
        val inBoundShipmentRes = receivingRepository.getASN(packageInboundShipmentRequest)
        inBoundShipmentResponse.postValue(handleInboundShipmentResponse(inBoundShipmentRes))
    }

    private fun handleInboundShipmentResponse(inBoundShipmentRes: Response<PackageInboundShipmentResponse>): Resource<PackageInboundShipmentResponse>? {
        if (inBoundShipmentRes.isSuccessful) {
            inBoundShipmentRes.body()?.let { resultResponse ->
                FlareLog.i(TAG, "InboundShipmentResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(inBoundShipmentRes.code(), inBoundShipmentRes.errorBody(), inBoundShipmentRes.message())
            FlareLog.e(TAG, "InboundShipment Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getItems(packageItemRequest: PackageItemRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getItems Request: $packageItemRequest")
        packageItemResponse.postValue(Resource.Loading())
        val packageItemRes = receivingRepository.getItems(packageItemRequest)
        packageItemResponse.postValue(handlePackageItemResponse(packageItemRes))
    }

    private fun handlePackageItemResponse(packageItemResponse: Response<PackageItemResponse>): Resource<PackageItemResponse>? {
        if (packageItemResponse.isSuccessful) {
            packageItemResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PackageItemResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(packageItemResponse.code(), packageItemResponse.errorBody(), packageItemResponse.message())
            FlareLog.e(TAG, "PackageItem Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun getItemRecallLock(itemRecallLockRequest: ItemRecallLockRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "ItemRecallLock Request: $itemRecallLockRequest")
        _itemRecallLockResponse.postValue(Resource.Loading())
        val itemRecallResponse = receivingRepository.getItemRecallLock(itemRecallLockRequest)
        _itemRecallLockResponse.postValue(handleItemRecallLockResponse(itemRecallResponse))
    }

    private fun handleItemRecallLockResponse(itemRecallResponse: Response<ItemRecallLockResponse>): Resource<ItemRecallLockResponse>? {
        if (itemRecallResponse.isSuccessful) {
            itemRecallResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "itemRecallResponse Success Response: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(itemRecallResponse.code(), itemRecallResponse.errorBody(), itemRecallResponse.message())
            FlareLog.e(TAG, "itemRecallResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun submitReceiving(submitReceivingRequest: SubmitReceivingRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "submitReceiving Request: $submitReceivingRequest")
        submitReceivingResponse.postValue(Resource.Loading())
        val response = receivingRepository.submitReceiving(submitReceivingRequest)
        submitReceivingResponse.postValue(handleSubmitReceivingResponse(response))
    }

    private fun handleSubmitReceivingResponse(response: Response<SubmitReceivingResponse>): Resource<SubmitReceivingResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SubmitReceivingResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SubmitReceiving Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun exitReceiving(exitReceivingRequest: ExitReceivingRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "exitReceiving Request: $exitReceivingRequest")
        exitReceivingResponse.postValue(Resource.Loading())
        val response = receivingRepository.exitReceiving(exitReceivingRequest)
        exitReceivingResponse.postValue(handleExitReceivingResponse(response))
    }

    private fun handleExitReceivingResponse(response: Response<ExitReceivingResponse>): Resource<ExitReceivingResponse>? {

        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ExitReceivingResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ExitReceiving Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun criteriaFirstInspection(criteriaFirstInspectionRequest: CriteriaFirstInspectionRequest) = viewModelScope.launch {
        criteriaFirstInspectionResponse.postValue(Resource.Loading())
        val criteriaFirstInspectionRes = receivingRepository.criteriaFirstInspection(criteriaFirstInspectionRequest)
        criteriaFirstInspectionResponse.postValue(handleCriteriaFirstInspectionResponse(criteriaFirstInspectionRes))
    }

    private fun handleCriteriaFirstInspectionResponse(response: Response<CriteriaFirstInspectionResponse>): Resource<CriteriaFirstInspectionResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "CriteriaFirstInspectionResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "CriteriaFirstInspection Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to validate serial number API
     */
    fun validateSerialNumber(serialNumReqBody: SerialNumReqBody) = viewModelScope.launch {
        FlareLog.i(TAG, "validateSerialNumber Request: $serialNumReqBody")
        serialValidationResponse.postValue(Resource.Loading())
        val serialNumberValidationRes = receivingRepository.validateSerialNumber(serialNumReqBody)
        serialValidationResponse.postValue(handleSerialNumberValidationResponse(serialNumberValidationRes))
    }

    /**
     * method to handle serial validation response
     */
    private fun handleSerialNumberValidationResponse(response: Response<SerialValidationResponse>): Resource<SerialValidationResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "SerialNumberResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCode(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "SerialNumber Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * Api request to validate Lot number
     */
    fun validateLotRequest(batchNumber: String) {
        viewModelScope.launch(dispatcher) {
            validateLotNumber(
                ValidateLotNumberASNRequest(
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    batchNumber = batchNumber,
                    itemName = getItem().itemName,
                    itemId = getItem().itemId,
                    asnId = getAsn().asnId,
                    isAsn = false,
                    itemLevelReceiving = true
                )
            )
        }
    }

    /**
     * Api request to validate Lot number from LotMaster
     */
    fun validateLotRequestFromLotMaster() {
        viewModelScope.launch(dispatcher) {
            validateLotNumberFromLotMaster(
                ValidateLotNumberRequestFromLotMaster(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    itemName = getItem().itemName
                )
            )
        }
    }

    /**
     * Function to handle lot request
     */
    internal suspend fun validateLotNumber(request: ValidateLotNumberASNRequest) {
        _validateLotNumberResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateLotNumber(request)
        _validateLotNumberResponse.postValue(handleValidateLotNumberResponse(response))
    }

    /**
     * Function to handle lot request from Lot Master
     */
    private suspend fun validateLotNumberFromLotMaster(request: ValidateLotNumberRequestFromLotMaster) {
        _validateLotNumberResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateLotNumberFromLotMaster(request)
        _validateLotNumberResponse.postValue(handleValidateLotNumberResponse(response))
    }

    /**
     * Function to handle lot response
     */
    private fun handleValidateLotNumberResponse(response: Response<ValidateLotNumberResponse>): Resource<ValidateLotNumberResponse> {
        return if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                Resource.Success(resultResponse)
            } ?: Resource.Error(response.message())
        } else {
            val errorResponse = handleForwardErrorResponse(
                response.code(),
                response.errorBody(),
                response.message()
            )
            Resource.Error(errorResponse)
        }
    }


    /**
     * method to get ASN details
     */
    fun getASNDetails(receivingASNRequest: ReceivingASNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getASNDetails Request: $receivingASNRequest")
        asnDetailsResponse.postValue(Resource.Loading())
        val asnDetailsRes = receivingRepository.getASNDetails(receivingASNRequest)
        asnDetailsResponse.postValue(handleASNDetailsResponse(asnDetailsRes))
    }

    /**
     * method to handle ASN details from response
     */
    private fun handleASNDetailsResponse(asnDetailsResponse: Response<PackageInboundShipmentResponse>): Resource<PackageInboundShipmentResponse>? {
        if (asnDetailsResponse.isSuccessful) {
            asnDetailsResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "asnDetailsResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(asnDetailsResponse.code(), asnDetailsResponse.errorBody(), asnDetailsResponse.message())
            FlareLog.e(TAG, "asnDetails Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get DockDoor details
     */
    fun getDockDoorDetails(receivingDockDoorRequest: ReceivingDockDoorRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "DockDoor Request: $receivingDockDoorRequest")
        dockDoorResponse.postValue(Resource.Loading())
        val dockDoorDetailsRes = receivingRepository.getDockDoorDetails(receivingDockDoorRequest)
        dockDoorResponse.postValue(handleDockDoorDetailsResponse(dockDoorDetailsRes))
    }

    /**
     * method to handle DockDoor details from response
     */
    private fun handleDockDoorDetailsResponse(dockDoorDetailsResponse: Response<PackageInboundShipmentResponse>): Resource<PackageInboundShipmentResponse>? {
        if (dockDoorDetailsResponse.isSuccessful) {
            dockDoorDetailsResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "DockDoor Response: ${Gson().toJson(resultResponse)}")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(dockDoorDetailsResponse.code(), dockDoorDetailsResponse.errorBody(), dockDoorDetailsResponse.message())
            FlareLog.e(TAG, "DockDoor Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get container details
     */
    fun getContainer(container: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "Container Request: containerBarcode=$container ")
        containerResponse.postValue(Resource.Loading())
        val response = receivingRepository.getContainer(container, itemInfo)
        containerResponse.postValue(handleContainerResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handleContainerResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Container Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    /**
     * method to get pallet details
     */
    fun getPalletDetails(palletNumber: String, itemInfo: String) = viewModelScope.launch {
        FlareLog.i(TAG, "PalletDetails Request: containerBarcode=$palletNumber ")
        palletResponse.postValue(Resource.Loading())
        val response = receivingRepository.getContainer(palletNumber, itemInfo)
        palletResponse.postValue(handlePalletResponse(response))
    }

    /**
     * method to handle pallet response
     */
    private fun handlePalletResponse(response: Response<InventoryContainerResponse>): Resource<InventoryContainerResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletResponse Success: $resultResponse")
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Pallet Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to validate staging location
     */
    fun validateStagingLocation(locationClassReq: LocationClassReq) = viewModelScope.launch {
        FlareLog.i(TAG, "StagingLocation Request: $locationClassReq")
        stagingLocationResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateStagingLocation(locationClassReq)
        stagingLocationResponse.postValue(handleStagingLocationResponse(response))
    }

    /**
     * method to handle staging location response
     */
    private fun handleStagingLocationResponse(response: Response<LocationClassRes>): Resource<LocationClassRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "StagingLocation Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }


    /**
     * method to validate LPN
     */
    fun validateLPN(rcValidateLPNRequest: RCValidateLPNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "ValidateLPN Request: $rcValidateLPNRequest")
        validateLPNResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateLPN(rcValidateLPNRequest)
        validateLPNResponse.postValue(handleLPNResponse(response))
    }

    fun validateLPNForContainer(rcValidateLPNRequest: RCValidateLPNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "ValidateLPN Request: $rcValidateLPNRequest")
        validateLPNResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateLPNForContainer(rcValidateLPNRequest)
        validateLPNResponse.postValue(handleLPNResponse(response))
    }

    /**
     * method to validate pallet number
     */
    fun validatePalletNumber(rcValidateLPNRequest: RCValidateLPNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "ValidateLPN Request: $rcValidateLPNRequest")
        validateLPNResponse.postValue(Resource.Loading())
        val response = receivingRepository.validatePalletNumber(rcValidateLPNRequest)
        validateLPNResponse.postValue(handleLPNResponse(response))
    }

    /**
     * method to end receiving
     */
    fun endReceiving(endReceiving: EndReceiving) = viewModelScope.launch {
        FlareLog.i(TAG, "End receiving Request: $endReceiving")
        endReceivingPalletResponse.postValue(Resource.Loading())
        val response = receivingRepository.endReceiving(endReceiving)
        endReceivingPalletResponse.postValue(handleExitReceivingResponse(response))
    }

    /**
     * method to handle LPN response
     */
    private fun handleLPNResponse(response: Response<RCValidateLPNResponse>): Resource<RCValidateLPNResponse> {

        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateLPNResponse Success:$resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse: String = if(response.message().isNullOrEmpty()) {
                handleForwardErrorDescription(response.code(), response.errorBody(), Constants.COMMON_ERROR_MESSAGE )
            } else {
                handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
            }
            return Resource.Error(errorResponse)
        }
        return Resource.Error(response.message())
    }

    /**
     * method to submit receiving LPN
     */
    fun submitReceivingLPN(rcSubmitReceivingLPNRequest: RCSubmitReceivingLPNRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "SubmitReceivingLPN Request: $rcSubmitReceivingLPNRequest")
        submitReceivingLPNResponse.postValue(Resource.Loading())
        val response = receivingRepository.submitReceivingLPN(rcSubmitReceivingLPNRequest)
        submitReceivingLPNResponse.postValue(handleSubmitReceivingLPNResponse(response))
    }

    /**
     * method to validate transaction param
     */
    fun submitValidateTransactionParam(request: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "submit validate transaction param Request: $request")
        validateTransactionParamResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateTransactionParam(request)
        validateTransactionParamResponse.postValue(handleTransactionParamResponse(response))
    }


    /**
     * method to handle submit receiving LPN response
     */
    private fun handleSubmitReceivingLPNResponse(response: Response<RCSubmitReceivingLPNResponse>): Resource<RCSubmitReceivingLPNResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "SubmitReceivingLPN Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to get transaction param details
     */
    fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionParamResponse.postValue(Resource.Loading())
        val response = receivingRepository.getTransactionParam(transactionParamRequest)
        transactionParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to get transaction param details
     */
    fun getRPCTransactionParam(transactionParamRequest: TransactionParamRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "transactionParam Request: $transactionParamRequest")
        transactionRPCParamResponse.postValue(Resource.Loading())
        val response = receivingRepository.getTransactionParam(transactionParamRequest)
        transactionRPCParamResponse.postValue(handleTransactionParamResponse(response))
    }

    /**
     * method to handle transaction param response
     */
    private fun handleTransactionParamResponse(transactionParamResponse: Response<TransactionParamResponse>): Resource<TransactionParamResponse>? {
        if (transactionParamResponse.isSuccessful) {
            transactionParamResponse.body()?.let { resultResponse ->
                FlareLog.i(TAG, "TransactionParamResponse: $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse =
                handleForwardErrorResponse(transactionParamResponse.code(), transactionParamResponse.errorBody(), transactionParamResponse.message())
            FlareLog.e(TAG, "TransactionParam Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun generatePalletCaseNumber(type: String) = viewModelScope.launch {
        newPalletDetailResponse.postValue(Resource.Loading())
        val response = receivingRepository.generatePalletCaseNumber(type)
        newPalletDetailResponse.postValue(handleGeneratePalletCaseNumberResponse(response))
    }

    private fun handleGeneratePalletCaseNumberResponse(response: Response<CaseTransferPalletGenerateResponse>): Resource<CaseTransferPalletGenerateResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletGenerateResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "PalletGenerate Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    /**
     * method to get container details
     */
    fun getPalletDetail(palletNumber: String, transferType: String) = viewModelScope.launch {
        palletDetailResponse.postValue(Resource.Loading())
        val response = receivingRepository.palletDetailValidate(palletNumber, transferType)
        palletDetailResponse.postValue(handlePalletDetailResponse(response))
    }

    /**
     * method to handle container response
     */
    private fun handlePalletDetailResponse(response: Response<CaseTransferContainerResponse>): Resource<CaseTransferContainerResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "PalletResponse : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorCodeAndDescription(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "Pallet Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private var ddAsn: InboundShipment? = null
    private var item: MutableLiveData<Item> = MutableLiveData()
    private var location: MutableLiveData<Location> = MutableLiveData()
    private var inventoryLocksOptions: MutableLiveData<ArrayList<String>> = MutableLiveData()
    private var asnDDDetails: MutableLiveData<InboundShipment> = MutableLiveData()
    private var stagingLocation: MutableLiveData<com.fsc.flare.source.data.dto.pickingforward.res.Location> = MutableLiveData()
    private var lpnDetails: MutableLiveData<RCValidateLPNResponse> = MutableLiveData()
    private var caseNbrList: MutableLiveData<List<String>> = MutableLiveData()
    private val receivingPalletCommonData: MutableLiveData<ReceivingPalletCommonData> = MutableLiveData()
    private var inventoryTypeSelected : MutableLiveData<String> = MutableLiveData()
    private var inventoryTypesHashMap :  MutableLiveData<HashMap<String, String>> = MutableLiveData()
    private var defaultInvTypeCode : MutableLiveData<String> = MutableLiveData()
    private var defaultInvTypeDesc : MutableLiveData<String> = MutableLiveData()
    var countriesHashMap : HashMap<String, String> = hashMapOf()
    var countriesWithCodesList : ArrayList<String> = arrayListOf()
    private var containerLocksHashMap: HashMap<String, String> = hashMapOf()


    fun getExpiryDate(list: List<BatchDetail>?): String {
        if (list.isNullOrEmpty() || list[0].expirationDateFormat == null) {
            return ""
        }
        return list[0].expirationDateFormat.toString()
    }

    fun getReceivingPalletCommonData(): ReceivingPalletCommonData? {
        return receivingPalletCommonData.value
    }

    fun setReceivingPalletCommonData(data: ReceivingPalletCommonData?) {
        this.receivingPalletCommonData.value = data
    }

    var transValue: MutableLiveData<String> = MutableLiveData()
    var transRPCValue: MutableLiveData<Int> = MutableLiveData()
    var palletNumberValue: MutableLiveData<String> = MutableLiveData()

    fun isEligibleForEndReceiving(): Boolean {
        return  ddAsn?.asnNumber?.isNotEmpty() == true
    }

    fun getAsn(): InboundShipment {
        return ddAsn!!
    }

    fun setAsn(ddAsn: InboundShipment?) {
        this.ddAsn = ddAsn
    }

    fun getItem(): Item {
        return item.value!!
    }

    fun setItem(item: Item) {
        this.item.value = item
    }

    fun getLocation(): Location? {
        return location.value
    }

    fun setLocation(location: Location) {
        this.location.value = location
    }

    fun setAsnDDDetails(ddAsn: InboundShipment) {
        this.asnDDDetails.value = ddAsn
    }

    fun getAsnDDDetails(): InboundShipment {
        return asnDDDetails.value!!
    }

    fun getAsnDDDetails2(): InboundShipment? {
        return asnDDDetails.value
    }

    fun setLPNDetails(lpnDtls: RCValidateLPNResponse) {
        this.lpnDetails.value = lpnDtls
    }

    fun getLPNDetails(): RCValidateLPNResponse {
        return lpnDetails.value!!
    }

    fun setStagingLocationDetails(location: com.fsc.flare.source.data.dto.pickingforward.res.Location) {
        this.stagingLocation.value = location
    }

    fun setCaseNbrList(list: List<String>) {
        this.caseNbrList.value = list
    }

    fun getCaseNbrList(): List<String>? {
        return caseNbrList.value
    }

    fun setFirstArticleMsgShown(itemBarCode: String) {
        this.firstArticleMsgShown.add(itemBarCode)
    }

    fun getFirstArticleMsgShown(): List<String> {
        return firstArticleMsgShown
    }

    fun emptyFirstArticleMsgShown()
    {
        this.firstArticleMsgShown.clear()
    }

    fun setTransValue(transValue: String) {
        this.transValue.value = transValue
    }

    fun getTransValue(): String {
        return transValue.value!!
    }

    fun setRPCTransValue(transValue: Int) {
        this.transRPCValue.value = transValue
    }

    fun getRPCTransValue(): Int {
        return transRPCValue.value!!
    }

    fun setPalletNumberValue(palletNumberValue: String) {
        this.palletNumberValue.value = palletNumberValue
    }

    fun getPalletNumberValue(): String {
        return palletNumberValue.value!!
    }

    fun getInventoryTypesHashMap(): HashMap<String, String>  {
        return inventoryTypesHashMap.value!!
    }

    fun setInventoryTypesHashMap(inventoryTypesHashMap: HashMap<String, String>) {
        this.inventoryTypesHashMap.value = inventoryTypesHashMap
    }

    fun getInventoryTypeSelected():String? {
        return inventoryTypeSelected.value
    }

    fun setInventoryTypeSelected(inventoryTypeSelected: String) {
        this.inventoryTypeSelected.value = inventoryTypeSelected
    }
    fun getDefaultInvTypeCode():String? {
        return defaultInvTypeCode.value
    }

    fun setDefaultInvTypeCode(defaultInvTypeCode: String) {
        this.defaultInvTypeCode.value = defaultInvTypeCode
    }
    fun getDefaultInvTypeDesc():String? {
        return defaultInvTypeDesc.value
    }

    fun setDefaultInvTypeDesc(defaultInvTypeDesc: String) {
        this.defaultInvTypeDesc.value = defaultInvTypeDesc
    }

    fun getContainerLockCode(containerId: String): String? {
        return containerLocksHashMap[containerId]
    }

    fun addContainerLockCode(containerId: String, lockCode: String): Boolean{
        return if (!isContainerLockAdded(containerId)) {
            containerLocksHashMap[containerId] = lockCode
            true
        } else {
            containerLocksHashMap[containerId] == lockCode
        }
    }

    private fun isContainerLockAdded(containerId: String): Boolean {
        return containerLocksHashMap.containsKey(containerId)
    }

    /**
     * method to get inventory lockcodes
     */
    val inventoryLockcodeResponse: MutableLiveData<Resource<InventoryLockCodeResponse>> = SingleLiveEvent()

    fun getInventoryLockCodes() =
        viewModelScope.launch {
            inventoryLockcodeResponse.postValue(Resource.Loading())
            val response = receivingRepository.getInventoryLockCodes(
                InventoryLockcodeRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
            inventoryLockcodeResponse.postValue(handleInventoryLockCodesResponse(response))
        }

    /**
     * method to handle inventory lockcodes response
     */
    private fun handleInventoryLockCodesResponse(response: Response<InventoryLockCodeResponse>): Resource<InventoryLockCodeResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryLockcodesResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getInventoryLockcodes Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    val inventoryTypesLookUpResponse: MutableLiveData<Resource<LookUps>> = SingleLiveEvent()

    fun getInventoryTypeLookUps(lookUpsRequest: LookUpsRequest) = viewModelScope.launch {
        inventoryTypesLookUpResponse.postValue(Resource.Loading())
        val response = receivingRepository.getLookUps(lookUpsRequest)
        inventoryTypesLookUpResponse.postValue(handleInventoryTypesResponse(response))
    }

    private fun handleInventoryTypesResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getInventoryTypesResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getInventoryTypes Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun setDataToDefault() {
        setPalletNumberValue("")
        setCaseNbrList(ArrayList())
        setRPCTransValue(0)
        setTransValue("")
    }

    fun getCountriesLookUps(lookUpsRequest: LookUpsRequest) = viewModelScope.launch {
        countriesLookUpResponse.postValue(Resource.Loading())
        val response = receivingRepository.getLookUps(lookUpsRequest)
        countriesLookUpResponse.postValue(handleCountriesLookUpResponse(response))
    }

    private fun handleCountriesLookUpResponse(response: Response<LookUps>): Resource<LookUps>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "getCountriesLookUps Success : $resultResponse")

                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "getCountriesLookUps Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    fun validateOverReceipt(asnId: Int, itemId: Int, qty: Int, invType: String?, lotNumber: String?) = viewModelScope.launch {
        validateOverReceiptResponse.postValue(Resource.Loading())
        val response = receivingRepository.validateOverReceipt(asnId,itemId,qty,invType,lotNumber)
        validateOverReceiptResponse.postValue(handleValidateOverReceiptResponse(response))
    }

    private fun handleValidateOverReceiptResponse(response: Response<ValidateOverReceiptResponse>): Resource<ValidateOverReceiptResponse>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "validateOverReceiptResponse Success : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "validateOverReceiptResponse Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    var _queryCombinations = listOf<String>()
    val queryCombinations: List<String> get() = _queryCombinations

    lateinit var _validateLPNResponseObject: RCValidateLPNResponse
    val validateLPNResponseObject: RCValidateLPNResponse get() = _validateLPNResponseObject

    /**
     * Verify's Item UOM's are defined or not.
     */
    fun isUMOAllowForReceiving(itemDetails: Item) = when (selectedContainerType) {

        CASE -> {
            listOf("CS", "EA").all { requiredUOM -> itemDetails.uomConversions.any { it.toUOM == requiredUOM } }
        }

        PALLET -> {
            listOf("CS", "EA", "PL").all { requiredUOM -> itemDetails.uomConversions.any { it.toUOM == requiredUOM } }
        }

        else -> {
            false
        }
    }

    /**
     * method to check recall locks and proceed
     */
    fun checkRecallLocksAndProceed(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ClearError)
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar( isShowProgress = true))

            val recallLockRequest = ItemRecallLockRequest(
                itemCode = item.value?.itemName ?: "",
                asnNumber = ddAsn?.asnNumber ?: "",
                lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, null),
                coo = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, null),
                invType = inventoryTypeSelected.value,
                vendorName = ddAsn?.vendorName ?: "",
                expiryDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, null),
                status = arrayListOf("1")
            )

            _queryCombinations = recallLockRequest.generateCombinations()

            val recallResponse = receivingRepository.getItemRecallLock(
                ItemRecallLockRequest(
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toLong(),
                    itemCode = item.value?.itemName ?: "",
                    status = arrayListOf("1")
                )
            )
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar( isShowProgress = false))
            recallResponse.takeIf { it.isSuccessful && it.body() != null }?.body()?.let {
                FlareLog.i(TAG, "itemRecallResponse Success Response: $it")
                if (it.success) {
                    FlareLog.i(TAG, "recall Lock Status ${it.recallLocksDetails[0].status}")
                    if(it.recallLocksDetails.isNotEmpty()) {
                        val recallLock = acquireRecallLockForCombination(it)
                        recallLock?.let { FlareLog.i("recallLock", recallLock) }
                        when {
                            !recallLock.isNullOrBlank() && _queryCombinations.contains(recallLock) -> {
                                isItemRecalled = true
                                _submitReceivingViewState.emit(SubmitReceiveEvent.ItemRecallAlert)
                            }

                            else -> _submitReceivingViewState.emit(SubmitReceiveEvent.CallReceivingSubmitAPI)
                        }
                    } else _submitReceivingViewState.emit(SubmitReceiveEvent.CallReceivingSubmitAPI)
                } else _submitReceivingViewState.emit(SubmitReceiveEvent.CallReceivingSubmitAPI)
            } ?: run {
                val errorResponse = handleForwardErrorResponse(recallResponse.code(), recallResponse.errorBody(), recallResponse.message())
                FlareLog.e(TAG, "itemRecallResponse Error Response: $errorResponse")
                _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ResponseError(errorResponse))
            }
        }
    }

    /**
     * method to submit receiving for virtual cases scenario.
     */
    fun virtualCasesReceivingSubmit(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ClearError)
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = true))
            val response = receivingRepository.submitReceiving(getSubmitReceivingRequest())
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = false))
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { successResponse ->
                FlareLog.i(TAG, "SubmitReceivingResponse : $successResponse")
                if (successResponse.success) {
                    if (selectedContainerType == null) {
                        _submitReceivingViewState.emit(SubmitReceiveEvent.ReceivingSuccess(successResponse.message))
                    } else {
                        containersToBePrint = successResponse.containers
                        _submitReceivingViewState.emit(SubmitReceiveEvent.ReceivingSuccessWithPrintLabels(successResponse.message))
                    }
                } else {
                    _submitReceivingErrorState.emit(successResponse.message.takeIf { it.isNotEmpty() }
                        ?.let { SubmitReceiveErrorMessage.ResponseError(it) }
                        ?: SubmitReceiveErrorMessage.SomethingWentWrong)
                }
            } ?: run {
                val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
                FlareLog.e(TAG, "SubmitReceiving Error Response: $errorResponse")
                _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ResponseError(errorResponse))
            }
        }
    }

    /**
     * method to get print requesters
     */
    fun getPrintRequesters(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ClearError)
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = true))
            val request = PrinterConfigRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                page = 0,
                pageLimit = 100,
                printerType = "LBL"
            )
            val response = masterPalletRepackRepository.getPrintRequestorList(request)
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = false))
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { successResponse ->
                if (successResponse.printerConfigs.isNotEmpty()) {
                    printRequesters = successResponse.printerConfigs.map { it.requestor }
                    _submitReceivingViewState.emit(SubmitReceiveEvent.PrintRequesters(printRequesters ?: emptyList()))
                } else {
                    _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.NoPrintRequesters())
                }
            } ?: run {
                val errorResponse = handleForwardErrorDescription(response.code(), response.errorBody(), response.message())
                FlareLog.e(TAG, "PrintRequesterResponse Error: $errorResponse")
                _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.NoPrintRequesters(errorResponse))
            }
        }
    }

    /**
     * method to print labels
     */
    fun printLabels(scope: CoroutineScope = viewModelScope, printRequester: String) {
        scope.launch {
            _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.ClearError)
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = true))
            val response = masterPalletRepackRepository.printContainerLabelInfo(
                PrintContainerLabelRequest(
                    printRequester = printRequester,
                    labelType = IB_CASE_LABEL,
                    containers = containersToBePrint ?: emptyList()
                )
            )
            _submitReceivingViewState.emit(SubmitReceiveEvent.ProgressBar(isShowProgress = false))
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.let { successResponse ->
                FlareLog.i(TAG, "PrintLabelsResponse : $successResponse")
                if (successResponse.success) {
                    _submitReceivingViewState.emit(SubmitReceiveEvent.PrintLabelsSuccess)
                } else {
                    _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.UnableToPrintLabels(successResponse.message ?: ""))
                }
            } ?: run {
                val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
                FlareLog.e(TAG, "Print virtual labels labels Error: $errorResponse")
                _submitReceivingErrorState.emit(SubmitReceiveErrorMessage.UnableToPrintLabels(errorResponse))
            }
        }
    }

    /**
     * method to get submit receiving request
     */
    private fun getSubmitReceivingRequest(containerNum: String = ""): SubmitReceivingRequest {

        val serialNumberTypeToken = object : TypeToken<List<SerialNumber?>?>() {}.type
        val serialNumbers: List<SerialNumber> = sharedPreferences.getString(PreferenceKeys.SERIAL_NUM_LIST, null)?.let { Gson().fromJson(it, serialNumberTypeToken) } ?: emptyList()

        val itemRequest = ItemRequest(
            containerNum = containerNum,
            coo = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_COUNTRY_OF_ORIGIN, ""),
            expDate = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_EXPIRATION_DATE, ""),
            itemId = item.value?.itemId ?: -1,
            itemQty = when (selectedContainerType) {
                PALLET -> 1
                CASE -> casesQuantity
                else -> sharedPreferences.getString(PreferenceKeys.Item.TRX_QUANTITY_INPUT, "")?.toIntOrNull() ?: 0
            },
            itemQtyUom = when (selectedContainerType) {
                PALLET -> "PL"
                CASE -> "CS"
                else -> "EA"
            },
            itemBarcode = item.value?.itemBarCode ?: "",
            lotNumber = sharedPreferences.getString(PreferenceKeys.Item.ITEM_BARCODE_TRACKING_LOT_NO, "") ?: "",
            trxQty = sharedPreferences.getString(PreferenceKeys.Item.QUANTITY_INPUT, "")?.toIntOrNull() ?: 0,
            trxQtyUom = sharedPreferences.getString(PreferenceKeys.Item.UOM_INPUT, "") ?: ""
        )

        val location = Locations(
            `class` = location.value?.classification ?: "",
            locationId = sharedPreferences.getString(PreferenceKeys.Item.LOCATION_ID_INPUT, "")?.toIntOrNull() ?: 0,
            status = location.value?.status ?: "",
            locationBarcode = location.value?.locationBarcode ?: ""
        )

        return SubmitReceivingRequest(
            asnId = ddAsn?.asnId ?: -1,
            asnStatus = ContainerStatus.PUTAWAY.code,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            inventoryType = inventoryTypesHashMap.value?.entries?.find { it.value == inventoryTypeSelected.value }?.key,
            item = itemRequest,
            locations = location,
            requestIdentifier = Utility.generateUUID(),
            transactionDate = DateTime.now().toString(),
            trxMenu = "ASN",
            vendorId = ddAsn?.vendorId ?: -1,
            serialNumbers = serialNumbers,
            lockCodes = getLockCodeList(),
            captureNewLot = !sharedPreferences.getString(PreferenceKeys.RECEIVING_LOT_MESSAGE, "").equals(RECORD_EXISTS),
            firstReceipt = sharedPreferences.getBoolean(PreferenceKeys.RECEIVING_FIRST_ARTICLE_INSPECTION, false),
            isOutBoundTracked = item.value?.tracking?.serialNumberRequired == Constants.ApplicationConstants.SERIAL_TRACK_OUTBOUND_ONLY,
            virtualLabelsNeeded = selectedContainerType == CASE || selectedContainerType == PALLET,
            virtualContainerType = when (selectedContainerType) {
                CASE -> "C"
                PALLET -> "P"
                else -> ""
            },
            palletNbr = newPalletNumber ?: ""
        )
    }

    /**
     * method to get list of selected lock codes
     */
    private fun getLockCodeList(): List<LockcodeRequest> {
        lockCodesLocalList.clear()
        if (isItemRecalled) addItemRecallLock()
        if (isItemExpired) addItemExpiredLock()
        if (isFirstArticleInspectionLockNeeded) addFirstArticleLock()

        val lockCodeData = sharedPreferences.getString(PreferenceKeys.RECEIVING_LOCK_CODES, null)
        if (!lockCodeData.isNullOrEmpty()) {
            val inventoryLockCode: InventoryLockcode? = Gson().fromJson(lockCodeData, InventoryLockcode::class.java)
            inventoryLockCode?.let { lockCode ->
                lockCodesLocalList.add(LockcodeRequest(lockCode.code, lockCode.lockCodeId))
            }
        }
        return lockCodesLocalList.distinct()
    }

    /**
     * Function to add recall lock
     */
    private fun addItemRecallLock() {
        lockCodesList.firstOrNull { it.code == "RC" && it.channel == "F" }
            ?.let { inventoryLockCodeWithRC ->
                lockCodesLocalList.add(
                    LockcodeRequest(
                        lockCode = inventoryLockCodeWithRC.code ?: "",
                        lockCodeId = inventoryLockCodeWithRC.lockCodeId ?: 0
                    )
                )
            }
    }

    private fun addItemExpiredLock() {
        lockCodesList
            .firstOrNull { it.code == "EX" && it.channel == "F"}
            ?.let { inventoryLockCodeWithEX ->
                lockCodesLocalList.add(
                    LockcodeRequest(
                        lockCode = inventoryLockCodeWithEX.code ?: "",
                        lockCodeId = inventoryLockCodeWithEX.lockCodeId ?: 0
                    )
                )
            }
    }

    /**
     * Function to add first article inspection lock
     */
    private fun addFirstArticleLock() {
        if (isFirstArticleInspectionLockNeeded) {
            storeItemBarCodeToHandleNextFIADialog()
            firstArticleLockCode?.let { lockCodeJson ->
                if (lockCodeJson != "null") {
                    val faiLockCode: InventoryLockcode? = Gson().fromJson(lockCodeJson, InventoryLockcode::class.java)
                    faiLockCode?.code?.let { code ->
                        faiLockCode.lockCodeId?.let { lockCodeId ->
                            lockCodesLocalList.add(LockcodeRequest(code, lockCodeId))
                        }
                    }
                }
            }
        }
    }

    /**
     * Function to acquire recall lock for a combination applied
     */
    private fun acquireRecallLockForCombination(response: ItemRecallLockResponse): String? {
        val responseAttributes = extractRecallAttributes(response)
        for (combination in responseAttributes) {
            if (combination.contains(item.value?.itemName ?: "") && responseAttributes.any { it == combination }) {
                return combination
            }
        }
        return null
    }

    /**
     * Function to extract recallAttributes from recallLockDetails and form as a list
     */
    private fun extractRecallAttributes(response: ItemRecallLockResponse): List<String> {
        return response.recallLocksDetails.map { it.recallAttributes.split("+").sorted().joinToString("+") }
    }

    /**
     * Function to save item barcode to display in FAI lock dialog
     */
    private fun storeItemBarCodeToHandleNextFIADialog() {
        if (item.value?.itemBarCode !in firstArticleMsgShown) {
            firstArticleMsgShown.add(item.value?.itemBarCode ?: "")
        }
    }

    fun onClearData() {
        _submitReceivingErrorState.value = null
        _submitReceivingViewState.value = null
    }
}

/**
 * Sealed class to handle submit receiving events
 */
sealed class SubmitReceiveEvent {
    data class ProgressBar(val isShowProgress: Boolean) : SubmitReceiveEvent()
    data object CallReceivingSubmitAPI: SubmitReceiveEvent()
    data class ReceivingSuccess(val successMessage: String) : SubmitReceiveEvent()
    data class ReceivingSuccessWithPrintLabels(val successMessage: String) : SubmitReceiveEvent()
    data object PrintLabelsSuccess: SubmitReceiveEvent()
    data class PrintRequesters(val printRequesters: List<String>): SubmitReceiveEvent()
    data object ItemRecallAlert : SubmitReceiveEvent()
}

/**
 * Sealed class to handle submit receiving error messages
 */
sealed class SubmitReceiveErrorMessage {
    data class ResponseError(val errorMessage: String) : SubmitReceiveErrorMessage()
    data object SomethingWentWrong: SubmitReceiveErrorMessage()
    data object ClearError: SubmitReceiveErrorMessage()
    data class NoPrintRequesters(val errorMessage: String? = null): SubmitReceiveErrorMessage()
    data class UnableToPrintLabels(val errorMessage: String): SubmitReceiveErrorMessage()
}