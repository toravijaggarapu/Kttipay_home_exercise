package com.fsc.flare.utils

import com.fsc.flare.BuildConfig

class Constants {

    companion object {
        const val HTTP_TIMEOUT_IN_SECONDS = 15L
        const val UTILITY_CLASS = "Utility class"
        const val COMMON_ERROR_MESSAGE="Something went wrong"
        const val TASK_RELEASED="10"
        const val TASK_ASSIGNED="20"
        const val TASK_IN_PROGRESS="30"
        const val CYC_LOCATION_MISMATCH_ERROR_CODE = "CYC-0003"
        const val CYC_QUANTITY_MISMATCH_ERROR_CODE = "CYC-0004"
        const val CYC_LOCATION_MISMATCH_PALLET_ID_ERROR_CODE = "ERR-CYC-023"
        const val CYC_QUANTITY_MISMATCH_PALLET_ID_ERROR_CODE = "ERR-CYC-022"
        const val TASK_NOT_FOUND_ERROR_CODE = "ERR-CYC-025"
        const val TASK_CYCLE_COUNT_NOT_COUNTED = "ERR-CYC-005"
        const val TASK_PALLET_CONTAINER_CYCLE_COUNT_NOT_COUNTED = "ERR-CYC-031"
        const val TASK_CYCLE_COUNT_SLP_NOT_COUNTED = "ERR-CYC-014"
        const val TASK_CYCLE_COUNT_MORE_CONTAINERS = "ERR-CYC-015"
        const val ERR_INVALID_PALLET = "ERR-INV-0104"
        const val TASK_PALLET_COUNT_CYCLE_COUNT_NOT_COUNTED = "ERR-CYC-034"
        const val TRANSFER_TYPE_PALLET = "Pallet"
        const val FILL_KILL = "FillKill"
        const val DATE_HOUR_MINUTE_FORMAT = "MM-dd-YYYY'T'HH:mm"
        const val MIXED_ATTRIBUTE_LOT = "L#"
        const val MIXED_ATTRIBUTE_EXP_DATE = "E#"
        const val MIXED_ATTRIBUTE_COO = "C#"
        const val MIXED_ATTRIBUTE_MFG_DATE = "M#"
        const val TASK_CYCLE_COUNT_EACHES_MORE_CONTAINERS = "ERR_END_SLCC_004"
        const val TASK_CYCLE_COUNT_EACHES_QTY_MISMATCH = "ERR_SLCC_014"
        const val TASK_CYCLE_COUNT_EACHES_CONTAINER_MISMATCH = "ERR_SLCC_007"
        const val TASK_CYCLE_COUNT_EACHES_PALLET_MISMATCH = "ERR_SLCC_004"
        const val TASK_CYCLE_COUNT_EACHES_LOCATION_CONTAINER_MISMATCH = "ERR_SLCC_003"
        const val ERR_MULTIPLE_SKU = "ERR-MULTIPLE-SKU"
        const val YES = "Y"
        const val NO = "N"
        const val TSK_CREATE_SUCCESS = "TSK_CREATE_SUCCESS"
        const val IS_RTV = "isRTV"
        const val ROOT_MENU_NAME = "rootMenuName"
        const val DISPLAY_NAME = "displayName"
        const val PI_LOCK_STATE_REFRESH_INTERVAL_SECONDS = 60
        const val PI_LOCK_STATE_VALUE_YES = "Y"
    }

    object BarcodeSCAC {
        const val SCAC_RPSC = "RPSC"
    }

    object RequestHeaders {
        const val HEADER_BUID = "BUID"
        const val HEADER_CUSTOMER = "CUSTOMER"
        const val HEADER_WAREHOUSE = "WAREHOUSE"
        const val HEADER_AUTHORIZATION = "Authorization"
        const val HEADER_CONTENT_TYPE = "Content-Type"
        const val HEADER_CONNECTION = "Connection"
        const val HEADER_APPID = "APPID"
        const val HEADER_UUID = "UUID"
        const val HEADER_ORIGIN = "Origin"
        const val HEADER_OktaJWTToken = "OktaJWTToken"
        const val HEADER_OktaTempJWTToken = "OktaTempJWTToken"
        const val HEADER_FSC_USER = "FSC_USER"
        const val VALUE_APP_JSON = "application/json"
        const val VALUE_APP_ID = "APP3536781"
        const val VALUE_ORIGIN = BuildConfig.ORIGIN
        const val VALUE_CONNECTION_CLOSE = "close"
        const val HEADER_ID_TOKEN = "X-ID-Token"
        const val HEADER_LANGUAGE = "Accept-Language"
        const val HEADER_APP_NAME = "appName"
        const val HEADER_MODULE = "Module"
        const val HEADER_CUST_ID = "custId"
        const val HEADER_BU_ID = "buId"
        const val HEADER_FACILITY_ID = "facId"
        const val HEADER_CUST_NAME = "custName"
        const val HEADER_TRACE_PATH = "tracePath"
        const val HEADER_LOGGED_IN_USER = "FSC_LOGGED_IN_USER"
        const val VALUE_APP_NAME = "FLARE"
        const val VALUE_MODULE = "RF"
        const val VALUE_TRACE_PATH = "RF"
        const val HEADER_FCY_TIMEZONE = "FCY_TIMEZONE"
        const val HEADER_FCY_TZ_GMT_OFFSET = "FCY_TZ_GMT_OFFSET"
        const val FSC_USER_ID = "FSC_USER_ID"
        const val MACHINE_ID = "machineId"
        const val MACHINE_NAME = "machineName"
        const val ENROLLMENT_TYPE = "enrollmentType"
        const val TIME_STAMP = "timeStamp"
        const val OPERATIONAL_DELAY = 500L
        const val HEADER_FCY_ID = "fcyId"
        const val BEARER = "Bearer"
    }

    object ReceivingPallet {
        const val ASN_NUMBER = "ASN_NUMBER"
        const val PALLET_NUMBER = "PALLET_NUMBER"
        const val CASE_COUNT_NUMBER = "CASE_COUNT_NUMBER"
    }

    object ReceivingPalletFromScreen {
        const val CONTAINER_NUMBER_SCREEN = "CONTAINER_NUMBER_SCREEN"
        const val PALLET_NUMBER_SCREEN = "PALLET_NUMBER_SCREEN"
        const val CASE_COUNT_SCREEN = "CASE_COUNT_SCREEN"
        const val ITEM_ATTRIBUTES_REQUIRED = "Item Attributes Required"
    }

    class PreScanScreen private constructor() {
        companion object {
            const val RETURNS = "Returns"
            const val LAUNCHED_FROM_PRE_PROCESS_SCREEN = "launchedFrom"
            const val CUSTOMER_DETAILS = "customerDetails"
            const val DEFAULT_VENDOR_CODE = "defaultVendorCode"
            const val PRE_SCAN_PARAMETER_SCAN = "scan"
            const val PRE_SCAN_VENDOR_REQUEST_ACTIVE_COUNT = 1
            const val PRE_SCAN_RMA_PAGE_NUMBER = 0
            const val PRE_SCAN_RMA_PAGE_LIMIT = 10
        }
    }

    class ApplicationConstants private constructor() {
        companion object {
            const val SOMETHING_WENT_WRONG = "Something went wrong."
            const val NAVIGATION_POST_DELAY_TIME = 1000L
            const val NAVIGATION_POST_DELAY_TIME_500 = 500L
            const val AUTO_GENERATE_PALLET_NUMBER = "AGPN"
            const val AUTO_GENERATE_CASE_NUMBER = "AGCN"
            const val PRINT_PALLET_LABEL = "PPL"
            const val PRINT_CASE_LABEL = "PCL"
            const val SERIAL_TRACK_OUTBOUND_ONLY = "1"
            const val SERIAL_TRACK_FULL_TRACKING = "4"
        }
    }

    object CustomersApi {
        const val DETAILS_FILTER = "details"
    }

    object LockCodes {
        const val INCUBATION_HOLD = "IH"
        const val FIRST_ARTICLE_INSPECTION = "FAI"
        const val QUALITY_HOLD = "QHLOCK_ENABLE"
        const val QUALITY_AUDIT_VENDOR_COMPLIANCE_LOCK = "QAVC"
        const val RECALL_LOCK = "RC"
        const val CYCLE_COUNT_LOCK = "CC"
    }

    object DateFormatter {
        const val INPUT_DATE_FORMAT = "yyyyMMdd"
        const val OUTPUT_DATE_FORMAT = "yyyy-MM-dd"
    }

    object LocationClasses {
        const val ACTIVE = "A"
        const val QUARANTINE_ACTIVE = "QA"
        const val QUARANTINE_CASEPICK = "QC"
        const val QUARANTINE_RESERVE = "QR"
        const val CASE_PICK = "C"
        const val RESERVE = "R"
        const val DAMAGE_CASE_PICK = "DMC"
        const val DAMAGE_RESERVE = "DMR"
        const val STAGE = "S"
        const val INBOUND_QA = "IBQA"
        const val OUTBOUND_QA = "OBQA"
    }

    object ItemCategory {
        const val HAZMAT = "H"
        const val NON_HAZMAT = "N"
    }

    object AllocationType {
        const val ACTIVE_PARCEL = "10"
        const val ACTIVE_LTL = "11"
        const val FROM_CASE_PICK = "20"
        const val FROM_RESERVE_PICK = "30"
        const val INVENTORY_MOVEMENT_TO_DAMAGE_CASE_PICK = "100"
        const val INVENTORY_MOVEMENT_TO_DAMAGE_RESERVE = "110"
        const val INVENTORY_MOVEMENT_TO_ISOLATED_LOCATION = "120"
    }

    object Lookup {
        const val LOOKUP_INVENTORY_TYPES = "INVENTORY_TYPES"
        const val LOOKUP_ORDER_STATUS = "ORDER_STATUS"
        const val LOOKUP_CONTAINER_STATUS = "CONTAINER_STATUS"
        const val LOOKUP_LOCATION_STATUS = "LOCATION_STATUS"
        const val LOOKUP_LOCATION_TYPE = "LOCATION_TYPE"
        const val LOOKUP_LOCATION_CLASSES = "LOCATION_CLASSES"
        const val LOOKUP_LD_ULD_TRAIL_PALLET_OVERRIDE = "LD_ULD_TRAIL_PALLET_OVERRIDE"
        const val PICK_ORD_TYPE_SELECTION = "PICK_ORD_TYPE_SELECTION"
        const val ALLOC_TYPE_ORD_TYPE_SELECTION = "ALLOC_TYPE_ORD_TYPE_SELECTION"
        const val PCL_ORD_TYPES = "PCL_ORD_TYPES"
        const val LTL_ORD_TYPES = "LTL_ORD_TYPES"
        const val RESTRICT_LOCKS_FWD_INV_TRANS = "RESTRICT_LOCKS_FWD_INV_TRANS"
        const val LOCK_COMPARE_IN_PALLETIZE_CONT = "LOCK_COMPARE_IN_PALLETIZE_CONT"
        const val CASE_PICK_METHOD = "CASE PICK METHOD"
        const val ENABLE_DMG_LOC_MVMNT = "ENABLE_DMG_LOC_MVMNT"
        const val ENABLE_SYS_ICP = "ENABLE_SYS_ICP"
        const val ENABLE_REPLEN_PICK_DROP = "ENABLE_REPLEN_PICK_DROP"
        const val PPP_OUTBOUND_DOCUMENT_TYPE = "PPP_OUTBOUND_DOCUMENT_TYPE"
        const val LOOKUP_PI_LOCK_STATUS = "PI_LOCK_STATUS"
        const val OUTBOUND_MOVEMENT_TYPE = "OUTBOUND_MOVEMENT_TYPE"
        const val OUTBOUND_MOVEMENT_TRANSFER_TO = "OUTBOUND_MOVEMENT_TRANSFER_TO"
    }

    object TaskModes {
        const val SYSTEM_DIRECTED = "System Directed"
        const val USER_DIRECTED = "User Directed"
        const val CC_USER_DIRECTED_VALUE ="M"
    }

    object ContainerType {
        const val PALLET = "P"
        const val CASE = "C"
    }

    object TaskTypes {
        const val USER_CYCLE_COUNT_CASE_PICK = "UCC"
        const val CYCLE_COUNT_FOR_CASE_PICK = "CCC"
        const val RECOUNT_FOR_CASE_PICK = "CRC"
        const val USER_CYCLE_COUNT_RESERVE = "UCR"
        const val CYCLE_COUNT_FOR_RESERVE = "CCR"
        const val RECOUNT_FOR_RESERVE = "CRR"
        const val RECOUNT_CASEPICK = "CRC"
        const val RECOUNT_RESERVE = "CRR"
        const val CC_REVERSE_COUNT= "RVCA"
        const val CC_REVERSE_RECOUNT= "RVRA"
    }

    object ContainerStatus {
        const val CREATED = "0"
        const val RECEIVED = "10"
        const val PUTAWAY = "20"
        const val CLOSED = "25"
        const val PARTIALLY_ALLOCATED = "35"
        const val ALLOCATED = "40"
        const val RA_FORWARD = "55"
        const val RA_RECEIVED = "65"
        const val CONSUMED = "50"
        const val CANCELLED = "99"
        const val SHIPPED = "300"
    }

    object DamageReasonCodes{
        const val DAMAGE_IN_TRANSIT = "DMGT"
        const val DAMAGE_IN_FACILITY = "DMGF"
        const val DAMAGE_IN_CONCEALED = "DMGC"
    }

    object DamageLockCodes{
        const val DAMAGE_IN_TRANSIT = "DT"
        const val DAMAGE_IN_FACILITY = "DF"
        const val DAMAGE_IN_CONCEALED = "DC"
    }

    object InventoryTypes{
        const val PRISTINE = "P"
        const val DAMAGE = "D"
        const val SLIGHT_DAMAGE = "SD"
        const val RESEARCH = "RE"
        const val RETURNED = "RET"
    }

    object ErrorCode{
        const val NO_TASK_FOUND = "NO_TASK_FOUND"
        const val ERR_CNT_DYS_001 = "ERR-CNT-DYS-001"
        const val ERR_CNT_DYS_002 = "ERR-CNT-DYS-002"
    }

    object PhysicalInventoryCountTypes{
        const val PRIMARY_COUNT = "Primary Count"
        const val RECOUNT = "Recount"
        const val AUDIT_COUNT = "Audit Count"
        val PI_LOCK_MENU_NAME = arrayOf(
            "USER DIRECTED PUTAWAY",
            "SYSTEM DIRECTED PUTAWAY",
            "REWAREHOUSE",
            "RE-WAREHOUSE",
            "IB PALLET - SPLIT/COMBINE",
            "PACKOUT FROM ACTIVE",
            "RECEIVING",
            "RECEIVING CARTON",
            "RECEIVING PALLET",
            "PALLETIZE CONTAINER",
            "CONTAINER ADJUSTMENT",
            "INVENTORY MOVEMENT",
            "ADJUSTMENT",
            "PALLET TRANSFER",
            "PALLETIZE IB",
            "SLP",
            "CONTAINER",
            "PACKING",
            "PUTAWAY BY SLP/CNT",
            "PUTAWAY BY UPC",
            "PUTAWAY BY SERIAL#",
            "PUTAWAY CONTAINER",
            "MIXED SB PUTAWAY",
            "PRESCAN",
            "REWAREHOUSE BY SERIAL#",
            "INV MOVE - KIT STAGING TO KIT STATION",
            "INV MOVE - KIT STATION TO KIT STATION",
            "PACK STATION TOTE TO PR",
            "KIT STAGING TO PR",
            "PR TOTE TO PACK STATION",
            "PR TOTE TO KIT STAGING",
            "CHANGE ITEM SIZE BY SLP",
            "BL PICKING"
        )
    }

    class PartsReplacement private constructor() {
        companion object {
            const val TASK_GROUP_TNR = "TNR_TSK"
            const val TASK_TYPE_REPAIR = "TNR_MPR"
            const val TASK_TYPE_PUTAWAY = "TNR_MPP"
            const val MOVE_PARTS_TO_REPAIR = "Move Parts to Repair"
            const val MOVE_PARTS_TO_PUTAWAY = "Move Parts to Putaway"
            const val ACTION_TYPE_GET = "assignAndGet"
            const val ACTION_TYPE_FETCH = "fetchPicked"
            const val ACTION_TYE_COMPLETE_PICK="completePicking"
        }
    }


    class SubMenu private constructor() {
        companion object {
            const val TNR_MOVE_TASK = "T&R MOVE TASK"
        }
    }

    class HomeAdapter private constructor() {
        companion object {
            const val TECH_RF = "TECH RF"
            const val INTERLEAVING = "INTERLEAVING"
        }
    }
}

object AlertConstants {
    const val POSITIVE_BUTTON_TITLE = "OK"
    const val NEGATIVE_BUTTON_TITLE = "CANCEL"

}

object TransCodes {
    const val AOPCCP = "AOPCCP"
    const val UOM_VALID = "UOM_VALID"
    const val MIP = "MIP"
    const val VCPILR = "VCPILR"
}

object PrintLabelTypes {
    const val IB_CASE_LABEL = "IB Case Label"

}

object PickByCaseMethod {
    const val PIK_BY_CNT = "PIK_BY_CNT"
    const val PIK_BY_CASE = "PIK_BY_CASE"
}

object ICPConstants {
    const val ICP_SKIP_TASK_ID = "skipTaskId"
    const val ICP_ALLOCATION_TYPE = "allocationType"
    const val ICP_PICK_CART_NBR = "pickCartNbr"
    const val ICP_IS_LTL_FLOW = "isLTLFlow"

    const val ALLOCATION_TYPE_VALUE = "130"
    const val TASK_GROUP_VALUE = "ICP"
}
object RecallCodes{
    const val RECALL_LOCK = "RC"
    const val RECALL_UNLOAD_ERROR = "ERR-ULD-RC-01"
    const val RECALL_UNLOAD_CONTAINERS = "ULD-001"
    const val RECALL_CLOSE_TRAILER_ERROR = "ERR-CT-RC-01"
}

object LocationTypes{
    const val FORWARD = "F"
    const val REVERSE = "R"
}

object OBMovementTransferToLookUpCodes{
    const val PROBLEM_RESOLUTION = "PR"
    const val OUTBOUND_QA = "OBQA"
    const val PACK_STATION = "PS"
    const val OUTBOUND_STAGING = "S"
}

object MaterialMovementTypeLookUpCode{
    const val TOTE_OR_CARTON_TRANSFER = "TCT"
    const val CART_OR_PALLET_TRANSFER = "PT"
}

