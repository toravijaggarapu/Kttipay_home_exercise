package com.fsc.flare.di

import android.content.SharedPreferences
import android.util.Log
import com.fsc.flare.database.dao.FlareDao
import com.fsc.flare.database.entities.RFlog
import com.fsc.flare.database.utils.LogLevel
import com.fsc.flare.utils.PreferenceKeys
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.logging.HttpLoggingInterceptor.Logger
import java.util.Date
import javax.inject.Inject

class FlareRfAPILog @Inject constructor(
    private val flareDao: FlareDao,
    private val sharedPreferences: SharedPreferences
) : Logger {

    @OptIn(DelicateCoroutinesApi::class)
    override fun log(message: String) {

        val log = RFlog(
            createdBy = sharedPreferences.getString("userName", "") ?: "",
            createdOn = Date(),
            uuid = "",
            customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toLong(),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
            loginUser = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
            customerName = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "undefined").orEmpty(),
            fcyTimeZone = sharedPreferences.getString(PreferenceKeys.FACILITY_TIMEZONE, "").orEmpty(),
            loginUserID = 0L,
            enrollmentType = sharedPreferences.getString(PreferenceKeys.CUSTOMER_ENROLLMENT_TYPE, "").orEmpty(),
            message = message,
            logLevel = LogLevel.INFO
        )

//        GlobalScope.launch(Dispatchers.IO) { flareDao.insert(log) }
        Log.i("FLARE_LOG", log.toString(), null)
    }

}