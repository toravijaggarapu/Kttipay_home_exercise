package com.fsc.flare.ui.fragment.splitcontainerreverse

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.splitcontainerreverse.*
import com.fsc.flare.source.repository.SplitContainerReverseRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.SingleLiveEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "SplitContainerReverseViewModel"
@HiltViewModel
class SplitContainerReverseViewModel @Inject constructor(
    private val splitContainerReverseRepository: SplitContainerReverseRepository
) : BaseViewModel() {


    val fromContainerResponse: MutableLiveData<Resource<SplitContDetailsResponse>> = SingleLiveEvent()
    val skuResponse: MutableLiveData<Resource<SplitSkuResponse>> = SingleLiveEvent()
    val itemBarcodeResponse: MutableLiveData<Resource<SplitSkuResponse>> = SingleLiveEvent()
    val qtyResponse: MutableLiveData<Resource<QtyBaseRes>> = SingleLiveEvent()
    val submitConResponse: MutableLiveData<Resource<SplitContSubmitResponse>> = SingleLiveEvent()
    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()
    val inventoryType: MutableLiveData<String> = MutableLiveData()

    /**
     * method to validate from container
     */
    fun validateFromContainer(splitContDetailsRequest: SplitContDetailsRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "fromContainer request: $splitContDetailsRequest")
            fromContainerResponse.postValue(Resource.Loading())
            val response = splitContainerReverseRepository.validateFromContainer(splitContDetailsRequest)
            fromContainerResponse.postValue(handleFromContainerResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    /**
     * method to validate sku
     */
    fun validateSku(splitSkuRequest: SplitSkuRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "SKU request: $splitSkuRequest")
            skuResponse.postValue(Resource.Loading())
            val response = splitContainerReverseRepository.validateSku(splitSkuRequest)
            skuResponse.postValue(handleSkuResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    /**
     * method to validate itembarcode
     */
    fun validateItemBarcode(splitSkuRequest: SplitSkuRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "com.fsc.flare.source.data.dto.inventoryadjustment.res.Item barcode request: $splitSkuRequest")
            itemBarcodeResponse.postValue(Resource.Loading())
            val response = splitContainerReverseRepository.validateItemBarcode(splitSkuRequest)
            itemBarcodeResponse.postValue(handleItemBarcodeResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }


    /**
     * method to validate QTY
     */
    fun validateQty(qtyBaseReq: QtyBaseReq) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "QTY request: $qtyBaseReq")
            qtyResponse.postValue(Resource.Loading())
            val response = splitContainerReverseRepository.validateQty(qtyBaseReq)
            qtyResponse.postValue(handleQtyResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    /**
     * method to submit split container
     */
    fun validateSubmitSplitContainer(splitContSubmitRequest: SplitContSubmitRequest) = viewModelScope.launch {
        try {
            FlareLog.i(TAG, "Process parts request: $splitContSubmitRequest")
            submitConResponse.postValue(Resource.Loading())
            val response = splitContainerReverseRepository.validateSubmitContainer(splitContSubmitRequest)
            submitConResponse.postValue(handleSubmitSplitContainerResponse(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }


    /**
     * method to handle from container validation response
     */
    private fun handleFromContainerResponse(response: Response<SplitContDetailsResponse>): Resource<SplitContDetailsResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "FromContainer Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to handle sku validation response
     */
    private fun handleSkuResponse(response: Response<SplitSkuResponse>): Resource<SplitSkuResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Sku Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to handle item barcode validation response
     */
    private fun handleItemBarcodeResponse(response: Response<SplitSkuResponse>): Resource<SplitSkuResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "ItemBarcode Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to handle qty validation response
     */
    private fun handleQtyResponse(response: Response<QtyBaseRes>): Resource<QtyBaseRes> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "Qty Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    /**
     * method to handle submit split container response
     */
    private fun handleSubmitSplitContainerResponse(response: Response<SplitContSubmitResponse>): Resource<SplitContSubmitResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
        FlareLog.e(TAG, "SplitContainer Error Response: $errorResponse")
        return Resource.Error(errorResponse)
    }

    fun getInventoryType(): String? {
        return inventoryType.value
    }

    fun setInventoryType(inventoryType: String?) {
       this.inventoryType.value = inventoryType
    }
}