package com.fsc.flare.ui.fragment.submenuchildren

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.login.Children
import com.fsc.flare.utils.StringUtils
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textview.MaterialTextView
import java.util.*

class SubMenuChildrenAdapter(
    private val submenuMenuList: ArrayList<Children>,
    private val listener: OnAdapterClickListener,
    context: Context
) : RecyclerView.Adapter<SubMenuChildrenAdapter.ViewHolder>(), Filterable {

    companion object {
        var row_index = -1
    }

    var filterList = ArrayList<Children>()
    private val mContext: Context

    init {
        filterList = submenuMenuList
        mContext = context
        row_index = -1
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var submenuiv: ImageView = itemView.findViewById(R.id.placeholder_sub_menu)
        var itemData: MaterialTextView = itemView.findViewById(R.id.customer_tv)
        var itemLayout: MaterialCardView = itemView.findViewById(R.id.customer_layout)

    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.item_sub_menu_children, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item: String = filterList[position].displayName!!.uppercase(Locale.ROOT)

        val menuName = StringUtils.langConvertedName(filterList[position].id,filterList[position].displayName, mContext)

        viewHolder.itemData.apply {
            //text = item
            text =menuName
        }
        viewHolder.itemLayout.setOnClickListener {
            row_index = position
            listener.onItemSelected(item,filterList[position].id)
            notifyDataSetChanged()
        }
        viewHolder.itemView.apply {
            if (row_index == position) {
                viewHolder.itemView.backgroundTintList =
                    ContextCompat.getColorStateList(mContext, R.color.colorPrimaryTransparent)
            }
        }
    }

    override fun getItemCount(): Int {
        return filterList.size
    }

    interface OnAdapterClickListener {
        fun onItemSelected(item: String?, menuID:String?)
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                filterList = if (charSearch.isEmpty()) {
                    submenuMenuList
                } else {
                    val resultList = ArrayList<Children>()
                    for (row in submenuMenuList) {
                        if (row.displayName!!.lowercase(Locale.ROOT)
                                .contains(charSearch.lowercase(Locale.ROOT))
                        ) {
                            resultList.add(row)
                        }
                    }
                    resultList
                }
                val filterResults = FilterResults()
                filterResults.values = filterList
                return filterResults
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filterList = results?.values as ArrayList<Children>
                notifyDataSetChanged()
            }
        }
    }
}