package com.fsc.flare.ui.fragment.inquiry.locationInquiry

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fsc.flare.R
import com.fsc.flare.source.data.dto.inquiry.location.ReverseContObj

class ReverseContainerAdapter (private val containers: List<ReverseContObj>):
    RecyclerView.Adapter<ReverseContainerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.reverse_container_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val container = containers[position]
        holder.bind(container)
    }

    override fun getItemCount(): Int {
        return containers.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val containerNbrTextView: TextView = itemView.findViewById(R.id.ContainerNbr)
        private val vendorTextView: TextView = itemView.findViewById(R.id.vendorId)
        private val blNbrTextView: TextView = itemView.findViewById(R.id.BlNumber)
        private val blStatusTextView: TextView = itemView.findViewById(R.id.BlStatus)

        fun bind(container: ReverseContObj) {
            containerNbrTextView.text = container.containerNbr
            vendorTextView.text = container.vendorId
            blNbrTextView.text = container.blNbr
            blStatusTextView.text = container.blStatus
        }
    }
}