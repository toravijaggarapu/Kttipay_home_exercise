package com.fsc.flare.utils

import android.content.Intent
import android.os.Build
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.fsc.flare.source.data.dto.ForwardErrorResponse
import com.fsc.flare.utils.Constants.ApplicationConstants.Companion.SOMETHING_WENT_WRONG
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.Response
import java.io.Serializable

/**
 * Enable or disable field.
 */
fun TextView.enableOrDisableField(isEnable: Boolean) {
    this.isEnabled = isEnable
    this.isFocusable = isEnable
    this.isFocusableInTouchMode = isEnable
    this.alpha = if (isEnable) 1f else 0.35f
    if (isEnable) {
        this.post { this.requestFocus() }
    }
}

/**
 * Observe flow on UI thread.
 */
fun Fragment.observeFlowOnUI(observe: suspend () -> Unit) {
    viewLifecycleOwner.lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            observe()
        }
    }
}

/**
 * Observe navigation results from the target fragment.
 */
inline fun <reified T> Fragment.getNavigationResult(key: String, crossinline callBack: (T) -> Unit) {
    findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<T>(key)?.observe(viewLifecycleOwner) { result ->
        findNavController().currentBackStackEntry?.savedStateHandle?.remove<T>(key)
        result?.let(callBack)
    }
}

/**
 * Set navigation result to the previous fragment.
 */
inline fun <reified T> Fragment.setNavigationResult(key: String, result: T?) {
    findNavController().previousBackStackEntry?.savedStateHandle?.set(key, result)
}

/**
 * Get serializable extra from intent.
 */
inline fun <reified T : Serializable> Intent.serializable(key: String): T? = when {
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
        getSerializableExtra(key, T::class.java)
    }

    else -> {
        @Suppress("DEPRECATION")
        getSerializableExtra(key) as? T
    }
}

/**
 * Get error code and message from response body.
 *
 * @return A Pair where the first element is the error code (nullable) and the second element is the error message (non-nullable).
 *         If an error code is available, it will be in the first element, otherwise it will be null.
 *         The second element will always contain the error message.
 */
inline fun <reified T> Response<T>?.getErrorCodeAndMessage(): Pair<String?, String> {
    val message = this?.message() ?: SOMETHING_WENT_WRONG
    return try {
        if (this?.errorBody()?.charStream() == null)
            return Pair(null, message)
        val errorResponse = Gson().fromJson(this.errorBody()?.charStream(), ForwardErrorResponse::class.java)
        when {
            errorResponse.errors.exceptionResponse.isNotEmpty() ->
                Pair(
                    errorResponse.errors.exceptionResponse.first().code,
                    errorResponse.errors.exceptionResponse.first().description
                )

            errorResponse.errors.errorMessage.isNotEmpty() ->
                Pair(null, errorResponse.errors.errorMessage)

            else -> Pair(null, message)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Pair(null, message)
    }
}

fun Fragment.disableTouch() {
    activity?.window?.setFlags(
        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    )
}

fun Fragment.enableTouch() {
    activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
}