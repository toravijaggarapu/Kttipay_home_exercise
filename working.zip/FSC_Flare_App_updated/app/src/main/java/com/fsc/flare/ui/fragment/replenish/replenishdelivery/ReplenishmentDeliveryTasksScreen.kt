package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.ReplenDeliveryTaskBinding
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.repository.REPLENISH_DELIVERY_TASK_TYPE
import com.fsc.flare.ui.fragment.receiving.CASE
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import com.fsc.flare.utils.observeFlowOnUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.filterNotNull
import javax.inject.Inject

@AndroidEntryPoint
class ReplenishmentDeliveryTasksScreen : BaseFragment() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var binding: ReplenDeliveryTaskBinding
    private val viewModel: ReplenishmentDeliveryTasksViewModel by viewModels()
    private val sharedViewModel: ReplenishmentDeliverySharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = ReplenDeliveryTaskBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Set the header title
        binding.tvHeaderTitle.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)

        binding.btSkip.setOnClickListener {
            sharedViewModel.task?.let {
                viewModel.skipTask(
                    taskId = it.taskId ?: -1,
                    taskDetailId = it.taskDetId ?: -1
                )
            }
        }

        binding.btAccept.setOnClickListener {
            val action = ReplenishmentDeliveryTasksScreenDirections.actionTaskScreenToContainerScanScreen()
            findNavController().navigate(action)
        }

        observeFlowOnUI { observeScreenState() }

        sharedViewModel.task?.let {
            updateTaskUI(it)
        } ?: run {
            binding.grpPriority.visibility = View.GONE
            binding.grpTaskContent.visibility = View.GONE
            binding.grpBottomButtons.visibility = View.GONE
            viewModel.getTask()
        }
    }

    private suspend fun observeScreenState() {
        viewModel.taskScreenState.filterNotNull().collect { state ->
            when (state) {
                ReplenishmentDeliveryTasksState.ShowLoading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    disableTouch()
                }

                ReplenishmentDeliveryTasksState.HideLoading -> {
                    binding.progressBar.visibility = View.GONE
                    enableTouch()
                }

                is ReplenishmentDeliveryTasksState.SuccessTask -> {
                    updateTaskUI(state.task)
                }

                is ReplenishmentDeliveryTasksState.GetTaskError -> {
                    showErrorSnackBarStd(state.message ?: getString(R.string.lbl_something_went_wrong)) {
                        findNavController().popBackStack()
                    }
                }

                is ReplenishmentDeliveryTasksState.SkipTaskError -> {
                    showErrorSnackBar(state.message ?: getString(R.string.lbl_something_went_wrong))
                }
            }
        }
    }

    private fun updateTaskUI(task: ReplenishDeliveryTask) {
        binding.grpTaskContent.visibility = View.VISIBLE
        binding.grpBottomButtons.visibility = View.VISIBLE
        sharedViewModel.task = task
        binding.tvTaskNumber.text = "${task.taskId}"
        binding.tvTaskType.text =
            if (task.taskType == REPLENISH_DELIVERY_TASK_TYPE)
                getString(R.string.replenishment_delivery)
            else
                task.taskType
        binding.tvFromLocation.text = task.locationBarcode
        binding.tvDeliveryLocation.text = task.destLocationBarcode
        binding.tvPalletOrContainerTitle.text =
            if (task.taskContainer == CASE)
                getString(R.string.lbl_container_colon)
            else
                getString(R.string.lbl_pallet_colon)
        binding.tvPalletOrContainer.text = task.containerNbr
        if (!task.priority.isNullOrEmpty()) {
            binding.grpPriority.visibility = View.VISIBLE
            binding.tvPriority.text = task.priority
        } else {
            binding.grpPriority.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.clearScreenState()
    }
}