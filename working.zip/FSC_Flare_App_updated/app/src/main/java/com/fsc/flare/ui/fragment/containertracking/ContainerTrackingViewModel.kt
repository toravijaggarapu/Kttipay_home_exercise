package com.fsc.flare.ui.fragment.containertracking

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailResBase
import com.fsc.flare.source.data.dto.containertracking.screenconfig.ScreenConfigBaseRes
import com.fsc.flare.source.data.dto.containertracking.screenconfig.ScreenConfigReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseRes
import com.fsc.flare.source.repository.ContainerTrackingRepository
import com.fsc.flare.utils.NetworkConnectionInterceptor
import com.fsc.flare.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

private const val TAG = "ContainerTrackingViewMo"

@HiltViewModel
class ContainerTrackingViewModel @Inject constructor(
    private val containerTrackingRepository: ContainerTrackingRepository
) : BaseViewModel() {
    val containerTrackingRes: MutableLiveData<Resource<GetContDetailResBase>> = MutableLiveData()
    val screenConfigRes: MutableLiveData<Resource<ScreenConfigBaseRes>> = MutableLiveData()
    val containerTrackingSubmitRes: MutableLiveData<Resource<SendContainerTrackingBaseRes>> = MutableLiveData()
    val noNetworkUpdate: MutableLiveData<String> = MutableLiveData()

    fun getContTracking(getContDetailRequest: GetContDetailRequest) = viewModelScope.launch {
        FlareLog.i(TAG, "getContTracking Request: $getContDetailRequest")
        try {
            containerTrackingRes.postValue(Resource.Loading())
            val response = containerTrackingRepository.getContTracking(getContDetailRequest)
            containerTrackingRes.postValue(handleContainerTrackingRes(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun getScreenConfig(screenConfigReq: ScreenConfigReq) = viewModelScope.launch {
        FlareLog.i(TAG, "getScreenConfig Request: $screenConfigReq")
        try {
            screenConfigRes.postValue(Resource.Loading())
            val response = containerTrackingRepository.getScreenConfig(screenConfigReq)
            screenConfigRes.postValue(handleScreenConfigRes(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    fun sendContainerTracking(sendContainerTrackingBaseReq: SendContainerTrackingBaseReq) = viewModelScope.launch {
        FlareLog.i(TAG, "sendContainerTracking Request: $sendContainerTrackingBaseReq")
        try {
            containerTrackingSubmitRes.postValue(Resource.Loading())
            val response = containerTrackingRepository.sendContainerTracking(sendContainerTrackingBaseReq)
            containerTrackingSubmitRes.postValue(handleSendContainerTrackingSubmitRes(response))
        } catch (e: Exception) {
            FlareLog.e("Connection Issue", e.message.toString())
            if (e is NetworkConnectionInterceptor.NoConnectivityException) {
                Log.d("No Network", "Connection issue")
                noNetworkUpdate.postValue("No Network")
            }
        }
    }

    private fun handleSendContainerTrackingSubmitRes(response: Response<SendContainerTrackingBaseRes>): Resource<SendContainerTrackingBaseRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "sendContainerTracking success response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "sendContainerTracking Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

    private fun handleScreenConfigRes(response: Response<ScreenConfigBaseRes>): Resource<ScreenConfigBaseRes>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ScreenConfig success response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ScreenConfig Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }


    private fun handleContainerTrackingRes(response: Response<GetContDetailResBase>): Resource<GetContDetailResBase>? {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                FlareLog.i(TAG, "ContainerTracking success response : $resultResponse")
                return Resource.Success(resultResponse)
            }
        } else {
            val errorResponse = handleForwardErrorResponse(response.code(), response.errorBody(), response.message())
            FlareLog.e(TAG, "ContainerTracking Error Response: $errorResponse")
            return Resource.Error(errorResponse)
        }
        return null
    }

}