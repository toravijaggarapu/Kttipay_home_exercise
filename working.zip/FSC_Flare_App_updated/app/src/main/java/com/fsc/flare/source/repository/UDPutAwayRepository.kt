package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawayContainerRequest
import com.fsc.flare.source.data.dto.userdirectedputaway.UserDirectedPutawaySubmitRequest
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UDPutAwayRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {

    suspend fun validateContainer(userDirectedPutawayContainerRequest: UserDirectedPutawayContainerRequest) =
        apiGatewayInterface.validateContainerPutawayUserDirected(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = userDirectedPutawayContainerRequest.custId,
            buId = userDirectedPutawayContainerRequest.buId,
            fcyId = userDirectedPutawayContainerRequest.fcyId,
            containerNumber = userDirectedPutawayContainerRequest.containerNumber,
            putAwayType = userDirectedPutawayContainerRequest.putAwayType,
            userDirected = true,
            containerType = userDirectedPutawayContainerRequest.containerType,
            includeCCLocation = userDirectedPutawayContainerRequest.includeCCLocation,
            recallLockExists = userDirectedPutawayContainerRequest.recallLockExists
        )

    suspend fun validateLocation(locationClassReq: LocationClassReq) = apiGatewayInterface.validateLocation(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = locationClassReq.facility,
        barcode = locationClassReq.barcode,
        locationClass = locationClassReq.locationClass
    )

    suspend fun submitUserdirectedPutaway(userDirectedPutawaySubmitRequest: UserDirectedPutawaySubmitRequest) =
        apiGatewayInterface.submitUserDirectedPutaway(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            requestBody = userDirectedPutawaySubmitRequest
        )

    suspend fun getTransactionParam(transactionParamRequest: TransactionParamRequest) = apiGatewayInterface.validateTransactionParam(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = transactionParamRequest.cust_id,
        buId = transactionParamRequest.bu_id,
        fcyId = transactionParamRequest.fcy_id,
        transCode = transactionParamRequest.trans_code
    )

    suspend fun getContainerDetails(containerNum: String) = apiGatewayInterface.getContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNumber = containerNum,
        itemInfo = "Y"
    )

}