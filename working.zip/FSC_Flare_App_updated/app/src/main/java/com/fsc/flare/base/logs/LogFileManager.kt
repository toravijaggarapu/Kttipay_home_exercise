package com.fsc.flare.base.logs

import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.Constants
import org.joda.time.DateTime
import org.joda.time.Days
import java.io.File
import javax.inject.Inject

class LogFileManager @Inject constructor() {
    private val logFilesDirectory: File
        get() = File(FlareLog.logFilesDirectory!!)
    private val allLogFiles: List<File>
        get() = ArrayList(listOf(*logFilesDirectory.listFiles()!!))
    val logFilesToUpload: List<File>
        get() {
            val filesToUpload: MutableList<File> = ArrayList()
            for (file in allLogFiles) {
                if (!file.name.contains(UPLOAD_SUCCEEDED_FILE_KEY)) {
                    filesToUpload.add(file)
                }
            }
            return filesToUpload
        }

    fun updateFilesToSuccess(files: List<File>) {
        val now = DateTime.now()
        for (file in files) {
            if (file.name.contains(UPLOAD_SUCCEEDED_FILE_KEY)) {
                //Already uploaded? Concerning.
                FlareLog.i(LOG_TAG, "Log file " + file.name + " was already uploaded?")
            } else if (file.name.contains(UPLOAD_FAILED_FILE_KEY)) {
                //Rename failed to uploaded - TODO only affects versions prior to 17.1.0 that specified this
                val newFileName = file.name.replace("failed", "_uploaded_$now")
                renameFile(file, File(logFilesDirectory.toString() + File.separator + newFileName))
            } else {
                //Append _uploaded_timestamp to original file name
                val postfix = String.format(
                    "_%s_%s.txt", UPLOAD_SUCCEEDED_FILE_KEY, now.toString(
                        Constants.DATE_HOUR_MINUTE_FORMAT
                    )
                )
                val newFileName = file.name.replace(".txt", postfix)
                renameFile(file, File(logFilesDirectory.toString() + File.separator + newFileName))
            }
        }
    }

    private fun renameFile(file: File, file2: File) {
        if (file.renameTo(file2)) {
            FlareLog.i(LOG_TAG, "Renamed " + file.name + " to " + file2.name)
        } else {
            FlareLog.i(LOG_TAG, "Failed to rename " + file.name + " to " + file2.name)
        }
    }

    fun deleteFilesOlderThan15Days() {
        val logFiles = allLogFiles
        val now = DateTime.now()
        for (file in logFiles) {
            val fileDateTime = DateTime(file.lastModified())
            if (Days.daysBetween(fileDateTime, now).days > 15) {
                val deleted = file.delete()
                if (deleted) {
                    FlareLog.i(LOG_TAG, "Deleted old file: " + file.name)
                } else {
                    FlareLog.i(LOG_TAG, "Failed to delete old file: " + file.name)
                }
            }
        }
    }

    companion object {
        const val LOG_FILE_NAME = "Flare"
        const val LOG_DIRECTORY = "/Logs/"
        const val UPLOAD_FAILED_FILE_KEY = "failed"
        const val UPLOAD_SUCCEEDED_FILE_KEY = "uploaded"
        private const val LOG_TAG = "LogFileManager"
    }
}