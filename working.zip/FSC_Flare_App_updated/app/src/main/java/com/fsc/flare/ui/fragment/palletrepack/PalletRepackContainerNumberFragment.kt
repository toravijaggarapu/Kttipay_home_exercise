package com.fsc.flare.ui.fragment.palletrepack

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentRepackContainerNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.masterpalletrepack.MasterPalletRepackTempContainerResponse
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletRepackContainerNumber"

/**
 * A simple [PalletRepackContainerNumberFragment]
 */
@AndroidEntryPoint
class PalletRepackContainerNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: PalletRepackViewModel by activityViewModels()
    private lateinit var binding: FragmentRepackContainerNumberBinding
    var etContainer = ""

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        binding.btnEndPallet.isEnabled = viewModel.containerInfo.size > 0

        super.onResume()
        cb1.onVisibilityChange(true)

    }



    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRepackContainerNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvPalletNumber.text = viewModel.getPalletData().palletNumber
        if (viewModel.getMPRTransactionParamData() != null) {
            if (viewModel.getTransactionParamByTransCode("AGCN"))
                binding.btnNewContainer.visibility = View.VISIBLE
            else
                binding.btnNewContainer.visibility = View.GONE
        }
        binding.containerNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerNumberResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        if (viewModel.containerInfo.isEmpty()) {
            viewModel.validateTempTablePallet(viewModel.getPalletData().palletNumber, "")
        }

        binding.containerNumber.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.containerNumber)
                FlareLog.i(TAG, "Container field focused")
                validateContainer()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    validateContainer()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.btnNewContainer.setOnClickListener {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            FlareLog.i(TAG, "Container field focused")
            getNewContainerNumber()
        }

        binding.btnEndPallet.setOnClickListener {
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            navigateDestinationLocationView()
        }
    }

    /**
     * method to generate container from API
     */
    private fun getNewContainerNumber() {
        //Call new container API.
        viewModel.generatePalletCaseNumber(viewModel.newCaseNumberKey)
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        viewModel.containerDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            binding.containerNumber.requestFocus()
                            binding.containerNumberResponse.text = getString(R.string.master_pallet_repack_container_exists)
                            binding.containerNumber.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.containerNumber)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    //In error check the pallet number is in temporary table or not by API
                    etContainer = binding.containerNumber.text.toString().trim()
                    viewModel.validateTempTable(viewModel.getPalletData().palletNumber, etContainer)
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //Get temp table data for pallet only
        viewModel.masterPalletRepackTempPalletResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            val containersList = containerResponse.tempLpn!!.containerDetails
                            if (containersList != null) {
                                viewModel.setTempTableTransactionIdentifier(containerResponse.tempLpn!!.transactionIdentifier)
                                binding.btnEndPallet.isEnabled = true
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //Get temp table data
        viewModel.masterPalletRepackTempContainerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        if (containerResponse.success) {
                            viewModel.setTempTableData(containerResponse)
                            if (etContainer.isNotEmpty()) {
                                viewModel.setTempTableTransactionIdentifier(containerResponse.tempLpn!!.transactionIdentifier)
                                // Save values to display in location screen
                                val palletData = viewModel.getPalletData()
                                palletData.palletNumber = containerResponse.tempLpn!!.palletNumber!!
                                val containersList = containerResponse.tempLpn!!.containerDetails
                                viewModel.setItem(containerResponse.tempLpn!!.itemId!!)
                                if (containersList != null) {
                                    viewModel.setSerialNumbers(containersList)
                                    binding.btnEndPallet.isEnabled = true
                                    viewModel.saveContainerNumber(binding.containerNumber.text.toString())
                                    palletData.palletQty = viewModel.getPalletQuantity(containersList)
                                    palletData.noOfContainer = containersList.size
                                    palletData.itemCode = containerResponse.tempLpn!!.itemCode!!
                                    palletData.itemDesc = containerResponse.tempLpn!!.itemDescription!!


                                    val list = hashMapOf<String, MasterPalletRepackTempContainerResponse.ContainerDetailsEntity>()
                                    for (container in containersList) {
                                        if (!list.contains(container.containerNumber)) {
                                            list[container.containerNumber!!] = container
                                        }
                                    }

                                    if (list.size > 0) {
                                        if (viewModel.getTransactionParamByTransCode("IUU")) {
                                            if (list.contains(etContainer)) {
                                                val data = list[etContainer]

                                                if (data!!.containerQty < data.maxEaches) {
                                                    palletData.containerNumber = data.containerNumber!!
                                                    palletData.quantity = data.containerQty
                                                    viewModel.saveContainerSerialNumbers(data.serialNumbers)
                                                    navigateEndPalletView()
                                                    return@observe
                                                } else if (containersList.size == data.maxCase) {
                                                    maxPalletReachAlert()
                                                }
                                                // Entered container have the enough eaches then prompt error
                                                else if (data.containerNumber == etContainer && data.containerQty == data.maxEaches) {
                                                    binding.containerNumber.requestFocus()
                                                    binding.containerNumberResponse.text = getString(R.string.master_pallet_repack_container_exists)
                                                    binding.containerNumber.selectAll()
                                                    showSoftKeyBoard(fragmentContext, binding.containerNumber)
                                                    return@observe
                                                }
                                            } else {
                                                val data = containersList[0]

                                                if (containersList.size < data.maxCase) {
                                                    palletData.containerNumber = etContainer
                                                    palletData.quantity = 0
                                                    viewModel.saveContainerSerialNumbers(arrayListOf())
                                                    navigateEndPalletView()
                                                    return@observe
                                                } else if (containersList.size == data.maxCase) {
                                                    maxPalletReachAlert()
                                                }
                                            }
                                        } else {
                                            if (list.contains(etContainer)) {
                                                val data = list[etContainer]
                                                palletData.containerNumber = data!!.containerNumber!!
                                                palletData.quantity = data.containerQty
                                                viewModel.saveContainerSerialNumbers(data.serialNumbers)
                                                navigateEndPalletView()
                                                return@observe
                                            } else {
                                                palletData.containerNumber = etContainer
                                                palletData.quantity = 0
                                                viewModel.saveContainerSerialNumbers(arrayListOf())
                                                navigateEndPalletView()
                                                return@observe
                                            }
                                        }
                                    } else {
                                        updatePalletData()
                                        navigateEndPalletView()
                                        return@observe
                                    }
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    if (response.message != null && response.message == "Container Record Not Found") {
                        updatePalletData()
                        navigateEndPalletView()
                    } else {
                        binding.containerNumber.requestFocus()
                        binding.containerNumberResponse.text = response.message
                        binding.containerNumber.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.containerNumber)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        //New container generate response
        viewModel.newPalletDetailResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { generatePalletCaseNumberResponse ->
                        if (generatePalletCaseNumberResponse.success) {
                            //Save the Pallet number.
                            for (palletValue in generatePalletCaseNumberResponse.numbers) {
                                if (palletValue.type != viewModel.palletTransferTypeKey) {
                                    val palletData = viewModel.getPalletData()
                                    palletData.containerNumber = palletValue.value
                                    palletData.quantity = 0
                                    etContainer = palletValue.value
                                    viewModel.validateTempTable(viewModel.getPalletData().palletNumber, etContainer)
                                    break
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        viewModel.masterPalletRepackTempPostResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { tempTableSubmitResponse ->
                        if (tempTableSubmitResponse.success) {
                            viewModel.setTempTableTransactionIdentifier(tempTableSubmitResponse.tempLpn!!.transactionIdentifier)
                            val palletData = viewModel.getPalletData()
                            palletData.palletNumber = tempTableSubmitResponse.tempLpn!!.palletNumber!!
                            val containersList = tempTableSubmitResponse.tempLpn!!.containerDetails
                            if (containersList != null) {
                                viewModel.setSerialNumbers(containersList)
                                palletData.palletQty = viewModel.getPalletQuantity(containersList)
                                palletData.noOfContainer = containersList.size
                                palletData.itemCode = tempTableSubmitResponse.tempLpn!!.itemCode!!
                                palletData.itemDesc = tempTableSubmitResponse.tempLpn!!.itemDescription!!
                            }

                            navigateDestinationLocationView()
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        showCustomDialog(message) {}
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun updatePalletData() {
        val palletData = viewModel.getPalletData()
        palletData.containerNumber = etContainer
        palletData.itemCode = ""
        palletData.itemDesc = ""
        palletData.quantity = 0
        viewModel.saveContainerSerialNumbers(arrayListOf())
    }

    /**
     * method to validate container from API
     */
    private fun validateContainer() {
        if (!binding.containerNumber.text.isNullOrEmpty()) {
            val containerType = viewModel.validateContainerType(sharedPreferences, "Carton")
            val containerNumber = binding.containerNumber.text.toString()
            if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.containerNumberResponse.text =
                    getString(R.string.container_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                viewModel.validateContainerDetail(containerNumber, viewModel.containerDetailKey)
            }
        }
    }

    private fun navigateEndPalletView() {
        binding.containerNumber.text = null
        val action = PalletRepackContainerNumberFragmentDirections.actionPalletRepackContainerFragmentToPalletRepackEndFragment()
        getNavigationController().navigate(action)
    }

    private fun navigateDestinationLocationView() {
        val action = PalletRepackContainerNumberFragmentDirections.actionPalletRepackContainerFragmentToPalletRepackDestLocationFragment()
        getNavigationController().navigate(action)
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.containerNumber.setText(scan?.barcode.toString())
                binding.containerNumber.text?.length?.let {
                    binding.containerNumber.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container field focused")
                    validateContainer()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun maxPalletReachAlert() {
        showAlertDialog(
            "",
            getString(R.string.master_pallet_repack_pallet_reached_max_qty),
            getString(R.string.button_continue),
            getString(R.string.alert_button_cancel),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    navigateDestinationLocationView()
                }

                override fun onNegativeButtonClick() {

                }
            })
    }
}