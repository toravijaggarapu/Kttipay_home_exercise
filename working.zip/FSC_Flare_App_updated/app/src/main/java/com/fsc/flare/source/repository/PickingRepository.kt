package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.picking.*
import com.fsc.flare.utils.PreferenceKeys
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PickingRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) {
    suspend fun getWeightReq(url: String) =
        apiGatewayInterface.getWeightReq( url,
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        )

    suspend fun isValidBlReq(pickingValidateBlRequest: PickingValidateBlRequest) =
        apiGatewayInterface.isValidBL(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            pickingValidateBlRequest = pickingValidateBlRequest
        )

    suspend fun isValidLocationReq(pickingValidateLocationRequest: PickingValidateLocationRequest) =
        apiGatewayInterface.isValidLocation(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            pickingValidateLocationRequest = pickingValidateLocationRequest
        )

    suspend fun isValidContainerIdReq(pickingValidateContainerIdRequest: PickingValidateContainerIdRequest) =
        apiGatewayInterface.isValidContainerId(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            pickingValidateContainerIdRequest = pickingValidateContainerIdRequest
        )

    suspend fun isValidPickSubmitReq(pickingSubmitRequest: PickingSubmitRequest) =
        apiGatewayInterface.isValidToDoPick(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            pickingSubmitRequest = pickingSubmitRequest
        )

    suspend fun isValidLocationTo(pickingLocationToRequest: PickingLocationToRequest) =
        apiGatewayInterface.isValidLocationTo(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            pickingLocationToRequest = pickingLocationToRequest
        )
}