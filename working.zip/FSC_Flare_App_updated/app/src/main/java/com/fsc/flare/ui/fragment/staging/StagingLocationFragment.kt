package com.fsc.flare.ui.fragment.staging

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentStagingLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.pickingforward.req.LocationClassReq
import com.fsc.flare.source.data.dto.staging.StagingPalletLocationRequest
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.disableTouch
import com.fsc.flare.utils.enableTouch
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "StagingLocationFragment"
private const val ORDER_SEARCH_ENTITY = "O"

@AndroidEntryPoint
class StagingLocationFragment : BaseFragment(), FlareScannable {

    private val viewModel: StagingViewModel by activityViewModels()
    private lateinit var binding: FragmentStagingLocationBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    @Inject
    lateinit var alertHandler: AlertHandler
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStagingLocationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.caseCount.text = viewModel.casesInPallet.toString()
        val containerRes = viewModel.getContainerResponse()
        if(containerRes!=null){
            if(!containerRes.shipmentStageLoc.isNullOrEmpty()){
                binding.tvShipmentStageLocationValue.text = containerRes.shipmentStageLoc
            }
            if(!containerRes.currentStageLoc.isNullOrEmpty()){
                binding.tvCurrentStageLocationValue.text = containerRes.currentStageLoc
            }
            if (!containerRes.orderNumber.isNullOrEmpty()) {
                binding.orderLayout.visibility = View.VISIBLE
                binding.tvOrderNumberValue.text = containerRes.orderNumber
            } else {
                binding.orderLayout.visibility = View.GONE
            }
        }
        //display previously captured carton/pallet number
        binding.tvPalletNumberValue.text = sharedPreferences.getString(PreferenceKeys.STAGING_PALLET_NUMBER, "")

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etStagingLocation.isFocused && !binding.etStagingLocation.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Location field focused")
                        validateStagingLocation()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etStagingLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                FlareLog.i(TAG, "Location field focused")
                validateStagingLocation()
            }
            false
        }

        binding.etStagingLocation.doAfterTextChanged {
            binding.tvStagingLocationResponse.text = null
        }

        binding.btnPrint.setOnClickListener { validateInputForPrinting() }
        binding.btnStageNextPallet.setOnClickListener { redirectForStateNextPallet() }
    }

    /**
     * method to validate staging location from API
     */
    private fun validateStagingLocation() {
        viewModel.validateStagingLocation(
            LocationClassReq(
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                binding.etStagingLocation.text.toString(),
                "S"
            )
        )
    }

    /**
     * method to call stageLocation API
     */
    private fun callValidateStageLocationAPI(locationId: Int) {
        viewModel.validatePalletStagingLocation(
            StagingPalletLocationRequest(
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                palletId = sharedPreferences.getInt(PreferenceKeys.STAGING_PALLET_ID, -1),
                palletNumber = sharedPreferences.getString(PreferenceKeys.STAGING_PALLET_NUMBER, "").toString(),
                stageLocId = locationId
            )
        )
    }

    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeStagingLocationObserver()
        subscribeStagingPalletLocationObserver()
        subscribePrintDetailsObserver()
        subscribePrintRequesterObserver()
        subscribeInternationalDocumentsObserver()
    }

    private fun subscribeInternationalDocumentsObserver() {
        viewModel.printInternationalDocumentResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Error -> {
                    hideProgressBar()
                    showErrorSnackBar(getString(R.string.do_you_want_to_retry, response.message ?: getString(R.string.lbl_something_went_wrong)))
                }

                is Resource.Loading -> {
                    showProgressBar()
                }

                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data != null && response.data.status == true) {
                        FlareLog.i(TAG, "PrintInternationalDocumentsResponse success: ${response.data}")
                        disableTouch()
                        showSuccessSnackBarStd(response.data.responseMessage) {
                            enableTouch()
                            redirectForStateNextPallet()
                        }
                    } else {
                        showErrorSnackBar(getString(R.string.do_you_want_to_retry, response.data?.errorDescription ?: getString(R.string.lbl_something_went_wrong)))
                    }
                }
            }
        }
    }

    private fun subscribePrintDetailsObserver() {
        viewModel.printInputResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data != null && response.data.success) {
                        FlareLog.i(TAG, "printInputResponse success: ${response.data}")
                        viewModel.setInput(response.data)
                        if (response.data.internationalShipDocsRequired == true) {
                            getPrintRequesterList()
                        } else {
                            showErrorSnackBar(getString(R.string.do_you_want_to_retry, getString(R.string.failed_to_print_documents)))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    showErrorSnackBar(getString(R.string.do_you_want_to_retry, response.message ?: getString(R.string.lbl_something_went_wrong)))
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe print requester observer
     */
    private var printRequester = ""

    private fun subscribePrintRequesterObserver() {
        viewModel.printRequestorResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data?.printerConfigs?.isNotEmpty() == true) {
                        viewModel.setPrintConfigs(response.data.printerConfigs)
                        alertHandler.showPrintRequesterDialog(false, response.data.printerConfigs.map { it.requestor } ) { printRequester ->
                            this.printRequester = printRequester
                            viewModel.printInternationalDocuments(printRequester)
                        }
                    } else {
                        showErrorSnackBar(getString(R.string.do_you_want_to_retry, getString(R.string.no_print_requester_found)))
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    showErrorSnackBar(getString(R.string.do_you_want_to_retry, response.message ?: getString(R.string.lbl_something_went_wrong)))
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to subscribe staging location observer
     */
    private fun subscribeStagingLocationObserver() {
        viewModel.stagingLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    if (response.data != null && response.data.success) {
                        FlareLog.i(TAG, "stagingLocationResponse success: ${response.data}")
                        if (response.data.locations.isNotEmpty()) {
                            callValidateStageLocationAPI(response.data.locations.firstOrNull()?.locationId ?: 0)
                        } else {
                            binding.tvStagingLocationResponse.text = resources.getString(R.string.invalid_location)
                            binding.etStagingLocation.requestFocus()
                            binding.etStagingLocation.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe observer for stagingPalletLocation response
     */
    private fun subscribeStagingPalletLocationObserver() {
        viewModel.stagingPalletLocationResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { stagingPalletLocationResponse ->
                        if (stagingPalletLocationResponse.success) {
                            FlareLog.i(TAG, "stagingLocationResponse success: $stagingPalletLocationResponse")
                            showSuccessSnackBarStd(stagingPalletLocationResponse.message) {
                                // check if all pallets are staged the shipment and it's internation shipment.  If yes we need to Print the International shipping documents
                                when {
                                    stagingPalletLocationResponse.stagedIntlShipment != null && viewModel.getContainerResponse()?.orderNumber != null &&
                                            stagingPalletLocationResponse.stagedIntlShipment.allPalletsStaged &&
                                            stagingPalletLocationResponse.stagedIntlShipment.intlShipment -> {
                                        binding.grpInternationalShipment.visibility = View.VISIBLE
                                        binding.tvStagingLocationResponse.text = null
                                        binding.etStagingLocation.isEnabled = false
                                        binding.etStagingLocation.alpha = 0.4f
                                        disableDeviceBack()
                                        displayPrintConfirmationForInternationalShipments(getString(R.string.international_shipment_desc))
                                    }
                                    else -> {
                                        redirectForStateNextPallet()
                                    }
                                }
                            }
                        } else {
                            FlareLog.e(TAG, "stagingPalletLocationResponse error: ${stagingPalletLocationResponse.errors.errorMessage}")
                            binding.tvStagingLocationResponse.text = stagingPalletLocationResponse.errors.errorMessage
                            binding.etStagingLocation.requestFocus()
                            binding.etStagingLocation.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.etStagingLocation)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "stagingPalletLocationResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        enableTouch()
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        disableTouch()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)

        if (isProgressBarVisible()) return

        binding.etStagingLocation.setText(scan?.barcode.toString())
        binding.etStagingLocation.text?.length?.let {
            binding.etStagingLocation.setSelection(it)
            FlareLog.i(TAG, "Location field focused")
            validateStagingLocation()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = it
            it.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

    private fun displayPrintConfirmationForInternationalShipments(infoMessage: String) {
        alertHandler.showFlareConfirmationAlert(
            message = infoMessage,
            positiveButtonTitle = getString(R.string.stage_next_pallet),
            negativeButtonTitle = getString(R.string.print_docs),
            positiveCallBack = { redirectForStateNextPallet() },
            negativeCallBack = { validateInputForPrinting() }
        )
    }

    private fun getPrintRequesterList() {
        viewModel.getPrintRequesterList(
            PrinterConfigRequest(
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                page = 0,
                pageLimit = 100,
                printerType = "DOC"
            )
        )
    }

    private fun validateInputForPrinting() {
        val containerRes = viewModel.getContainerResponse()
        viewModel.validateInputForPrinting(
            ValidateInputRequest(
                ORDER_SEARCH_ENTITY,
                containerRes?.orderNumber.orEmpty(),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            )
        )
    }

    private fun redirectForStateNextPallet() {
        viewModel.setContainerResponse(null)
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.StagingPalletFragment, true).build()
        findNavController().navigate(R.id.action_stagingLocation_to_stagingPalletFragment, null, navOptions)
    }

    private fun disableDeviceBack() {
        // Hide the action bar back button
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            // With blank your fragment BackPressed will be disabled.
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Show the action bar back button when leaving the fragment
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
}