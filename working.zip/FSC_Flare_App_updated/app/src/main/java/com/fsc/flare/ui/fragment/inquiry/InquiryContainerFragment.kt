package com.fsc.flare.ui.fragment.inquiry

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInquiryContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InquiryConFragment"

/**
 * A simple [InquiryContainerFragment] class.
 */
@AndroidEntryPoint
class InquiryContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInquiryContainerBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentInquiryContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        subscribeObservers()
        binding.container.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateField()
            }
            false
        }
        binding.container.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.containerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun validateField() {
        hideSoftKeyBoard(fragmentContext, binding.rootLayout)
        if (binding.container.isFocused && !binding.container.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "com.fsc.flare.source.data.dto.inventoryadjustment.res.Container field focused")
            viewModel.getItemsInContainer(binding.container.text.toString())
        }
    }

    private fun subscribeObservers() {
        viewModel.containerResponse.observe(viewLifecycleOwner) { containerInquiryResponse ->
            when (containerInquiryResponse) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "container success: $containerInquiryResponse")
                    hideProgressBar()
                    containerInquiryResponse.data?.let { containerResponse ->
                        viewModel.setItem(containerResponse)
                        binding.container.text = null
                        val navController =
                            Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                        val action =
                            InquiryContainerFragmentDirections.actionInquiryContainerToInquiryContainerDesc()
                        navController.navigate(action)
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    containerInquiryResponse.message?.let { message ->
                        binding.containerResponse.text = message
                        FlareLog.e(TAG, "container error: $message")
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG,"onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.container.setText(scan?.barcode.toString())
            binding.container.text?.length?.let {
                binding.container.setSelection(
                    it
                )
            }
            FlareLog.i(TAG, "com.fsc.flare.source.data.dto.inventoryadjustment.res.Container field focused")
            viewModel.getItemsInContainer(binding.container.text.toString())
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG,"onScanError: $scanRaw")
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}