package com.fsc.flare.ui.fragment.loadunloadtrailer.unloadtrailer

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentUnloadTrailerNumberBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.loadunloadtrailer.LoadTrailerRequest
import com.fsc.flare.source.data.dto.loadunloadtrailer.UnloadTrailerResponse
import com.fsc.flare.ui.fragment.loadunloadtrailer.LoadUnloadViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

private val TAG = UnloadTrailerNumberFragment::class.java.simpleName.toString()
private const val PALLET_UNLOAD_SUCCESS_MSG_CODE = "PALLET_UNLOAD_SUCCESS"
@AndroidEntryPoint
class UnloadTrailerNumberFragment : BaseFragment(), FlareScannable {

    private val viewModel: LoadUnloadViewModel by activityViewModels()
    private lateinit var binding: FragmentUnloadTrailerNumberBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentUnloadTrailerNumberBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.etTrailerNumber.requestFocus()
        subscribeObservers()
        handleTouchAndFocusEvents()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleTouchAndFocusEvents() {
        with(binding) {
            rootLayout.setOnTouchListener { v, event ->
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        hideSoftKeyBoard(fragmentContext, rootLayout)
                        if (etTrailerNumber.isFocused && !etTrailerNumber.text.isNullOrEmpty()) {
                            FlareLog.i(TAG, "TrailerNumber field focused")
                            validateTrailerNumber()
                        }
                    }
                }
                v?.onTouchEvent(event) ?: return@setOnTouchListener true
            }

            etTrailerNumber.setOnEditorActionListener { _, actionId, event ->
                if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                    hideSoftKeyBoard(fragmentContext, etTrailerNumber)
                    FlareLog.i(TAG, "TrailerNumber field focused")
                    validateTrailerNumber()
                }
                return@setOnEditorActionListener false
            }

            etTrailerNumber.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    tvTrailerNumberResponse.text = null
                }

                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val dockDoorShipmentData = viewModel.dockDoorShipment
        dockDoorShipmentData?.let {
            binding.tvShipmentNumberValue.text = it.shipmentNumber
            binding.tvTrailerNumberValue.text = it.trailerNbr
            binding.tvTotalStopValue.text = it.totalStops.toString()
        }
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    /**
     * Function to validate Trailer Number
     */
    private fun validateTrailerNumber() {
        val trailerNumberInput = binding.etTrailerNumber.text.toString()
        val trailerNumberValue = binding.tvTrailerNumberValue.text.toString()
        val shipmentNumberValue = binding.tvShipmentNumberValue.text.toString()

        when {
            trailerNumberInput != trailerNumberValue -> {
                handleTrailerNumberMismatch()
            }
            shipmentNumberValue.isEmpty() -> {
                handleShipmentNumberNotAvailable()
            }
            else -> {
                callUnloadTrailerAPI()
            }
        }
    }

    /**
     * Function to handle trailer number mismatch
     */
    private fun handleTrailerNumberMismatch() {
        binding.tvTrailerNumberResponse.text = getString(R.string.trailer_number_mismatch)
        binding.etTrailerNumber.requestFocus()
        binding.etTrailerNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etTrailerNumber)
    }

    /**
     * Function to handle shipment number not available
     */
    private fun handleShipmentNumberNotAvailable() {
        binding.tvTrailerNumberResponse.text = getString(R.string.shipment_number_not_available)
    }

    /**
     * Function to call load trailer api with shipmentId
     */
    private fun callUnloadTrailerAPI() {
        val dockDoorShipmentData = viewModel.dockDoorShipment
        dockDoorShipmentData?.let {
            viewModel.unloadTrailer(
                LoadTrailerRequest(
                    buId = sharedPreferencesBase.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    custId = sharedPreferencesBase.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferencesBase.getInt(PreferenceKeys.FACILITY_ID, -1).toLong(),
                    shipmentId = dockDoorShipmentData.shipmentId
                )
            )
        }
    }

    /**
     * Function to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeUnloadTrailerObserver()
    }

    /**
     * Function to subscribe load trailer observer
     */
    private fun subscribeUnloadTrailerObserver() {
        viewModel.unloadTrailerResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleSuccessResponse(response.data)
                is Resource.Error -> handleErrorResponse(response.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    /**
     * Function to process load trailer success response
     */
    private fun handleSuccessResponse(data: UnloadTrailerResponse?) {
        hideProgressBar()
        data?.let { unloadTrailerResponse ->
            if (unloadTrailerResponse.success) {
                handleSuccessfulLoadTrailerResponse(unloadTrailerResponse)
            } else {
                handleFailedLoadTrailerResponse(unloadTrailerResponse)
            }
        }
    }

    /**
     * Function to handle load trailer response object
     */
    private fun handleSuccessfulLoadTrailerResponse(unloadTrailerResponse: UnloadTrailerResponse) {
        when {
            unloadTrailerResponse.messageCode == PALLET_UNLOAD_SUCCESS_MSG_CODE -> {
                showSuccessSnackBarStd(unloadTrailerResponse.message) {
                    navigateToUnloadDockDoorFragment()
                }
            }
            unloadTrailerResponse.shipmentNumber == null -> {
                showErrorSnackBar(getString(R.string.lbl_shipment_details_not_available))
            }
            else -> {
                viewModel.unloadTrailer = unloadTrailerResponse
                navigateToUnloadCartonPalletFragment()
            }
        }
    }

    /**
     * Nav Handler to DockDoor Fragment
     */
    private fun navigateToUnloadDockDoorFragment() {
        val navOptions = NavOptions.Builder().setPopUpTo(R.id.UnLoadDockDoorFragment, true).build()
        getNavigationController().navigate(R.id.action_unloadTrailerNumber_to_unLoadDockDoorFragment, null, navOptions)
    }

    /**
     * Nav Handler to Unload Carton Pallet Fragment
     */
    private fun navigateToUnloadCartonPalletFragment() {
        binding.etTrailerNumber.text = null
        val action = UnloadTrailerNumberFragmentDirections.actionUnloadTrailerNumberToUnloadCartonPalletFragment()
        getNavigationController().navigate(action)
    }

    /**
     * Function to handle load trailer error response
     */
    private fun handleFailedLoadTrailerResponse(unloadTrailerResponse: UnloadTrailerResponse) {
        binding.tvTrailerNumberResponse.text = unloadTrailerResponse.message
        binding.etTrailerNumber.requestFocus()
        binding.etTrailerNumber.selectAll()
        showSoftKeyBoard(fragmentContext, binding.etTrailerNumber)
    }

    /**
     * Function to handle error response
     */
    private fun handleErrorResponse(message: String?) {
        hideProgressBar()
        message?.let { showErrorSnackBar(it) }
        binding.etTrailerNumber.requestFocus()
        binding.etTrailerNumber.selectAll()
    }

    /**
     * Function to hide progress bar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    /**
     * Function to show progress bar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * Function to handle scanned barcode data
     */
    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        binding.etTrailerNumber.setText(scan?.barcode.toString())
        binding.etTrailerNumber.text?.length?.let {
            binding.etTrailerNumber.setSelection(
                it
            )
            FlareLog.i(TAG, "TrailerNumber field focused")
            validateTrailerNumber()
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}
