package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementPutawayLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private val TAG = PartsReplacementPutawayLocationFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementPutawayLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private lateinit var partsReplacementPutawayLocationBinding: FragmentPartsReplacementPutawayLocationBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails : List<TaskDetail>
    lateinit var task : List<Task>

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacementPutawayLocationBinding =
            FragmentPartsReplacementPutawayLocationBinding.inflate(inflater, container, false)
        partsReplacementPutawayLocationBinding.lifecycleOwner = this
        return partsReplacementPutawayLocationBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        partsReplacementPutawayLocationBinding.tvPutawayLocationValue.text = taskDetails.get(0).targetLocation
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {

        partsReplacementPutawayLocationBinding.etPutawayLocation.doAfterTextChanged {
            partsReplacementPutawayLocationBinding.errResponses.text = null
        }

        partsReplacementPutawayLocationBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, partsReplacementPutawayLocationBinding.etPutawayLocation)
                    if (partsReplacementPutawayLocationBinding.etPutawayLocation.isFocused) {
                        validateTest()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacementPutawayLocationBinding.etPutawayLocation.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, partsReplacementPutawayLocationBinding.etPutawayLocation)
                validateTest()
            }
            false
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun validateTest() {
        val etPutawayLocation = partsReplacementPutawayLocationBinding.etPutawayLocation.text.toString().trim()
        if (etPutawayLocation.isNotEmpty()) {
            partsReplacementPutawayLocationBinding.errResponses.text = null
                if (partsReplacementPutawayLocationBinding.tvPutawayLocationValue.text.toString().trim() == etPutawayLocation) {
                    navigateToPartPutsContainerFragment()
                } else {
                    displayErrorMessage(resources.getString(R.string.parts_replacement_putaway_away_error_message))
                }
        }
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacementPutawayLocationBinding.etPutawayLocation.setText(scan?.barcode.toString())
        partsReplacementPutawayLocationBinding.etPutawayLocation.text?.length?.let {
            partsReplacementPutawayLocationBinding.etPutawayLocation.setSelection(it)
        }
        validateTest()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    @SuppressLint("SuspiciousIndentation")
    private fun navigateToPartPutsContainerFragment() {
        val action = PartsReplacementPutawayLocationFragmentDirections.actionPartsReplacementPutawayLocationFragmentToPartsReplacementPutawayContainerFragment()
        findNavController().navigate(action)

    }

    private fun displayErrorMessage(errorMessage: String) {
        partsReplacementPutawayLocationBinding.errResponses.text = errorMessage
        partsReplacementPutawayLocationBinding.etPutawayLocation.requestFocus()
        partsReplacementPutawayLocationBinding.etPutawayLocation.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacementPutawayLocationBinding.etPutawayLocation)
    }
}