package com.fsc.flare.ui.fragment.replenish.palletreplenishment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenishmentScanPalletPageBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.pickfromreserve.ValidatePalletOverrideRequest
import com.fsc.flare.ui.fragment.replenish.ReplenishViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletReplenishmentScanPalletFragment"
private const val MIXED = "Mixed"
@AndroidEntryPoint
class PalletReplenishmentScanPalletFragment: BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: ReplenishViewModel by activityViewModels()
    lateinit var binding: FragmentReplenishmentScanPalletPageBinding
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentReplenishmentScanPalletPageBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = this

        if(sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null) == "40")
        {
            binding.tvPalletReplenishHeader.text= getString(R.string.pallet_repln_active_header)

        }else if(sharedPreferences.getString(PreferenceKeys.PalletReplenishment.PALLET_REPLEN_TASK_GROUP_ALLOCATION_TYPE, null) == "50"){
            binding.tvPalletReplenishHeader.text= getString(R.string.pallet_repln_casepick_header)
        }

        subscribeObservers()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    private fun subscribeObservers() {
        viewModel.validatePalletOverrideResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    FlareLog.i(TAG, "validatePalletOverrideResponse success: $response")
                    hideProgressBar()
                    response.data?.let { validatePalletOverrideResponse ->
                        val taskData = viewModel.getReplenTaskDetails()
                        FlareLog.i(TAG, "validatePalletOverrideResponse success: $response")
                        hideProgressBar()
                        if (taskData != null) {
                            zeroLocationPromptCall(taskData.pullLocationId.toLong(),validatePalletOverrideResponse.cartonInfo.containerId.toLong())
                        }else{
                            binding.scanPalletResponse.text = getString(R.string.task_details_are_not_found)
                        }
                    }
                }
                is Resource.Error ->{
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "validatePalletOverrideResponse Error: $message")
                        if (message != null) {
                            displayErrorMessage(message)
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.zeroLocationPromptResponse.observe(viewLifecycleOwner){response ->
            when(response){
                is Resource.Success ->{
                    hideProgressBar()
                    response.data.let { zeroLocationPromptResponse ->
                        FlareLog.i(TAG, "zeroLocationPromptResponse Response: $zeroLocationPromptResponse")
                        if (zeroLocationPromptResponse != null) {
                            if(!zeroLocationPromptResponse.zeroQtyLocation.isNullOrEmpty() && zeroLocationPromptResponse.zeroQtyLocation == "Y"){
                                showZeroLocationAlert()
                            }else{
                                navigateToDeliveryLocation()
                            }
                        }
                    }
                }
                is Resource.Error ->{
                    hideProgressBar()
                    response.message.let { message ->
                        FlareLog.e(TAG, "zeroLocationPromptResponse Error: $message")
                        if (message != null) {
                            binding.scanPalletResponse.text = message
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun showZeroLocationAlert() {
        val taskData = viewModel.getReplenTaskDetails()
        if(taskData != null){
            showAlertDialog("",
                getString(R.string.lbl_does_the_location_empty_after_picking,taskData.locationBarcode ),
                getString(R.string.alert_button_yes),
                getString(R.string.alert_button_no),
                object : AlertDialogClickListener {
                    override fun onPositiveButtonClick() {
                        navigateToDeliveryLocation()
                    }
                    override fun onNegativeButtonClick() {
                        viewModel.canGenerateCycleCount = true
                        navigateToDeliveryLocation()
                    }
                })
        }
    }

    fun navigateToDeliveryLocation() {
        val action = PalletReplenishmentScanPalletFragmentDirections.actionReplenishmentScanPalletFragmentToReplenishmentScanDeliveryLocationFragment()
        getNavigationController().navigate(action)
    }

    private fun displayErrorMessage(message: String) {
        binding.scanPalletVal.requestFocus()
        binding.scanPalletResponse.text = message
        binding.scanPalletVal.selectAll()
        showSoftKeyBoard(fragmentContext, binding.scanPalletVal)
    }

    private fun zeroLocationPromptCall(locationId: Long, palletId: Long) {
        val skipPalletIdList: ArrayList<Long> = ArrayList()
        skipPalletIdList.add(palletId)
        viewModel.zeroLocationPromptCall(locationId,skipPalletIdList)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initData()
        binding.skipTask.setOnClickListener{
            FlareLog.i(TAG, "skipTask clicked")
            val action = PalletReplenishmentScanPalletFragmentDirections.actionReplenishmentScanPalletFragmentToReplenishmentScanDeliveryLocationFragment()
            getNavigationController().navigate(action)
        }

        binding.saveReplen.setOnClickListener{
            FlareLog.i(TAG, "Save clicked")
            val action = PalletReplenishmentScanPalletFragmentDirections.actionReplenishmentScanPalletFragmentToReplenishmentScanDeliveryLocationFragment()
            getNavigationController().navigate(action)
        }

        binding.scanPalletVal.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Pallet field focused")
                validatePallet()
            }
            false
        }
        binding.scanPalletVal.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.scanPalletResponse.text = null
            }
        })
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "Location field focused")
                    validatePallet()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    private fun validatePallet() {
        if (binding.scanPalletVal.text.toString().trim().isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.scanPalletVal)
            viewModel.setScannedPallet(binding.scanPalletVal.text.toString().trim())
            viewModel.validatePalletOverride(
                ValidatePalletOverrideRequest(
                    givenContainerNbr = binding.scanPalletVal.text.toString().trim(),
                    taskDetId = viewModel.getReplenTaskDetails()?.taskDetId,
                    custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1)
                )
            )
        }else{
            binding.scanPalletResponse.text = getString(R.string.pallet_is_required)
            binding.scanPalletVal.selectAll()
        }
    }

    private fun initData() {
        val data = viewModel.getReplenTask()
        val taskData = viewModel.getReplenTaskDetails()

        if(data!=null)
        {
            if (taskData != null) {
                binding.taskId.text = taskData.taskId.toString()
                binding.itemVal.text = taskData.itemCode
                binding.locationVal.text = taskData.locationBarcode
            }
        }else
        {
            showErrorSnackBar(resources.getString(R.string.lbl_task_details_are_not_found))
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.scanPalletVal.setText(scan?.barcode.toString())
            binding.scanPalletVal.text?.length?.let {
                binding.scanPalletVal.setSelection(it)
            }
            FlareLog.i(TAG, "Scan Pallet field focused")
            validatePallet()
    }
    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}