package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.inventory.InventoryContainerResponse
import com.fsc.flare.source.data.dto.inventory.PalletCombineDetailResponse
import com.fsc.flare.source.data.dto.inventory.palletconsolidation.ICPTaskRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPCompleteRequest
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPSystemTask
import com.fsc.flare.source.data.dto.splitcontainerreverse.ICPTaskComplete
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.ICPConstants.ALLOCATION_TYPE_VALUE
import com.fsc.flare.utils.ICPConstants.TASK_GROUP_VALUE
import com.fsc.flare.utils.PreferenceKeys
import retrofit2.Response
import javax.inject.Inject

private const val TRANSFER_CONTAINER_TYPE = "Pallet"

interface SDCombinePalletRepository {

    suspend fun getCombinePalletTasks(): Response<ICPSystemTask>

    suspend fun skipPalletCombineTask(skipTaskId: Int): Response<ICPSystemTask>

    suspend fun getPalletDetails(palletNumber: String): Response<PalletCombineDetailResponse>

    suspend fun getPalletContainers(palletNumber: String): Response<InventoryContainerResponse>

    suspend fun completeICPTask(icpCompleteRequest: ICPCompleteRequest): Response<ICPTaskComplete>
}

class SDCombinePalletRepositoryImpl @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences
) : SDCombinePalletRepository {

    override suspend fun getCombinePalletTasks() = apiGatewayInterface.getICPTaskPick(
        gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
        taskPickReq = ICPTaskRequest(
            allocationType = ALLOCATION_TYPE_VALUE,
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            taskGroup = TASK_GROUP_VALUE
        )
    )

    override suspend fun skipPalletCombineTask(skipTaskId: Int) =
        apiGatewayInterface.palletConsolidationTaskSkip(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            userId = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            skipTaskId = skipTaskId
        )

    override suspend fun getPalletDetails(palletNumber: String) =
        apiGatewayInterface.getPalletDetailsForCombine(
            gatewayToken = "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = "${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = palletNumber,
            transferType = TRANSFER_CONTAINER_TYPE,
            combineBy = TRANSFER_CONTAINER_TYPE
        )

    override suspend fun getPalletContainers(palletNumber: String) =
        apiGatewayInterface.getCaseDetailsByPallet(
            gatewayToken ="$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId ="${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            parentContainerId = palletNumber,
            excludeLocationInfo = true,
            itemInfo = Constants.YES
        )

    override suspend fun completeICPTask(icpCompleteRequest: ICPCompleteRequest) =
        apiGatewayInterface.completeICPTak(
            gatewayToken ="$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId ="${sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)}",
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            icpCompleteRequest = icpCompleteRequest
        )
}