package com.fsc.flare.ui.fragment.inquiry.inventorytransfer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentInventoryTransferContainerInquiryBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.ui.fragment.inquiry.InquiryViewModel
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "InventoryTransferContainerInquiryFragment"

/**
 * A simple [Fragment] subclass.
 * Use the [InventoryTransferContainerInquiryFragment] factory method to
 * create an instance of this fragment.
 */
@AndroidEntryPoint
class InventoryTransferContainerInquiryFragment : BaseFragment(), FlareScannable {

    private val viewModel: InquiryViewModel by activityViewModels()
    private lateinit var binding: FragmentInventoryTransferContainerInquiryBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInventoryTransferContainerInquiryBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.etContainer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvContainerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })

        binding.etContainer.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "Container field focused")
                getContainerDetail()
            }
            false
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.etContainer.isFocused && !binding.etContainer.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "Container field focused")
                        getContainerDetail()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }
    }

    /**
     * method to get Container details from API
     */
    private fun getContainerDetail(){
        viewModel.inventoryTransferContainer(
            GetContDetailRequest(
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
            containerNbr = binding.etContainer.text.toString(),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                includeCCLocation = if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)) "Y" else "N"))
    }

    /**
     * method to subscribe observers for API calls
     */
    private fun subscribeObservers() {
        subscribeContainerObserver()
    }

    /**
     * method to subscribe Container observer
     */
    private fun subscribeContainerObserver() {
        viewModel.inventoryTransferContainerInquiryResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { inventoryTransferResponse ->
                        FlareLog.i(TAG, "Container Inquiry success: $inventoryTransferResponse")

                        viewModel.setInventoryTransferContainerInquiryDetail(inventoryTransferResponse)
                        val action = InventoryTransferContainerInquiryFragmentDirections.actionInventoryTransferContainerInquiryFragmentToInventoryTransferContainerInquiryDetailFragment()
                        getNavigationController().navigate(action)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "inventoryTransferGET Error: $message")
                        binding.tvContainerResponse.text = message
                        binding.etContainer.requestFocus()
                        binding.etContainer.selectAll()
                        showSoftKeyBoard(fragmentContext, binding.etContainer)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.onVisibilityChange(true)
        cb1 = cb!!
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.etContainer.setText(scan?.barcode.toString())
                binding.etContainer.text?.length?.let {
                    binding.etContainer.setSelection(it)
                    FlareLog.i(TAG, "Container field focused")
                    getContainerDetail()
                }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }

}