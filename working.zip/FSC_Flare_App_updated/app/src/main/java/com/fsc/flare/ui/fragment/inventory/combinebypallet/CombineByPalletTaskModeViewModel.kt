package com.fsc.flare.ui.fragment.inventory.combinebypallet

import android.content.SharedPreferences
import androidx.lifecycle.viewModelScope
import com.fsc.flare.base.BaseViewModel
import com.fsc.flare.source.data.dto.receiving.item.LookUpsRequest
import com.fsc.flare.source.repository.AccountRepository
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.Constants.Lookup.ENABLE_SYS_ICP
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CombineByPalletTaskModeViewModel @Inject constructor(
    private val accountRepository: AccountRepository,
    private val sharedPreferences: SharedPreferences
) : BaseViewModel() {


    private val _icpLookUpVerification = MutableStateFlow<CombineByPalletTaskModeEvent?>(null)
    val icpLookUpVerification = _icpLookUpVerification.asStateFlow()


    fun verifyICP(scope: CoroutineScope = viewModelScope) {
        scope.launch {
            _icpLookUpVerification.emit(CombineByPalletTaskModeEvent.ShowLoading)
            val response = accountRepository.getLookUps(
                LookUpsRequest(
                    fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    lookupNames = ENABLE_SYS_ICP
                )
            )
            _icpLookUpVerification.emit(CombineByPalletTaskModeEvent.HideLoading)
            response.takeIf { it.isSuccessful && it.body() != null }?.body()?.apply {
                lookups.firstOrNull { it.lookupName == ENABLE_SYS_ICP && it.lookupCodes.any { code -> code.lookupCode == YES } }?.let {
                    _icpLookUpVerification.emit(CombineByPalletTaskModeEvent.ICPTaskEnabled(enabled = true))
               } ?: run {
                    _icpLookUpVerification.emit(CombineByPalletTaskModeEvent.ICPTaskEnabled(enabled = false))
               }
            } ?: run {
                val errorResponse = handleForwardErrorResponse(
                    response.code(),
                    response.errorBody(),
                    response.message()
                )
                _icpLookUpVerification.emit(CombineByPalletTaskModeEvent.ShowError(errorResponse))
            }
        }
    }

    fun clearData() {
        _icpLookUpVerification.value = null
    }
}


sealed class CombineByPalletTaskModeEvent {
    data object ShowLoading : CombineByPalletTaskModeEvent()
    data object HideLoading : CombineByPalletTaskModeEvent()
    data class ShowError(val message: String? = null) : CombineByPalletTaskModeEvent()
    data class ICPTaskEnabled(val enabled: Boolean) : CombineByPalletTaskModeEvent()
}