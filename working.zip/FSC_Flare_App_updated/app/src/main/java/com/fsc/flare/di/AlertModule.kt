package com.fsc.flare.di

import android.content.Context
import com.fsc.flare.ui.common.AlertHandler
import com.fsc.flare.ui.common.AlertHandlerImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import dagger.hilt.android.qualifiers.ActivityContext


@InstallIn(ActivityComponent::class)
@Module
class AlertModule {

    /**
     * Inject AlertHandler
     */
    @Provides
    fun bindAlertHandler(@ActivityContext context: Context): AlertHandler {
        return AlertHandlerImpl(context)
    }
}