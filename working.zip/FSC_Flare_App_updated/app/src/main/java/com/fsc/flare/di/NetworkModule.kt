package com.fsc.flare.di

import android.annotation.SuppressLint
import android.app.Application
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import com.appdynamics.eumagent.runtime.BreadcrumbVisibility
import com.appdynamics.eumagent.runtime.Instrumentation
import com.fsc.flare.BuildConfig
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.api.GzipRequestInterceptor
import com.fsc.flare.source.data.api.TimingInterceptor
import com.fsc.flare.source.repository.TokenRepository
import com.fsc.flare.transactiontracker.FSCTransactionTracker
import com.fsc.flare.transactiontracker.dto.FSCTrackerContainerDetailModel
import com.fsc.flare.ui.activity.splash.SplashActivity
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.Constants.RequestHeaders
import com.fsc.flare.utils.Constants.RequestHeaders.BEARER
import com.fsc.flare.utils.ExceptionUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.StringUtils
import com.fsc.flare.utils.Utility
import com.fsc.flare.utils.getMachineTimeStamp
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton


private const val TAG = "NetworkModule"
private const val TIMEOUT_VALUE:Long = 120

@InstallIn(SingletonComponent::class)
@Module
class NetworkModule {

    @Provides
    @Singleton
    fun getLoggingInterceptor(logger: FlareRfAPILog): HttpLoggingInterceptor {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        return loggingInterceptor
    }

    @Provides
    @Singleton
    fun getOkHttpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS))
            .retryOnConnectionFailure(false)
            .connectTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .addInterceptor(GzipRequestInterceptor())
            .addInterceptor(TimingInterceptor())
        return builder.build()
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Provides
    @Singleton
    @SuppressLint("HardwareIds")
    @AndroidId
    fun getAndroidId(context: Application): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }

    @OptIn(DelicateCoroutinesApi::class)
    @Provides
    @Singleton
    fun getRetrofit(
        loggingInterceptor: HttpLoggingInterceptor,
        okHttpClient: OkHttpClient,
        sharedPreferences: SharedPreferences,
        context: Application,
        @AndroidId androidId: String,
        trackerInstance: FSCTransactionTracker
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.GATEWAY_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .client(OkHttpClient.Builder().connectTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS).addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header(RequestHeaders.HEADER_AUTHORIZATION, "$BEARER ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}")
                    .header(RequestHeaders.HEADER_CONTENT_TYPE, RequestHeaders.VALUE_APP_JSON)
                    .header(RequestHeaders.HEADER_APPID, RequestHeaders.VALUE_APP_ID)
                    .header(RequestHeaders.HEADER_APP_NAME, RequestHeaders.VALUE_APP_NAME)
                    .header(RequestHeaders.HEADER_UUID, Utility.generateUUID())
                    .header(RequestHeaders.HEADER_LOGGED_IN_USER, sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "undefined").orEmpty())
                    .header(RequestHeaders.HEADER_CUST_ID, sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString())
                    .header(RequestHeaders.HEADER_BU_ID, sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString())
                    .header(RequestHeaders.HEADER_FACILITY_ID, sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString())
                    .header(RequestHeaders.HEADER_CUST_NAME, sharedPreferences.getString(PreferenceKeys.CUST_NAME, "").orEmpty())
                    .header(RequestHeaders.HEADER_MODULE, RequestHeaders.VALUE_MODULE)
                    .header(RequestHeaders.HEADER_TRACE_PATH, RequestHeaders.VALUE_TRACE_PATH)
                    .header(RequestHeaders.HEADER_ORIGIN, RequestHeaders.VALUE_ORIGIN)
                    .header(RequestHeaders.HEADER_FCY_TIMEZONE,sharedPreferences.getString(PreferenceKeys.FACILITY_TIMEZONE, "").orEmpty())
                    .header(RequestHeaders.HEADER_FCY_TZ_GMT_OFFSET,sharedPreferences.getString(PreferenceKeys.FACILITY_GMT_OFFSET, "").orEmpty())
                    .header(RequestHeaders.FSC_USER_ID,sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString())
                    .header(RequestHeaders.HEADER_LANGUAGE, sharedPreferences.getString(PreferenceKeys.APP_LANGUAGE, "en").orEmpty())
                    .header(RequestHeaders.HEADER_OktaJWTToken, sharedPreferences.getString(PreferenceKeys.OKTA_ACCESS_TOKEN, "").orEmpty())
                    .header(RequestHeaders.HEADER_OktaTempJWTToken, sharedPreferences.getString(PreferenceKeys.TEMP_OKTA_ACCESS_TOKEN, "").orEmpty())
                    .header(RequestHeaders.MACHINE_ID, androidId)
                    .header(RequestHeaders.MACHINE_NAME, "${Build.BRAND}-${Build.MODEL}")
                    .header(RequestHeaders.ENROLLMENT_TYPE, sharedPreferences.getString(PreferenceKeys.CUSTOMER_ENROLLMENT_TYPE, "").orEmpty())
                    .header(RequestHeaders.TIME_STAMP, Calendar.getInstance().getMachineTimeStamp())
                    .build()
                Instrumentation.setUserData("Request_HEADER_UUID", request.headers[RequestHeaders.HEADER_UUID].toString())
                Instrumentation.leaveBreadcrumb("API Request $request", BreadcrumbVisibility.CRASHES_AND_SESSIONS)

                try {
                    val response: Response = chain.proceed(request)
                    val rawJson = response.body!!.string()
                    if (response.code == 401) {
                        trackerInstance.writeTrackerData(
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toLong(),
                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toLong(),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toLong()
                        )
                        FlareLog.e(TAG, response.code.toString() + " : " + "Unauthorized")
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(context, "Session Expired, Logging out", Toast.LENGTH_SHORT).show()
                        }
                        FlareLog.reset()
                        val intent = Intent(context, SplashActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        intent.putExtra(SplashActivity.EXTRA_LOGGING_OUT, true)
                        context.startActivity(intent)
                    } else {
                        GlobalScope.launch {
                            trackerInstance.setTriggersModel(
                                FSCTrackerContainerDetailModel(
                                    httpMethod = request.method,
                                    url = request.url.toString(),
                                    request = if (response.request.body != null) StringUtils.bodyToString(response.request.body) else request.url.toString(),
                                    response = rawJson
                                )
                            )
                        }
                    }
                    response.newBuilder().body(rawJson.toResponseBody(response.body?.contentType())).build()
                }catch (e:Exception)
                {
                    val errorMessage = ExceptionUtil.catchException(e)
                    Response.Builder()
                        .request(request)
                        .protocol(Protocol.HTTP_1_1)
                        .code(500)
                        .message(errorMessage)
                        .body(errorMessage.toResponseBody(null)).build()
                }

            }.addInterceptor(loggingInterceptor).addInterceptor(TimingInterceptor()).build())
            .build()
    }

    @Provides
    @Singleton
    fun provideFlareApi(retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    ////////////////////////////////

    @Provides
    @Singleton
    @Named("compressedCustomTimeout")
    fun provideCompressedOAuthOkHttpClientWithTimeout(baseOkHttpClient: OkHttpClient.Builder): OkHttpClient {
        return baseOkHttpClient
            .addInterceptor(GzipRequestInterceptor())
            .addInterceptor(TimingInterceptor())
            .connectTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_VALUE, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    @Named("compressedCustomTimeout")
    fun provideCompressedOAuthRetrofitWithTimeout(
        baseRetrofit: Retrofit.Builder,
        @Named("compressedCustomTimeout") okHttpClient: OkHttpClient
    ): Retrofit {
        return baseRetrofit.client(okHttpClient).build()
    }

    @Provides
    @Singleton
    @Named("compressedCustomTimeout")
    fun provideCompressedCustomTimeoutBodyEndpoint(@Named("compressedCustomTimeout") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    /////////////////////////////////

    @Provides
    @Singleton
    @Named("basic")
    fun getBasicOkHttpClient(loggingInterceptor: HttpLoggingInterceptor): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS))
            .retryOnConnectionFailure(false)
            .writeTimeout(Constants.HTTP_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS)
            .readTimeout(Constants.HTTP_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS)
            .connectTimeout(Constants.HTTP_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .addInterceptor(TimingInterceptor())
            .addInterceptor(GzipRequestInterceptor())

        return builder.build()
    }

    @Provides
    @Singleton
    @Named("basic")
    fun getBasicRetrofit(@Named("basic") okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
    }

    @Provides
    @Singleton
    @Named("basic")
    fun provideAppPropertiesEndpoint(@Named("basic") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    /////////////////////////////

    @Provides
    @Singleton
    @Named("auth")
    fun provideAuthOkHttpClient(loggingInterceptor: HttpLoggingInterceptor): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS))
            .addInterceptor(TimingInterceptor())
            .addNetworkInterceptor(loggingInterceptor)
        return builder.build()
    }

    @Provides
    @Singleton
    @Named("auth")
    fun getAuthRetrofit(@Named("auth") okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_AUTH_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
    }

    @Provides
    @Singleton
    @Named("tempauth")
    fun getTempAuthRetrofit(@Named("auth") okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.TEMP_WORKER_BASE_AUTH_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
    }

    @Provides
    @Singleton
    @Named("auth")
    fun provideAuthEndpoint(@Named("auth") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    @Provides
    @Singleton
    @Named("tempauth")
    fun provideTempAuthEndpoint(@Named("tempauth") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    /////////////////////////////////////////////////

    @Provides
    @Singleton
    @Named("authmenu")
    fun getAuthorizedMenuRetrofit(@Named("basic") okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.GATEWAY_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
    }

    @Provides
    @Singleton
    @Named("authmenu")
    fun provideAuthMenuEndpoint(@Named("authmenu") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    /////////////////////////////////////////////

    @Provides
    @Singleton
    @Named("gateway")
    fun provideBaseOkHttpClient(loggingInterceptor: HttpLoggingInterceptor): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS))
            .addNetworkInterceptor(loggingInterceptor)
        return builder.build()
    }

    @Provides
    @Singleton
    @Named("gateway")
    fun getTokenRetrofit(@Named("gateway") okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.GATEWAY_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
    }

    @Provides
    @Singleton
    @Named("gateway")
    fun provideGatewayEndpoint(@Named("gateway") retrofit: Retrofit): ApiGatewayInterface {
        return retrofit.create(ApiGatewayInterface::class.java)
    }

    ////////////////////////////////////////////////////

    @Provides
    @Singleton
    fun provideTokensRepository(
        @Named("auth") apiGateway: ApiGatewayInterface,
        @Named("tempauth") apiGatewayTemp: ApiGatewayInterface,
        apiGatewayInterface: ApiGatewayInterface,
        sharedPreferences: SharedPreferences
    ): TokenRepository {
        return TokenRepository(apiGateway, apiGatewayTemp, apiGatewayInterface, sharedPreferences)
    }
}
