package com.fsc.flare.ui.fragment.palletizecontainer

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPalletizeContainerContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.inventory.Container
import com.fsc.flare.source.data.dto.inventory.Item
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_COO
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_EXP_DATE
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_LOT
import com.fsc.flare.utils.Constants.Companion.MIXED_ATTRIBUTE_MFG_DATE
import com.fsc.flare.utils.Constants.Companion.YES
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_CONCEALED
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_FACILITY
import com.fsc.flare.utils.Constants.DamageLockCodes.DAMAGE_IN_TRANSIT
import com.fsc.flare.utils.ItemUOMConversionRateUtil
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PalletizeContianerFragment"

@AndroidEntryPoint
class PalletizeContianerFragment : BaseFragment(), FlareScannable {
    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: PalletizeContainerViewModel by activityViewModels()
    private lateinit var binding: FragmentPalletizeContainerContainerBinding
    lateinit var cb1: CustomVisibilityCallback
    private var noOfCasesAllowed = 1
    private var totalCaseScanned = 0
    private var palletItemId: Int? = null
    var itemBarCode:String? =null
    private var palletInventoryType: String? = null
    private var containerListAdapter: PalletizeIBContainerAdapter? = null
    private var firstCaseItemAttributes: Item? = null
    private val caseNbrList = mutableListOf<String>()
    private val checkedContainers = ArrayList<String>()
    private var itemUomConversionRateUtil: ItemUOMConversionRateUtil? = null
    private var isPalletNew = false
    private var mixedAttributes = ArrayList<String>()
    private var palletHasDamageLocks = false
    private var palletDamageLock: String? = null
    private var restrictedLockCodesMixListOnPallet = emptyList<String?>()
    private var damageLocksList = listOf(DAMAGE_IN_FACILITY, DAMAGE_IN_TRANSIT, DAMAGE_IN_CONCEALED)
    private var mixLockErrMsg = ""
    private var isDamageLockConfigOn = false

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
                PreferenceKeys.FEDEX_ID,
                null
        )
        super.onResume()
        handleContainerCountView()
        cb1.onVisibilityChange(true)
    }

    private fun handleContainerCountView() {
        if (caseNbrList.size > 0) {
            binding.lnrContainerList.visibility = View.VISIBLE
            binding.tvTotalCountValue.text = "${caseNbrList.size} ${getString(R.string.lbl_view)}"
            binding.btnStage.isEnabled = true
        } else {
            binding.lnrContainerList.visibility = View.GONE
            binding.btnStage.isEnabled = false
            if(viewModel.getPalletizeContainerPalletInfo().palletId == null){
                binding.lnrItem.visibility = View.GONE
                binding.lnrInventoryType.visibility = View.GONE
                itemBarCode = null
                palletInventoryType = null
                palletItemId = null
                firstCaseItemAttributes = null
                isPalletNew = true
                palletHasDamageLocks = false
                palletDamageLock = null
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        binding = FragmentPalletizeContainerContainerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        return binding.root
    }

    private fun showScannedContainersList() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle(getString(R.string.containers_scanned))
        checkedContainers.clear()

        val containersArray = caseNbrList.toTypedArray()
        builder.setMultiChoiceItems(containersArray, null) { dialog, which, isChecked ->
            if (isChecked) {
                checkedContainers.add(caseNbrList[which])
            } else {
                checkedContainers.remove(caseNbrList[which])
            }
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        builder.setPositiveButton(getString(R.string.btn_delete)) { _, _ ->
            removeCheckedContainers(checkedContainers)
            handleContainerCountView()
        }
        builder.setNegativeButton(getString(R.string.alert_button_cancel), null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            handleTheDeleteButtonInAlertDialog(dialog)
        }
        dialog.show()
    }

    private fun handleTheDeleteButtonInAlertDialog(dialog: DialogInterface?) {

        (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = checkedContainers.size>0
        if(checkedContainers.size>0)
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 1f
        }else
        {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).alpha = 0.35f
        }
    }

    private fun removeCheckedContainers(checkedContainers: ArrayList<String>) {
        caseNbrList.removeAll(checkedContainers)
    }

    private fun deAssociateContainerAlert(container: Container, containerParentNumber: String?) {
        val message = "${getString(R.string.alert_dialog_message_palletize_container_message)} $containerParentNumber"
        showAlertDialog(
            "",
            message,
            getString(R.string.yes),
            getString(R.string.no),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    prepareContainerToAddToPallet(container)
                }
                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun moveToNextScreen() {
        val action = PalletizeContianerFragmentDirections.actionPalletizeContianerFragmentToPcStagingLocationFragment()
        moveToFragment(action)
    }

    private fun checkForStageButton() {
        if (viewModel.associatedContainersIds.isNotEmpty()) {
            binding.btnStage.isEnabled = true
        }
    }

    private fun subscribeObservers() {

        viewModel.caseDetailsResp.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { caseDetailsResponse ->

                        if (caseDetailsResponse.success && caseDetailsResponse.container.isNotEmpty()) {
                            val container = caseDetailsResponse.container.first()
                            val isAllowedOnCCPendingLocation = sharedPreferencesBase.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION, false)
                            if (firstCaseItemAttributes != null){
                                val secondCaseItemDetails = caseDetailsResponse.container[0].item
                                mixedAttributes =  hasMixedAttributes(firstCaseItemAttributes, secondCaseItemDetails)
                            }
                            if(!caseDetailsResponse.container[0].item?.uomConversions.isNullOrEmpty() && sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS,false)){
                                itemUomConversionRateUtil = caseDetailsResponse.container[0].item?.uomConversions?.let { ItemUOMConversionRateUtil(it) }
                            }

                            if (container.status != "20") {
                                displayErrorMessage(getString(R.string.invalid_ib_container_status))
                            } else if (container.parentContainerNumber != null && container.parentContainerNumber == viewModel.getPalletizeContainerPalletInfo()?.palletNumber) {
                                displayErrorMessage(getString(R.string.container_already_in_scanned_pallet))
                            } else if (caseDetailsResponse.container[0].lockCode == "CC") {
                                displayErrorMessage(getString(R.string.cycle_count_in_progress_for_given_location))
                            } else if (caseDetailsResponse.container[0].cyclePending == YES && !isAllowedOnCCPendingLocation) {
                                displayErrorMessage(getString(R.string.cycle_count_is_pending_for_given_location))
                            } else if (palletItemId != null && palletItemId != container.item?.itemId) {
                                displayErrorMessage(getString(R.string.lbl_containers_of_different_items_can_not_be_palletized_together_plese_check))
                            } else if (palletInventoryType != null && container.inventoryType != palletInventoryType) {
                                displayErrorMessage(getString(R.string.containers_have_different_inventory_type_can_not_palletize_together))
                            } else if(mixedAttributes.size > 0){
                                displayErrorMessage(getMixedAttributesErrorMsg())
                            }else if(isDamageLockConfigOn && !isPalletNew && !checkDamageLockCombination(container)){
                                displayErrorMessage(getString(R.string.cannot_palletize_cases_having_damage_locks_and_cases_not_having_damage_locks_together))
                            }else if(isDamageLockConfigOn && !isPalletNew && checkMixedDamageLockCombination(container)){
                                displayErrorMessage(getString(R.string.containers_having_different_damage_lock_codes_can_not_be_palletized_together_please_check))
                            }else if(isDamageLockConfigOn && !isPalletNew &&  checkRestrictedLocksMixCombinationConfig(container)){
                                displayErrorMessage(mixLockErrMsg)
                            }else if (itemUomConversionRateUtil != null
                                && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS, false) && itemUomConversionRateUtil!!.isPalletUomDefined)
                                && (totalCaseScanned >= itemUomConversionRateUtil!!.getCasesQtyInAPallet()!!)) {
                                displayErrorMessage(getString(R.string.lbl_max_pallet_capacity_is_reached))
                            } else if (itemUomConversionRateUtil != null
                                && (sharedPreferences.getBoolean(PreferenceKeys.FOLLOW_ITEM_UOMS, false) && itemUomConversionRateUtil!!.isCaseUomDefined)
                                && (caseDetailsResponse.container[0].item?.itemQty!! > itemUomConversionRateUtil!!.getEachesQtyInACase()!!)) {
                                displayErrorMessage(getString(R.string.lbl_scanned_case_is_having_qty_greater_than_case_uom))
                            } else {
                                if (container.parentContainerNumber != null) {
                                    deAssociateContainerAlert(container, container.parentContainerNumber)
                                } else {
                                    firstCaseItemAttributes = caseDetailsResponse.container[0].item
                                    prepareContainerToAddToPallet(container)
                                }
                            }
                        }else{
                            displayErrorMessage(getString(R.string.invalid_container))
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        binding.tvError.text = message
                        binding.etPalletizeContainer.selectAll()
                        binding.etPalletizeContainer.requestFocus()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun checkDamageLockCombination(container: Container): Boolean {
        val caseHasDamageLocks = container.lockCodes?.map { it.code }?.any { damageLocksList.contains(it) } == true
        return if (palletHasDamageLocks){
            caseHasDamageLocks
        }else{
            !caseHasDamageLocks
        }
    }

    private fun checkMixedDamageLockCombination(container: Container): Boolean {
        val caseDamageLock = container.lockCodes?.map { it.code }?.intersect(damageLocksList)?.toList()?.firstOrNull()
        return caseDamageLock != palletDamageLock
    }

    private fun checkRestrictedLocksMixCombinationConfig(container: Container): Boolean {
        val restrictedLockCodesMixListOnCase = container.lockCodes?.map { it.code }?.filter { it in  getRestrictedLockCodesMixList()} ?: emptyList()
        val notCommonRestrictMixLocksBetweenCaseAndPallet = restrictedLockCodesMixListOnCase.filterNot { it in restrictedLockCodesMixListOnPallet  } + (restrictedLockCodesMixListOnPallet.filterNot { it in restrictedLockCodesMixListOnCase })
        if(notCommonRestrictMixLocksBetweenCaseAndPallet.isNotEmpty()){
            mixLockErrMsg = getString(R.string.cannot_palletize_cases_having_typeof_lock_and_cases_not_having_that_typeof_locks_together,
                getRestrictedLockCodeDescription(notCommonRestrictMixLocksBetweenCaseAndPallet[0] ?: ""))
        }
        return notCommonRestrictMixLocksBetweenCaseAndPallet.isNotEmpty()
    }

    private fun getRestrictedLockCodesMixList():List<String> {
        val restrictLocksHashMap: HashMap<String, String> = Gson().fromJson(sharedPreferencesBase.getString(PreferenceKeys.LOCK_COMPARE_IN_PALLETIZE_CONT_HASH_MAP,""), object : TypeToken<HashMap<String?, String?>?>() {}.type)
        return restrictLocksHashMap.keys.toList()
    }

    private fun getRestrictedLockCodeDescription(code: String): String? {
        val restrictLocksHashMap: HashMap<String, String> = Gson().fromJson(sharedPreferencesBase.getString(PreferenceKeys.LOCK_COMPARE_IN_PALLETIZE_CONT_HASH_MAP,""), object : TypeToken<HashMap<String?, String?>?>() {}.type)
        return restrictLocksHashMap[code]
    }


    private fun prepareContainerToAddToPallet(container: Container) {
        isPalletNew = false
        if (palletItemId == null) {
            palletItemId = container.item?.itemId
            itemBarCode = container.item?.itemBarCode
        }
        if (palletInventoryType == null) {
            palletInventoryType = container.inventoryType
        }
        binding.etPalletizeContainer.text = null
        if (itemBarCode != null) {
            binding.lnrItem.visibility = View.VISIBLE
            binding.tvItemBarcode.text = itemBarCode
        }
        if (palletInventoryType != null) {
            binding.lnrInventoryType.visibility = View.VISIBLE
            binding.tvInventoryType.text = palletInventoryType?.let { getInventoryDescription(it) }
        }
        palletDamageLock = container.lockCodes?.map { it.code }?.filter { it in damageLocksList }?.toList()?.getOrNull(0)
        palletHasDamageLocks = container.lockCodes?.map { it.code }?.any { damageLocksList.contains(it) } == true
        restrictedLockCodesMixListOnPallet = (container.lockCodes?.map { it.code }?.filter { it in getRestrictedLockCodesMixList() } ?: emptyList())
        totalCaseScanned++
        viewModel.associatedContainersIds.add(container.containerId)
        caseNbrList.add(container.containerNumber)
        handleContainerCountView()
        if (containerListAdapter != null) {
            binding.lnrContainerList.visibility = View.VISIBLE
            containerListAdapter!!.notifyDataSetChanged()
        }
        checkForStageButton()
    }

    private fun getMixedAttributesErrorMsg(): String {
        var errMsg = ""
        when {
            mixedAttributes.size > 1 -> {
                errMsg = getString(R.string.mixed_attributes_are_not_allowed_to_be_part_of_a_pallet)
            }

            mixedAttributes.size == 1 -> {
                when {
                    mixedAttributes[0] == MIXED_ATTRIBUTE_LOT -> {
                        errMsg =
                            getString(R.string.mixed_lots_are_not_allowed_to_be_part_of_a_pallet)
                    }

                    mixedAttributes[0] == MIXED_ATTRIBUTE_EXP_DATE -> {
                        errMsg =
                            getString(R.string.mixed_expiry_dates_are_not_allowed_to_be_part_of_a_pallet)
                    }

                    mixedAttributes[0] == MIXED_ATTRIBUTE_COO -> {
                        errMsg =
                            getString(R.string.mixed_coo_s_are_not_allowed_to_be_part_of_a_pallet)
                    }

                    mixedAttributes[0] == MIXED_ATTRIBUTE_MFG_DATE -> {
                        errMsg =
                            getString(R.string.mixed_manufacturing_dates_are_not_allowed_to_be_part_of_a_pallet)
                    }
                }
            }
        }
        return errMsg
    }

    private fun hasMixedAttributes(firstCaseItemAttributes: Item?, secondCaseItemDetails: Item?): ArrayList<String> {
        val mixedAttributes = arrayListOf<String>()
        if (firstCaseItemAttributes?.lotNumber != secondCaseItemDetails?.lotNumber) {
            mixedAttributes.add(MIXED_ATTRIBUTE_LOT)
        }
        if (firstCaseItemAttributes?.expDate != secondCaseItemDetails?.expDate) {
            mixedAttributes.add(MIXED_ATTRIBUTE_EXP_DATE)
        }
        if (firstCaseItemAttributes?.coo != secondCaseItemDetails?.coo) {
            mixedAttributes.add(MIXED_ATTRIBUTE_COO)
        }
        if (firstCaseItemAttributes?.mfgDate != secondCaseItemDetails?.mfgDate) {
            mixedAttributes.add(MIXED_ATTRIBUTE_MFG_DATE)
        }
        return mixedAttributes
    }


    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        isDamageLockConfigOn = sharedPreferences.getBoolean(PreferenceKeys.ALLOW_INV_MOVEMENT_FOR_DAMAGE_LOCK_CONTAINERS, false)

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateField()
                }
            }
            v?.onTouchEvent(event) ?: true
        }
        binding.etPalletizeContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.etPalletizeContainer)
                FlareLog.i(TAG, "Container field focused")
                validateField()
            }
            false
        }
        subscribeObservers()

        binding.tvTotalCountValue.setOnClickListener {
            if (caseNbrList.size > 0)
                showScannedContainersList()
        }

        init()
        initListener()
    }

    private fun init() {
        viewModel.getPalletizeContainerPalletInfo().let {
            binding.tvPalletValue.text = it.palletNumber
            noOfCasesAllowed = it.noOfCasesAllowed ?: 1
            palletItemId = it.itemId
            palletInventoryType = it.inventoryType
            itemBarCode = it.itemBarCode
            firstCaseItemAttributes = Item()
            firstCaseItemAttributes!!.lotNumber = it.lotNumber
            firstCaseItemAttributes!!.coo = it.COO ?: ""
            firstCaseItemAttributes!!.expDate = it.expDate ?: ""
            firstCaseItemAttributes!!.mfgDate = it.mfgDate ?: ""
            isPalletNew = (palletItemId == null)
            palletHasDamageLocks = viewModel.palletHasDamageLocks
            palletDamageLock = viewModel.palletDamageLock
            restrictedLockCodesMixListOnPallet = viewModel.restrictedLockCodesMixListOnPallet
        }
        if (itemBarCode != null) {
            binding.lnrItem.visibility = View.VISIBLE
            binding.tvItemBarcode.text = itemBarCode
        }
        if (palletInventoryType != null) {
            binding.lnrInventoryType.visibility = View.VISIBLE
            binding.tvInventoryType.text = palletInventoryType?.let { getInventoryDescription(it) }
        }
    }


    private fun initListener() {
        binding.btnEndPalletize.setOnClickListener {
            onBackFromFragment()
        }

        binding.etPalletizeContainer.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.tvError.text = null
            }
        })
        binding.btnStage.setOnClickListener {
            moveToNextScreen()
        }
    }

    private fun validateField() {
        val containerNumber = binding.etPalletizeContainer.text.toString().trim()
        if(caseNbrList.contains(binding.etPalletizeContainer.text.toString())){
            displayErrorMessage(getString(R.string.case_transfer_container_already_scanned))
        }else{
            hideSoftKeyBoard(fragmentContext, binding.rootLayout)
            viewModel.getCaseDetails(containerNumber, "Y")
        }
    }

    private fun displayErrorMessage(message: String) {
        binding.tvError.text = message
        binding.etPalletizeContainer.requestFocus()
        binding.etPalletizeContainer.selectAll()
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            binding.etPalletizeContainer.setText(scan?.barcode.toString())
            binding.etPalletizeContainer.text?.length?.let {
                binding.etPalletizeContainer.setSelection(it)
            }
            FlareLog.i(TAG, "Carton field focused")
        validateField()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}