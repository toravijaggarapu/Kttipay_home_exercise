package com.fsc.flare.ui.fragment.pickfromreverse.tivoLTL

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentTaskgroupPickFromReverseBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.lookups.toLookUpCodes
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.receiving.carton.TransactionParamRequest
import com.fsc.flare.source.data.dto.taskgroup.TaskGroup
import com.fsc.flare.ui.fragment.pickfromreverse.PickFromReserveViewModel
import com.fsc.flare.ui.fragment.pickingforward.ORDER_TYPE_RESULT
import com.fsc.flare.utils.Constants.AllocationType.FROM_RESERVE_PICK
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.PreferenceKeys.Companion.LTL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.PreferenceKeys.Companion.PCL_ORD_TYPES_PREFERENCE
import com.fsc.flare.utils.Resource
import com.fsc.flare.utils.getNavigationResult
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


private val TAG = TivoTaskgroupsFragment::class.simpleName.toString()

@AndroidEntryPoint
class TivoTaskgroupsFragment : BaseFragment(), FlareScannable {

    private val viewModel: PickFromReserveViewModel by activityViewModels()
    private lateinit var binding: FragmentTaskgroupPickFromReverseBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callLTLTransactionParamAPI()
        //  viewModel.getTaskGroups("11,30")
    }

    /**
     * method to get transaction param info from API
     */
    private fun callLTLTransactionParamAPI() {
        viewModel.getLTLTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "LTLCUBE"
            )
        )
    }

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        if (viewModel.gettaskGroupCodeOptions() != null) {
            binding.rsvTaskGroupDropDown.setOptions(viewModel.gettaskGroupCodeOptions())
        }
        cb1.onVisibilityChange(true)
        // Reset all completed tasks if user comes back to this screen
        viewModel.setTasksCompletedList(ArrayList())

    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTaskgroupPickFromReverseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeLTLTransactionParamObserver()
        subscribeObservers()
        return binding.root
    }

    private fun subscribeLTLTransactionParamObserver() {
        viewModel.ltlTransactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transVal == viewModel.ltlFLowEnabledKey) {
                                    Log.d("debug", "LTL Cubing Enabled")
                                    viewModel.isLTLCubingEnabled = true
                                    viewModel.getTaskGroups("30,31")
                                } else {
                                    Log.d("debug", "LTL Cubing Disabled")
                                    viewModel.isLTLCubingEnabled = false
                                    viewModel.getTaskGroups("11,30,31")
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                viewModel.isLTLCubingEnabled = false
                                viewModel.getTaskGroups("11,30,31")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        viewModel.isLTLCubingEnabled = false
                        viewModel.getTaskGroups("11,30,31")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //set this flag to "false" initially. which will be used to enable "Stage button" after 1st task pick
        sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_FIRST_TASK_UNITPICKED, false).apply()

        binding.rsvTaskGroupDropDown.boolFoo.observe(viewLifecycleOwner) { selectedTaskGroup ->

            viewModel.getTaskGroupsList()?.firstOrNull { it.description == selectedTaskGroup }?.let { taskGroup ->
                    viewModel.orderType = null
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP, selectedTaskGroup).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, taskGroup.code).apply()
                    sharedPreferences.edit().putString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, taskGroup.allocationType).apply()

                viewModel.getConfiguredOrderTypes()?.takeIf { viewModel.isPickOrderTypeEnabled() && it.isNotEmpty() && it.contains(taskGroup.allocationType) }?.let {
                    when (taskGroup.allocationType) {
                        FROM_RESERVE_PICK -> {
                            val orderTypes = (sharedPreferences.getString(PCL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes() +
                                    sharedPreferences.getString(LTL_ORD_TYPES_PREFERENCE, null).orEmpty().toLookUpCodes()).distinctBy { it.lookupCode }
                            if (orderTypes.size > 1) {
                                val action = TivoTaskgroupsFragmentDirections.actionTaskGroupToOrderTypeSelection(FROM_RESERVE_PICK)
                                getNavigationController().navigate(action)
                            } else {
                                viewModel.orderType = orderTypes.getOrNull(0)?.lookupCode
                                callTaskPickAPI(true)
                            }
                        }
                        else -> callTaskPickAPI(true)
                    }
                } ?: callTaskPickAPI(true)
            }
        }

        getNavigationResult<String>(ORDER_TYPE_RESULT) { orderType ->
            viewModel.orderType = orderType
            callTaskPickAPI(true)
        }
    }

    private fun callTaskPickAPI(stageRequired: Boolean) {
        viewModel.tivoGetTaskPick(
            TaskPickReq(
                sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!,
                stageRequired,
                sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, null)!!,
                isLTLcubing = viewModel.isLTLCubingEnabled,
                orderType = viewModel.orderType
            )
        )
    }


    /**
     * method to subscribe observers
     */
    private fun subscribeObservers() {
        subscribeTransactionParamObserver()
        subscribeTaskGroupsObserver()
        subscribeTaskDetailsObserver()
    }

    /**
     * method to get transaction param info from API
     */
    private fun callTransactionParamAPI() {
        viewModel.getTransactionParam(
            TransactionParamRequest(
                cust_id = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                bu_id = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                fcy_id = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                trans_code = "PIA"
            )
        )
    }

    /**
     * method to subscribe Transaction param observer
     */
    private fun subscribeTransactionParamObserver() {
        viewModel.transactionParamResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { transactionParamResponse ->
                        if (transactionParamResponse.success) {
                            FlareLog.i(TAG, "TransactionParamResponse success: $transactionParamResponse")
                            if (!transactionParamResponse.noOfCases.isNullOrEmpty()) {
                                val noOfCases = transactionParamResponse.noOfCases[0]
                                if (noOfCases.transValDesc.equals("Prompt Item Attributes", true)) {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_PROMPT_ITEM_ATTRIBUTES, true).apply()
                                } else {
                                    sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                                }
                            } else {
                                showErrorSnackBar(resources.getString(R.string.transaction_param_error))
                                sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TransactionParamResponse error: $message")
                        showErrorSnackBar(message)
                        sharedPreferences.edit().putBoolean(PreferenceKeys.PickFromReserve.IS_PROMPT_ITEM_ATTRIBUTES, false).apply()
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe task group observer
     */
    private fun subscribeTaskGroupsObserver() {
        viewModel.taskGroupResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskGroupResponse ->
                        FlareLog.i(TAG, "TaskGrpResponse success: $taskGroupResponse")
                        val taskGroupDescList = ArrayList<String>()
                        val taskGroups = ArrayList<TaskGroup>()
                        taskGroupResponse.taskGroups?.forEach { lookup ->
                            taskGroupDescList.add(lookup.description)
                            taskGroups.add(lookup)
                        }
                        viewModel.settaskGroupCodeOptions(taskGroupDescList)
                        viewModel.setTaskGroupsList(taskGroups)
                        binding.rsvTaskGroupDropDown.setOptions(taskGroupDescList)
                        callTransactionParamAPI()
                    }
                }

                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "TaskGrpResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }

                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    /**
     * method to subscribe task details observer
     */
    private fun subscribeTaskDetailsObserver() {
        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { taskpickResponse ->
                        if (taskpickResponse.success!!) {
                            FlareLog.i(TAG, "taskPickResponse success: $taskpickResponse")
                            if (taskpickResponse.taskDetails == null) {
                                showErrorSnackBar(taskpickResponse.message!!)

                            } else {
                                viewModel.setPickTaskDetails(taskpickResponse.taskDetails)
                                //Set the task Id for duplicate loop check and restrict.
                                viewModel.setTaskId(taskpickResponse.taskDetails.taskId)
                                viewModel.setOrderId(taskpickResponse.taskDetails.orderId)
                                viewModel.setCustomerOrderNumber(taskpickResponse.taskDetails.customerOrderNumber)
                                when (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null)!!) {
                                    "11" -> {
                                        if (taskpickResponse.taskDetails.taskStatus == 35) {
                                            showStagePendingAlert()
                                        } else {
                                            moveToNextTask()
                                        }
                                    }
                                    "30" -> {
                                        if (taskpickResponse.taskDetails.stageLocationName.isNullOrEmpty()) {
                                            noStageLocationDetailsError(taskpickResponse.taskDetails)
                                        } else {
                                            // navigate to Full Pallet Pick Page
                                            val action =
                                                TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToFullPalletPickFromReservePalletPage()
                                            getNavigationController().navigate(action)
                                        }
                                    }
                                    "31" -> {
                                            // navigate to Full Pallet Pick Page
                                            val action =
                                                TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToFullPalletPickFromReservePalletPage()
                                            getNavigationController().navigate(action)
                                    }
                                    /*"30" -> {
                                        if (taskpickResponse.taskDetails.taskStatus == 35){
                                            showStagePendingAlert()
                                        } else {
                                            val serialTracked = taskpickResponse.taskDetails.itemSerialTracked
                                            val uom = taskpickResponse.taskDetails.taskQtyUom!!.toLowerCase()
                                            val isLotTracked = taskpickResponse.taskDetails.itemLotTracked
                                            val isExpiredTracked = taskpickResponse.taskDetails.itemExpDateTracked


                                            val action =
                                                if ((serialTracked == "1" && uom == "pallets") || (serialTracked == "0" && uom == "pallets") || (serialTracked == "4" && uom == "pallets")) {
                                                    TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToPalletSerialNumberTwoTivoPickFromFragment()

                                                } else if ((serialTracked == "1" && uom == "cases") || (serialTracked == "0" && uom == "cases") || (serialTracked == "4" && uom == "cases")) {
                                                    TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToContainerSerialNumberTivoPickFromFragment()

                                                } else if (isLotTracked != "0") {
                                                    TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToLotNumberTivoPickFromFragment()

                                                } else if (isExpiredTracked != "0") {
                                                    TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToExpiryDateTivoPickFromFragment()

                                                } else {
                                                    showErrorSnackBar(getString(R.string.alert_task_completed))
                                                    null
                                                }
                                            action?.let { moveToFragment(it) }
                                        }
                                    }*/
                                }
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "taskPickResponse Error: $message")
                        showErrorSnackBar(message)

                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        viewModel.reservePickStageResponse.observe(viewLifecycleOwner) { reservePickStageResponse ->
            when (reservePickStageResponse) {
                is Resource.Success -> {
                    hideProgressBar()
                    reservePickStageResponse.data?.let { response ->
                        if (response.success) {
                            if (response.taskDetails == null) {
                                showSuccessSnackBar(response.message)
                            } else {
                                viewModel.setStageTaskDetails(response.taskDetails)
                                val action = TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.TivoALTYP11StagingLocation, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        } else {
                            FlareLog.e(TAG, "reservePickStageResponse error: ${response.message}")
                            showErrorSnackBar(response.message)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    reservePickStageResponse.message?.let { message ->
                        FlareLog.e(TAG, "reservePickStageResponse error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }


    /**
     * method to show progressbar
     */
    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    /**
     * method to hide progressbar
     */
    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun noStageLocationDetailsError(taskDetails: TaskDetails) {

        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        val msg = getString(R.string.stage_location_not_added, taskDetails.taskId.toString(), taskDetails.customerOrderNumber.toString())
        builder.setTitle("")
        builder.setMessage(msg)

        builder.setPositiveButton(resources.getString(R.string.alert_button_ok)) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")

    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    private fun showStagePendingAlert() {
        val builder = MaterialAlertDialogBuilder(fragmentContext, R.style.AlertDialogTheme)
        builder.setTitle("")
        builder.setMessage(getString(R.string.ltl_stage_pending_task_alert_message))

        builder.setPositiveButton(resources.getString(R.string.stage_go)) { dialogInterface, _ ->
            dialogInterface.dismiss()
            viewModel.reservepickstage()
        }

        builder.setNegativeButton(resources.getString(R.string.button_continue)) { dialogInterface, _ ->
            dialogInterface.dismiss()
//            moveToNextTask()
            callTaskPickAPI(false)
        }

        val alertDialog: MaterialAlertDialogBuilder = builder
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun moveToNextTask() {
        val action = TivoTaskgroupsFragmentDirections.actionTaskGroupFragmentToLocationFragment()
        getNavigationController().navigate(action)
    }
}