package com.fsc.flare.ui.fragment.labelsanddocuments

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPrintEntitySelectBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.labelsanddocuments.ValidateInputRequest
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "PrintEntitySelect"

/**
 * A simple [PrintEntityFragment] subclass.
 */
@AndroidEntryPoint
class PrintEntityFragment : BaseFragment() , FlareScannable {

    private lateinit var binding: FragmentPrintEntitySelectBinding
    private val viewModel: LabelsAndDocumentsViewModel by activityViewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        if (viewModel.getEntityDescList() != null) {
            binding.printEntityDropDown.setOptions(viewModel.getEntityDescList())
        }
        cb1.onVisibilityChange(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getPrintEntity()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentPrintEntitySelectBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val printerConfig = viewModel.getPrinterConfigs()
        if (printerConfig != null) {
            binding.printRequesterValueTv.text = printerConfig[0].requestor
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    if (binding.entityNumberEt.isFocused && !binding.entityNumberEt.text.isNullOrEmpty()) {
                        FlareLog.i(TAG, "entityNumberEt field focused")
                        validateInputForPrinting()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.entityNumberEt.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.entityNumberEt)
                FlareLog.i(TAG, "entityNumberEt field focused")
                validateInputForPrinting()
            }
            false
        }

    }

    private fun validateInputForPrinting() {
        if (!binding.entityNumberEt.text.isNullOrEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.entityNumberEt)
            val printEntitiesList = viewModel.getEntityList()
            printEntitiesList.forEach { lookUp ->
                lookUp.lookupCodes.forEach { lookupcode ->
                    if (lookupcode.lookupCodeDescription == sharedPreferences.getString(PreferenceKeys.LD_PRINT_ENTITY, null)) {
                        viewModel.validateInputForPrinting(
                            ValidateInputRequest(
                                lookupcode.lookupCode,
                                binding.entityNumberEt.text.toString(),
                                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            )
                        )
                    }
                }
            }
        }
    }

    private fun subscribeObservers() {
        viewModel.printEntityResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { lookUpResponse ->
                        FlareLog.i(TAG, "lookUp success: $lookUpResponse")
                        val entityDescList = ArrayList<String>()
                        lookUpResponse.lookups.forEach { lookUp ->
                            lookUp.lookupCodes.forEach {
                                entityDescList.add(it.lookupCodeDescription)
                            }
                        }
                        viewModel.setEntityDescList(entityDescList)
                        viewModel.setEntityList(lookUpResponse.lookups)
                        binding.printEntityDropDown.setOptions(entityDescList)
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "lookUpResponse Error: $message")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }

        binding.printEntityDropDown.boolFoo.observe(viewLifecycleOwner) { isSelected ->
            val printEntitiesList = viewModel.getEntityList()
            printEntitiesList.forEach { lookUp ->
                lookUp.lookupCodes.forEach { lookupcode ->
                    if (lookupcode.lookupCodeDescription == isSelected) {
                        binding.entityNumberTv.visibility = View.VISIBLE
                        binding.entityNumberEt.visibility = View.VISIBLE
                        sharedPreferences.edit().putString(PreferenceKeys.LD_PRINT_ENTITY, isSelected).apply()
                        binding.entityNumberTv.text = String.format("%s Number",isSelected)
                    }
                }
            }
        }

        viewModel.printInputResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { printInputResponse ->
                        FlareLog.i(TAG, "printInputResponse success: $printInputResponse")
                        if (printInputResponse.success) {
                            viewModel.setInput(printInputResponse)
                            binding.entityNumberEt.text = null
                            val action = if (printInputResponse.internationalShipDocsRequired == true)
                                    PrintEntityFragmentDirections.actionLdPrintEntitySelectToInternationalDocumentsPrint()
                                else
                                    PrintEntityFragmentDirections.actionLdPrintEntitySelectToPrintLabelsAndDocuments()
                            findNavController().navigate(action)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "printInputResponse Error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        }
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
                binding.entityNumberEt.setText(scan?.barcode.toString())
                binding.entityNumberEt.text?.length?.let {
                    binding.entityNumberEt.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "Container field focused")
                    validateInputForPrinting()
                }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScan Error: $scanRaw")
    }
}