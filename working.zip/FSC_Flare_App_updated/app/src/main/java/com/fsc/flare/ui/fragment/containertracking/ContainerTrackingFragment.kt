package com.fsc.flare.ui.fragment.containertracking


import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentContainerTrackingBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.containertracking.screenconfig.ScreenConfigReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingBaseReq
import com.fsc.flare.source.data.dto.containertracking.senddetails.SendContainerTrackingReq
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject


private const val TAG = "ContainerTrackingFragment"

@AndroidEntryPoint
class ContainerTrackingFragment : BaseFragment(), FlareScannable {

    private val viewModel: ContainerTrackingViewModel by viewModels()
    private lateinit var binding: FragmentContainerTrackingBinding
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault())
    var isContainerAvailable = false
    lateinit var cb1: CustomVisibilityCallback


    @Inject
    lateinit var sharedPreferences: SharedPreferences


    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getScreenConfigAPICAll()
        subscribeObservers()


        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(fragmentContext, binding.rootLayout)
                    clickListeners()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etContainerId.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                clickListeners()
            }
            false
        }

        binding.etChannelId.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                clickListeners()
            }
            false
        }

    }


    private fun clickListeners(){
        if (binding.etChannelId.isVisible && binding.etContainerId.isFocused && !binding.etContainerId.text.isNullOrEmpty()) {
            FlareLog.i(TAG, "ChannelId field focused")
            containerTrackingAPICall()
        } else if (!binding.etChannelId.isVisible && binding.etContainerId.isFocused && !binding.etContainerId.text.isNullOrEmpty()) {
            //don't call container tracking api, directly call submit
            containerTrackingAPICall()

        } else if (binding.etChannelId.isVisible
            && binding.etChannelId.isFocused
            && !binding.etChannelId.text.isNullOrEmpty()
            && !binding.etContainerId.text.isNullOrEmpty()
        ) {

            //don't call container tracking api, as it is called
            //This will be post, after you added container
            //call submit directly
            sendContainerTrackingAPICall()
        }
    }
    private fun subscribeObservers() {
        screenConfigAPIObserver()
        containerTrackingAPIObserver()
        sendContainerTrackingAPIObserver()

        viewModel.noNetworkUpdate.observe(viewLifecycleOwner) { response ->
            if (response != null) {
                hideProgressBar()
                showErrorSnackBar(resources.getString(R.string.network_connect_failure))
            }
        }
    }

    fun screenConfigAPIObserver() {
        viewModel.screenConfigRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { screenConfigRes ->
                        FlareLog.i(TAG, "screenConfig response: $response")
                        when (screenConfigRes.statusHandler.statusCode) {
                            "500" -> {
                                //Show error
                                FlareLog.e(
                                    TAG, "screenConfigRes Error : $screenConfigRes.statusHandler.error"
                                )
                                showErrorSnackBar(screenConfigRes.statusHandler.error)

                            }
                            "200" -> {
                                FlareLog.i(
                                    TAG, "screenConfigRes success : $response.data"
                                )
                                if (response.data.screenConfigDomains.isNotEmpty()) {
                                    when (response.data.screenConfigDomains[0].sccShow) {
                                        "Y" -> {
                                            binding.grpChannelId.visibility = View.VISIBLE
                                        }
                                        else -> {
                                            binding.grpChannelId.visibility = View.GONE
                                        }
                                    }
                                }
                            }
                            else ->
                                FlareLog.e(TAG, "screenConfigRes error: ${response.data.statusHandler.message}")
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "screenConfigRes error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    fun containerTrackingAPIObserver() {
        viewModel.containerTrackingRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        FlareLog.i(TAG, "ContainerTracking success: $containerResponse")
                        if (containerResponse.success && containerResponse.containerTracking != null) {
                            isContainerAvailable = true
                            containerResponse.containerTracking.startTime.let {
                                binding.etStartTime.setText(it)
                            }
                            containerResponse.containerTracking.endTime.let {
                                binding.etEndTime.setText(it)
                            }
                            containerResponse.containerTracking.channelId.let {
                                binding.etChannelId.setText(it)
                            }

                            /* If you get the record from the get API call (your trigger will be container field itself)
                             display the channel Id(if exists based on the screen config), start time and end time and immediately submit the transaction (POST call with container track id in request to update the record.)
                             upon success transaction you should show the message that “com.fsc.flare.source.data.dto.inventoryadjustment.res.Container xxxxxx ended. */
                            //Here we dont need to show end time for a sec, as end time is already set
                            sendContainerTrackingAPICall(containerResponse.containerTracking.cntTrackId)

                        } else {
                            isContainerAvailable = false
                            binding.etChannelId.requestFocus()

                            //take user input for channeled and set the start time as current time and submit the transaction(This is a new record you will not be having any Id).
                            //showErrorSnackBar(response.data.errors.errorMessage)
                            binding.etStartTime.setText(getCurrentTime())
//                            binding.etStartTime.setText(Utility.getDateTimeInGMT("yyyy-MM-dd HH:mm:ss"))
                            //Dont show the end time, if container ID response is null, as we don't have end time at all, submit without end time
//                            binding.etEndTime.setText(getCurrentTime())

                            if (!binding.etChannelId.isVisible && binding.etContainerId.isFocused && !binding.etContainerId.text.isNullOrEmpty()) {
                                //don't call container tracking api, directly call submit
                                sendContainerTrackingAPICall()

                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.i(TAG, "ContainerTracking error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    fun sendContainerTrackingAPIObserver() {
        viewModel.containerTrackingSubmitRes.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { containerResponse ->
                        FlareLog.i(TAG, "containerTrackingSubmit response: $response")
                        if (containerResponse.success) {
                            FlareLog.i(TAG, "containerTrackingSubmit success: $containerResponse")
                            if (isContainerAvailable) {
                                binding.txtContainerIdRes.text =
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${getString(R.string.lbl_end)}."
                                showSuccessSnackBar(
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${
                                    getString(
                                        R.string.lbl_end
                                    )
                                    }."
                                )
                            } else if (!isContainerAvailable && binding.etChannelId.isVisible) {
                                binding.txtContainerIdRes.text =
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${getString(R.string.lbl_start)}."
                                showSuccessSnackBar(
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${
                                    getString(
                                        R.string.lbl_start
                                    )
                                    }."
                                )
                            } else if (!isContainerAvailable && !binding.etChannelId.isVisible) {
                                binding.txtContainerIdRes.text =
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${getString(R.string.lbl_start)}."
                                showSuccessSnackBar(
                                    "${getString(R.string.lbl_cont)} ${containerResponse.containerTracking.containerNumber} ${
                                    getString(
                                        R.string.lbl_start
                                    )
                                    }."
                                )
                            }
                            reInitFieldsAfterSubmit()
                        } else {
                            FlareLog.e(TAG, "containerTrackingSubmit error: ${response.data.errors.errorMessage}")
                            showErrorSnackBar(response.data.errors.errorMessage)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "containerTrackingSubmit error: $message")
                        showErrorSnackBar(message)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun reInitFieldsAfterSubmit() {
        with(binding) {
            this.etChannelId.setText("")
            this.etEndTime.setText("")
            this.etStartTime.setText("")
            this.etContainerId.setText("")
            binding.etContainerId.requestFocus()
        }
    }

    private fun getScreenConfigAPICAll() {
        viewModel.getScreenConfig(
            ScreenConfigReq(
                program = "CTR",
                cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                whsId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                deletedFlag = "N",
            )
        )
    }

    private fun sendContainerTrackingAPICall(aCntTrackId: Int? = null) {
        binding.txtContainerIdRes.text = ""
        //If container id already available, and you are adding that id for post request, show the end time, and send it
        //End time will be passed only when there is a record
        //Check if that has the end time already, then don't set it
        if (isContainerAvailable && binding.etEndTime.text.isNullOrEmpty()) {
//            binding.etEndTime.setText(Utility.getDateTimeInGMT("yyyy-MM-dd HH:mm:ss"))
            binding.etEndTime.setText(getCurrentTime())
        }

        viewModel.sendContainerTracking(
            SendContainerTrackingBaseReq(
                containerTracking = SendContainerTrackingReq(
                    cntTrackId = aCntTrackId,
                    cutomer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                    businessUnit = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                    facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                    containerNumber = binding.etContainerId.text.toString(),
                    channelId = binding.etChannelId.text.toString(),
                    startTime = binding.etStartTime.text.toString(),
                    endTime = if (!binding.etEndTime.text.isNullOrEmpty()) binding.etEndTime.text.toString() else null,
                    user = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1).toString(),
                )
            )
        )
        //Show End time for a second...
        //binding.etEndTime.setText(getCurrentTime())
    }

    fun getCurrentTime() = sdf.format(Date())

    fun containerTrackingAPICall() {
        binding.txtContainerIdRes.text = ""
        viewModel.getContTracking(
            GetContDetailRequest(
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
                buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                containerNbr = binding.etContainerId.text.toString(),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
                includeCCLocation = if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)) "Y" else "N")
            )
    }

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentContainerTrackingBinding.inflate(inflater, container, false)
        binding.containerTrackingViewModel = viewModel
        binding.lifecycleOwner = this
        return binding.root
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.INVISIBLE
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        when {
            //FLOW 1
            binding.etChannelId.isVisible && binding.etContainerId.isFocused -> {
                binding.etContainerId.setText(scan?.barcode.toString())
                binding.etContainerId.text?.length?.let {
                    binding.etContainerId.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ChannelId field focused")
                    containerTrackingAPICall()
                }
            }
            //FLOW 3
            !binding.etChannelId.isVisible && binding.etContainerId.isFocused -> {
                //don't call container tracking api, directly call submit
                binding.etContainerId.setText(scan?.barcode.toString())
                binding.etContainerId.text?.length?.let {
                    binding.etContainerId.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ChannelId field focused")
                    containerTrackingAPICall()
                }


            }
            //FLOW 2
            binding.etChannelId.isVisible
                    && binding.etChannelId.isFocused

            -> {

                //don't call container tracking api, as it is called
                //call submit directly
                binding.etChannelId.setText(scan?.barcode.toString())
                binding.etChannelId.text?.length?.let {
                    binding.etChannelId.setSelection(
                        it
                    )
                    FlareLog.i(TAG, "ChannelId field focused")
                    sendContainerTrackingAPICall()
                }
            }
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.i(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}