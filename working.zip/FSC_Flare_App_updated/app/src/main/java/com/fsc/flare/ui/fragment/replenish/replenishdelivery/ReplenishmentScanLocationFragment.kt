package com.fsc.flare.ui.fragment.replenish.replenishdelivery

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentReplenFromLocationBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.replenishment.ReplenishDeliveryTask
import com.fsc.flare.source.repository.REPLENISH_DELIVERY_TASK_TYPE
import com.fsc.flare.ui.fragment.receiving.CASE
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ReplenishmentScanLocationFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var binding: FragmentReplenFromLocationBinding
    private val sharedViewModel: ReplenishmentDeliverySharedViewModel by activityViewModels()
    private val currentTask: ReplenishDeliveryTask? by lazy { sharedViewModel.task }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReplenFromLocationBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initScreenUI()
        binding.tvHeaderTitle.text = sharedPreferencesBase.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.etFromLocation.doAfterTextChanged { binding.tvErrorMessage.text = null }
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    validateFromLocation()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.etFromLocation.setOnEditorActionListener { _, actionId, event ->
            if (event?.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                validateFromLocation()
            }
            false
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initScreenUI() {
        currentTask?.let {
            binding.tvPalletOrContainerTitle.text =
                if (it.taskContainer == CASE)
                    getString(R.string.container_label)
                else
                    getString(R.string.lbl_pallet_colon)
            binding.tvPalletOrContainer.text = it.containerNbr
            binding.tvTaskNumber.text = "${it.taskId}"
            binding.tvTaskType.text =
                if (it.taskType == REPLENISH_DELIVERY_TASK_TYPE)
                    getString(R.string.replenishment_delivery)
                else
                    it.taskType
            binding.tvReplenishQty.text = "${it.taskQty} ${it.taskQtyUom}"
            binding.tvFromLocation.text = it.locationBarcode
        }
    }

    override fun onScan(scan: Scan?) {
        super.onScan(scan)
        FlareLog.i(screenName, "onScan: $scan")
        if (binding.progressBar.visibility == View.VISIBLE)
            return
        val barCode = scan?.barcode.toString().trim()
        binding.etFromLocation.setText(barCode)
        binding.etFromLocation.text?.length?.let {
            binding.etFromLocation.setSelection(it)
        }
        validateFromLocation()
    }

    private fun validateFromLocation() {
        hideSoftKeyBoard(requireContext(), binding.etFromLocation)
        val inputString = binding.etFromLocation.text.toString().trim()
        if (inputString == currentTask?.locationBarcode) {
            binding.tvErrorMessage.text = null
            val action = ReplenishmentScanLocationFragmentDirections.actionScanFromLocationToDeliveryLocation()
            findNavController().navigate(action)
        } else {
            binding.tvErrorMessage.text = getString(R.string.lbl_invalid_location)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(screenName, "onScanError: $scanRaw")
    }
}