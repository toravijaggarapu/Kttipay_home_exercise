package com.fsc.flare.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.fsc.flare.database.entities.RFlog
import kotlinx.coroutines.flow.Flow

@Dao
interface FlareDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: RFlog)

    @Query("select * from rfLog ORDER BY createdOn DESC LIMIT :limitNumber")
    fun getRequestedLogs(limitNumber: Int): Flow<List<RFlog>>

    @Delete
    suspend fun deleteLogs(log: List<RFlog>)
}