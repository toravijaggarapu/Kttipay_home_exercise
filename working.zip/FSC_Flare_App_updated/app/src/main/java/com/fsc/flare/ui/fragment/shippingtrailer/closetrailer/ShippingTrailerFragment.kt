package com.fsc.flare.ui.fragment.shippingtrailer.closetrailer

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentShippingTrailerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.ui.fragment.shippingtrailer.ShippingTrailerViewModel
import com.fsc.flare.utils.PreferenceKeys
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "ShippingTrailerFragment"

/**
 * [ShippingTrailerFragment] class.
 */
@AndroidEntryPoint
class ShippingTrailerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    private val viewModel: ShippingTrailerViewModel by activityViewModels()
    private lateinit var binding: FragmentShippingTrailerBinding

    lateinit var cb1: CustomVisibilityCallback

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )

        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentShippingTrailerBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.tvShipping.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        binding.trailerEt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.trailerResponse.text = null
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (binding.trailerEt.isFocused && !binding.trailerEt.text.isNullOrEmpty()) {
                        hideSoftKeyBoard(fragmentContext, binding.trailerEt)
                        if(binding.trailerEt.text.toString() == binding.trailer.text.toString()){
                            binding.trailerEt.text = null
                            val navController =
                                Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                            val action = ShippingTrailerFragmentDirections.actionShippingTrailerFragmentToShippingSealNumberFragment()
                            navController.navigate(action)
                        } else {
                            binding.trailerResponse.text = resources.getString(R.string.lbl_trailer_number_mismatch)
                            binding.trailerEt.selectAll()
                            showSoftKeyBoard(fragmentContext, binding.trailerEt)
                        }
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        binding.trailerEt.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(fragmentContext, binding.trailerEt)
                FlareLog.i(TAG, "trailerEt field focused")
                if(binding.trailerEt.text.toString() == binding.trailer.text.toString()){
                    binding.trailerEt.text = null
                    val navController =
                        Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                    val action = ShippingTrailerFragmentDirections.actionShippingTrailerFragmentToShippingSealNumberFragment()
                    navController.navigate(action)
                } else {
                    binding.trailerResponse.text = resources.getString(R.string.lbl_trailer_number_mismatch)
                    binding.trailerEt.selectAll()
                    showSoftKeyBoard(fragmentContext, binding.trailerEt)
                }
            }
            false
        }
        val data = viewModel.getDockDoorShipment()
        if(data != null){
            binding.shipment.text = data.shipmentNumber
            binding.trailer.text = data.trailerNbr
            binding.dockdoor.text = sharedPreferences.getString(PreferenceKeys.Shipping.DD_NUMBER, "")
        }
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
            sharedPreferences.edit().apply {
                sharedPreferences.edit().putString(PreferenceKeys.Item.DD_NUMBER, scan?.barcode.toString()).apply()
            }
            binding.trailerEt.setText(scan?.barcode.toString())
            binding.trailerEt.text?.length?.let {
                binding.trailerEt.setSelection(
                    it
                )
            }
            if(binding.trailerEt.text.toString() == binding.trailer.text.toString()){
                binding.trailerEt.text = null
                val navController =
                    Navigation.findNavController(requireActivity(), R.id.nav_host_fragment)
                val action = ShippingTrailerFragmentDirections.actionShippingTrailerFragmentToShippingSealNumberFragment()
                navController.navigate(action)
            } else {
                binding.trailerResponse.text = resources.getString(R.string.lbl_trailer_number_mismatch)
                binding.trailerEt.selectAll()
                showSoftKeyBoard(fragmentContext, binding.trailerEt)
            }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }
}