package com.fsc.flare.ui.fragment.pickingforward

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavOptions
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.AlertDialogClickListener
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentBuildCartPalletBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.enumeration.AllocationType
import com.fsc.flare.source.data.dto.pickingforward.req.EndPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.TaskPickCartReq
import com.fsc.flare.source.data.dto.pickingforward.req.WorkOrderDetailsReq
import com.fsc.flare.source.data.dto.pickingforward.res.TaskDetails
import com.fsc.flare.source.data.dto.pickingforward.res.TaskPickResponse
import com.fsc.flare.source.data.dto.pickingforward.res.WorkOrderDetails
import com.fsc.flare.utils.Constants.Companion.IS_RTV
import com.fsc.flare.utils.PreferenceKeys
import com.fsc.flare.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private const val TAG = "BuildCartPalletFragment"

@AndroidEntryPoint
class BuildCartPalletFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    private val viewModel: PickingForwardViewModel by activityViewModels()
    lateinit var binding: FragmentBuildCartPalletBinding
    lateinit var cb1: CustomVisibilityCallback
    private var workOrderNumberList = ArrayList<String>()
    private var workOrderDetailsHashmap = HashMap<String, WorkOrderDetails>()
    private var workOrderID :String? = null

    override fun onResume() {
        val actionBar = (activity as AppCompatActivity).supportActionBar
        actionBar?.title = sharedPreferences.getString(PreferenceKeys.CUST_CODE, null) + " - " + sharedPreferences.getString(
            PreferenceKeys.FEDEX_ID,
            null
        )
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentBuildCartPalletBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        viewModel.isRTV = arguments?.getBoolean(IS_RTV) ?: viewModel.isRTV

        binding.tvPickForward.text = sharedPreferences.getString(PreferenceKeys.SUB_MENU_SELECTED, null)
        subscribeObservers()
        return binding.root
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "12" || sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "21") {
            binding.workOrderDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
                val selectedWorkOrder = workOrderDetailsHashmap.get(selection)
                workOrderID = selectedWorkOrder?.orderId
                binding.etCartPallet.isEnabled = true
                binding.etCartPallet.alpha = 1f
            }
        }

        if (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "12" || sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "21") {
            binding.workOrderDropDown.boolFoo.observe(viewLifecycleOwner) { selection ->
                val selectedWorkOrder = workOrderDetailsHashmap.get(selection)
                workOrderID = selectedWorkOrder?.orderId
                binding.etCartPallet.isEnabled = true
                binding.etCartPallet.alpha = 1f
            }
        }

        binding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    FlareLog.i(TAG, "CartPallet field focused")
                    getTaskPickCart()
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        if (sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "12" || sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, null) == "21") {
            binding.workOrderSelectionLayout.visibility = View.VISIBLE
            binding.etCartPallet.alpha = 0.25f
            binding.etCartPallet.isEnabled = false
            getWorkOrderDetails()

        } else {
            binding.workOrderSelectionLayout.visibility = View.GONE
            binding.etCartPallet.isEnabled = true
            binding.etCartPallet.alpha = 1f
        }

        binding.etCartPallet.setOnEditorActionListener { v, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                FlareLog.i(TAG, "CartPallet field focused")
                getTaskPickCart()
            }
            false
        }
        binding.etCartPallet.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                binding.txtCartPalletRes.text = ""
            }
        })
    }

    private fun getWorkOrderDetails() {
        viewModel.getWorkOrderDetails(
            WorkOrderDetailsReq(
                allocationType =  sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")!!,
                buId =  sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                taskGroup = sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, "")!!,
                assignedTo = sharedPreferences.getInt(PreferenceKeys.USER_ID, -1)
            )
        )
    }

    private fun subscribeObservers() {
        viewModel.workOrderDetailsResponse.observe(viewLifecycleOwner){response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { assignedWorkOrdersResponse ->
                        FlareLog.i(TAG, "assignedWorkOrdersResponse: $response")
                        if (assignedWorkOrdersResponse.success != null && assignedWorkOrdersResponse.success) {
                            FlareLog.i(TAG, "assignedWorkOrdersResponse success: $assignedWorkOrdersResponse")
                            if (!assignedWorkOrdersResponse.workOrderTasksProjection.isNullOrEmpty()) {

                                if(assignedWorkOrdersResponse.workOrderTasksProjection.size>1)
                                {
                                    assignedWorkOrdersResponse.workOrderTasksProjection.forEach {
                                        workOrderNumberList.add(it.customerWorkOrderNumber)
                                        workOrderDetailsHashmap.put(it.customerWorkOrderNumber, it)
                                    }
                                    binding.workOrderDropDown.setOptions(workOrderNumberList)
                                }else
                                {
                                    assignedWorkOrdersResponse.workOrderTasksProjection.forEach {
                                        workOrderNumberList.add(it.customerWorkOrderNumber)
                                        workOrderDetailsHashmap.put(it.customerWorkOrderNumber, it)
                                    }
                                    binding.workOrderDropDown.setOptions(workOrderNumberList)
                                    binding.workOrderDropDown.isEnabled = false
                                    binding.workOrderDropDown.setSelectedValue(workOrderNumberList[0])
                                    binding.etCartPallet.isEnabled = true
                                    binding.etCartPallet.alpha = 1f
                                }
                            }else
                            {
                                showErrorSnackBar("Work Order details not found")
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        FlareLog.e(TAG, "assignedWorkOrdersResponse error: $message")
                      //  binding.txtCartPalletRes.text = message
                        showErrorSnackBar(message)
                       // showSoftKeyBoard(fragmentContext, binding.etCartPallet)
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
        observeTaskPickResponse()

        viewModel.endPickCartResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { endPickCartResponse ->
                        FlareLog.i(TAG, "endPickCart Response: $response")
                        if (endPickCartResponse.success != null && endPickCartResponse.success) {
                            FlareLog.i(TAG, "endPickCart success: $endPickCartResponse")
                            if (endPickCartResponse.taskDetails != null) {
                                viewModel.updateOrderType(endPickCartResponse.orderType)
                                viewModel.setPickTaskDetails(endPickCartResponse.taskDetails)
                                val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToPickCartLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickCartLocationFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            } else if (endPickCartResponse.promptStage != null && endPickCartResponse.promptStage) {
                                val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToPickingStagingLocationFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.pickingStagingLocationFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            } else {
                                val action = BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                                val navOptions = NavOptions.Builder().setPopUpTo(R.id.buildCartToteFragment, true).build()
                                getNavigationController().navigate(action, navOptions)
                            }
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        if(message.contains("##")) {
                            val msgArray = message.split("##")
                            if (msgArray.isNotEmpty()) {
                                FlareLog.e(TAG, "endPickCart error: ${msgArray[1]}")
                                showErrorSnackBar(msgArray[1])
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }
        }
    }

    private fun observeTaskPickResponse() {
        viewModel.taskPickResponse.observe(viewLifecycleOwner) { response ->
            when (response) {
                is Resource.Success -> handleSuccess(response)
                is Resource.Error -> handleError(response.message)
                is Resource.Loading -> showProgressBar()
            }
        }
    }

    private fun handleSuccess(response: Resource.Success<TaskPickResponse>) {
        hideProgressBar()
        response.data?.let { taskReplenResponse ->
            FlareLog.i(TAG, "taskPick Response: $response")
            if (taskReplenResponse.success == true) {
                processSuccessfulResponse(taskReplenResponse)
            } else if (taskReplenResponse.cartIsReadyToEnd) {
                if (viewModel.isRTV) {
                    /* when a user enters the cart number which is already in the staging location, an error message should be displayed.
                     This is because the RTV build option does not allow the user to perform picking
                    */
                    showErrorSnackBar(getString(R.string.show_error_msg_for_rtv))
                } else {
                    viewModel.setPickTask(taskReplenResponse)
                    showEndCartDialog(taskReplenResponse.cartId)
                }
            }
        }
    }

    private fun processSuccessfulResponse(taskPickResponse: TaskPickResponse) {
        FlareLog.i(TAG, "taskPick success: $taskPickResponse")

        taskPickResponse.cartNbr?.let {
            viewModel.setPickTask(taskPickResponse)
            taskPickResponse.taskDetails?.let { details ->
                viewModel.setPickTaskDetails(details)
                navigateToNextFragment(details)
            }
        }
    }

    private fun navigateToNextFragment(taskDetails: TaskDetails?) {
        taskDetails?.let {
            val allocationTypeCode = it.allocationType
            val action = when (allocationTypeCode) {
                AllocationType.ALLOCATED_FROM_ACTIVE.code,
                AllocationType.ALLOCATED_FROM_ACTIVE_LTL_AND_TL.code,
                AllocationType.PICK_FROM_ACTIVE.code,
                AllocationType.PICK_FROM_ACTIVE_RTV.code,
                AllocationType.PICK_FROM_QUARANTINE_ACTIVE_RTV.code ->
                    BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToBuildCartToteFragment()
                else ->
                    BuildCartPalletFragmentDirections.actionBuildCartPalletFragmentToPickCartPickLocationFragment()
            }
            getNavigationController().navigate(action)
        }
    }

    private fun handleError(response: String?) {
        hideProgressBar()
        response.let { message ->
            FlareLog.e(TAG, "taskPick error: $message")
            binding.txtCartPalletRes.text = message
            binding.etCartPallet.selectAll()
            showSoftKeyBoard(fragmentContext, binding.etCartPallet)
        }
    }

    private fun getTaskPickCart() {
        if (binding.etCartPallet.text.toString().trim().isNotEmpty()) {
            hideSoftKeyBoard(fragmentContext, binding.etCartPallet)
            val containerType = viewModel.validateContainerType(sharedPreferences, "Cart")
            val containerNumber = binding.etCartPallet.text.toString().trim()
            if (containerType != null && (!containerNumber.startsWith(containerType.ctyId!!) || containerNumber.length != containerType.ctyContainerLength!!.toInt())) {
                binding.txtCartPalletRes.text =
                    getString(R.string.cart_prefix_length_validation, containerType.ctyId, containerType.ctyContainerLength)
            } else {
                val allocationType = when {
                    viewModel.isRTV -> sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, null)!!
                    else -> sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "")!!
                }
                val taskGroupCode = when {
                    viewModel.isRTV -> sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_CODE, null)!!
                    else -> sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_CODE, "")!!
                }
                viewModel.getTaskPickCart(
                    TaskPickCartReq(
                        allocationType,
                        sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
                        sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                        sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                        taskGroupCode,
                        binding.etCartPallet.text.toString().trim(),
                        isLTLcubing = viewModel.isLTLCubingEnabled,
                        orderId = workOrderID,
                        orderType = viewModel.orderType
                    )
                )
            }
        } else {
            binding.txtCartPalletRes.text = getString(R.string.cart_pallet_required)
        }
    }

    private fun showEndCartDialog(cartId: Int?) {
        showAlertDialog(
            getString(R.string.tasks_completed_in_cart_perform_end_cart_here),
            getString(R.string.end_cart),
            object : AlertDialogClickListener {
                override fun onPositiveButtonClick() {
                    val allocationType = when {
                        viewModel.isRTV -> sharedPreferences.getString(PreferenceKeys.RtvPicking.TASK_GROUP_ALLOCATION_TYPE, null).orEmpty()
                        else -> sharedPreferences.getString(PreferenceKeys.CycleCount.ACT_TASK_GROUP_ALLOCATION_TYPE, "").orEmpty()
                    }
                    viewModel.pickEndCart(
                        EndPickCartReq(
                            allocationType = allocationType.toInt(),
                            sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
                            sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
                            binding.etCartPallet.text.toString(),
                            cartId,
                            isLTLcubing = viewModel.isLTLCubingEnabled
                        )
                    )
                }

                override fun onNegativeButtonClick() {

                }
            })
    }

    private fun hideProgressBar() {
        binding.progressBar.visibility = View.GONE
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    private fun showProgressBar() {
        binding.progressBar.visibility = View.VISIBLE
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
    }

    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if(isProgressBarVisible()){
            return
        }
        binding.etCartPallet.setText(scan?.barcode.toString())
        binding.etCartPallet.text?.length?.let {
            binding.etCartPallet.setSelection(it)
        }
        FlareLog.i(TAG, "CartPallet field focused")
        getTaskPickCart()
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb1 = cb!!
        cb.onVisibilityChange(true)
    }
}