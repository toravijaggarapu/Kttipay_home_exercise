package com.fsc.flare.ui.fragment.partsreplacement

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.fedex.services.blazar.callbacks.CustomVisibilityCallback
import com.fedex.services.blazar.models.Scan
import com.fsc.flare.R
import com.fsc.flare.base.BaseFragment
import com.fsc.flare.databinding.FragmentPartsReplacementSourceContainerBinding
import com.fsc.flare.di.FlareScannable
import com.fsc.flare.log.FlareLog
import com.fsc.flare.source.data.dto.partsreplacement.response.Task
import com.fsc.flare.source.data.dto.partsreplacement.response.TaskDetail
import com.fsc.flare.utils.Constants
import com.fsc.flare.utils.PreferenceKeys
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

private val TAG = PartsReplacementSourceContainerFragment::class.java.simpleName.toString()

@AndroidEntryPoint
class PartsReplacementSourceContainerFragment : BaseFragment(), FlareScannable {

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    lateinit var serialListAdapter: PartsRepalcementSerialAdapter
    private lateinit var partsReplacemenSourceContainerBinding: FragmentPartsReplacementSourceContainerBinding
    private val viewModel: PartsReplacementViewModel by activityViewModels()
    lateinit var cb1: CustomVisibilityCallback
    lateinit var taskDetails: List<TaskDetail>
    lateinit var task: List<Task>
    var containerNumberList = mutableListOf<String>()
    private var containerList = ArrayList<String>()
    private var scannedSerial = ""

    override fun onPrepareMenu(menu: Menu) {
        menu.findItem(R.id.home)?.isVisible = true
        menu.findItem(R.id.logout)?.isVisible = true
        menu.findItem(R.id.account)?.isVisible = true
        super.onPrepareMenu(menu)
    }


    override fun onResume() {
        super.onResume()
        cb1.onVisibilityChange(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        partsReplacemenSourceContainerBinding =
            FragmentPartsReplacementSourceContainerBinding.inflate(inflater, container, false)
        partsReplacemenSourceContainerBinding.lifecycleOwner = this
        viewModel.resetSrcContainerNumber()
        return partsReplacemenSourceContainerBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetails = viewModel.getMoveTaskDetails()
        task = viewModel.getMoveTaskList()
        taskDetails.firstOrNull()?.let {
            with(partsReplacemenSourceContainerBinding) {
                tvStagingContainerValue.text = it.ibContainerNumber
                tvSourceLocationValue.text = it.sourceLocation
            }
        }
        addListeners()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addListeners() {
        if (viewModel.getMoveTaskDetails() != null) {
            containerNumberList = viewModel.getSrcContainerList()
            if (!viewModel.getSourceContianerList().isNullOrEmpty()) {
                containerList = viewModel.getSourceContianerList() as ArrayList<String>
                partsReplacemenSourceContainerBinding.tvContainerValue.text =
                    "(${containerNumberList.size}/${viewModel.getSourceContianerCount()})"
            }
            setupRecyclerView()
        }

        partsReplacemenSourceContainerBinding.tvSourceContainerEt.doAfterTextChanged {
            partsReplacemenSourceContainerBinding.errResponses.text = null
        }


        partsReplacemenSourceContainerBinding.rootLayout.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    hideSoftKeyBoard(
                        fragmentContext,
                        partsReplacemenSourceContainerBinding.etSourceContainer
                    )
                    if (partsReplacemenSourceContainerBinding.etSourceContainer.isFocused) {
                        validateStagingContainer()
                    }
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        partsReplacemenSourceContainerBinding.etSourceContainer.setOnEditorActionListener { _, actionId, event ->
            if (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER || actionId == EditorInfo.IME_ACTION_DONE) {
                hideSoftKeyBoard(
                    fragmentContext,
                    partsReplacemenSourceContainerBinding.etSourceContainer
                )
                validateStagingContainer()
            }
            false
        }
    }


    /**
     * method to setup recyclerview
     */
    private fun setupRecyclerView() {
        partsReplacemenSourceContainerBinding.rvSerial.layoutManager =
            LinearLayoutManager(fragmentContext)
        serialListAdapter = PartsRepalcementSerialAdapter(containerNumberList as ArrayList<String>, getString(R.string.staging_container))
        partsReplacemenSourceContainerBinding.rvSerial.adapter = serialListAdapter
    }


    private fun validateStagingContainer() {
        val sourceContainer =
            partsReplacemenSourceContainerBinding.etSourceContainer.text.toString().trim()
        if (sourceContainer.isNotEmpty()) {
            partsReplacemenSourceContainerBinding.errResponses.text = null
            containerNumberValidate()
        } else {
            displayErrorMessage(resources.getString(R.string.parts_replacement_staging_container_error_message))
        }
    }

    private fun containerNumberValidate() {
        val taskDetails = viewModel.getMoveTaskDetails()
        if (taskDetails != null) {
            val serialNumber =
                partsReplacemenSourceContainerBinding.etSourceContainer.text.toString().trim()
            if (containerNumberList.size < viewModel.getSourceContianerCount()) {
                if (!containerNumberList.contains(serialNumber)) {
                    if (containerList.contains(serialNumber)) {
                        FlareLog.i(TAG, "serialList contains")
                        scannedSerial =
                            partsReplacemenSourceContainerBinding.etSourceContainer.text.toString()
                                .trim()
                        showSuccessSnackBar(resources.getString(R.string.parts_replacement_staging_container_completed))
                        serialNumberUpdate()
                    }
                } else {
                    displayErrorMessage(resources.getString(R.string.parts_replacement_staging_container_duplicate))
                }
            } else {
                partsReplacemenSourceContainerBinding.etSourceContainer.text = null
                navigateToPartsReplacementToteFragment()
            }
        }
    }

    private fun serialNumberUpdate() {
        containerNumberList.add(
            partsReplacemenSourceContainerBinding.etSourceContainer.text.toString().trim()
        )
        serialListAdapter.notifyDataSetChanged()
        partsReplacemenSourceContainerBinding.etSourceContainer.text = null
        val taskDetail = viewModel.getMoveTaskDetails()
        if (taskDetail != null) {
            partsReplacemenSourceContainerBinding.tvContainerValue.text = String.format(
                getString(R.string.actual_by_required),
                containerNumberList.size,
                viewModel.getSourceContianerCount()
            )
            if (containerNumberList.size == viewModel.getSourceContianerCount()) {
                partsReplacemenSourceContainerBinding.etSourceContainer.isEnabled = false
                saveContainerListToSharedPref()
                navigateToPartsReplacementToteFragment()
            } else {
                partsReplacemenSourceContainerBinding.tvStagingContainerValue.text =
                    containerList.get(containerNumberList.size)
            }
        }
        scannedSerial = ""

    }

    private fun saveContainerListToSharedPref() {
        val json = Gson().toJson(containerNumberList)
        sharedPreferences.edit()
            .putString(PreferenceKeys.PartsReplacement.REPAIR_CONTAINER_NUMBER_LIST, json).apply()
    }


    override fun onScan(scan: Scan?) {
        FlareLog.i(TAG, "onScan: $scan")
        super.onScan(scan)
        if (isProgressBarVisible()) {
            return
        }
        partsReplacemenSourceContainerBinding.etSourceContainer.setText(scan?.barcode.toString())
        partsReplacemenSourceContainerBinding.etSourceContainer.text?.length?.let {
            partsReplacemenSourceContainerBinding.etSourceContainer.setSelection(it)
        }
        validateStagingContainer()
    }

    override fun setCustomVisibilityCallback(cb: CustomVisibilityCallback?) {
        cb?.let {
            cb1 = cb
            cb.onVisibilityChange(true)
        }
    }

    override fun onScanError(scanRaw: String?, ex: Exception?) {
        FlareLog.e(TAG, "onScanError: $scanRaw")
    }


    private fun displayErrorMessage(errorMessage: String) {
        partsReplacemenSourceContainerBinding.errResponses.text = errorMessage
        partsReplacemenSourceContainerBinding.etSourceContainer.requestFocus()
        partsReplacemenSourceContainerBinding.etSourceContainer.selectAll()
        showSoftKeyBoard(fragmentContext, partsReplacemenSourceContainerBinding.etSourceContainer)
    }

    private fun navigateToPartsReplacementToteFragment() {
        viewModel.resetSrcContainerNumber()
        val action = PartsReplacementSourceContainerFragmentDirections.actionPartsReplacementSourceContainerFragmentToPartsReplacementToteFragment()
        findNavController().navigate(action)
    }
}