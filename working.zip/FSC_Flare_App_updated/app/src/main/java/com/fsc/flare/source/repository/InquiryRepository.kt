package com.fsc.flare.source.repository

import android.content.SharedPreferences
import com.fsc.flare.source.data.api.ApiGatewayInterface
import com.fsc.flare.source.data.dto.containertracking.getdetails.GetContDetailRequest
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPalletInquiryRequest
import com.fsc.flare.source.data.dto.inquiry.asn.ASNPrintPalletRequest
import com.fsc.flare.source.data.dto.inquiry.asn.ASNRenamePalletRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.MPRTransParamRequest
import com.fsc.flare.source.data.dto.masterpalletrepack.PrinterConfigRequest
import com.fsc.flare.source.data.dto.receiving.ReceivingASNRequest
import com.fsc.flare.utils.PreferenceKeys
import java.math.BigInteger
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InquiryRepository @Inject constructor(
    private val apiGatewayInterface: ApiGatewayInterface,
    private val sharedPreferences: SharedPreferences,
) {
    suspend fun getItemsInContainer(containerNum: String) = apiGatewayInterface.getInquiryContainer(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        containerNbr = containerNum
    )

    suspend fun getLocationInfo(locBarCode: String) = apiGatewayInterface.getLocationDetails(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        customerId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        facility = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        barcode = locBarCode,
        locationStatus= "All"
    )

    suspend fun getDockDoorInfo(locBarCode: String) = apiGatewayInterface.getDockDoorInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locBarCode = locBarCode,
        locClass = "DD"
    )

    suspend fun getInquiryItemInfo(itemBarcode: String) = apiGatewayInterface.getInquiryItemInfo(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        responseFilter = "summary",
        itemBarcode = itemBarcode,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1)
    )

    suspend fun getSLPDetails(slp: BigInteger) = apiGatewayInterface.getSLPDetails(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        slp = slp
    )

    suspend fun getInventoryTransferSlpInquiryDetail(slp: String) = apiGatewayInterface.getInventoryTransferSlpInquiry(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        slp = slp,
        includeCCLocation = if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)) "Y" else "N"
    )

    suspend fun inventoryTransferContainerResponse(getContDetailRequest: GetContDetailRequest) =
        apiGatewayInterface.inventoryTransferContainerInquiryResponse(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            containerNbr = getContDetailRequest.containerNbr,
            custId = getContDetailRequest.custId,
            buId = getContDetailRequest.buId,
            fcyId = getContDetailRequest.fcyId,
            includeCCLocation = getContDetailRequest.includeCCLocation,
        )

    suspend fun getInventoryTransferSerialInquiryDetail(serial: String) = apiGatewayInterface.getInventoryTransferSerialInquiry(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1).toString(),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1).toString(),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1).toString(),
        serial = serial,
        includeCCLocation = if(sharedPreferences.getBoolean(PreferenceKeys.AllOW_OPS_ON_CC_PENDING_LOCATION,false)) "Y" else "N"
    )

    suspend fun getASNDetails(receivingASNRequest: ReceivingASNRequest) =
        apiGatewayInterface.getReceivingASNDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            customerId=sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            pageLimit = receivingASNRequest.pageLimit,
            asnNumber = receivingASNRequest.asnNumber
        )


    suspend fun getPalletDetails(asnPalletInquiryRequest: ASNPalletInquiryRequest) =
        apiGatewayInterface.getASNInquiryPalletDetails(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = asnPalletInquiryRequest.custId,
            buId = asnPalletInquiryRequest.buId,
            fcyId = asnPalletInquiryRequest.fcyId,
         //   asnId = asnPalletInquiryRequest.asnId,
            container = asnPalletInquiryRequest.container
        )

    suspend fun getPrintRequestorList(printerConfigRequest: PrinterConfigRequest) = apiGatewayInterface.masterPalletRepackGetPrintRequestorList(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        fcyId = printerConfigRequest.fcyId,
        page = printerConfigRequest.page,
        pageLimit = printerConfigRequest.pageLimit,
        printerType = printerConfigRequest.printerType
    )

    suspend fun getMPRTransactionParam(mprTransParamRequest: MPRTransParamRequest) = apiGatewayInterface.masterPalletRepackGetTransactionParam(
        gatewayToken = "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        fedexId = sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        custId = mprTransParamRequest.custId,
        buId = mprTransParamRequest.buId,
        fcyId = mprTransParamRequest.fcyId,
        transCode = mprTransParamRequest.transCode
    )

    suspend fun generatePalletCaseNumber() =
        apiGatewayInterface.generatePalletCaseNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            type = "pallet"
        )

    suspend fun renamePalletNumber(renamePalletRequest: ASNRenamePalletRequest) =
        apiGatewayInterface.renameASNPalletNumber(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            renamePalletRequest
        )

    suspend fun printPalletLabel(renamePalletRequest: ASNPrintPalletRequest) =
        apiGatewayInterface.printASNPalletLabel(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            renamePalletRequest
        )

    suspend fun getLocationInventory(location: String,  page: Int , pageLimit: Int) = apiGatewayInterface.getLocationInventory(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
        cusId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationBarCode = location,
        page = page,
        pageLimit = pageLimit
    )

    suspend fun getPalletInventory(palletNumber: String, page: Int, pageLimit: Int) =
        apiGatewayInterface.getPalletInventory(
            "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
            sharedPreferences.getString(PreferenceKeys.FEDEX_ID, null)!!,
            custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
            buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
            fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
            palletNumber = palletNumber,
            page = page,
            pageLimit = pageLimit
        )

    suspend fun getLocationInventoryCount(locationId: String) = apiGatewayInterface.getLocationInventoryCount(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        custId = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        buId = sharedPreferences.getInt(PreferenceKeys.BUSINESS_UNIT_ID, -1),
        fcyId = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationId = locationId,
    )

    suspend fun getRlogLocationInquiry(locationBarcode: String) = apiGatewayInterface.rlogLocationInquiry(
        "Bearer ${sharedPreferences.getString(PreferenceKeys.API_GATEWAY_ACCESS_TOKEN, null)}",
        sharedPreferences.getString(PreferenceKeys.FEDEX_ID, "")!!,
        customer = sharedPreferences.getInt(PreferenceKeys.CUST_ID, -1),
        warehouse = sharedPreferences.getInt(PreferenceKeys.FACILITY_ID, -1),
        locationBarcode = locationBarcode,
    )
}